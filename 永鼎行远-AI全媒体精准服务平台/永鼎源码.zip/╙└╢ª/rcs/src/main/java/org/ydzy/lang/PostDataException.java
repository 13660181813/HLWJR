package org.ydzy.lang;

public class PostDataException extends RuntimeException {

    @java.io.Serial
    private static final long serialVersionUID = 5151710183389028792L;

    /**
     * Constructs a {@code PostDataException} with no detail message.
     */
    public PostDataException() {
        super();
    }

    Exception innerExeption ;
    public PostDataException(Exception e)
    {
    	super();
    	this.innerExeption=e;
    }
    /**
     * Constructs a {@code PostDataException} with the specified
     * detail message.
     *
     * @param   s   the detail message.
     */
    public PostDataException(String s) {
        super(s);
    }

    
    public String getMessage() {
        String message = super.getMessage();
        if (innerExeption != null) {
            return innerExeption.getMessage();
        }
        return message;
    }

    private native String getExtendedNPEMessage();


}
