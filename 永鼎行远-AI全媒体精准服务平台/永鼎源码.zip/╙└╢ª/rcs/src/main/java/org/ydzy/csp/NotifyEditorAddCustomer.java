package org.ydzy.csp;

import java.io.IOException;
import java.nio.charset.Charset;

import org.ydzy.csp.service.BaseCspInter;
import org.ydzy.handler.BaseHandler;
import org.ydzy.rcs.Provider;
import org.ydzy.util.StreamsUtil;
import org.ydzy.util.Util;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class NotifyEditorAddCustomer extends BaseHandler {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6887206568528860217L;
	private String ispName="";//String name="telcsp"

	public String getIspName() {
		return ispName;
	}

	public void setIspName(String ispName) {
		this.ispName = ispName;
	}

	/**
	 *
	 */
	@Override
	public void handle(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		BaseCspInter cspimp=Provider.getInstance(BaseCspInter.class, ispName);
		String body = StreamsUtil.copyToString(request.getInputStream(), Charset.forName("UTF-8"));
		JsonObject object = null;
		if (!Util.isNull(body)) {
			JsonElement ele = JsonParser.parseString(body);
			object = ele.getAsJsonObject();
		}
		org.ydzy.csp.service.BaseCspInter.TaskInner task=new org.ydzy.csp.service.BaseCspInter.TaskInner();
		task.body=object;
		task.ds=ds;
		task.request=request;
		task.response=response;
		boolean flag = cspimp.validateHeader(request,ds);
		if (!flag) {
			String resbody1 = resBodyJson("500", "accessToken validate failed or timeout", null);
			try {
				sendResponse(BaseHandler.getIpAddress(request), resbody1, 200, request, response);
				return;
			} catch (IOException e) {
				e.printStackTrace();
			}
		} else {
			String type=Util.getElementAsString(object, "type");
			/*
			 *11 �ͻ���Ϣ���֪ͨ
		 ֪ͨ���ͣ�1��������2�������3��ɾ��
			 */
			if("1".equals(type)) //add
			{
				task.doretryRMI = Boolean.FALSE;
				cspimp.addCspCustomer(task);
			}else if("2".equals(type))
			{
				task.doretryRMI = Boolean.FALSE;
				cspimp.editCspCustomer(task);
			}else if("3".equals(type))
			{
				task.doretryRMI = Boolean.FALSE;
				cspimp.deleteCustomer(task);
			}
		}
	}

}
