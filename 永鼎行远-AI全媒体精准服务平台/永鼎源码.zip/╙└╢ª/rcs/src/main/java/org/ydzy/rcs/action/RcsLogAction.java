package org.ydzy.rcs.action;

import java.lang.reflect.Field;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Enumeration;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.ydzy.bot.BotUtil;
import org.ydzy.rcs.BodyTransform;
import org.ydzy.rcs.RcsConfig;
import org.ydzy.rcs.RcsGeo;
import org.ydzy.rcs.db.DbType;
import org.ydzy.rcs.db.XmlSqlGenerator;
import org.ydzy.rcs.entity.ReceiveEntity;
import org.ydzy.thirdparty.util.MsgUtils;
import org.ydzy.util.SqlUtil;
import org.ydzy.util.TimeUtil;
import org.ydzy.util.Util;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;
import com.google.inject.Inject;
import com.google.inject.Singleton;
import com.google.inject.name.Named;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@Singleton
public class RcsLogAction {
	static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(RcsLogAction.class);

	@Inject
	MsgUtils msgutl;
	@Inject(optional = true)
	private RcsConfig config;
	private String insertSql;
	private DataSource dataSource = null;

	@Inject
	public RcsLogAction(@Named("rcsDb") DataSource dataSource, @Named("rcsDb.DbType") String dbTypestr) {
		super();
		this.dataSource = dataSource;
		if (Util.isNull(insertSql)) {
			DbType dbType = DbType.valueof(dbTypestr);
			XmlSqlGenerator.init(dbType.desc, "sqls/current");
			insertSql = XmlSqlGenerator.getSqlstr("recordLogs");
		}
	}

	Gson gson = new Gson();

	public static class LogRecord{
		public String phone = null;
		public String endPoint = "";
		public String userName;
		public String chatbotid;

		public String body = null;
		public String showType = null;
		public String toward = null;
		private String peer = null;
		public Number lat = null;
		public Number lng = null;
		public String nick = null;

		public String logTime = null;
		public String msgId=null;
		public String deliverystatus=null;
		public String isanswer=null; 
	}
	/** ���SendLog ��Ϣ�ӿ� */
	static interface IParseLogSend{
		boolean parse(LogRecord r);
	}

	/** chatbox �û�������Ϣ */
	protected boolean parseLogSend(ReceiveEntity message, LogRecord r) {
		if (message != null && message.getReceive5GMsg() != null) {
			JsonObject reqObject = message.getReceive5GMsg();
			JsonObject query = (JsonObject)message.getAnswersObject().get("query");
			if(query !=null && query.size()>0)
			{
				r.nick=Util.getElementAsString(query, "nick");
			}
			r.isanswer=Util.toString(message.getAnswersObject().get("isanswer"));
			Object o = reqObject.get("sendObject");
			if (o != null && o instanceof JsonObject) {
				JsonObject jo = (JsonObject) o;
				r.showType = Util.getElementAsString(jo, "showType", null);
				r.toward = Util.getElementAsString(jo, "type", null);
				r.body = Util.getElementAsString(jo, "text", null);
				r.peer = Util.getElementAsString(jo, "target", null);
				/*
				 * lat: 39.921806 lng: 116.399059 showType: "loaction"
				 */
				if ("loaction".equals(r.showType)) {
					r.lat = BotUtil.getElementAsNumber(jo, "lat");
					if (r.lat != null)
						r.lat = r.lat.doubleValue();
					r.lng = BotUtil.getElementAsNumber(jo, "lng");
					if (r.lng != null)
						r.lng = r.lng.doubleValue();
				}
			}
		}
		if (r.body == null) {
			RcsGeo geo = RcsGeo.parse(message.getRawcontent());
			if (geo != null) {
				r.showType = "loaction";
				r.lat = geo.getLat();
				r.lng = geo.getLng();
				r.body = geo.getRcs1();
			} else {
				r.body = message.getContent();
			}
		}
		if (r.peer == null || r.peer.isEmpty()) {
			r.peer = message.getDestinationAddress();
			if (r.peer == null || r.peer.isEmpty())
				r.peer = message.sendTo;
		}
		return true;
	}
	
	/** �û�������������Ϣ */
	public boolean logSend(HttpServletRequest request, HttpServletResponse response, final JsonObject reqObject) {
		IParseLogSend parse = (r) ->{
			JsonElement je = reqObject.get("receive5GMsg");
			if(je==null || !je.isJsonObject())return false;
			JsonObject jo = je.getAsJsonObject();
			r.phone = Util.getElementAsString(reqObject, "mdn");
			if(Util.isNull(r.phone))r.phone = Util.getElementAsString(jo, "senderAddress");
			int p1;
			if(r.phone!=null && (p1=r.phone.indexOf('@'))>0) {
				int p2 = r.phone.indexOf(':');
				String mdn = r.phone.substring(p2>=0&p2<p1?(p2+1):0, p1);
				if(mdn.startsWith("+86"))mdn = mdn.substring(3);
				r.phone = mdn;
			}
			r.msgId=Util.getElementAsString(reqObject, "msgId");
			r.showType = Util.getElementAsString(reqObject, "showType", null);
			r.toward = Util.getElementAsString(reqObject, "toward", null);
			r.body = Util.getElementAsString(reqObject, "content", null);
			if(r.body==null) {
				r.body = Util.getElementAsString(jo, "bodyText", null);
			}
			
			String chatbotID =  Util.getElementAsString(reqObject, "chatBotID", null);
			r.chatbotid = chatbotID;
			r.peer = Util.getElementAsString(jo, "destinationAddress", null);
			r.isanswer=Util.toString(reqObject.get("isanswer"));
			if(Util.isNull(r.peer)) r.peer = chatbotID;
			if(Util.isNull(r.logTime)) r.logTime = TimeUtil.format(System.currentTimeMillis());
			if(Util.isNull(r.msgId))r.msgId=String.valueOf((r.phone+r.logTime).hashCode());
			return true;
		};
		return logSend(parse);
	}

	/** �û�������������Ϣ */
	public boolean logSend(HttpServletRequest request, HttpServletResponse response, final BodyTransform transform) {
		transform.receiveEntity.receiveMsgTime = TimeUtil.format(System.currentTimeMillis());
		IParseLogSend parse = (r) ->{
			r.phone = transform.receiveEntity.getMdn();
			r.logTime = transform.receiveEntity.receiveMsgTime;
			r.msgId=transform.receiveEntity.requestMSGID;
			r.isanswer=Util.toString(transform.receiveEntity.getAnswersObject().get("isanswer"));
			ReceiveEntity message = transform.receiveEntity;
			parseLogSend(message, r);
			if(message != null) {
				if(message.getAnswersObject() != null)r.userName =  (String) message.getAnswersObject().get("userName");
				r.chatbotid = message.getChatBotId();
			}
			if(Util.isNull(r.msgId))r.msgId=String.valueOf((r.phone+r.logTime).hashCode());
			return true;
		};
		return logSend(parse);
	}
	
	
	protected boolean logSend(IParseLogSend parse) {
		try {
			LogRecord r = new LogRecord();
			if(!parse.parse(r)) return false;
			if (r.body == null || r.body.isEmpty())
				return false;
			if (r.showType == null)
				r.showType = "text";
			if (r.toward == null || r.toward.length() <= 0) {
				r.toward = "S";
			} else {
				r.toward = r.toward.charAt(0) == 'R' || r.toward.charAt(0) == 'r' ? "R" : "S";
			}

			if (config != null) {
				String appId = config.enterpriseProperty(r.chatbotid, "appId");
				if (appId != null && !appId.isEmpty())
					r.chatbotid = appId;
			}
			// phone,toward,showType,isShowMenu,bodyText
			List<Object> list = new ArrayList<>();
			list.add(r.msgId);
			list.add(r.logTime);
			list.add(r.phone);
			list.add(r.toward);
			list.add(r.showType);
			list.add(r.peer);
			list.add(r.lat);
			list.add(r.lng);
			list.add(r.body);
			list.add(r.chatbotid);
			list.add(null);
			list.add(r.userName);
			list.add(r.nick);
			list.add(r.endPoint!=null?r.endPoint:r.userName);
			list.add("");
			list.add(r.isanswer);
			String sql = XmlSqlGenerator.getSqlstr("insertSessionLogs");
			try {
				SqlUtil.updateRecords(dataSource, sql, list.toArray());
			} catch (SQLException e1) {
				log.error("Insert log error, {} {}", sql, list);
			}
		} catch (Exception e) {
			log.error("run logSend error", e);;
		}
		return true;
	}

//	/** �û�����Ϣ ���������û�����Ϣ */
//	public boolean logReceive(ReceiveEntity message) {
//		message.setMsgId(message.hashCode()+""+System.currentTimeMillis());
//		return logReceive(message, null);
//
//	}

	/** �û�����Ϣ ���������û�����Ϣ */
	public boolean logReceive(ReceiveEntity message, String phone) {
		try {
			String body = null;
			String showType = null;
			String toward = null;
			String peer = null;
			Number lat = null;
			Number lng = null;
			String nick = null;
			Object o = null;
			String boxId=null;
			message.responseMsgTime = Util.isNull(message.responseMsgTime) ? TimeUtil.format(System.currentTimeMillis()) : message.responseMsgTime;
			String logTime = message.responseMsgTime;
			if (message != null && message.getAnswersObject() != null) {
				o = message.getAnswersObject().get("sendObject");
				boxId=Util.toString(message.getAnswersObject().get("boxId"));
				if (o != null && o instanceof JsonObject) {
					JsonObject jo = (JsonObject) o;
					showType = Util.getElementAsString(jo, "showType", null);
					toward = Util.getElementAsString(jo, "type", null);
					if (jo.has("text") && jo.get("text").isJsonObject()) {
						jo.get("text").getAsJsonObject().addProperty("configCssClassName", Util.toString(message.getAnswersObject().get("configCssClassName"), ""));
					}
					body = Util.getElementAsString(jo, "text", null);
					peer = Util.getElementAsString(jo, "target", null);
					nick = Util.getElementAsString(jo, "nick", null);
				}
				if (body == null) {
					o = message.getAnswersObject().get("resObject");
					if (o != null && o instanceof JsonObject) {
						JsonObject jo = (JsonObject) o;
						jo.addProperty("configCssClassName", Util.toString(message.getAnswersObject().get("configCssClassName"), ""));
						String[] tmps = this.getCardSessionBody(jo);
						body = tmps[1];
						showType = tmps[0];
						toward = Util.getElementAsString(jo, "type", null);
						peer = Util.getElementAsString(jo, "target", null);
						nick = Util.getElementAsString(jo, "nick", null);
					}
				}
				if (nick == null)
					nick = (String) message.getAnswersObject().get("nick");
				if (peer == null) {
					peer=Util.toString(message.getAnswersObject().get("targetId"));
					if(Util.isNull(peer))
					peer = message.getSenderAddress() .equals( phone) ? message.getDestinationAddress()
							: message.getSenderAddress();
				}
			}
			if (body == null || body.isEmpty())
				return false;
			RcsGeo geo = RcsGeo.parse(body);
			if (geo != null) {
				showType = "loaction";
				lat = geo.getLat();
				lng = geo.getLng();
				body = geo.getRcs1();
			}
			if (showType == null)
				showType = body.startsWith("[{") && body.endsWith("}]") ? "cards" : "text";
			if (toward == null || toward.length() <= 0) {
				toward = "R";
			} else {
				toward = toward.charAt(0) == 'R' || toward.charAt(0) == 'r' ? "R" : "S";
			}

			if ("S".equals(toward)) {
				// ˵������ͬ�� �û��ķ���Ϣ �����Ϣ���յ�ʱ�Ѿ���¼������ֱ�Ӻ���
				return false;
			}

			if (phone == null || phone.isEmpty()) {
				if ("R".equals(toward)) {//&&!"system".equals(boxId)
					phone = message.senderAddress;
					peer =message.getDestinationAddress();
				} else {
					phone = message.getDestinationAddress();
					peer = message.senderAddress;
				}
			}
			String userName = message == null || message.getAnswersObject() == null ? null
					: (String) message.getAnswersObject().get("userName");
			String chatbotid = message.getChatBotId();
			if (config != null) {
				String appId = config.enterpriseProperty(chatbotid, "appId");
				if (appId != null && !appId.isEmpty())
					chatbotid = appId;
			}
			String endPoint = message.destinationEndPoint;
			
			// phone,toward,showType,isShowMenu,bodyText
			List<Object> list = new ArrayList<>();
			list.add(message.getMsgId());
			list.add(logTime);
			list.add(phone);
			list.add(toward);
			list.add(showType);
			list.add(peer);
			list.add(lat);
			list.add(lng);
			list.add(body);
			list.add(chatbotid);
			list.add(null);
			list.add(userName);
			list.add(nick);
			list.add(endPoint==null?"":endPoint);
			list.add("");
			list.add(Util.toString(message.getAnswersObject().get("isanswer")));
			String sql = XmlSqlGenerator.getSqlByJson("insertSessionLogs", "", null);

			try {
				SqlUtil.updateRecords(dataSource, sql, list.toArray());
			} catch (SQLException e1) {
				log.error("Insert log error,%s", sql, e1);
			}
		} catch (Exception e) {
			log.warn("write session log error", e);
			;
		}
		return true;
	}

//	/** �û�����Ϣ ���������û�����Ϣ */
//	public boolean logReceive(BodyTransform transform) {
//		transform.receiveEntity.setMsgId(transform.receiveEntity.hashCode()+""+System.currentTimeMillis());
//		return logReceive(transform.receiveEntity, transform.receiveEntity.senderAddress);
//	}

	// 2021-05-26
	static final long KEY_DATE = 1621987200000L;

	/**
	 * ���� ������� showType �� body
	 * 
	 * @param message
	 * @return ���� [showType, Body]
	 */
	protected String[] getCardSessionBody(JsonObject message) {
		if (message == null)
			return null;
		JsonObject jo;
		JsonElement je;

		String rBody = null;
		String showType = null;
		je = message.get("body");
		if (je != null && !je.isJsonNull()) {
			if (!je.isJsonObject()) {
				// {"body":"��������Ҫȥ��Ŀ�ĵ�ַ","globalSuggestion":[],"modelParam":{}}
				rBody = je.getAsString();
				showType = "text";
			} else if (message.has("isShowMenu") && System.currentTimeMillis() > KEY_DATE) {
				// ���ǵ�������, 5-26���Ժ����ɵ����ݲ�ȫ��ת��data
				rBody = gson.toJson(message);
				showType = "data";
			} else {
				jo = je.getAsJsonObject();
				jo = jo.get("message").getAsJsonObject();
				List<JsonElement> list = new ArrayList<>();
				je = jo.get("generalPurposeCardCarousel");
				if (je != null && je.isJsonObject()) {
					je = je.getAsJsonObject().get("content");
					if (je != null && je.isJsonArray()) {
						JsonArray ja = je.getAsJsonArray();
						for (int i = 0; i < ja.size(); i++) {
							list.add(ja.get(i));
						}
					}
				}
				je = jo.get("generalPurposeCard");
				if (je != null && je.isJsonObject()) {
					je = je.getAsJsonObject().get("content");
					if (je != null && je.isJsonObject()) {
						list.add(je.getAsJsonObject());
					}
				}
				rBody = gson.toJson(list);
				showType = "cards";
			}
		}
		return new String[] { showType, rBody };
	}

	static interface IHeaders {
		void headers(StringBuilder sb);
	}
	
	@Deprecated
	public boolean log(String inBody, BodyTransform transform, int delayMs, boolean succ) {
		return log(null, null, inBody, transform, delayMs, succ);
	}

	static class RequestHeaders implements IHeaders{
		HttpServletRequest request;
		RequestHeaders(HttpServletRequest request){
			this.request = request;
		}
		public void headers(StringBuilder sb) {
			sb.append(request.getMethod()).append(" ").append(request.getRequestURI());
			sb.append("\r\n");
			Enumeration<String> hNames = request == null ? null : request.getHeaderNames();
			if (hNames != null) {
				while (hNames.hasMoreElements()) {
					String hName = hNames.nextElement();
					sb.append(hName).append(" : ").append(request.getHeader(hName));
					sb.append("\r\n");
				}
			}
		}
	}
	static class ResponseHeaders implements IHeaders{
		HttpServletResponse response;
		ResponseHeaders(HttpServletResponse response){
			this.response = response;
		}
		public void headers(StringBuilder sb) {
			sb.append(response.getStatus());
			sb.append("\r\n");
			Collection<String> rHeaderNames = response.getHeaderNames();
			if (rHeaderNames != null) {
				for (String hName : rHeaderNames) {
					sb.append(hName).append(" : ").append(response.getHeader(hName));
					sb.append("\r\n");
				}
			}
		}
	}

	/** ��5G��Ϣ�� ���� ����������Ϣ */
	public boolean log(final HttpServletRequest request, final HttpServletResponse response, String inBody, JsonObject reqObject,
			String responseBody, int delayMs, boolean succ) {
		return this.log(request, response, inBody, reqObject, responseBody, delayMs, succ, null);
	}
	/** ��5G��Ϣ�� ���� ����������Ϣ */
	public boolean log(final HttpServletRequest request, final HttpServletResponse response, String inBody, JsonObject reqObject,
			String responseBody, int delayMs, boolean succ, String channel) {
		boolean flag = false;
		try {
			JsonObject jo = gson.toJsonTree(new ReceiveEntity()).getAsJsonObject();
			reqObject.entrySet().forEach( (v) ->  jo.add(v.getKey(), v.getValue()));
			boolean checkOk = false;
			JsonElement je = reqObject.get("receive5GMsg");
			if(je!=null && je.isJsonObject()) {
				JsonObject jo1 = je.getAsJsonObject();
				jo1.entrySet().forEach( (v) -> jo.add(v.getKey(), v.getValue()));
				checkOk = true;
			}else {
				je = reqObject.get("messageList");
				checkOk = je!=null;
			}
			if(checkOk) {
				jo.addProperty("configId", Util.toString(jo.get("configid"), "-1"));
				jo.addProperty("errorCode", Util.toString(jo.get("errorCode"), "-1"));


				String mdn = BotUtil.getElementAsString(jo, "mdn");
				if(Util.isNull(mdn)) {
					mdn = BotUtil.getElementAsString(jo, "senderAddress");
					mdn = Util.spiltNumbers(mdn);
					jo.addProperty("mdn", mdn);
				}
				jo.addProperty("chatBotId", Util.toString(jo.get("chatBotId"), BotUtil.getElementAsString(jo, "destinationAddress")));
				jo.addProperty("keywords", Util.toString(jo.get("keywords"), BotUtil.getElementAsString(jo, "content")));
				
				jo.addProperty("channel", getRequestChannel(channel, request));
				flag = log(request==null?null:new RequestHeaders(request), response==null?null:new ResponseHeaders(response)
						, delayMs, succ, inBody, responseBody, jo, 'S');
				
				boolean makeSessionLog = true;
				if (jo!=null) {
					String sessionLog = Util.getElementAsString(jo, "sessionLog");
					if("0".equals(sessionLog)) makeSessionLog = false;
				}
				if(makeSessionLog)logSend(request, response, reqObject);
			}
		}catch(Exception e) {}
		return flag;
	}


	public boolean log(final HttpServletRequest request, final HttpServletResponse response, String inBody, BodyTransform transform,
			int delayMs, boolean succ) {
		return this.log(request, response, inBody, transform, delayMs, succ, null);
	}
	
	public boolean log(final HttpServletRequest request, final HttpServletResponse response, String inBody, BodyTransform transform,
			int delayMs, boolean succ, String channel) {
		JsonObject jo = null;
		 Gson gson = new Gson();
		ReceiveEntity body5G =gson.fromJson(gson.toJson(transform.receiveEntity),ReceiveEntity.class);
		try {
			String serviceCapability = body5G.serviceCapability;
			body5G.serviceCapability = "";
			body5G.getAnswersObject().putAll(transform.receiveEntity.getAnswersObject());
			JsonElement e = new Gson().toJsonTree(body5G);
			jo = e.getAsJsonObject();
			jo.addProperty("serviceCapability", serviceCapability);
			jo.addProperty("messageId", Util.getElementAsString(body5G.getReceive5GMsg(), "messageId"));
			
			jo.addProperty("channel", getRequestChannel(channel, request));
		}catch(Exception e) {}
		
		return jo==null?false:log(request==null?null:new RequestHeaders(request), response==null?null:new ResponseHeaders(response)
				, body5G, delayMs, succ, inBody, transform.responseBody, jo, 'S');
	}

	private String getRequestChannel(String channel, HttpServletRequest request) {
		if(channel==null && request!=null) {
			String url = request.getRequestURI();
			if(url.startsWith("/sms")) {
				channel = "sms";
			}else if(url.startsWith("/bot")) {
				channel = "bot";
			}else if(url.startsWith("/hw/messageNotification/msg")) {
				channel = "openapi";
			}else if(url.startsWith("/hw/msg")){
				//inner-tenant-id: 0000000000ghrIMXBORU
				//Inner-Service-Name: bingo
				if(request.getHeader("inner-tenant-id")!=null || request.getHeader("Inner-Service-Name")!=null) {
					channel = "hwbot";
				}else {
					channel = "chatbox";
				}
			}
		}
		return channel;
	}
	
	/**
	 * ����ʱ��
	 * 
	 * @param conn
	 * @param requestBody
	 * @param entity
	 * @param delayMs
	 * @param succ
	 * @return
	 */
	public boolean log(BotUtil.HttpInfo conn, String requestBody, ReceiveEntity entity, int delayMs, boolean succ) {
		try {
			//BodyTransform transform
			//ReceiveEntity entity = transform.receiveEntity;
			JsonElement e;
			entity.serviceCapability = "";
			e = new Gson().toJsonTree(entity);
			final JsonObject jo = e.getAsJsonObject();
			String serviceCapability = entity.serviceCapability;
			jo.addProperty("serviceCapability", serviceCapability);
			Object pack = entity.getAnswersObject().get("messagePack");
			if(pack!=null) {
				JsonObject jo1 = new Gson().toJsonTree(pack).getAsJsonObject();
				jo1.entrySet().forEach( (v) -> jo.add(v.getKey(), v.getValue()));
			}
			conn.getAttributes().forEach((k,v) -> jo.addProperty(k, Util.toString(v)));
			if(Util.isNull(Util.getElementAsString(jo, "keywords"))) {
				if(entity.getAnswersObject()!=null)jo.addProperty("keywords", String.valueOf(entity.getAnswersObject().get("msg")));
			}
			if(Util.isNull(Util.getElementAsString(jo, "mdn"))) {
				String dest = Util.getElementAsString(jo, "destinationAddress");
				if(!Util.isNull(dest)) {
					dest = Util.spiltNumbers(dest);
					jo.addProperty("mdn", dest);
				}
			}
			return log(conn == null?null:conn::getRequestHeaders, conn==null ? null : conn::getResponseHeaders
					, entity, delayMs, succ, requestBody, conn==null?"":conn.getResponseBody(),jo, 'R');
		}catch(Exception e) {}
		return false;
	}

	protected boolean log(IHeaders request, IHeaders response, ReceiveEntity entity, int delayMs, boolean succ,
			String requestBody, String responseBody, JsonObject jo, char toward) {
		boolean flag = false;
		try {
			boolean makeSessionLog = true;
			if (jo!=null) {
				Map<String, Object> answersObject = entity.getAnswersObject();
				jo.addProperty("configId", Util.toString(answersObject==null?null:answersObject.get("configid"), "-1"));
				jo.addProperty("download", new Gson().toJson(answersObject.get("download")));
				flag = log(request, response, delayMs, succ, requestBody, responseBody, jo, toward);
				
				String sessionLog = Util.getElementAsString(jo, "sessionLog");
				if("0".equals(sessionLog)) makeSessionLog = false;
			}
			
			if(makeSessionLog)this.logReceive(entity, entity.sendTo);
		} catch (Exception e) {
			log.warn("RcsLogAction log error(" + e.getMessage() + ")", e);
		}
		return flag;
	}

	protected boolean log(IHeaders request, IHeaders response, int delayMs, boolean succ,
			String requestBody, String responseBody, JsonObject jo, char toward) {
		JsonObject object = null;
		if (jo!=null) {
			object = jo;
			object.addProperty("deley", delayMs);
			object.addProperty("rspBodyText", responseBody!= null ? responseBody : "");
			StringBuilder reqWhole = new StringBuilder();
			if (request != null) {
				request.headers(reqWhole);
				reqWhole.append("\r\n");
			}
			if (requestBody != null)
				reqWhole.append(requestBody);
			
			object.addProperty("reqWhole", reqWhole.toString().replace('\'', ' '));
			StringBuilder rspWhole = new StringBuilder();
			if (response != null) {
				response.headers(rspWhole);
				rspWhole.append("\r\n");
			}
			rspWhole.append(responseBody != null ? responseBody : "");
			object.addProperty("rspWhole", rspWhole.toString().replace('\'', ' '));
			object.addProperty("toward", Character.toString(toward));
			
			//һЩ�ֶ�Ϊ��ʱ��Ĭ��ֵ
			// 1.1 ���ȸ���ReceiveEntity������������, �󲿷�ReceiveEntity�����Զ��Ǳ�����Ҫ��
			for(Field f:ReceiveEntity.class.getFields()) {
				Object v = jo.get(f.getName());
				if(v==null) {
					if(f.getClass().isAssignableFrom(Number.class)) {
						jo.addProperty(f.getName(), -1);
					}else {
						jo.addProperty(f.getName(), "");
					}
				}
			}
			// 1.2 �����һЩ����
			if(jo.get("configId")==null)jo.addProperty("configId", "-1");
			if(jo.get("errorCode")==null)jo.addProperty("errorCode", "-1");
			if(jo.get("description")==null)jo.addProperty("description", "");
			if(jo.get("subject")==null)jo.addProperty("subject", "");
			if(jo.get("remoteAddr")==null)jo.addProperty("remoteAddr", "");
			if(jo.get("channel")==null)jo.addProperty("channel", "");
			// 0�����ɹ� 1���ɹ� 2������ sent����Ϣ�ѷ��� failed����Ϣ����ʧ�� delivered����Ϣ���ʹ� displayed����Ϣ���Ķ� deliveredToNetwork����ת���ŷ��� revokeOk����Ϣ���سɹ� revokeFail����Ϣ����ʧ��
			if(jo.get("action_status")==null)jo.addProperty("action_status", succ?"1":"0");
			
			
			// 1.3 �������ܳ���������
			for(Map.Entry<String, JsonElement> e:jo.entrySet()) {
				if(e.getValue()!=null && e.getValue().isJsonArray()) {
					JsonArray ja = e.getValue().getAsJsonArray();
					String text;
					if(ja.size()==0) {
						text = "";
					}else if(ja.size()==1) {
						text = ja.get(0).toString();
					}else {
						text = ja.toString();
					}
					e.setValue(new JsonPrimitive(text));
				}
			}
			Object o = jo.get("serviceCapability");
			if(o!=null && o instanceof JsonArray) {
				jo.addProperty("serviceCapability", ((JsonArray)o).toString());
			}
			
			// 1.4 ��ǻظ�
			if('R'== toward && "1".equals(Util.getElementAsString(jo, "doReply"))) {
				String keywords = Util.getElementAsString(jo, "keywords");
				jo.addProperty("keywords", "re:" + keywords);
			}
			String sql = XmlSqlGenerator.getSqlByJson("recordLogs", "", object);
			try {
				return SqlUtil.updateRecords(dataSource, sql);
			} catch (SQLException e1) {
				log.error("Insert log error,%s", sql, e1);
			}
		}
		
		return false;
	}

	public String queryDeliveryStatus(String messageid){
		if(messageid==null ||messageid.isEmpty())return null;
		String sql = XmlSqlGenerator.getSqlstr("queryRecordLogsStatus", new Object[0]);
		if(Util.isNull(sql)) sql = "select deliveryStatus from rcs_logs WHERE messageId=? and log_date>?";
		LocalDateTime time =java.time.LocalDateTime.now();
		time.minusHours(1);
		try(
				Connection con = dataSource.getConnection();
				PreparedStatement stmt = con.prepareStatement(sql);
		){
			long t = time.atZone(ZoneId.systemDefault()).toEpochSecond();
			stmt.setString(1, messageid);
			stmt.setObject(2, new java.sql.Timestamp(t));
			ResultSet rs = stmt.executeQuery();
			if(rs.next()) {
				String text = rs.getString(1);
				return text;
			}
		}catch(SQLException e) {
			log.debug("Call sql error:" + sql, e);
			// ignore
		}
		return null;
	}
	
	public LogRecord querySessionLog(String msgid){
	/*
CREATE TABLE `rcs_session_log` (
  `msgid` int NOT NULL AUTO_INCREMENT,
  `logTime` timestamp NOT NULL COMMENT '��Ϣ����/����ʱ��',
  `phone` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '��ǰ�û�(phone/sid)',
  `endPoint` tinytext COMMENT '��ǰ�û�(phone/sid)��Ӧ�Ķ�',
  `userName` varchar(24) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '��Ϣ�����˶˶�Ӧ������username',
  `nick` varchar(50) DEFAULT NULL COMMENT '����Ϣ������',
  `chatbotid` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT 'chatbotid',
  `toward` varchar(1) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT 'S' COMMENT '��Ϣ���� S:�û�����Ϣ(send) A:�û�������Ϣ(accept)',
  `showType` varchar(12) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT 'T' COMMENT '��Ϣ��ʾ���� T:�ı�  C:��Ƭ��Ϣ(cards) ',
  `isShowMenu` varchar(1) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT '' COMMENT '�Ƿ���ʾ��Ϣ�˵� 1:���ݺ��˵�',
  `peer` varchar(60) DEFAULT NULL COMMENT '�Ի��ĶԶ�',
  `lat` float DEFAULT NULL COMMENT 'showTypeΪlocation,λ�õ�ά��',
  `lng` float DEFAULT NULL COMMENT 'showTypeΪlocation,λ�õľ���, ����null',
  `bodyText` text CHARACTER SET utf8 COLLATE utf8_general_ci COMMENT '��Ϣ����',
	 */
		
		if(msgid==null||msgid.isEmpty())return null;
		String sql = XmlSqlGenerator.getSqlstr("querySessionLogs", new Object[0]);
		if(Util.isNull(sql)) sql = "select * from rcs_session_log WHERE msgid=? and logTime>?";
		LocalDateTime time =java.time.LocalDateTime.now();
		time.minusDays(1);
		try(
				Connection con = dataSource.getConnection();
				PreparedStatement stmt = con.prepareStatement(sql);
		){
			long t = time.atZone(ZoneId.systemDefault()).toEpochSecond();
			stmt.setString(1, msgid);
			stmt.setObject(2, new java.sql.Timestamp(t));
			ResultSet rs = stmt.executeQuery();
			if(rs.next()){
				LogRecord record = new LogRecord();
				record.msgId = rs.getString("msgid");
				record.body = rs.getString("bodyText");
				record.phone = rs.getString("phone");
				record.endPoint = rs.getString("endPoint");
				record.userName = rs.getString("userName");
				record.nick = rs.getString("nick");
				record.chatbotid = rs.getString("chatbotid");
				record.toward = rs.getString("toward");
				record.showType = rs.getString("showType");
				//record.isShowMenu = rs.getString("isShowMenu");
				record.peer = rs.getString("peer");
				record.logTime = String.valueOf(rs.getTimestamp("logTime"));
				record.isanswer=rs.getString("isanswer");
				return record;
			}
		}catch(SQLException e) {
			log.warn("Call sql error:" + sql, e);
			// ignore
		}
		return null;
	}
	
	public static String getElementAsString(JsonObject object, String eleText) {
		if (object != null && object.get(eleText) != null && !object.get(eleText).isJsonNull())
			return object.get(eleText).getAsString();
		return "";
	}

}
