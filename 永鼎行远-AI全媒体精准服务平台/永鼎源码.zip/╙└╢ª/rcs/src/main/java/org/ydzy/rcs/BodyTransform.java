package org.ydzy.rcs;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.*;

import com.google.common.collect.Maps;
import org.apache.commons.beanutils.BeanUtils;
import org.json.XML;
import org.ydzy.bot.BotInfo;
import org.ydzy.bot.BotManager;
import org.ydzy.handler.BaseRcsContext;
import org.ydzy.handler.RcsSession;
import org.ydzy.rcs.decker.DeckerRobotProcesser;
import org.ydzy.rcs.entity.ReceiveEntity;
import org.ydzy.rcs.module.LoadProperties;
import org.ydzy.util.FileUtils;
import org.ydzy.util.TimeUtil;
import org.ydzy.util.Util;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonSyntaxException;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;

public class BodyTransform {
	private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(BodyTransform.class);
	public static final String USER_STATE = "userState";

	public ReceiveEntity receiveEntity;
	JsonObject requestBody;
	public String responseBody;
	HttpServletRequest request;
	public RcsConfig rcsConfig;
	public BaseRcsContext context;
	public RcsSession session;
	public boolean continued = true;
	public Map<String, Object> ResponseHeader;
	public static Map<String, String> phone2sidMap = Maps.newHashMap();

	public BodyTransform(JsonObject requestBody, BaseRcsContext context) {
		this(requestBody, null, context);

		if (request != null && "v2".equals(Util.getElementAsString(requestBody, "version")))
			responseBody = new Gson().toJson(XML.toJSONObject(responseBody));
//		if(!Util.isNull(responseBody))
//		receiveEntity.getAnswersObject().put("responseBody", responseBody);
	}

	private void sessions()
	{
		if(receiveEntity==null)
			return ;
		String sid="session_"+this.receiveEntity.getMdn().hashCode()+"_"+this.receiveEntity.getChatBotId().hashCode();
		session = context.getSession(sid);

		if (!Util.isNull(receiveEntity.getChatBotId()))
			session.put("spName", receiveEntity.getChatBotId());
		if (!Util.isNull(this.receiveEntity.getRemoteAddr()))
			session.put("remoteAddr", this.receiveEntity.getRemoteAddr());
		session.put("createTime", Instant.now().getNano());
		session.put("chatbotid", receiveEntity.getChatBotId());
		session.put("chatbotid_short", rcsConfig.enterpriseProperty(receiveEntity.getChatBotId(), "chatbotid"));
		if (!Util.isNull(this.receiveEntity.getMdn()))
			session.put("mdn", this.receiveEntity.getMdn());
		session.put("sid", sid);
		String sendTo = Util.toString(session.get("sendTo"));
		if (!Util.isNull(sendTo)) {
			this.receiveEntity.sendTo = sendTo;
		}
		if (rcsConfig.getChatbotInfo().get(receiveEntity.getChatBotId()) != null) {
			session.put(receiveEntity.getChatBotId(), rcsConfig.getChatbotInfo().get(receiveEntity.getChatBotId()));
			//third part user login info
			BotManager botManager = Provider.injector.getInstance(BotManager.class);
			BotInfo chatBotInfo = botManager.getChatBotInfo(receiveEntity.getChatBotId());
			if (chatBotInfo != null && chatBotInfo.getLoginServer() != null) {
				session.put("thirdpartUserInfo", chatBotInfo.getLoginServer().login(this, request));
			}
		}
		receiveEntity.getAnswersObject().put("sid", sid);
		if(session.containsKey("nick")&&!Util.isNull(session.get("nick").toString()))
		receiveEntity.getAnswersObject().put("nick", session.get("nick"));
		else {
			receiveEntity.getAnswersObject().put("nick", this.receiveEntity.getMdn());
			session.put("nick", this.receiveEntity.getMdn());
		}
		session.put("currentEntity",receiveEntity);

		JsonObject queryobj =(JsonObject) receiveEntity.getAnswersObject().get("query");
		if(queryobj!=null  && !queryobj.isJsonNull()) {
			String targetPhone = Util.getElementAsString(queryobj, "mdn");
			if (!Util.isNull(targetPhone)) {
				session.put("police_target_phone", targetPhone);
				phone2sidMap.put(targetPhone, receiveEntity.senderAddress);
			}
			session.put("newOrder",Util.getElementAsString(queryobj, "newOrder"));
		}
		if (session.containsKey("police_target_phone")) {
			receiveEntity.getAnswersObject().put("police_target_phone", session.get("police_target_phone"));
			if (!Util.isNull(receiveEntity.sendTo)) {
				RcsSession targetSession = context.getSession(receiveEntity.sendTo, receiveEntity.getChatBotId());
				targetSession.put("police_target_phone", session.get("police_target_phone"));
			} else {
				receiveEntity.getAnswersObject().put("police_target_phone", session.get("police_target_phone"));
			}
		}
		String driving=Util.toString(session.get("driving"));
		if(!Util.isNull(driving)) {
			receiveEntity.getAnswersObject().put("driving", driving);
		}

		if (session.containsKey("nick")) {
			if (!Util.isNull(receiveEntity.sendTo)) {
				RcsSession targetSession = context.getSession(receiveEntity.sendTo, receiveEntity.getChatBotId());
				targetSession.put("police_nick", session.get("nick"));
			}
		}
		if (session.containsKey("police_nick") && Util.isNull(receiveEntity.sendTo)) {
			receiveEntity.getAnswersObject().put("police_nick", session.get("police_nick"));
		}
	}
	public BodyTransform(JsonObject requestBody,HttpServletRequest request,BaseRcsContext context)
	{
		this.processer=Provider.injector.getInstance(DeckerRobotProcesser.class);
		this.request=request;
		this.context = context;
		this.rcsConfig=context.getConfig();
		this.requestBody=requestBody;
		request2Entity();
		receiveEntity.getAnswersObject().put("botInfo",context.getAttributes().get("chatbotinfo"));
		sessions();

//		if(!Util.isNull(responseBody))
//			receiveEntity.getAnswersObject().put("responseBody", responseBody);
	}
	DeckerRobotProcesser processer;

	/**
	 * @param send25gmsg true����5����Ϣ��false����H5��Ϣ
	 */
	public void transform(boolean send25gmsg) {
		processer.requestHandler(this, receiveEntity);
		if(Util.isNull(receiveEntity.getContent()) &&
				(receiveEntity.getAnswersObject()==null || receiveEntity.getAnswersObject().get("download")==null))
			return ;
		processer.doTransform(this, send25gmsg);
		receiveEntity.responseMsgTime = TimeUtil.format(System.currentTimeMillis());
//		try {
//			transFormAudio();
//		} catch (IOException e) {
//			e.printStackTrace();
//		}
//		JsonElement elementfind=checkIsKeyWords();
//		
//		checkAi(elementfind);
//		
//		if(session.get(USER_STATE)!=null)
//		{
//			StateManager sm = (StateManager)session.get(USER_STATE);
//			if(elementfind==null||(!elementfind.getAsJsonObject().get("keywords").equals(receiveEntity.getContent())))
//			{
//				elementfind=checkIsKeyWords();
//			}
//			//if(sm.getState().getState().runstep.stepid==(ProcedureStatus.process.RUN_FINISHED.stepid))
//			if(sm.getState().getState().runstep.hasTag(org.ydzy.handler.impl.Process.Tag.RUN_FINISHED))
//			{
//				session.remove(USER_STATE);
//			}
//		}
//		
//		if(elementfind==null && rcsConfig.getRobot()!=null && "1".equals(Util.getElementAsString(rcsConfig.getChatbotInfo().get(receiveEntity.getChatBotId()),"useAi"))){
//			elementfind = rcsConfig.getRobot().run(receiveEntity);
//		}
//		if(elementfind==null) {
//			receiveEntity.setContent("default");
//			elementfind=checkIsKeyWords();			
//		}
//		responseBody=Provider.parseContent(receiveEntity, elementfind,context);
//		//TODO  V2 
//		if(request!=null&&"v2".equals(request.getParameter("version")))
//		responseBody=new Gson().toJson(XML.toJSONObject(responseBody));
//		//TODO INTERFACE 
//		
//		String password = rcsConfig.enterpriseProperty(receiveEntity.getChatBotId(), "key");
//
//		Map<String, Object> header = headers(rcsConfig,password,receiveEntity.getChatBotId(),receiveEntity.getMdn(),"application/xml");
//		this.ResponseHeader=header;
	}

	private  JsonElement checkIsKeyWords()
	{
		String reqKeyWords = receiveEntity.getContent();
		JsonObject eobject=this.rcsConfig.getKeyWordsBysp(receiveEntity.getChatBotId(),reqKeyWords);
		if(eobject==null||eobject.isJsonNull())
			return null;
		else
		{
			receiveEntity.getAnswersObject().put("configid", Util.getElementAsString(eobject, "configid"));
			return  eobject;
		}

	}
	private String decodeContent(String contentType,String contentEncoding,String contentText)
	{
		if("text/plain".equals(contentType)||contentType.indexOf("text")>-1) {
			if("base64".equals(contentEncoding)||contentEncoding.indexOf("base64")>-1)
			{
				String tmp="";
				try {
					tmp = new String(Base64.getDecoder().decode(contentText),"UTF-8");
				} catch (UnsupportedEncodingException e) {
				}
				return tmp;
			}
			else
			{
				try {
					String tmp= new String(java.net.URLDecoder.decode(contentText,"UTF-8"));
					return tmp;
				} catch (UnsupportedEncodingException e1) {
				}

			}
		}else if("application/vnd.gsma.rcs-ft-http+xml".equals(contentType))
		{
			return contentText;
		}
		return "";
	}
	private String getKeyValue(String key)
	{
		String v=Util.getElementAsString(requestBody, key);
		if(Util.isNull(v))
			v=Util.getElementDeepAsString(requestBody, "outboundIMMessage",key);
		if(Util.isNull(v))
			v=Util.getElementDeepAsString(requestBody, "receive5GMsg",key);
		return v;

	}
	private String getKeyObjectValue(String key)
	{
		JsonElement e=requestBody.get(key);
		if(e==null&&requestBody.has("outboundIMMessage"))
			e=requestBody.getAsJsonObject("outboundIMMessage").get(key);
		if(e==null&&requestBody.has("receive5GMsg"))
			e=requestBody.getAsJsonObject("receive5GMsg").get(key);

		return e!=null?new Gson().toJson(e):"";

	}
	private void addDownload(ReceiveEntity entity,Map<String, Object> downloadinfo)
	{
		List<Map<String, Object>> dinofs=new ArrayList<Map<String,Object>>();
		if(entity.getAnswersObject().containsKey("download")) {
			dinofs=(List<Map<String, Object>>) entity.getAnswersObject().get("download");
		}
		if(dinofs==null)
			 dinofs=new ArrayList<Map<String,Object>>();
		if(downloadinfo!=null){
			setThumnail4Video(downloadinfo);
			dinofs.add(downloadinfo);
		}
		entity.getAnswersObject().put("download", dinofs);

	}



	/**
	 * Ϊ��Ƶ����Ƶ�ļ���������ͼ
	 * @param downloadinfo
	 */
	private Set medias = new HashSet();
	{
		medias.add("AMR");
		medias.add("MP3");
		medias.add("M4A");
		medias.add("MP4");
		medias.add("WEBM");
	}
	private void setThumnail4Video(Map<String, Object> downloadinfo){
		if (downloadinfo == null) {
			return;
		}
		// TODO: 2022/3/7 zxw ��ʱ����
		String defurl = "https://csp.bjydzy.com:22443/hw/media/uploadHw01646665520589.jpg";
		Object thhumbnailurlo = downloadinfo.get("thhumbnailurl");
		String urlo = (String) downloadinfo.get("url");

		if((urlo != null && urlo.equals(thhumbnailurlo)) || thhumbnailurlo == null){
			String[] split = urlo.split("\\.");
			if(split!= null && split.length > 1 && medias.contains(split[split.length-1].toUpperCase())){
				downloadinfo.put("thhumbnailurl", defurl);
				downloadinfo.put("thumbnailContentType", "image/jpg");
			}
		}
	}

	private void addDownloadList(ReceiveEntity entity,List<Map<String, Object>> downloadinfo)
	{
		List<Map<String, Object>> dinofs=new ArrayList<Map<String,Object>>();
		if(entity.getAnswersObject().containsKey("download")) {
			dinofs=(List<Map<String, Object>>) entity.getAnswersObject().get("download");
		}
		if(dinofs==null)
			 dinofs=new ArrayList<Map<String,Object>>();
		if(downloadinfo!=null){
			downloadinfo.forEach(el->{
				setThumnail4Video(el);
			});
			dinofs.addAll(downloadinfo);
		}
		entity.getAnswersObject().put("download", dinofs);

	}


	//BaseRcsContext context = contextProvidor.newBaseRcsContext();
//    org.ydzy.handler.RcsSession sessions=  context.getSession("app_"+username.hashCode());
//    sessions .put("chatbotid", chatbotid);
	public void request2Entity() {
		if (requestBody == null)
			return;
		ReceiveEntity entity = new ReceiveEntity();
		String query = Util.getElementAsString(requestBody, "query");
		String weburl = request != null ? request.getHeader("weburl"):null;
		if (!Util.isNull(weburl)) {
			entity.getAnswersObject().put("weburl", weburl + "/" + Util.toString(LoadProperties.systemProperties.get("publicenv.webPath")));
			entity.getAnswersObject().put("webapiurl", weburl + "/" + Util.toString(LoadProperties.systemProperties.get("publicenv.apiPath")));
		}
		Instant time1 = Instant.now();
		entity.requestMSGID = entity.hashCode() + "" + time1.getEpochSecond();
		String keywordsearch = Util.getElementAsString(requestBody, "keywordsearch");
		entity.getAnswersObject().put("keywordsearch", keywordsearch);
		//welcomeId
		String driving = Util.getElementAsString(requestBody, "driving");
		if (!Util.isNull(query)) {
			try {
				JsonObject queryobj = (JsonObject) JsonParser.parseString(query);
				entity.getAnswersObject().put("query", queryobj);
				if(queryobj!=null) {
				entity.getAnswersObject().put("reallysid", Util.getElementAsString(queryobj, "sid"));
				entity.getAnswersObject().put("newOrder", Util.getElementAsString(queryobj, "newOrder"));
				if(Util.isNull(driving))driving=Util.getElementAsString(queryobj, "driving");
				}
			} catch (JsonSyntaxException e) {
			}
		}
		entity.getAnswersObject().put("driving", driving);
		String userName=request!=null?request.getHeader("Username"):"";
		entity.getAnswersObject().put("userName", userName);
		String address = request!=null?request.getParameter("address"):"";
		if(Util.isNull(address))
		address = Util.getElementAsString(requestBody.getAsJsonObject("receive5GMsg"), "senderAddress");
		if(Util.isNull(address))
			address=Util.getElementAsString(requestBody, "senderAddress");
		String keywords=Util.getElementAsString(requestBody.getAsJsonObject("receive5GMsg"), "keywords");

		JsonArray messageList =requestBody.getAsJsonArray("messageList");

		String remoteAddr = getIpAddress(request);
		if(remoteAddr==null)remoteAddr = Util.getElementAsString(requestBody, "remoteAddr");
		String encode =  request!=null?request.getParameter("encode"):"";
//		String spName = request!=null?request.getParameter("spName"):"";
//		if (Util.isNull(spName))
//			spName = Util.getElementAsString(requestBody, "spName");
		String v= Util.getElementAsString(requestBody, "chatbotVersion");
		entity.getAnswersObject().put("chatbotVersion", v);

		String mdn=Util.getElementAsString(requestBody, "mdn");
		if(Util.isNull(mdn)) {
			mdn=Util.getElementAsString(requestBody, "senderAddress");
			if(Util.isNull(mdn))mdn=Util.getElementAsString(requestBody.getAsJsonObject("receive5GMsg"), "senderAddress");
		}
		if(!Util.isNull(mdn))
		mdn=Util.spiltNumbers(mdn);
		String destionationAddress=getKeyValue("destinationAddress");
		String messageId=getKeyValue("messageId");
		String conversationID=getKeyValue("conversationID");
		if(Util.isNull(conversationID))
			conversationID=getKeyValue("conversationId");
		entity.setMessageId(messageId);
		entity.conversationID=conversationID;
		String contributionID=getKeyValue("contributionID");

		if(Util.isNull(contributionID))
			contributionID=getKeyValue("contributionId");
		entity.contributionID=contributionID;
		String sendTo=Util.getElementAsString(requestBody, "sendTo");
		entity.sendTo=sendTo;
		String boxId=Util.getElementAsString(requestBody, "boxId");
		entity.getAnswersObject().put("boxId", boxId);
		if(Util.isNull(driving)&&!Util.isNull(sendTo))
		{
			entity.getAnswersObject().put("driving", userName);
		}
		String contentType1=getKeyValue("contentType");
		String contentEncoding1=getKeyValue("contentEncoding");

		String pchatid=Util.getElementAsString(requestBody, "chatbodid");
		entity.contentType=contentType1;
		if(!Util.isNull(pchatid))
		{
			if(Util.isNull(destionationAddress))
			{
				destionationAddress=pchatid;
			}
		}
		if(Util.isNull(destionationAddress)&&context.getSession(userName + "_" + mdn)!=null)
		{
			destionationAddress=Util.toString(context.getSession(userName + "_" + mdn).get("chatbotid"));
		}

		entity.rcsBodyText=getKeyValue("rcsBodyText");
		entity.contentEncoding=contentEncoding1;
		entity.setDestinationAddress(destionationAddress);
		String chatbotIdenty=destionationAddress;
		destionationAddress=Util.spiltNumbers(destionationAddress);


		String serviceCapability=getKeyObjectValue("serviceCapability");
		entity.serviceCapability=serviceCapability;
		String trafficType=getKeyValue("trafficType");
		entity.trafficType=trafficType;
		String smssupported=getKeyValue("smsSupported");
		entity.smssupported=smssupported;

		String imFormat=getKeyValue("imFormat");
		entity.imFormat=imFormat;

		String reportRequest=getKeyValue("reportRequest");
		entity.reportRequest=reportRequest;
		String storeSupported=getKeyValue("storeSupported");
		entity.storeSupported=storeSupported;
		String smsContent=getKeyValue("smsContent");
		entity.smsContent=smsContent;

		String inReplyToContributionID=getKeyValue("inReplyToContributionID");
		if(Util.isNull(inReplyToContributionID))
			inReplyToContributionID=getKeyValue("inReplyTo");
		entity.inReplyToContributionID=inReplyToContributionID;
		String fallbackSupported=getKeyValue("fallbackSupported");
		entity.fallbackSupported=fallbackSupported;

		String content=Util.getElementAsString(requestBody, "content");
		if(Util.isNull(content))
		{
			content=Util.getElementAsString(requestBody, "contentText");
		}
		String rawcontent=content;
		String manager=Util.getElementAsString(requestBody, "manager");
		entity.getAnswersObject().put("manager",manager);
		if(messageList!=null)
		{
			String contentList = null;
			for(JsonElement e :messageList)
			{
				JsonObject oj=e.getAsJsonObject();
				String contentType=Util.getElementAsString(oj, "contentType").toLowerCase().trim();
				String contentEncoding=Util.getElementAsString(oj, "contentEncoding").toLowerCase();
				String contentText =Util.getElementAsString(oj,"contentText");
				rawcontent = contentText;
				if(("application/vnd.gsma.rcs-ft-http+xml".equals(contentType) || "application/vnd.gsma.rcs-ft-http".equals(contentType))
						&& !Util.isNull(contentText)) {
					try {
						Map<String, Object>  downloadinfo=	FileUtils.doDownloadTelecom(oj.get("contentText"),"upload",destionationAddress);
						if(downloadinfo!=null)
							addDownload(entity,downloadinfo);

					} catch (IOException | ServletException e1) {
						log.warn("Get messageList file error(" + e1.getMessage() + ")", e);
					}
				}else {
					String tmp=decodeContent(contentType,contentEncoding,contentText);
					if(!Util.isNull(tmp))
						entity.contentType=contentType;
					entity.contentEncoding=contentEncoding;
					if(!Util.isNull(contentList))
						contentList+=" "+tmp;
					else
						contentList=tmp;
				}
			}
			if(contentList!=null&&contentList.length()>0)content = contentList;
			entity.setReceive5GMsg(requestBody);
		}else if(requestBody.has("contentType")&&requestBody.has("outboundIMMessage")) {
			String contentType =Util.getElementDeepAsString(requestBody,"outboundIMMessage", "contentType");
			String contentEncoding =Util.getElementDeepAsString(requestBody,"outboundIMMessage", "contentEncoding");
			String bodyText=Util.getElementDeepAsString(requestBody,"outboundIMMessage", "bodyText");
			String tmp=decodeContent(contentType,contentEncoding,bodyText);
			if(Util.isNull(tmp))
			{
				if("application/vnd.gsma.rcs-ft-http+xml".equals(contentType) && !Util.isNull(bodyText))
				{
					try {
						Map<String, Object>  downloadinfo=	FileUtils.doDownloadByC(bodyText,"upload",destionationAddress);
						if(downloadinfo!=null)
							addDownload(entity,downloadinfo);
					} catch (IOException | ServletException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				else
				{
					try {
						Map<String, Object>  downloadinfo=	FileUtils.doDownloadByPost(requestBody,"upload",destionationAddress);
						addDownload(entity,downloadinfo);
					} catch (IOException | ServletException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}else {
				if("application/vnd.gsma.rcs-ft-http+xml".equals(contentType)&&!Util.isNull(bodyText))
				{
					try {
						Map<String, Object>  downloadinfo=	FileUtils.doDownloadByC(bodyText,"upload",destionationAddress);
						if(downloadinfo!=null)
							addDownload(entity,downloadinfo);
						entity.setRawcontent(bodyText);
					} catch (IOException | ServletException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

				}
				else
				{
					entity.contentType=contentType;
					entity.contentEncoding=contentEncoding;
					if(!Util.isNull(content))
						content+=" "+tmp;
					else
						content=tmp;
				}
			}
			entity.setReceive5GMsg(requestBody);
		}
		else {
			JsonObject receive5GMsg =requestBody.getAsJsonObject("receive5GMsg");
			if(remoteAddr==null)remoteAddr = Util.getElementAsString(requestBody, "remoteAddr");
			String contentType =Util.getElementAsString(receive5GMsg, "contentType");
				String contentEncoding =Util.getElementAsString(receive5GMsg, "contentEncoding");
				String bodyText=Util.getElementAsString(receive5GMsg, "bodyText");
				if(!Util.isNull(bodyText))rawcontent = bodyText;
				String tmp=decodeContent(contentType,contentEncoding,bodyText);
				if(Util.isNull(contentType))
				{
					contentType =Util.getElementAsString(requestBody, "contentType");
					contentEncoding =Util.getElementAsString(requestBody, "contentEncoding");
				}
				if("application/vnd.gsma.rcs-ft-http".equals(contentType))
				{
					try {
						List<Map<String,Object>>  downloadinfo=	FileUtils.doDownloadByThirdParty(content,"upload",destionationAddress);
						if(downloadinfo!=null&&downloadinfo.size()>0)
							addDownloadList(entity,downloadinfo);
					} catch (IOException | ServletException e) {
						e.printStackTrace();
					}
				}
				else if("application/vnd.gsma.rcs-ft-http+xml".equals(contentType))
				{
					try {
						Map<String, Object>  downloadinfo=	FileUtils.doDownloadByC(tmp,"upload",destionationAddress);
						if(downloadinfo!=null)
						addDownload(entity,downloadinfo);
					} catch (IOException | ServletException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}else if(Util.isNull(tmp))
				{
					if(contentType.indexOf("botsuggestion.response.v1.0+json")>0 &&!Util.isNull(bodyText)) {
						if("base64".equals(contentEncoding)||contentEncoding.indexOf("base64")>-1)
						{
							try {
								bodyText = new String(Base64.getDecoder().decode(bodyText),"UTF-8");
							} catch (UnsupportedEncodingException e) {
							}
						}
						try {
							JsonElement e2 =JsonParser.parseString(bodyText);
							if(e2!=null&&e2.isJsonObject())
							{
								Map<?,?> map=new Gson().fromJson(e2, Map.class);
								try {
									if(map!=null) {

										content= BeanUtils.getNestedProperty(map,"response.reply.postback.data");

									}
								} catch (Exception e) {
									content="";
								}
							}
						} catch (JsonSyntaxException e) {
							content="";
						}
					}else {
						try {
							Map<String, Object>  downloadinfo=	FileUtils.doDownloadByPost(receive5GMsg,"upload",destionationAddress);
							addDownload(entity,downloadinfo);
						} catch (IOException | ServletException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				}
				else{
					entity.contentType=contentType;
					entity.contentEncoding=contentEncoding;
					if(!Util.isNull(content))
					;//	content+=" "+tmp
					else
						content=tmp;
				}
				entity.setReceive5GMsg(requestBody);
//				entity.setReceive5GMsg(receive5GMsg);

		}
		if(Util.isNull(keywords) && !Util.isNull(content)) {
			keywords = content;
		}
		try {
			content=java.net.URLDecoder.decode(content,"UTF-8");
			 String tmp="";
			//geo:26.586435171316765,106.72470059207059;u=0;crs=gcj02;rcs-l=%E8%B4%B5%E5%B7%9E%E7%9C%81%E8%B4%B5%E9%98%B3%E5%B8%82%E4%BA%91%E5%B2%A9%E5%8C%BA%3B%E8%B4%B5%E5%B7%9E%E7%9C%81%E8%B4%B5%E9%98%B3%E5%B8%82%E4%BA%91%E5%B2%A9%E5%8C%BA%E6%A0%96%E9%9C%9E%E7%A4%BE%E5%8C%BA%E6%9C%8D%E5%8A%A1%E4%B8%AD%E5%BF%83%E8%9E%BA%E8%9B%B3%E5%B1%B1%E8%B7%AF%E4%BA%91%E5%B2%A9%E5%8C%BA%E6%94%BF%E5%BA%9C%E6%97%AD%E4%B8%9C%E5%B0%8F%E5%8C%BA
			if(content.startsWith("geo"))
			{
				tmp=content.substring(content.indexOf("rcs-l=")+6);
			}
			if(!Util.isNull(tmp)) {
				content=tmp;
				entity.getAnswersObject().put("contentFromMap","true");
			}
		} catch (UnsupportedEncodingException e) {
		}
		/* Audio�Ѿ����� transFormAudio  image��δ����
<?xml version="1.0" encoding="UTF-8"?>
<file xmlns="urn:gsma:params:xml:ns:rcs:rcs:fthttp">
<file-info type="thumbnail">
<file-size>5620</file-size>
<content-type>image/jpeg</content-type>
<data url = "https://hn.ftcontentserver.rcs.mnc000.mcc460.pub.3gppnetwork.org:443/Access/PF?ID=MjcxQjQ2N0EzNTgyNTk4NDc4MDg2Mzg4RTIzMjA2RDdGNTFFRTQ1ODQ0QTg2NkI0NjlBODkxQTIxNUYzRUI0OTgwNUNEOEFFMTE1RTU3MEQ5RkQ1ODNGNjc0NDI3Rjg1" until = "2021-05-05T16:33:40Z"/>
</file-info>
<file-info type="file" file-disposition="attachment">
<file-size>55033</file-size>
<file-name>9886e44e-d21c-4c12-86e3-e86d7a41b0f8_tmp.jpg</file-name>
<content-type>image/jpeg</content-type>
<data url = "https://hn.ftcontentserver.rcs.mnc000.mcc460.pub.3gppnetwork.org:443/Access/PF?ID=MDVCODYxNEU0NTUzREM4NDNEMDIxQURGRDBBREFDOURFOEM0N0M1RjBGREZEN0I2MTFDMzRFRUQ2N0Q5RkI4ODAwQzY1NjQxMkY1RjAzODRDOUNEOTI3M0E4MTMxRERC" until = "2021-05-05T16:33:40Z"/>
</file-info>
</file>
		 */

		String subject=Util.getElementAsString(requestBody.getAsJsonObject("receive5GMsg"), "subject");
		entity.setSenderAddress(address);
		entity.setKeywords(Util.isNull(content)?keywords:content);
		entity.setRemoteAddr(remoteAddr);
		entity.setEncode(encode);
		entity.setChatBotId(chatbotIdenty);
//		entity.setSpName(spName);
		entity.setMdn(mdn);
		entity.setContent(content);
		entity.setRawcontent(rawcontent);
		entity.setSubject(subject);
		Instant time =Instant.now() ;
		entity.msgId=entity.hashCode()+""+time.getNano();
		this.receiveEntity=entity;
	}

    public static  Map<String, Object> headers(RcsConfig rcsConfig,String password,String spName,String mdn,String contentType) {
		return headers(rcsConfig,password,spName,mdn,"v1",contentType);
	}
    public static  Map<String, Object> headersV2(RcsConfig rcsConfig,String password,String spName,String mdn,String contentType) {
		return headers(rcsConfig,password,spName,mdn,"v2",contentType);
	}
 public static  Map<String, Object> headers(RcsConfig rcsConfig,String password,String spName,String mdn,String version,String contentType) {

		String Nonce = Base64.getEncoder().encodeToString(Instant.now().toString().getBytes());
		Instant i1 = Instant.now();
		i1 = i1.truncatedTo(ChronoUnit.SECONDS);
//   	long Timestamp=i1.getEpochSecond();
//		System.out.println(i1.toString());
		Map<String, Object> head = new HashMap<String, Object>();

		if("v1".equals(version))
		{
			String token = new String(Base64.getEncoder().encode(Util.digest(password, Nonce, i1.toString())));
			String xwsse = "UsernameToken Username=\""+rcsConfig.enterpriseProperty(spName, "appId")+"\",PasswordDigest=\"" + token + "\",Nonce=\"" + Nonce
					+ "\",Created=\"" + i1.toString() + "\"";
			head.put("token", token);
			head.put("x-wsse", xwsse);
			head.put("authorization", "WSSE realm=\"chatbot\", profile=\"UsernameToken\", type=\"Appkey\"");
		}
		else
		{
			head.put("Authorization", "Username=\""+rcsConfig.enterpriseProperty(spName, "appId")+"\", Password=\""+password+"\"");
//			head.put("x-wsse", "UsernameToken Username=\""+rcsConfig.enterpriseProperty(spName, "appId")+"\"");
		}
		head.put("x-3gpp-intended-identity", rcsConfig.enterpriseProperty(spName, "sp"));
		head.put("User-Agent", "SP/"+rcsConfig.enterpriseProperty(spName, "sp"));
		head.put("terminal-type", "Chatbot");
		head.put("address", "sip:+"+mdn+"@gx.5gmc.ims.mnc000.mcc460.3gppnetwork.org");
		if(!Util.isNull(contentType))
		head.put("Content-Type", contentType);
		return head;
	}

	/**
	 * ��ȡ��������IP��ַ,���ͨ��������������͸������ǽ��ȡ��ʵIP��ַ;
	 *
	 * @param request
	 * @return
	 * @throws IOException
	 */
	public static String getIpAddress(HttpServletRequest request) {
		if(request==null)
			return null;

		// ��ȡ��������IP��ַ,���ͨ��������������͸������ǽ��ȡ��ʵIP��ַ
		String ip = request.getHeader("X-Forwarded-For");
		log.debug("getIpAddress(HttpServletRequest) - X-Forwarded-For - String ip=" + ip);

		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
				ip = request.getHeader("Proxy-Client-IP");
				log.debug("getIpAddress(HttpServletRequest) - Proxy-Client-IP - String ip=" + ip);
			}
			if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
				ip = request.getHeader("WL-Proxy-Client-IP");
				log.debug("getIpAddress(HttpServletRequest) - WL-Proxy-Client-IP - String ip=" + ip);
			}
			if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
				ip = request.getHeader("HTTP_CLIENT_IP");
				log.debug("getIpAddress(HttpServletRequest) - HTTP_CLIENT_IP - String ip=" + ip);
			}
			if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
				ip = request.getHeader("HTTP_X_FORWARDED_FOR");
				log.debug("getIpAddress(HttpServletRequest) - HTTP_X_FORWARDED_FOR - String ip=" + ip);
			}
			if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
				ip = request.getRemoteAddr();
				log.debug("getIpAddress(HttpServletRequest) - getRemoteAddr - String ip=" + ip);
			}
		} else if (ip.length() > 15) {
			String[] ips = ip.split(",");
			for (int index = 0; index < ips.length; index++) {
				String strIp = (String) ips[index];
				if (!("unknown".equalsIgnoreCase(strIp))) {
					ip = strIp;
					break;
				}
			}
		}
		return ip;
	}
}
