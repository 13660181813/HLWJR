/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.ydzy.nlp;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.util.HashSet;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.eclipse.jetty.util.resource.Resource;

/**
 *
 * @author xf
 */
public class Nlp {

    private String m_sResult = ""; // �зֺ�Ľ����
    private int m_nPosIndex;  // ָ����з����ϵ�ָ��ľ���λ��
    private int m_MaxLen; // ���ȡ�ʳ�
    private int totalMaxLen; //�����ȡ�ʳ�
    private Set<String> dictionary; // �ִ��ֵ�

    public Nlp(int maxLen){
        this.m_MaxLen = maxLen;
        this.m_nPosIndex = 0;
        this.totalMaxLen = maxLen;
        try {
            this.dictionary = this.loadFile();
        } catch (IOException ex) {
            Logger.getLogger(Nlp.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public Nlp(){
        this.m_MaxLen = 3;
        this.totalMaxLen = 3;
        this.m_nPosIndex = 0;
        try {
            this.dictionary = this.loadFile();
        } catch (IOException ex) {
            Logger.getLogger(Nlp.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public Set<String> loadFile() throws FileNotFoundException, IOException{
        //��ȡ�ֵ�
    	Set<String> dictionary = new HashSet<String>();
    	String filename = "nlpdic/dict.txt";
    	Resource resource=null;
		try {
			resource = Resource.newSystemResource(filename);
			if (resource.exists()) {
				;
				BufferedReader br = new BufferedReader(new InputStreamReader(Files.newInputStream(resource.getFile().toPath()),Charset.forName("UTF-8")));
		        String tmp;
		        while( ( tmp = br.readLine() )!=null){
		            String[] token = tmp.split(",");
		            String word = token[0];
		            dictionary.add(word);
		        }
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
        return dictionary;
    }
    public String MMSegment(String source){
         int len = totalMaxLen;
         int frompos = 0;
         MM(source, len, frompos);
         return m_sResult;
     }
    public String getSubString(String source, int m_nPosIndex, int len){
        int endIndex = m_nPosIndex + len;
        int length = source.length();

        //��Ҫ�ж��Ƿ񳬳����ӱ߽�
        while(endIndex > length){
            endIndex -= 1;
        }
        String sub = source.substring(m_nPosIndex, endIndex);
        return sub;
    }
    public void MM(String source, int len , int frompos){

        //�ݹ�ƥ��
         if (m_nPosIndex >= source.length()) return;
        String sub = getSubString(source, m_nPosIndex,len);
        if(dictionary.contains(sub)){
            //ƥ��
            m_sResult += sub + "/ ";
            m_nPosIndex = m_nPosIndex + m_MaxLen;
            m_MaxLen = totalMaxLen;
            MM(source, m_MaxLen, m_nPosIndex);
        }
        else{
            //��ƥ��
            if(m_MaxLen > 1){
                m_MaxLen = m_MaxLen - 1;
                MM(source, m_MaxLen, m_nPosIndex);
            }
            else{
                m_sResult += sub+ "/ ";
                m_nPosIndex  += 1;
                m_MaxLen = totalMaxLen;
                MM(source, m_MaxLen, m_nPosIndex);
            }
    }
}
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Nlp nlp = new Nlp();
        String source = "��������������";
        String result = nlp.MMSegment(source);
        System.out.println(result);
    } 
}