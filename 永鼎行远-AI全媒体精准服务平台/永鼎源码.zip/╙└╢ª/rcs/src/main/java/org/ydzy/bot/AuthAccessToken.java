package org.ydzy.bot;

import java.util.Map;

public class AuthAccessToken implements IAuthorize {
	public static final String KEY_AUTH_ACCESS_TOKEN = KEY_AUTH + "accessToken";

	@Override
	public String attach(String url, Map<String, Object> headers, BotInfo botInfo) {
		String token = botInfo.getAccessToken();
		String authValue;
		if(token==null||token.isEmpty()) {
			return null;
		}else if(token!=null && token.toLowerCase().startsWith("accesstoken ")) {
			authValue = token;
		}else {
			authValue = "accessToken " + token;
		}
		headers.put("authorization", authValue);
		return url;
	}

}
