package org.ydzy.rcs.media;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

import org.ydzy.rcs.BodyTransform;
import org.ydzy.rcs.RcsConfig;
import org.ydzy.rcs.Upload;
import org.ydzy.rcs.annotation.Description;
import org.ydzy.util.NetUtils;
import org.ydzy.util.Util;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.inject.Inject;
import com.google.inject.Singleton;

@Singleton
@Description("uploadRaw")
public class UploadRaw  extends Upload{
	    private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(UploadRaw.class);
	//"http://121.37.229.90:80/openchatbot/v2/sip:1065051210646@botplatform.rcs.chinamobile.com/files"
		private final static String UPLOAD_URL="http://121.37.229.90:80/openchatbot/v2/%s/files";
//		private final static String NOTIFY_URL="http://121.37.229.90:80/openchatbot/v2/auditnotification";
		private static BlockingQueue<UploadFileEntity> uploadFiles=new LinkedBlockingQueue<UploadFileEntity>();
		public UploadRaw()
		{
//			startMediaCheck();
		}
//		private void startMediaCheck() {
//		Thread thread=new Thread()
//		{
//	public void run()
//	{
//		while(true)
//		{
//			try {
//				UploadFileEntity entity = uploadFiles.take();
//				
//				Thread.sleep(1000);
//			} catch (InterruptedException e1) {
//				e1.printStackTrace();
//			}
//		}
//		
//	}
//		};
//		thread.setName("MediaNofiyCheckThread");
//		thread.start();
//	}
		Gson gson= new Gson();
		MediaEnclosure enclosure = new MediaEnclosure();
		public void doUpload(UploadFileEntity param)
		{
			String boundary="--------------------------"+UUID.randomUUID().toString().replace("-", "");
			String spName=Util.getElementAsString(param.getOtherParam(), "spName");
			
			Map<String, Object> headers=header(spName,boundary);
			ByteBuffer body = enclosure.convertBody(param, boundary);
			try {
				String content=NetUtils.doHttps(UPLOAD_URL, (Object)body, headers, "");
				if(!Util.isNull(content))
				{
					JsonElement e = JsonParser.parseString(content);
					if(e!=null && !e.isJsonNull())
					{
						JsonObject obj=e.getAsJsonObject();
						String tid=obj.get("tid").getAsString();
						param.setTid(tid);
						
						try {
							uploadFiles.put(param);
						} catch (InterruptedException e1) {
							e1.printStackTrace();
						}
					}
				}
				log.info("upload sucess ! fileinfo {} ,response {}" ,gson.toJson(param),content);
			} catch (IOException e) {
				log.error("upload error ",e);
			}
		}
		
		@Inject
		private RcsConfig rcsConfig = null;
		private Map<String, Object>  header(String spName,String boundary) {
			Map<String, Object> headers= BodyTransform.headersV2(rcsConfig, rcsConfig.enterpriseProperty(spName, "key"),spName, "","");
//	        String boundary="--------------------------"+UUID.randomUUID().toString().replace("-", "");
	        headers.put("Content-Type", " multipart/form-data; boundary="+boundary);
	        return headers;

		}
		
		private void checkNofity(UploadFileEntity entity)
		{
			String tid=entity.getTid();
			String spName="";
			if(entity.getOtherParam()!=null&&entity.getOtherParam().has("spName"))
			spName=entity.getOtherParam().get("spName").getAsString();
			
			Map<String, Object> headers= BodyTransform.headersV2(rcsConfig, rcsConfig.enterpriseProperty(spName, "key"),spName, "","");
			headers.put("tid", tid);
			
		}
}
