package org.ydzy.bot;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.TreeMap;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.ydzy.rcs.annotation.Description;
import org.ydzy.rcs.db.DBModule;

import com.google.inject.Binder;
import com.google.inject.Guice;
import com.google.inject.Injector;
import com.google.inject.Key;
import com.google.inject.Module;
import com.google.inject.Scopes;
import com.google.inject.Stage;
import com.google.inject.TypeLiteral;
import com.google.inject.name.Names;

@Description("BotModule")
public class BotModule implements Module {
	private final static Logger log = LoggerFactory.getLogger(BotModule.class);
	private static Set<Binder> binded = new HashSet<>();

	@Override
	public void configure(Binder binder) {
		binder.install(new DBModule());
		synchronized(binded) {
			if(!binded.contains(binder)) {
				binded.add(binder);
				configure2(binder);
			}
		}
		
	}
	
	private Properties createProperties(String configFile) {
		Properties result = new Properties();
		try {
			result.load(BotModule.class.getClassLoader().getResourceAsStream(configFile));
			return result;
		} catch (Exception e) {
			throw new RuntimeException("can not load " + configFile + " .", e);
		}
	}
	
	protected void configure2(final Binder binder) {
		final Properties prop = createProperties("ydzy-chatbotinfo.properties");
		
		binder.bind(Key.get(IAuthorize.class, Names.named(AuthCmcc.KEY_AUTH_CMCC))).to(AuthCmcc.class);
		binder.bind(Key.get(IAuthorize.class, Names.named(AuthAccessToken.KEY_AUTH_ACCESS_TOKEN))).to(AuthAccessToken.class);
		binder.bind(Key.get(IAuthorize.class, Names.named(AuthHuaweiPassword.KEY_AUTH_HUAWEI_PASSWORD))).to(AuthHuaweiPassword.class);
		binder.bind(Key.get(IAuthorize.class, Names.named(AuthHuaweiWsse.KEY_AUTH_HUAWEI_WSSE))).to(AuthHuaweiWsse.class);
		binder.bind(Key.get(IVerify.class, Names.named(VerifyNone.KEY_VERIFY_NONE))).to(VerifyNone.class);
		binder.bind(Key.get(IVerify.class, Names.named(VerifySignature.KEY_VERIFY_SIGNATURE))).to(VerifySignature.class);
		binder.bind(Key.get(ILogin.class, Names.named(LoginJXHK.KEY_LOGIN_BEAN_NAME))).to(LoginJXHK.class);
		binder.bind(Key.get(IRedirectHandler.class, Names.named(RedireHandlerJXHK.KEY_REDIRECT_HANDLER_BEAN_NAME))).to(RedireHandlerJXHK.class);

		String loadFrom = (String)prop.getOrDefault("bootFrom", "rcs");
		if("rcs".equalsIgnoreCase(loadFrom)) {
			binder.bind(Key.get(List.class, Names.named(BotManager.BOTINFO_LIST))).toProvider(RcsConfigChatBotInfo.class);
		}else if("file".equalsIgnoreCase(loadFrom)) {
			List<BotInfo> botInfos = loadBotInfoList(prop);
			binder.bind(Key.get(List.class, Names.named(BotManager.BOTINFO_LIST))).toInstance(botInfos);
		}else {
			binder.bind(Key.get(List.class, Names.named(BotManager.BOTINFO_LIST))).toProvider(DBChatBotInfoLoader.class);
		}
		
		Map<String, String> ispMap = new TreeMap<>();
		Set<String> baNames = prop.keySet().stream().map(String::valueOf)
				.filter(k -> (k.startsWith(BotAccess.KEY_BOT_TYPE) &&!k.endsWith(".name"))).collect(Collectors.toSet());
		boolean defaultAccessFinished = false;
		if(baNames!=null && baNames.size()>0)for(String k:baNames) {
			String fileName = prop.getProperty(k);
			if(k!=null && k.length()>0) {
				try {
					if(!defaultAccessFinished)defaultAccessFinished = BotAccess.KEY_BOT_TYPE_DEFAULT.equals(k); 
					Properties props = createProperties(fileName);
					BotAccess ba = getBotAccess(props);
					binder.bind(Key.get(BotAccess.class, Names.named(k))).toInstance(ba);
					log.debug("bind " + k + " ->" + fileName);
					
					String key = k;
					int p = key.lastIndexOf('.');
					if(p>=0)key = key.substring(p+1);
					String name = prop.getProperty(k+".name");
					if(name==null||name.isEmpty())name = key;
					ispMap.put(key, name);
				}catch(Exception e) {
					log.warn("load from " + fileName + " error!",e);
				}
			}
		}
		binder.bind(Key.get(new TypeLiteral<Map<String, String>>(){}, Names.named(BotManager.BOTISP_LIST))).toInstance(ispMap);

		if(!defaultAccessFinished) {
			BotAccess access = getBotAccess(prop);
			binder.bind(Key.get(BotAccess.class, Names.named(BotAccess.KEY_BOT_TYPE_DEFAULT))).toInstance(access);
		}
		binder.bind(BotManager.class).in(Scopes.SINGLETON);
		binder.bind(DbOperator.class).in(Scopes.SINGLETON);
	}
	
	protected static String BOT_CHATBOTID = "bot.chatbotId";
	protected static String BOT_APPID = "bot.appId";
	protected static String BOT_APPKEY = "bot.appKey";
	protected static String BOT_TOKEN = "bot.token";
	protected List<BotInfo> loadBotInfoList(Properties prop) {
		Set<String> botNames = prop.keySet().stream().map(k ->String.valueOf(k))
				.filter(k->k.endsWith(BOT_CHATBOTID))
				.map(k -> k.substring(0,k.length()-BOT_CHATBOTID.length()).trim())
				.collect(Collectors.toSet());
		
		List<BotInfo> botInfos = new ArrayList<>();
		for(String dbName:botNames) {
			if(dbName.length()>0) {
				String chatbotid = prop.getProperty(dbName + BOT_CHATBOTID);
				String appid = prop.getProperty(dbName + BOT_APPID);
				String appkey = prop.getProperty(dbName + BOT_APPKEY);
				String token = prop.getProperty(dbName + BOT_TOKEN);
				BotInfo bi = new BotInfo(chatbotid, appid, token, appkey);
				botInfos.add(bi);
			}
		}
		return botInfos;
	}
	
	protected BotAccess getBotAccess(final Properties prop) {
		Injector injector = Guice.createInjector(Stage.PRODUCTION,
				new com.google.inject.Module() {
					@Override
					public void configure(Binder binder) {
						Names.bindProperties(binder, prop);
						String className = prop.getProperty("bot.className");
						Class<? extends BotAccess> clazz = null;
						if(className!=null && !className.isEmpty()) {
							try {
								clazz = this.getClass().getClassLoader().loadClass(className).asSubclass(BotAccess.class);
							} catch (Throwable e) {
								log.warn("Error load botaccess class from " + className + "!!!");
							}
						}
						if(clazz==null || clazz.equals(BotAccess.class)) {
							binder.bind(BotAccess.class).to(BotAccessTelcom.class);
						}else {
							binder.bind(BotAccess.class).to(clazz);
						}
					}
				});
		BotAccess bm = null;
		bm = injector.getInstance(BotAccess.class);
		return bm;
	}
	
}