package org.ydzy.rcs.impl;

import org.ydzy.rcs.SuggestionDisplay;
import org.ydzy.rcs.annotation.Description;
import org.ydzy.util.StringUtils;

import com.google.inject.Singleton;

@Singleton
@Description("showLocation")
public class ShowLocation implements SuggestionDisplay{
	private 	String map = "    {\r\n" + "        \"action\":{\r\n"
			+ "            \"displayText\":\"%s\",\r\n"
			+ "            \"mapAction\":{\r\n"
			+ "                \"showLocation\":{\r\n"
			+ "                    \"location\":{\r\n"
			+ "                        \"latitude\":%s,\r\n"
			+ "                        \"longitude\":%s,\r\n"
			+ "                        \"label\":\"%s\",\r\n"
			+ "                        \"query\":\"%s\"\r\n"

			+ "                    },\r\n"
			+ "                    \"fallbackUrl\":\"https://www.google.com/maps/@%s,%sz\"\r\n"
			+ "                }\r\n" + "            },\r\n"
			+ "            \"postback\":{\r\n"
			+ "                \"data\":\"set_by_chatbot_open_map\"\r\n" + "            }\r\n"
			+ "        }\r\n" + "    }";
	@Override
	public String suggestionHtml(String[] args) {
		//TODO DISPLAY
		int length=args.length;
		String query = length<=4?"":args[4].replace("\r\n", "");
		if(query.isEmpty())query = " ";
		return StringUtils.format(map, length<=0?"":args[0].replace("\r\n", ""), length<=1?"":args[1].replace("\r\n", ""),length<=2?"": args[2].replace("\r\n", ""), length<=3?"":args[3].replace("\r\n", ""),
				query, length<=1?"":args[1].replace("\r\n", ""), length<=2?"":args[2].replace("\r\n", ""));
	}

}
