package org.ydzy.bot;

import java.io.IOException;
import java.nio.charset.Charset;
import java.util.concurrent.Callable;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

import org.eclipse.jetty.util.AtomicBiInteger;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.ydzy.bot.BotUtil.HttpInfo;
import org.ydzy.handler.BaseRcsContext;
import org.ydzy.publish.ConstantTopics;
import org.ydzy.publish.IPublisher;
import org.ydzy.publish.SubscribeCaches;
import org.ydzy.publish.SubscribePublish;
import org.ydzy.rcs.BodyTransform;
import org.ydzy.rcs.Provider;
import org.ydzy.rcs.action.RcsLogAction;
import org.ydzy.rcs.action.RcsRunLogAction;
import org.ydzy.rcs.entity.ReceiveEntity;
import org.ydzy.rcs.media.UploadFileEntity;
import org.ydzy.thirdparty.gz110.IPushOnlineMsg;
import org.ydzy.thirdparty.gz110.MsgBySms;
import org.ydzy.thirdparty.gz110.entity.InstantBean;
import org.ydzy.util.Util;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.inject.ConfigurationException;
import com.google.inject.Inject;
import com.google.inject.Injector;
import com.google.inject.Key;
import com.google.inject.name.Named;
import com.google.inject.name.Names;

/**
 * 5G��Ϣҵ��ƽ̨��ҵ�ͻ�����ӿ�
 * @author ljp
 *
 */
public abstract class BotAccess {
	static final Logger log = LoggerFactory.getLogger(BotAccess.class);
	protected static Charset utf8 = Charset.forName("UTF8");
	public static String KEY_BOT_TYPE = "bot.access.";
	public static String KEY_BOT_TYPE_DEFAULT = KEY_BOT_TYPE + "default";
	
	/** ������ϢURL */
	public abstract String getUrlMessages();
	
	/**  ý���ϴ�URL */
	public abstract String getUrlMediasUpload();
	
	/**  ý���ز�ɾ�� */
	public abstract String getUrlMediasDelete();
	
	
	@Inject(optional = true)
	@Named("bot.enable")
	private boolean enable = false;
	public boolean isEnable() {
		return enable;
	}

	@Inject(optional = true)
	@Named("bot.authorize")
	protected String authorizeName;
	@Inject(optional = true)
	@Named("bot.verify")
	protected String verifyName;
	
	@Inject(optional = true)
	private SubscribeCaches subscribeCaches;

	private MsgBySms msgBySms = null;
	protected MsgBySms getMsgBySms() {
		if(msgBySms==null && injector!=null) {
			IPushOnlineMsg instance = injector.getInstance(Key.get(IPushOnlineMsg.class, Names.named("MsgBySms")));
			if(instance!=null)this.msgBySms = (MsgBySms)instance;
		}
		return msgBySms;
	}

	private Injector injector;
	@Inject
	protected void doInject(Injector injector) {
		this.injector = injector;
		if(authorizeName!=null && injector!=null) {
			if(authorizeName.isEmpty()) {
				authorize = null;
			}else {
				try {
					IAuthorize auth = injector.getInstance(Key.get(IAuthorize.class, Names.named(authorizeName)));
					if(auth!=null)this.authorize = auth;
				}catch(ConfigurationException ignore) {
				}
			}
		}
		if(verifyName!=null && injector!=null) {
			if(verifyName.isEmpty()) {
				verify = defaultVerify;
			}else {
				try {
					IVerify verify = injector.getInstance(Key.get(IVerify.class, Names.named(verifyName)));
					if(verify!=null)this.verify = verify;
				}catch(ConfigurationException ignore) {
				}
			}
		}
	}
	
	protected IAuthorize authorize;
	/** �����������������֤��ʽ */
	public IAuthorize getAuthorize() {
		return authorize;
	}

	static final IVerify defaultVerify = new VerifyNone();
	/** ������֤��ʽ */
	IVerify verify = null;
	public IVerify getVerify() {
		return verify==null?defaultVerify:verify;
	}
	public void setVerify(IVerify verify) {
		this.verify = verify;
	}
	
	
	/** У��sinature��ʱ�䳤�� �� */
	private int sinatureTimeout = 600;
	@Inject(optional = true)
	private void setSinatureTimeout(@Named("bot.sinatureTimeout")int sinatureTimeout) {
		this.sinatureTimeout = sinatureTimeout;
	}
	/** У��sinature��ʱ�䳤�� �� */
	public int getSinatureTimeout() {
		return sinatureTimeout;
	}

	protected Gson gson = new Gson();

	@Inject(optional=true)
	protected RcsLogAction rcsLogAction = null;
	
	/**
	 * ����
	 * @return
	 */
	public abstract boolean active(BotInfo botInfo);
	
	
	/**
	 * ִ�з�����Ϣ
	 * @param botInfo
	 * @param msgObj
	 * @param context
	 * @param body
	 * @return
	 * @throws IOException
	 */
	protected abstract boolean sendMessage(BotInfo botInfo, JsonObject msgObj, BaseRcsContext context, String body, CompletableFuture<HttpInfo> future) throws IOException;

	/**
	 * ��MAAPƽ̨(����ӿ�)������Ϣ
	 */
	public boolean cspUnSendMsg(BotInfo botInfo, ReceiveEntity message, org.ydzy.handler.BaseRcsContext context){
		if(message!=null) {
			//if(message.getSenderAddress().indexOf(botInfo.getAppId())<=0 )return false;
			long startTime = System.currentTimeMillis();
			if(log.isDebugEnabled())log.debug("sendMsg {}  ", message);
			CompletableFuture<HttpInfo> future = new CompletableFuture<>();
			JsonObject jo = (JsonObject)message.getAnswersObject().get("elementFind");
			if(jo==null) {
				log.debug("No elementFind object, skip message send!!!");
				return false;
			}
			JsonElement tmpJo = gson.toJsonTree(message);
			ReceiveEntity m1 = gson.fromJson(tmpJo, ReceiveEntity.class);
			m1.getAnswersObject().putAll(message.getAnswersObject());
			String boxId=Util.toString(message.getAnswersObject().get("boxId"));
			if("system".equals(boxId)) {
				m1.setDestinationAddress(message.getChatBotId());
				m1.senderAddress=message.getDestinationAddress();
			}
			else {
				if(!Util.isNull(message.sendTo)) m1.senderAddress= message.sendTo;
			}
			//sip:"destinationAddress": "sip:106500@botplatform.rcs.domain.cn",			"senderAddress": "tel:+8617928222350",
			//���ϸ�ʽ���ں��� Ϊ�����ɸ���ʡ�ݺ�׺�ӳ����������������� 
			if(m1.senderAddress==null || (m1.senderAddress.indexOf(":")<=0&&(m1.senderAddress.length()<10 || m1.senderAddress.length()>21 || m1.senderAddress.indexOf('-')>0))) {
				//��Ч���ֻ��ŵ�ַ ����ȡ������
				log.error("Illegal phone number(" + m1.senderAddress + "), ignore 5g message send!");
				return false;
			}
			if(m1.senderAddress!=null && m1.senderAddress.indexOf("sip:")<0 && m1.senderAddress.indexOf("tel:")<0) {
				m1.senderAddress = "tel:+86" + m1.senderAddress;
			}
			if(m1.senderAddress==null || m1.senderAddress.isEmpty())return false;
			m1.setDestinationAddress(message.getChatBotId());

			String body=Provider.parseContent(m1, jo , context,true);
			//Provider.parseContent(transform.receiveEntity, find, context);
			try {
				if(body!=null && !body.isEmpty())return sendMessage(botInfo, message.getReceive5GMsg(), context, body, future);
			} catch (Exception e) {
				log.error("Send message error(" + e.getMessage() + ")��", e);
			}finally {
				if(rcsLogAction!=null) try{
					long endTime = System.currentTimeMillis();
					int delayMs = (int)(endTime-startTime);
					
					HttpInfo conn = null;
					if(future.isDone())
						try {
							conn = future.get(0, TimeUnit.MILLISECONDS);
						} catch (Exception ignore) {}
					if(conn!=null) {
						//��־ ����д��session_log��, ��Ϊ���ݽ���unsend����ʱ�Ѿ�д��
						conn.getAttributes().put("sessionLog", "0");
						conn.getAttributes().put("channel", "bot");
						rcsLogAction.log(conn, body, m1, delayMs, true);
					}
				}catch(Throwable ignore) {if(log.isDebugEnabled())ignore.printStackTrace();}
			}
		}
		return false;
	}
	
	/**
	 * ��MAAPƽ̨(����ӿ�)������Ϣ����д���, ����лظ�������Ϣ
	 */
	public boolean cspSendMsg(BotInfo botInfo,JsonObject msgObj,org.ydzy.handler.BaseRcsContext context)
	{
		context.getAttributes().put("chatbotinfo", botInfo);
		context.getAttributes().put("origMsg", msgObj);
		long startTime=System.currentTimeMillis();
		BodyTransform body=new BodyTransform(msgObj,context);
		body.transform(true);
		String rsponse = body.responseBody;
		ReceiveEntity entity = body.receiveEntity;
		
		String channel = BotUtil.getElementAsString(msgObj, "channel");
		if("sms".equalsIgnoreCase(channel)) {
			String smsTemplate = BotUtil.getElementAsString(msgObj, "smsTemplate");
			String smsConfigKey = BotUtil.getElementAsString(msgObj, "smsConfigKey");
			if(smsConfigKey!=null)entity.getAnswersObject().put("smsConfigKey", smsConfigKey);
			InstantBean sessionBean = new InstantBean(BotUtil.getElementAsString(msgObj, "mdn"), botInfo.getChatbotId());
			JsonElement je = this.getMsgBySms().postMsg2Client(entity, sessionBean, smsTemplate);
			return (je!=null);
		}
		
		if(subscribeCaches!=null) {
			SubscribePublish<ReceiveEntity> sub=subscribeCaches.getSubscribePublishInstance(ConstantTopics.CHARTBOT_MSG_DISPOSED, ReceiveEntity.class);
			IPublisher<ReceiveEntity> publishObj =new IPublisher<ReceiveEntity>() {
				@Override
				public void publish(SubscribePublish<ReceiveEntity> subscribeObj, ReceiveEntity message, boolean isInstantMsg) {
					subscribeObj.publish(ConstantTopics.CHARTBOT_MSG_DISPOSED+"_Subscribers", message, isInstantMsg);
				}};
			publishObj.publish(sub, entity, false);
		}
		if(rsponse!=null && !rsponse.isEmpty()) {
			if(log.isDebugEnabled())log.debug("sendMsg {}  " ,rsponse);
			CompletableFuture<HttpInfo> future = new CompletableFuture<>();
			try {
				return sendMessage(botInfo, msgObj, context, rsponse, future);
			} catch (Exception e) {
				e.printStackTrace();
			}finally {
				if(rcsLogAction!=null) {
					long endTime = System.currentTimeMillis();
					int delayMs = (int)(endTime-startTime);
					
					HttpInfo conn = null;
					if(future.isDone())
						try {
							conn = future.get(0, TimeUnit.MILLISECONDS);
						} catch (Exception ignore) {}
					if(conn!=null) {
						conn.getAttributes().put("channel", "bot");
						conn.getAttributes().put("doReply", "1");
						rcsLogAction.log(conn, rsponse, entity, delayMs, true);
					}else {
						rcsLogAction.log( null, null, rsponse, body, delayMs, true);
					}
				}
			}
		}
		return false;
	}

	@Inject(optional = true)
	@Named("bot.maxRetry")
	private int maxRetry = 30;
	
	/** ����ʱ ����ǰ�ȴ�ʱ�� �� Ĭ�� 15 */
	@Inject(optional = true)
	@Named("bot.retryWaitTime")
	private int retryWaitTime = 15;

	public int getMaxRetry() {
		return maxRetry;
	}
	public int getRetryWaitTime() {
		return retryWaitTime;
	}

	/** 2�������ȴ����� */
	public IRetryPolicy retryPolicy(int maxRetry, int retryWaitTime) {
		return new RetryPolicy(maxRetry, retryWaitTime, 2.0);
	}

	public <T> CompletableFuture<T> callWithRetry(final BotInfo botInfo, final Callable<T> caller, final String action) {
		return callWithRetry(botInfo, caller, action, null, retryPolicy(maxRetry, retryWaitTime));
	}
	
	public <T> CompletableFuture<T> callWithRetry(final BotInfo botInfo, final Callable<T> caller, final String action, final Runnable failer) {
		return callWithRetry(botInfo, caller, action, failer, retryPolicy(maxRetry, retryWaitTime));
	}
	
	public <T> CompletableFuture<T> callWithRetry(final BotInfo botInfo, final Callable<T> caller, final String action, final Runnable failer, final IRetryPolicy retryPlicy) {
		CompletableFuture<T> future = new CompletableFuture<T>();
		try {
			Callable<T> run = ()-> {
				T r = caller.call();
				if(botInfo!=null && botInfo.getDbOper().getDataSource()!=null){
					RcsRunLogAction.recordLog(action, action + " success", "", "0", action, botInfo.getDbOper().getDataSource());
				}
				future.complete(r);
				return r;
			};
			Consumer<Throwable> runFail = (e) -> {
				if(failer!=null)failer.run();
				if(botInfo!=null && botInfo.getDbOper().getDataSource()!=null){
					RcsRunLogAction.recordLog(action, action + " error", "", "100", action, botInfo.getDbOper().getDataSource());
				}
				future.completeExceptionally(e);
			};
			newRetryRunner(run, runFail , action, botInfo!=null && botInfo.manager!=null?botInfo.manager.getExecutor():null , retryPlicy).run();
		} catch (Exception e) {}
		return future;
	}
	/** ����ִ�����Թ���, ������������� */
	protected <V> RetryRunner<V> newRetryRunner(Callable<V> run, Consumer<Throwable> runFail, String action, ScheduledExecutorService executor, IRetryPolicy retryPolicy) {
		return (new RetryRunner<V>(run, runFail , action, executor , retryPolicy));
	}
	
	/**����ý�� ��Ϣ
	 * @param botInfo chatbot
	 * @param url ����ý�� url��ַ
	 * @param outputfile �����ļ���ַ
	 */
	public abstract void mediaDownload(BotInfo botInfo, String url,String outputfile);
	/***
	 * �ϴ�ý��
	 * @param botInfo
	 * @param param
	 */
	public abstract boolean mediaUpload(final BotInfo botInfo, final UploadFileEntity param);

	/*** ɾ��ý��
	 * 
	 * @param botInfo
	 * @param mediaID
	 * @return
	 */
	public boolean mediaDelete(final BotInfo botInfo, final String mediaID) {
		UploadFileEntity media = new UploadFileEntity("", "");
		media.setMediaID(mediaID);
		if( botInfo.getDbOper().loadMedia(media)) {
			return mediaDelete(botInfo, media);
		}
		return false;
	}

	/***
	 * ɾ��ý��
	 * 
	 * @param botInfo
	 * @param media
	 * @return
	 */
	public abstract boolean mediaDelete(final BotInfo botInfo, final UploadFileEntity media);
	
	/** ���Ե���retry�Ƴ����쳣 */
	public class SpecialException extends RuntimeException{

		public SpecialException() {
			super();
		}
		public SpecialException(String message) {
			super(message);
		}

		public SpecialException(Throwable cause) {
			super(cause);
		}
		
	}
	
	/**
	 * ���Բ��� ֧�ֶ���������Դ��������Եȴ�ʱ��
	 * */
	public static interface IRetryPolicy{
		/** ������Դ��� */
		public int getMaxRetry();
		/** ���ֵȴ����� */
		public int getNextWaitTime();
	}
	
	/** ���ȴ�ʱ������ĵȴ����� */
	static class RetryPolicy implements IRetryPolicy{
		int maxRetry;
		int initWaitTime;
		double multier;
		double nextMultier = 1;
		public RetryPolicy(int maxRetry, int initWaitTime, double multier) {
			this.maxRetry = maxRetry;
			this.initWaitTime = initWaitTime;
			this.multier = multier;
		}
		public int getMaxRetry() {
			return maxRetry;
		}
		public int getNextWaitTime() {
			if(multier<=0){
				return initWaitTime;
			}else {
				int waitTime = (int) (multier*nextMultier);
				nextMultier = nextMultier * multier;
				return waitTime;
			}
		}
	}
	
	public static class RetryRunner<V> implements Runnable{
		AtomicBiInteger count = new AtomicBiInteger(0);
		Callable<V> caller;
		Consumer<Throwable> runFail;
		String action;
		ScheduledExecutorService executor;
		IRetryPolicy retryPolicy;
		public RetryRunner(Callable<V> caller, Consumer<Throwable> failer, String action, ScheduledExecutorService executor, IRetryPolicy retryPolicy) {
			super();
			this.caller = caller;
			this.runFail = failer;
			this.action = action;
			this.executor = executor;
			this.retryPolicy = retryPolicy;
		}

		public void run(){
			try {
				count.incrementAndGet();
				caller.call();
			}catch(Exception e) {
				exception(e);
			}
		}
		
		/** �����쳣,�ж��Ƿ��������, ���ǵ���fail���� */
		protected void exception(Throwable e) {
			if(e instanceof SpecialException) {
				fail(e.getCause()==null?e:(e.getCause()));
			}else {
				int maxRetry = retryPolicy.getMaxRetry();
				if(executor!=null && count.get() < maxRetry) {
					int waitMs = retryPolicy.getNextWaitTime()*1000;
					if(waitMs<0)waitMs =15000;
					log.info("Run {} error {}/{}, retry after {}'ms, e:{}.", action, count.get(), maxRetry, waitMs, e.toString());
					executor.schedule(this, waitMs, TimeUnit.MILLISECONDS);
				}else {
					log.warn(String.format("Run %s error, exceed try(count=%d), (%s)", action, count.get(), e.toString()),e);
					fail(e);
				}
			}
		}
		
		protected void fail(Throwable e) {
			if(runFail!=null)runFail.accept(e);
		}
	}
}
