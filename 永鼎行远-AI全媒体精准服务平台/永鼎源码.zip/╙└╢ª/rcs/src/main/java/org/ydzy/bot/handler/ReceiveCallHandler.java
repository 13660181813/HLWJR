package org.ydzy.bot.handler;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.nio.charset.Charset;
import java.sql.SQLException;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.beanutils.BeanUtils;
import org.eclipse.jetty.server.HandlerContainer;
import org.eclipse.jetty.server.Request;
import org.eclipse.jetty.server.handler.ContextHandler;
import org.ydzy.ability.privatenumber.PhonePondManager;
import org.ydzy.ability.privatenumber.PrivateNumber;
import org.ydzy.ability.privatenumber.PrivateNumber.pairNum;
import org.ydzy.ability.privatenumber.PrivateNumber.privatePhoneNo;
import org.ydzy.handler.BaseRcsContextProvidor;
import org.ydzy.handler.RcsSession;
import org.ydzy.publish.ConstantTopics;
import org.ydzy.publish.IPublisher;
import org.ydzy.publish.SubscribeCaches;
import org.ydzy.publish.SubscribePublish;
import org.ydzy.rcs.Provider;
import org.ydzy.rcs.db.XmlSqlGenerator;
import org.ydzy.rcs.db.XmlSqlGenerator.innerSql;
import org.ydzy.rcs.entity.ReceiveEntity;
import org.ydzy.thirdparty.KFSkillGroupInter;
import org.ydzy.thirdparty.MessageDispatcher;
import org.ydzy.thirdparty.gz110.IPushOnlineMsg;
import org.ydzy.thirdparty.gz110.MsgBySms;
import org.ydzy.thirdparty.gz110.entity.InstantBean;
import org.ydzy.thirdparty.util.MsgUtils;
import org.ydzy.util.SqlUtil;
import org.ydzy.util.StreamsUtil;
import org.ydzy.util.TimeUtil;
import org.ydzy.util.Util;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.inject.Inject;
import com.google.inject.name.Named;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class ReceiveCallHandler extends ContextHandler {
	@Inject
	@Named("rcsDb")
	protected DataSource ds;
	/***
	 * Context�����ṩ��
	 */
	@Inject
	private BaseRcsContextProvidor contextProvidor = null;
	public BaseRcsContextProvidor getContextProvidor() {
		return contextProvidor;
	}
	public ReceiveCallHandler(HandlerContainer parent, String contextPath) {
//		super(parent, contextPath);
//		this.setAllowNullPathInfo(true);
//		this.setDisplayName("Suffix(" + contextPath + ")");
	}
	@Inject
	private PrivateNumber privateNum;
	public ReceiveCallHandler(String contextPath) {
		this(null, contextPath);
	}
	@Inject
	@Named("MsgBySms")
	private IPushOnlineMsg onlineMsg;
	public ReceiveCallHandler() {
		 this(null, null);
	}
	@Override
	public void doHandle(String target, Request baseRequest, HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {
//		super.doHandle(target, baseRequest, request, response);
//		super.handle(request, runnable);
		String contentType=request.getContentType();
		try {
			//if(contentType.indexOf("json")>-1)
			{
				String body = StreamsUtil.copyToString(request.getInputStream(), Charset.forName("UTF-8"));
				
				
				/*
				  ����״̬���յ�ַ http://csp.bjydzy.com:20480/bot/receivecallstatus
                 
				  {
					    "eventType":"callin",
					    "statusInfo":{
					        "sessionId":"1202_4822_4294967295_20210623072318@callenabler245qh.huaweicaas.com",
					        "timestamp":"2021-06-23 07:23:18",
					        "caller":"+8619899445919",
					        "called":"+8617055888660",
					        "subscriptionId":"bb354ec1-d0b8-486f-9538-4dfd6800afdf"
					    }
				  }
				  {
					    "eventType":"callout",
					    "statusInfo":{
					        "sessionId":"1202_4822_4294967295_20210623072318@callenabler245qh.huaweicaas.com",
					        "timestamp":"2021-06-23 07:23:18",
					        "caller":"+8617055888660",
					        "called":"+8617610598682",
					        "subscriptionId":"bb354ec1-d0b8-486f-9538-4dfd6800afdf"
					    }
					}
					{
    "eventType":"alerting",
    "statusInfo":{
        "sessionId":"1202_4822_4294967295_20210623072318@callenabler245qh.huaweicaas.com",
        "timestamp":"2021-06-23 07:23:22",
        "caller":"+8617055888660",
        "called":"+8617610598682",
        "subscriptionId":"bb354ec1-d0b8-486f-9538-4dfd6800afdf"
    }
}

{
    "eventType":"disconnect",
    "statusInfo":{
        "sessionId":"1202_4822_4294967295_20210623072318@callenabler245qh.huaweicaas.com",
        "timestamp":"2021-06-23 07:23:27",
        "caller":"+8619899445919",
        "called":"+8617055888660",
        "stateCode":7502,
        "stateDesc":"The calling party releases the call after the called party is alerted.",
        "subscriptionId":"bb354ec1-d0b8-486f-9538-4dfd6800afdf"
    }
}
				 */
				
				
				if(!Util.isNull(body))
				{
					JsonObject resultO = Util.str2JsonObject(body);
					String eventType=Util.getElementAsString(resultO, "eventType");
					String sqlid="insertprivate_callstatusinfo";
					if("fee".equals(eventType))
					{
						sqlid="insertprivate_feeinfo";
						JsonArray feeLst =resultO.getAsJsonArray("feeLst");
						for(int i =0;i<feeLst.size();i++)		
						{
							JsonObject fee=feeLst.get(i).getAsJsonObject();
							fee.addProperty("eventType", "fee");
							String recordDomain =Util.getElementAsString(fee, "recordDomain");
							String recordObjectName =Util.getElementAsString(fee, "recordObjectName");
							String result =privateNum.downLoadRecord(recordDomain, recordObjectName);
//							System.out.println(result);
							Map dbParam=new Gson().fromJson(fee, Map.class);
							if(!dbParam.containsKey("fwdAlertingTime"))
								dbParam.put("fwdAlertingTime", "1970-01-01 00:00:00");
							if(!dbParam.containsKey("fwdAnswerTime"))
								dbParam.put("fwdAnswerTime", "1970-01-01 00:00:00");
							
							try {
								String caller = BeanUtils.getNestedProperty(dbParam, "callerNum");
								String called=BeanUtils.getNestedProperty(dbParam, "calleeNum");
								pushMsg(eventType, caller, called);
							} catch (IllegalAccessException e1) {
								e1.printStackTrace();
							} catch (InvocationTargetException e1) {
								e1.printStackTrace();
							} catch (NoSuchMethodException e1) {
								e1.printStackTrace();
							}
							innerSql sql=XmlSqlGenerator.getSqlByMap(sqlid, dbParam);
							try {
								SqlUtil.updateRecords(ds, sql.exeSql,sql.sqlParams.toArray());
							} catch (Exception e) {
								e.printStackTrace();
							}
							
						}
					}else
					{
						Map dbParam=new Gson().fromJson(body, Map.class);
						String	caller ="";
						String called="";
						try {
							caller = BeanUtils.getNestedProperty(dbParam, "statusInfo.caller");
							called=BeanUtils.getNestedProperty(dbParam, "statusInfo.called");
							pushMsg(eventType, caller, called);
							 
						} catch (IllegalAccessException e) {
							e.printStackTrace();
						} catch (InvocationTargetException e) {
							e.printStackTrace();
						} catch (NoSuchMethodException e) {
							e.printStackTrace();
						}
						
						
						privateNum.updateAnswerTime(caller,eventType,called);
						innerSql sql=XmlSqlGenerator.getSqlByMap(sqlid, dbParam);
						SqlUtil.updateRecords(ds, sql.exeSql,sql.sqlParams.toArray());
					}
				}
				/*���л������յ�ַ	http://csp.bjydzy.com:20480/bot/receivecall
				 {
				    "eventType":"fee",
				    "feeLst":[
				        {
				            "direction":0,
				            "spId":"hw91689161_pv",
				            "appKey":"i6m4ZM128X3e808z46Xa3gn8YLE6",
				            "icid":"ba171f34e6953fcd751edc77127748f4.3833421798.134127319.24",
				            "bindNum":"+8617055888660",
				            "sessionId":"1202_4822_4294967295_20210623072318@callenabler245qh.huaweicaas.com",
				            "subscriptionId":"bb354ec1-d0b8-486f-9538-4dfd6800afdf",
				            "callerNum":"+8619899445919",
				            "calleeNum":"+8617055888660",
				            "fwdDisplayNum":"+8617055888660",
				            "fwdDstNum":"+8617610598682",
				            "callInTime":"2021-06-23 07:23:18",
				            "fwdStartTime":"2021-06-23 07:23:18",
				            "fwdAlertingTime":"2021-06-23 07:23:22",
				            "callEndTime":"2021-06-23 07:23:27",
				            "fwdUnaswRsn":127,
				            "failTime":"2021-06-23 07:23:27",
				            "ulFailReason":7502,
				            "sipStatusCode":0,
				            "callOutUnaswRsn":0,
				            "recordFlag":0,
				            "ttsPlayTimes":0,
				            "ttsTransDuration":0,
				            "mptyId":"bb354ec1-d0b8-486f-9538-4dfd6800afdf",
				            "serviceType":"003",
				            "hostName":"callenabler245qh.huaweicaas.com"
				        }
				    ]
				}
				 */
//				System.out.println(body);
			}
		} catch (IOException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally {
			baseRequest.setHandled(true);
		}
	
	}
	@Override
	public void handle(Request request, Runnable runnable) {}

	private void pushMsg(String eventType,String caller,String called)
	{
		try {
			PhonePondManager axbPhonePonds=privateNum.getPhonePondManager(caller, called);
			if(axbPhonePonds!=null)
			{
				privatePhoneNo phoneNo = axbPhonePonds.borrowPrivateNum();
				pairNum tmpPair=null;
				String phone="";
				if(phoneNo.currentSubscriptionID.containsKey(caller))
				{
					tmpPair=phoneNo.currentSubscriptionID.get(caller);
					phone=caller.replace("+86", "");
				}
				if(tmpPair==null && phoneNo.currentSubscriptionID.containsKey(called))
				{
					tmpPair=phoneNo.currentSubscriptionID.get(called);
					phone=called.replace("+86", "");
				}
				if(tmpPair!=null)
				{
					String chatbotid= getContextProvidor().newBaseRcsContext().getConfig().enterpriseProperty(tmpPair.chatbotId, "chatbotIdenty");
					
					if(!tmpPair.eventTypes.containsKey(eventType))
					tmpPair.eventTypes.put(eventType,System.currentTimeMillis());
					
				    if(Util.isNull(tmpPair.senderAddress) && !Util.isNull(tmpPair.targetAddress))
					{
						InstantBean bean=messageCache.InstantBean(tmpPair.targetAddress, chatbotid);
						if(bean!=null&&bean.target!=null)
							tmpPair.senderAddress=bean.target.fromNo;
					}else if(!Util.isNull(tmpPair.senderAddress) && Util.isNull(tmpPair.targetAddress))
					{
						InstantBean bean=messageCache.InstantBean(tmpPair.senderAddress, chatbotid);
						if(bean!=null&&bean.target!=null)
							tmpPair.targetAddress=bean.target.fromNo;
					}
						
					RcsSession	targetsession=getContextProvidor().newBaseRcsContext().getSession(tmpPair.targetAddress, chatbotid);
					
					RcsSession	mysession=getContextProvidor().newBaseRcsContext().getSession(tmpPair.senderAddress, chatbotid);
					//pushMessages("ͨ��֪ͨ|�𾴵��û�,Ϊ�����յ���֪ͨ�����ǳ�ֿ�ĵ�����Ǹ\r\n",chatbotid,mdn,chatbotid,contextProvidor,"","", null,plat);
//					if("callin".equals(eventType) && !tmpPair.start)
//					{
//						pushMessages("�绰֪ͨ|���ڲ���绰��", chatbotid, tmpPair.senderAddress, chatbotid, contextProvidor, "", "",false);
//						pushMessages("�绰֪ͨ|���ڲ���绰��", chatbotid, tmpPair.targetAddress, chatbotid, contextProvidor, "", "",false);
//						tmpPair.start=true;
//					}//�һ��¼�
//					  
					if("disconnect".equals(eventType))//||"fee".equals(eventType))  && (!tmpPair.end&&tmpPair.start)
					{
						long duration=0;
						if(tmpPair.eventTypes.size()>1)
						{
							if(tmpPair.eventTypes.containsKey("answer")) {
								Long startTime=tmpPair.eventTypes.get("answer");
								Long endTime=tmpPair.eventTypes.get("disconnect");
								duration=endTime-startTime;
							}
							if(duration>0)
							{
								String time="";
								if(duration>3600000)
									time=TimeUtil.formatDay(duration, "HH:mm:ss");
									else
										time=TimeUtil.formatDay(duration, "mm:ss");
								//���X
								//privateNum.backPrivateNum(caller,called);
								//pushMessages("ͨ��ʱ�� "+time, chatbotid, tmpPair.senderAddress, chatbotid, contextProvidor, "", "",true,true);
								//pushMessages("ͨ��ʱ�� "+time, chatbotid, tmpPair.targetAddress, chatbotid, contextProvidor, "", "",true,true);
								targetsession.put("talk_time", time);
								mysession.put("talk_time", time);
								targetsession.put("systemEmptyTip", "");
								mysession.put("systemEmptyTip", "");
								pushMessages(KFSkillGroupInter.GZ110CHECKTALKTIME, chatbotid, tmpPair.senderAddress, chatbotid, contextProvidor, "", "",true,true);
								pushMessages(KFSkillGroupInter.GZ110CHECKTALKTIME, chatbotid, tmpPair.targetAddress, chatbotid, contextProvidor, "", "",true,true);

							}else {
								targetsession.put("systemEmptyTip", "");
								mysession.put("systemEmptyTip", "");
								pushMessages(KFSkillGroupInter.GZ110CHECKTALKBUSY, chatbotid, tmpPair.senderAddress, chatbotid, contextProvidor, "", "",true,false);
								pushMessages(KFSkillGroupInter.GZ110CHECKTALKBUSY, chatbotid, tmpPair.targetAddress, chatbotid, contextProvidor, "", "",true,false);
							}
						}
						tmpPair.eventTypes.clear();
					}
				}
			}
		} catch ( Exception e) {
			e.printStackTrace();
		} 
	}
	private JsonObject platConfig(String username)
	{
		String sql=XmlSqlGenerator.getSqlstr("queryPasswdByName",username);
		try {
			JsonArray sqlResult=SqlUtil.queryForJson(ds, sql);
			if(sqlResult!=null && !sqlResult.isJsonNull() &&sqlResult.size()>0 ) {
				return sqlResult.get(0).getAsJsonObject();
			}
		}
		catch (Exception e) {
		}
		return null;
			 
	}
	@Override
	public boolean checkContextPath(String uri) {
//		String contextPath = getContextPath();
//		if (contextPath.length() > 1)
//		{
//			// reject requests that are not for us
//			if (!uri.endsWith(contextPath))
//				return false;
//			if (uri.length() > contextPath.length() && uri.charAt(uri.length()- contextPath.length()) != '/')
//				return false;
//		}
		return true;

	}
	
	private boolean pushMessages(String hint, String chatbotid, String dest, String sender,
			BaseRcsContextProvidor contextProvidor,String suggestions,String innersuggestions,boolean sendSms,boolean isanswered) {
		//JsonObject jo = new JsonObject();
		JsonObject jo=contextProvidor.newBaseRcsContext().getConfig().getKeyWordsBysp(chatbotid, hint);
		if (jo == null) {
			jo = new JsonObject();

			jo.addProperty("type", "multicard");
			jo.addProperty("spName", chatbotid);
			jo.addProperty("suggestions", "");
			JsonArray ja = new JsonArray();
			JsonObject content = new JsonObject();
			content.addProperty("msg", hint);
			if (!Util.isNull(innersuggestions))
				content.addProperty("suggestions", innersuggestions);
			content.addProperty("params", "");
			ja.add(content);
			jo.add("content", ja);
			if (!Util.isNull(suggestions))
				jo.addProperty("suggestions", suggestions);
		}
		ReceiveEntity send = new ReceiveEntity();
		send.responseMsgTime=TimeUtil.format(System.currentTimeMillis());
		send.getAnswersObject().put("manager", true);
		send.setDestinationAddress(dest);
		send.senderAddress = sender;
		send.setChatBotId(chatbotid);
		send.responseMsgTime=TimeUtil.format(System.currentTimeMillis());
		send.setMdn(dest);

		send.getAnswersObject().put("elementFind", jo);
//			InstantBean target= messageDistribute.onlineSession.get(dest);
//			messageDistribute.onlineSession.get(sender).target=target;
		send.getAnswersObject().put("boxId", "system");
		//boxIdΪsystem nickΪ������
		send.getAnswersObject().put("nick", "���ܿͷ�");	
//			send.destinationAddress=message.senderAddress;
		send.getAnswersObject().put("type", "accept");
		InstantBean bean=messageCache.InstantBean(dest, chatbotid);
		send.getAnswersObject().put("sessionBean", bean);
		send.sendTo= dest;
	
		if(sendSms)
		{
			String uname=bean.appname;
			JsonObject plat=platConfig(uname);
			if(plat!=null)
			{
				String enableEvalutate=Util.getElementAsString(plat, "enableEvalutate");
				String privatePhoneByMsg = Util.getElementAsString(plat, "privatePhoneByMsg");
				if("1".equals(enableEvalutate)) {
					RcsSession  session = getContextProvidor().newBaseRcsContext().getSession(bean.fromNo, chatbotid);
					String key ="sendSms2User"+bean.target.fromNo;
					String issendsms="0";
					JsonObject updatejo=new JsonObject();
					updatejo.addProperty("sid", bean.fromNo);
					
					
					if(session!=null) {
						if(session.containsKey(key))
						  issendsms=Util.toString(session.get(key));
						else {
							JsonObject joselect =selectSession(updatejo);
							if(joselect!=null)
							issendsms=Util.getElementAsString(joselect, MsgBySms.SEND_MSG_TAG);
							if(Util.isNull(issendsms))
								issendsms="0";
							session.put(key, issendsms);
							
						}
					}
					if("0".equals(issendsms))
					{
						Gson gson =new Gson();
						ReceiveEntity bean1 =gson.fromJson(gson.toJson(send),ReceiveEntity.class);
						bean1.getAnswersObject().putAll(send.getAnswersObject());
						String nick=Util.toString(session.get("nick"),"����");
						bean1.setContent("����ѯ�����⣬����"+nick+"Ϊ�����񣬳������Ա��η���������ۣ�");
						
						//content.addProperty("msg", hint);
						bean1.getAnswersObject().put("msg", bean1.getContent());
						((MsgBySms)onlineMsg).postMsg2Client(bean1, bean.target,privatePhoneByMsg);
						updatejo.addProperty("sendSms", "1");
						updateSession(updatejo);
						session.put(key, "1");
					}
				}
			}
		}
		send.getAnswersObject().put("isanswer", isanswered);
		String responseBody = Provider.parseContent(send, jo, contextProvidor.newBaseRcsContext());
		send.getAnswersObject().put("responseBody", responseBody);
		publishUnSend(send);
		return true;
	}
	private void updateSession(JsonObject jo)
	{
		String sqlid="updateSessionStatus";
		String sql =XmlSqlGenerator.getSqlByJson(sqlid, "", jo);
		try {
			SqlUtil.updateRecords(ds, sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	private JsonObject selectSession(JsonObject jo)
	{
		String sqlid="selectSessionStatus";
		String sql =XmlSqlGenerator.getSqlByJson(sqlid, "", jo);
		try {
		JsonArray ja=	SqlUtil.queryForJson(ds, sql);
		if(ja!=null && ja.size()>0) return ja.get(0).getAsJsonObject();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	@Inject
	SubscribeCaches subscribeCaches;
	@Inject
	protected MessageDispatcher  messageCache;
	private void publishUnSend(ReceiveEntity message) {
		SubscribePublish sub = subscribeCaches.getSubscribePublishInstance(ConstantTopics.CHATBOT_MSG_UNSEND);
		IPublisher<ReceiveEntity> publishObj = new IPublisher<ReceiveEntity>() {
			@Override
			public void publish(SubscribePublish subscribeObj, ReceiveEntity message, boolean isInstantMsg) {
				subscribeObj.publish(ConstantTopics.CHATBOT_MSG_UNSEND + "_Subscribers", message, isInstantMsg);
			}
		};
		publishObj.publish(sub, message, true);
//			if(rcsLogAction!=null) rcsLogAction.logReceive(message);
	}

}
