package org.ydzy.jdbc.control.result.datepattern;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.ydzy.rcs.annotation.Description;
import org.ydzy.util.Util;

import com.google.inject.Singleton;

@Description(autoInstance = false,value = "dayTname")
@Singleton
public class DayTname implements ITime {
	@Override
	public List<String> reckonName(String pattern,long timeInterval,  String sDate, String eDate, Calendar c1, Calendar c2) throws ParseException {
		List<String> tablelist =new ArrayList<String>();
		if(pattern.indexOf("'")<0) {
			tablelist.add(pattern);
			return tablelist;
		}
//		SimpleDateFormat sdfPattern = new SimpleDateFormat(pattern);
		
		String radiustable =pattern
				.substring(pattern.indexOf("'") + 1, pattern.lastIndexOf("'")).toUpperCase();
		if (timeInterval == 86400) { // 娌℃湁鍛ㄣ�佹湀鎶ヨ〃锛屾寜澶╄〃鏌ヨ
			if(radiustable.indexOf("$")>-1){
				String moreflag= radiustable.substring(radiustable.indexOf("$"),radiustable.length());
				radiustable = radiustable.replace(moreflag, "");
			}
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			if(!Util.isNull(sDate))
			c1.setTime(sdf.parse(sDate));
			if(!Util.isNull(eDate))
			c2.setTime(sdf.parse(eDate));
			sdf = new SimpleDateFormat("yyMMdd");
			String tn = radiustable + sdf.format(c1.getTime());
			tablelist.add(tn);
//			while (c1.getTimeInMillis() != c2.getTimeInMillis()) {
//				c1.set(Calendar.DAY_OF_MONTH, c1.get(Calendar.DAY_OF_MONTH) + 1);
//				tn = radiustable + sdf.format(c1.getTime());
//				if (!tablelist.contains(tn))
//					tablelist.add(tn);
//			}
		}
		return tablelist;
	}

}
