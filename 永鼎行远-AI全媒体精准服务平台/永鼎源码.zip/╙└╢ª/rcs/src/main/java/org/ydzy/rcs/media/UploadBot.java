package org.ydzy.rcs.media;

import org.ydzy.bot.BotInfo;
import org.ydzy.bot.BotManager;
import org.ydzy.rcs.Upload;
import org.ydzy.rcs.annotation.Description;

import com.google.inject.Inject;
import com.google.inject.Singleton;

@Singleton
@Description("uploadBot")
public class UploadBot  extends Upload{
	private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(UploadBot.class);
	public UploadBot() {

	}

	@Inject
	BotManager botManager;
	public void doUpload(UploadFileEntity param){
		String chatbotid=param.getChatbotid();
		try {
			BotInfo botInfo = botManager.getChatBotInfo(chatbotid);
			botInfo.getBotAccess().mediaUpload(botInfo, param);
		}catch(Exception e) {
			log.warn("doUpload media error!!", e);
		}

	}
}
