//
//  ========================================================================
//  Copyright (c) Mort Bay Consulting Pty Ltd and others.
//  ------------------------------------------------------------------------
//  All rights reserved. This program and the accompanying materials
//  are made available under the terms of the Eclipse Public License v1.0
//  and Apache License v2.0 which accompanies this distribution.
//
//      The Eclipse Public License is available at
//      http://www.eclipse.org/legal/epl-v10.html
//
//      The Apache License v2.0 is available at
//      http://www.opensource.org/licenses/apache2.0.php
//
//  You may elect to redistribute this code under either of these licenses.
//  ========================================================================
//

package org.ydzy.ws;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CountDownLatch;

import javax.sql.DataSource;

import org.eclipse.jetty.websocket.api.Session;
import org.eclipse.jetty.websocket.api.WebSocketAdapter;
import org.ydzy.handler.BaseRcsContextProvidor;
import org.ydzy.publish.SubscribeCaches;
import org.ydzy.rcs.Provider;
import org.ydzy.thirdparty.MessageDispatcher;
import org.ydzy.thirdparty.gz110.SendMsg2ClientH5;
import org.ydzy.thirdparty.gz110.entity.ClientRegister;

import com.google.inject.Inject;
import com.google.inject.Singleton;
import com.google.inject.name.Named;
@Singleton
public class EventSocket extends WebSocketAdapter  
{
    private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(EventSocket.class);
    private final CountDownLatch closureLatch = new CountDownLatch(1);
    private MessageDispatcher messageDispatcher;
  
    public EventSocket()
    {
    	if(subscribeCaches==null)
			subscribeCaches=Provider.injector.getInstance(SubscribeCaches.class);
    	if(contextProvidor==null)
    		contextProvidor=Provider.injector.getInstance(BaseRcsContextProvidor.class);
		if(messageDispatcher==null)
        {
            messageDispatcher=Provider.injector.getInstance(MessageDispatcher.class);
        }
		if(sendMsg==null)
		{
			sendMsg=Provider.injector.getInstance(SendMsg2ClientH5.class);
		}
    }

    @Override
    public void onWebSocketConnect(Session sess)
    {
        super.onWebSocketConnect(sess);
        messageDispatcher.online(getSenderAddress(sess),getClient(sess));
    }

    ByteBuffer payload = ByteBuffer.wrap("pong".getBytes());
    @Override
    public void onWebSocketText(String message)
    {
        super.onWebSocketText(message);
        ClientRegister cr = getClient(getSession());
        String sender =getSenderAddress(getSession());
        if("closing".equals(message))
        {
        	messageDispatcher.msgUtil.clearPositionMark(sender, cr.chatbotid);
        }else {
        	messageDispatcher.reportHeart(sender, cr);
        }
        try {
			getSession().getRemote().sendPong(payload);
		} catch (IOException e) {
			e.printStackTrace();
		}
    }

    @Override
    public void onWebSocketClose(int statusCode, String reason)
    {
    	super.onWebSocketClose(statusCode, reason);
        ClientRegister cr = getClient(getSession());
        String sender=getSenderAddress(getSession());
        /* �޸�Ϊboxid ������ͬһ�û��Ĳ�ͬ����
        if(System.currentTimeMillis()-cr.lastActiveTime<30000)
        {
        	log.warn("sender {} chatbotiD {} Socket lastConnected AtTime: {}, will wait for closetimeout 30000s",sender,cr.chatbotid,cr.lastActiveTime);
        }else 
        */
        {
        	log.error("sender {} chatbotiD {} Socket Closed: [" + statusCode + "] " + reason,sender,cr.chatbotid);
        	closureLatch.countDown();
        	messageDispatcher.offline(getSenderAddress(getSession()),cr);
        }
    }

    @Override
    public void onWebSocketError(Throwable cause)
    {
        super.onWebSocketError(cause);
        cause.printStackTrace(System.err);
    }

    public void awaitClosure() throws InterruptedException
    {
    	log.warn("Awaiting closure from remote");
        closureLatch.await();
    }

    @Inject 
    SendMsg2ClientH5 sendMsg;
    @Inject
	SubscribeCaches subscribeCaches;
	@Inject
	private BaseRcsContextProvidor contextProvidor = null;
	public BaseRcsContextProvidor getContextProvidor() {
		return contextProvidor;
	}
	@Inject
	@Named("rcsDb")
	protected DataSource ds;


	private ClientRegister getClient(Session sess){
        Map<String, List<String>> params  = sess.getUpgradeRequest().getParameterMap();
        String username = params.containsKey("username")?params.get("username").get(0):"";
        String boxId = params.containsKey("boxId")?params.get("boxId").get(0):"";
        String pchatid=params.containsKey("chatbotid")?params.get("chatbotid").get(0):"";
        ClientRegister cr = new ClientRegister();
        cr.platform = username;
        cr.lastActiveTime = System.currentTimeMillis();
        cr.endpoint = sess.getRemote();
        cr.closed = false;
        cr.boxId = boxId;
        cr.chatbotid=pchatid;
        cr.session=sess;
        return cr;
    }
    private String getSenderAddress(Session sess){
        Map<String, List<String>> params  = sess.getUpgradeRequest().getParameterMap();
        String senderAddress = params.containsKey("senderAddress")?params.get("senderAddress").get(0):"";
        return senderAddress;
    }
}