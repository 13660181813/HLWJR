package org.ydzy.rcs.util;

import java.io.IOException;
import java.util.concurrent.CompletableFuture;

import org.ydzy.bot.BotUtil.HttpInfo;
import org.ydzy.rcs.entity.ReceiveEntity;

public interface ISms {
	/** ������Ϣ */
	String doSend(String mdn, String configid, String chatbotid, ReceiveEntity message, String content, CompletableFuture<HttpInfo> future) throws IOException;

	/** �Ƿ�֧�� ���� �ظ� */
	default boolean suportReply() {
		return true;
	}
	
	/** 
	 * ����״̬���������������Ϣ
	 * @param code
	 * @return
	 */
	DeliveryStatus getDeliveryStatus(String code);
	static public class DeliveryStatus{
		public boolean succ;
		public String code;
		public String reason;
	}
}
