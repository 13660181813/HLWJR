package org.ydzy.rcs.decker;

import java.util.Map;

import org.ydzy.handler.impl.ProcedureStatus;
import org.ydzy.handler.impl.StateManager;
import org.ydzy.rcs.BodyTransform;
import org.ydzy.rcs.annotation.Description;
import org.ydzy.util.Util;

import com.google.gson.JsonElement;
import com.google.inject.Singleton;


@Singleton
@Description(value = "runstepchatbot")
public class RunStepRobot  implements DeckerRobot{
	/**
	 * ִ��AI״̬��ִ��
	 * @param find �Ƿ���ͨ�ؼ���ҳ��
	 */
	private void runAi(BodyTransform transform,JsonElement elementfind) {
			Integer aiId = null;
			if(elementfind!=null) {
				if(elementfind.isJsonObject()){
					JsonElement e = elementfind.getAsJsonObject().get("aistepid");
					if(e!=null) {
						try{
							aiId = Integer.parseInt(e.getAsString());
						}catch(Exception ignore) {}
					}
				}
				//TODO WHY DELETE ?
//				if(aiId==null || aiId==0) {
//					transform.session.remove(BodyTransform.USER_STATE);
//				}
			}else{
				String request = transform.receiveEntity.getContent();
				if(transform.receiveEntity.getChatBotId()!=null&& request !=null) {
					Map<String, Integer> map = transform.rcsConfig.getAiMap().get(transform.receiveEntity.getChatBotId());
					if(map!=null)aiId = map.get(request);
				}
			}
			StateManager manager = (StateManager)transform.session.get(BodyTransform.USER_STATE);
			org.ydzy.handler.impl.Process process;
			if (aiId!=null && (process=transform.rcsConfig.getProcessStore().forId(aiId))!=null) {
				//����ǹؼ���, �����滻״̬
				if (manager == null|| elementfind!=null) {
					manager = new StateManager(new ProcedureStatus(process).newState(transform.context), transform.receiveEntity, transform.context);
					manager.submit(transform.context);
					transform.session.put(transform.USER_STATE, manager);
				}else {
					if(manager.getState().getState().runstep.hasTag(org.ydzy.handler.impl.Process.Tag.RUN_FINISHED))
					{
						transform.session.remove(transform.USER_STATE);
						ProcedureStatus state=new ProcedureStatus(process);
						manager = new StateManager(state.newState(transform.context), transform.receiveEntity, transform.context);
						manager.submit(transform.context);
						transform.session.put(transform.USER_STATE, manager);
					}else
					manager.submit(transform.receiveEntity, transform.context);
				}
			} else if (manager != null) {
				//������ǹؼ���, �����滻״̬
				manager.submit(transform.receiveEntity, transform.context);
			}

		}
	@Override
	public JsonElement doTransform(BodyTransform transform,JsonElement efind) {
		runAi(transform,efind);;
		if(transform.session.get(transform.USER_STATE)!=null)
		{
			
			StateManager sm = (StateManager)transform.session.get(transform.USER_STATE);
			if(efind==null||(!efind.getAsJsonObject().get("keywords").equals(transform.receiveEntity.getContent())))
			{
				efind=checkIsKeyWords(transform.receiveEntity,transform.context);
			}
			//if(sm.getState().getState().runstep.stepid==(ProcedureStatus.process.RUN_FINISHED.stepid))
			String runStep=Util.toString(transform.receiveEntity.getAnswersObject().get("runStep"));
			if(sm.getState()!=null && sm.getState().getState()!=null && sm.getState().getState().runstep!=null && sm.getState().getState().runstep.hasTag(org.ydzy.handler.impl.Process.Tag.RUN_FINISHED) ||"1".equals(runStep))
			{
				transform.session.remove(transform.USER_STATE);
			}
		}
		transform.continued=true;
		return efind;
	}

}
