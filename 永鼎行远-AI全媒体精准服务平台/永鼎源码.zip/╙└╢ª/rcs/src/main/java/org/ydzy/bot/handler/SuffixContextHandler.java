package org.ydzy.bot.handler;

import org.eclipse.jetty.server.HandlerContainer;
import org.eclipse.jetty.server.handler.ContextHandler;

public class SuffixContextHandler extends ContextHandler {
	public SuffixContextHandler(HandlerContainer parent, String contextPath) {
		super(parent, contextPath);
		this.setAllowNullPathInfo(true);
		this.setDisplayName("Suffix(" + contextPath + ")");
	}

	public SuffixContextHandler(String contextPath) {
		this(null, contextPath);
	}

	public SuffixContextHandler() {
		 this(null, null);
	}

	@Override
	public boolean checkContextPath(String uri) {
		String contextPath = getContextPath();
		if (contextPath.length() > 1)
		{
			// reject requests that are not for us
			if (!uri.endsWith(contextPath))
				return false;
			if (uri.length() > contextPath.length() && uri.charAt(uri.length()- contextPath.length()) != '/')
				return false;
		}
		return true;

	}

}
