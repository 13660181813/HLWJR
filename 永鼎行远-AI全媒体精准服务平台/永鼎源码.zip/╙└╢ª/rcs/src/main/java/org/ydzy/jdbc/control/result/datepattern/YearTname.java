package org.ydzy.jdbc.control.result.datepattern;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.ydzy.rcs.annotation.Description;
import org.ydzy.util.TimeUtil;

import com.google.inject.Singleton;
@Description(autoInstance = false,value = "yearTname")
@Singleton
public class YearTname  implements ITime{

	@Override
	public List<String> reckonName(String pattern,long timeInterval, String sDate, String eDate,Calendar c1, Calendar c2) throws ParseException {
		List<String> tablelist =new ArrayList<String>();
		if(pattern.indexOf("'")<0) {
			tablelist.add(pattern);
			return tablelist;
		}
		SimpleDateFormat sdfPattern = new SimpleDateFormat(pattern);
		
		String radiustable =pattern
				.substring(pattern.indexOf("'") + 1, pattern.lastIndexOf("'")).toUpperCase();
		if(timeInterval == 31104000){
			long slDate=TimeUtil.convertDate(sDate);
			radiustable = radiustable.replace("$", "Y");
			sdfPattern = new SimpleDateFormat("yy");
			String tn = radiustable + sdfPattern.format(slDate);
			tablelist.add(tn);
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy");
			c1.setTime(sdf.parse(sDate));
			c2.setTime(sdf.parse(eDate));
			int dif = c2.get(Calendar.YEAR) - c1.get(Calendar.YEAR);
			for(int i = 0; i < dif ; i++){
				c1.set(c1.get(Calendar.YEAR) + 1, 1, 1);
				tn = radiustable + sdfPattern.format(c1.getTime());
				if(!tablelist.contains(tn)) {
					tablelist.add(tn);
				}
			}
		}
		return tablelist;
	}

}
