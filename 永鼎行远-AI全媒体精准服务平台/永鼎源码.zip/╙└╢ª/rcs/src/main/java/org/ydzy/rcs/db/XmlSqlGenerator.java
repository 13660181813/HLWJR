package org.ydzy.rcs.db;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.InvocationTargetException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.text.MessageFormat;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import org.apache.commons.beanutils.BeanUtils;
import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;
import org.eclipse.jetty.util.resource.Resource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.ydzy.jdbc.control.result.datepattern.DateTnameHandler;
import org.ydzy.util.EscapeSqlUtil;
import org.ydzy.util.FileUtils;
import org.ydzy.util.SqlUtil;
import org.ydzy.util.TimeUtil;
import org.ydzy.util.Util;

import com.google.common.util.concurrent.ThreadFactoryBuilder;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

/**
 * @author lirui
 * @Desc
 */
public class XmlSqlGenerator {
	private static Pattern p = Pattern.compile("\\{(\\d+)\\}");
	private static Logger log = LoggerFactory.getLogger(XmlSqlGenerator.class);
	private static Map<String, innerSql> sqlGeneratorMap = new ConcurrentHashMap<>(); // �洢���ɺ��sql��key=sqlId
	private static final Pattern paramRegex = Pattern.compile("(?<!\\/)\\$\\{([^\\}]*)}(?!\\/)"); // ������ȡ����
	private static ScheduledExecutorService executorService;
	private static Map<String, Long> currentSqlFilesState = new HashMap<>();
	private static DbType dbType;
	private static Map<String, innerSql> specialSqlGeneratorMap = new ConcurrentHashMap<>(); // �洢���ɺ��sql��key=sqlId

	public static class innerSql {
		public Map<String, Object> properties = new HashMap<String, Object>();
		public Map<String, String> params = new HashMap<String, String>();
		public String rawSql;
		public String uuid;
		public String generatorSql;
		public String afterUpdateBeanName;
		public List<Object> sqlParams = new ArrayList<Object>();
		public String exeSql;
		public String exceptionSqlId;
		public String tablePattern;
		public String timePattern;
		public int step;
	}

	/**
	 * ��ǰʹ�����ݿ�����
	 */

	public static String dbTypeStr;

	private static void setDbTypeStr(String type) {
		dbTypeStr = type;
		dbType = DbType.valueof(dbTypeStr);

	}

	/**
	 * ����sql
	 *
	 * @return
	 */
	public static String buildSql(innerSql sqlObject, boolean UpdateCache) {
		String sqlId = Util.toString(sqlObject.properties.get("id"));

		if (sqlGeneratorMap.containsKey(sqlId))
			log.warn("--------Repeated sqlID:  {}-------------", sqlId);
		String sqlName = Util.toString(sqlObject.properties.get("name"));
		String datasource = Util.toString(sqlObject.properties.get("datasource"));
		String sql = sqlObject.rawSql;
		Matcher matcher = paramRegex.matcher(sql);
		while (matcher.find()) {
			String regexName = matcher.group(1);
			String parameterID = "${" + regexName + "}";
			Map<String, String> prameterValueMap = sqlObject.params;// + "_" + regexName

			if (prameterValueMap == null || !prameterValueMap.containsKey(regexName)) {
				log.error("s :{}   {}", regexName, sqlId);
				return "";
			}
			sql = sql.replace(parameterID, prameterValueMap.get(regexName));
		}

		if (UpdateCache) {
			sqlObject.generatorSql = sql;
			if (Util.isNull(datasource))
				sqlGeneratorMap.put(sqlId, sqlObject);

		}
		return sql;
	}

	private volatile static boolean inited = false;

	public synchronized static void reset() {
		inited = false;
	}

	/**
	 * ��ʼ��sql������
	 */
	public synchronized static void init(String dbTypeStr, String sqlFilePath) {
		if (!inited) {
			setDbTypeStr(dbTypeStr);
			if (dbType == null) {
				log.warn("dbType Null,or undefined ,please checking !");
				return;
			}
			XmlSqlGenerator sqlGenerator = new XmlSqlGenerator();
			try {
				List<String> fs = FileUtils.getjarAndLocalFilePath(sqlFilePath);

				fs.forEach((f) -> {
					if (f.endsWith("sql.xml")) {

						URL url = XmlSqlGenerator.class.getResource("/" + f);
						try {
							log.info("start load sql file {} ...path {} ", f, url.getPath());
							sqlGenerator.parseXml(url.openStream());
							log.info("  load sql file {} path {} sucess ...", f, url.getPath());
						} catch (Exception e) {
							log.error("---------------------fetch  dirs {} error : file is {} ", sqlFilePath, f, e);
						}
						File tmpfile = new File(java.net.URLDecoder.decode(url.getFile()));
						if (tmpfile.exists())
							currentSqlFilesState.put(f, tmpfile.lastModified());
					} else
						log.warn("file format error!checking {}", f);
				});
			} catch (Exception e) {
				log.error("---------------------get directory: {} error -------------------------", sqlFilePath, e);
			}
			if (executorService == null)
				reloadSqlFileExecutor(sqlGenerator);
			inited = true;
		}

	}

	private static String sqlReplace(String sql, String sqlName, Map<String, String> loadEnv, innerSql sqlObject) {
		if (sqlObject == null)
			return "";
		Map<String, String> pMap = sqlObject.params;

		if (pMap != null) {
			for (String key : pMap.keySet()) {
				if (loadEnv != null && !Util.isNull(loadEnv.get(key)) && !Util.isNull(sql))
					sql = sql.replace("/*{" + key + "}*/", loadEnv.get(key));
				else
					sql = sql.replace("/*{" + key + "}*/", "-1");
			}
		}
		return sql;
	}

//	private  static  String replaceVariable(String sql,String sqlName){
//		Map<String,String> loadEnv=loadEnv(null);
//		return sqlReplace(sql,sqlName,loadEnv);
//	}

	

	public static innerSql fetch(String sqlId) {
		innerSql sqlObj = sqlGeneratorMap.get(sqlId);
		if (sqlObj == null) {
			sqlObj = specialSqlGeneratorMap.get(sqlId + "ds");
			if (sqlObj == null) {
				log.debug("can't find sql by sqlId {}", sqlId);
				return null;
			}
		}
		return sqlObj;
	}

	private static String replaceVariable(String sql, String sqlName, String sid, innerSql sqlObject) {

		return sqlReplace(sql, sqlName, null, sqlObject);
	}
	public static String replaceTname(innerSql sqlObj,String sql)
	{
		 String tablePattern =sqlObj.tablePattern;
	        List<String> tnames = new ArrayList<String>();
	        if(!Util.isNull(tablePattern))
	        {
	        	try {
	        		long step =sqlObj.step*TimeUtil.ONE_HOUR_TIME;
	        		String sdate =TimeUtil.format(System.currentTimeMillis()+step);
					DateTnameHandler.matchTname(tablePattern, Util.toLong(sqlObj.timePattern,86400l), sdate, sdate, tnames);
				} catch (ParseException e) {
				}
	        	if(tnames!=null && tnames.size()>0)
	        		sql=sql.replace("{tablePattern}", tnames.get(0));
	        	else
	        	{
	        		String tmp="tmp"+Util.getRandomString(10);
	        		sql=sql.replace("{tablePattern}",tmp);
	        	}
	        }
	        return sql;
	}
	
	/**
	 * ͨ��sqlid��ȡsql
	 *
	 * @param sqlId
	 * @return
	 */

	public static innerSql getSqlByEnv(String sqlId, String sid, Object... params) {
		innerSql sqlObj = fetch(sqlId);
		if (sqlObj == null)
			return sqlObj;
		String sql = replaceVariable(sqlObj.generatorSql, sqlId, sid, sqlObj);
		sql=replaceTname(sqlObj,sql);
       
		if (params != null && params.length > 0) {
			String[] strV = new String[params.length];
			for (int i = 0; i < params.length; i++) {
				strV[i] = EscapeSqlUtil.EscapeSqlStr(Util.toString(params[i]));
			}
			sql = MessageFormat.format(sql.replace("'", "''"), strV).trim();
			;
		}
		innerSql newInnersql = new innerSql();
		newInnersql.exeSql = sql;
		newInnersql.exceptionSqlId=sqlObj.exceptionSqlId;
		return newInnersql;
	}

	public static synchronized innerSql getSql(String sqlId, Object... params) {
		return getSqlByEnv(sqlId, null, params);
	}

	public static synchronized String getSqlstr(String sqlId, Object... params) {
		innerSql sqls =  getSqlByEnv(sqlId, null, params);
		if(sqls==null)
		return "";
		else
		return sqls.exeSql;
	}
	

	public static String getSqlstrByMap(String sqlId, Map<String, Object> param) {
		innerSql sql = getSql(sqlId);
		if (sql == null)
			return "";

		String tempsql = sql.exeSql;
		tempsql=replaceTname(sql,tempsql);
		tempsql=Util.replaceV(tempsql, param);
		return tempsql;
	}

	public static innerSql getSqlByMap(String sqlId, Map<String, Object> param) {
		innerSql sqlObject = getSql(sqlId);
		List<String> params = Util.findParams(sqlObject.exeSql);
		if (params == null)
			return sqlObject;
//		sqlObject.sqlParams = new Object[params.size()];
		String tempSql = sqlObject.exeSql;
		tempSql=replaceTname(sqlObject,tempSql);
		if(tempSql.indexOf(";")>-1)
		{
			sqlObject.exeSql=getSqlstrByMap(sqlId, param);
			return sqlObject;
		}
		for (String p1 : params) {
			try {
				String v = BeanUtils.getNestedProperty(param, p1);
				tempSql = sql2Params(tempSql, sqlObject, v, p1);
			} catch (IllegalAccessException | InvocationTargetException | NoSuchMethodException e) {
				e.printStackTrace();
			}
		}
		sqlObject.exeSql = tempSql;
		return sqlObject;
	}

	private static String sql2Params(String tempSql, innerSql sqlObject, String v, String p1) {
		try {
			if (tempSql.indexOf("'{" + p1 + "}'") > -1) {
				tempSql = tempSql.replaceFirst("'\\{" + p1 + "\\}'", "?");
				sqlObject.sqlParams.add(v);
			} else {
				tempSql = tempSql.replaceFirst("\\{" + p1 + "\\}", "?");
				if (!Util.isNull(v)) {
					sqlObject.sqlParams.add(v);
				} else {
					sqlObject.sqlParams.add(null);
				}
			}

		} catch (Exception e) {
			sqlObject.sqlParams.add(null);
		}
		return tempSql;
	}

	public static String getAfterUpdateBeanName(String sqlId) {
		innerSql sqlObj = fetch(sqlId);
		if (sqlObj == null) {
			return "";
		}
		String beanname = sqlId + "AfterUpdate";
		if (!Util.isNull(sqlObj.afterUpdateBeanName))
			beanname = sqlObj.afterUpdateBeanName;
		return beanname;
	}

	public static String fillSqlParamsByJson(String sql, JsonObject param) {
		return fillSqlParamsByJson(sql, param,false);
	}
	public static String fillSqlParamsByJson(String sql, JsonObject param,boolean convertJsonArray) {
		Gson gson = new Gson() ;
		if (param != null && !param.isJsonNull()) {
			sql = SqlUtil.replaceSqlWidthParam(sql, param);
			for (String k : param.keySet()) {
				if (param.get(k).isJsonArray()) {
					JsonArray array =param.get(k).getAsJsonArray();
					if(convertJsonArray)
					sql = sql.replaceAll("\\{\\s*" + k + "\\s*\\}", gson.toJson(array));
					else {
						List<String> vs = new ArrayList<>();
						for (JsonElement e : param.get(k).getAsJsonArray()) {
							vs.add("'" + (e.isJsonPrimitive() ? (e.getAsString()) : (e.toString())) + "'");
						}
						String vss = vs.stream().collect(Collectors.joining(","));
						sql = sql.replaceAll("\\{\\s*" + k + "\\s*\\}", vss);
					}
						
				} else if (param.get(k).isJsonObject()) {
					log.warn("{}  not String key,value is {}  ", k, param.get(k));
					sql = sql.replaceAll("\\{\\s*"+k+"\\s*\\}",String.valueOf(new Gson().toJson(param.get(k))).replaceAll("\"", "\\\"").replace(";", "��").replace(",","��"));
				} else {
					String v = Util.getElementAsString(param, k);
					if (!Util.isNull(v)) {
						try {
							sql = sql.replaceAll("\\{\\s*"+k+"\\s*\\}",v.replaceAll("\"", "\\\"").replace(";", "��").replace(",","��"));

						} catch (Exception e) {
							sql = sql.replace("{"+k+"}",v.replaceAll("\"", "\\\"").replace(";", "��").replace(",","��"));

						}
					} else
						sql = sql.replaceAll("\\{\\s*" + k + "\\s*\\}", "");
				}
			}
		}
		return sql;
	}
	public static String getSqlByJson(String sqlId, String conversId, JsonObject param) {
		return getSqlByJson(sqlId,conversId,param,false);
	}
	public static String getSqlByJson(String sqlId, String conversId, JsonObject param,boolean jsonArrayConvert) {
		innerSql sqlObj = fetch(sqlId);
		if (sqlObj == null) {
			return "";
		}
		String sql = replaceVariable(!Util.isNull(sqlObj.generatorSql) ? sqlObj.generatorSql : sqlObj.rawSql, sqlId,
				conversId, sqlObj);
		sql=replaceTname(sqlObj,sql);
		sql = fillSqlParamsByJson(sql, param,jsonArrayConvert);
		return sql;
	}
	/**
	 * ����sql�ļ�
	 *
	 * @param stream
	 */
	private void parseXml(InputStream stream) {
		SAXReader reader = new SAXReader();
		try {
			Document doc = reader.read(stream);//
			// Document doc = reader.read(xmlResource.getURL());
			Element rootElement = doc.getRootElement();
			List<Element> sqlElementlist = rootElement.elements("SQL");
			for (Element sqlElement : sqlElementlist) {
				innerSql isql = new innerSql();
				for (int m = 0; m < sqlElement.attributeCount(); m++) {
					String name = sqlElement.attribute(m).getQName().getName();
					String value = Util.trim(sqlElement.attribute(m).getValue());
					isql.properties.put(name, value);
					if ("id".equals(name))
						isql.uuid = value;
					else if ("afterUpdateBeanName".equals(name)) {
						isql.afterUpdateBeanName = value;
					}else if("exceptionSqlId".equals(name))
						isql.exceptionSqlId=value;
					else if("tablePattern".equals(name))
						isql.tablePattern=value;
					else if("timePattern".equals(name))
						isql.timePattern=value;
					else if("step".equals(name))
						isql.step=Util.toInt(value, 0);
				}
				isql.rawSql = sqlElement.elementTextTrim("GENERAL");
				Element specialElement = sqlElement.element(dbType.name().toUpperCase());
				if (specialElement != null) {
					List<Element> list = specialElement.elements();
					list.forEach(element -> {
						String id = element.attributeValue("id");
						String value = element.attributeValue("value");
						if (Util.isNull(value))
							value = element.getTextTrim();
						isql.params.put(id, value);
					});

				}
				if (isql != null && !Util.isNull(isql.uuid)) {
					sqlGeneratorMap.put(isql.uuid, isql);
					buildSql(isql, true);
				} else {
					log.error("unKnown");
				}
			}
		} catch (Exception e) {
			log.error("parse   error .", e);
		}
	}

	/**
	 * ��ʱ���񣬴���sql.xml�ļ��޸ĺ��Զ����¼���sql.xml�ļ�
	 * 
	 * @param sqlGenerator
	 */
	private static void reloadSqlFileExecutor(XmlSqlGenerator sqlGenerator) {
		executorService = Executors.newSingleThreadScheduledExecutor(
				new ThreadFactoryBuilder().setDaemon(true).setNameFormat("XmlSqlGeneratorThread").build());
		executorService.scheduleAtFixedRate(() -> {
			currentSqlFilesState.forEach((key, value) -> {
				log.debug("start load resource sql file {} ", key);
				try {
					Resource fileResource = Resource.newSystemResource(key);
					if (fileResource.exists()) {
						Long newfileTime = fileResource.lastModified();
						if (newfileTime > value) {
							sqlGenerator.parseXml(Files.newInputStream(Path.of(fileResource.getFile().getPath())));
							currentSqlFilesState.put(key, newfileTime);
							log.info("reload sql file {} .", key);
						}
					}
				} catch (IOException e) {
					log.error("load resource sql file {} error !", key, e);
				}
			});
			log.debug("end reload resource sql file task ");
		}, 20, 60, TimeUnit.SECONDS); // ���� MINUTES
	}

	public synchronized static Map<String, Map<String, Object>> getSpecialSqlGeneratorMap() {
		Map<String, Map<String, Object>> map = new HashMap<>();
		specialSqlGeneratorMap.forEach((k, v) -> {
			map.put(k, v.properties);
		});
		return map;
	}

	public static void main(String[] args) {

		String body = "	{\r\n" + " \"rcsRegisterInfo\": {\r\n" + " \"ecName\": \"�й�����\",\r\n" + " \"ecGrade\": 1,\r\n"
				+ " \"businessType\": 1\r\n" + " },\r\n" + " \"rcsInfo\": {\r\n"
				+ " \"introduce\": \"XXXXXX��˾����2010-08-16 ����,��ҵ��Ҫ����������������Ӧ;�ȵ���\r\n"
				+ "����������졢����;����Դ��������;���¹ܡ����¼������°����졢����\",\r\n"
				+ " \"serviceIcon \": \"http://172.17.25.10:9081/7,026c1babd98a\",\r\n"
				+ " \"workPhone\": \"020-58587765\",\r\n"
				+ " \"businessLicense\": \"http://172.17.25.10:9081/7,026d2c25342d\",\r\n"
				+ " \"businessAddress\": \"������ 13 ��\", \"province\": \"�����\",\r\n" + " \"city\": \"�����\",\r\n"
				+ " \"area\": \"�Ͽ���\",\r\n" + " \"operatorName\": \"������\",\r\n"
				+ " \"operatorCard\": \"210102199003077037\",\r\n" + " \"operatorPhone\": \"133XXXXXXXX\",\r\n"
				+ " \" emailAddress \": \"133XXXXXXXX@189.cn\",\r\n" + " \" operatorIdentityPic \": \r\n"
				+ "[\"http://172.17.25.10:9081/7,026d2c25342d\",\"http://172.17.25.10:9081/7,026d2c25342d\"]\r\n"
				+ " },\r\n" + " \"rcsContractInformation\": {\r\n" + " \"contractNo\": \"100001\",\r\n"
				+ " \"name\": \"��ͬ����\",\r\n" + " \"effectiveDate\": \"20201208013659\",\r\n"
				+ " \"expiryDate\": \"20221208013659\",\r\n" + " \"status\": 1,\r\n"
				+ " \"renewalDate\": \"20211208013659\",\r\n"
				+ " \"accessory\": \"http://172.18.91.4:8080/2,03bdf0e3a1\"\r\n" + " },\r\n" + " \"rcsLegalP\": {\r\n"
				+ " \"legalName\": \"��ΰ\",\r\n" + " \"legalIdentification\": \"110302203002030203\",\r\n"
				+ " \"identificationStraight\": \"http://172.17.25.10:9081/7,026d2c25342d\",\r\n"
				+ " \"identificationCounter\": \"http://172.17.25.10:9081/7,026d2c25342d\"\r\n" + " }\r\n" + "}";
		XmlSqlGenerator.init("mysql", "sqls/current");
		Map dbParam = new Gson().fromJson(body, Map.class);
		try {
			String sqlId = "updatecspecinfoallmap";
//			String sql = XmlSqlGenerator.getSqlByMap(sqlId, dbParam);
//			System.out.println(sql);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}