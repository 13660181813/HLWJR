package org.ydzy.util;

import java.io.*;
import java.net.URL;
import java.net.URLConnection;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.nio.file.attribute.PosixFilePermission;
import java.nio.file.attribute.PosixFilePermissions;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collection;
import java.util.EnumSet;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.stream.Collectors;

import javax.sql.DataSource;

import org.eclipse.jetty.server.Request;
import org.eclipse.jetty.server.handler.ContextHandler;
import org.eclipse.jetty.util.IO;
import org.eclipse.jetty.util.resource.Resource;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.XML;
import org.ydzy.bot.BotInfo;
import org.ydzy.bot.BotManager;
import org.ydzy.rcs.Provider;
import org.ydzy.rcs.Upload;
import org.ydzy.rcs.action.MergeChunkMediaAction;
import org.ydzy.rcs.action.RcsRunLogAction;
import org.ydzy.rcs.db.XmlSqlGenerator;
import org.ydzy.rcs.media.UploadFileEntity;
import org.ydzy.rcs.module.LoadProperties;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import jakarta.servlet.MultipartConfigElement;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.Part;


public class FileUtils {
	private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(FileUtils.class);
	public static List<String> getjarAndLocalFilePath(String fileName)
	{
		List<String> files =new ArrayList<String>();
		String path =	FileUtils.class.getProtectionDomain().getCodeSource().getLocation().getPath();
		try {
			path = java.net.URLDecoder.decode(path, "utf-8");
			if(path.endsWith(".jar"))
			{
				JarFile localJarFile = new JarFile(new File(path));
				Enumeration<JarEntry> entries = localJarFile.entries();
				while (entries.hasMoreElements()) {
					JarEntry jarEntry = entries.nextElement();
					String name =jarEntry.getName();
					if(name.indexOf(fileName)>-1){
						log.info("find fileName: {} in path {} ",name,path);
						files.add(name);
					}
				}
			}
			else
			{
				File f =new File(path,fileName);
				if(f.exists())
				{
					List<String> childfils=java.util.Arrays.asList(f.list()).stream().map((fs)->fileName+File.separator+fs).collect(Collectors.toList());
					files.addAll(childfils);
				}
			}
			
		} catch (UnsupportedEncodingException e) {
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 try {
//			File	localfile = new ClassPathResource(fileName).getFile();
			Resource resource=Resource.newSystemResource(fileName);
			
			if(resource!=null &&resource.exists())
			{
				File	localfile=resource.getFile();
				List<String> childfils=java.util.Arrays.asList(localfile.list()).stream().map((f)->fileName+File.separator+f).collect(Collectors.toList());
				files.addAll(childfils);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return files;
	}

	private static MultipartConfigElement getMultipartConfig(String tempDir, String localMediaPath) {
		File dir = new File(localMediaPath);
		if (!dir.exists())
			dir.mkdirs();
		Path multipartTmpDir = Paths.get(tempDir + File.separatorChar + ".multipart-tmp");
		String location = multipartTmpDir.toString();
		long maxFileSize = 200 * 1024 * 1024; // 200 MB
		long maxRequestSize = 200 * 1024 * 1024; // 200 MB
		int fileSizeThreshold = 64 * 1024; // 64 KB
		return new MultipartConfigElement(location, maxFileSize, maxRequestSize, fileSizeThreshold);
	}

	public static Collection<Part> getParts(HttpServletRequest request, String tempDir) throws IOException, ServletException {
		String localMediaPath = ContextHandler.getCurrentContext().getContextHandler().getBaseResource().getName() + File.separatorChar + "media";
		MultipartConfigElement multipartConfig = getMultipartConfig(tempDir, localMediaPath);
		request.setAttribute(Request.__MULTIPART_CONFIG_ELEMENT, multipartConfig);
		return request.getParts();
	}

	public static Map<String, Object> uploadByChunk(HttpServletRequest request, String chunkName, String chunkNum, String tempDir) throws IOException, ServletException {
		Map<String, Object> map = new HashMap<>();
		String localMediaPath = getTempDir() + File.separatorChar + "media";
		if (ContextHandler.getCurrentContext() != null)
			localMediaPath = ContextHandler.getCurrentContext().getContextHandler().getBaseResource().getName() + File.separatorChar + "media";
		localMediaPath += File.separator + tempDir + File.separator + chunkName;
		Path localPath = Paths.get(localMediaPath);
		MultipartConfigElement multipartConfig = getMultipartConfig(tempDir, localMediaPath);
		request.setAttribute(Request.__MULTIPART_CONFIG_ELEMENT, multipartConfig);
		Collection<Part> parts = getParts(request, tempDir);
		for (Part part : parts) {
			map.put("localpath", doUploadChunk(part, localPath, chunkName + '-' + chunkNum));
			map.put("filesize", part.getSize());
			return map;
		}
		return map;
	}

	public static String doUploadChunk(Part part, Path localPath, String chunkName) {
		Path outputFile = localPath.resolve(chunkName);
		try (InputStream inputStream = part.getInputStream();
			 OutputStream outputStream = Files.newOutputStream(outputFile, StandardOpenOption.CREATE,
					 StandardOpenOption.TRUNCATE_EXISTING)) {
			IO.copy(inputStream, outputStream);
			log.info("Saved Part {} to {}", part.getName(), outputFile.toString());
		} catch (Exception e) {
			log.error("Save Part error.", e);
			return null;
		}
		return outputFile.toString();
	}

	public static String moveChunkMergeFile2Media(String mergeFilePath) {
		File mergeFile = new File(mergeFilePath);
		if (!mergeFile.exists())
			return null;
		String localMediaPath = ContextHandler.getCurrentContext().getContextHandler().getBaseResource().getName() + File.separatorChar + "media";
		Path localPath = Paths.get(localMediaPath).resolve(mergeFile.toPath().getFileName());
		try {
			Files.move(mergeFile.toPath(), localPath);
		} catch (IOException e) {
			log.error("move mergeChunkFile to local mediaPath error.", e);
			return null;
		}
		return localPath.toString();
	}

	public static Map<String, Object> doUpload(Part part, Path localPath, String tempDir) {
		Map<String, Object> responseMap = new HashMap<>();
		responseMap.put("originName", part.getSubmittedFileName());
		Path targetPath = localPath.resolve(tempDir);
		File targetFile = new File(targetPath.toString());
		if (!targetFile.isDirectory())
			targetFile.mkdirs();
		String filename = tempDir + System.currentTimeMillis() + part.getSubmittedFileName().substring(part.getSubmittedFileName().lastIndexOf('.'));
		Path outputFile = localPath.resolve(filename);
		try (InputStream inputStream = part.getInputStream();
			 OutputStream outputStream = Files.newOutputStream(outputFile, StandardOpenOption.CREATE,
					 StandardOpenOption.TRUNCATE_EXISTING)) {
			IO.copy(inputStream, outputStream);
			log.info("Saved Part {} to {}", part.getSubmittedFileName(), outputFile.toString());
		} catch (Exception e) {
			log.error("Save Part error.", e);
			responseMap.put("state", 500);
			responseMap.put("message", "Save Part error.");
			return responseMap;
		}
		responseMap.put("size", part.getSize());
		responseMap.put("contentType", part.getContentType());
		responseMap.put("state", 200);
		responseMap.put("localPath", outputFile.toString());
		responseMap.put("filename", filename);
		return responseMap;
	}

	public static Map<String, Object> doUploadByMulti(HttpServletRequest request, String tempDir, String targetDir) throws IOException, ServletException {
		String localMediaPath = getTempDir() + File.separatorChar + "media";
		if (ContextHandler.getCurrentContext() != null)
			localMediaPath = ContextHandler.getCurrentContext().getContextHandler().getBaseResource().getName() + File.separatorChar + "media";
		if (!Util.isNull(targetDir))
			localMediaPath += File.separator + targetDir;
		Path localPath = Paths.get(localMediaPath);
		MultipartConfigElement multipartConfig = getMultipartConfig(tempDir, localMediaPath);
		request.setAttribute(Request.__MULTIPART_CONFIG_ELEMENT, multipartConfig);
		Collection<Part> parts = getParts(request, tempDir);
		Map<String, Object> responseMap = new HashMap<>();
		responseMap.put("localMediaPath", localMediaPath);
		for (Part part : parts) {
			responseMap.putAll(doUpload(part, localPath, tempDir));
			return responseMap;
		}
		responseMap.put("state", 500);
		responseMap.put("message", "Invalid request.");
		return responseMap;
	}

	public static Map<String, Object> doUploadByMulti(HttpServletRequest request, String tempDir) throws IOException, ServletException {
		return doUploadByMulti(request, tempDir, "");
	}

	public static List<Map<String, Object>> doDownloadByThirdParty(String content, String tempDir, String chatbotid) throws IOException, ServletException {

		JsonElement files = JsonParser.parseString(content);
		if (files == null || !files.isJsonArray())
			return null;

		try {
			List<Map<String, Object>> responseMap = new ArrayList<Map<String, Object>>();
			JsonArray fileinfo = files.getAsJsonArray();
			 String fileName="";
			 String filecontentType="";
			 for(int i=0;i<fileinfo.size();i++)
			 {
				 JsonObject eobject =fileinfo.get(i).getAsJsonObject();
				 String type =Util.getElementAsString(eobject, "type");
				 String contentype="";
				 String fileContent=Util.getElementAsString(eobject, "fileContent");
				 if(eobject.has("contentType"))
				 {
					contentype=Util.getElementAsString(eobject, "contentType");
					 
				 }
				 filecontentType=contentype;
				 if(eobject.has("fileName"))
				 fileName=Util.getElementAsString(eobject, "fileName");
				 if(type.equals("file"))
				 {
					 String filename1 =tempDir+System.currentTimeMillis()+fileName;
					 byte [] bytes= Base64.getUrlDecoder().decode(fileContent);
					 String[] files2= saveFile(bytes,filename1,tempDir);
					 Map<String, Object> fileObject=new HashMap<String,Object>();
					 fileObject.put("LocalPath", files2[0]);
					 fileObject.put("Filename", files2[1]);
					 fileObject.put("FileSize", files2[2]);
					 fileObject.put("filecontentType", filecontentType);
					 fileObject.put("url", Util.isNull(files2[3])?LoadProperties.systemProperties.getProperty("webUrl")+"/media/"+chatbotid+"/"+files2[1]:files2[3]);
					 responseMap.add(fileObject);
				 }
			 }
			return responseMap;
		} catch (JSONException e) {
		} catch (IOException e) {
		}
		 return null;
	}

	public static Map<String,Object> doDownloadByC(String content,String tempDir,String chatbotid)throws IOException, ServletException
	{

		 JSONObject obj=XML.toJSONObject(content);
		 Object o = obj.get("file");
		 if(o==null || !(o instanceof JSONObject))
			 return null;
		 JSONObject jo = (JSONObject)o;
		 if(jo.isEmpty())return null;
		 try {
			 List<JSONObject> fileinfo = new ArrayList<>();
			 o = jo.get("file-info");
			 if(o==null) {
				 //ignore
			 }else if(o instanceof JSONObject) {
				 fileinfo.add((JSONObject)o);
			 }else if(o instanceof JSONArray) {
				 JSONArray ja = (JSONArray)o;
				 for(int i=0;i<ja.length();i++) {
					 o = ja.get(i);
					 if(o instanceof JSONObject)fileinfo.add((JSONObject)o);
				 }
			 }
			 String thumbnailUrl="";
			 String fileUrl="";
			 String fileName="";
			 String thumbcontentType="";
			 String filecontentType="";
			 for(int i=0;i<fileinfo.size();i++)
			 {
				 try {
					JSONObject eobject =fileinfo.get(i);
					 String type =eobject.getString("type");
					 String contentype="";
					 String url=eobject.getJSONObject("data").getString("url");
					 if(eobject.has("content-type"))
					 {
						contentype=eobject.getString("content-type");
						 
					 }
					 if("thumbnail".equals(type)) {
						 thumbnailUrl = MergeChunkMediaAction.thumbnailMaps.get(url);
						 if (Util.isNull(thumbnailUrl))
							 thumbnailUrl = url;
						 MergeChunkMediaAction.thumbnailMaps.remove(url);
						 thumbcontentType = contentype;
					 }else {
						 fileUrl=url;
						 filecontentType=contentype;
					 }
					 if(eobject.has("file-name"))
					 fileName=eobject.getString("file-name");
				} catch (Exception e) {
				}
			 }
			 Map<String, Object> responseMap = new HashMap<>();
				
				if(!Util.isNull(thumbnailUrl)&&!Util.isNull(thumbcontentType))
				{
					String filename =tempDir+System.currentTimeMillis()+"_thumbnail"+fileName;
					String [] files =saveFile(thumbnailUrl,thumbcontentType,chatbotid,filename,tempDir);
					responseMap.put("thhumbnailLocalPath", files[0]);
					responseMap.put("thhumbnailLFilename", files[1]);
					responseMap.put("thhumbnailLFilesize", files[2]);
					responseMap.put("thumbcontentType", thumbcontentType);
					responseMap.put("thhumbnailurl",  Util.isNull(files[3])?LoadProperties.systemProperties.getProperty("webUrl")+"/media/"+chatbotid+"/"+files[1]:files[3]);
				}
				if(!Util.isNull(fileUrl)&&!Util.isNull(filecontentType))
				{
					String filename1 =tempDir+System.currentTimeMillis()+fileName;
					String[] files2=saveFile(fileUrl,filecontentType,chatbotid,filename1,tempDir);
					responseMap.put("LocalPath", files2[0]);
					responseMap.put("Filename", files2[1]);
					responseMap.put("FileSize", files2[2]);
					responseMap.put("filecontentType", filecontentType);
					responseMap.put("url", Util.isNull(files2[3])?LoadProperties.systemProperties.getProperty("webUrl")+"/media/"+chatbotid+"/"+files2[1]:files2[3]);
				}
				return responseMap;
		} catch (JSONException e) {
		} catch (IOException e) {
		}
		 return null;
	}
	
	public static Map<String,Object> doDownloadTelecom(JsonElement content,String tempDir,String chatbotid)throws IOException, ServletException{

		 if(content==null || !content.isJsonArray() || content.getAsJsonArray().size()==0)
			 return null;
		 try {
			 JsonArray ja = content.getAsJsonArray();
			 String thumbnailUrl="";
			 String fileUrl="";
			 String fileName="";
			 String thumbcontentType="";
			 String filecontentType="";
			 for(int i=0;i<ja.size();i++){
				 JsonObject eobject = ja.get(i).getAsJsonObject();
				 String type =Util.getElementAsString(eobject,"type");

				 String contentype="";
				 contentype=Util.getElementAsString(eobject,"contentType");
				 String url=Util.getElementAsString(eobject,"url");
				 if("thumbnail".equals(type)){
					 thumbnailUrl=url;
					 thumbcontentType=contentype;
				 }else {
					 fileUrl=url;
					 filecontentType=contentype;
					 fileName = new File(url).getName();
				 }
			 }
			 Map<String, Object> responseMap = new HashMap<>();
			 if(!Util.isNull(thumbnailUrl)&&!Util.isNull(thumbcontentType)){
				 String filename ="download"+System.currentTimeMillis()+"_thumbnail"+fileName;
				 String [] files =saveFile(thumbnailUrl,thumbcontentType,chatbotid,filename,tempDir);
				 responseMap.put("thhumbnailLocalPath", files[0]);
				 responseMap.put("thhumbnailLFilename", files[1]);
				 responseMap.put("thhumbnailLFilesize", files[2]);
				 responseMap.put("thumbcontentType", thumbcontentType);
				 responseMap.put("thhumbnailurl",  Util.isNull(files[3])?LoadProperties.systemProperties.getProperty("webUrl")+"/media/"+chatbotid+"/"+files[1]:files[3]);
			 }
			 if(!Util.isNull(fileUrl)&&!Util.isNull(filecontentType)){
				 String filename1 =tempDir+System.currentTimeMillis()+fileName;
				 String[] files2=saveFile(fileUrl,filecontentType,chatbotid,filename1,tempDir);
				 responseMap.put("LocalPath", files2[0]);
				 responseMap.put("Filename", files2[1]);
				 responseMap.put("FileSize", files2[2]);
				 responseMap.put("filecontentType", filecontentType);
				 responseMap.put("url", Util.isNull(files2[3])?LoadProperties.systemProperties.getProperty("webUrl")+"/media/"+chatbotid+"/"+files2[1]:files2[3]);
			 }
			 return responseMap;
		 } catch (Exception e) {}
		 return null;
	}
	public static Map<String, Object>  doDownloadByPost(JsonObject content,String tempDir,String chatbotid) throws IOException, ServletException
	{
		if(content==null)
			return null;
		JsonElement je = content.get("contentText");
		if(je==null||je.isJsonNull())return null;
		List<JsonElement> list = new ArrayList<>();
		if(je.isJsonArray()) {
			je.getAsJsonArray().forEach(list::add);
//TODO for telecom
//		}else if(je.isJsonObject()){
//			list.add(je);
		}
		String fileName="";
		String thumbnailUrl="";
		String fileUrl="";
		String thumbcontentType="";
		String filecontentType="";
		for(JsonElement e:list)
		{
			JsonObject eo=e.getAsJsonObject();
			String type=Util.getElementAsString(eo, "type");
			if("thumbnail".equals(type))
			{
				thumbnailUrl=Util.getElementAsString(eo, "url");
				thumbcontentType=Util.getElementAsString(eo, "contentType");
			}else
			{
				fileName=Util.getElementAsString(eo, "fileName");
				fileUrl=Util.getElementAsString(eo, "url");
				filecontentType=Util.getElementAsString(eo, "contentType");
			}
		}
		if(Util.isNull(fileName))
			return null;
		Map<String, Object> responseMap = new HashMap<>();
		
		if(!Util.isNull(thumbnailUrl)&&!Util.isNull(thumbcontentType))
		{
			String filename =tempDir+System.currentTimeMillis()+"_thumbnail"+fileName;
			String [] files =saveFile(thumbnailUrl,thumbcontentType,chatbotid,filename,tempDir);
			responseMap.put("thhumbnailLocalPath", files[0]);
			responseMap.put("thhumbnailLFilename", files[1]);
			responseMap.put("thhumbnailLFilesize", files[2]);
			responseMap.put("thumbcontentType", thumbcontentType);
			responseMap.put("thhumbnailurl", Util.isNull(files[3])?LoadProperties.systemProperties.getProperty("webUrl")+"/media/"+chatbotid+"/"+files[1]:files[3]);
		}
		if(!Util.isNull(fileUrl)&&!Util.isNull(filecontentType))
		{
			String filename1 =tempDir+System.currentTimeMillis()+fileName;
			String[] files2=saveFile(fileUrl,filecontentType,chatbotid,filename1,tempDir);
			responseMap.put("LocalPath", files2[0]);
			responseMap.put("Filename", files2[1]);
			responseMap.put("FileSize", files2[2]);
			responseMap.put("filecontentType", filecontentType);
			responseMap.put("url", Util.isNull(files2[3])?LoadProperties.systemProperties.getProperty("webUrl")+"/media/"+chatbotid+"/"+files2[1]:files2[3]);
		}
		return responseMap;
	}
	public static String [] saveFile(byte[] bs,String filename,String tempDir) throws IOException
	{
		String localMediaPath = getTempDir() + File.separatorChar + "media"+File.separator+  "users";
		if(ContextHandler.getCurrentContext()!=null)
			localMediaPath=	 ContextHandler.getCurrentContext().getContextHandler().getBaseResource().getName()
					+ File.separatorChar + "media"+File.separator+ "users";
		File localMediaPathfile=new File(localMediaPath);
		if(!localMediaPathfile.exists())
			localMediaPathfile.mkdirs();
		File file=new File(localMediaPath,filename);
		Files.write(file.toPath(), bs);
		String originUrl="";
		try {
			
			List<String> filelist = new ArrayList<>(){{add(file.getAbsolutePath());}};
			String remoteUrl = LoadProperties.systemProperties.getProperty("fileServerUrl");
			String result = PostMedia.uploadMedia(filelist, remoteUrl);
			if (Util.isNull(result)) {
				log.error("Failed to synchronize medias.");
			} else {
				try {
					JsonObject syncEle = JsonParser.parseString(result).getAsJsonObject();
					  originUrl = Util.getElementAsString(syncEle.get(filename).getAsJsonObject(), "mediaUrl");
					 
				} catch (Exception e){
					log.error("syncMedia error", e);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new String [] {file.toString(),filename,file.length()+"",originUrl};
	}
	private static String getTempDir() {
		// ϵͳ��������
		String tmpDir = System.getenv("TMP");
		if(tmpDir==null || tmpDir.isEmpty())tmpDir = System.getProperty("java.io.tmpdir");
		Path tmpPath = Paths.get(tmpDir);
		if(!Files.isDirectory(tmpPath)) {
			try {
				Files.createDirectories(tmpPath, PosixFilePermissions.asFileAttribute(
						EnumSet.of(PosixFilePermission.OWNER_READ, PosixFilePermission.OWNER_WRITE, PosixFilePermission.OWNER_EXECUTE)));
			} catch (IOException e) {
			}
		}
		return tmpDir;
	}
	public static String []  saveFile(String thumbnailUrl,String thumbcontentType,String chatbotid,String filename,String tempDir) throws IOException
	{
		String tmpDir = getTempDir();
		String localMediaPath =tmpDir + File.separatorChar + "media"+File.separator+ chatbotid;
		if(ContextHandler.getCurrentContext()!=null&&ContextHandler.getCurrentContext().getContextHandler().getBaseResource()!=null)
			localMediaPath=	ContextHandler.getCurrentContext().getContextHandler().getBaseResource().getName()
				+ File.separatorChar + "media"+File.separator+ chatbotid;
		File localfile=new File(localMediaPath);
		if(!localfile.exists())
			localfile.mkdirs();
		final String ofile=localMediaPath+File.separator+filename;
//		Path localPath = Paths.get(localMediaPath);
		String originUrl ="";
//		File dir = new File(localMediaPath);
//		if (!dir.exists())
//			dir.mkdirs();
//		
//

		File outputFile = null;
//		Files.write(outputFile, con.getBytes("GB2312"));
		try {
			
			String remoteUrl = LoadProperties.systemProperties.getProperty("fileServerUrl");
			String webUrl=LoadProperties.systemProperties.getProperty("webUrl");
			String innerMedia=LoadProperties.systemProperties.getProperty("innerMediaUrl");
			String mediaSys = LoadProperties.systemProperties.getProperty("mediaSys");
			String rawUrl=thumbnailUrl;
			if(!Util.isNull(innerMedia))
			{
				thumbnailUrl=thumbnailUrl.replace(webUrl, innerMedia);
			}
//			if(remoteUrl.startsWith(webUrl)&&thumbnailUrl.startsWith(webUrl)) {
//				originUrl = thumbnailUrl;
//				filename=thumbnailUrl.substring(thumbnailUrl.lastIndexOf("/")+1);
//				ofile=localMediaPath+File.separator+filename;
//			}else
			{
				if("true".equals(mediaSys))
				{
					outputFile = new File(ofile);
//					String tofile=localMediaPath+chatbotid+File.separator+filename;
//					ofile=tofile;
					List<String> filelist = new ArrayList<>(){{add(ofile);}};
					log.info("file {} ofile {} rawUrl {}  ",thumbnailUrl,ofile,rawUrl);
					try {
						BotManager manager =Provider.injector.getInstance(BotManager.class);
						BotInfo botinfo = manager.getChatBotInfo(chatbotid);
						if(botinfo!=null)
							botinfo.getBotAccess().mediaDownload(botinfo, thumbnailUrl, ofile);
						if(!outputFile.exists()) {
							NetUtils.doHttpsWriteFiles(thumbnailUrl, null, null, thumbcontentType,ofile);
						}
					} catch (Exception e1) {
						NetUtils.doHttpsWriteFiles(thumbnailUrl, null, null, thumbcontentType,ofile);
					}
					String result = PostMedia.uploadMedia(filelist, remoteUrl);
					if (Util.isNull(result)) {
						log.error("Failed to synchronize medias.");
					} else {
						try {
							JsonObject syncEle = JsonParser.parseString(result).getAsJsonObject();
							originUrl = Util.getElementAsString(syncEle.get(filename).getAsJsonObject(), "mediaUrl");
							
						} catch (Exception e){
							log.error("syncMedia error", e);
						}
					}
					
				}else
				{
					originUrl=rawUrl;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new String [] {ofile.toString(),filename,outputFile!=null?outputFile.length()+"":"",originUrl};
	}

	public static Map<String, String> uploadSyncMedia(DataSource ds, JsonObject cardObj, Upload uploadMethod, String chatbotid, String remoteAddr) {
		String baseUrl = LoadProperties.systemProperties.getProperty("webUrl");
		baseUrl += (baseUrl.endsWith("/") ? "" : "/") + "media";
		String filename = Util.getElementAsString(cardObj, "filename");
		String originContentType = Util.getElementAsString(cardObj, "originContentType");
		String thumbnailFilename = Util.getElementAsString(cardObj, "thumbnailFilename");
		String thumbnailImageUrl = baseUrl + "/" + thumbnailFilename;
		String thumbnailContentType = Util.getElementAsString(cardObj, "thumbnailContentType");
		
		String localMediaPath =  getTempDir() + File.separatorChar + "media";
		if(ContextHandler.getCurrentContext()!=null)
			localMediaPath=	   ContextHandler.getCurrentContext().getContextHandler().getBaseResource().getName() + "/media";

		Path targetPath;
		Path localPath = Paths.get(localMediaPath);
		Path thumbnailPath = localPath.resolve(thumbnailFilename);
		JsonArray filenameArray;
		if (cardObj.has("filenames") && cardObj.get("filenames").isJsonArray() && (filenameArray = cardObj.get("filenames").getAsJsonArray()).size() > 1) {
			String mergeFilename = "m" + System.currentTimeMillis() + ".gif";
			targetPath = localPath.resolve(mergeFilename);
			originContentType = "image/jpeg"; //HTTP ��Content-Type�� of ��image/gif�� is not supported.
			boolean flag = ImageUtil.mergeGIF(localPath, targetPath, Paths.get(""), 300, 300, filenameArray); // ����gifͼƬ
			if (flag)
				filename = mergeFilename;
			else
				log.error("picture merge failed, filenames={}.", filenameArray);
		} else {
			targetPath = localPath.resolve(filename);
			
		}
		if(Util.isNull(thumbnailFilename))
			thumbnailPath=targetPath;

		String originImageUrl = baseUrl + "/" + filename;
		Map<String, Object> uploadParams = new HashMap<>();
		uploadParams.put("originImageUrl", originImageUrl);
		uploadParams.put("originContentType", originContentType);
		uploadParams.put("thumbnailImageUrl", thumbnailImageUrl);
		uploadParams.put("thumbnailContentType", thumbnailContentType);
		uploadParams.put("filename", filename);
		uploadParams.put("chatbotid", chatbotid);
		String remoteUrl = LoadProperties.systemProperties.getProperty("fileServerUrl");

		String finalTargetPath = targetPath.toString();
		String finalThumbnailPath = thumbnailPath.toString();
		Map<String, String> mediaTypeMap = new HashMap<>();
		mediaTypeMap.put(filename, "media");
		mediaTypeMap.put(thumbnailFilename, "thumbnail");
		List<String> filelist = new ArrayList<>(){{add(finalTargetPath); add(finalThumbnailPath);}};
		String result = PostMedia.uploadMedia(filelist, remoteUrl);
		JsonObject syncEle = !Util.isNull(result) ? JsonParser.parseString(result).getAsJsonObject() : new JsonObject();
		if (syncEle == null || syncEle.isJsonNull() || syncEle.get(filename) == null || syncEle.get(thumbnailFilename) == null) {
			log.error("Failed to synchronize medias. start upload to local server...");
			uploadParams.put("mediaSize", targetPath.toFile().length());
			String mediaLocalPath = Util.getElementAsString(cardObj, "originImageLocalPath");
			String thumbnailLocalPath = Util.getElementAsString(cardObj, "thumbnailLocalPath");
			return uploadMedia2HW(mediaLocalPath, thumbnailLocalPath, uploadMethod, ds, remoteAddr, uploadParams);
		} else {
			Map<String, String> uploadmap = new HashMap<>();
			try {
				long mediaSize = targetPath.toFile().length();
				for (String m : mediaTypeMap.keySet()) {
					if (syncEle.get(m) != null && syncEle.get(m).isJsonObject()) {
						JsonObject mediaObj = syncEle.get(m).getAsJsonObject();
						String mediaUrl = Util.getElementAsString(mediaObj, "mediaUrl");
						String rpath = Util.getElementAsString(mediaObj, "localPath");
//							String state = Util.getElementAsString(mediaObj, "state");
						String type = mediaTypeMap.get(m);
						if (type.equals("media")) {
							originImageUrl = mediaUrl;
							uploadmap.put("originImageUrl", mediaUrl);
							uploadmap.put("originImagePath", rpath);
						}
						if (type.equals("thumbnail")) {
							thumbnailImageUrl = mediaUrl;
							uploadmap.put("thumbnailUrl", mediaUrl);
							uploadmap.put("thumbnailPath", rpath);
						}
					}
				}
				insertMedias(ds, originImageUrl, originContentType, thumbnailImageUrl, uploadmap.get("originImagePath"),
						thumbnailContentType, uploadmap.get("thumbnailPath"), filename, chatbotid, mediaSize);
				return uploadmap;
			}catch (Exception e) {
				log.error("parse json data error.", e);
			}
		}
		return new HashMap<>();
	}

	public static Map<String, String> uploadMedia2HW(String contentLocalPath, String thumbnailLocalPath, Upload uploadMethod, DataSource ds,
													 String remoteAddr, Map<String, Object> params) {
		UploadFileEntity entity = new UploadFileEntity(contentLocalPath, thumbnailLocalPath);
		if (Util.isNull(entity.getContentLocalPath()) || Util.isNull(entity.getThumbnailLocalPath())) {
			return null;
		}
		String originImageUrl = params.get("originImageUrl") + "";
		String originContentType = params.get("originContentType") + "";
		String thumbnailImageUrl = params.get("thumbnailImageUrl") + "";
		String thumbnailContentType = params.get("thumbnailContentType") + "";
		String filename = params.get("filename") + "";
		String chatbotid = params.get("chatbotid") + "";
		long mediaSize = Util.toLong(params.get("mediaSize") + "", 0);
		entity.setChatbotid(chatbotid);
		long lastId = insertMedias(ds, originImageUrl, originContentType, thumbnailImageUrl, contentLocalPath,
				thumbnailContentType, thumbnailLocalPath, filename, chatbotid, mediaSize);
		if (lastId > 0)
			entity.setMediaID(lastId + "");


		uploadMethod.setDbSource(ds);
		uploadMethod.doUpload(entity);

		if(!Util.isNull(entity.getMediaUrl()))
		{
			log.info("upload sucess ,receive {} from remoteAddr {},resbody{} ", entity,
					remoteAddr, JsonParser.parseString(new Gson().toJson(entity)));
			if(ds!=null)
			{
				RcsRunLogAction.recordLog("UpdateMedia ", "upload sucess  "+JsonParser.parseString(new Gson().toJson(entity)), remoteAddr, "200", "UpdateMedia", ds);
			}
			Map<String, String> uploadmap = new HashMap<>();
			uploadmap.put("originImageUrl", entity.getMediaUrl());
			uploadmap.put("thumbnailUrl", entity.getThumbnailUrl());
			uploadmap.put("originImagePath", entity.getContentLocalPath());
			uploadmap.put("thumbnailPath", entity.getThumbnailLocalPath());
			return uploadmap;
		}else
		{
			log.info("upload failed ,receive {} from remoteAddr {},resbody{} ", entity,
					remoteAddr, JsonParser.parseString(new Gson().toJson(entity)));
			if(ds!=null)
			{
				RcsRunLogAction.recordLog("UpdateMedia ", "upload failed  "+JsonParser.parseString(new Gson().toJson(entity)), remoteAddr, "500", "UpdateMedia", ds);
			}
			Map<String, String> uploadmap = new HashMap<>();
			uploadmap.put("originImageUrl", originImageUrl);
			uploadmap.put("thumbnailUrl", thumbnailImageUrl);
			uploadmap.put("originImagePath", contentLocalPath);
			uploadmap.put("thumbnailPath", thumbnailLocalPath);
			return uploadmap;
		}
	}

	public static long insertMedias(DataSource ds,String originImageUrl, String originContentType, String thumbnailImageUrl, String contentLocalPath,
								String thumbnailContentType, String thumbnailLocalPath, String filename, String chatbotid, long mediaSize) {
		String sqlId = "insertUploadMedias";
		try {
			Object[] insertParams = new Object[15];
			insertParams[0] = originImageUrl;
			insertParams[1] = 0;
			insertParams[2] = originContentType;
			insertParams[3] = thumbnailImageUrl;
			insertParams[4] = contentLocalPath;
			insertParams[5] = null;
			insertParams[6] = null;
			insertParams[7] = thumbnailContentType;
			insertParams[8] = thumbnailLocalPath;
			insertParams[9] = filename;
			insertParams[10] = null;
			insertParams[11] = 0;
			insertParams[12] = new java.util.Date();
			insertParams[13] = chatbotid;
			insertParams[14] = mediaSize;
			long lastId = SqlUtil.insertBySqlId(ds, sqlId, insertParams);
			log.info("media insert to db {}", lastId);
			return lastId;
		} catch (SQLException e) {
			log.error("media insert to db failed. sqlId={}", sqlId, e);
		}
		return -1;
	}

	public static String exportMedias(DataSource ds, JsonObject object) {
		String chatbotid = Util.getElementAsString(object, "chatbotid");
		JsonArray medias = object.getAsJsonArray("mediaids");
		if(Util.isNull(chatbotid) && (medias == null || medias.size() == 0))
			return "";
		String sqlId = "queryAvaMedias";
		try {
			String sql = XmlSqlGenerator.getSqlByJson(sqlId, null, object);
			JsonArray array = SqlUtil.queryForJson(ds, sql);
			if (array.size() == 0)
				return "";
			String targetFile = "";
			String localMediaPath = ContextHandler.getCurrentContext().getContextHandler().getBaseResource().getName() + File.separatorChar + "media";
			targetFile = File.separatorChar + "mediaZip" + File.separatorChar + System.currentTimeMillis();
			localMediaPath += targetFile;
			Path zipDirPath = Paths.get(localMediaPath);
			Files.deleteIfExists(zipDirPath);
			Files.createDirectories(zipDirPath);
			Path zipSubDirPath = Paths.get(zipDirPath.toString() + File.separatorChar + "medias");
			Files.createDirectory(zipSubDirPath);
			for (JsonElement element : array) {
				JsonObject mediaObj = element.getAsJsonObject();
				String mediaurl = Util.getElementAsString(mediaObj, "mediaurl");
				String thumbnailurl = Util.getElementAsString(mediaObj, "thumbnailurl");
				String mediacontenttype = Util.getElementAsString(mediaObj, "mediacontenttype");
				String thumbnailcontenttype = Util.getElementAsString(mediaObj, "thumbnailcontenttype");
				if (!Util.isNull(mediacontenttype)) {
					mediacontenttype = mediacontenttype.substring(mediacontenttype.lastIndexOf("/") + 1);
					download(mediaurl, zipSubDirPath.toString() + File.separatorChar + System.currentTimeMillis() + "." + mediacontenttype);
				}
				Thread.sleep(1);
				if (!Util.isNull(thumbnailcontenttype)) {
					thumbnailcontenttype = thumbnailcontenttype.substring(thumbnailcontenttype.lastIndexOf("/") + 1);
					download(thumbnailurl, zipSubDirPath.toString() + File.separatorChar + System.currentTimeMillis() + "." + thumbnailcontenttype);
				}
			}
			String zipFilename = System.currentTimeMillis() + ".zip";
			targetFile = targetFile + File.separatorChar + zipFilename;

			ZipUtil.zip(zipDirPath.toString() + File.separatorChar + zipFilename, zipSubDirPath.toString());
			return targetFile;
		}catch (Exception e) {
			log.error("export medias error.", e);
		}
		return "";
	}

	private static void download(String url, String targetPath) throws IOException {
		URL url1 = new URL(url);
		URLConnection uc = url1.openConnection();
		uc.setConnectTimeout(15000);
		uc.setReadTimeout(15000);
		InputStream inputStream = uc.getInputStream();
		FileOutputStream out = new FileOutputStream(targetPath);
		int j = 0;
		while ((j = inputStream.read()) != -1) {
			out.write(j);
		}
		inputStream.close();
	}

	public static List<Map<String, Object>> multiUpload(HttpServletRequest request, String tmpDir, String targetDir) throws ServletException, IOException {
		Collection<Part> parts = getParts(request, tmpDir);

		String localMediaPath = ContextHandler.getCurrentContext().getContextHandler().getBaseResource().getName() + File.separatorChar + "media";
		if (!Util.isNull(targetDir))
			localMediaPath += File.separator + targetDir;

		List<Map<String, Object>> retInfos = new ArrayList<>();
		for (Part part : parts) {
			retInfos.add(doUpload(part, Paths.get(localMediaPath), tmpDir));
		}
		return retInfos;
	}

	public static String makeMediaUrl(String targetDir, String filename) {
		String baseUrl = LoadProperties.systemProperties.getProperty("webUrl");
		baseUrl += (baseUrl.endsWith("/") ? "" : "/") + "media";
		return baseUrl + "/" + targetDir + "/" + filename;
	}
}
