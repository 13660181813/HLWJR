package org.ydzy.rcs.impl;

import org.ydzy.rcs.SuggestionDisplay;
import org.ydzy.rcs.annotation.Description;
import org.ydzy.util.StringUtils;

import com.google.inject.Singleton;

@Singleton
@Description("calendarAction")
public class CalendarAction implements SuggestionDisplay{
	String calendar = "{\r\n" 
			+ "        \"action\":{\r\n" 
			+ "            \"displayText\":\"%s\",\r\n"
			+ "            \"calendarAction\":{\r\n"
			+ "                \"createCalendarEvent\":{\r\n" 
			+ "                    \"startTime\":\"%s\",\r\n"
			+ "                    \"endTime\":\"%s\",\r\n" 
			+ "                    \"title\":\"%s\",\r\n"
			+ "                    \"description\":\"%s\",\r\n" 
			+ "                    \"fallbackUrl\":\"%s\"\r\n"
			+ "                }\r\n" 
			+ "            },\r\n" 
			+ "            \"postback\":{\r\n"
			+ "                \"data\":\"set_by_chatbot_create_calendar_event\"\r\n" 
			+ "            }\r\n"
			+ "        }\r\n" 
			+ "    }\r\n";

	@Override
	public String suggestionHtml(String[] args) {
		int length=args.length;
		return StringUtils.format(calendar, length<=1?"":args[1].replace("\r", ""), length<=2?"":args[2].replace("\r", ""), length<=3?"":args[3].replace("\r", ""), length<=4?"":args[4].replace("\r", ""),
				length<=5?"":args[5].replace("\r", ""), length<=6?"":args[6].replace("\r", ""));
	}

}
