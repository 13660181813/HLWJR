package org.ydzy.rcs.impl;

import java.util.List;
import java.util.UUID;

import org.ydzy.handler.BaseRcsContext;
import org.ydzy.rcs.MessagesInter;
import org.ydzy.rcs.annotation.Description;
import org.ydzy.rcs.entity.CmccMsg;
import org.ydzy.rcs.entity.CommonMsg;
import org.ydzy.rcs.entity.ReceiveEntity;
import org.ydzy.util.Util;
import org.ydzy.util.XmlUtils;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.inject.Singleton;

/**�й��ƶ����ݽṹ ��Ϣ����
 * @author XFDEP
 *
 */
@Singleton
@Description(value="cmccMessageImp")
public class CmccMessagePack implements MessagesInter {
	@Override
	public String body(ReceiveEntity requestObject, JsonObject eobject, BaseRcsContext context,List<MessageBody> body) {
		CmccMsg outmsg=this.makeMsg(requestObject, eobject, context, body);
		String rst= makeMsg(outmsg, "xml");
		return rst;
	}
	
	protected String makeMsg(CmccMsg msg, String type) {
		String rst;
		if("json".equals(type)){
			Gson gson = new GsonBuilder()
					.setPrettyPrinting()
					.disableHtmlEscaping()
					.create();
			rst=gson.toJson(msg);
		}else {
			rst = XmlUtils.toXml(CmccMsg.class, msg, true);
		}
		
//		rst= XmlUtils.toXml(CmccMsg.class, msg,true);
//		if("json".equals(type))
//		{
//			rst=new Gson().toJson(XML.toJSONObject(rst));
//		}
		return rst;
	}
	
	protected CmccMsg makeMsg(ReceiveEntity requestObject, JsonObject eobject, BaseRcsContext context, List<MessageBody> body) {
		CmccMsg msg=new CmccMsg();
		msg.address=requestObject.getSenderAddress();
		msg.setDestinationAddress(requestObject.getSenderAddress());
		CmccMsg.outboundIMMessage outmsg=new CmccMsg.outboundIMMessage();
		
		String boundary = "next";
		String miltipartBody = multipart(boundary, body);
		outmsg.bodyText=miltipartBody;
		outmsg.contentType="multipart/mixed; boundary=\"" + boundary + "\"";
		//outmsg.contentEncoding="base64";
		outmsg.contributionID=UUID.randomUUID().toString().replace("-", "").toLowerCase();
		outmsg.conversationID=UUID.randomUUID().toString().replace("-", "").toLowerCase();
		msg.fallbackContentEncoding="utf8";
		msg.fallbackContentType="text/plain";
		outmsg.fallbackSupported=false;
		outmsg.storeSupported=true;
		outmsg.imFormat="IM";
		Object orignMsg= context.getAttributes().get("origMsg");
		
		if(orignMsg!=null&&orignMsg instanceof JsonObject) {
			String cid = Util.getElementAsString((JsonObject)orignMsg, "contributionID");
			if(Util.isNull(cid)) {
				cid = Util.getElementDeepAsString((JsonObject)orignMsg, "receive5GMsg", "contributionID");
			}
			outmsg.inReplyToContributionID = Util.isNull(cid)?null:cid;
		}
		outmsg.messageId=UUID.randomUUID().toString().replace("-", "").toLowerCase();
		msg.rcsBodyText=Util.getElementAsString(eobject, "rcsBodyText");
//		outmsg.reportRequest=new ArrayList<String>(){{ add("Delivered");add("Failed");}};
		CommonMsg.serviceCapability service=new CommonMsg.serviceCapability();
		service.capabilityId=context.getConfig().enterpriseProperty(requestObject.getChatBotId(), "capabilityId");
		service.version=context.getConfig().enterpriseProperty(requestObject.getChatBotId(), "version");
		
		outmsg.serviceCapability=service;
		outmsg.shortMessageSupported=false;
		msg.smsBodyText=Util.getElementAsString(eobject, "smsContent");
		outmsg.subject=Util.getElementAsString(eobject, "keywords");
		msg.trafficType=Util.getElementAsString(eobject, "trafficType");
		
		msg.outboundIMMessage=outmsg;
		msg.senderAddress=context.getConfig().enterpriseProperty(requestObject.getChatBotId(), "sp");
		msg.senderName=context.getConfig().enterpriseProperty(requestObject.getChatBotId(), "defaultName");
		requestObject.getAnswersObject().put("messagePack", outmsg);
		return msg;
	}

	
}
