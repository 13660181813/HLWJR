package org.ydzy.rcs;

import org.ydzy.rcs.entity.ReceiveEntity;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

/***
 * ai����
 * @author ljp
 *
 */
public interface IAIRobot {
	String runAi(ReceiveEntity reqObject);
	
	
	default JsonElement run(ReceiveEntity receiveEntity) {
		String say = runAi(receiveEntity);
		if(say==null)return null;

		JsonObject jo = new JsonObject();
		jo.addProperty("type", "singlecard");
		jo.addProperty("spName", receiveEntity.getChatBotId());
		jo.addProperty("suggestions", "");
		JsonArray ja = new JsonArray();
		JsonObject content = new JsonObject();
		content.addProperty("msg", say);
		content.addProperty("smsContent", say);
		content.addProperty("suggestions", "");
		content.addProperty("params", "");
		ja.add(content);
		jo.add("content", ja);
		return jo;
	}
	
}
