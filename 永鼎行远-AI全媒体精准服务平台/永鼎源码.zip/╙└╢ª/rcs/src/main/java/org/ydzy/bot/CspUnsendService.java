package org.ydzy.bot;

import org.ydzy.handler.BaseRcsContextProvidor;
import org.ydzy.publish.ConstantTopics;
import org.ydzy.publish.ISubscriber;
import org.ydzy.publish.SubscribeCaches;
import org.ydzy.publish.SubscribePublish;
import org.ydzy.rcs.Provider;
import org.ydzy.rcs.annotation.Description;
import org.ydzy.rcs.entity.ReceiveEntity;

import com.google.inject.Inject;
import com.google.inject.Singleton;

@Singleton
@Description(value="AutoMsgUnsendSubscriber",autoInstance=true)
public class CspUnsendService   implements ISubscriber<ReceiveEntity> {
	@Inject
	SubscribeCaches subscribeCaches;
	public CspUnsendService() {
		
	}
	public void init()
	{
		if(subscribeCaches==null)
			subscribeCaches=Provider.injector.getInstance(SubscribeCaches.class);
		SubscribePublish<ReceiveEntity> sub=subscribeCaches.getSubscribePublishInstance(ConstantTopics.CHATBOT_MSG_UNSEND, ReceiveEntity.class);
		this.subscribe(sub);
	}

	@Inject
	private BaseRcsContextProvidor contextProvidor = null;
	public BaseRcsContextProvidor getContextProvidor() {
		return contextProvidor;
	}
	@Inject
	BotManager botmanager;
	@Override
	public void subscribe(SubscribePublish<ReceiveEntity> subscribePulish) {
		subscribePulish.subcribe(this);
	}

	@Override
	public void unSubscribe(SubscribePublish<ReceiveEntity> subscribePulish) {
		subscribePulish.unSubcribe(this);
		
	}

	@Override
	public void update(String publisher, ReceiveEntity message) {
		String chatBotID=message.getChatBotId();
		BotInfo info = botmanager.getChatBotInfo(chatBotID);
		
		org.ydzy.handler.BaseRcsContext context = contextProvidor.newBaseRcsContext();
		if(info!=null)
		info.getBotAccess().cspUnSendMsg(info, message, context);
	}

}
