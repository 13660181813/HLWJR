package org.ydzy.rcs.cache.impl;

import com.google.inject.Singleton;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.ydzy.rcs.Provider;
import org.ydzy.rcs.annotation.Description;
import org.ydzy.rcs.cache.CacheProvider;

import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.DelayQueue;
import java.util.concurrent.Delayed;
import java.util.concurrent.TimeUnit;

@Description(value = "concurrentHashMapCacheProvider", autoInstance = true)
@Singleton
public class ConcurrentHashMapCacheProvider implements CacheProvider {
    private static final Logger log = LoggerFactory.getLogger(ConcurrentHashMapCacheProvider.class);
    private final Map<String, ValueWrapper> caches = new ConcurrentHashMap<>();
    private final DelayQueue<ValueWrapper> delayQueue = new DelayQueue<>();

    @Override
    public <T> T getCache(String key) {
        ValueWrapper valueWrapper = caches.get(key);
        return valueWrapper == null ? null : (T) valueWrapper.data;
    }

    @Override
    public boolean exists(String key) {
        return caches.containsKey(key);
    }

    @Override
    public boolean isEquals(String key, Object value) {
        return Objects.equals(getCache(key), value);
    }

    @Override
    public boolean isEqualsIgnoreCase(String key, String value) {
        Object cacheValue = getCache(key);
        if (!(cacheValue instanceof String)) {
            return false;
        }
        String holder = (String) cacheValue;
        return holder.equalsIgnoreCase(value);
    }

    @Override
    public void putCache(String key, Object value) {
        putCache(key, value, 5 * 60 * 1000);
    }

    @Override
    public void putCache(String key, Object value, long timeout) {
        putCache(key, value, timeout, TimeUnit.MILLISECONDS);
    }

    @Override
    public void putCache(String key, Object value, long timeout, TimeUnit timeUnit) {
        long timeoutMils = TimeUnit.MILLISECONDS.convert(timeout, timeUnit);
        ValueWrapper valueWrapper = new ValueWrapper(key, timeoutMils, value);
        ValueWrapper oldValueWrapper = caches.put(key, valueWrapper);
        if (oldValueWrapper != null) {
            delayQueue.remove(oldValueWrapper);
        }
        delayQueue.offer(valueWrapper);
    }

    @Override
    public boolean deleteCache(String key) {
        ValueWrapper oldValueWrapper = caches.remove(key);
        if (oldValueWrapper != null) {
            delayQueue.remove(oldValueWrapper);
            return true;
        }
        return false;
    }

    public void init() {
        ConcurrentHashMapCacheProvider instance = Provider.injector.getInstance(ConcurrentHashMapCacheProvider.class);
        instance.startCleanCacheThread();
    }

    public void startCleanCacheThread() {
        Thread cleanCacheThread = new Thread(() -> {
            while (!Thread.interrupted()) {
                try {
                    ValueWrapper valueWrapper = delayQueue.take();
                    caches.remove(valueWrapper.key, valueWrapper);
                } catch (InterruptedException e) {
                    log.error("take task error:", e);
                }
            }
        });
        cleanCacheThread.setDaemon(true);
        cleanCacheThread.setName("cleanCacheThread");
        cleanCacheThread.start();
    }

    static class ValueWrapper implements Delayed {
        final String key;
        final long start = System.currentTimeMillis();
        volatile long time;
        volatile Object data;

        public ValueWrapper(String key, long time, Object data) {
            this.key = key;
            this.time = time;
            this.data = data;
        }

        @Override
        public long getDelay(TimeUnit unit) {
            return unit.convert((start + time) - System.currentTimeMillis(), TimeUnit.MILLISECONDS);
        }

        @Override
        public int compareTo(Delayed o) {
            return (int) (this.getDelay(TimeUnit.MILLISECONDS) - o.getDelay(TimeUnit.MILLISECONDS));
        }

        @Override
        public String toString() {
            return "ValueWrapper{" +
                    "key='" + key + '\'' +
                    ", start=" + start +
                    ", time=" + time +
                    ", data=" + data +
                    '}';
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;
            ValueWrapper that = (ValueWrapper) o;
            return start == that.start && time == that.time && Objects.equals(key, that.key) && Objects.equals(data, that.data);
        }

        @Override
        public int hashCode() {
            return Objects.hash(key, start, time, data);
        }
    }
}
