package org.ydzy.rcs.util;

import java.time.LocalDate;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.time.temporal.ChronoField;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

import org.ydzy.bot.BotManager;
import org.ydzy.bot.BotUtil;
import org.ydzy.util.Util;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.inject.Inject;

/**
 * 
 * @author ljp
 * ������Ϣ
 */
public class TravelRecordManager{
	private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(TravelRecordManager.class);

	/*
{
"color":"green","phone":"186****8841","time":"2021.07.22 17:46:03"
,"message":"iVBORw0KGgoAAAANSUhEUgAAA7YAAACWCAYAAADqvhQzAAAZHElEQVR42u3dS5LdurFA0Zp/221PVa/1IuRrq1SHzC+wdoR6Kh6SAIHc+CS+fgEAAAAAsJgvrwAAAAAAQGwBAAAAACC2AAAAAAAQWwAAAAAAsQUAAAAAgNgCAAAAAEBsAQAAAAAgtgAAAAAAYgsAAAAAwLFi+69//fvx3z39W8wjuyzVFQBv25B//gMAPJCHr69v/3me897RFWL7NEj4XwGGIOOMgLEiIAWIFyrfb0dZ3FwfPn32U9/N1FhJ2wRi6x1NfabHd/GmwRXA6XRP6NwBInP+++0qD2L7s2ev6H9IrXoJYusdXSi2JEWwGF2e6gsE8+h4v91tD7H9+7P/qYwi3lXnu898Ln0yiC2xJbaBDZsGkdie0Ll/d6/ACSLz3ffX8a/j/RLb+d9CRp2ZOKgxoR48vZ+tbQb2SNtPpOu0f8Q2WWxPGumbFtBNb9grA9EN9WVLXb7925hWXsR2h9h2tqvEtlduJ313xJbYEltiS2wDxPZtAo4NDY+gvV9CN3RUm++R2BJbYjt7QJbYxpVVZHs36Zvb0t8RW2JLbIntSLHd2LBFZm0WtNcEFDcKY0eQRGyJ7VaxrV5W3FF3iG18/z25L/rbb20evCa2xJbYEttxYrtdaontjsB8uywSW98IsSW2xLb32betHnpT77tWD2zo60BsiS2xLR9BJbZnBe0ZgcQWod12v8SW2G4NLjsSQVXXH2IbN0g6uSw+bZsMspBaYktsie1LsT1htlYAe4+oVCxFu1VsiZ3n3yp9JyxN9S18fp2p9ftN+zxpiTSp3SufZC5X1B33M1Rs3wTGMkoS261iu3kAZev+I2JLbKeLbWU5Edtzz2+NaJur2nZSS2yJ7XyxNVP9Q7F92/jKJklst4ntJ9chtvcF8pZgz2jnp4ltxvNOP27mxu8g8xrR1zpZHiWMIrYgth+L7dsOwWwtsT1RbKd3+pszRhLbc8T2k7/dJrZV3z6x3bE9pUtqKyTvSdxHaslOq9RcKnbENllsSe3+e7yV6Uk8IgNS3wWx7ZrRydjrWl2/zNgS206h7RLmru+B1BJbYktsH4vtmw4hM2kPsUV12XTP2kTUK2Ir6K8MprP+brLYnvQ9ENufvaMpUhsxGRFR/zqfD8SW2BLbP4rtmw4hOxstsUVV2WQG9pXBKLEV9E9ZphhZ1hPE9jvB2Vz+xHamaEa2T6SW2BJbYnuF2H4aHGc2blMCF2KL6WL7t/sgtjvucdO1OwcvN/QPzm++t4+c8P6rV911bHcQNxFbYktsvxXbJ8FxZsMWNWOr075bNG8V24n3SWzPuHb3ACaxJbabhbaqbCNX3pHafXHmT2QnU5i77pnYEtuvnzYeT0b7Oju2yY0NsSW2lfdAbInt5KNuqiSV2BLb7vKuqhtP5XDSEv+pdXjT9zRVPjvFdgNTn2HLcUxfP22cPt2j81Y6T5a/yc+2ObAitvlbBIjtvWI7aa/uyVtVDICeN2Nb3cf+5P4ivu+qga4pgrttsIjYEturxfafH21WR/OmwXwjyjrtXWK7IXCd2skS2333OP1M1IqtJqe1D8T2vmd/s4e1sm+NeOcdbUK3WBLbs8R26vJaYhsotpGN3tuG8EnArtMmtreI7ebzdontLrGNSj6TnbmX2O7qE6Y9e2Td3Fb+3auwfnrd6Um5iC2xJbYDxXbKiP8p+waJLbHtrkPElthGJmmaeiRN1DuYMEu0YU9htgRNO292gmhPLuNKUZz2Xd4kttlyQ2yJ7QqxzRKbrXK7TWw7rktscweJiC2xnTjYFbmi5zSxPW2wM1tso5bWEtv49xF1vUlnBU+E2BJbYls44l8RhBBbYnua2HYk+NiQ4bUr2Ca2se97QvZWYjtTbDtWid0itm/LuVpoP71u9ruaCrEltsS2QDQyOrXo37k5eCe2c8U2uo4T29lHW0wKkrv32xHbOWJbdZ2MOhtZx28S26wJjupsyrcRLSFR54xWyziIbXonMen3iC2xJbbEltjOmaF4emRKRdkR2x1i2zHYcnIdiJ5wqG7rbhVcYgtiW9CgZTbqWUkIiC2x7RbbjH1IxHa22G45Ize7vk9qH27cw3eK2G77fqZ9sxkrHqr75tvktktsM5c6Z97v9H/EtklsM5MLZASJxJbYTg9As8SU2PbXsaoAcFtgPrV96Pzep2RFni62Vctct7aXXf335LPeiW2eJBLbXrG9UeRDxTY7Y15GYEBsie3kTjMzYcfkWbpbkqtVzW6cNuN0q9h2fA/E9m6xrdpOVlWHbyJKHCoFhdgS2zFiW5EG/pQg2Tm2xLbyNzaI7ZZlY9n79joTMhHb/vc4KXnRRrGdsOKB2P7n305qu29jith+8nvEltiOnrGNbvhPEUhiS2wrr09s5327T7KPbmsLiW1++3uy2EbJMLGt3xKGc8S2WlaILbEdJba//7+JMxUnzvoQ2zPFtuKMv01ie9qgVMRWCWJ7lth+V86Tjp3pFNsnQrm1z562BJ3U3ie2HcIyLTlRqZAlPC+xDRLbaSPTG4J4Yktso2Vmi9hOW3rZIUcTs8wT2zli2ym3m8V2c589LekS7hLbTwUkSlomiG1HxuLq6xLbX3uTpkzkpuQ4T69LbPP3ck6vcyfuj48+i3hyIhdim1Mvuo9OmSi2m47LypL6yd/ttizQt4vtG/l4Ky9dYjt5qTCxPUhsT4XYEtvt16x4h6eJbYacdmWY7Q5OTxLb6PPXq77RCuF4I7YT+8WMPnDCoOqb5KLEdpbYRsjHm2tUim2njHUubya2ILbEtkQYt591mFEvpn0rHVL6SR0htueIbVWdmiy2P5HBrneQfZ2s7+BNPXxavsR2h9hW7pX907Wmzl5+8veZ95DxzBPr5iqxzV4yRWyJLbHdEQw8DYi2fR9Ve6YzZrSIbW4bU3lm+yli+5N9xxP7xaw+MHPff1T5Etv5YttxdM8TeawS2Tfyn3EvEwWS2P76VdbxEFtiS2zPENtp30vksR+ZskFs54vtljPbiW3P3vrK/cVT+xCiWiO2mZJVJbbZS2AzZ3g7klJdL7YRS9y2JNohtsSW2PYkFpqSLCcz2KwUDmI7V2wrZ/Gj61n1dT49Amlav1ixLz5z5r+z/yC2+WI7bTnstGW+m/aWEtsfim1kwERuiS2xJbaVe0Srv4+Od/uT35IVeY7YdszibxbbT9rGaXW5MpN5p9zeGCudIrafyFvWvTy557ci2jEo0CGYxDZZbLMklNjWBMnOsd1Z76bPeE4t30/uYfpgAbGdIbads/jEdobYTq3jE/erEtsasY0Qyqf38+ae3wh0hBRPl1pi+7AzihLbm+SW2BJbYls7+9H9fXS3K8S2X2wnZDHuFNvs7+6Ta3XVt2yxjfo7sdJ9Yvvd/8+6p4h7/u4akZIVkUXajO0Asa3c6/TJ354oGsSW2J5+n1mJZCYcTzRllmNSdmli+7M2deq3tqUdezv7m1HuWQmdTuqXiO08sf1ff5N1X5H3nCVWmVmOqyST2BaJ7ZtOasKZdsSW2BLbvkB7y6xoZ3lPaHOI7a91e9k3iu20utN5n6fJLbGtF9vf/27TPUfLbLTQfvK3xDZJbCvOUMtKIjO9UZc8itjeIrYZgf20bM5/k8pb25wTziCO7BenfX8nSO0ksX2S1TuzzT613Cfe12lie8o9T8qQ/Ok1iO1Ssc0aCSW2xJbY9t9n1zmut367xHaG2E5LwrNdDiLfZXbiusiBj66lzFFlemrd3TRgcJvYZi0Djl5iXCm3xDZINrMaw61nXxJbYntbRzztHFdiS2ynzNh2P/uU9idSALPrwNOY6O07qYqtNrXxE/vSqX3BjTO2kXtaM/fOVsktsW0S2/+/ToUcTR3xI7b73iux7e/8J5wZS2xzfnNaG/RWyibUgSkSGzXz3XWEzk9ij+h31VnuXZngiS2xfZMVuUJon953VVIpYvugEZ9+ltzEBojYEtsTxbZrCWbl7xLb+N/cECS/mXE8kexkglkiNSn517TjwqLLltgS22liGyWzUefvVshtVvbmin+pYjul4dmwPJXYEtsbxbY7OKsKtohtj/xMGxg97SidKnn9ybt7838i60DFTOqGJGPElthOud8nZ9NmiF/ku86WvevFtupYlurg3B5bYktse/a5Tg3OiO2/W9//hiA5S67I7DOZjGjTIlaiKfe7cxpIHtUntZUJlaLltEKuie0/xDZyBHSitEyWWmJ7/oDBaUyexapKxnKT2FbP3lXMtGdm4D/trNjscotMLPX2G3gzo7y5z5nYpjvuZ7fYTpGd7N+sukbWfuPrZmzfNIbZje22xm1DZ7hVbG9YGij4yQ3QTxXbqJU4m0T2Tbubkbn3BrnN+r2oso08KvDEpenZA4CT/t3CzWJb8VudEtpZBuv22P7eME1uxE4b3T5ZbDsS+hDb3rq+OUifLLZVg2mbZ2GzMvFuDuQjEzdVfp9R7X/G8ubtZf7d80+KjYjtXrHNEKutAhf5vroHF9aK7fRG7CSxnS4wXSP8OjBCW/0MHQM/U9uc6d9f5T7PE4L5J3LfWXaVA1idfdSJckdsiW2GWGX/Vvcs89+eY8qs+RViW92QbQ78iW1doIjaOr79ObK+j61tzvRyrxLb04L66fW3axBu8x50Yis2ILYx+1RHCVrRObbEtqlBO2VGa2MGXWKLk95zdJKbU9uc02bjn7Rppwf508qtcxCuQ67JHYjtvKW8E+Ts93vJfv8T6+YosRXwnyfq2QHFTe/3pLp+yvNUSbE2p/9dfHJd7G5Pugc0JosuiG2l0EzIglwt41vqALHFlaKeJQmdgStqRND3AWDLAILvGcR2hthG/F61iG+sA8QWAncAAAAQW2BavfcKAAAAAADEFgAAAAAAYgsAAAAAALEFAAAAABBbAAAAAACILQAAAAAAxBYAAAAAAGILAAAAACC2AAAAAAAQWwAAAAAAiC0AAAAAAMQWAAAAAEBsAQAAAAAgtgAAAAAAEFsAAAAAALHN/5Gvr//4h/9+NwDQ1f786d+bv6+6BwDiIwBoE9sNQUzFvQji5gf73kHNd7pJbk6qH8QW2PNt3trnAMBKsZ3awJ4iD9DBEtvYdovYElvUfU+nfpMbB/89NwBiu1RsOwJ5DfpuqfukfDP+EVtye4LY3hS4d3/zxJbgTX52ABghtidIbcY9TuzIumVsQsAXdS1iS2wn1BVi2/vOiS2xJXieGwCxPTaInSq1xJbYEtuedoHYEltiS2wtRya3AIhtW6Bz4jshtsT2BrGdVi9PlKxPypHYEltiu28iwHMDILaLlyFH3ffkBvx2sa0UZGJLbIktsSW2O8T21L5x42oxAHgstmbs+q79yTV13nNmWYktsSW2xJbYEtuT+k1CD4DYLm6ousXpybV03rvENru8iC2xJbbzxXbSN09siS2xJbYAsT20oapO0vL2KBmd94zjeYgtsSW2u8U2sq4S2x1i+7e/I7bEFgCxXd9QTZPazceOEFtiS2w/ryuR70xgSmyJ7ffXI7bEFgCxPb6hqpKmrtHqLpmJHlWfIDsbxPaEmcisGcKTxTbjGhPf/Saxtce2rw/c2GYQW98RAGKb1ilXSu0Gsa0Sz6lSuyV51O1iuyngzx6EIrbE9kax3ToYRmx9RwCIbZtcdWVW7hDbDvEktsSW2BLbzq0HxHaf2D65BrEltgCI7ZENVXSW3a4AITLI7RTP7GBrgiwT253vITN5ErEltsQ29pshOOfHgsodILbjG4CpDVV3xuYqyZuS0IrYEttbxLbz3O4N+5uJLbGNKm+I5QAQ2+sbw4pOs+P83mnS2TVDTWyJLbEltjdmRe4uu+plxCC2AIjt+sZwwhFBHb+TORORHUBtE9vsuk9s7xTbSaJCbIltp9hWCa1lt8QWALEd2xhWBInTgryn5T0lWJgQoBFbYlshtt0DSBnfZfR+SWJLbCtlj9gSWwDEdmRjmNnZbui8KmZgJkjt7WI7KcCYkuW8azk/sZ0ntpFlTGzrxbZa8ogtsQVAbMc1hlWZFid3YBOyTVZ1ysS2P8CYdHzXCWI7LSgntucljzpVbCe/E2JLbAEUie0pjffb69wutk/fQaYgTxfbqQFLZUDUHZBtE9uOoG/qAA2xJbZT3huxJbYAiO3afXab31N2EFu5H3NakEZsa989sa0J+IgtsT1VbLe8k6l1xtm1AIjt8hnbySIzQWzfvMvtAcltYjshKNoYkD6VrK7AjNg+fycnBueniO2md0JsiS0AYlsmZCfN2lYloToxIDlBbLclXCG2u44niWxzNmRFFpx//s6zy22j7BNb3w4AYlsmZB3v6u39V8zObBPbTXI/8Qikjrpxi9iecjwJsc39RontuasaJt4bsQVAbJc0WhGzdBuDh+kBdOb7ul1spw8gnRKYmbG9Q2w7VjoQ2573QmyJLQBiu372anMAUfnM0zueqsyzJxyb1Tnj8qe/vUVsTxh0Iba5A0/Edua+Y2JLbAEQ29GJdLYGEFs7we2BwPROdXIW8p/IwvpGuPh8ZGL7a1x/ZI9tzdF8xJbYEluA2K6faYq8/sZgeUoHvaHDmXD8y3axzQjeiW29HBDbmTkStn4DVXX3JHkktsQWALFNE7JtwfK0DvrGGdvbZmufSNlP39OpgUmVDGaIdNezdB73k9UXEVtie5LYTorliC1AbIntjZVh8OjuBqGrlMbupcGRGWI/qXsT939X7bGN+laJ7Vlie0r/QmyJLbEFQGyXzfhtPu6o+31sEtsN5V+VIKfqWsSW2HaK7dvrnr6E8laxvfUcW2ILgNgS26PEdvJemM7zK0/a0/dW8j+te9uPvYmUoQopnCi2G5f3R9fJlcEGsSW2xBbAZLG9ISsysZ0nDcS2Pwvrd9d6UqeiZsOJbe6AxoTkUdsGXEFsiS2xBUBsxx33Q2zndPRTxXZD+Wde86m0RS7zvkVss8Tw5GXY1cIDYktsiS0AYjv6HNuJsyETxLZaCG8NRrLF9o0wVchqVN0gtvPrYXaQ6qiSe8V28iApsSW2AIhtedIjYhsjtW+usSkYyRC5J+WWJbZvvp8qKeqcsYkcQCO2xJbYxvd3xJbYAiC2xPZyse3e+1kZfEXVlajzX6OlsGqQ4+17nxDwR9XP6kCf2BJbYrt7SwOxJbYAiO0IsZ0YLGTKRdXs72SxffP/syR0u9h2ym3lgNK075bYEttbxHZzXg1iS2wBYktsxwVdk8U2uzymZkv+9O/eikyl2FbU/8rsuNOPiOoS2ykBIbEltieI7d9+Y5LgVZYnsQVAbIntCrGtKoeNo9DVs7WTxHbasS/TzmDOENttszIR1yW2u4LyyGfZJLaZdTJLqoktgKvF9pRR4MhrmrGdkeSpswOs2EcaLYWZ95r53Ww+Y5jYzhfbCX+3MSjPare3iG33fU3YkkFsARBbYrtGbCNkJitI2hjId5zrWjGzTGzfi23nUmxie5bYdueluEFsK7bhPPn7W8X2pOX8AIhtSgM76Z11Z4mctr9xWmedMWgQHWS/vd+KhGFRf7t1xjb7dyqfubOuENuvcjncKrZdfVTmAGF3okViC4DYEtvxHf2EbLSdnXV0najOLltxz11imx2IE9t4sa0MqIltjnjdJraRz5r9t92JFifFcsQWILbHi+2k2YQtYvvPv60u78r3+ekzZy5Bjgiyu2S86u+rA/NpYjvtuYntXrGdkAirMut+h9S+ubfbjvu5MbM4AGJLbAtHsKvqxIR9Q1nnrE5ZDp5xNm72d9MdoGfUudPEtkJuiO27ek9se4+lqxTbSQmZiC2AdrE98TiESUHXNrGtHtDoGijJWpo7KWFZ9bL0aWJb+X1kie3G9ry6nSK2sTOJN4ltVhzSVU63ii0AYktsLxXbG+pB1cxYZDlOGo3vHlTZdLzFp+X3tq7fMFtLbGfJ3MTyr1ouvHEfNLEFQGwPEtsNHX/38xPbd9leM4LXqcexdARJmYHKFrGd+MzR3xCx3dO/TZLSjsGhjYPVG8Q2or0AQGyJLbEltsFimzl70CU03aP/1VI7QWynynzGN0Rse1ZFZEvhlD5qstRWZGzuWJ1WLbYAiO31YrtVDolt3VLkTcfkTBLNziBkQ/KoqUIfHbBmlcHpbVvG9ojourpZbKclbstu406fsQVAbAkNsVUPXgYxHe+b2BLbznKpPmuX2NaLbaa4bJyxrbjvzHauq83OFlsAxJbQENurxDYzkH5a34htTVBCbOPLpWN2i9jWiG3WNzahn5rwPXSdPzu5rSGnAIhtw7IaYnuP2D4NAiv3HBJbYttZLlOWFxLbfmE4QWy/+/2q+84qi+ltDbEFkC62Ix5g2BESxPZ8sa0QqMzZK2IbX/dPnEGJKpcJSXpuFtspwrChr3r6+5X3nFUexBYAsSW244VAZzBPsLqXZRLb2KAz87dP+h6yxNag3X1iO0EWq7ITV2Q+PyWWAwBi+yIAI7b3yG3X70yUrRPF9tN3XfW7pw30RO6H7RCgE8X2BHHZkB3XmatiGQDEtr0xnH4ep84gv151/8402TpVbCe2YaeJ7e/XxN4y1FedK+DEFsCxYgvcHAye+FsAgNliCwAgtgAAAACAC/k/42VQ7VWY/OwAAAAASUVORK5CYII="
}

	 */
	/**
	 * ������м�¼
	 * @author ljp
	 *
	 */
	static class Record{
		java.time.Instant time;
		long expireTime;
		String phone;
		JsonObject result;
	}
	/** �û��г��𻺴� */
	protected Map<String, Record> cacheMap = new ConcurrentHashMap<>();
	public Record getTravelRecord(String mdn) {
		Record record = null;
		record = cacheMap.get(mdn);
		if(record==null) {
			String v = mdn;
			if(mdn.indexOf("+86")<0) v = "+86" + v;
			record = cacheMap.get(v);
		}
		return record;
	}
	
	protected void refresh() {
		final long keyTime = System.currentTimeMillis();
		Iterator<Entry<String, Record>> it = cacheMap.entrySet().iterator();
		while (it.hasNext()) {
			Entry<String, Record> entry = it.next();
			if(entry.getValue()==null || entry.getValue().expireTime < keyTime) {
				log.debug("Removing trval record for " + entry.getValue().phone);
				it.remove();
			}
		}
	}
	
	BotManager botManager;
	private transient ScheduledFuture<?> sf;
	@Inject
	protected void setBotManager(BotManager botManager){
		this.botManager = botManager;
		if(botManager!=null && botManager.getExecutor()!=null) {
			if(sf!=null) sf.cancel(true);
			sf = botManager.getExecutor().scheduleWithFixedDelay(this::refresh, 1000, 15000, TimeUnit.MILLISECONDS);
		}
	}
	
	/**
	 * ������֤��
	 * @param phone
	 * @return
	 */
	public boolean sendVerifyCode(String phone) throws java.lang.IllegalAccessError{
		//{"p090983d":"18611778841","s324234m":"2021-08-05 21:03:58","s234234s":"88715420b3e54a5c3016be852c939e69","q435434f":"125d59005fc4e492599f2cdfd3c0ac57"}
		//curl -v  -H "origin: https://xc.caict.ac.cn" -H "Content-Type: application/json" "https://xcweb.caict.ac.cn:8088/dYvFMYL8/h8A2xuUsHKoMz" --data-binary "@${tmpFile}"
		
		JsonObject jo = new JsonObject();
		jo.addProperty("p090983d", phone);
		String noncestr = mkNonce();
		nonceMap.put(phone, noncestr);
		jo.addProperty("q435434f", noncestr);
		
		String time = FMT_LOCAL_DATE_TIME.format(java.time.Instant.now().atZone(ZoneId.systemDefault()));
		jo.addProperty("s324234m", time);
		String md5sum = Md5Encrypt("MOFXTCJq8bOhlSi" + time);
		jo.addProperty("s234234s", md5sum);;
		
		Map<String,Object> headers = new HashMap<>();
		headers.put("origin", "https://xc.caict.ac.cn");
		headers.put("Content-Type", "application/json");
		String body = jo.toString();
		try {
			String rsp = BotUtil.doHttp("https://xcweb.caict.ac.cn:8088/dYvFMYL8/h8A2xuUsHKoMz", body, headers);
			//{"status":"1","code":"00","errorDesc":"����ɹ�","result":"���ŷ�����,��ע�����","queryId":"125d59005fc4e492599f2cdfd3c0ac57"}
			jo = JsonParser.parseString(rsp).getAsJsonObject();
			if(!"00".equals(Util.getElementAsString(jo, "code"))){
				//{"status":"2","code":"32","errorDesc":"������֤��������Ч����","result":null,"queryId":"b64dfaf3d6ec26103073006677d60ef4"}
				String errorDesc = Util.getElementAsString(jo, "errorDesc");
				throw new IllegalAccessError(errorDesc);
			}
			return true;
		}catch(Exception e) {
			log.warn("call travel record verify error",e);
		}
		return false;
	}
	/** ����� ����*/
	protected Map<String, String> nonceMap = new ConcurrentHashMap<>();
	String mkNonce() {
		return Util.getRandomString(32);
	}

	/**
	 * ��ȡ�г���
	 * @param phone
	 * @return
	 */
	public boolean getTravelRecord(String phone, String smsCode) throws java.lang.IllegalAccessError{
		//vcode=$(echo -n "OcpqZSOIZOxr0${phone}"|md5sum|tr -d " -")
		//echo "{\"c098465\":\"\",\"p234324\":\"${phone}\",\"q363209\":\"${uuid}\",\"s456hr8\":\"${vcode}\",\"y892342\":\"${sms}\"}" > ${tmpFile}
		//curl -v  -H "origin: https://xc.caict.ac.cn" -H "Content-Type: application/json" "https://xcweb.caict.ac.cn:8088/PMfdZtmQM6PIu/jKDFMlURRsN6D9" --data-binary "@${tmpFile}"
		
		JsonObject jo = new JsonObject();
		jo.addProperty("c098465", "");
		jo.addProperty("p234324", phone);
		String noncestr = nonceMap.get(phone);
		jo.addProperty("q363209", noncestr);
		String md5sum = Md5Encrypt("OcpqZSOIZOxr0" + phone);
		jo.addProperty("s456hr8", md5sum);
		jo.addProperty("y892342", smsCode);
		
		Map<String,Object> headers = new HashMap<>();
		headers.put("origin", "https://xc.caict.ac.cn");
		headers.put("Content-Type", "application/json");
		String body = jo.toString();
		try {
			String rsp = BotUtil.doHttp("https://xcweb.caict.ac.cn:8088/PMfdZtmQM6PIu/jKDFMlURRsN6D9", body, headers);
			//{"status":"1","code":"00","errorDesc":"����ɹ�","result":{"color":"green","phone":"186****8841","time":"2021.08.05 21:05:08","message":"XXXXXXXX
			jo = JsonParser.parseString(rsp).getAsJsonObject();
			if(!"00".equals(Util.getElementAsString(jo, "code"))){
				//{"status":"2","code":"32","errorDesc":"������֤��������Ч����","result":null,"queryId":"b64dfaf3d6ec26103073006677d60ef4"}
				String errorDesc = Util.getElementAsString(jo, "errorDesc");
				throw new IllegalAccessError(errorDesc);
			}
			JsonElement je = jo.get("result");
			Record record = new Record();
			record.phone = phone;
			record.time = java.time.Instant.now();
			record.result = je.getAsJsonObject();
			LocalDate localDate = record.time.atZone(ZoneId.systemDefault()).toLocalDate();
			ZonedDateTime expire = localDate.atStartOfDay(ZoneId.systemDefault()).plusDays(1);
			record.expireTime = expire.toEpochSecond();
			this.cacheMap.put(phone, record);
			return true;
		}catch(Exception e) {
			log.warn("call travel record verify error",e);
		}
		return false;
	}
	/** ʱ���ʽ������ */
	private static final DateTimeFormatter FMT_LOCAL_DATE_TIME;
    static {
    	FMT_LOCAL_DATE_TIME = new DateTimeFormatterBuilder()
                .parseCaseInsensitive()
                .append(DateTimeFormatter.ISO_LOCAL_DATE)
                .appendLiteral(' ')
                .appendValue(ChronoField.HOUR_OF_DAY, 2)
                .appendLiteral(':')
                .appendValue(ChronoField.MINUTE_OF_HOUR, 2)
                .optionalStart()
                .appendLiteral(':')
                .appendValue(ChronoField.SECOND_OF_MINUTE, 2)
                .toFormatter();
    }
    

	public static String Md5Encrypt(String strSrc){
		java.security.MessageDigest msgDigest = null;
		try{
		    //md5 
		    msgDigest = org.apache.commons.codec.digest.DigestUtils.getMd5Digest();
		}catch(Exception e){
			throw new RuntimeException("MD5 unsuport", e);
		}

	    msgDigest.update(strSrc.getBytes());
	    byte[] buff = msgDigest.digest();
	    String string = org.apache.commons.codec.binary.Hex.encodeHexString(buff);
	    return string;
	}	

	
}
