package org.ydzy.csp.openapi;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.inject.Inject;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.ydzy.handler.BaseHandler;
import org.ydzy.handler.BaseRcsContext;
import org.ydzy.handler.RcsSession;
import org.ydzy.publish.ConstantTopics;
import org.ydzy.publish.IPublisher;
import org.ydzy.publish.SubscribeCaches;
import org.ydzy.publish.SubscribePublish;
import org.ydzy.rcs.BodyTransform;
import org.ydzy.rcs.action.RcsLogAction;
import org.ydzy.rcs.action.RcsRunLogAction;
import org.ydzy.rcs.db.XmlSqlGenerator;
import org.ydzy.rcs.entity.ReceiveEntity;
import org.ydzy.thirdparty.util.MsgUtils;
import org.ydzy.util.SqlUtil;
import org.ydzy.util.StreamsUtil;
import org.ydzy.util.Util;

import java.io.IOException;
import java.nio.charset.Charset;
import java.sql.SQLException;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;


public class ReceiveEventMsg extends BaseHandler {
    private static final long serialVersionUID = 1L;
    private static final Logger log = LoggerFactory.getLogger(ReceiveEventMsg.class);
    @Inject
    protected MsgUtils msgUtil;
    private volatile Map<String, JsonObject> eventTmplateCache = new ConcurrentHashMap<>();

    @Override
    public void handle(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        BaseRcsContext context = getContextProvidor().newBaseRcsContext();
        String ipAddress = getIpAddress(request);
        String body = StreamsUtil.copyToString(request.getInputStream(), Charset.forName("UTF-8"));
        JsonElement jsonElement = JsonParser.parseString(body);
        JsonObject bodyJson = null;
        if (jsonElement != null && !jsonElement.isJsonNull() && jsonElement.isJsonObject()) {
            bodyJson = jsonElement.getAsJsonObject();
        }

        String chatbotId = Util.getElementAsString(bodyJson, "chatbotId");
        String eventType = Util.getElementAsString(bodyJson, "eventType");
        int version = Integer.valueOf(Util.getElementAsString(bodyJson, "version"));
        JsonObject eventTemplateRelation = getEventTemplateRelation(chatbotId, eventType, version);
        if (eventTemplateRelation == null || eventTemplateRelation.isJsonNull() || eventTemplateRelation.size() == 0) {
            log.error("msg template is not defined for chatbotId��{} eventType:{} version:{}", chatbotId, eventType, version);
            String resBody = resBody("500", "message template is not defined.", null);
            sendResponse(ipAddress, resBody, 200, request, response);
            return;
        }

        String templateId = Util.getElementAsString(eventTemplateRelation, "templateId");
        String relationId = Util.getElementAsString(eventTemplateRelation, "relationId");
        String phone = Util.getElementAsString(bodyJson, "tel");
        chatbotId = context.getConfig().enterpriseProperty(chatbotId, "chatbotIdenty");

        //insert log record
        saveLog(relationId, templateId, bodyJson);
        //send msg
        sendMsg(templateId, chatbotId, phone, chatbotId, bodyJson.get("datas"));
        String resBody = resBody("200", "�ɹ�", null);
        sendResponse(ipAddress, resBody, 200, request, response);
    }

    /**
     * @param msgConfigId   ��Ϣģ��configId
     * @param chatbotIdenty �����Ψһ��ʶ
     * @param dest          ��Ϣ������
     * @param sender        ��Ϣ������
     * @param msgParams     ��Ϣ����
     */
    public void sendMsg(String msgConfigId, String chatbotIdenty, String dest, String sender, JsonElement msgParams) {
        Map<String, Object> contextObject = new HashMap<>();
        contextObject.put(ConstantTopics.CHATBOT_THIRDPART_API_TEMPLATE_DATA, msgParams);
        msgUtil.sendHint(msgConfigId, chatbotIdenty, dest, sender, false, contextObject);
    }

    /**
     * @param chatbotId �����ID
     * @param eventType �¼�����
     * @param version   �汾��
     * @return �¼���������Ϣģ���ϵ����
     */
    private JsonObject getEventTemplateRelation(String chatbotId, String eventType, int version) {
        // get from cache
        String key = chatbotId + eventType + version;
        JsonObject jsonObject = eventTmplateCache.get(key);
        if (jsonObject != null) {
            return jsonObject;
        }
        // get from db
        JsonObject dbParam = new JsonObject();
        dbParam.addProperty("chatbotId", chatbotId);
        dbParam.addProperty("eventType", eventType);
        dbParam.addProperty("version", version);
        String sql = XmlSqlGenerator.getSqlByJson("queryEventMsgTemplateByEventAndChatbotId", null, dbParam);
        try {
            JsonArray array = SqlUtil.queryForJson(ds, sql);
            if (array != null && !array.isJsonNull() && array.isJsonArray() && array.size() > 0) {
                JsonObject eventTemp = array.get(0).getAsJsonObject();
                eventTmplateCache.put(key, eventTemp);
                return eventTemp;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * ��¼��Ϣģ��Ĳ�������
     *
     * @param relationId �¼�-��Ϣģ�������ϵId
     * @param templateId ��Ϣģ��Id
     * @param data       ��Ϣ����
     */
    private void saveLog(String relationId, String templateId, JsonElement data) {
        JsonObject dbParam = new JsonObject();
        dbParam.addProperty("relationId", Util.isNull(relationId) ? 0 : Integer.valueOf(relationId));
        dbParam.addProperty("templateId", templateId);
        dbParam.add("data", data);
        String sql = XmlSqlGenerator.getSqlByJson("inserEventMsgRecordLog", null, dbParam);
        try {
            SqlUtil.updateRecords(ds, sql);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}
