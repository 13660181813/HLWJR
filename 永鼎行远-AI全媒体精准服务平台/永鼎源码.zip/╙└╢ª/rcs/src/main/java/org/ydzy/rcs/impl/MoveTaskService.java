package org.ydzy.rcs.impl;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.annotations.SerializedName;
import com.google.inject.Inject;
import com.google.inject.Singleton;
import com.google.inject.name.Named;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.ydzy.handler.BaseHandler;
import org.ydzy.handler.BaseRcsContext;
import org.ydzy.rcs.action.MoveConfigAction;
import org.ydzy.rcs.annotation.Description;
import org.ydzy.rcs.db.XmlSqlGenerator;
import org.ydzy.util.SqlUtil;
import org.ydzy.util.Util;

import javax.sql.DataSource;
import java.sql.SQLException;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicIntegerArray;

/**
 * @author jyp
 */
@Singleton
@Description("taskService")
public class MoveTaskService {
    private static final Logger log = LoggerFactory.getLogger(MoveTaskService.class);
    private final Map<String,Integer> jobType = new HashMap<>(){{
        put("card",1);
        put("bottom_menu",1);
        put("material",1);
        put("channel",1);
    }};

    private static final String PROCESS = "process";

    private final Gson gson = new Gson();

    // �̳߳�
    private final ThreadPoolExecutor exec = new ThreadPoolExecutor(3,10,10, TimeUnit.SECONDS,new LinkedBlockingQueue<>(1000));
    // �����̳߳�
    private final ThreadPoolExecutor retryExec = new ThreadPoolExecutor(1,10,10, TimeUnit.SECONDS,new LinkedBlockingQueue<>(1000));
    // ��chatbotId��Ϊkey
    public static final ConcurrentHashMap<String, List<Task>> taskMap = new ConcurrentHashMap<>();


    @Inject
    @Named("rcsDb")
    private DataSource ds;

    public JsonObject doMoveConfigAction(JsonObject object) {
        Task task = doDepartTask(object);
        return (JsonObject) gson.toJsonTree(task);
    }

    /**
     * ��ѯǨ������ĵ�ǰ����
     * @Param chatbotId
     * @Param rootTaskId
     * @return
     */
    public JsonObject getCurrentMoveProcess(String chatbotId, String rootTaskId) {
        // ��ѯtaskLog����taskLog��û�����ѯ���ݿ����Ƿ��д˼�¼
        JsonObject respBody = new JsonObject();
        if(!Util.isNull(chatbotId) && taskMap.containsKey(chatbotId)) {
            List<Task> list = taskMap.get(chatbotId);
            JsonArray array = new JsonArray();
            for (Task task : list) {
                JsonObject t = new JsonObject();
                t.addProperty("taskName",task.taskName);
                t.addProperty("state",task.state);
                t.addProperty("result",task.taskResult);
                t.addProperty("fromChatbotName",task.originName);
                t.addProperty("toChatbotName",task.targetName);
                array.add(t);
            }
            respBody.add("tasks", array);
            return respBody;
        }
        // ��ѯ���ݿ�
        JsonObject object = new JsonObject();
        object.addProperty("rootTaskId",rootTaskId);
        object.addProperty("originChatbotId",chatbotId);
        JsonArray moveTask = queryMoveTask(object);
        if(moveTask.size() == 0) {
            respBody.addProperty("data", "you queryed a mission does not exist");
            return respBody;
        }
        respBody.add("tasks", moveTask);
        return respBody;
    }

    /**
     * ��ѯǨ���������ʷ��¼
     * ��ѡ����㼶����level��Ĭ��Ϊ0��levelΪ1�򷵻�root->1��������¼
     * @param reqBody
     * @return
     */
    public JsonArray getMoveTaskHist(JsonObject reqBody) {
        // 1����ȡuser_id�����и��ڵ�
        JsonObject query1 = new JsonObject();
        query1.addProperty("user_id", Util.getElementAsString(reqBody, "user_id"));
        query1.addProperty("parentTaskId", 0);
        // ����ǲ�ѯ��ǰ����ִ�е�����
        String states = Util.getElementAsString(reqBody, "state");
        if(!Util.isNull(states)) {
            query1.addProperty("state",states);
            return queryMoveTask(query1);
        }
        JsonArray root = queryMoveTask(query1);
        // 2��ͨ�����ڵ��ø��ڵ��µĽڵ�
        JsonArray roots = queryTaskTree(query1);
        Map<String, taskNode> map = new HashMap<>();
        roots.forEach(e->{
            // TODO
            String key = Util.getElementAsString(e.getAsJsonObject(),"taskId");
            map.put(key,new taskNode(new ArrayList<>(),0,e.getAsJsonObject()));
        });
        for(Map.Entry<String,taskNode> e : map.entrySet()) {
            JsonObject body = e.getValue().body;
            String  parentTaskId = Util.getElementAsString(body, "parentTaskId");
            if(!parentTaskId.equals("0")) { // ��Ϊ���ڵ�����
                taskNode parent = map.get(parentTaskId);
                parent.sons.add(e.getValue());
            }
        }
        // TODO ��������ȼ�
        int levelThreshold = Util.getElementAsInt(reqBody, "level", 0);
        JsonArray array = new JsonArray();
        // ��������JSON
        root.forEach(e->{
            int level = 0;
            String index = Util.getElementAsString(e.getAsJsonObject(), "taskId");
            taskNode node = map.get(index);
            taskNode json = generateTree(node, 0, levelThreshold);
            array.add(gson.toJsonTree(json));
        });
        return array;
    }

    /**
     * ����һ����ȵ���������˳�������ȼ���ֵ
     * @param root
     * @param level
     * @param levelThreshold
     * @return
     */
    private taskNode generateTree(taskNode root, int level, int levelThreshold) {
        if(level > levelThreshold || root == null) {
            return null;
        }
        root.level = level;
        for (taskNode son : root.sons) {
            taskNode node = generateTree(son, level + 1, levelThreshold);
            if(node == null)
                root.sons = null;
        }
        return root;
    }

    private JsonArray queryMoveTask(JsonObject object) {
        String queryId = "queryMoveTask";
        String sql = XmlSqlGenerator.getSqlByJson(queryId, null, object);
        JsonArray jsonArray = null;
        try {
            jsonArray = SqlUtil.queryForJson(ds, sql);
        }catch (Exception e) {
        }
        return jsonArray;
    }

    private JsonArray queryTaskTree(JsonObject object) {
        String queryId = "queryMoveTaskTree";
        String sql = XmlSqlGenerator.getSqlByJson(queryId, null, object);
        JsonArray jsonArray = null;
        try {
            jsonArray = SqlUtil.queryForJson(ds, sql);
        }catch (Exception e) {
        }
        return jsonArray;
    }

    /**
     * ��ʷ��¼�ڵ�
     */
    static class taskNode {
        List<taskNode> sons;
        int level;
        JsonObject body;

        public taskNode() {
        }

        public taskNode(List<taskNode> sons, int level, JsonObject body) {
            this.sons = sons;
            this.level = level;
            this.body = body;
        }
    }

    /**
     * ���ƻ����������
     * @param object
     * @return
     */
    private Task doDepartTask(JsonObject object){
        JsonObject body = object; //req������
        String from = Util.getElementAsString(body, "fromChatbotid");
        taskMap.put(from, new ArrayList<>());
        Random random = new Random();
        int r = random.nextInt(10000);
        long date = new Date().getTime();
        Task task = Task.getTask(body, 1);
        task.taskId = "" + date + (r++);
        task.rootTaskId = task.taskId;
        task.reqData = body.toString();

        List<Task> list = new ArrayList<>();

        Task msg = Task.getTask(body, 0);
        msg.taskId = "" + date + (r++);
        StringBuilder sb = new StringBuilder();
        JsonArray configs = object.getAsJsonArray("configs");
        String configMoveQueryId = "oneKeyCopy_all_configinfo";
        if (configs != null && configs.size() > 0) {
            configMoveQueryId = "oneKeyCopy_configinfo";
            object.add("configid", configs);
            msg.reqData = configs.toString();
        }else {
            msg.reqData = "{\"isAll\":\"y\"}";
        }
        sb.append(XmlSqlGenerator.getSqlByJson(configMoveQueryId, null, object));
        msg.mission = sb.toString();
        msg.rootTaskId = msg.parentTaskId = task.taskId;
        list.add(msg);

        JsonArray partdatas = body.getAsJsonArray("partdata");
        for (JsonElement ele : partdatas) {
            JsonObject part = ele.getAsJsonObject();
            String value = Util.getElementAsString(part, "value");
            String params = Util.getElementAsString(part, "params");
            if (value.equals("1")) {
                String sqlid = "oneKeyCopy_all_" + params;
                Task task1 = Task.getTask(body, 0);
                task1.taskId = "" + date + (r++);
                task1.rootTaskId = task1.parentTaskId = task.taskId;
                task1.reqData = sqlid;
                task1.mission = XmlSqlGenerator.getSqlByJson(sqlid, null, object);
                if(task1.preconditions == null)
                    task1.preconditions = new ArrayList<>();
                task1.preconditions.add(msg);
                list.add(task1);
            }
        }

        // �����β����
        Task clear = Task.getTask(body, 0);
        clear.taskId = "" + date + r;
        clear.rootTaskId = clear.parentTaskId = task.taskId;
        clear.mission = XmlSqlGenerator.getSqlByJson("clear_all_copymsgid", null, object);
        clear.taskName = clear.reqData =  "clear_all_copymsgid";
        if(clear.preconditions == null)
            clear.preconditions = new ArrayList<>();
        clear.preconditions.addAll(list);
        list.add(clear);
        // ������������
        task.preconditions.add(clear);
        list.add(task);


        try {
            JsonArray array = new JsonArray();
            list.forEach(e -> {
                array.add(gson.toJsonTree(e));
            });
            String queryId = "insertMoveTask";
            StringBuilder sqlBuilder = new StringBuilder();
            for (JsonElement jsonElement : array) {
                sqlBuilder.append(XmlSqlGenerator.getSqlByJson(queryId,null,jsonElement.getAsJsonObject()));
            }
            SqlUtil.updateRecords(ds, sqlBuilder.toString());
        }catch (SQLException e) {
            e.printStackTrace();
        }

        for (Task task1 : list) {
            taskMap.get(from).add(task1);
        }
        toExecuteTask(list);
        return task;
    }

    private void toExecuteTask(List<Task> tasks) {
        for (Task task : tasks) {
            ExecuteTask executeTask = new ExecuteTask(task, ds, this);
            exec.submit(executeTask);
        }
    }

    // TODO: 2022/3/3   ������ɹ���ʧ��֮�����map�����¼�����Դ
    public void reload(JsonObject object, BaseRcsContext baseRcsContext) {
        String rootTaskId = Util.getElementAsString(object, "rootTaskId");
        String chatbotId = Util.getElementAsString(object, "originChatbotId");
        List<Task> list = taskMap.get(chatbotId);
        for (Task task : list) {
            if(task.taskId.equals(rootTaskId)){
                new Thread(()->{
                    try {
                        task.myCondition.await();
                        taskMap.remove(chatbotId);
                        log.info("resource is reloading.........");
                        baseRcsContext.getConfig().reload();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }).start();
                break;
            }
        }

    }


    static class ExecuteTask implements Runnable {

        private final Task task;
        private final DataSource ds;
        private final MoveTaskService taskService;

        ExecuteTask(Task task, DataSource ds, MoveTaskService taskService) {
            this.task = task;
            this.ds = ds;
            this.taskService = taskService;
        }

        @Override
        public void run() {
            try {
                for (Task precondition : task.preconditions) {
                    precondition.myCondition.await();
                }
                if(task.abort == 1) { // ��������
                    log.info("{} will be aborted", task.mission);
                    updateTask(task,3, null);
                    return;
                }
                log.info("{} will be executed", task.mission);
//                if(new Random().nextInt(10) < 9) {
//                    int i = 1 / 0;
//                }
                String sql = task.mission;
                updateTask(task,0, null);
                SqlUtil.updateRecords(ds,sql);
                updateTask(task,1, null);
                task.myCondition.countDown();
                log.info("{}'s lock is released", task.taskName);
            } catch (Exception e) {
                // ����
                if(task.retry > 5) {
                    task.retry--;
                    updateTask(task, 2, e.toString());
                    ExecuteTask executeTask = new ExecuteTask(task, ds, taskService);
                    taskService.retryExec.submit(executeTask);
                }else {
                    String err = e.toString().replaceAll("'","");
                    updateTask(task, 2, err);
                    // TODO: 2022/3/3  ʣ��������ִ�в��ͷ���
                    List<Task> list = taskMap.get(task.originChatbotId);
                    for (Task task : list) {
                        if (task.preconditions.contains(this.task)) {
                            task.abort = 1;
                        }
                    }
                    taskMap.remove(task.originChatbotId);
                    task.myCondition.countDown();
                }
                e.printStackTrace();
            }

        }

        public void updateTask(Task task, int state, String logInfo) {
            try {
                String sqlId = "updateMoveTask";
                task.state = state;
                if(state == 1) {
                    task.taskResult = "���";
                } else if(state == 2) {
//                    task.myCondition.countDown();
                    task.taskResult = "ʧ��";
                    // ����ʧ����־
                    JsonObject taskFailLog = new JsonObject();
                    taskFailLog.addProperty("chatbotId", task.originChatbotId);
                    taskFailLog.addProperty("taskId",task.taskId);
                    taskFailLog.addProperty("logInfo",logInfo);
                    String queryId1 = "insertMoveTaskLog";
                    String sql1 = XmlSqlGenerator.getSqlByJson(queryId1, null, taskFailLog);
                    SqlUtil.updateRecords(ds,sql1);
                    // ���������״̬
                    taskFailLog.addProperty("state", 2);
                    taskFailLog.addProperty("taskId", task.rootTaskId);
                    taskFailLog.addProperty("originChatbotId", task.originChatbotId);
                    sql1 = XmlSqlGenerator.getSqlByJson(sqlId, null, taskFailLog);
                    SqlUtil.updateRecords(ds,sql1);
                }else if(state == 3) {
                    task.taskResult = "ǰ������ʧ�ܣ�������ֹ";
                }
                String sql = XmlSqlGenerator.getSqlByJson(sqlId, null, (JsonObject) new Gson().toJsonTree(task));
                SqlUtil.updateRecords(ds, sql);
            }catch (Exception e) {
            }
        }
    }

    static class Task {
        private transient int isSplit; // �Ƿ���Ҫ��� 1��Ҫ��0����Ҫ
        private String taskName; // �������ƣ�Ӧ����������ʶ�Ƿ���
        private transient List<Task> preconditions; // ǰ������
        private transient CountDownLatch myCondition; //�Լ�ӵ�е�countDownLatch
        private transient String mission; // ��Ҫִ�е�����Sql
        @SerializedName("handler")
        private String access; // ������ڻ��߲�����
        // ����DB����Ϣ
        private String taskId;
        private String originChatbotId;
        private String targetChatbotId;
        private String originName;
        private String targetName;
        private String parentTaskId;
        private String reqData;
        private int type;
        private String publisher;
        private int state;
        private String taskResult;
        private String rootTaskId;
        private transient int retry = 5;
        private transient int abort = 0;

        public static Task getTask(JsonObject object, int isSplit) {
            Task task = new Task(isSplit,"��������"+new Random().nextInt(10000),
                    new ArrayList<>(),new CountDownLatch(1),null,"access");
            task.originChatbotId = Util.getElementAsString(object, "fromChatbotid");
            task.targetChatbotId = Util.getElementAsString(object, "toChatbotid");
            task.type = 0;
            task.publisher = Util.getElementAsString(object,"user_id");
            task.state = -1;
            task.taskResult = "";
            task.originName = "Դ";
            task.targetName = "Ŀ��";
            task.parentTaskId = "0";
            return task;
        }

        public Task() {
        }

        public Task(int isSplit, String taskName, List<Task> preconditions, CountDownLatch myCondition, String mission, String access) {
            this.isSplit = isSplit;
            this.taskName = taskName;
            this.preconditions = preconditions;
            this.myCondition = myCondition;
            this.mission = mission;
            this.access = access;
        }
    }
}
