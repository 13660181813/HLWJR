package org.ydzy.bot;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.ydzy.rcs.media.UploadFileEntity;
import org.ydzy.util.NetUtils;

/**
 * 
 * �й��ƶ� bot�ӿ�ģ�� 
 * @author ljp
 *
 */
public class BotAccessHuawei extends BotAccessCmcc {

	public BotAccessHuawei() {
		this.authorizeName = AuthHuaweiPassword.KEY_AUTH_HUAWEI_PASSWORD;
	}

	/** 
	 * �ϴ�ý��
	 */
	@Override
	public boolean mediaUpload(final BotInfo botInfo, final UploadFileEntity fileEntity) {
		//TODO add upload
		return super.mediaUpload(botInfo, fileEntity);
	}

//	@Override
//	public boolean mediaDelete(BotInfo botInfo, UploadFileEntity media) {
//		throw new SpecialException("No implements");
//	}

	@Override
	public void mediaDownload(BotInfo botInfo, String mediaUrl,String outputfile) {
		Map<String, Object> headers= new HashMap<>();
		headers.put("Content-Type", "application/json");
		headers.put("File-Location", mediaUrl);
		String url = BotUtil.mustache(getFileServerRoot(), this, botInfo, botInfo.getInfos());
		headers.put("User-Agent", "SP/"+botInfo.getChatbotIdenty());
		url = authorize.attach(url, headers, botInfo);
		try {
			 NetUtils.doHttpsWriteFiles(url, null, headers, "",outputfile);
		} catch (IOException e) {
			log.info("Download chatbot media file error(" + e.getMessage() + ")");
		}
		
	}
		

}
