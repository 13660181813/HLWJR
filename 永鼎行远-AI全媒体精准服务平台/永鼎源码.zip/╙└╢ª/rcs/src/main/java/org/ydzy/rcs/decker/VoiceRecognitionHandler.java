package org.ydzy.rcs.decker;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.SequenceInputStream;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.ydzy.rcs.BodyTransform;
import org.ydzy.rcs.annotation.Description;
import org.ydzy.rcs.entity.ReceiveEntity;
import org.ydzy.util.Util;

import com.google.inject.Inject;
import com.google.inject.Singleton;
import com.google.inject.name.Named;
@Singleton
@Description(value = "voiceHandler")
public class VoiceRecognitionHandler implements ReceiveHandle {
	private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(VoiceRecognitionHandler.class);
	@Override
	public ReceiveEntity requestHandler(BodyTransform transform,ReceiveEntity receiveEntity) {
		try {
			return transFormAudio(receiveEntity);
		} catch (IOException e) {
		}
		return receiveEntity;
	}
	public ReceiveEntity transFormAudio(ReceiveEntity receiveEntity) throws IOException
	{
		String localhile = null;
		if(receiveEntity.getAnswersObject().containsKey("download")) {
			List<?> dinofs=null;
			dinofs =(List<?>) receiveEntity.getAnswersObject().get("download");
			if(dinofs!=null && dinofs.size()>0) {
				for(Object o:dinofs) {
					if(o instanceof Map) {
						Map<?, ?> map = (Map<?, ?>)o;
						String contentType = String.valueOf(map.get("filecontentType"));
						if(contentType.indexOf("audio")>=0) {
							localhile = String.valueOf(map.get("LocalPath"));
							break;
						}
					}
				}
			}
		}
		if(localhile!=null) {
			Runtime run = Runtime.getRuntime();
			//����ʶ�� ԭshell�������ļ��ķ�ʽ �������ã�ý�� �ļ�������ҪȨ�� 
			//���������غ󣬴��뱾���ļ��� shell�ű���Ҫ�޸�һ��
			log.info ("videoparse /home/evtquery/asr/doasr.sh  parse  {}",localhile);
			try {
				Process	process = run.exec("/home/evtquery/asr/doasr.sh "+localhile);
				shellAudio2Str(receiveEntity,process, false);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}else if(!Util.isNull(receiveEntity.getKeywords())&&receiveEntity.getKeywords().indexOf("\u003ccontent-type\u003eaudio/amr\u003c/content-type")>-1)
		{
			Runtime run = Runtime.getRuntime();

			Process process=run.exec("/home/evtquery/asr/doasr.sh");
			shellAudio2Str(receiveEntity,process, true);
			log.info ("videoparse /home/evtquery/asr/doasr.sh  parse  {}",receiveEntity.getKeywords());

		}
		return receiveEntity;
	}
	@Inject(optional = true)
	@Named("doasr.cmd")
	String doasrCmd="/home/evtquery/asr/doasr.sh";
	
	public void shellAudio2Str(ReceiveEntity receiveEntity,Process process, boolean outputContent) {
		

//		Process process=run.exec("/home/evtquery/asr/doasr.sh");
		try {
			if(outputContent) {
				DataOutputStream os = new DataOutputStream(process.getOutputStream());
				os.writeBytes(receiveEntity.getKeywords());
				os.flush();
				os.close();
			}
			SequenceInputStream sis = new SequenceInputStream(process.getInputStream(), process.getErrorStream());
            InputStreamReader in=new InputStreamReader(sis,"UTF-8");
            BufferedReader inBr=new BufferedReader(in);
            String lineStr;
        	StringBuilder sb = new StringBuilder();
            while((lineStr=inBr.readLine())!=null){
            	sb.append(lineStr);
            }
            //
            inBr.close();
            process.waitFor(10,TimeUnit.SECONDS);
            process.destroy();
			
			 if(!Util.isNull(sb.toString()))
			{
//				 requestBody.addProperty("content", sb.toString());
				 receiveEntity.setContent(sb.toString());
				 receiveEntity.setKeywords(sb.toString());
				log.info ("videoparse /home/evtquery/asr/doasr.sh  parse  {} result {} ",receiveEntity.getKeywords(),sb);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
