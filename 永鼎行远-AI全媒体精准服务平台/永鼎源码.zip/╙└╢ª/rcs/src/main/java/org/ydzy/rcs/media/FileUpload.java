package org.ydzy.rcs.media;
import static java.nio.charset.StandardCharsets.UTF_8;
 
import com.fasterxml.jackson.databind.ObjectMapper;
 
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.SequenceInputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.eclipse.jetty.http.MimeTypes;
import org.ydzy.rcs.BodyTransform;
import org.ydzy.rcs.RcsConfig;
import org.ydzy.rcs.impl.RcsConfigFromfile;
import org.ydzy.util.Util;
/**
* 5Gý���ļ��ϴ���������
*/
public final class FileUpload {
    static final int SUCCESS = 200;
    static final int ERR = 204;
    private FileUpload() {
    }
 
    /**
     * ��������
     *
    
     * @param args
     * @throws IOException
     * @throws NoSuchAlgorithmException
    
     */
    public static void main(String[] args) throws IOException, NoSuchAlgorithmException {
    	
    	
//    	Files.write(Path.of("C:\\Users\\XFDEP\\Desktop\\test.jpg"),Files.readAllBytes(Path.of("C:\\Users\\XFDEP\\Desktop\\23434343.jpg")));
    	
        File file = new File("C:\\Users\\XFDEP\\Desktop\\23434343.jpg");
        file.setFileId("12341234");
        file.setFileSize(20);
        file.setFileUrl("C:\\Users\\XFDEP\\Desktop\\23434343.jpg");
        file.setStatus("OK");
        file.setValidity("");
        file.contentType="image/jpeg";
        Map<String, Object> map = new HashMap<>();
        map.put("File",file);
        map.put("Thumbnail", file);
        post("http://121.37.229.90:80/openchatbot/v2/sip:1065051210646@botplatform.rcs.chinamobile.com/files",map);
    }
    /**
     * ����post����
     *
     
     * @param url
     * @param params
     * @Parameters: parms�����ʲ���,Map��ʽ����K-v��Ŷ���ֵ��
     * @return null
     * @throws IOException
     * @throws NoSuchAlgorithmException
   
     */
 
    public static String post(String url, Map<String, Object> params) throws IOException, NoSuchAlgorithmException {
        Logger logger = Logger.getLogger(FileUpload.class.getName());
        logger.setLevel(Level.WARNING);
        logger.warning("url" + url);
 
        // ��ȡ��֤��Ϣauthorization������Ϣ
//        String authorization = "Username=\"appId32test1\",Password=\"123456\"";
// 
//        // ��ȡ��֤��ϢX-WSSE
//        String xwsse = "UsernameToken Username=\"appId32test1\"";
        URL url1 = new URL(url);
        InputStream is;
        RcsConfig config=new RcsConfigFromfile();
        // ��url��open�������ص�urlConnection����ǿתΪHttpURLConnection����(��ʶһ��url�����õ�Զ�̶�������),��ʱcnnectionֻ��Ϊһ�����Ӷ���,��������
        HttpURLConnection conn = (HttpURLConnection) url1.openConnection();
 
        // �������������Ϊtrue,Ĭ��false (post�����������ķ�ʽ��ʽ�Ĵ��ݲ���)
        conn.setDoOutput(true);
 
        // ��������������Ϊtrue
        conn.setDoInput(true);
 
        // ��������ʽΪpost
        conn.setRequestMethod("POST");
 
        // post���󻺴���Ϊfalse
        conn.setUseCaches(false);
 
        // ���ø�HttpURLConnectionʵ���Ƿ��Զ�ִ���ض���
        conn.setInstanceFollowRedirects(true);
 
        // �������ݵ�����,����Ϊ����urlEncoded�������from����
//        conn.setRequestProperty("Authorization", authorization);
//        conn.setRequestProperty("X-WSSE", xwsse);
//        conn.setRequestProperty("User-Agent", "SP/sip:1065051210646@botplatform.rcs.chinamobile.com");
        Map<String, Object> headers= BodyTransform.headersV2(config, config.enterpriseProperty("dccar", "key"),"dccar", "8619899445919","");
        String boundary="--------------------------"+UUID.randomUUID().toString().replace("-", "");
        conn.setRequestProperty("Content-Type", " multipart/form-data; boundary="+boundary);
//        conn.setRequestProperty("Accept", "*/*");
//        conn.setRequestProperty("Accept-Encoding", "gzip, deflate");
//        conn.setRequestProperty("Accept-Language", "zh-CN,zh;q=0.9");
        headers.forEach((k,v)->{
        	 conn.setRequestProperty(k	,Util.toString(v));
        });
//        conn.setRequestProperty("Authorization", "Username=\""+config.enterpriseProperty("dccar", "appId")+"\", Password=\""+config.enterpriseProperty("dccar", "key")+"\"");
//        ObjectMapper objectMapper = new ObjectMapper();
//        PrintWriter pw = new PrintWriter(new OutputStreamWriter(conn.getOutputStream(), UTF_8));
//        pw.write(objectMapper.writeValueAsString(params));
        OutputStream pw=new DataOutputStream(conn.getOutputStream());
        if(params!=null)
        {
        	File f=(File) params.get("File");
        	java.io.File file=new java.io.File(f.getFileUrl());
        	String filename=file.getName();
        	String contentType=f.contentType;
        	StringBuffer strBuf=new StringBuffer();
        	strBuf.append("\r\n").append("--").append(boundary).append("\r\n");
        	strBuf.append("Content-Disposition: form-data; name=\"File\"; filename=\""+filename+"\"\r\n");
        	strBuf.append("Content-Type: "+contentType+""
//        			 +"Content-Length=\""+file.length()+"\""
        			+ "\r\n\r\n");//Content-Transfer-Encoding: base64
        	pw.write(strBuf.toString().getBytes());
        	
        	pw.write((Files.readAllBytes(Path.of(f.getFileUrl()))));//Base64.getEncoder().encode
        	
//        	pw.write(("\r\n "+boundary+"--\r\n").getBytes());
        	
        	
        	File Thumbnail=(File) params.get("Thumbnail");
        	
        	StringBuffer strtBuf=new StringBuffer();
        	strtBuf.append("\r\n").append("--").append(boundary).append("\r\n");
        	strtBuf.append("Content-Disposition: form-data; name=\"Thumbnail\"; filename=\""+filename+"\"\r\n");
//        	strtBuf.append("Content-Length=\""+file.length()+"\"");
        	strtBuf.append("Content-Type: "+contentType+"\r\n\r\n");//\r\nContent-Transfer-Encoding: base64
        	pw.write(strtBuf.toString().getBytes());
        	
        	pw.write((Files.readAllBytes(Path.of(f.getFileUrl()))));//Base64.getEncoder().encode
        	
        	pw.write(("\r\n--"+boundary+"--\r\n").getBytes());
        }
        
 
        // �鿴������Ϣ
//        logger.warning(objectMapper.writeValueAsString(params));
        pw.flush();
        pw.close();
 
        // ��������(����δ��ʼ,ֱ��connection.getInputStream()��������ʱ�ŷ���,���ϸ��������������ڴ˷���֮ǰ����)
        conn.connect();
 
        // ���������Ϣ��ʵ��ʹ��ʱȥ��
        outConnInfo(conn, url1);
 
        // ���ӷ�������,������������Ӧ (�����ӻ�ȡ������������װΪbufferedReader)
        int status = conn.getResponseCode();
        logger.warning("status:" + status);
        if (status != SUCCESS) {
            logger.warning("No Content");
            if (status == ERR) {
                logger.warning("err");
                is = conn.getInputStream();
            } else { // 400/401
                is = conn.getErrorStream();
            }
        } else { // 200
            logger.warning("OK,SUCESS");
            is = conn.getInputStream();
        }
//        SequenceInputStream sis = new SequenceInputStream(conn.getInputStream(), conn.getErrorStream());
        InputStreamReader in=new InputStreamReader(is,"UTF-8");
        BufferedReader br = new BufferedReader(in);
        String line;
        StringBuilder resultMsg = new StringBuilder();
        while ((line = br.readLine()) != null) { // ��ȡ����
            resultMsg.append(line);
        }
 
        // �������������Ҫ
        is.close();
        br.close();
 
        // �ر�����
        conn.disconnect();
        logger.warning("resultMsg.toString()" + resultMsg.toString());
        return null;
    }
 
    // ���崫����ļ�,Я����Ҫ�ϴ��Ĳ���
    /**
     * ��������
     *
     
     
     */
    public static class File {
        private String fileId;
        private Integer fileSize;
        private String status;
        private String fileUrl;
        private String validity;
        private String contentType;
 
        /**
         * ��������
         *
       
         * @param s
         
         */
        public File(String s) {
        }
 
        public String getFileId() {
            return fileId;
        }
 
        public void setFileId(String fileId) {
            this.fileId = fileId;
        }
 
        public Integer getFileSize() {
            return fileSize;
        }
 
        public void setFileSize(Integer fileSize) {
            this.fileSize = fileSize;
        }
 
        public String getStatus() {
            return status;
        }
 
        public void setStatus(String status) {
            this.status = status;
        }
 
        public String getFileUrl() {
            return fileUrl;
        }
 
        public void setFileUrl(String fileUrl) {
            this.fileUrl = fileUrl;
        }
 
        public String getValidity() {
            return validity;
        }
 
        public void setValidity(String validity) {
            this.validity = validity;
        }
 
    }
    /**
     * ���������Ϣ ,ʵ��ҵ���漰
     * */
    private static void outConnInfo(HttpURLConnection conn, URL url) throws IOException {
        Logger logger = Logger.getLogger(FileUpload.class.getName());
        logger.setLevel(Level.WARNING);
        logger.warning("conn.getResponseCode():" + conn.getResponseCode());
        logger.warning("conn.getURL():" + conn.getURL());
        logger.warning("conn.getRequestMethod():" + conn.getRequestMethod());
        logger.warning("conn.getContentType():" + conn.getContentType());
        logger.warning("conn.getReadTimeout():" + conn.getReadTimeout());
        logger.warning("conn.getResponseMessage():" + conn.getResponseMessage());
        logger.warning("url.getDefaultPort():" + url.getDefaultPort());
        logger.warning("url.getFile():" + url.getFile());
        logger.warning("url.getHost():" + url.getHost());
        logger.warning("url.getPath():" + url.getPath());
        logger.warning("url.getPort():" + url.getPort());
        logger.warning("url.getProtocol():" + url.getProtocol());
    }
}
