package org.ydzy.bot.handler;
import java.io.IOException;
import java.nio.charset.Charset;
import java.sql.SQLException;
import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

import com.google.inject.Inject;
import com.google.inject.name.Named;
import org.eclipse.jetty.server.Request;
import org.ydzy.bot.BotInfo;
import org.ydzy.bot.BotUtil;
import org.ydzy.handler.BaseHandler;
import org.ydzy.rcs.db.XmlSqlGenerator;
import org.ydzy.rcs.media.UploadFileEntity;
import org.ydzy.util.SqlUtil;
import org.ydzy.util.StreamsUtil;
import org.ydzy.util.Util;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import javax.sql.DataSource;

/**
 * �й����š���ͨMAAP�ӿ�
 *  13.3��˽��֪ͨ
 *  ��http://{notifyURL}/notifyInfoNotification/{chatbotId}/check
 */
public  class CheckHandler extends BaseBotHandler {
	private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(CheckHandler.class);

	@Inject
	@Named("rcsDb")
	protected DataSource ds;

	@Override
	public void handle(String target, Request baseRequest, HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException{
		baseRequest.setHandled(true);
		BotInfo bi = null;
		try {
			bi = verifyChatbot(request, response);
		}catch(VerifyError e) { 
			response.setStatus(HttpServletResponse.SC_FORBIDDEN);
			response.setContentType("application/json");
			JsonObject jo = new JsonObject();
			jo.addProperty("errorMsg", e.getMessage());
			// Write back response
			response.getWriter().println(jo.toString());
			log.debug("Sinagure error(" + e.getMessage() + "!");
			return;
		}

		String address=BaseHandler.getIpAddress(request);
		// Content-Type: text/xml; charset=utf-8
		String contentType = request.getContentType();
		if(contentType==null)contentType="application/json";
		String body = StreamsUtil.copyToString(request.getInputStream(), Charset.forName("UTF-8"));
		if(log.isDebugEnabled())log.debug("CheckHandler uri {}  ", request.getRequestURI());
		if(log.isDebugEnabled())log.debug("receive {} from remoteAddr {}  ", body, address);
		String code = null,msg = null;
		if(contentType.indexOf("json")>0 || contentType.indexOf("text")>=0) {
			JsonElement je = JsonParser.parseString(body);
			if(je!=null && je.isJsonObject()) {
				JsonObject jo = je.getAsJsonObject();
				String type = BotUtil.getElementAsString(jo, "type");
				IHandler handler = handlers.get(type);
				if(handler!=null) {
					handler.handler(jo, bi);
				}else {
					code = "2001";
					msg = "Unkown type(" + type + ")";
				}
			}else {
				code = "2001";
				msg = "No status message found";
			}
		}else {
			code = "2002";
			msg = "Unknow contentType:" + contentType;
		}
		boolean succ = code==null;
		if(succ) {
			code = "0";
			msg = "success";
		}
		String resBody = resBodyJson(code, msg, null);
		sendResponse(address, resBody, HttpServletResponse.SC_OK, request, response);
	}
	
	Map<String, IHandler> handlers = new HashMap<>();
	public static interface IHandler{
		boolean handler(JsonObject jo, BotInfo bi);
	}
	{
		/*
				����
				{
					"type": "media",
					"result": "fail",
					"time": "2020-01-17T14:42:20.840+08:00",
					"description": "�ļ������Ϲ���",
					"remark": "url:http://124.127.121.100/temp/src/2020062217asdfkjaoskd/836ee/view/373c3504f6e4cc6c5274f0.mp4"
				}

				�����
				{
					"type": "media",
					"result": "pass",
					"time": "2020-01-17T14:42:20.840+08:00",
					"remark": "fileId: dcb7074c-09d0-4b47-a685-4985651ff134",
					"fileInfo": {
						"url": "http://124.127.121.100/temp/src/2020062217asdfkjaoskd/836ee/view/37,3c3504f6e4cc6c5274f0.jpeg",
						"fileName": "AA.jpeg",
						"contentType": "image/jpeg",
						"fileSize": 22347,
						"until": "2017-04-25T12:17:07Z"
					}
				}
		 */
		handlers.put("media", (jo, bi) ->{
			String remark = BotUtil.getElementAsString(jo, "remark");
			if(remark!=null && remark.startsWith("url:")){
				remark = remark.substring(4);
			}
			JsonObject dbparams = new JsonObject();
			UploadFileEntity media = new UploadFileEntity(null,null);
			media.setMediaUrl(remark);
			bi.getDbOper().loadMedia(media);
			if(media.getMediaID()!=null) {
				dbparams.addProperty("mediaID", media.getMediaID());
				String result = BotUtil.getElementAsString(jo, "result");
				boolean pass = !"fail".equals(result);
				
				String TagMedia = "media=";
				String TagThumb = "thumb=";
				String errCode = media.getErrorCode();
				String errDesc = media.getErrorDesc();
				String mType;
				boolean allOk = false;

				String url = null;
				String contentType = null;
				if(remark.startsWith("fileId")) {
					JsonElement je = jo.get("fileInfo");
					if(je!=null && je.isJsonObject()) {
						JsonObject fileInfo = je.getAsJsonObject();
						url = Util.getElementAsString(fileInfo, "url");
						contentType = (Util.getElementAsString(fileInfo, "contentType"));
						String until = BotUtil.getElementAsString(fileInfo, "until");
						if(until!=null&&!until.isEmpty()) {
							Instant ins = DateTimeFormatter.ISO_INSTANT.parse(until, Instant::from);
							long expiredTime = ins.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli();
							if(media.getExpiredTime()<24*3600000 || expiredTime<=media.getExpiredTime()) {
								dbparams.addProperty("expiredTime", new java.sql.Timestamp(expiredTime).toString());
							}else{
								dbparams.addProperty("expiredTime", new java.sql.Timestamp(media.getExpiredTime()).toString());
							}
						}
					}
				}

				if(remark.equals(media.getChatbotMediaUrl()))
				{
					mType = TagMedia;
					if(Util.isNull(media.getChatbotMediaUrl()) || errDesc.indexOf(TagThumb)>=0) {
						allOk = true;
					}

					if(!Util.isNull(url)){
						dbparams.addProperty("chatbotMediaUrl", url);
					}
					if(contentType!=null){
						dbparams.addProperty("mediaContentType", contentType);
					}
				}
				else
				{
					mType = TagThumb;
					if(Util.isNull(media.getChatbotThumbnailUrl()) || errDesc.indexOf(TagMedia)>=0) {
						allOk = true;
					}
					if(!Util.isNull(url)){
						dbparams.addProperty("chatbotThumbnailUrl", url);
					}
					if(contentType!=null){
						dbparams.addProperty("thumbnailContentType", contentType);
					}
				}

				if(pass) {
					dbparams.addProperty("authStatus", 0);
				}else {
					dbparams.addProperty("authStatus", 1);
				}


				String desc = BotUtil.getElementAsString(jo, "description");
				String s = mType.charAt(0) + result;
				errCode = Util.isNull(errCode) ? s : errCode +"|"+ s;
				if(!Util.isNull(errCode) && !Util.isNull(errDesc)) errDesc += "|" + mType + desc;
				dbparams.addProperty("errorCode", errCode);
				dbparams.addProperty("errorDesc", errDesc);

				if(allOk){
					dbparams.addProperty("status" , "3");
				}

				String sqlId= "updateMediasByChatBotMediaUrl";
				String sql = XmlSqlGenerator.getSqlByJson(sqlId, null, dbparams);
				try {
					SqlUtil.updateRecords(ds, sql);
				} catch (SQLException e) {
					e.printStackTrace();
				}

				if(allOk) {
					CompletableFuture<UploadFileEntity> future = manager.getMediaUploadFuture().remove(media.getMediaID());
					if(future!=null)future.complete(media);
				}
			}
			return true;
		});
		
		/*
			{
			  "type": "chatbotInformation",
			  "result": "fail",
			  "time": "2020-01-17T14:42:20.840+08:00",
			  "description": "not match rules",
			  "remark": "menu"
			}
		 */
		handlers.put("chatbotInformation", (JsonObject jo, BotInfo bi) ->{
			// TODO: 2022/1/21
			return true;
		});
		
		/*
			{
			  "type": "message",
			  "result": "fail",
			  "time": "2020-01-17T14:42:20.840+08:00",
			  "description": "�ļ������Ϲ���",
			  "remark": "messageId: cb1188a3-37ec-1037-9054-2dc66e44375b"
			}
		 */
		handlers.put("message", (JsonObject jo, BotInfo bi) ->{
			// TODO: 2022/1/21
			return true;
		});
	}
	
}