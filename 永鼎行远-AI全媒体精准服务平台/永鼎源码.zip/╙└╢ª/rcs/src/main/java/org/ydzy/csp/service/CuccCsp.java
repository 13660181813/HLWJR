package org.ydzy.csp.service;

import com.google.gson.*;
import com.google.inject.Inject;
import com.google.inject.Singleton;
import io.jsonwebtoken.Claims;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.slf4j.LoggerFactory;
import org.ydzy.handler.BaseHandler;
import org.ydzy.rcs.Provider;
import org.ydzy.rcs.annotation.Description;
import org.ydzy.rcs.db.XmlSqlGenerator;
import org.ydzy.rcs.impl.OperationLogService;
import org.ydzy.rcs.module.LoadProperties;
import org.ydzy.util.*;

import javax.sql.DataSource;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.*;

/**
 * ��ͨcsp
 */
@Singleton
@Description(value = "cuccCsp", autoInstance = true)
public class CuccCsp extends BaseCspInter {
    private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(CuccCsp.class);
    volatile String accesskey = LoadProperties.systemProperties.getProperty("csp.cucc.accessKey");
    volatile String cspid = LoadProperties.systemProperties.getProperty("csp.cucc.cspId");
    volatile long accessTokenTime = 0;
    private Map<String, String> cuccRegionsMap = null;

    @Inject
    JwtOperatorUtil jwtOperatorUtil;

    public void checkAccessToken(DataSource ds, HttpServletRequest request) {
        if (accessTokenTime == 0 || Util.isNull(accessToken))
            accessToken(ds, request);
        else {
            boolean flag = isTimeOutToken(accessTokenTime, "csp.cucc.accessTimeOut");
            if (flag) {
                accessToken(ds, request);
            }
        }
    }

    public CuccCsp() {
        super();
    }

    public boolean validateHeader(HttpServletRequest request, DataSource ds) {
        Map<String, String> headMap = new HashMap<>();
        Enumeration<String> headers = request.getHeaderNames();
        while (headers.hasMoreElements()) {
            String key = headers.nextElement();
            String value = request.getHeader(key);
            headMap.put(key, value);
        }

        String nonce = headMap.get("nonce");
        String signature = headMap.get("signature");
        String timestamp = headMap.get("timestamp");
        String authorization = headMap.get("authorization");
        String signaturecompute = Util.encrypt(accesskey + nonce + timestamp);
        Date date = Util.isNull(timestamp) ? new Date() : parse(timestamp);
        boolean flag = isTimeOutToken(date.getTime(), "csp.cucc.accessTimeOut");
        if (flag) {
            try {
                logger(ds, "error", "500", "validateHeaderError", "accessToken " + authorization + " timeout timestamp " + timestamp, BaseHandler.getIpAddress(request), request, "CuccCspImpl");
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else {
            if (signaturecompute.equals(signature)) {
                try {
                    logger(ds, "info", "200", "validateHeaderSucess", "accessToken " + authorization + " timeout timestamp " + timestamp, BaseHandler.getIpAddress(request), request, "CuccCspImpl");
                } catch (IOException e) {
                }
                return true;
            } else {
                try {
                    logger(ds, "error", "500", "validateHeaderError", "md5 check failed signature error " + signature + " md5str " + accesskey + nonce + timestamp + " signaturecompute " + signaturecompute, BaseHandler.getIpAddress(request), request, "CuccCspImpl");
                } catch (IOException e) {
                    e.printStackTrace();
                }
                return false;
            }
        }
        return false;
    }

    Gson gson = new Gson();

    private static final String CODE_TOKEN_TIME_OUT = "42001";
    private static final String CODE_SUCCESS = "0";

    /**
     * ��ȡtoken
     */
    public synchronized void accessToken(DataSource ds, HttpServletRequest request) {
        LocalDateTime time = LocalDateTime.now(ZoneOffset.of("+8"));
        if (gson == null) gson = new Gson();
        if (accesskey == null) accesskey = LoadProperties.systemProperties.getProperty("csp.cucc.accessKey");
        if (cspid == null) cspid = LoadProperties.systemProperties.getProperty("csp.cucc.cspId");
        Map<String, Object> header = headers(accesskey, time);
        JsonObject body = new JsonObject();
        body.addProperty("cspId", cspid);
        body.addProperty("accessKey", accesskey);
        String uri = LoadProperties.systemProperties.getProperty("csp.cucc.accessTokenUri");
        header.put("host", uri);
        String gsonhead = gson.toJson(header);
        try {
            log.info("request AccessToken  \r\nuri{}   \r\nheader {}   \r\nbody {} ", uri, gsonhead, body);
            String response = NetUtils.doHttps(uri, gson.toJson(body), header, "application/json");
            JsonObject resObj = requestBody2Json(response);
            if (resObj == null)
                return;
            JsonObject data = resObj.getAsJsonObject("data");
            if (data != null && !data.isJsonNull()) {
                accessToken = Util.getElementAsString(data, "accessToken");
                accessTokenTime = LocalDateTime.now().toInstant(ZoneOffset.of("+8")).toEpochMilli();
            }

            if (Util.isNull(accessToken)) {
                try {
                    logger(ds, "warn", "500", "get accessToken from uri " + uri + " failed ", "head is: " + gsonhead + " body is " + gson.toJson(body), request != null ? BaseHandler.getIpAddress(request) : "", request, "BaseCspInter");
                } catch (IOException e) {
                }
            } else {
                logger(ds, "info", "200", "get accessToken from uri " + uri + " sucess  token: " + accessToken + " tokenTime : " + accessTokenTime, "head is: " + gsonhead + " body is: " + gson.toJson(body), request != null ? BaseHandler.getIpAddress(request) : "", request, "BaseCspInter");
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * �ϴ��ͻ����� 6.1 �ӿ���Ϣ �ӿڷ���CSP��5G ��Ϣҵ�����ƽ̨
     * �ӿ�˵�������ڴ����ͻ�ǰ�ϴ��ͻ�������Ϣ����Ӫҵִ�ա�����֤���������Ϣ��
     * 6.2 ���󷽷� ���󷽷���HTTPS POST ����
     * URL��https://{serverRoot}/cspApi/{apiVersion}/uploadFile
     */
    public boolean doUploadFile(TaskInner task) {
        DataSource ds = task.ds;
        JsonObject body = task.body;
        HttpServletRequest request = task.request;
        HttpServletResponse rsp = task.response;
        LocalDateTime time = LocalDateTime.now(ZoneOffset.of("+8"));
        Map<String, Object> header = headers(accesskey, time, "multipart/form-data");
        header.put("authorization", accessToken);

        String uploadType = request.getParameter("uploadType");// Util.getElementAsString(body, "uploadType");
        String fileType = request.getParameter("fileType");// 1:ecinfo  2 chatbot

        header.put("uploadType", uploadType);
        boolean flag = false;
        try {
            Map<String, Object> uploadObj = uploadFile(request);
            String localFile = Util.toString(uploadObj.get("localPath"));
            String filename = Util.toString(uploadObj.get("filename"));
            String uri = LoadProperties.systemProperties.getProperty("csp.cucc.uploadFileUri");
            if ("2".equals(fileType))
                uri = LoadProperties.systemProperties.getProperty("csp.cucc.uploadChatbotFileUri");
            header.put("host", uri);
            try {
                logger(ds, "info", "ready", "request uploadFile " + uri, "upload " + filename, BaseHandler.getIpAddress(request), request, "CuccCspImpl.uploadFiles");
            } catch (IOException e) {
                e.printStackTrace();
            }
            String response = null;
            try {
                String boundary = "--------------------------" + UUID.randomUUID().toString().replace("-", "");
                if (task.doretryRMI) {
                    ByteBuffer buffer = NetUtils.getMultiPartBody(localFile, Util.fileType(filename), boundary);
                    response = NetUtils.doHttps(uri, buffer, header, "multipart/form-data;boundary=" + boundary);
                }
            } catch (IOException ioe) {

            }
            JsonObject resObj = new JsonObject();
            Object[] paramsUpdate = null;
            String resbody1 = "";
            if (!Util.isNull(response)) {
//				resbody1=response;
                JsonObject resObjnew = requestBody2Json(response);
                if (resObjnew.get("code").getAsInt() != 0) {
                    sendResponse(BaseHandler.getIpAddress(request), response, resObjnew.get("code").getAsInt(), request, rsp);
                }
                String code = Util.getElementAsString(resObjnew, "code");
                if (CODE_TOKEN_TIME_OUT.equals(code)) {
                    accessToken(ds, request);
                    doUploadFile(task);
                }
                JsonObject data = resObjnew.getAsJsonObject("data");
                if (data != null && !data.isJsonNull()) {
                    // TODO ADD 2db
                    String uploadFileUrl = Util.getElementAsString(data, "url");
                    if (Util.isNull(uploadFileUrl)) uploadFileUrl = Util.getElementAsString(data, "filePath");
                    resObj.addProperty("url", uploadFileUrl);
                    flag = true;
                    task.doretryRMI = false;
                    resbody1 = resBodyJson("200", "upload 2 5GServer sucess ", resObj);
                    //INSERT INTO `rcs_csp_files`(`uploadServerUrl`, `headers`, `fileParams`, `url`, `uploadType`, `fileName`, `from`) VALUES (?,?, ?,?, ?,?,?);
                    paramsUpdate = new Object[]{
                            uri, gson.toJson(header), gson.toJson(uploadObj), uploadFileUrl, uploadType, filename, fileType
                    };
                    try {
                        logger(ds, "info", "200", "uploadFile sucess " + uri + "responseuri " + uploadFileUrl + "body " + gson.toJson(body), resbody1, BaseHandler.getIpAddress(request), request, "CuccCspImpl.uploadFiles");
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            } else {
                String upurl = LoadProperties.systemProperties.getProperty("webUrl") + "/media/" + filename;
                resObj.addProperty("url", upurl);
                paramsUpdate = new Object[]{
                        uri, gson.toJson(header), gson.toJson(uploadObj), upurl, uploadType, filename, fileType
                };
                resbody1 = resBodyJson("500", "upload 2 5GServer failed ", resObj);
                try {
                    logger(ds, "info", "500", "uploadFile failed " + uri + "responseuri " + upurl + "body " + gson.toJson(body), resbody1, BaseHandler.getIpAddress(request), request, "CuccCspImpl.uploadFiles");
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if (task.add2db) {
                task.add2db = !InsertUploadFiles(ds, paramsUpdate);
            }
            try {
                sendResponse(BaseHandler.getIpAddress(request), resbody1, 200, request, rsp);
                return flag;
            } catch (IOException e) {
                e.printStackTrace();
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ServletException e) {
            e.printStackTrace();
        }
        return flag;
    }

    /**
     * addCspCustomer ������Ϣ
     * 1��uploadType���ϴ��������͡�0���ͻ�ͼƬ 1������֤������  2����ͬ
     * 2��fileType�� 1:ecinfo �ͻ�����   2 chatbot chatbot����
     * 3��body ���� �ļ�����������
     * 4��operatorType ��������
     * 5��isp��	1:�й��ƶ� telcsp:�й����� 3:�й���ͨ
     * ��� �ֶ� �� �� ���� ���� ���� �� ѡ ���� ����
     * 1 rcsRegisterInfo object M �ͻ�������Ϣ,��ϸ�뿴rcsRegisterInfo ����˵��
     * 2 rcsInfo object M �ͻ���ҵ��Ϣ,��ϸ�뿴 rcsInfo ����˵��
     * 3 rcsContractInformation object M ��ͬ��Ϣ,��ϸ�뿴rcsContractInformation ����˵��
     * 4 rcsLegalP object M �ͻ�������Ϣ,��ϸ�뿴 rcsLegalP����˵��
     * {
     * "rcsRegisterInfo": {
     * "ecName": "�й�����",
     * "ecGrade": 1,
     * "businessType": 1
     * },
     * "rcsInfo": {
     * "introduce": "XXXXXX ��˾���� 2010-08-16 ����,��ҵ��Ҫ����������������Ӧ;�ȵ���
     * ����������졢����;����Դ��������;���¹ܡ����¼������°����졢����",
     * " serviceIcon ": "http://172.17.25.10:9081/7,026c1babd98a",
     * "workPhone": "020-58587765",
     * "businessLicense": "http://172.17.25.10:9081/7,026d2c25342d",
     * "businessAddress": "������ 13 ��", "province": "�����",
     * "city": "�����",
     * "area": "�Ͽ���",
     * "operatorName": "������",
     * "operatorCard": "210102199003077037",
     * "operatorPhone": "133XXXXXXXX",
     * " emailAddress ": "133XXXXXXXX@189.cn",
     * " operatorIdentityPic ":
     * ["http://172.17.25.10:9081/7,026d2c25342d","http://172.17.25.10:9081/7,026d2c25342d"]
     * },
     * "rcsContractInformation": {
     * "contractNo": "100001",
     * "name": "��ͬ����",
     * "effectiveDate": "20201208013659",
     * "expiryDate": "20221208013659",
     * "status": 1,
     * "renewalDate": "20211208013659",
     * "accessory": "http://172.18.91.4:8080/2,03bdf0e3a1"
     * },
     * "rcsLegalP": {
     * "legalName": "��ΰ",
     * "legalIdentification": "110302203002030203",
     * "identificationStraight": "http://172.17.25.10:9081/7,026d2c25342d",
     * "identificationCounter": "http://172.17.25.10:9081/7,026d2c25342d"
     * }
     * }
     * rcsRegisterInfo ����˵��:
     * ��� �ֶ� �������� ���ݳ��� ��ѡ���� ����
     * 1 ecName string 34 M �ͻ�����
     * 2 businessType int 4 M �ͻ���ҵ���ͣ��μ�����ҵ�����ֵ� id �ֶ�  rcs_tags  isp
     * 3 ecGrade int 4 M 0 ���Ƽ���1 ���Ƽ���2 ͭ�Ƽ���3 ��׼����Ĭ�ϣ�3��׼��
     * rcsInfo ����˵��:
     * ��� �ֶ� �������� �� �� ���� �� ѡ ���� ����
     * 1 introduce string 999 M ��ҵ����
     * 2 serviceIcon string 128 M ��ҵ logo����ʹ�ÿͻ������ϴ��ӿڷ��صĵ�ַ
     * 3 workPhone string 32 M �칫�绰
     * 4 businessLicense string 255 M ��ҵӪҵִ�գ���ʹ�ÿͻ������ϴ��ӿڷ��صĵ�ַ
     * 5 businessAddress string 64 M ��ҵ���ڵ�
     * 6 province string 64 M ʡ��
     * 7 city string 64 M ��
     * 8 area string 64 M ��
     * 9 operatorName string 16 M �ͻ���ϵ��
     * 10 operatorCard string 16 M �ͻ���ϵ������֤��
     * 11 operatorPhone string 32 M �ͻ���ϵ���ֻ���
     * 12 emailAddress string 64 M �ͻ���ϵ������
     * 13 operatorIdentityPic array 255 M �ͻ���ϵ������֤�������ļ���ַ
     * <p>
     * rcsContractInformation ����˵��:
     * ��� �ֶ� �������� ���� ���� �� ѡ ���� ����
     * 1 contractNo string 255 M ��ͬ����
     * 2 name string 32 M ��ͬ����
     * 3 effectiveDate string 14 M �� ͬ �� Ч �� �� ��yyyyMMddHHmmss��:20201208013659
     * 4 expiryDate string 14 M �� ͬ ʧ Ч �� �� ��yyyyMMddHHmmss��:20201208013659
     * 5 status int 4 M ��ͬ�Ƿ���ǩ(1.�� 2.��)
     * 6 renewalDate string 14 C �� ͬ �� ǩ �� �� ��yyyyMMddHHmmss��:20201208013659
     * 7 accessory string 255 M ��ͬ��������ʹ�ÿͻ������ϴ��ӿڷ��ص� url
     * <p>
     * rcsLegalP ����˵��:
     * ��� �ֶ� �������� �� �� ���� �� ѡ ���� ����
     * 1 legalName string 20 M ��������
     * 2 legalIdentification string 64 M ��������֤��
     * 3 identificationStraight string 512 M ��������֤�����ļ���ַ
     * 4 identificationCounter string 512 M ��������֤�����ļ���ַ
     */
    public boolean addCspCustomer(TaskInner task) {
        DataSource ds = task.ds;
        JsonObject body = task.body;
        JsonObject bodyCopy = task.body.deepCopy();
        HttpServletRequest request = task.request;
        HttpServletResponse response = task.response;
        boolean flag = false;
        String uri = LoadProperties.systemProperties.getProperty("csp.cucc.addCspCustomerUri");
        // ��ӳ�����ݷŵ��ڴ���
        this.getRegionMapping();
        JsonObject rcsRegisterInfo = body.getAsJsonObject("rcsRegisterInfo");
        JsonObject rcsInfo = body.getAsJsonObject("rcsInfo");
        String province = rcsInfo.get("province").getAsString();
        String city = rcsInfo.get("city").getAsString();
        if (cuccRegionsMap.containsKey(province)) {
            rcsInfo.addProperty("province", cuccRegionsMap.get(province));
        }
        if (cuccRegionsMap.containsKey(city)) {
            rcsInfo.addProperty("city", cuccRegionsMap.get(city));
        }
        JsonObject rcsContractInformation = body.getAsJsonObject("rcsContractInformation");
        JsonObject rcsLegalP = body.getAsJsonObject("rcsLegalP");
        rcsInfo.remove("operatorarea");
        rcsInfo.remove("operatorsex");
        rcsInfo.remove("operatoripfrom");
        JsonArray array = new JsonArray();
        array.add(Util.getElementAsString(rcsInfo, "operatorIdentityPic1"));
        array.add(Util.getElementAsString(rcsInfo, "operatorIdentityPic2"));
        rcsInfo.add("operatorIdentityPic", array);

        rcsInfo.remove("operatorIdentityPic1");
        rcsInfo.remove("operatorIdentityPic2");
        rcsLegalP.remove("operatorIdentityPic1");
        rcsLegalP.remove("operatorIdentityPic2");

        JsonArray legalarray = new JsonArray();
        legalarray.add(Util.getElementAsString(rcsLegalP, "identificationStraight"));
        legalarray.add(Util.getElementAsString(rcsLegalP, "identificationCounter"));
        rcsLegalP.add("identificationPic", legalarray);
        rcsLegalP.remove("identificationStraight");
        rcsLegalP.remove("identificationCounter");
        rcsRegisterInfo.remove("cspEcNo");
        JsonObject resbody = new JsonObject();
        resbody.add("rcsRegisterInfo", rcsRegisterInfo);
        resbody.add("rcsInfo", rcsInfo);
        resbody.add("rcsContractInformation", rcsContractInformation);
        rcsLegalP.remove("operatorPhone");
        resbody.add("rcsLegalP", rcsLegalP);
//		resbody.remove("isp");
        try {
            logger(ds, "info", "ready", "addCustomer2Db sucess ready request  " + uri, gson.toJson(resbody), BaseHandler.getIpAddress(request), request, "CuccCspImpl.addCustomers");
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            String r = "";
            if (task.doretryRMI) {
                r = post25gMsgAddCspCustomer(uri, resbody);
            }
            String resbody1 = "";
            if (!Util.isNull(r)) {
                JsonObject ro = requestBody2Json(r);
                String code = Util.getElementAsString(ro, "code");
                if (CODE_SUCCESS.equals(code)) {
                    JsonObject data = ro.getAsJsonObject("data");
                    String cspEcNo = Util.getElementAsString(data, "cspEcNo");
                    if (Util.isNull(cspEcNo)) {
                        resbody1 = resBodyJson("500", "addCustomer failed  ���������� ", data);
                        task.add2db = false;
                        flag = true;
                    } else {
                        if (task.add2db) {
                            task.add2db = !insertCspCustomer(gson, bodyCopy, ds);
                            task.body.addProperty("cspEcNo", cspEcNo);
                            task.add2db = !updateCustomerStatus(task);
                        }
                        resbody1 = resBodyJson("200", "addCustomer sucess ", data);
                        task.doretryRMI = false;
//						waitNotifyQueue.add(task);
                        Object[] updateParam = new Object[]{cspEcNo, Util.getElementAsString(rcsRegisterInfo, "ecName")};
                        updateCspNo(ds, updateParam);
                        flag = true;
                        try {
                            logger(ds, "info", "sucess", "addCustomer Request sucess ready request  " + uri + "body " + gson.toJson(body), resbody1, BaseHandler.getIpAddress(request), request, "CuccCspImpl.addCustomers");
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                } else if (CODE_TOKEN_TIME_OUT.equals(code)) {
                    accessToken(ds, request);
                } else {
                    task.add2db = false;
                    flag = true;
                    resbody1 = resBodyJson("500", "addCustomer failed  ���������� ", ro);
                }

            } else {
                if (task.add2db)
                    task.add2db = !insertCspCustomer(gson, bodyCopy, ds);
                String cspEcNo = "YD" + new java.util.Random().nextInt();
                Object[] updateParam = new Object[]{cspEcNo, Util.getElementAsString(rcsRegisterInfo, "ecName")};
                updateCspNo(ds, updateParam);
                resbody1 = resBodyJson("200", "addCustomer request will be retried later ", null);
                try {
                    logger(ds, "warn", "failed", "addCustomer Request failed ready request  " + uri + "body " + gson.toJson(body), resbody1, BaseHandler.getIpAddress(request), request, "CuccCspImpl.addCustomers");
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            try {
                sendResponse(BaseHandler.getIpAddress(request), resbody1, 200, request, response);
                return flag;
            } catch (IOException e) {
                e.printStackTrace();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return flag;
    }

    public String post25gMsgAddCspCustomer(String uri, JsonObject resbody) {
        LocalDateTime time = LocalDateTime.now(ZoneOffset.of("+8"));
        Map<String, Object> header = headers(accesskey, time);
        header.put("host", uri);
        header.put("authorization", accessToken);
        try {
            String s = NetUtils.doHttps(uri, resbody, header, "application/json");
            return s;
        } catch (IOException ioee) {
        }
        return null;
    }

    public boolean getFile(TaskInner task) {
        DataSource ds = task.ds;
        JsonObject body = task.body;
        HttpServletRequest request = task.request;
        HttpServletResponse response = task.response;
        boolean flag = false;
        LocalDateTime time = LocalDateTime.now(ZoneOffset.of("+8"));
        String uri = LoadProperties.systemProperties.getProperty("csp.cucc.getFileUri");
        Map<String, Object> header = headers(accesskey, time);
        header.put("authorization", accessToken);
        String fileUrl = Util.getElementAsString(body, "fileUrl");
        JsonObject sendbody = new JsonObject();
        sendbody.addProperty("fileUrl", fileUrl);
        //TODO GETFILES ?
        try {
            String responsebody = "";
            if (task.doretryRMI)
                responsebody = NetUtils.doHttps(uri, sendbody, header, " application/json");
            if (!Util.isNull(responsebody)) {
                String res = new String(Base64.getEncoder().encode(responsebody.getBytes("UTF-8")));
                task.doretryRMI = false;
                JsonObject obj = new JsonObject();
                obj.addProperty("content", res);
                obj.addProperty("code", "base64");
                String resbody1 = resBodyJson("200", "getFile sucess", obj);
                flag = true;
                try {
                    try {
                        logger(ds, "info", "sucess", "getFile sucess ready request  " + uri + "body " + gson.toJson(body), resbody1, BaseHandler.getIpAddress(request), request, "CuccCspImpl.getFiles");
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    sendResponse(BaseHandler.getIpAddress(request), resbody1, 200, request, response);
                    return flag;
                } catch (IOException e) {
                    e.printStackTrace();
                }
            } else {
                String resbody1 = resBodyJson("500", "getFile failed", null);
                try {
                    logger(ds, "warn", "failed", "getFile sucess ready request  " + uri + "body " + gson.toJson(body), resbody1, BaseHandler.getIpAddress(request), request, "CuccCspImpl.getFiles");
                } catch (IOException e) {
                    e.printStackTrace();
                }
                sendResponse(BaseHandler.getIpAddress(request), resbody1, 200, request, response);
                return flag;

            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return flag;
    }

    Map<String, String> rcsRegisterInfoMap = new HashMap<>() {
        {
            put("ecName", "ecName");
            put("ecGrade", "ecGrade");
            put("businessType", "businessType");
            put("cspEcNo", "cspEcNo");
        }
    };
    Map<String, String> rcsInfoMap = new HashMap<>() {
        {
            put("introduce", "introduce");
            put("serviceIcon", "serviceIcon");
            put("workPhone", "workPhone");

            put("businessLicense", "businessLicense");
            put("businessAddress", "businessAddress");
            put("province", "province");
            put("city", "city");
            put("area", "area");
            put("operatorRcsUserId", "operatorRcsUserId");
            put("operatorUserId", "operatorUserId");
            put("contractNo", "contractNo");
            put("legalUserId", "legalUserId");
            put("operatorName", "operatorName");
            put("operatorCard", "operatorCard");
            put("operatorPhone", "operatorPhone");
            put("emailAddress", "emailAddress");
            put("operatorIdentityPic1", "operatorIdentityPic1");
            put("operatorIdentityPic2", "operatorIdentityPic2");
            put("operatorarea", "operatorarea");
            put("operatoripfrom", "operatoripfrom");
            put("operatorsex", "operatorsex");
//			put("serverIcon","serverIcon");
        }
    };
    Map<String, String> rcsContractInformationMap = new HashMap<String, String>() {
        {
            put("contractNo", "contractNo");
            put("name", "name");
            put("effectiveDate", "effectiveDate");


            put("expiryDate", "expiryDate");
            put("status", "status");
            put("renewalDate", "renewalDate");
            put("accessory", "accessory");
        }
    };
    Map<String, String> rcsLegalIpMap = new HashMap<>() {
        {
            put("legalRcsUserId", "legalRcsUserId");
            put("legalName", "legalName");
            put("legalIdentification", "legalIdentification");
            put("identificationStraight", "identificationStraight");
            put("identificationCounter", "identificationCounter");
            put("operatorIdentityPic1", "operatorIdentityPic1");
            put("operatorIdentityPic2", "operatorIdentityPic2");
            put("operatorPhone", "operatorPhone2");
        }
    };

    protected JsonArray getNotifyResult() {
//		String sqlid = "updateChatbotDeveloper";
//		String sql = XmlSqlGenerator.getSqlstr(sqlid);
//		try {
//			JsonArray array = SqlUtil.queryForJson(ds, sql);
//			if(array==null)
//			{
//				System.out.println("why");
//			}
//			return array;
//		}
//		catch (Exception e) {
//		e.printStackTrace();
//		}
        return null;
    }

    protected JsonArray getUnCommitCustomers() {
//		String sqlid = "queryUnCommitCustomers";
//		String sql = XmlSqlGenerator.getSqlstr(sqlid);
//		try {
//			JsonArray array = SqlUtil.queryForJson(ds, sql);
//			JsonArray resArray=dbRecord2CspStructs(array);
//			return resArray;
//		}
//		catch (Exception e) {
//		}
        return null;
    }

    public void showEcInfos(TaskInner task) {
        DataSource ds = task.ds;
        JsonObject body = task.body;
        HttpServletRequest request = task.request;
        HttpServletResponse response = task.response;
        /*
         * SELECT A.*, b.username AS operatorName, b.phone AS operatorPhone, b.area AS
         * operatorarea, b.sex AS operatorsex, b.ipfrom AS operatoripfrom,
         * b.operatorCard AS operatorCard, b.emailAddress AS emailAddress,
         * b.operatorIdentityPic1 AS operatorIdentityPic1, b.operatorIdentityPic2 AS
         * operatorIdentityPic2, c.username AS legalName, c.operatorCard AS
         * legalIdentification, c.operatorIdentityPic1 AS identificationStraight,
         * c.operatorIdentityPic2 AS identificationCounter, `name`, DATE_FORMAT( (
         * effectiveDate ), '%Y%m%d%H%i%S' ) effectiveDate, DATE_FORMAT( ( expiryDate ),
         * '%Y%m%d%H%i%S' ) expiryDate, `status`, DATE_FORMAT( ( renewalDate ),
         * '%Y%m%d%H%i%S' ) renewalDate, accessory FROM rcs_csp_ecinfo A LEFT JOIN
         * rcs_user b ON a.operatorUserId = b.userid LEFT JOIN rcs_user c ON
         * a.legalUserId = b.userid LEFT JOIN rcs_csp_contractinfomation d ON
         * a.contractNo = d.contractNo
         */

        String sqlid = "showecinfos";
        Map dbParam = gson.fromJson(body, Map.class);
        String sql = XmlSqlGenerator.getSqlstrByMap(sqlid, dbParam);
        try {
            JsonArray array = SqlUtil.queryForJson(ds, sql);
            JsonArray resArray = dbRecord2CspStructs(array);
            String send = resBodyJson("200", "sucess", resArray);
            sendResponse(BaseHandler.getIpAddress(request), send, 200, request, response);
            task.add2db = false;
            task.doretryRMI = false;
        } catch (SQLException | IOException e) {
            e.printStackTrace();
        }
    }

    private JsonArray dbRecord2CspStructs(JsonArray array) {
        JsonArray resArray = new JsonArray();
        for (JsonElement c : array) {
            JsonObject record = c.getAsJsonObject();
            JsonObject rcsRegisterInfo = new JsonObject();// "rcsRegisterInfo"
            JsonObject rcsInfo = new JsonObject();// ("rcsInfo");
            JsonObject rcsContractInformation = new JsonObject();// ("rcsContractInformation");
            JsonObject rcsLegalP = new JsonObject();// ("rcsLegalP");
            rcsRegisterInfoMap.forEach((k, v) -> {
                rcsRegisterInfo.addProperty(k, Util.getElementAsString(record, v));
            });
            rcsInfoMap.forEach((k, v) -> {
                rcsInfo.addProperty(k, Util.getElementAsString(record, v));
            });
            rcsContractInformationMap.forEach((k, v) -> {
                rcsContractInformation.addProperty(k, Util.getElementAsString(record, v));
            });
            rcsLegalIpMap.forEach((k, v) -> {
                rcsLegalP.addProperty(k, Util.getElementAsString(record, v));
            });
            JsonObject newRecord = new JsonObject();
            newRecord.add("rcsRegisterInfo", rcsRegisterInfo);
            newRecord.add("rcsInfo", rcsInfo);
            newRecord.add("rcsContractInformation", rcsContractInformation);
            newRecord.add("rcsLegalP", rcsLegalP);

            resArray.add(newRecord);
        }
        return resArray;
    }

    public boolean editCspCustomer(TaskInner task) {
        DataSource ds = task.ds;
        JsonObject body = task.body;
        HttpServletRequest request = task.request;
        HttpServletResponse response = task.response;
        boolean flag = false;
        LocalDateTime time = LocalDateTime.now(ZoneOffset.of("+8"));
        String uri = LoadProperties.systemProperties.getProperty("csp.cucc.editcspCustomerUri");
        Map<String, Object> header = headers(accesskey, time);
        header.put("authorization", accessToken);

        if (task.add2db) {
            task.add2db = !updateCspInfos(gson, body, ds);
        }
        JsonObject resbody = reBuildCustomers(body);
        JsonObject rcsRegisterInfo = resbody.getAsJsonObject("rcsRegisterInfo");
        try {
            String r = "";
            if (task.doretryRMI)
                r = NetUtils.doHttps(uri, resbody, header, "application/json");
            if (!Util.isNull(r)) {
                JsonObject ro = requestBody2Json(r);
                JsonElement data = ro.get("data");
                if (data.isJsonNull()) {
                    sendResponse(BaseHandler.getIpAddress(request), r, 200, request, response);
                    return Boolean.TRUE;
                }
                String cspEcNo = Util.getElementAsString(data.getAsJsonObject(), "cspEcNo");
                Object[] updateParam = new Object[]{Util.getElementAsString(rcsRegisterInfo, "ecName"), cspEcNo};
                flag = true;
                task.doretryRMI = false;
                try {
                    String sqlId = "updatecspecinfo";
                    String sql = XmlSqlGenerator.getSqlstr(sqlId);
                    SqlUtil.updateRecords(ds, sql, updateParam);

                    sendResponse(BaseHandler.getIpAddress(request), r, 200, request, response);
                    try {
                        logger(ds, "info", "sucess", "updateCustomerinfo sucess ready request  " + uri + "body " + gson.toJson(body), r, BaseHandler.getIpAddress(request), request, "CuccCspImpl.editCspCustomer");
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    return flag;
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        String resbody1 = resBodyJson("200", "request will be retried later " + uri, null);
        try {
            sendResponse(BaseHandler.getIpAddress(request), resbody1, 200, request, response);
            try {
                logger(ds, "warn", "failed", "updateCustomerinfo failed ready request  " + uri + "body " + gson.toJson(body), resbody1, BaseHandler.getIpAddress(request), request, "CuccCspImpl.editCspCustomer");
            } catch (IOException e) {
                e.printStackTrace();
            }
            return flag;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return flag;
    }

    public boolean deleteCustomer(TaskInner task) {
        DataSource ds = task.ds;
        JsonObject body = task.body;
        HttpServletRequest request = task.request;
        HttpServletResponse response = task.response;
        boolean flag = false;
        LocalDateTime time = LocalDateTime.now(ZoneOffset.of("+8"));
        String uri = LoadProperties.systemProperties.getProperty("csp.cucc.deleteCustomerUri");
        Map<String, Object> header = headers(accesskey, time);
        header.put("authorization", accessToken);

        if (task.add2db)
            task.add2db = !deleteCustomer2Db(gson, body, ds);
        try {
            String back = "";
            if (task.doretryRMI)
                back = NetUtils.doHttps(uri, gson.toJson(body), header, "");
            if (!Util.isNull(back)) {
                JsonObject obj = requestBody2Json(back);
                String code = Util.getElementAsString(obj, "code");
                String message = Util.getElementAsString(obj, "message");
                String desc = "";
                if (CODE_SUCCESS.equals(code)) {
                    flag = true;
                    desc = "ɾ���ɹ�";
                    task.doretryRMI = false;
                } else if (CODE_TOKEN_TIME_OUT.equals(code)) {
                    accessToken(ds, request);
                } else {
                    desc = Util.toString(LoadProperties.systemProperties
                            .getOrDefault(code, Util.toString(LoadProperties.systemProperties.get("other"))));
                    flag = true;
                    task.doretryRMI = false;
                }
                String resbody1 = resBodyJson(desc, message, null);
                try {
                    sendResponse(BaseHandler.getIpAddress(request), resbody1, 200, request, response);
                    try {
                        logger(ds, "info", "sucess", "deleteCustomerinfo sucess ready request  " + uri + "body " + gson.toJson(body), resbody1, BaseHandler.getIpAddress(request), request, "CuccCspImpl.deleteCspCustomer");
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    return flag;
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        } catch (IOException e) {

            String resbody1 = resBodyJson("200", "request will be retried later", null);
            try {
                sendResponse(BaseHandler.getIpAddress(request), resbody1, 200, request, response);
                try {
                    logger(ds, "warn", "failed", "deleteCustomerinfo failed ready request  " + uri + "body " + gson.toJson(body), resbody1, BaseHandler.getIpAddress(request), request, "CuccCspImpl.deleteCspCustomer");
                } catch (IOException e2) {
                    e2.printStackTrace();
                }
                return flag;
            } catch (IOException e1) {
                e1.printStackTrace();
            }
        }
        return flag;
    }

    /**
     * <p> ChatbotManager �����˹���
     * 1���ϴ����� <br/>
     * operatorType uploadFile <br/>
     * uploadType���ϴ��������͡��ϴ��������͡�0��LogoͼƬ 1��Chatbot ����ͼƬ
     * </p>
     * 2 chatbot chatbot����
     * 2�� ���� Chatbot ��Ϣ
     * operatorType ChatbotManager
     * <p>
     * ���ݸ�ʽ��<br/>
     * <li>��� �ֶ� �������� ���� ��ѡ���� ����</li>
     * <li>1 cspId string 32 M CSP ����</li>
     * <li>2 cspEcNo string 32 M �ͻ�ʶ����</li>
     * <li>3 chatbotId string 64 M ChatbotId���������+�Զ�����루ChatbotId һ�����������޸ģ� ��̨���㲻��ǰ�˴�ֵ</li>
     * <li>4 serviceName string 128 M Chatbot ��������</li>
     * <li>5 serviceIcon string 128 M Chatbot logo ·��</li>
     * <li>6 serviceDescription string 300 M Chatbot ������Ϣ</li>
     * <li>7 SMSNumber string 64 M Chatbot ���Ŷ˿ں�=chatbotId ��(�������+�Զ������) ��̨���㲻��ǰ�˴�ֵ</li>
     * <li>8 autograph string 128 M Chatbot ǩ��</li>
     * <li>9 category array 64 M Chatbot ���༴��ҵ�����࣬�����ҵ�����ֵ������ǰֻ֧�ֵ�һ��ҵ����</li>
     * <li>10 provider string 32 M Chatbot �ṩ������ ѡ��ͻ�����</li>
     * <li>11 showProvider int 4 M �Ƿ���ʾChatbot�ṩ�����ƣ�1����ʾ��0������ʾ</li>
     * <li>12 TCPage string 255 M Chatbot ��������</li>
     * <li>13 emailAddress string 50 M Chatbot ����</li>
     * <li>14 serviceWebsite string 150 M Chatbot ����(��ҳ��ַ)</li>
     * <li>15 callBackNumber string 21 M Chatbot ����绰</li>
     * <li>16 address string 200 M Chatbot �칫��ַ</li>
     * <li>17 longitude double 10 M Chatbot ��������</li>
     * <li>18 latitude double 10 M Chatbot ����γ��</li>
     * <li>19 ipWhiteList array 1024 M IP ��ַ������ (��� 15 �� ,�ָ�������</li>
     * <li>20 useAi �Ƿ�����AI������ 0:������ 1:����</li>
     * </p>
     *
     * <p>
     * ʾ����<br/>
     * {
     * "cspCode":"A100000001",
     * "cspEcNo":"A10000000100001",
     * "chatbotId":"1065988898989",
     * "serviceName":"1209API",
     * "serviceIcon":"http://124.126.120.19:8080/maap_message/bot/chanageUrl/perm/20201205145323/95465/6,0566ad9c2462.jpg",
     * "serviceDescription":"dgsdgdsfgdfg",
     * "SMSNumber":"1065988898989",
     * "autograph":"fddgdgfdg",
     * "category":[1,2],
     * "provider":"XXX ��˾",
     * "showProvider ":1,
     * "TCPage":"https://www.baidu.com/",
     * "emailAddress":"XXXX@189.cn",
     * "serviceWebsite":"https://www.baidu.com/",
     * "callBackNumber":"16619898798",
     * "address":"XX �� XX �� XX �ֵ�",
     * "longitude":116.20,
     * "latitude":39.56,
     * "ipWhiteList":["124.126.120.102"]
     * }
     * </p>
     * <p>
     * 3��chatbot״̬���<br/>
     * <p>
     * operatorType isOnlineUpdate <br/>
     * <li>��� �ֶ� �� �� ���� �� �� ���� �� ѡ ���� ����</li>
     * <li>1 accessTagNo string 64 M Chatbot �����ɹ��󷵻��ֶ�accessTagNo</li>
     * <li>2 type int 4 M �����߱�־��1:���ߣ�2:����</li>
     * </p>
     * <p>
     * {
     * " accessTagNo": "9bb127ae3a5e43d8baece177564788ca",
     * " type": 1,
     * }
     * </p>
     * <p>
     * 4����� Chatbot ��Ϣ<br/>
     * <p>
     * operatorType ChatbotManager <br/>
     * ����������һ�� ��һ��ID Ψһ��ʶ accessTagNo
     * </p>
     * <p>
     * 5������ɾ�� Chatbot
     * <p>
     * <li>��� �ֶ� �� �� ���� �� �� ���� �� ѡ ���� ����</li>
     * <li>1 accessTagNo string 64 M Chatbot �����ɹ��󷵻��ֶ�accessTagNo</li>
     * </p>
     * <p>
     * operatorType ChatbotManager <br/>
     * {
     * " accessTagNo": "9bb127ae3a5e43d8baece177564788ca"
     * }
     * </p>
     */
    public boolean ChatbotManager(TaskInner task) {
        String accessTagNo = null;
        DataSource ds = task.ds;
        // ԭʼ������Ϣ
        JsonObject body = task.body;
        // �����޸�������Ϣ
        JsonObject bodyclone = body.deepCopy();
        HttpServletRequest request = task.request;
        HttpServletResponse response = task.response;
        // ����chatbotUri
        String addUri = LoadProperties.systemProperties.getProperty("csp.cucc.addChatbotUri");
        String accessNum = LoadProperties.systemProperties.getProperty("csp.cucc.accessNumber");
        boolean flag = false;
        //TODO HOW TO CREATE CHATBOTID

        String latitude = Util.realToString(Util.getElementAsString(body, "latitude"), 7);
        body.addProperty("latitude", latitude);
        String longitude = Util.realToString(Util.getElementAsString(body, "longitude"), 7);
        body.addProperty("longitude", longitude);

        // chatbot������� 1������  2���޸�  3. ɾ��
        String type = Util.getElementAsString(body, "type");
        // �Ƿ��ݴ���Ϣ 2���ݴ�  1�����ݴ�
        String form = Util.getElementAsString(body, "form","2");
        // �Ƿ�����chatbot
        String comefrom = body.get("comefrom").getAsString();


        // loginname��ĿǰΪ�û��ֻ��� Ŀǰ�����洢��־��Ϣ
        String authorization = request.getHeader("Authorization").replaceAll("\"", "");
        Claims claimsFromToken = jwtOperatorUtil.getClaimsFromToken(authorization);
        String loginname = claimsFromToken.get("loginname").toString();
        log.info("From ChatbotManager data {} \r\nloginname:{}", body, loginname);

        // chatbot���༴��ҵ������
        String category = Util.getElementAsString(body, "categoryold");
        if (Util.isNull(category)) {
            category = Util.getElementAsString(body, "category");
            body.addProperty("categoryold", category);
            bodyclone.addProperty("categoryold", category);
        }
        JsonArray categoryArray = new JsonArray();
        categoryArray.add(category);
        body.add("category", categoryArray);

        body.remove("hasChatbotAccount");
        body.remove("isp");
        body.addProperty("cspCode", accessNum);
        // ����ip��ַ������
        String ipWhiteList = Util.getElementAsString(body, "ipWhiteListold");
        if (Util.isNull(ipWhiteList)) {
            ipWhiteList = Util.getElementAsString(body, "ipWhiteList");
            bodyclone.addProperty("ipWhiteListold", ipWhiteList);
        }
        if (!Util.isNull(ipWhiteList)) {
            JsonArray array = new JsonArray();
            array.add(ipWhiteList);
            if (array != null && array.isJsonArray()) {
                body.add("ipWhiteList", array);
            }
        }

        // ֪ͨ���ͣ�1��������2�������3��ɾ��
        if ("1".equals(type))
        {
            String msgNotifyUrl = "http://" + LoadProperties.systemProperties.getProperty("csp.publicAddressHttp");
            // ����chatbot
            if ("owner".equals(comefrom)) {
                // TODO reids������������
                int diyNum = new java.util.Random().nextInt(99999);
                String chatbotNum = accessNum + "" + diyNum;
                // cspId��csp����
                body.addProperty("cspId", cspid);
                body.addProperty("chatbotId", chatbotNum);
                body.addProperty("SMSNumber", chatbotNum);
                // Chatbot ���Ŷ˿ں�
                body.addProperty("chatbotIdenty", "sip:" + chatbotNum + "@botplatform.rcs.wo.cn");
                bodyclone.addProperty("cspId", cspid);
                bodyclone.addProperty("chatbotId", chatbotNum);
                bodyclone.addProperty("SMSNumber", chatbotNum);
                bodyclone.addProperty("chatbotIdenty", "sip:" + chatbotNum + "@botplatform.rcs.wo.cn");
                addUri = LoadProperties.systemProperties.getProperty("csp.cucc.addChatbotUri");
            } else {
                String chatbotIdenty = body.get("chatbotIdenty").getAsString();
                String chatbotId = Util.spiltNumbers(chatbotIdenty);
                body.addProperty("cspId", cspid);
                body.addProperty("chatbotId", chatbotId);
                body.addProperty("SMSNumber", chatbotId);
                bodyclone.addProperty("cspId", cspid);
                bodyclone.addProperty("chatbotId", chatbotId);
                bodyclone.addProperty("SMSNumber", chatbotId);
                // ��������Ӫ�̵���
                addUri = null;
            }
            try {
                String rsp = "";
                // 1 ��ʾ��Ҫ������������Ӫ��
                String one = "1";
                // Ϊ�˲�����ʱ ע�͵�rsp
                if (task.doretryRMI && addUri != null && one.equals(form)) {
                    rsp = doHttps(addUri, body, "application/json");
                }
                if (!Util.isNull(rsp))
                {
                    JsonObject obj = requestBody2Json(rsp);
                    String code = Util.getElementAsString(obj, "code");
                    if (obj != null && !obj.isJsonNull() && CODE_SUCCESS.equals(code)) {
                        flag = true;
                        task.doretryRMI = false;
                        accessTagNo = Util.getElementDeepAsString(obj, "data", "accessTagNo");
                        body.addProperty("accessTagNo", accessTagNo);
                        rsp = resBodyJson("200", "chatbot ����ɹ�", body);
                        bodyclone.addProperty("accessTagNo", accessTagNo);
                        bodyclone.addProperty("msgNotifyUrl", msgNotifyUrl);
                    } else if (CODE_TOKEN_TIME_OUT.equals(code)) {
                        accessToken(ds, request);
                        task.add2db = false;
                    } else {
                        rsp = resBodyJson("500", "addchatbot  request will be retried later", obj);
                        flag = true;
                        task.add2db = false;
                        task.doretryRMI = false;
                        //body.addProperty("accessTagNo",new java.util.Random().nextInt());
                    }
                    bodyclone.addProperty("auditStatus", 11);
                    insertOperationLog(loginname, "���������", 11, rsp, accessTagNo, gson.toJson(body));
                } else {
                    accessTagNo = "YD-" + Util.getRandomString(15).toUpperCase();
                    body.addProperty("accessTagNo", accessTagNo);
                    rsp = resBodyJson("200", "success", body);
                    bodyclone.addProperty("accessTagNo", accessTagNo);
                    bodyclone.addProperty("auditStatus", 10);
                    bodyclone.addProperty("msgNotifyUrl", msgNotifyUrl);
                    insertOperationLog(loginname, "�������ύ", 10, rsp, accessTagNo, gson.toJson(body));
                }
                if (task.add2db) {
                    bodyclone.addProperty("opType", "1");
                    bodyclone.addProperty("agreement", "1");
                    task.add2db = !insertChatBot(gson, bodyclone, ds);
                }
                if (comefrom.equals("owner")) {
//                    if (task.add2db) updateDeveloper(task);
//                    if (task.add2db) quitTestStatus(task);
                } else {
                    // �������񴴽���Ӧ��Ϊ�Զ����ͨ��
                    body.addProperty("auditStatus", 12);
                    body.addProperty("description", "�Զ���� ��������������� ");
                    body.addProperty("enable", 1);
                    body.addProperty("opType", 1);
                    body.addProperty("auditNo", accessTagNo);
                    // �������񴴽���Ӧ��Ϊ�Զ����ͨ��
                    bodyclone.addProperty("auditStatus", 12);
                    bodyclone.addProperty("enable", 1);
                    bodyclone.addProperty("auditNo", accessTagNo);
                    bodyclone.addProperty("description", "optype:1, �Զ����ͨ��");
                    updateChatbotAuditStatus(gson, bodyclone, ds);
                    insertOperationLog(loginname, "���ͨ��", 12, rsp, accessTagNo, gson.toJson(body));
                }
                try {
                    sendResponse(BaseHandler.getIpAddress(request), rsp, 200, request, response);
                    try {
                        logger(ds, "info", "chatbot", "addChatbot request ready request  " + addUri + "body " + gson.toJson(body), rsp, BaseHandler.getIpAddress(request), request, "CuccCspImpl.addChatbot");
                    } catch (IOException e2) {
                        e2.printStackTrace();
                    }
                    return flag;
                } catch (IOException e) {
                    e.printStackTrace();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else if ("2".equals(type))
        {
            // �޸�chatbot��Ϣ
            boolean isOwner = "owner".equals(comefrom) ? true : false;
            if (Util.isNull(body.get("SMSNumber").getAsString())) {
                body.addProperty("SMSNumber", body.get("chatbotId").getAsString());
                bodyclone.addProperty("SMSNumber", body.get("chatbotId").getAsString());
            }
            String updateUri = LoadProperties.systemProperties.getProperty("csp.cucc.updateChatbotUri");
            try {
                String requestUpdate = "";
                boolean fromTimes = "2".equals(form);
                // �ݴ�
                if (fromTimes){
                    task.doretryRMI = false;
                    task.add2db = false;
                    requestUpdate = resBodyJson("200", "success", null);
                    bodyclone.addProperty("type","1");
                    boolean b = !updateChatBotByChatbotId(gson, bodyclone, ds);
                    insertOperationLog(loginname, "�ٴ��ݴ�ɹ�", 10, requestUpdate, accessTagNo, gson.toJson(body));
                }
                if (task.doretryRMI) {
                    accessTagNo = body.get("accessTagNo").getAsString();

                    if (accessTagNo.startsWith("YD")) {

                        if (isOwner) {
                            requestUpdate = doHttps(addUri, body, "application/json");
                            bodyclone.addProperty("auditStatus", 11);
                            JsonObject object = requestBody2Json(requestUpdate);
                            if (object != null && !object.isJsonNull()) {
                                String code = Util.getElementAsString(object, "code");
                                if (CODE_SUCCESS.equals(code)) {
                                    JsonObject obj = object.getAsJsonObject("data");
                                    log.info("����������ݣ�{}",requestUpdate);
                                    bodyclone.addProperty("accessTagNo", Util.getElementAsString(obj, "accessTagNo"));
                                    bodyclone.addProperty("opType","2");
                                    task.add2db = !updateChatBotByChatbotId(gson, bodyclone, ds);
                                    insertOperationLog(loginname, "���������", 11, requestUpdate, accessTagNo, gson.toJson(body));
                                    flag = true;
                                    task.doretryRMI = false;
                                    task.add2db = false;
                                }
                            }
                        } else {
                            requestUpdate = "{\"code\":200,\"message\":\"success\"}";
                            bodyclone.addProperty("auditStatus", 12);
                            bodyclone.addProperty("enable", 1);
                            bodyclone.addProperty("auditNo", accessTagNo);
                            bodyclone.addProperty("description", "optype:2, �Ѵ����˻��༭���ͨ��");
                            task.add2db = !updateChatbotAuditStatus(gson, bodyclone, ds);
                            insertOperationLog(loginname, "�Ѵ����˻��༭���ͨ��", 12, requestUpdate, accessTagNo, gson.toJson(body));
                            flag = true;
                            task.doretryRMI = false;
                            task.add2db = false;
                        }
                    } else {
                    requestUpdate = doHttps(updateUri, body, "application/json");
                    // TODO
//                        requestUpdate = "{\n" +
//                                "\"code\": 0,\n" +
//                                "\"message\":\"success\"\n" +
//                                "}";
                    }
                }
                if (Util.isNull(requestUpdate)) {
                    requestUpdate = resBodyJson("200", "updatechatbot request will be retried later", null);
                } else {
                    JsonObject obj = requestBody2Json(requestUpdate);
                    if (obj != null && !obj.isJsonNull()) {
                        String code = Util.getElementAsString(obj, "code");
                        if (CODE_SUCCESS.equals(code)) {
                            flag = true;
                            task.doretryRMI = false;
                        } else {
                            flag = true;
                            task.doretryRMI = false;
                            task.add2db = false;
                        }
                    }
                }

                if (task.add2db) {
                    String auditStatus = String.valueOf(task.body.get("auditStatus").toString());
                    if (!Util.isNull(auditStatus) && "1".equals(auditStatus)) {
                        bodyclone.addProperty("auditStatus", 12);
                        insertOperationLog(authorization, "���ͨ��", 12, requestUpdate, bodyclone.get("accessTagNo").getAsString(), gson.toJson(body));
                    } else {
                        bodyclone.addProperty("auditStatus", 14);
                        insertOperationLog(authorization, "�޸Ĵ����", 14, requestUpdate, bodyclone.get("accessTagNo").getAsString(), gson.toJson(body));
                    }
                    bodyclone.addProperty("Optype", "2");
                    task.add2db = !updateChatBot(gson, bodyclone, ds);
                }
                try {
                    sendResponse(BaseHandler.getIpAddress(request), requestUpdate, 200, request, response);
                    try {
                        logger(ds, "info", "chatbot", "UpdateChatbot request ready request  " + updateUri + "body " + gson.toJson(body), requestUpdate, BaseHandler.getIpAddress(request), request, "CuccCspImpl.UpdateChatbot");
                    } catch (IOException e2) {
                        e2.printStackTrace();
                    }
                    return flag;
                } catch (IOException e) {
                    e.printStackTrace();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else if ("3".equals(type))
        {
            String delUri = LoadProperties.systemProperties.getProperty("csp.cucc.deleteChatbotUri");
            String requestUpdate = "";
            boolean remoteUpdateFlag = false; // ��ʶ ����˱༭��ɾ��Ӧ��״̬
            // 1: ���ݴ�
            boolean noTemporaryStorage = "1".equals(form);

            try {
                switch (comefrom){
                    case "other" -> {
                        body.addProperty("enable", "3");
                        bodyclone.addProperty("opType","3");
                        task.add2db = !updateOnlineStatusChatbot(gson, body, ds);
                        requestUpdate =  resBodyJson("200", "deleteChatbot is success", null);
                        insertOperationLog(loginname, "ɾ��chatbot�ɹ�",
                                12, requestUpdate, bodyclone.get("accessTagNo").getAsString(), gson.toJson(body));
                    }
                    case "owner"  -> {
                        if (task.doretryRMI && noTemporaryStorage) {
                            requestUpdate = doHttps(delUri, body, "application/json");
                        }else {
                            // ɾ���ݴ�״̬�µ�chatbot
                            requestUpdate = resBodyJson("200", "deleteChatbot is success", null);
                            remoteUpdateFlag = true;

                        }

                        if (Util.isNull(requestUpdate)) {
                            requestUpdate = resBodyJson("500", "deletechatbot request failed", null);
                        } else {
                            JsonObject obj = requestBody2Json(requestUpdate);
                            if (obj != null && !obj.isJsonNull()) {
                                String code = Util.getElementAsString(obj, "code");
                                if (CODE_SUCCESS.equals(code)) {
                                    flag = true;
                                    task.doretryRMI = false;
                                    if (!remoteUpdateFlag) {
                                        requestUpdate = resBodyJson("200", "deletechatbot request successfully", null);
                                    }
                                    insertOperationLog(loginname, "ɾ�������", 15, requestUpdate, bodyclone.get("accessTagNo").getAsString(), gson.toJson(body));
                                } else if (CODE_TOKEN_TIME_OUT.equals(code)) {
                                    // ���»�ȡ��Ч��accessToken
                                    accessToken(ds, request);
                                    task.add2db = false;
                                    requestUpdate = resBodyJson("500", "deletechatbot request failed", null);
                                } else {
                                    flag = true;
                                    task.doretryRMI = false;
                                    task.add2db = false;
                                    requestUpdate = resBodyJson("500", "deletechatbot request failed", null);
                                }
                            }
                        }
                        // ɾ��ʱ��������У��һ�� opType������Ϣ
                        if (task.add2db && !noTemporaryStorage) {
                            body.addProperty("enable", "3");
                            bodyclone.addProperty("opType","3");
                            task.add2db = !updateOnlineStatusChatbot(gson, body, ds);
                            insertOperationLog(loginname, "ɾ���ݴ�chatbot�ɹ�", 12, requestUpdate, bodyclone.get("accessTagNo").getAsString(), gson.toJson(body));
                        }
                    }
                }
            } catch (Exception e1) {
                e1.printStackTrace();
            }

            try {
                sendResponse(BaseHandler.getIpAddress(request), requestUpdate, 200, request, response);
                try {
                    logger(ds, "info", "chatbot", "deleteChatbot request ready request  " + delUri + "body " + gson.toJson(body), requestUpdate, BaseHandler.getIpAddress(request), request, "CuccCspImpl.deleteChatbot");
                } catch (IOException e2) {
                    e2.printStackTrace();
                }
                return flag;
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else if ("4".equals(type))
        {

            String optionalsUri = LoadProperties.systemProperties.getProperty("csp.cucc.optionals");
            String result = "";
            try {
                if (task.doretryRMI) {
//                    requestUpdate = doHttps(optionalsUri, body, "application/json");
                    result = "{\n" +
                            "\"errorCode\": 0,\n" +
                            "\"errorMessage\": \"success\"\n" +
                            "}";
                }
                if (Util.isNull(result)) {
                    result = resBodyJson("200", "optionalschatbot request will be retried later", null);
                } else {
                    JsonObject obj = requestBody2Json(result);
                    if (obj != null && !obj.isJsonNull()) {
                        String code = Util.getElementAsString(obj, "code");
                        if (CODE_SUCCESS.equals(code)) {
                            flag = true;
                            task.doretryRMI = false;
                        } else if (CODE_TOKEN_TIME_OUT.equals(code)) {
                            accessToken(ds, request);
                        } else {
                            flag = true;
                            task.doretryRMI = false;
                        }
                    }
                }
                if (task.add2db) {
                    body.addProperty("auditStatus", 17);
                    task.add2db = !optionalsChatbot(gson, body, ds);
                    insertOperationLog(loginname, "��������", 17, result, bodyclone.get("accessTagNo").getAsString(), gson.toJson(body));
                }
                try {
                    sendResponse(BaseHandler.getIpAddress(request), result, 200, request, response);
                    logger(ds, "info", "chatbot", "optionalsChatbot request ready request  " + optionalsUri + "body " + gson.toJson(body), result, BaseHandler.getIpAddress(request), request, "CuccCspImpl.optionalsChatbot");
                } catch (IOException e2) {
                    e2.printStackTrace();
                }
                return flag;

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return flag;
    }

    /**
     * <li>1.�����ӿ�-�˳�����״̬���롣�½�chatbot��Ĭ�Ͻ������״̬���˳�����״̬������Ҫ��ˡ�</li>
     * <li>2. �˳�����״̬��Ĭ�Ͻ�������̬��֮����������CSP���������������߲�����Ҫ���</li>
     *
     * @param task
     * @return
     */
    public boolean quitTestStatus(TaskInner task) {
        boolean flag = false;
        JsonObject olbody = task.body;
        String uri = LoadProperties.systemProperties.getProperty("csp.cucc.quitTestStatus");
        JsonObject body = new JsonObject();
        body.addProperty("accessTagNo", Util.getElementAsString(olbody, "accessTagNo"));
        body.addProperty("file", Util.getElementAsString(olbody, "file"));
        String auth = task.request.getHeader("Authorization").replaceAll("\"", "");
        // loginname��ĿǰΪ�û��ֻ��� Ŀǰ�����洢��־��Ϣ
        String loginname = jwtOperatorUtil.getClaimsFromToken(auth).get("loginname").toString();
        String s = doHttps(uri, body, "application/json");
        // TODO
//        s = "{\n" +
//                "\"code\": 0,\n" +
//                "\"message\": \"success\"\n" +
//                "}";
        String responseBody = "";
        if (!Util.isNull(s)) {
            JsonObject jsonObject = requestBody2Json(s);
            if (jsonObject != null && !jsonObject.isJsonNull()) {
                switch (Util.getElementAsString(jsonObject, "code")) {
                    case CODE_SUCCESS -> {
                        responseBody = resBodyJson("200", "quitTestStatus success.", jsonObject.get("data"));
                        task.doretryRMI = false;
//                        2. �˳�����״̬��Ĭ�Ͻ�������̬��֮����������CSP���������������߲�����Ҫ���
                        if (task.add2db) {
                            JsonObject quryBody = new JsonObject();
                            quryBody.addProperty("accessTagNo", Util.getElementAsString(body, "accessTagNo"));
                            quryBody.addProperty("quitFile", Util.getElementAsString(body, "file"));
                            quryBody.addProperty("auditStatus", 18);
                            task.add2db = !updateQuitTestStatusFile(gson, quryBody, ds);
                            insertOperationLog(loginname, "�˳�����״̬�����", 18, s, Util.getElementAsString(olbody, "accessTagNo"), gson.toJson(body));
                        }
                    }
                    case CODE_TOKEN_TIME_OUT -> checkAccessToken(task.ds, task.request);
                    default -> {
                        task.doretryRMI = false;
                        task.add2db = false;
                        flag = true;
                        responseBody = resBodyJson("500", "quitTestStatus  failed.", jsonObject);
                    }
                }
            }

        } else {
            responseBody = resBodyJson("500", "quitTestStatus  request will be retried later.", null);
        }
        try {
            sendResponse(BaseHandler.getIpAddress(task.request), responseBody, 200, task.request, task.response);
            logger(ds, "info", "chatbot", "quitTestStatus request ready request  " + uri + "body " + gson.toJson(body),
                    responseBody, BaseHandler.getIpAddress(task.request), task.request, "CuccCspImpl.quitTestStatus");
        } catch (IOException e) {
            e.printStackTrace();
        }
        return flag;
    }

    /**
     * <p>�ӿڷ���CSP��5G��Ϣҵ�����ƽ̨</p>
     * <p>�ӿ�˵���������޸�Chatbot�ڲ���״̬ʱ�ֻ��Ű�����</p>
     * | ��� | �ֶ�         | �������� | ���� | ��ѡ�� �� | ����                                          |
     * | ---- | ------------ | -------- | ---- | --------- | --------------------------------------------- |
     * | 1    | phoneNumbers | Array    |      | M         | ȫ�����ֻ����������                          |
     * | 2    | accessTagNo  | string   | 64   | M         | ���� Chatbot ʱ,���ص� Chatbot ��Ψһʶ���ʶ |
     *
     * @param task
     * @return
     */
    public boolean updatePhoneNumber(TaskInner task) {
        boolean flag = false;
        JsonObject oldBody = task.body;
        String uri = LoadProperties.systemProperties.getProperty("csp.cucc.updatePhoneNumber");
        JsonObject body = new JsonObject();
        JsonElement phoneNumbers = oldBody.get("phoneNumbers");
        String auth = task.request.getHeader("Authorization").replaceAll("\"", "");
        // loginname��ĿǰΪ�û��ֻ��� Ŀǰ�����洢��־��Ϣ
        String loginname = jwtOperatorUtil.getClaimsFromToken(auth).get("loginname").toString();
        if (phoneNumbers != null && !phoneNumbers.isJsonNull() && phoneNumbers.isJsonArray()) {
            body.add("phoneNumbers", phoneNumbers.getAsJsonArray());
        } else {
//            body.add("phoneNumbers", new JsonArray());
        }
        body.addProperty("accessTagNo", Util.getElementAsString(oldBody, "accessTagNo"));
        String responseBody = "";
        String res = doHttps(uri, body, CONTENT_TYPE_JSON);
        // TODO
//        res = "{\"code\":0,\"message\":\"ȫ��������������ӳɹ�\"}";
        if (!Util.isNull(res)) {
            JsonObject jsonObject = requestBody2Json(res);
            if (jsonObject != null && !jsonObject.isJsonNull()) {
                switch (Util.getElementAsString(jsonObject, "code")) {
                    case CODE_SUCCESS -> {
                        task.doretryRMI = false;
                        responseBody = resBodyJson("200", "updatePhoneNumber success.", jsonObject);
                        body.addProperty("phoneNumbers", gson.toJson(phoneNumbers));
                        updatechatbotWhitePhoneList(gson, body, task.ds);
                        insertOperationLog(loginname, "�˳�����״̬�����", 18, jsonObject.toString(), Util.getElementAsString(oldBody, "accessTagNo"), gson.toJson(body));
                    }
                    case CODE_TOKEN_TIME_OUT -> checkAccessToken(task.ds, task.request);
                    default -> {
                        task.doretryRMI = false;
                        task.add2db = false;
                        flag = true;
                        responseBody = resBodyJson("500", "updatePhoneNumber failed", jsonObject);
                    }
                }
            }
        } else {
            resBodyJson("500", "updatePhoneNumber request will be retried later. ", null);
        }
        try {
            sendResponse(BaseHandler.getIpAddress(task.request), responseBody, 200, task.request, task.response);
            logger(ds, "info", "chatbot", "updatePhoneNumber request ready request  " + uri + "body " + gson.toJson(body),
                    responseBody, BaseHandler.getIpAddress(task.request), task.request, "CuccCspImpl.updatePhoneNumber");
        } catch (IOException e) {
            e.printStackTrace();
        }
        return flag;
    }

    private static String CONTENT_TYPE_JSON = "application/json";

    /**
     * ��װheaderУ�����
     *
     * @param uri
     * @param body
     * @param contentType
     * @return
     */
    String doHttps(String uri, Object body, String contentType) {
        LocalDateTime time = LocalDateTime.now(ZoneOffset.of("+8"));
        Map<String, Object> header = headers(accesskey, time);
        header.put("authorization", accessToken);
        try {
            String reponse = NetUtils.doHttps(uri, body, header, contentType);
            if (Util.isNull(reponse)) {
                reponse = null;
            }
            log.debug("uri:{}\r\nheader{}\r\nbody{}\r\nresponse:{}", uri, header, body, reponse);
            return reponse;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * ���Chatbot ״̬<br/>
     * <li>| ��� | �ֶ�        | �������� | �ֶγ��� | ��ѡ���� | ����                                     |</li>
     * <li>| ---- | ----------- | -------- | -------- | -------- | ------------------------------------ |</li>
     * <li>| 1    | accessTagNo | string   | 64       | M        | Chatbot�����ɹ��󷵻��ֶ�accessTagNo   |</li>
     * <li>| 2    | type        | int      | 4        | M        | �����߱�־��1:���ߣ�2:���ߣ�3 ����      |</li>
     *
     * @param task
     * @return
     */
    public boolean isOnlineUpdate(TaskInner task) {
        DataSource ds = task.ds;
        JsonObject oldbody = task.body;
        JsonObject body = new JsonObject();
        String accessTagNo = Util.getElementAsString(oldbody, "accessTagNo");
        // 1 Ĭ������״̬
        String type = Util.getElementAsString(oldbody, "enable", "1");
        body.addProperty("accessTagNo", accessTagNo);
        body.addProperty("type", type);
        HttpServletRequest request = task.request;
        HttpServletResponse response = task.response;
        boolean flag = false;
        String uri = LoadProperties.systemProperties.getProperty("csp.cucc.isOnlineUpdateUri");
        String rsp = "";
        if (task.doretryRMI) {
            rsp = doHttps(uri, body, " application/json");
        }
        String resbody1 = "";
        if (!Util.isNull(rsp)) {
            JsonObject obj = requestBody2Json(rsp);
            if (obj != null && !obj.isJsonNull()) {
                String code = Util.getElementAsString(obj, "code");
                if (CODE_SUCCESS.equals(code)) {
                    flag = true;
                    task.doretryRMI = false;
                    resbody1 = resBodyJson("200", rsp, null);
                    isOnlineUpdateSQL(task, body, rsp, accessTagNo, oldbody);
                } else if (CODE_TOKEN_TIME_OUT.equals(code)) {
                    accessToken(ds, request);
                } else {
                    flag = true;
                    task.doretryRMI = false;
                    resbody1 = resBodyJson(!task.add2db ? "200" : "500", rsp, null);
                }
            }
        } else {
            resbody1 = resBodyJson("500", "server request failed", null);
        }
        try {
            sendResponse(BaseHandler.getIpAddress(request), resbody1, 200, request, response);
            try {
                logger(ds, "info", "chatbot", "offlineChatbot request ready request  " + uri + "body " + gson.toJson(body), resbody1, BaseHandler.getIpAddress(request), request, "CuccCspImpl.offlineChatbot");
            } catch (IOException e2) {
                e2.printStackTrace();
            }
            return flag;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return flag;
    }

    /**
     * ���chatbot������״̬
     * @param task
     * @param body
     * @param rsp
     * @param accessTagNo
     * @param oldbody
     */
    private void isOnlineUpdateSQL(TaskInner task, JsonObject body, String rsp, String accessTagNo, JsonObject oldbody){
        if (task.add2db) {
            // �޸�enable����״̬
            String type = body.get("type").getAsString();
            body.addProperty("enable", type);
            task.add2db = !updateOnlineStatusChatbot(gson, body, ds);
//            task.add2db = !updateOnlineStatusChatbot(gson, body, ds);
            String auth = task.request.getHeader("Authorization").replaceAll("\"", "");
            switch (type) {
                case "1":
                    insertOperationLog(auth, "chatbot:����", 1, rsp, accessTagNo, gson.toJson(oldbody));
                    break;
                case "2":
                    insertOperationLog(auth, "chatbot:����", 2, rsp, accessTagNo, gson.toJson(oldbody));
                    break;
                default:
                    insertOperationLog(auth, "chatbot:�ڲ�", 3, rsp, accessTagNo, gson.toJson(oldbody));
                    break;
            }
        }
    }

    /**
     * <p>����������</p>
     * <li>| ��� | �ֶ�        | �������� | ���� | ��ѡ�� �� | ����                                                         |</li>
     * <li>| 1    | agreement   | string   | 25   | C         | Э �� 1:http��2:https                                        |</li>
     * <li>| 2    | token       | string   | 128  | C         | ������ token����� 16 λ                                     |</li>
     * <li>| 3    | url         | string   | 150  | C         | �ص� URL ��ַ��Ŀ¼  �� http://��ͷ��IP+�˿ڵ���ʽ����������������Ϣ״̬�����Լ���Ϣ֪ͨ|</li>
     * <li>| 4    | accessTagNo | string   | 64   | M         | ���� Chatbot ʱ,���ص� Chatbot ��Ψһʶ���ʶ                |</li>
     * <li>| 5    | enable      | int      | 4    | M         | Chatbot �ӿ��Ƿ����ã�1:���ã�0:������                       |</li>
     * <p>
     * {
     * "accessTagNo":"9bb127ae3a5e43d8baece177564788ca",
     * "agreement":"1",
     * "token":"wfXbHLeIqKCkJJSI",
     * "url":"http://127.0.0.1",
     * "enable":1
     * }
     * </p>
     */
    public boolean updateDeveloper(TaskInner task) {
        DataSource ds = task.ds;
        JsonObject body = task.body;
        JsonObject updateDeveloperBody = new JsonObject();
        String token = LoadProperties.systemProperties.getProperty("csp.cucc.token");
        String agreement = Util.getElementAsString(body, "agreement");
        updateDeveloperBody.addProperty("agreement", agreement);
        String accessTagNo = Util.getElementAsString(body, "accessTagNo");
        updateDeveloperBody.addProperty("token", token);
//        String msgNotifyUrl = Util.getElementAsString(body, "msgNotifyUrl");
        String publicAddressCsp = "";
        if ("1".equals(agreement)) {
            String http = "http://";
            publicAddressCsp = http + LoadProperties.systemProperties.getProperty("csp.publicAddressHttp");
//
//            if (!Util.isNull(msgNotifyUrl)) {
//                if (msgNotifyUrl.startsWith("https:")) {
//                    msgNotifyUrl = msgNotifyUrl.replaceFirst("https:", "http:");
//                }
//                if (!msgNotifyUrl.startsWith("http:")) {
//                    msgNotifyUrl = "http://" + msgNotifyUrl;
//                }
//            }
        } else {
            String https = "https://";
            publicAddressCsp = https + LoadProperties.systemProperties.getProperty("csp.publicAddressHttps");
//            if (!Util.isNull(msgNotifyUrl)) {
//                if (msgNotifyUrl.startsWith("http:")) {
//                    msgNotifyUrl = msgNotifyUrl.replaceFirst("http:", "https:");
//                }
//                if (!msgNotifyUrl.startsWith("https:")) {
//                    msgNotifyUrl = "https://" + msgNotifyUrl;
//                }
//            }
        }
        updateDeveloperBody.addProperty("url", publicAddressCsp);
        updateDeveloperBody.addProperty("accessTagNo", accessTagNo);
        // TODO δ���Գ������Ҫ�ϰ����
        updateDeveloperBody.addProperty("enable", 1);

        HttpServletRequest request = task.request;
        String auth = request.getHeader("Authorization").replaceAll("\"", "");
        Claims claimsFromToken = jwtOperatorUtil.getClaimsFromToken(auth);
        String loginname = claimsFromToken.get("loginname").toString();
        String uri = LoadProperties.systemProperties.getProperty("csp.cucc.updateDeveloperUri");
        boolean flag = false;
        String resbody1 = "";
        if (task.doretryRMI)
            resbody1 = doHttps(uri, updateDeveloperBody, " application/json");
        // TODO
//        resbody1 = "{\n" +
//                "\"code\": 0,\n" +
//                "\"message\":\"�����޸ĳɹ�\",\n" +
//                "\"data\": \n" +
//                "{\n" +
//                "\"appId\":\"Nbugeraa\",\n" +
//                "\"appKey\":\"YD656013361875341312\"\n" +
//                " } }";
        log.debug("updateDeveloper response {}", resbody1);
        if (!Util.isNull(resbody1)) {
            JsonObject resObject = requestBody2Json(resbody1);
            String code = Util.getElementAsString(resObject, "code");
            if (CODE_SUCCESS.equals(code)) {
                flag = true;
                task.doretryRMI = false;
                JsonObject data = resObject.getAsJsonObject("data");
                data.addProperty("accessTagNo", accessTagNo);
                data.addProperty("appkey", Util.getElementAsString(data, "appKey"));
                data.addProperty("appid", Util.getElementAsString(data, "appId"));
//                data.addProperty("auditStatus", 16);
//                data.addProperty("enable", 3);
//                data.addProperty("msgNotifyUrl", body.get("url").getAsString());
                data.addProperty("msgNotifyUrl", publicAddressCsp);
//                data.addProperty("token", body.get("token").getAsString());
                data.addProperty("token", token);
                data.addProperty("agreement", body.get("agreement").getAsString());
                updateDeveloper(gson, data, ds);
                insertOperationLog(loginname, "�������������ͨ��", 16, resbody1, accessTagNo, gson.toJson(body));
//                isOnlineUpdate(task);
            } else if (CODE_TOKEN_TIME_OUT.equals(code)) {
                accessToken(ds, request);
            } else {
                flag = true;
                task.doretryRMI = false;
            }
        } else {
            resbody1 = resBodyJson("500", "deleloper server request failed", null);
            flag = true;
        }
        try {
            //TODO ��ֱ��ҳ����� ���ض��response
				sendResponse(BaseHandler.getIpAddress(request), resbody1, 200, request, task.response);
            try {
                logger(ds, "info", "developer", "chatbot developer request ready request  " + uri + "body " + gson.toJson(body), resbody1, BaseHandler.getIpAddress(request), request, "CuccCspImpl.developer");
            } catch (IOException e2) {
                e2.printStackTrace();
            }
            return flag;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return flag;
    }

    @Override
    public String selectCspCustomer(TaskInner task) {
        DataSource ds = task.ds;
        JsonObject body = task.body;
        HttpServletRequest request = task.request;
        HttpServletResponse response = task.response;
        String uri = LoadProperties.systemProperties.getProperty("csp.cucc.selectCspCustomerUri");
//        body.addProperty("token", LoadProperties.systemProperties.getProperty("csp.cucc.token"));
        String resbody1 = "";
        if (task.doretryRMI)
            resbody1 = doHttps(uri, body, " application/json");
        if (!Util.isNull(resbody1)) {
            JsonObject resObject = requestBody2Json(resbody1);
            String code = Util.getElementAsString(resObject, "code");
            if (CODE_SUCCESS.equals(code)) {
                task.doretryRMI = false;
            } else if (CODE_TOKEN_TIME_OUT.equals(code)) {
                accessToken(ds, request);
            } else {
                task.doretryRMI = false;
            }
        } else {
            resbody1 = resBodyJson("500", "QueryCustomer   request failed", null);
        }
        try {
            if (!task.operatorType.isBlank() && !"updateStatus".equals(task.operatorType))
                sendResponse(BaseHandler.getIpAddress(request), resbody1, 200, request, response);
            try {
                logger(ds, "info", "selectCspCustomer", "chatbot developer request ready request  " + uri + "body " + gson.toJson(body), resbody1, BaseHandler.getIpAddress(request), request, "CuccCspImpl.selectCspCustomer");
            } catch (IOException e2) {
                e2.printStackTrace();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return resbody1;
    }

    @Override
    public JsonObject reBuildCustomers(JsonObject body) {
        JsonObject rcsRegisterInfo = body.getAsJsonObject("rcsRegisterInfo");
        JsonObject rcsInfo = body.getAsJsonObject("rcsInfo");
        JsonObject rcsContractInformation = body.getAsJsonObject("rcsContractInformation");
        JsonObject rcsLegalP = body.getAsJsonObject("rcsLegalP");

        rcsInfo.remove("operatorarea");
        rcsInfo.remove("operatorsex");
        rcsInfo.remove("contractNo");
        rcsInfo.remove("operatoripfrom");
        rcsInfo.remove("legalUserId");
        rcsInfo.remove("operatorUserId");
        JsonArray array = new JsonArray();
        array.add(Util.getElementAsString(rcsInfo, "operatorIdentityPic1"));
        array.add(Util.getElementAsString(rcsInfo, "operatorIdentityPic2"));
        // ��ӳ�����ݷŵ��ڴ���
        this.getRegionMapping();
        String province = rcsInfo.get("province").getAsString();
        String city = rcsInfo.get("city").getAsString();
        if (cuccRegionsMap.containsKey(province)) {
            rcsInfo.addProperty("province", cuccRegionsMap.get(province));
        }
        if (cuccRegionsMap.containsKey(city)) {
            rcsInfo.addProperty("city", cuccRegionsMap.get(city));
        }
        rcsInfo.add("operatorIdentityPic", array);

        rcsInfo.remove("operatorIdentityPic1");
        rcsInfo.remove("operatorIdentityPic2");


        JsonObject resbody = new JsonObject();
        resbody.add("rcsRegisterInfo", rcsRegisterInfo);
        resbody.add("rcsInfo", rcsInfo);
        resbody.add("rcsContractInformation", rcsContractInformation);
        rcsLegalP.remove("operatorPhone");
        JsonArray identification = new JsonArray();
        identification.add(Util.getElementAsString(rcsLegalP, "identificationCounter"));
        identification.add(Util.getElementAsString(rcsLegalP, "identificationStraight"));
        rcsLegalP.add("identificationPic", identification);
        rcsLegalP.remove("identificationCounter");
        rcsLegalP.remove("identificationStraight");
        resbody.add("rcsLegalP", rcsLegalP);
        return resbody;
    }

    private void getRegionMapping() {
        // ��ȡ��ͨӳ������
        try {
            if (cuccRegionsMap == null || cuccRegionsMap.isEmpty()) {
                cuccRegionsMap = new HashMap<>();
                String sqlID = "cuccRegionsMap";
                String sql = XmlSqlGenerator.getSql(sqlID).exeSql;
                JsonArray json = SqlUtil.queryForJson(ds, sql);
                Iterator<JsonElement> it = json.iterator();
                while (it.hasNext()) {
                    JsonElement next = it.next();
                    String name = next.getAsJsonObject().get("name").getAsString();
                    String mName = next.getAsJsonObject().get("mName").getAsString();
                    cuccRegionsMap.put(name, mName);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private String customer = null;

    /**
     * �޸Ŀͻ�״̬
     * @param task
     * @return
     */
    public boolean updateCustomerStatus(TaskInner task) {
        boolean flag = Boolean.FALSE;
        try {
            TaskInner inner = new TaskInner();
            inner.body = task.body;
            inner.operatorType = "updateStatus";
            String result = this.selectCspCustomer(task);
            JsonObject object = gson.fromJson(result, JsonObject.class);
            if (!object.isJsonNull()) {
                JsonObject json = new JsonObject();
                if (object.get("code").getAsInt() == 0
                        && !object.get("data").getAsJsonObject().get("rcsInfo").isJsonNull()) {
                    inner.doretryRMI = false;
                    json.addProperty("auditStatus", 1);
                    json.addProperty("cspEcNo", task.body.get("cspEcNo").getAsString());
                    // �޸Ŀͻ�״̬
                    String sqlID = "updateCustomerStatus";
                    String sql = XmlSqlGenerator.getSqlByJson(sqlID, null, json);
                    boolean fan = SqlUtil.updateRecords(ds, sql);
                    if (!fan)
                        inner.add2db = true;
                    else
                        inner.add2db = false;
                    flag = Boolean.TRUE;
                } else
                    inner.doretryRMI = true;
            }
            retryTaskQueue.add(inner);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return flag;
    }

    /**
     *  ������־
     * @param operationUse
     * @param operationType
     * @param operationStatus
     * @param operationResult
     * @param cspEcNo
     * @param requestBody
     */
    public void insertOperationLog(String operationUse, String operationType,
                                   Integer operationStatus, String operationResult, String cspEcNo, String requestBody) {

       try {
           OperationLogService operation = Provider.injector.getInstance(OperationLogService.class);
           Map map = new HashMap();
           map.put("operationTime", String.valueOf(LocalDateTime.now()));
           map.put("operationUse", operationUse);
           map.put("operationType", operationType);
           map.put("operationStatus", operationStatus);
           map.put("operationResult", operationResult);
           map.put("cspEcNo", cspEcNo);
           map.put("requestBody", requestBody);
           map.put("type", 2);
           map.put("ISP", "cucc");
           operation.addOperationLog(map);
       } catch (Exception e) {
           e.printStackTrace();
       }
    }

    /**
     * ��ѯ��־
     * @param task
     * @return
     */
    public boolean selOperationLog(TaskInner task) {
        try {
            task.doretryRMI = false;
            OperationLogService operation = Provider.injector.getInstance(OperationLogService.class);
            String authorization = task.request.getHeader("Authorization").replaceAll("\"", "");
            String loginname = jwtOperatorUtil.getClaimsFromToken(authorization).get("loginname").toString();
            String cspEcNo = task.body.get("cspEcNo").getAsString();
            JsonArray array = operation.selOperationLog(loginname, cspEcNo);
            String send=resBodyJson("200","sucess",array);
            sendResponse(BaseHandler.getIpAddress(task.request), send, 200, task.request, task.response);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
}
