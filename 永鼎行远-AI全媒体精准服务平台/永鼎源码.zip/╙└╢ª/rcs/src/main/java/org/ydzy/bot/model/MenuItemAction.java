package org.ydzy.bot.model;

import com.google.gson.JsonElement;

public class MenuItemAction extends MenuItem{
	public MenuItemAction(int menuid, int parentid, JsonElement json) {
		super(menuid, parentid);
		this.action = json;
	}

	public MenuItemAction(int menuid) {
		super(menuid);
	}
	
	/** action */
	public JsonElement action;
	
	
}
