package org.ydzy.jdbc.control.result.datepattern;

import java.text.ParseException;
import java.util.Calendar;
import java.util.List;

import org.ydzy.rcs.Provider;


public class DateTnameHandler {
	static enum timepattern{
		hourTname(0,"hourTname"),
		dayTname(86400l,"dayTname"),
		weekTname(604800,"weekTname"),
		monthTname(2592000,"monthTname"),
		quarterTname(7776000,"quarterTname"),
		yearTname(31104000,"yearTname");
		long timeInterval;
		String name;
		timepattern(long timeInterval,String name ){
			this.timeInterval=timeInterval;
			this.name=name;
		}
		public static timepattern fromType(long interval) {  
            for (timepattern type : timepattern.values()) {  
                if (type.timeInterval==interval) {  
                    return type;  
                }  
            }  
            return hourTname;  
        }  
	}
	
	public static  List<String> matchTname(String tablePattern, long timeInterval,String sDate, String eDate,List<String> tnames) throws ParseException {
		
		Calendar c1 = Calendar.getInstance();
		Calendar c2 = Calendar.getInstance();
		ITime time =loadTimeCenter(timeInterval);
		List<String> tablelist=time.reckonName(tablePattern,timeInterval,sDate,eDate,c1,c2);
		tnames.addAll(tablelist);
		return tablelist;
	}
	public  static ITime loadTimeCenter(long timeInterval)
	{
		ITime time= null;
		timepattern tm=timepattern.fromType(timeInterval);
		time	=Provider.getInstance(ITime.class, tm.name);
		return time;
	}

}
