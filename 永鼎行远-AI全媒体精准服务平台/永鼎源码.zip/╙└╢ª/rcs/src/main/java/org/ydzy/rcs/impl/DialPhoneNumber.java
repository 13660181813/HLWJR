package org.ydzy.rcs.impl;

import com.google.inject.Singleton;

import org.ydzy.rcs.SuggestionDisplay;
import org.ydzy.rcs.annotation.Description;
import org.ydzy.util.StringUtils;

@Singleton
@Description(value="dialPhoneNumber")
public class DialPhoneNumber implements SuggestionDisplay{
	String dialer = "{\r\n" 
			+ "\"action\":\r\n" 
			+ "	{\r\n" 
			+ "			\"displayText\":\"%s\",\r\n"
			+ "			\"dialerAction\":\r\n" 
			+ "			{\r\n" 
			+ "				\"dialPhoneNumber\":{\r\n"
			+ "				\"phoneNumber\":\"%s\",\r\n" 
			+ "				\"fallbackUrl\":\"%s\"\r\n" 
			+ "				}\r\n" 
			+ "			}\r\n" 
			+ "	}\r\n"
			+ "}\r\n";
	@Override
	public String suggestionHtml(String[] args) {
		int length=args.length;
		// ARGS[0] DISPLAY TEXT
		return StringUtils.format(dialer, length<=0?"":args[0], length<=1?"":args[1].replace("��", ","), length<=2?"":args[2]);
	}

}
