package org.ydzy.rcs.impl;

import java.util.List;

import org.ydzy.handler.BaseRcsContext;
import org.ydzy.rcs.MessagesInter;
import org.ydzy.rcs.annotation.Description;
import org.ydzy.rcs.entity.CmccMsg;
import org.ydzy.rcs.entity.ReceiveEntity;

import com.google.gson.JsonObject;
import com.google.inject.Singleton;

/**�й��ƶ����ݽṹ ��Ϣ����
 * @author XFDEP
 *
 */
@Singleton
@Description(value="huaweiMessageImp")
public class HuaweiMessagePack extends CmccMessagePack implements MessagesInter {
	@Override
	public String body(ReceiveEntity requestObject, JsonObject eobject, BaseRcsContext context, List<MessageBody> body) {
		CmccMsg outmsg=this.makeMsg(requestObject, eobject, context, body);
		outmsg.outboundIMMessage.shortMessageSupported = false;
		outmsg.outboundIMMessage.bodyText = "<![CDATA[" + outmsg.outboundIMMessage.bodyText + "]]>";
		String rst= makeMsg(outmsg, "json");
		return rst;
	}

}
