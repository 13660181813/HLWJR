package org.ydzy.bot;

import org.ydzy.handler.BaseRcsContextProvidor;
import org.ydzy.handler.RcsSession;

import java.util.Map;

/**
 * @author zxw
 * @create 2021/11/30
 */
public interface IRedirectHandler {
    public static final String BEAN_INSTANCE_KEY_PREFIX = "bot.redirect.h5.handler.";

    String transForm(Map<String, String[]> paramsMap, BaseRcsContextProvidor contextProvidor);

    String transForm(String params, String url, BaseRcsContextProvidor contextProvidor, RcsSession session);
}
