package org.ydzy.bot;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * ����֤, ���еĶ���ͨ��
 * @author ljp
 *
 */
public class VerifyNone implements IVerify {
	public static final String KEY_VERIFY_NONE = KEY_VERIFY + "none";

	static final Logger log = LoggerFactory.getLogger(VerifyNone.class);
	
	@Override
	public Object verify(RequestContext request, BotInfo bi) throws VerifyError{
		//Do nothing;
		return null;
	}
	
}
