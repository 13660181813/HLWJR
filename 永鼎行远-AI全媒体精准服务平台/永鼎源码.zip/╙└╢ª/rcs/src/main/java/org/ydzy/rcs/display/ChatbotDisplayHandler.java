package org.ydzy.rcs.display;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.ydzy.handler.BaseHandler;
import org.ydzy.rcs.db.XmlSqlGenerator;
import org.ydzy.rcs.display.bean.DisplayBean;
import org.ydzy.rcs.module.LoadProperties;
import org.ydzy.util.ParamUtils;
import org.ydzy.util.SqlUtil;
import org.ydzy.util.StreamsUtil;
import org.ydzy.util.Util;

import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.sql.SQLException;
import java.time.Instant;
import java.util.*;

public class ChatbotDisplayHandler extends BaseHandler {
    private static final Logger log = LoggerFactory.getLogger(ChatbotDisplayHandler.class);

    private static final Map<String, JsonObject> roleMap = new LinkedHashMap<>();

    private static JsonArray businessTypes = null;

    private synchronized JsonArray getBusinessTypes() {
        if (businessTypes == null) {
            String sqlid = "placebychatbot";
            try {
                String sql = XmlSqlGenerator.getSql(sqlid).exeSql;
                businessTypes = SqlUtil.queryForJson(ds, sql);
            } catch (Exception e) {
                log.error("initBusinessTypes error.", e);
            }
        }
        return businessTypes;
    }

    @Override
    public void handle(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        String bodyStr = StreamsUtil.copyToString(request.getInputStream(), StandardCharsets.UTF_8);
        String remoteAddr = getIpAddress(request);
        DisplayBean displayBean = gson.fromJson(bodyStr, DisplayBean.class);
        // ��ȡ��ɫ�б�������
        if (roleMap.isEmpty()) {
            synchronized (roleMap) {
                if (roleMap.isEmpty()) {
                    JsonArray elements;
                    try {
                        elements = SqlUtil.queryForJson(ds, XmlSqlGenerator.getSqlstr("chatbotDisplay-roleList"));
                        if (elements.size() > 0) {
                            for (JsonElement element : elements) {
                                JsonObject jsonObject = element.getAsJsonObject();
                                roleMap.put(jsonObject.get("username").getAsString(), jsonObject);
                            }
                        }
                    } catch (SQLException e) {
                        log.error("query roles error", e);
                    }
                }
            }
        }
        JsonArray elements;
        switch (displayBean.getType()) {
            case "listRoles": // ��ȡ��ɫ�б�
                elements = new JsonArray();
                for (Map.Entry<String, JsonObject> entry : roleMap.entrySet()) {
                    JsonObject jsonObject = new JsonObject();
                    jsonObject.addProperty("username", entry.getValue().get("username").getAsString());
                    jsonObject.addProperty("desc", Util.getElementAsString(entry.getValue(), "desc"));
                    jsonObject.addProperty("id", entry.getValue().get("id").getAsString());
                    jsonObject.addProperty("accesstagno", entry.getValue().get("accesstagno").getAsString());
                    jsonObject.addProperty("chatbotid", entry.getValue().get("chatbotid").getAsString());
                    if (!entry.getValue().get("jump2case").isJsonNull()) {
                        jsonObject.addProperty("jump2case", entry.getValue().get("jump2case").getAsString());
                    } else {
                        jsonObject.addProperty("jump2case", "0");
                    }
                    elements.add(jsonObject);
                }
                sendResponse(remoteAddr, resBodyJson("200", "success", elements), HttpServletResponse.SC_OK, request, response);
                break;
            case "caseDealList": // �������б�
                Map<String, Object> params = new HashMap<>() {{
                    put("phone", displayBean.getPhone());
                    put("chargePhone", displayBean.getMdn());
                    put("username", displayBean.getUsername());
                    put("chatbotid", displayBean.chatbotid);
                }};
                try {
                    elements = SqlUtil.queryForJson(ds, XmlSqlGenerator.getSqlByJson("chatbotDisplay-caseDealList", null, JsonParser.parseString(gson.toJson(params, Map.class)).getAsJsonObject()));
                    String chatbotUrl = getChatbotUrl();
                    if (elements.size() > 0) {
                        for (JsonElement element : elements) {
                            JsonObject jsonObject = element.getAsJsonObject();
                            jsonObject.addProperty("targetUrl", makeTargetUrl(chatbotUrl, jsonObject, displayBean));
                            jsonObject.addProperty("progressUrl", makeProgressUrl(jsonObject));
                        }
                    }
                    sendResponse(remoteAddr, resBodyJson("200", "success", elements), HttpServletResponse.SC_OK, request, response);
                } catch (Exception e) {
                    log.error("list caseDealList error:", e);
                    sendResponse(remoteAddr, resBodyJson("500", "query error", null), HttpServletResponse.SC_OK, request, response);
                }
                break;
            case "userChatbotUrl": // ���ݽ�ɫ������������
                if (Util.isNull(displayBean.getUsername())) {
                    sendResponse(remoteAddr, resBodyJson("500", "ȱʧ����", null), HttpServletResponse.SC_OK, request, response);
                    return;
                }
                sendResponse(remoteAddr, resBody("200", "success", Collections.singletonMap("targetUrl", makeTargetUrl(getChatbotUrl(), null, displayBean))), HttpServletResponse.SC_OK, request, response);
                break;
            case "getBusinessType": // ��ȡҵ�񳡾�
                sendResponse(remoteAddr, resBodyJson("200", "success", getBusinessTypes()), HttpServletResponse.SC_OK, request, response);
                break;
            default:
                sendResponse(remoteAddr, resBodyJson("500", "����֧�ֵĲ���", null), HttpServletResponse.SC_OK, request, response);
        }

    }

    private String makeProgressUrl(JsonObject jsonObject) {
        StringBuilder builder = new StringBuilder(LoadProperties.systemProperties.getProperty("webUiFormUrl") + "/alarm?");
        builder.append("phone=").append(Util.getElementAsString(jsonObject, "phone"));
        builder.append("&chatbotid=").append(URLEncoder.encode(Util.getElementAsString(jsonObject, "chatbotid"), StandardCharsets.UTF_8));
        builder.append("&userName=weixinMPgz110&isuser=true");
        return builder.toString();
    }

    private String getChatbotUrl() {
        return LoadProperties.systemProperties.getProperty("webUiDialogUrl") + "/chat/box?";
    }

    private String makeTargetUrl(String webUrl, JsonObject caseInfo, DisplayBean displayBean) {
        JsonObject roleInfo = roleMap.get(displayBean.getUsername());
        String demoUrl = Util.getElementAsString(roleInfo, "demoUrl");
        if (!Util.isNull(demoUrl)) {
            JsonElement demoUrlElement = JsonParser.parseString(demoUrl);
            if (demoUrlElement != null && !demoUrlElement.isJsonNull()) {
                JsonObject object = demoUrlElement.getAsJsonObject();
                String url = Util.getElementAsString(object, "url");
                if (!Util.isNull(url)) {
                    Map<String, String> params = new HashMap<>();
                    params.put("weburl", LoadProperties.systemProperties.getProperty("webUiUrl"));
                    params.put("Username", displayBean.getUsername());
                    params.put("phone", displayBean.getMdn());
                    // etc.. params
                    // ...
                    return ParamUtils.formatVues(url, params);
                }
            }
        }
        String nonce = Base64.getEncoder().encodeToString(String.valueOf(Math.random() * new Random().nextInt(10000)).getBytes(StandardCharsets.UTF_8));
        String password = Util.getElementAsString(roleInfo, "password");
        long timestamp = Instant.now().getEpochSecond();
        byte[] sha256 = Util.digest(password, nonce, timestamp + "");
        String mySign = Base64.getEncoder().encodeToString(sha256);

        webUrl += "accessTagNo=" + displayBean.getAccessTagNo();
        webUrl += "&Username=" + displayBean.getUsername();
        webUrl += "&timestamp=" + timestamp;
        webUrl += "&nonce=" + nonce;
        webUrl += "&signature=" + mySign;

        if (caseInfo != null) {
            caseInfo.addProperty("signature", mySign);
            caseInfo.addProperty("timestamp", timestamp + "");
            caseInfo.addProperty("nonce", nonce);
            caseInfo.addProperty("Username", displayBean.getUsername());
        }
        if ("user".equals(displayBean.id))
            return makeUserUrl(webUrl, displayBean);
        else
            return makeTargetUrl2(webUrl, caseInfo, displayBean);
    }


    // ����chatbotUrl
    private String makeUserUrl(String webUrl, DisplayBean displayBean) {
        webUrl += "&driving=" + displayBean.getDriving();
        webUrl += "&nick=liu";
        webUrl += "&phone=" + displayBean.getPhone();
        return webUrl;
    }

    // �����ں��˹���ϯ��Ľ�ɫ
    private String makeTargetUrl2(String webUrl, JsonObject caseInfo, DisplayBean displayBean) {
        String sid = null;
        if (caseInfo != null && !caseInfo.get("sid").isJsonNull()) {
            sid = caseInfo.get("sid").getAsString();
        }
        if (Util.isNull(sid)) {
            sid = displayBean.getSid();
        }
        if (Util.isNull(sid)) {
            sid = "YDXYtestchatbot_" + Instant.now().toEpochMilli();
        }

        String nick = null;
        if (caseInfo != null && !caseInfo.get("policeNick").isJsonNull()) {
            nick = caseInfo.get("policeNick").getAsString();
        }
        if (Util.isNull(nick)) {
            nick = "xu";
        }
        String sendTo = null;
        if (caseInfo != null && !caseInfo.get("phone").isJsonNull()) {
            sendTo = caseInfo.get("phone").getAsString();
        }
        if (Util.isNull(sendTo)) {
            sendTo = displayBean.getPhone();
        }
        if (!sid.startsWith("YDXY")) {
            String[] tmp = Util.getElementAsString(caseInfo, "sid").split("_");
            if (tmp.length > 0) {
                sid = tmp[0];
                if (tmp.length > 1) {
                    sendTo = tmp[1];
                }
            }
        }
        webUrl += "&sid=" + sid;
        webUrl += "&sendTo=" + sendTo;
        webUrl += "&driving=" + displayBean.getUsername();
        webUrl += "&mdn=" + displayBean.getMdn();
        webUrl += "&nick=" + URLEncoder.encode(nick, StandardCharsets.UTF_8);
        return webUrl;
    }
}
