package org.ydzy.config;

import java.util.Properties;

import org.slf4j.Logger;
import org.ydzy.rcs.annotation.Description;
import org.ydzy.rcs.module.LoadProperties;

import com.google.inject.Inject;
import com.google.inject.Singleton;
import com.google.inject.name.Named;

@Singleton
@Description(autoInstance = true,value = "ApplicationConfig")
public class ApplicationConfig {
	private static Logger log=org.slf4j.LoggerFactory.getLogger(ApplicationConfig.class);
	@Inject
	@Named("SystemProp")
	public Properties applicationProp;
	// �̻�appid
	@Inject
	@Named("alipay.appid")
	public  String ALPAY_APPID = "2021002133667293";
	// ˽Կ pkcs8��ʽ��
	@Inject
	@Named("alipay.rsa_private_key")
	public  String ALPAY_RSA_PRIVATE_KEY = "MIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQCd4g8l2fhiuc8GtSocYNsjQGrsIULAm4UAsco3+IxsCvINo0bfQzARyvfRRUH2pWjFfn4a6N6stcu77HMsaIyNrxGTzQW7o97Sa5QXY2B2Bhtf4mqQtJrG+04iWfapyOnmg3A1h9gSh2y48D0AGkGw6NDwvD3g2cIu4u3fafvzPp9HVK2wyL7NHZEa350odvOVmQ3m4vAe+95Mvo4KCUK8qyt6W1ZyzYzOB2Los4WfEl1GCKueGvG6yMH1Mnt0LyOO6ElIinddbiXLEadvAVhpi1IkzQujufm+iI2Ay/ARFBrWNTZvlano09D+cEwzvCw3jDRsEKG0S/4t3IYRfRq9AgMBAAECggEBAIP7sHISD0Ro1BplZDio90g216th+q2M1NjJx6SWkLzZQZQJBHwrbInTROuanBQWHsnKfpz8QvnaV+BXP8jF9YmT6nvGDp7X1LPO3tPWbZL8c/HqEu+5KxJgjubEkiFJJc9f3XPCheynbUoE+tmVGYlMdy5oDspi/6O2bOgxbz/dqiPTklXr9tnp519mwHLjtjNSR8wBNbSMvKf1+bmLyPfm5w1ihCc9d8pFgoV38OECBWOtQfsVlPmAjn0P359q/PPPWxjCJ0gRPLbEGh9V+VPzABB2KP2WKLhdrmi0eZbJ1z+UgV8tlpjL3M06FyqtDcLzmynYMV210DGNaW6uPTkCgYEA8NnDzzA3lfYWeC6EoHynHXm9jtH+AKhXFjjStiUAPXg0sxnqcokLC7KHmh4VehZlxs1rLr36Nksfjxll1XfAY+KLv9RGTlTX4f3/S3Xu/twhiWLIBnang0+mKL85hL6CS4wgIt3P80OnqvOwtZx18/JYnW1LhII4E2GkopHnoIcCgYEAp9BUemMBhpDqI54iJg3ynXOspHZMF4TpgJwg18aBhLjhMz8/eUOSRINBcktznXVtfESWBbqNRR4fwVAob6xxKHqTqVmDg09BPuBBDem52sgcSEUPfVwaN8nB9hN9dLyiP4pS+e1OedK9Hf2OyzYqJ0L2KWAnEUMNkA5sYKIxD5sCgYEAgV9H2cv5n7jPOwEpxpcOoTuagdP0j1/dX5doP+TCK0KddDMQhzNr1n2wby2HtcvAIbiHwVTUyUMzEYe/9plbo4u2K3WXyk2ypLbt4hfYJ9gQv55q+WXU9yjahPqqp845aOE9Bd2F7RLDRoWdvv/rL/1WckGaFfRosKh7acPb2pMCgYAChv2uti0AtNAB51DGV/Fuc56G/40X0ZWerTtFZKTwtcQWfH5dOipKw9tJeF9uYKVceL/1qCCWiOSbibSCMgumO2pb45A6ewgVhVUVe46j/92FLR0Vmzx92JkGNrbt+iVLZa7oOq2y4fydJgNvhgpOexCwANW1yde7cqwpLGgmvwKBgBt2n/igkvfwPqzNM/+yfsMG62MwoRZcDzPgik1V+shcyNQrY/8SFd7XKHKKfXh+/P4Rloe4P+yjTm33T+EGcl6NdPh0a2Fn/inOq4ioI5Lcc3Rx+BQ5LhGDcGIzqv+nmHrC9vay+hme6M7RR4YvTSA+fAlPCHOc4IrYj0eBxXAS";
	// �������첽֪ͨҳ��·�� ��http://����https://��ʽ������·�������ܼ�?id=123�����Զ����������������������������
	@Inject
	@Named("alipay.notify_url")
	public  String ALPAY_NOTIFY_URL = LoadProperties.systemProperties+"/hw/ainotify";
	// ҳ����תͬ��֪ͨҳ��·�� ��http://����https://��ʽ������·�������ܼ�?id=123�����Զ���������������������������� �̻������Զ���ͬ����ת��ַ
	@Inject
	@Named("alipay.return_url")
	public  String ALIPAY_RETURN_URL =LoadProperties.systemProperties+"/hw/aiback";
	// �������ص�ַ
	@Inject
	@Named("alipay.gateway_url")
	public  String ALIPAY_GATEWAY_URL = "https://openapi.alipay.com/gateway.do";
	// ����
	@Inject
	@Named("alipay.charset")
	public  String ALIPAY_CHARSET = "UTF-8";
	// ���ظ�ʽ
	@Inject
	@com.google.inject.name.Named("alipay.format")
	public  String ALIPAY_FORMAT = "json";
	// ֧������Կ
	@Inject
	@com.google.inject.name.Named("alipay.alipay_public_key")
	public  String ALIPAY_PUBLIC_KEY = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAg8KeSsJG17OrJzsx10R5Io3oaC/ndyBH3r0EyFSi9ARLhQQ5HTRbbfRUSKmfV63rQFHSPAJ+WPxESzpqUGBh1aLmMP050vBCvQdIiMMLevuO3ppcmwMpS2/KJJJD7CzLNPZTvn12CpiuZgs/5tDB1J4qwmVaj47Mws3Uaadt3MHWpfpU95aBWqhFrYwhIdbSn9wVBRt4Zqf4AemFZsv2EUioGMv+8eE+p8NLW/RBFzxOkJA/UR5Td7Sph5dxFsdFhvQpe8HDf6sPIzVKZrGcZUkwYNxY6VJVXaBB7+9ReIM+XutMRsBSrj1PbaHbFT4Z2dZOMidMzrF8EhY7Rv/WwwIDAQAB";
	// ��־��¼Ŀ¼
	@Inject
	@com.google.inject.name.Named( "alipay.log_path")
	public  String ALIPAY_LOGPATH ="/log";
	// RSA2
	@Inject
	@com.google.inject.name.Named("alipay.signtype")
	public  String ALIPAY_SIGNTYPE = "RSA2";
	
	@Inject(optional = true)
	@com.google.inject.name.Named("baiduai.appKey")
	public  String BAIDUAI_APPKEY="cnTB5LGfiGE1AjlXoeHEe9fn";
	@Inject(optional = true)
	@com.google.inject.name.Named("baiduai.appSecret")
	public  String BAIDUAI_APPSECRET="jEihpQVnElVKp4DZua7E1GL4MTomdcIo";
	@Inject(optional = true)
	@com.google.inject.name.Named("baiduai.service_id")
	public  String BAIDUAI_SERVICE_ID = "S49303";
	
	@Inject(optional = true)
	@com.google.inject.name.Named("baiduai.naughty")
	public String BAIDUAI_NAUGHTY="";

	@Inject(optional = true)
	@com.google.inject.name.Named("login.loginMode")
	public String LOGIN_LOGINMODE = "local";
	@Inject(optional = true)
	@com.google.inject.name.Named("login.accessTokenUrl")
	public String LOGIN_ACCESSTOKEN_URL = "";
	@Inject(optional = true)
	@com.google.inject.name.Named("login.grantPermissionUrl")
	public String LOGIN_GRANT_PERMISSION_URL = "";
	@Inject(optional = true)
	@com.google.inject.name.Named("login.appServerName")
	public String LOGIN_APP_SERVERNAME = "";
	@Inject(optional = true)
	@com.google.inject.name.Named("login.appServerCode")
	public String LOGIN_APP_SERVERCODE = "";
	@Inject(optional = true)
	@com.google.inject.name.Named("login.usergroup.visitor")
	public String LOGIN_USERGROUP_VISITOR = "";
	//ǩ����Чʱ�䣬��λs
	@Inject(optional = true)
	@com.google.inject.name.Named("login.signature.expireInSecond")
	public long LOGIN_SIGNATURE_EXPIREIN_SECOND = 600L;
	//��token��Чʱ�䣬��λs
	@Inject(optional = true)
	@com.google.inject.name.Named("login.accessToken.expireInSecond")
	public long LOGIN_ACCESSTOKEN_EXPIREIN_SECOND = 3600L;
	//��token��Чʱ�䣬��λs
	@Inject(optional = true)
	@com.google.inject.name.Named("login.refreshToken.expireInSecond")
	public long LOGIN_REFRESHTOKEN_EXPIREIN_SECOND = 2592000L;
	//������ʱ�䣬��λs
	@Inject(optional = true)
	@com.google.inject.name.Named("login.channel.maxIdleTimeSecond")
	public long LOGIN_CHANNEL_MAXIDLETIME_SECOND = 300L;
	//�û���¼�������
	@Inject(optional = true)
	@com.google.inject.name.Named("login.error.count")
	public int LOGIN_ERROR_COUNT = 5;
	//�û���¼��������ﵽ��ֵ�󣬾ܾ���¼ʱ��
	@Inject(optional = true)
	@com.google.inject.name.Named("login.error.blocked.min")
	public int LOGIN_ERROR_BLOCKED = 10;
	@Inject(optional = true)
	@com.google.inject.name.Named("user.grant.AES.key")
	public String AES_KEY = "tl#@fibVu#s%s221";

	public void init()
	{
		if(LOGIN_ACCESSTOKEN_EXPIREIN_SECOND<=0)
		{
			log.warn("��token��Чʱ�䣬��λs ������Ч�� LOGIN_ACCESSTOKEN_EXPIREIN_SECOND is  {}  will resetTo {} ",LOGIN_ACCESSTOKEN_EXPIREIN_SECOND,3600L);
			LOGIN_ACCESSTOKEN_EXPIREIN_SECOND=3600L;
		}
		if(LOGIN_SIGNATURE_EXPIREIN_SECOND<=0)
		{
			log.warn("ǩ����Чʱ�䣬��λs ������Ч�� LOGIN_SIGNATURE_EXPIREIN_SECOND is  {}  will resetTo {} ",LOGIN_SIGNATURE_EXPIREIN_SECOND,600L);
			LOGIN_SIGNATURE_EXPIREIN_SECOND=600L;
		}
		if(LOGIN_REFRESHTOKEN_EXPIREIN_SECOND<=0)
		{
			log.warn("��token��Чʱ�䣬��λs ������Ч�� LOGIN_REFRESHTOKEN_EXPIREIN_SECOND is  {}  will resetTo {} ",LOGIN_REFRESHTOKEN_EXPIREIN_SECOND,2592000L);
			LOGIN_REFRESHTOKEN_EXPIREIN_SECOND=2592000L;

		}
		if(LOGIN_CHANNEL_MAXIDLETIME_SECOND<0)
		{
			log.warn("������ʱ�䣬��λs ������Ч�� LOGIN_CHANNEL_MAXIDLETIME_SECOND is  {}  will resetTo {} ",LOGIN_CHANNEL_MAXIDLETIME_SECOND,300L);
			LOGIN_CHANNEL_MAXIDLETIME_SECOND=300L;
		}
		
		long timeoutThreshold=LOGIN_ACCESSTOKEN_EXPIREIN_SECOND+LOGIN_CHANNEL_MAXIDLETIME_SECOND;
		
		if(LOGIN_REFRESHTOKEN_EXPIREIN_SECOND<timeoutThreshold) {
			long ntime = (long) (timeoutThreshold * 1.2);
			log.warn("��token��Чʱ�䣬��λs ������Ч��LOGIN_REFRESHTOKEN_EXPIREIN_SECOND {} should larger than LOGIN_ACCESSTOKEN_EXPIREIN_SECOND+LOGIN_CHANNEL_MAXIDLETIME_SECOND {} will reset to timeoutThreshold*120% {}", LOGIN_REFRESHTOKEN_EXPIREIN_SECOND, timeoutThreshold, ntime);
			LOGIN_REFRESHTOKEN_EXPIREIN_SECOND = ntime;
		}
		log.info("ǩ����Чʱ�䣬��λs {} ��token��Чʱ�䣬��λs {} ��token��Чʱ�䣬��λs {} ������ʱ�䣬��λs  {} ",
				LOGIN_SIGNATURE_EXPIREIN_SECOND,
				LOGIN_ACCESSTOKEN_EXPIREIN_SECOND,
				LOGIN_REFRESHTOKEN_EXPIREIN_SECOND,
				LOGIN_CHANNEL_MAXIDLETIME_SECOND
		);

	}

	public String BAIDULOCATION_CLIENT_ID = "RtsVYrYL2edIvV87G5hc5la4";
	public String BAIDULOCATION_CLIENT_SECRECT = "q2VTKqNOtzVWQxsVnN8Bm0HBTPxXmUnG";
	public String BAIDULOCATION_GRANT_TYPE = "client_credentials";
	@Inject(optional = true)
	@com.google.inject.name.Named("baidumap.location.appkey")
	public String BAIDULOCATION_APPKEY = "8b7ce527b7e6ca099300bf26d27886a4";

	public String BAIDUFACE_APP_ID = "24137163";
	public String BAIDUFACE_APP_KEY = "gMmiRRw7tiU701xFSX2rjbTV";
	public String BAIDUFACE_SECRET_KEY = "8h8eIPeXA3PD0FVLq3srZV4e0iQ1R5qd";

	public String BAIDUFACE_APP_ID2 = "24162481";
	public String BAIDUFACE_APP_KEY2 = "k0Oo9DTDx7ft7qSTgUlnrMLX";
	public String BAIDUFACE_SECRET_KEY2 = "uYiXACTi6eLKuryiuc60j1OvK5RKRtsm";


	public String BAIDULOCATION_OAUTH_URL = "https://aip.baidubce.com/oauth/2.0/token?grant_type=%s&client_id=%s&client_secret=%s&";
	public String BAIDULOCATION_ADDRESS_URL = "https://aip.baidubce.com/rpc/2.0/nlp/v1/address?access_token=%s";
	public String BAIDUFACELIVENESS_VERIRY_URL = "https://aip.baidubce.com/rest/2.0/face/v1/faceliveness/verify?access_token=%s";
	public String BAIDUFACELIVENESS_SESSIONCODE_URL = "https://aip.baidubce.com/rest/2.0/face/v1/faceliveness/sessioncode?access_token=%s";
	public String BAIDULOCATION_LOCATION_URL = "http://api.map.baidu.com/geocoder/v2/?output=json&ak=" + BAIDULOCATION_APPKEY + "&location=%s";

	public String BAIDUMAPURL = "https://ga.bjydzy.com/api.map.baidu.com/reverse_geocoding/v3/?output=json&coordtype=wgs84ll&ak=Zix0BmGfZDjKIN6UrdCSwDdkFK1wRsGp&location=%s,%s";
	public String BAIDUMAPADDRESSURL = "https://ga.bjydzy.com/api.map.baidu.com/geocoding/v3/?address=%s&output=json&ak=Zix0BmGfZDjKIN6UrdCSwDdkFK1wRsGp&callback=showLocation";


	@Inject(optional = true)
	@com.google.inject.name.Named("wmp_default_entry_page")
	public String WMP_DEFAULT_ENTRY_PAGE = "pages/toIndex/toIndex";
	public String WMP_AUTH_GETACCESSTOKEN_URL = "https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=%s&secret=%s";
	public String WMP_AUTH_CODE2SESSION_URL = "https://api.weixin.qq.com/sns/jscode2session?appid=%s&secret=%s&js_code=%s&grant_type=authorization_code";
	public String WMP_AUTH_GENERATE_URLLINK_URL = "https://api.weixin.qq.com/wxa/generate_urllink?access_token=%s";

	public String WMP_ALIPAY_GATEWAY = "https://openapi.alipay.com/gateway.do";

}
