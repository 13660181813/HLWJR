package org.ydzy.bot;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.UUID;
import java.util.concurrent.Callable;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;

import org.ydzy.bot.BotUtil.HttpInfo;
import org.ydzy.bot.model.BotResult;
import org.ydzy.bot.model.CmccBotResult;
import org.ydzy.handler.BaseRcsContext;
import org.ydzy.rcs.media.MediaEnclosure;
import org.ydzy.rcs.media.MediaEnclosure.IMediaFileInfo;
import org.ydzy.rcs.media.UploadFileEntity;
import org.ydzy.util.NetUtils;
import org.ydzy.util.Util;

import com.google.gson.JsonObject;
import com.google.inject.Inject;
import com.google.inject.name.Named;

/**
 * 
 * �й��ƶ� bot�ӿ�ģ�� 
 * @author ljp
 *
 */
public class BotAccessCmcc extends BotAccess {

	public BotAccessCmcc() {
		this.authorizeName = AuthCmcc.KEY_AUTH_CMCC;
	}

//	@Inject
//	public void setAuthorizeName(@Named(AuthCmcc.KEY_AUTH_CMCC)IAuthorize auth) {
//		this.authorize = auth;
//	}
	
	@Inject(optional = true)
	@Named("bot.serverRoot")
	private String serverRoot;
	public String getServerRoot() {
		return serverRoot.startsWith("http")?serverRoot:("https://"+serverRoot);
	}

	@Inject(optional = true)
	@Named("bot.fileServerRoot")
	private String fileServerRoot;
	public String getFileServerRoot() {
		return serverRoot.startsWith("http")?fileServerRoot:("https://"+fileServerRoot);
	}


/*
 * �ļ�����
 * GET <FILE_URI> HTTP/1.1
ע�������FILE_URIΪ�ļ�URI
 */
	
	/*
HTTPS DELETE
URL��https://{serverRoot}/Content
	 */
	/**  ý���ز�ɾ�� */
	@Inject(optional = true)
	@Named("bot.url.medias.delete")
	// https://{serverRoot}/Content
	private String urlMediasDelete = "{serverRoot}/Content";
	public String getUrlMediasDelete() {
		return urlMediasDelete;
	}
	
	
	/*
HTTPS��POST
https://{serverRoot}/messaging/interaction/plain/outbound/{chatbotURI}/requests
	 */
	/** ������Ϣ */
	@Inject(optional = true)
	@Named("bot.url.messages")
	// https://{serverRoot}/messaging/interaction/plain/outbound/{chatbotURI}/requests
	private String urlMessages = "{serverRoot}/messaging/interaction/plain/outbound/{urlencode(chatbotIdenty)}/requests";
	public String getUrlMessages() {
		return urlMessages;
	}
	
	/**
	 * ִ�з�����Ϣ
	 * @param botInfo
	 * @param msgObj
	 * @param context
	 * @param body
	 * @return
	 * @throws IOException
	 */
	protected boolean sendMessage(BotInfo botInfo, JsonObject msgObj, BaseRcsContext context, String body, CompletableFuture<HttpInfo> future) throws IOException {
		Map<String, Object> headers = new HashMap<>();
		String url=BotUtil.mustache(getUrlMessages(), this,botInfo,botInfo.getInfos());
		url=botInfo.getAuthorize().attach(url, headers, botInfo);;
		body = convertCrLf(body);;
		if(log.isDebugEnabled())log.debug("result:" + body);
		String contentType = "application/json";
		if(body.startsWith("<"))contentType="application/xml";
		
		String outBody = BotUtil.doHttp(url, body, headers, contentType, BotUtil.utf8, null, future);
		if(!Util.isNull(outBody)){
			HttpInfo conn = null;
			CmccBotResult result = gson.fromJson(outBody, CmccBotResult.class);
			if(future.isDone())
				try {
					conn = future.get(0, TimeUnit.MILLISECONDS);
				} catch (Exception ignore) {}
			if(conn!=null) conn.getAttributes().put("errorCode", result.getCode());
			if(conn!=null) conn.getAttributes().put("description", result.getMsg());
			if(conn!=null) conn.getAttributes().put("messageId", result.getMessageId());
			if(!result.isSussces()) {
				log.warn("do sendMsg error,(" + outBody + ")");
				return false;
			}else {
				if(log.isDebugEnabled())log.debug("Send message success, respone:" + outBody + " , request:" + body);

			}
			return true;
		}
		return false;
	}

	/** ���ı��л���ͳһ���� �س����� */
	public String convertCrLf(String body) throws IOException {
		BufferedReader reader = new BufferedReader(new java.io.StringReader(body));
		StringBuffer sb = new StringBuffer();
		String line;
		boolean first = true;
		while((line=reader.readLine())!=null) {
			if(first) {
				first=false;
			}else {
				sb.append("\r\n");
			}
			sb.append(line);
		}
		return sb.toString();
	}
	
	@Override
	public boolean active(BotInfo botInfo) {
		//�����������κ�����
		botInfo.expire = System.currentTimeMillis()+ 10*365*24*3600*1000;
		botInfo.accessToken = "";
		return true;
	}
	
	/*
HTTPS POST
URL��https://{fileServerRoot}/Content
���ļ�ָ��ʱ��
https://{fileServerRoot}/Content?hash=sha256<sha256_value>&File-name=<file name>&File-size=<file size>
	 */
	@Inject(optional = true)
	@Named("bot.url.medias.upload")
	//https://{fileServerRoot}/Content
	private String urlMediasUpload = "{fileServerRoot}/Content";
	public String getUrlMediasUpload() {
		return urlMediasUpload;
	}
	
	protected static final String FORMNAME_FILE = "File";
	protected static final String FORMNAME_THUMBNAIL = "Thumbnail";
	/** �������ͼ�ļ���С */
	@Inject(optional = true)
	@Named("bot.thumbnail.max.filesize")
	private long maxThumbnailFilesize = 10*1024;
	/** 
	 * �ϴ�ý��
	 */
	@Override
	public boolean mediaUpload(final BotInfo botInfo, final UploadFileEntity fileEntity) {
		Callable<HttpInfo> caller = () -> {
			String boundary="--------"+UUID.randomUUID().toString().replace("-", "");
			Map<String, Object> headers= new HashMap<>();
			headers.put("Content-Type", "multipart/form-data; boundary="+boundary);
			headers.put("User-Agent", "SP/"+botInfo.getChatbotIdenty());
			String url = BotUtil.mustache(getUrlMediasUpload(), BotAccessCmcc.this, botInfo, botInfo.getInfos());
			if(log.isDebugEnabled())log.debug("posting chatbot media upload ->  " + url);
			url = botInfo.getAuthorize().attach(url, headers, botInfo);

			//��װ�ϴ��ļ�������
			MediaEnclosure enclosure = new MediaEnclosure();
			//ByteBuffer body = enclosure.convertBody(fileEntity, boundary, "File", "Thumbnail");
			List<Map.Entry<String, IMediaFileInfo>> list = new ArrayList<>();
			IMediaFileInfo mediaInfo = enclosure.getMediaFileInfo(fileEntity, false);
			if(mediaInfo!=null) {
				list.add(Map.entry(FORMNAME_FILE, mediaInfo));
				fileEntity.setFileName(mediaInfo.getFilename());
			}
			IMediaFileInfo thumbnailInfo = enclosure.getMediaFileInfo(fileEntity, true);
			if(thumbnailInfo!=null) {
				if(thumbnailInfo.getFileSize() > maxThumbnailFilesize) {
					if(thumbnailInfo.resizeTo(maxThumbnailFilesize)) {
						list.add(Map.entry(FORMNAME_THUMBNAIL, thumbnailInfo));
						fileEntity.setThumbFileSize(thumbnailInfo.getFileSize());
					}else {
						log.warn("Can't resize thumbnail file(" + thumbnailInfo.getFilename() + ") to limit size, skip!!!");;
					}
				}
			}
			if(list==null || list.size()==0) throw new SpecialException("No media file loaded!!!");
			if(fileEntity.getMediaID()==null|| fileEntity.getMediaID().isEmpty())botInfo.getDbOper().saveMedia(botInfo, fileEntity);
			final CompletableFuture<HttpInfo> putFuture = new CompletableFuture<>();;
			String rspBody = null;
			try (
					InputStream body = enclosure.convertBodyInputStream(list, boundary);
					){
				rspBody = BotUtil.doHttp(url, body, headers, null, BotUtil.utf8, null, putFuture);
			}catch(IOException e) {
				//ignore
//				e.printStackTrace();
			}
			
			HttpInfo putconn = null;
			try {
				putconn = putFuture.get(0, TimeUnit.SECONDS);
				if(putconn!=null &&(rspBody==null || rspBody.isEmpty())) rspBody = putconn.getResponseBody();
			}catch(SpecialException se) {
				throw se;
			}catch(Exception ignore) {}
			if(putconn==null || rspBody==null || rspBody.isEmpty())throw new IOException("do http error, no content!");
			
			if(putconn.getResponseCode()==400) {
				log.error("Call upload media error:" + putconn.getResponseBody());
				throw new SpecialException();
			}
			BotResult result = gson.fromJson(rspBody, BotResult.class);
			if(putconn.getResponseCode()==400) {
				fileEntity.setErrorCode(""+result.getErrorCode());
				fileEntity.setErrorDesc(result.getErrorMessage());
				log.error("Call upload media error:" + putconn.getResponseBody());
				throw new SpecialException();
			}
			if(result.getErrorCode()!=0) {
				if(result.getErrorCode()==36001) {
					log.warn("Media(" + fileEntity.getMediaID() + ") upload is completed with error, rsp:" + rspBody);
					throw new SpecialException(rspBody);
				}
				throw new IOException("result error," + result + " mediaid(" + fileEntity.getMediaID() + ")");
			}
			String tid = null;
			Map<String, ?> rspHeaders = putconn.getResponseHeaders();
			if(rspHeaders!=null) {
				Object o = rspHeaders.get("tid");
				if(o!=null) {
					if(o instanceof java.util.List) {
						tid = String.valueOf(((java.util.List<?>)o).get(0));
					}else {
						tid = o.toString();
					}
				}
			}
			if(tid==null) {
				throw new IOException("result error, can't get tid! url:" + url + " requestBody:" + putconn.getRequestBody() + ")");
			}
			fileEntity.setFileName(mediaInfo.getFilename());
			fileEntity.setFileSize(mediaInfo.getFileSize());
			fileEntity.setStatus("1");
			fileEntity.setTid(tid);
			botInfo.getDbOper().saveMedia(botInfo, fileEntity);
			return putconn;
		};
		
		try {
			String mediaID = fileEntity.getMediaID();
			if(mediaID!=null && !mediaID.isEmpty()) {
				if(botInfo.manager.getMediaUploadFuture().containsKey(mediaID)) {
					log.debug("Media(" + mediaID + " upload is running, skip!");
					return true;
				}
				CompletableFuture<UploadFileEntity> authorFuture = new CompletableFuture<>();
				botInfo.manager.getMediaUploadFuture().put(mediaID, authorFuture);
			}else {
				fileEntity.setErrorCode("");
				fileEntity.setErrorDesc("");
				botInfo.getDbOper().saveMedia(botInfo, fileEntity);
				mediaID = fileEntity.getMediaID();
				CompletableFuture<UploadFileEntity> authorFuture = new CompletableFuture<>();
				botInfo.manager.getMediaUploadFuture().put(mediaID, authorFuture);
			}

			CompletableFuture<Void> future = new CompletableFuture<>();
			callWithRetry(botInfo,caller, "mediaUpload(" + mediaID +")", () -> botInfo.getDbOper().saveMediaUploadFailed(botInfo, fileEntity))
				.whenComplete((putconn, t)->{
				
				try {
					if(t!=null) {
						future.completeExceptionally(t);
					}else {
						future.complete(null);
					}
				}catch(Exception e) {
					log.warn("Writer to media info to database error!",e);
				}			
			});
			future.whenComplete((v,t) ->{
				if(t!=null)log.warn("Error, upload media(" + fileEntity.getMediaID() + ") failed. " + t.getMessage()+ "",t);
			});
			LocalDateTime waitToTime = LocalDateTime.now().plusSeconds(60);
			while(!future.isDone() && LocalDateTime.now().isBefore(waitToTime)) {
				future.get(100, TimeUnit.MILLISECONDS);
			}
			if(future.isDone()) {
				if(future.isCompletedExceptionally()) {
					log.warn("Media(" + mediaID + " upload is completed with error,");
				}
				return true;
			}
		} catch (Exception e) {}
		return false;
	}

	@Override
	public boolean mediaDelete(BotInfo botInfo, UploadFileEntity media) {
		TreeMap<String, Object> headers = new TreeMap<String, Object>();
		headers.put("User-Agent", "SP/"+botInfo.getChatbotIdenty());
		headers.put("tid", media.getTid());
		String url = BotUtil.mustache(getUrlMediasUpload(), BotAccessCmcc.this, botInfo, botInfo.getInfos());
		url = authorize.attach(url, headers, botInfo);
		if(log.isDebugEnabled())log.debug("Deleting chatbot media upload ->  " + url);
		final CompletableFuture<HttpInfo> putFuture = new CompletableFuture<>();
		try{
			BotUtil.doHttp(url, null, headers, null, BotUtil.utf8, "DELETE", putFuture);
		}catch(IOException e) {
			log.info("Delete chatbot media file error(" + e.getMessage() + ")");
		}
		HttpInfo putconn = null;
		try {
			putconn = putFuture.get(0, TimeUnit.SECONDS);
			if(putconn!=null && putconn.getResponseCode()<=205) {
				media.setStatus("4");
				botInfo.getDbOper().saveMedia(botInfo, media);
				return true;
			}
		}catch(Exception ignore) {}
		return false;
	}

	@Override
	public void mediaDownload(BotInfo botInfo, String url,String outputfile) {
		TreeMap<String, Object> headers = new TreeMap<String, Object>();
		headers.put("User-Agent", "SP/"+botInfo.getChatbotIdenty());
		url = authorize.attach(url, headers, botInfo);
		try {
			 NetUtils.doHttpsWriteFiles(url, null, headers, "",outputfile);
		} catch (IOException e) {
			log.info("Download chatbot media file error(" + e.getMessage() + ")");
		}
		
	}
		

}
