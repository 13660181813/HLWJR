package org.ydzy.xml;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;
import org.ydzy.util.Util;

public class DataSetXmlConfig {
	private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(DataSetXmlConfig.class);
	private static Map<String, Long> lastReadTime = new HashMap<String, Long>();
	private static Map<String, Map<String, Object>> configContent = new HashMap<String, Map<String, Object>>();
	private static Map<String, Map<String, Object>> dataSourceConfig = new HashMap<String, Map<String, Object>>();
	private String fileName;
	private static DataSetXmlConfig dataSetConfig;

	public static Map<String, Map<String, Object>> getConfigContent() {
		if (dataSetConfig == null)
			dataSetConfig = new DataSetXmlConfig("dataset.xml");
		dataSetConfig.reload();
		return configContent;
	}

	public static Map<String, Map<String, Object>> getDataSources() {
		if (dataSetConfig == null)
			dataSetConfig = new DataSetXmlConfig("dataset.xml");
		dataSetConfig.reload();
		return dataSourceConfig;
	}

	private DataSetXmlConfig(String fileName) {
		this.fileName = fileName;
		loadXml();
	}

	private void loadXml() {
		Set<String> fs = Util.getjarAndLocalFilePath(fileName);
		fs.forEach((f) -> {
			readFromUrl(f);
		});
	}

	private void readFromUrl(String f) {
		File tmpfile = new File(f);
		long modify = lastReadTime.containsKey(f) ? lastReadTime.get(f) : 0;
		long currentModify = 0;
		if (tmpfile.exists()) {
			currentModify = tmpfile.lastModified();
		} else
			currentModify = System.currentTimeMillis();
		if (modify == 0 || currentModify > modify) {
			lastReadTime.put(f, currentModify);
			try (FileInputStream input = new FileInputStream(tmpfile)) {
				log.info("start load DataSetconfig file {}   ", f);
				parseXml(input);
				log.info("  load DataSetconfig file {} path {} sucess ...", f);
			} catch (Exception e) {
				log.error("---------------------fetch  dirs {} error : file is {} ", fileName, f, e);
			}
		}

	}

	public void reload() {
		lastReadTime.forEach((k, v) -> {
			readFromUrl(k);
		});
	}

	private void parseXml(InputStream stream) {
		SAXReader reader = new SAXReader();
		try {
			Document doc = reader.read(stream);//
			// Document doc = reader.read(xmlResource.getURL());
			Element rootElement = doc.getRootElement();
			List<Element> results = rootElement.elements("result");
			for (Element rs : results) {
				Map<String, Object> result = new HashMap<String, Object>();
				parseAttr(rs, result);
				String id = Util.toString(result.get("id"));
				List<Element> fields = rs.elements("fields");
				Map<String, Map<String, Object>> fieldsList = new HashMap<String, Map<String, Object>>();
				fields.forEach(element -> {
					Map<String, Object> fs = new HashMap<String, Object>();
					parseAttr(element, fs);
					String fid = Util.toString(fs.get("from"));
					fieldsList.put(fid, fs);
				});
				result.put("fields", fieldsList);
				String conditon="";
				if(rs.element("condition")!=null)
				conditon=rs.element("condition").getStringValue();
				result.put("condition", conditon);
				
				configContent.put(id, result);
			}
			List<Element> ds = rootElement.elements("datasource");
			ds.forEach(d -> {
				Map<String, Object> dmap = new HashMap<String, Object>();
				parseAttr(d, dmap);
				String id = Util.toString(dmap.get("id"));
				dataSourceConfig.put(id, dmap);
			});

		} catch (Exception e) {
			log.error("parse   error .", e);
		}
	}

	private void parseAttr(Element rs, Map<String, Object> result) {
		for (int m = 0; m < rs.attributeCount(); m++) {
			String name = rs.attribute(m).getQName().getName();
			String value = rs.attribute(m).getValue().trim();
			result.put(name, value);
		}
	}

	public static Connection createConnection(String dsId) {
		Map<String, Object> ds = DataSetXmlConfig.getDataSources().get(dsId);
		String driverClassName = Util.toString(ds.get("driverClassName"));
		String url = Util.toString(ds.get("url"));
		String username = Util.toString(ds.get("username"));
		String password = Util.toString(ds.get("password"));
		try {
			Class.forName(driverClassName);
			Connection connection = DriverManager.getConnection(url, username, password);
			connection.setAutoCommit(false);
			return connection;
		} catch (ClassNotFoundException | SQLException e) {
			log.error("create connection error ", e);
		}
		return null;
	}

	public static Set<String> selector(String resultId) {
		Map<String, Object> result = DataSetXmlConfig.getConfigContent().get(resultId);
		if (result.containsKey("fields") && result.get("fields") instanceof Map) {
			@SuppressWarnings("unchecked")
			Map<String, Map<String, Object>> fieldsList = (Map<String, Map<String, Object>>) result.get("fields");
			Set<String> selectors = fieldsList.values().stream().map((field) -> {
				if (field != null) {
					String from = Util.trim(field.get("from"));
					String to = Util.trim(field.get("to"));
					String express = Util.trim(field.get("express"));
					if (to != null && !to.isBlank()) {
						if (express != null && !express.isBlank()) {
							if (express.toLowerCase().endsWith(to.toLowerCase())) {
								return express;
							} else if (express.toLowerCase().endsWith(from.toLowerCase())) {
								log.warn(
										"to is null  will skip this from transfer ! field from {} to {} expression {} ",
										from, to, express);
								return express;
							} else {
								return express + " AS " + to;
							}
						} else
							return to;
					} else {
						log.warn("to is null  will skip this from transfer ! field from {} to {} expression {} ", from,
								to, express);
						return null;
					}
				} else
					return null;
			}).filter((o) -> o != null).collect(Collectors.toSet());
//			if (selectors.endsWith(",")) 
//				selectors= selectors.substring(0, selectors.length() - 1);
//			if (selectors.startsWith(",")) 
//				selectors=selectors.substring(1, selectors.length() );
			return selectors;
		}
		return null;
	}

	public static String selector2Str(Set<String> selectors) {
		return selectors != null && selectors.size() > 0 ? selectors.stream().collect(Collectors.joining(",")) : "";
	}
}
