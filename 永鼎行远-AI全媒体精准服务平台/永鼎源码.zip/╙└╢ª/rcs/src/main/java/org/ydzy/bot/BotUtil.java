package org.ydzy.bot;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Reader;
import java.io.Writer;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.KeyManager;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import org.ydzy.util.Util;

public class BotUtil {
	static final Logger log = LoggerFactory.getLogger(BotUtil.class);
	public static Charset utf8 = Charset.forName("UTF8");

	/**
	 * ��ȡ����ָ�����Ƶ�����ֵ
	 * @param name
	 * @param beans
	 * @return
	 * @see BotUtil#mustache
	 */
	private static Object getProperty(String name, Object ...beans) {
		Object o = null;
		for(Object bean:beans) if(bean!=null) {
			if(bean instanceof JsonObject) {
				try {
					JsonElement je = ((JsonObject)bean).get(name);
					if(je!=null) {
						if(!je.isJsonNull()) {
							o = je.getAsString();
						}
					}
				}catch(Throwable ignore) {}
				if(o!=null) break;
			}else {
				try {
					o = org.apache.commons.beanutils.BeanUtils.getProperty(bean, name);
				}catch(Throwable ignore) {}
				if(o!=null) break;
				try {
					o = org.apache.commons.beanutils.BeanUtils.getSimpleProperty(bean, name);
				}catch(Throwable ignore) {}	
				if(o!=null) break;
			}
		}
		return o;
		
	}
	
	public static interface IEncode {
		Object call(Object rawValue);
	}
	public static Map<String, IEncode> encodeMap = new ConcurrentHashMap<>();
	static {
		IEncode e = k -> URLEncoder.encode(String.valueOf(k), utf8);
		encodeMap.put("urlencode", e);
		encodeMap.put("%", e);
	}
	public static Object getValue(String expression, Object ...beans) {
		int p1 = expression.indexOf('(');
		if(p1>0) {
			int p2 = expression.indexOf(')',p1+1);
			String fn = expression.substring(0,p1).trim();
			String name = expression.substring(p1+1,p2>0?p2:expression.length());
			IEncode encode = null;
			if((!fn.isEmpty()) && (encode = encodeMap.get(fn.toLowerCase()))!=null) {
				Object raw = getProperty(name, beans);
				return encode.call(raw);
			}
		}
		return getProperty(expression, beans);
	}
	/***
	 * ���ģ������� ʹ��ʹ����{name}�����ı�� ��������
	 * @param template
	 * @param beans
	 * @return
	 */
	public static String mustache(String template, Object ...beans) {
		if(template==null || template.indexOf('{')<0)return template;
		StringBuilder sb = new StringBuilder();
		StringBuilder tName = new StringBuilder();
		int p1=-1;
		for(int i=0;i<template.length();i++) {
			char c = template.charAt(i);
			boolean escaped = false;
			if(c=='\\'){
				i++;
				if(i==template.length())break;
				escaped = true;
				c = template.charAt(i);
			}
			if(p1<0) {
				if(c!='{' || escaped) {
					sb.append(c);
				}else {
					p1 = i;
					tName.setLength(0);
				}
			}else {
				if(c!='}' || escaped ) {
					tName.append(c);
				}else {
					Object v = getValue(tName.toString(), beans);
					if(v!=null)sb.append(v);
					p1 = -1;
				}
			}
		}
		if(p1>0 && tName.length()>0) {
			Object v = getValue(tName.toString(), beans);
			if(v!=null)sb.append(v);
		}
		return sb.toString();
	}
	
	public static String getElementAsString(JsonObject object, String eleText) {
		JsonElement e  = getElement(object, eleText);
		return e==null?null:e.getAsString();
	}
	public static int getElementAsInt(JsonObject object, String eleText, int defaultValue) {
		int i = defaultValue;
		try {
			Number n  = getElementAsNumber(object, eleText);
			if(n!=null)i=n.intValue();
		}catch(Throwable ignore) {}
		return i;
	}
	
	public static Number getElementAsNumber(JsonObject object, String eleText) {
		JsonElement e  = getElement(object, eleText);
		return e==null?null:e.getAsNumber();
	}
	public static JsonElement getElement(JsonObject object, String eleText) {
		JsonElement e = null;
		if (object != null && (e=object.get(eleText))!= null && !e.isJsonNull()){
			return e;
		}else {
			return null;
		}
	}
	public static JsonElement getElement(JsonObject object, Object[] eleTexts) {
		return getElement(object, eleTexts, 0);
	}
	private static JsonElement getElement(JsonElement object, Object[] eleTexts, int level) {
		if(level>=eleTexts.length)return object;
		if (object != null) {
			Object eleText = eleTexts[level];
			JsonElement e = null;
			if(eleText instanceof Number) {
				int i = ((Number)eleText).intValue();
				JsonArray ja;
				if(object.isJsonArray() && (ja=object.getAsJsonArray()).size()>i) {
					e = ja.get(i);
				}
			}else {
				String key = String.valueOf(eleText);
				JsonObject jo;
				if(object.isJsonObject()) {
					jo = object.getAsJsonObject();
					e = jo.get(key);
				}
			}
			if(e!=null && !e.isJsonNull()){
				return getElement(e, eleTexts, level+1);
			}
			
		}
		return null;
	}
	
	public static String doHttp(String url, String outBody, Map<String, Object> headers) throws IOException{
		return doHttp(url, outBody, headers, "application/json", utf8);
	}
	
	public static String doHttp(String url, byte[] outBody, Map<String, Object> headers, String contentType) throws IOException{
		return doHttp(url, outBody, headers, contentType, utf8);
	}
	
	public static String doHttp(String url, ByteBuffer outBody, Map<String, Object> headers, String contentType) throws IOException{
		return doHttp(url, outBody, headers, contentType, utf8);
	}
	
	public static String doHttp(String url, Object outBody, Map<String, Object> headers, String contentType ,Charset chatset) throws IOException{
		return doHttp(url, outBody, headers, contentType, chatset, null, null);
	}
	
	/*** ִ��HTTP����
	 *  
	 * @param url
	 * @param outBody
	 * @param headers
	 * @param contentType
	 * @param chatset body���ݵ��ַ���
	 * @param method ���󷽷� Ĭ��null,���������Ƿ�Ϊ���Զ��ж�ΪPOST��GET
	 * @param future
	 * @return
	 * @throws IOException
	 */
	public static String doHttp(String url, final Object outBody, final Map<String, Object> headers, String contentType, final Charset chatset, String method, CompletableFuture<HttpInfo> future) throws IOException{
		final HttpURLConnection conn =  (HttpURLConnection) new URL(url).openConnection();
		if(conn instanceof HttpsURLConnection) {
			HttpsURLConnection httpsConn = (HttpsURLConnection)conn;
	        SSLContext ctx = null;
	        try {
	            ctx = SSLContext.getInstance("TLS");
	            ctx.init(new KeyManager[0], new TrustManager[] { new DefaultTrustManager() }, new SecureRandom());
	        } catch (KeyManagementException e) {
	            e.printStackTrace();
	        } catch (NoSuchAlgorithmException e) {
	            e.printStackTrace();
	        }
	        SSLSocketFactory ssf = ctx.getSocketFactory();

	        httpsConn.setSSLSocketFactory(ssf);
	        httpsConn.setHostnameVerifier(new HostnameVerifier() {
	            @Override
	            public boolean verify(String arg0, SSLSession arg1) {
	            	if("api.5gcsp.mas.10086.cn".equals(arg0)) {
	            		return true;
	            	}
	            	return true;
	                //return false;
	            }
	        });
		}
		if(headers!=null && headers.size()>0){
			headers.forEach((k,v) -> {conn.addRequestProperty(k, String.valueOf(v));});
		}
		if(conn.getRequestProperty("User-Agent")==null)	conn.addRequestProperty("User-Agent", "YDBot/1.0");
		conn.setConnectTimeout(5000);
		conn.setReadTimeout(5000);
		final StringBuilder sbResonse = new StringBuilder();
		final int[] rc = new int[] {0};
		try {
			if(contentType!=null && !contentType.isEmpty())conn.setRequestProperty("Content-Type", contentType);
			if(outBody!=null) {
				conn.setDoOutput(true);
				conn.setRequestMethod(method!=null?method:"POST");
				if(outBody instanceof String) {
					Writer out = new java.io.OutputStreamWriter(conn.getOutputStream(), chatset);
					out.write((String)outBody);
					out.close();
				}else if(outBody instanceof byte[]){
					OutputStream out = conn.getOutputStream();
					out.write((byte[])outBody);
					out.close();
				}else if(outBody instanceof ByteBuffer) {
					OutputStream out = conn.getOutputStream();
					ByteBuffer buff = (ByteBuffer) outBody;
					buff.flip();
					byte[] bytes = new byte[1024];
					while(buff.remaining()>0) {
						int l;
						if(buff.remaining()>bytes.length) {
							l = bytes.length;
						}else {
							l = buff.remaining();
						}
						buff.get(bytes, 0, l);
						out.write(bytes, 0, l);
					}
					out.close();
				}else if(outBody instanceof InputStream) {
					OutputStream out = conn.getOutputStream();
					InputStream in = (InputStream) outBody;
					byte[] bytes = new byte[1024];
					int l;
					while((l=in.read(bytes))>=0) {
						out.write(bytes, 0, l);
					}
					out.close();
				}
			}else {
				conn.setRequestMethod(method!=null?method:"GET");
			}
			rc[0] = conn.getResponseCode();
			String rspContentType = conn.getHeaderField("content-Type");
			if(rspContentType==null || rspContentType.indexOf("text")>=0 || rspContentType.indexOf("json")>0
					 || rspContentType.indexOf("xml")>0){
				java.io.InputStream in = null;
				try {
					in = conn.getInputStream();
				}catch(Exception e) {
					try {
						in = conn.getErrorStream();
					}catch(Throwable t) {}
				}
				if(in!=null)try(Reader reader = new java.io.InputStreamReader(in,chatset)){
					char[] cbuff = new char[1024];
					int l;
					while((l=reader.read(cbuff))>=0) {
						if(l>0)sbResonse.append(new String(cbuff,0,l));
					}
				}catch(Exception e) {
					log.debug("Fetch reponse error!",e);
				}
			}
			if(rc[0]>=300){
				if(rspContentType.indexOf("json")>0 && !Util.isNull(sbResonse.toString()))
					return sbResonse.toString();
				throw new IOException("Error response code:" + rc[0]);
			}
			return sbResonse.toString();
		}finally {
			log.debug(" url  {}  status {} response's size  {} ",url,rc[0],sbResonse.length());
			if(future!=null)try {
				future.complete(
					new HttpInfo() {
				@Override
				public void getRequestHeaders(StringBuilder sb) {
					sb.append(conn.getRequestMethod()).append(" ").append(conn.getURL()).append("\n");
					Map<String, ?> map = null;
					try {
						map = conn.getRequestProperties();
					} catch (Exception ignore) {}
					if(map==null)map = headers;
					if (map != null) {
						for (Map.Entry<String, ?> e : map.entrySet()) {
							if (e.getKey() != null) {
								sb.append(e.getKey());
								sb.append(" : ");
							}
							Object v = e.getValue();
							if (v != null)
								if(v instanceof List){
									List<?> list = (List<?>)v;
									for (int i = 0; i < list.size(); i++) {
										if (i > 0)
											sb.append(" ,");
										sb.append(list.get(i));
									}
								}else {
									sb.append(v);
								}
							sb.append("\n");
						}
					}
				}

				@Override
				public Map<String, ?> getResponseHeaders() {
					return conn.getHeaderFields();
				}
				
				@Override
				public void getResponseHeaders(StringBuilder sb) {
					try {
						Map<String, ?> map = conn.getHeaderFields();
						if (map != null) {
							for (Map.Entry<String, ?> e : map.entrySet()) {
								if (e.getKey() != null) {
									sb.append(e.getKey());
									sb.append(" : ");
								}
								Object v = e.getValue();
								if (v != null)
									if(v instanceof List){
										List<?> list = (List<?>)v;
										for (int i = 0; i < list.size(); i++) {
											if (i > 0)
												sb.append(" ,");
											sb.append(list.get(i));
										}
									}else {
										sb.append(v);
									}
								sb.append("\n");
							}
						}
					} catch (Exception ignore) {}
				}

				public String getResponseHeader(String key) {
					String value = conn.getHeaderField(key);
					return value;
				}
				
				@Override
				public String getRequestBody() {
					if(outBody==null)return null;
					if(outBody instanceof String)return(String)outBody;
					if(outBody instanceof byte[])return new String((byte[])outBody,chatset);
					if(outBody instanceof InputStream)return "[Stream]";
					return null;
				}

				@Override
				public String getResponseBody() {
					return sbResonse.toString();
				}

				@Override
				public int getResponseCode() {
					return rc[0];
				}
				
				@Override
				public InputStream getInputStream() throws IOException {
					return conn.getInputStream();
				}
				
				private Map<String, Object> attribute = new HashMap<>();
				@Override
				public Map<String, Object> getAttributes() {
					return attribute;
				}
				
			});
			}catch(Exception ignore) {}
		}
	}
	
	/** ��¼һ��HTTP�������Ϣ */
	public static interface HttpInfo{
		/** ��ȡ����ͷ, ���ӵ�sb�� */
		void getRequestHeaders(StringBuilder sb);
		/** ��ȡ��Ӧͷ, ���ӵ�sb�� */
		void getResponseHeaders(StringBuilder sb);
		/** ��ȡ������ */
		String getRequestBody();
		/** ��ȡ��Ӧ�� */
		String getResponseBody();
		
		/** ��Ӧ״̬�� */
		int getResponseCode();
		
		/** ��Ӧ������ 
		 * @throws IOException */
		InputStream getInputStream() throws IOException;
		
		/** ��ȡ��Ӧͷ */
		Map<String, ?> getResponseHeaders();
		
		/** ��ȡ��Ӧͷ���� */
		String getResponseHeader(String key);
		
		Map<String, Object> getAttributes();
	}
	
	/** ֤����� */
	private static final class DefaultTrustManager implements X509TrustManager {
        @Override
        public void checkClientTrusted(X509Certificate[] chain, String authType) throws CertificateException {
        }

        @Override
        public void checkServerTrusted(X509Certificate[] chain, String authType) throws CertificateException {
        }

        @Override
        public X509Certificate[] getAcceptedIssuers() {
            return null;
        }
    }
	
	/**
     * xmlתmap
     * 
     * @param body
	 * @param tag
     * @return
     * @throws IOException
     */
    public static Map<String, String> xml2Map(String body, String tag) throws IOException {
        Map<String, String> map = new HashMap<String, String>();
        SAXReader reader = new SAXReader();
        Document doc = null;
        //InputStream is = null;
        Reader in = null;
        try {
            //is = request.getInputStream();
            in = new java.io.StringReader(body);
            doc = reader.read(in);
            Element root = doc.getRootElement();
            
            Element msg = root.element(tag);
            if(msg!=null) {
            	for (Iterator<?> iterator = msg.elementIterator(); iterator.hasNext();) {  
            		Element e = (Element)iterator.next();
            		map.put(e.getName(), e.getText());
            	}
            }
        } catch (Exception e) {
            log.warn("parse xml error", e);
        } finally {
            in.close();
        }
        return map;
    }
}
