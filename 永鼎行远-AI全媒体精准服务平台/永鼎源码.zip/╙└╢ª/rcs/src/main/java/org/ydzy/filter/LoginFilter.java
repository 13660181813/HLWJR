package org.ydzy.filter;

import com.google.common.collect.Maps;
import com.google.common.net.HttpHeaders;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.inject.Inject;
import io.jsonwebtoken.Claims;
import jakarta.servlet.*;
import jakarta.servlet.http.HttpFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.eclipse.jetty.util.StringUtil;
import org.ydzy.config.ApplicationConfig;
import org.ydzy.handler.*;
import org.ydzy.rcs.Provider;
import org.ydzy.rcs.action.AuthAction;
import org.ydzy.rcs.module.LoadProperties;
import org.ydzy.util.JwtOperatorUtil;
import org.ydzy.util.PositionUtil;
import org.ydzy.util.Util;
import org.ydzy.util.crypto.cryptoDES;

import java.io.IOException;
import java.net.URL;
import java.net.URLDecoder;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;

public class LoginFilter extends HttpFilter {

    private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(LoginFilter.class);

    @Inject
    private BaseRcsContextProvidor contextProvidor = null;

    @Inject
    private AuthAction authAction = null;

    @Inject
    private ApplicationConfig applicationconfig = null;

    @Inject
    private LocationParse locationParse;

    public LoginFilter() {
        authAction = Provider.injector.getProvider(AuthAction.class).get();
        contextProvidor = Provider.injector.getProvider(BaseRcsContextProvidor.class).get();
        applicationconfig = Provider.injector.getProvider(ApplicationConfig.class).get();
        locationParse = Provider.injector.getProvider(LocationParse.class).get();
    }

    JwtOperatorUtil jwtOperatorUtil = new JwtOperatorUtil();

    public void destroy() {
        System.out.println("Stopping filter");
    }

    private boolean validateSignature(BaseRcsContext context, String username, String phone, String timestamp, String remoteAddr, String signature, HttpServletRequest req, HttpServletResponse rsp,
                                      String nonce, String accessTagNo) throws IOException {
        String chatbotid = Util.toString(context.getSession(username + "_" + phone).get("chatbotid"), "");
        String skey = "session_";
        if(!Util.isNull(phone))
        skey += phone.hashCode();
        if(!Util.isNull(chatbotid))
        skey+= "_" + chatbotid.hashCode();
        long timelong = Util.toLong(timestamp, 0);
        Instant i1 = Instant.now();
        long currentLong = i1.getEpochSecond();
        if (currentLong - timelong > applicationconfig.LOGIN_SIGNATURE_EXPIREIN_SECOND) {
            context.getSession(skey).remove(skey);
            authAction.recordLog("signLogin-header", "signature has timed out.", remoteAddr, "500", "login", phone, null, username);
            AuthAction.signatureValidateFailed(signature, remoteAddr, req, rsp);
            return false;
        }
        JsonObject userObj = (JsonObject) context.getSession(skey).get("userObj");
        if (userObj == null) {
            userObj = authAction.validateSignature(signature, timestamp, nonce, username, accessTagNo);
        }
        else {
//            rsp.setHeader("userinfo", userObj.getAsString());

            return true;
        }
        if (userObj == null) {
            authAction.recordLog("signLogin-header", "Signature verification failed.", remoteAddr, "500", "login", phone, null, username);
            AuthAction.signatureValidateFailed(req.getHeader("signature"), remoteAddr, req, rsp);
            return false;
        } else {
            if (Util.isNull(chatbotid)) {
                chatbotid = Util.getElementAsString(userObj, "chatbotid");
                chatbotid = context.getConfig().enterpriseProperty(chatbotid, "sp");
            }
//            skey = "session_" + phone.hashCode() + "_" + chatbotid.hashCode();
            skey = "session_";
            if(!Util.isNull(phone))
            skey += phone.hashCode();
            if(!Util.isNull(chatbotid))
            skey+= "_" + chatbotid.hashCode();
            userObj.addProperty("phone", phone);
            RcsSession session = context.getSession(skey);
            session.put("userObj", userObj);
            session.put("chatbotid", chatbotid);
//            String groupId = Util.getElementAsString(userObj, "groupid");
//            authAction.buildLoginResult(userObj, groupId, phone);
//            rsp.setHeader("userinfo", userObj.getAsString());
            context.getSession(username + "_" + phone).put("chatbotid", chatbotid);
            return true;

        }
    }

    private List<String> whitelistUri = null;
    private List<String> whitelistSqlId = null;
    private List<String> blackIps = null;
    private List<String> whiteIps = null;
    private String serverName = null;

    public void doFilter(ServletRequest request, ServletResponse response,
                         FilterChain chain) throws IOException, ServletException {
        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse rsp = (HttpServletResponse) response;
        String accessToken = req.getHeader(HttpHeaders.AUTHORIZATION);
        if (Util.isNull(accessToken))
            accessToken = request.getParameter("token");
        String loginType = Util.toString(req.getHeader("loginType"), "password");
        String uri = req.getRequestURI();
        String method = req.getMethod();
        if (whitelistUri == null)
            whitelistUri = getSubList("login.whitelist.uri");
        if (whitelistSqlId == null)
            whitelistSqlId = getSubList("login.whitelist.sqlid");
        if (blackIps == null)
            blackIps = getSubList("login.black.ip");
        if (whiteIps == null)
            whiteIps = getSubList("login.white.ip");
        String remoteAddr = BaseHandler.getIpAddress(req);
        //uri������ ����
        if (authAction.validateUri(whitelistUri, uri) || authAction.validateUri(whitelistUri, uri + "?" + req.getQueryString())) {
            chain.doFilter(request, response);
            return;
        }
        // OPTIONS IP��������֤
        if (method.equals("OPTIONS") || whiteIps.contains(remoteAddr)) {
            chain.doFilter(request, response);
            return;
        }
        // IP ��������֤
        if (blackIps.contains(remoteAddr)) {
            authAction.denyloginByIp(remoteAddr, req, rsp);
            return;
        }
        // sql ������ѯ�ӿ� sqlid������
        String queryId = req.getParameter("queryId");
        if (uri.endsWith("/common") && whitelistSqlId.contains(queryId)) {
            chain.doFilter(request, response);
            return;
        }
        BaseRcsContext context = contextProvidor.newBaseRcsContext();
        String sid = req.getParameter("sid");
        String configid = req.getParameter("configid");
        Map<String, String> paramMap = Util.buildQueryParams(req);
//        if(Util.isNull(sid))
//        	sid=paramMap.get("sid");
//        if(Util.isNull(configid))
//        	configid=paramMap.get("configid");
        String channle = req.getHeader("channel");
        if (!Util.isNull(sid) && !Util.isNull(configid)&&!"{configid}".equals(configid)) {
            accessToken = unknownUserLogin(req, rsp, context, sid, channle);
        }

        String signature = req.getHeader("signature");
        String timestamp = req.getHeader("timestamp");
        String nonce = req.getHeader("nonce");
        String username = req.getHeader("Username");
        String phone = req.getHeader("phone");
        String hsid = req.getHeader("sid");
        String accessTagNo = req.getHeader("accessTagNo");
        String position = req.getHeader("position");

        signature = Util.isNull(signature) ? paramMap.get("signature") : signature;
        timestamp = Util.isNull(timestamp) ? paramMap.get("timestamp") : timestamp;
        nonce = Util.isNull(nonce) ? paramMap.get("nonce") : nonce;
        username = Util.isNull(username) ? paramMap.get("Username") : username;
        phone = Util.isNull(phone) ? paramMap.get("phone") : phone;
        hsid = Util.isNull(hsid) ? paramMap.get("hsid") : hsid;
        phone = Util.isNull(phone) ? hsid : phone;
        sid = Util.isNull(sid) ? paramMap.get("sid") : sid;
        String sendTo = (paramMap.get("sendTo"));
        if (!Util.isNull(sid)) {
            if (!sid.startsWith("YDXY") && !Util.isNull(sendTo))
                sid = sid + "_" + sendTo;
        }
        phone = Util.isNull(phone) ? sid : phone;
        String nick = Util.toString(paramMap.get("nick"), "");
        if (Util.isNull(phone))
            phone = paramMap.get("mdn");
        username = Util.isNull(username) ? phone : username;
        String latitude = paramMap.get("latitude");
        String longitude = paramMap.get("longitude");
        String mdn = Util.toString(paramMap.get("mdn"), "");
        accessTagNo = Util.isNull(accessTagNo) ? paramMap.get("accessTagNo") : accessTagNo;
        String chatbotid = context.getConfig().enterpriseProperty(accessTagNo, "chatbotIdenty");
        if (!Util.isNull(phone) && !Util.isNull(chatbotid)) {
            RcsSession rcsSession = context.getSession(phone, chatbotid);
            if(!Util.isNull(nick))
            rcsSession.put("nick", nick);
            String driving = Util.toString(paramMap.get("driving"), "");
            if(!rcsSession.containsKey("driving")&&!Util.isNull(driving))
                rcsSession.put("driving", driving);
            if (!Util.isNull(mdn))
                rcsSession.put("police_target_phone", mdn);
            JsonObject userLocation = new JsonObject();
            String address = "";
            if (!Util.isNull(position)) {
                JsonObject positionObject = JsonParser.parseString(position).getAsJsonObject();
                address = Util.getElementAsString(positionObject, "address");
                if (!Util.isNull(address))
                    address = URLDecoder.decode(address,"UTF-8");
                latitude = Util.getElementAsString(positionObject, "latitude");
                longitude = Util.getElementAsString(positionObject, "longitude");
                if (!Util.isNull(latitude)&&!Util.isNull(longitude)) {
               	 //�ٶȵ�ͼ BD����ϵ תWGS84����ϵ
                   double lat = Double.valueOf(latitude);
                   double lng = Double.valueOf(longitude);
                   if(Util.isNull(address)) {
	                   CompletableFuture.supplyAsync(() -> {
	                       fillLocationAddress(rcsSession, lat+"", lng+"",false);
	                       return null;
	                   });
                   }
                   PositionUtil.Gps gps =  PositionUtil.bd09_To_Gps84(lat, lng);
               	   userLocation.addProperty("address", address);
                   userLocation.addProperty("latitude", gps.getWgLat());
                   userLocation.addProperty("longitude", gps.getWgLon());
                   rcsSession.put("userLocation", userLocation);
                   rcsSession.put("userLocationMap", new Gson().fromJson(userLocation, Map.class));
               }
                
            }
            else if (!Util.isNull(latitude) && !Util.isNull(longitude)&&Util.isNull(address)) {
                String finalLatitude = latitude;
                String finalLongitude = longitude;
                //WGS84 ����ϵ
                userLocation.addProperty("latitude",finalLatitude);
                userLocation.addProperty("longitude", finalLongitude);
                userLocation.addProperty("address", "");
                rcsSession.put("userLocation", userLocation);
                rcsSession.put("userLocationMap", new Gson().fromJson(userLocation, Map.class));
                CompletableFuture.supplyAsync(() -> {
                    fillLocationAddress(rcsSession, finalLatitude, finalLongitude,true);
                    return null;
                });
            }
        }
        // �û�token��֤
        int nextcheck = -1;
        if (!authAction.validateUri(whitelistUri, uri)) {
            if (Util.isNull(accessToken)) {
                accessToken = "";
                nextcheck = 2;
            }

            boolean isExpired = true; // true=�ѹ���
            try {
                if (!Util.isNull(accessToken) && AuthAction.logoutTokenQueue.contains(accessToken)) {
                    activeChannelUsers.remove(accessToken);
                    AuthAction.tokenValidateFailed(accessToken, remoteAddr, req, rsp);
                    return;
                }
                if (!Util.isNull(accessToken))
                    isExpired = jwtOperatorUtil.isTokenExpired(accessToken);
            } catch (Exception ignored) {
            }
            if (!Util.isNull(accessToken)) {
                if (isExpired) {
                    long lastActiveTime = 0;
                    if (activeChannelUsers.containsKey(accessToken)) {
                        lastActiveTime = activeChannelUsers.get(accessToken);
                    }
                    if (lastActiveTime == 0 || System.currentTimeMillis() - lastActiveTime > applicationconfig.LOGIN_CHANNEL_MAXIDLETIME_SECOND * 1000) {
                        activeChannelUsers.remove(accessToken);
                        String skey = "tokenKey".hashCode() + "";
                        RcsSession session = context.getSession(skey);
                        String refreshToken = Util.toString(session.get("token-" + accessToken));
                        boolean validate = jwtOperatorUtil.validateToken(refreshToken);
                        if (validate) {
                            session.remove("token-" + accessToken);
                            String newToken = authAction.generateAccessToken(refreshToken);
                            session.put("token-" + newToken, refreshToken);
                            activeChannelUsers.put(newToken, System.currentTimeMillis());
                            ((HttpServletResponse) response).setHeader("access-token", newToken);
                            chain.doFilter(request, response);
                            return;
                        }
                        if (loginType.equals("password")) {
                            nextcheck = 1;
                        } else {
                            nextcheck = 2;
                        }
                    } else {
                        chain.doFilter(request, response);
                        return;
                    }
                } else {
                    activeChannelUsers.put(accessToken, System.currentTimeMillis());
                    chain.doFilter(request, response);
                    return;
                }
            }
        }

        // api ����ӿ�sign��֤
        if (!Util.isNull(signature) && !Util.isNull(timestamp) && !Util.isNull(nonce) && !Util.isNull(username)) {
            boolean flag = validateSignature(context, username, phone, timestamp, remoteAddr, signature, req, rsp, nonce, accessTagNo);
            if (flag) {
                resetToken(req, rsp, username, "", "signature", "signature");
                chain.doFilter(request, response);
                return;
            }
        }
        if (nextcheck == 1)
            AuthAction.tokenValidateFailed(accessToken, remoteAddr, req, rsp);
        if (nextcheck == 2)
            AuthAction.signatureValidateFailed(accessToken, remoteAddr, req, rsp);
    }

    private String unknownUserLogin(HttpServletRequest req, HttpServletResponse rsp, BaseRcsContext context, String sid, String channle) throws IOException {
        Map<String, Object> session = context.getSession(sid);
        String mdn = (session == null || Util.isNull(session.get("mdn") + "")) ? "unKnownUser" : Util.toString(session.get("mdn"));
        JsonObject userObj = authAction.getRcsUserPermission(mdn);
        boolean insertRcsUserFlag = true;
        if (userObj == null) {
            insertRcsUserFlag = authAction.insertRcsUser(mdn, "", 1, channle, "", "", "", "");
        }
        String accessToken = "";
        if (insertRcsUserFlag) {
            JsonObject ydzyUserObj = authAction.getUserByMobile(mdn);
            long userId = 0;
            String username = "";
            String password = "";
            if (ydzyUserObj == null) {
                userId = authAction.insertYdzyUser(mdn);
            } else {
                userId = StringUtil.toLong(Util.getElementAsString(ydzyUserObj, "userid"));
            }
            boolean isertYdzyUserFlag = userId > 0;
            if (isertYdzyUserFlag) {
                JsonObject grantObj = authAction.getUserGrantByUid(userId);
                if (grantObj == null) {
                    isertYdzyUserFlag = authAction.insertYdzyUserGrant(userId, mdn);
                    username = mdn;
                    password = "000000";
                } else {
                    username = Util.getElementAsString(grantObj, "identifier");
                    password = Util.getElementAsString(grantObj, "credential");
                    if (!Util.isNull(password))
                        password = cryptoDES.decode(password);
                }
            }
            if (isertYdzyUserFlag) {
                accessToken = resetToken(req,rsp, username,password, "sid", applicationconfig.LOGIN_LOGINMODE);
            }
        }
        return accessToken;
    }

    private String resetToken(HttpServletRequest req, HttpServletResponse rsp, String username, String password, String loginType, String loginMode) throws IOException {
        String accessTokenUrl = applicationconfig.LOGIN_ACCESSTOKEN_URL;
        HashMap<String, Object> payload = Maps.newHashMap();
        payload.put("type", loginType);
        String accessToken = authAction.getAccessToekn(username, password, loginMode, accessTokenUrl, payload);
        try {
			Claims claims = jwtOperatorUtil.getClaimsFromToken(accessToken);
			String refreshToken = jwtOperatorUtil.generateToken(claims, applicationconfig.LOGIN_REFRESHTOKEN_EXPIREIN_SECOND);
			rsp.setHeader("access-token", accessToken);
			rsp.setHeader("refreshToken", refreshToken);
			req.setAttribute(HttpHeaders.AUTHORIZATION, refreshToken);
		} catch (Exception e) {
		}
        return accessToken;
    }

    public void init(FilterConfig filterConfig) throws ServletException {
        Enumeration<String> enums = filterConfig.getInitParameterNames();

        while (enums.hasMoreElements()) {
            String param = enums.nextElement();
            System.out.println(param + ":" + filterConfig.getInitParameter(param));
        }
    }

    private synchronized List<String> getSubList(String prefix) {
        if (serverName == null) {
            String webUrl = LoadProperties.systemProperties.getProperty("webUrl");
            try {
                URL url = new URL(webUrl);
                serverName = url.getPath();
                if (!Util.isNull(serverName) && serverName.endsWith("/")) {
                    serverName = serverName.substring(0, serverName.length() - 1);
                }
            } catch (Exception e) {
                serverName = "/hw";
                log.error("parse webUrl error, use default servername:/hw");
            }
        }
        List<String> list = new ArrayList<>();
        LoadProperties.systemProperties.propertyNames().asIterator().forEachRemaining(o -> {
            if (o != null && o.toString().startsWith(prefix)) {
                String uri = LoadProperties.systemProperties.getProperty(o.toString());
                uri = uri.replace("{serverName}", serverName);
                list.add(uri);
            }
        });
        return list;
    }

    /**
     * ��Ծ�����û�
     * key=������+phone/sid
     * value=����Ծʱ���
     */
    private static final Map<String, Long> activeChannelUsers = new ConcurrentHashMap<>();

    private void fillLocationAddress(RcsSession rcsSession, String latitude, String longitude,boolean convertGPS) {
        try {
        	if(convertGPS)
        	{
        		double lat = Double.valueOf(latitude);
        		double lng = Double.valueOf(longitude);
        		PositionUtil.Gps gps =  PositionUtil.gps84_To_Gcj02(lat, lng);
        		if(gps==null)
        			return ;
        		gps =  PositionUtil.gcj02_To_Bd09(gps.getWgLat(), gps.getWgLon());
        		latitude=gps.getWgLat()+"";
        		longitude=gps.getWgLon()+"";
        	}
            JsonObject locationJsonObject=new JsonObject();
            JsonObject lpoint=new JsonObject();
            lpoint.addProperty("lng", longitude);
            lpoint.addProperty("lat", latitude);
            locationJsonObject.add("lpoint", lpoint);
             locationParse.reAddress(locationJsonObject);
            String address = Util.getElementAsString(locationJsonObject, "address");
            JsonObject locationObject = (JsonObject) rcsSession.get("userLocation");
            if(locationObject==null)
            	locationObject=new JsonObject();
            locationObject.addProperty("address", address);
            locationObject.add("lpoint", lpoint);
            rcsSession.put("userLocation", locationObject);
            rcsSession.put("userLocationMap", new Gson().fromJson(locationObject, Map.class));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}