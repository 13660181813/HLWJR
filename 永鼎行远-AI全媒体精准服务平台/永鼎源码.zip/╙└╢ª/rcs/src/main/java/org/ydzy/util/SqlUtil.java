package org.ydzy.util;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import javax.sql.DataSource;

import org.eclipse.jetty.util.StringUtil;
import org.ydzy.rcs.db.XmlSqlGenerator;
import org.ydzy.rcs.db.XmlSqlGenerator.innerSql;
import org.ydzy.util.crypto.cryptoDES;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonNull;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

public class SqlUtil {
	 private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(SqlUtil.class);
	public static String encodeKeys(String oldV,boolean encry)
	{
		if(encry&&!Util.isNull(oldV))
			oldV=cryptoDES.encode(oldV);
		return oldV;
	}

	public static boolean updateRecords(DataSource dataSource,String sql,Object[] args) throws SQLException
	{
		if(args==null || args.length == 0)
			return updateRecords(dataSource, sql);
		log.debug("update sql {}  args {} ",sql,new Gson().toJson(args));
		long start=System.currentTimeMillis();
		try(Connection con = dataSource.getConnection();
				PreparedStatement stat = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)){
				for(int i=0;i<args.length;i++) {
					if(Util.isNull(Util.toString(args[i])))
						stat.setObject(i+1, null);
					else
					stat.setObject(i+1, args[i]);
				}
				stat.executeUpdate();
				try (ResultSet rs = stat.getGeneratedKeys()) {
		            if (rs.next()) {
		                long id = rs.getLong(1); // ע�⣺������1��ʼ
		            }
		        }
				try{
					con.commit();
				}catch(Throwable ignore) {
				}
				long end=System.currentTimeMillis();
				log.debug("update sql {}    duration {} ms ",sql,end-start);
				return true;
			}catch(SQLException e) {
				log.error("Insert log error,%s", sql ,e );
				throw e;
			}
	}

	public static boolean batchUpdateRecords(DataSource dataSource,String sql,List<List<String>> args) throws SQLException {
		if (args == null || args.size() == 0)
			return updateRecords(dataSource, sql);
		log.info("update sql {}  args {} ", sql, new Gson().toJson(args));
		try (Connection con = dataSource.getConnection();
			 PreparedStatement stat = con.prepareStatement(sql)) {
			for (int i = 0; i < args.size(); i++) {
				for (int j = 0; j < args.get(i).size(); j++) {
					stat.setObject(j + 1, args.get(i).get(j));
				}
				stat.addBatch();
			}
			stat.executeBatch();
			try {
				con.commit();
			} catch (Throwable ignore) {
			}
			return true;
		} catch (SQLException e) {
			log.error("Insert log error,%s", sql, e);
			throw e;
		}
	}

	public static boolean updateRecords(DataSource dataSource,String sql) throws SQLException
	{
		log.debug("update sql {}   ",sql);
        Connection con = dataSource.getConnection();
		con.setAutoCommit(false);
	    if (StringUtil.isNotBlank(sql)) {
	    	PreparedStatement stat = null;
	        try {
				String[] sqls = sql.split(";");
				for(String s : sqls) {
					if (StringUtil.isBlank(s) || s.trim().equals(";"))
						continue;
					
					stat = con.prepareStatement(s);
					stat.execute();
				}
				con.commit();
			} catch (SQLException e) {
				log.error("update Records error {}", sql ,e );
				con.rollback();
				
				stat = con.prepareStatement(sql);
				stat.execute();
				con.commit();
				throw e;
			}
	        finally {
				if (stat != null)
					stat.close();
				con.close();
			}
        }
	    return true;
	    /*
		try(
				Connection con = dataSource.getConnection();
				PreparedStatement stat = con.prepareStatement(sql)){
				stat.execute();
				try{
					con.commit();
				}catch(Throwable ignore) {}
				return true;
			}catch(SQLException e) {
				log.error("Insert log error,%s", sql ,e );
				throw e;
			}
	     */
	}

	/**
	 * ���¼�¼���ύ��������ⲿ��������
	 */
	public static boolean updateRecords(Connection connection,String sql) throws SQLException {
		log.debug("update sql {}   ", sql);
		if (StringUtil.isNotBlank(sql)) {
			PreparedStatement stat = null;
			try {
				String[] sqls = sql.split(";");
				for (String s : sqls) {
					if (StringUtil.isBlank(s) || s.trim().equals(";"))
						continue;

					stat = connection.prepareStatement(s);
					stat.execute();
				}
			} catch (SQLException e) {
				log.error("update Records error {}", sql, e);
				throw e;
			} finally {
				if (stat != null)
					stat.close();
			}
		}
		return true;
	}

	/**
	 * �����¼���ύ��������ⲿ��������
	 */
	public static void insert(Connection connection, String sql, Object ... args) throws SQLException {
		log.info("update sql {}  args {} ", sql, new Gson().toJson(args));
		if (sql.contains(" ; ")) {
			updateRecords(connection, sql);
			return;
		}
		try (PreparedStatement stat = connection.prepareStatement(sql)) {
			for (int i = 0; i < args.length; i++) {
				stat.setObject(i + 1, args[i]);
			}
			stat.execute();
		} catch (SQLException e) {
			log.error("insert data error, {}", sql, e);
			throw e;
		}
	}

//	public static Long getLastInsertId(DataSource ds) {
//		long lastId = -1;
//		try {
//			lastId = queryForJson(ds, "SELECT LAST_INSERT_ID() AS LASTID;").get(0).getAsJsonObject().get("LASTID").getAsLong();
//		} catch (Exception ignored) {
//		}
//		return lastId;
//	}

	public static long getLastInsertId(DataSource ds, String sql) {
		long lastId = -1;
		try {
			lastId = queryForJson(ds, sql).get(0).getAsJsonObject().get("id").getAsLong();
		} catch (Exception ignored) {
		}
		return lastId;
	}

	public static long insertStat(DataSource dataSource, String sql, JsonObject jsonParam) throws SQLException {
		Pattern p = Pattern.compile("\\{(.*?)}");;
		List<String> list = new ArrayList<String>();
		Matcher m = p.matcher(sql);
		while (m.find()) {
			list.add(m.group().substring(1, m.group().length() - 1));
		}
		Object[] params = new Object[list.size()];
		int i = 0;
		for (String s : list) {
			sql = sql.replace("'{" + s + "}'", "?");
			if (jsonParam.get(s) == null) {
				params[i] = "";
				i++;
				continue;
			}
			if (jsonParam.get(s).isJsonPrimitive())
				params[i] = jsonParam.get(s).getAsString();
			else
				params[i] = jsonParam.get(s).toString();
			i++;
			if (i == list.size())
				break;
		}
		return insert(dataSource, sql, params);
	}

	public static long insert(DataSource dataSource, String sql, Object ... args) throws SQLException {
		log.info("update sql {}  args {} ", sql, new Gson().toJson(args));
		if(sql.indexOf(" ; ")>-1) {
			updateRecords(dataSource,sql);
			return 0;
		}
		 long id=0;
		try (Connection con = dataSource.getConnection();
			 PreparedStatement stat = con.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS)) {
			for (int i = 0; i < args.length; i++) {
				stat.setObject(i + 1, args[i]);
			}
			stat.execute();
			try (ResultSet rs = stat.getGeneratedKeys()) {
	            if (rs.next()) {
	                 id = rs.getLong(1); // ע�⣺������1��ʼ
	            }
	        }
			try {
				con.commit();
			} catch (Throwable ignore) {
			}
			return id;
		} catch (SQLException e) {
			log.error("insert data error, {}", sql, e);
			throw e;
		}
	}


	public static long insertBySqlId(DataSource ds, String sqlId, Object... params) throws SQLException {
		innerSql sql = XmlSqlGenerator.getSql(sqlId);
		if (sql == null)
			return -1;
		else
			return insert(ds, sql.exeSql, params);
	}

	private static JsonArray executeQuery(Statement stat, String sql) {
		try {
			ResultSet rs = null;
			if (stat instanceof PreparedStatement)
				rs = ((PreparedStatement) stat).executeQuery();
			else
				rs = stat.executeQuery(sql);
			ResultSetMetaData rsmd = rs.getMetaData();
			int numberOfColumns = rsmd.getColumnCount();
			Set<String> columnnames = new HashSet<String>();

			for (int i = 1; i <= numberOfColumns; i++) {
				columnnames.add(rsmd.getColumnLabel(i));
			}

			JsonArray all = new JsonArray();
			while (rs.next()) {
				JsonObject content = new JsonObject();
				for (String c : columnnames) {
					String v = rs.getString(c);
					String name = c;
					if((c.charAt(0) == '{' && c.charAt(c.length() - 1) == '}'))
						name=c.substring(1, c.length() - 1);
					if (!Util.isNull(c)&&c.length() > 3 && (c.charAt(0) == '{' && c.charAt(c.length() - 1) == '}')) {
						if (v != null && !v.isEmpty()) {
							try {
								JsonElement je = JsonParser.parseString(v);
								content.add(name, je);
							} catch (Exception e) {
								log.debug("Parse column({}) error!", c);
							}
						}
					} else {
						content.addProperty(name, v);
					}
				}
				all.add(content);
			}
			long end = System.currentTimeMillis();
			log.info("query sql {} ", sql);
			return all;

		} catch (Exception e) {
			log.error("execute query error.", e);
		}
		return new JsonArray();
	}

	public static JsonArray queryForJson(DataSource dataSource, String sql, Object... params) throws SQLException {
		try (Connection con = dataSource.getConnection();
			 PreparedStatement stat = con.prepareStatement(sql)) {
			for (int i = 0; i < params.length; i++) {
				if (Util.isNull(Util.toString(params[i])))
					stat.setObject(i + 1, null);
				else
					stat.setObject(i + 1, params[i]);
			}
			return executeQuery(stat, sql);


		} catch (SQLException e) {
			log.error("querye log error, {}", sql, e);
			throw e;
		}
	}

	public static JsonArray queryForJson(DataSource dataSource, String sql) throws SQLException {
		log.debug("query sql {}   ", sql);
		long start = System.currentTimeMillis();
		try (Connection con = dataSource.getConnection();
			 Statement stat = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY)) {
			return executeQuery(stat, sql);
		} catch (SQLException e) {
			log.error("sql execute error {} ", sql);
			throw e;
		}

	}

	public static String parse(String model, JsonObject jsonObject, JsonArray encodekeys) {
		if (Util.isNull(model))
			return "";
		Gson gson = new Gson();
		String encodes = "";

		if(encodekeys!=null)
		encodes=gson.toJson(encodekeys);
		for (String k:jsonObject.keySet()) {
			boolean encry=false;
			if(!Util.isNull(encodes)&&encodes.indexOf(k)>-1)
				encry=true;
			JsonElement val = jsonObject.get(k);
			if(val instanceof JsonObject){
				model = parse(model,(JsonObject)val,encodekeys);
			}else if(val instanceof JsonArray){
				Pattern repeatedly = Pattern.compile("(((?!;).)*\\/\\*\\{"+k+"\\}\\*\\/((?!;).)*;?)");///*{APP_ID}*/ expand sqls
				Matcher m = repeatedly.matcher(model);
					while (m.find()) {
						StringBuffer repeat = new StringBuffer();
						String single = m.group(0);
						for (JsonElement e : (JsonArray) val) {
							repeat.append(single.replaceAll("/\\*\\{" + k + "\\}\\*/", encodeKeys(e.getAsString().replace(";", "%3B").replace("'", "''").replace('"', '\"'), encry)));
						}
						model = model.replace(single, repeat.toString());
					}
				repeatedly = Pattern.compile("\\'?\\/\\$\\{"+k+"\\}\\$\\/\\'?");
				 m = repeatedly.matcher(model);
				if(m.find()) {//'/${APP_ID}$/'  pattern convert to in ()
					String express =m.group(0);
					boolean  start=express.startsWith("'")&&express.endsWith("'");
					StringBuffer repeat = new StringBuffer();
					for (JsonElement e:(JsonArray)val) {
						repeat.append(start?"'":"").append(encodeKeys(e.getAsString().replace(";","%3B").replace("'","''").replace('"','\"'),encry)).append(start?"',":",");
					}
					if(repeat.toString().endsWith(","))
						model =model.replaceAll("=\\s*\\'?\\/\\$\\{"+k+"\\}\\$\\/\\'?"," in ("+repeat.toString().substring(0,repeat.toString().length()-1)+" ) ");

				}
			}else{
				if(val!=null&& !(val instanceof com.google.gson.JsonNull))
				model = model.replaceAll("\\{"+k+"\\}",encodeKeys(val.getAsString().replace(";","%3B").replace("'","''").replace('"','\"'),encry));
			}
		}
		model = model.trim();
		if(model.endsWith(";")){
			model.substring(0,model.length()-1);
		}
		return model;
	}

	public static String parse2Param(String model, JsonObject jsonObject,JsonArray encodekeys){
		if(Util.isNull(model))
			return "";
		Gson gson =new Gson();
		String encodes = "";

		if(encodekeys!=null)
		encodes=gson.toJson(encodekeys);
		for (String k:jsonObject.keySet()) {
			boolean encry=false;
			if(!Util.isNull(encodes)&&encodes.indexOf(k)>-1)
				encry=true;
			JsonElement val = jsonObject.get(k);
			if(val instanceof JsonObject){
				model = parse(model,(JsonObject)val,encodekeys);
			}else if(val instanceof JsonArray){
				Pattern repeatedly = Pattern.compile("(((?!;).)*\\/\\*\\{"+k+"\\}\\*\\/((?!;).)*;?)");///*{APP_ID}*/ expand sqls
				Matcher m = repeatedly.matcher(model);
				if(((JsonArray) val).size()<=10) {
					while (m.find()) {
						StringBuffer repeat = new StringBuffer();
						String single = m.group(0);
						for (JsonElement e : (JsonArray) val) {
							repeat.append(single.replaceAll("/\\*\\{" + k + "\\}\\*/", encodeKeys(e.getAsString().replace(";", "%3B").replace("'", "''").replace('"', '\"'), encry)));
						}
						model = model.replace(single, repeat.toString());
					}
				}else{
					model=model.replaceAll("'/\\*\\{" + k + "\\}\\*/'","?");
				}
				repeatedly = Pattern.compile("\\'?\\/\\$\\{"+k+"\\}\\$\\/\\'?");
				 m = repeatedly.matcher(model);
				if(m.find()) {//'/${APP_ID}$/'  pattern convert to in ()
					String express =m.group(0);
					boolean  start=express.startsWith("'")&&express.endsWith("'");
					StringBuffer repeat = new StringBuffer();
					for (JsonElement e:(JsonArray)val) {
						repeat.append(start?"'":"").append(encodeKeys(e.getAsString().replace(";","%3B").replace("'","''").replace('"','\"'),encry)).append(start?"',":",");
					}
					if(repeat.toString().endsWith(","))
						model =model.replaceAll("=\\s*\\'?\\/\\$\\{"+k+"\\}\\$\\/\\'?"," in ("+repeat.toString().substring(0,repeat.toString().length()-1)+" ) ");

				}
			}else{
				if(val!=null&& !(val instanceof com.google.gson.JsonNull))
				model = model.replaceAll("\\{"+k+"\\}",encodeKeys(val.getAsString().replace(";","%3B").replace("'","''").replace('"','\"'),encry));
			}
		}
		model = model.trim();
		if(model.endsWith(";")){
			model.substring(0,model.length()-1);
		}
		return model;
	}

	static Pattern Condtionpattern=Pattern.compile("\\/\\*[^\\*\\/]+\\*\\/");
	public static String replaceSqlWidthParam(String sql, JsonObject query)
	{
		 Matcher match =Condtionpattern.matcher(sql);
			while(match.find())
			{
				String colCondtion=match.group();
				if(colCondtion.indexOf("{")>0&&colCondtion.indexOf("}")>0) {
					String colid=colCondtion.substring(colCondtion.indexOf("{")+1,colCondtion.indexOf("}"));
					if(query.has(colid)&&!(query.get(colid) instanceof JsonNull) &&!(query.get(colid) instanceof JsonArray)&&!(query.get(colid) instanceof JsonObject)){
	                    String value = query.get(colid).getAsString();
	                    if(!Util.isNull(value)){
	                    	String ncon=colCondtion.replace("{"+colid+"}", EscapeSqlUtil.EscapeSqlStr(value)).replace("/*", "").replace("*/", "");
	                    	sql=sql.replace(colCondtion, (ncon));
	                    }
					}else if(query.has(colid)&&query.get(colid).isJsonArray()){
						Set<String> vals = new HashSet<>();
						JsonArray array = query.get(colid).getAsJsonArray();
						for (JsonElement e : array) {
							if(e.isJsonPrimitive())
								vals.add(e.getAsString());
						}
						if(vals.size()>0){
							String value = vals.stream().map((s)->"'"+s+"'").collect(Collectors.joining(","));
							String ncon =colCondtion.replaceAll("in\\s*'?\\{"+colid+"\\}'?","in ("+EscapeSqlUtil.EscapeSqlStr(value)+")")
									.replace("/*", "").replace("*/", "");
							sql=sql.replace(colCondtion, (ncon));
						}
					}
				}
			}
			return sql;
	}
	public static String replaceSqlWidthParam(String sql, Map<String,String> query)
	{
		 Matcher match =Condtionpattern.matcher(sql);
			while(match.find())
			{
				String colCondtion=match.group();
				if(colCondtion.indexOf("{")>0&&colCondtion.indexOf("}")>0) {
					String colid=colCondtion.substring(colCondtion.indexOf("{")+1,colCondtion.indexOf("}"));
					if(query.containsKey(colid)){
	                    String value = query.get(colid);
	                    if(!Util.isNull(value)){
	                    	String ncon=colCondtion.replace("{"+colid+"}", value).replace("/*", "").replace("*/", "");
	                    	sql=sql.replace(colCondtion, EscapeSqlUtil.EscapeSqlStr(ncon));
	                    }
					}
				}
			}
			return sql;
	}
	public static void main(String[] args) {

		String model="INSERT INTO USER_GROUP_MENU_RELATION (UGMR_ID,GROUPID,MENU_ID) VALUES (${seq},'{GROUPID}','/*{MENU_ID}*/');";
		model=model.replaceAll("'/\\*\\{MENU_ID\\}\\*/'","?");
		System.out.println(model);

//		String sql ="where= 1=1 and AND  TIMEINTERVAL$TIME = '1800' and time between a and b  ";//  col1= and col2 like '3'  or col4 in (1,2,1)
//		String find=findCondition(sql, "TIME");
//		if(!StringUtils.isNull(find))
//		{
//			System.out.println(find);
//			WhereEntity entry = SqlUtil.parseWhere2(find);
//			System.out.println(find +" condi: " +entry);
//		}
//		String sql ="   DELETE FROM ZUUL_USER_APP_RELATION WHERE GROUPID='{GROUPID}' AND APP_ID='/${APP_ID}$/';";

//		JsonObject obj =new JsonObject();
//		obj.addProperty("GROUPID", "1");
//		JsonArray array =new JsonArray();
//		array.add("1");
//		array.add("2");
//		obj.add("APP_ID",array);
//		JsonArray en =new JsonArray();
//		String result =parse(sql,obj,en);
//		System.out.println(result);
//		 sql ="   DELETE FROM ZUUL_USER_APP_RELATION WHERE GROUPID='{GROUPID}' AND APP_ID=/${APP_ID}$/;";
//		 result =parse(sql,obj,en);
//		 System.out.println(result);
//		 
//		 sql=" INSERT INTO USER_OPERATOR_RELATION (UORID,USERID,RIGHT_ID,RIGHT_TYPE,MENUID) VALUES (${seq},'{GROUPID}','/*{APP_ID}*/','1','{MENUID}');";
//		 result =parse(sql,obj,en);
//		 System.out.println(result);
	}

	public static String sqlEncode(String sql){
		try {
			sql=sql.replace(" ", "%20");
			sql= URLEncoder.encode(sql,"UTF-8");
			return sql;
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		return sql;
	}
	public static String sqlDecode(String sql){
		if(Util.isNull(sql)) return "";
		else {
			String t=sql.replace("%20", " ").replace("%2520", " ");
//			try {
//				t=URLDecoder.decode(t);
//			} catch (Exception e) {
//			}
			return t;
		}
	}
	

}
