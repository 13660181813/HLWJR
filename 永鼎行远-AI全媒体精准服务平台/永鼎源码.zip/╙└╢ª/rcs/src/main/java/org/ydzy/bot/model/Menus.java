package org.ydzy.bot.model;

import java.util.ArrayList;
import java.util.List;

/** �˵����� */
public class Menus{
	
	private String displayText;
	private List<MenuBase> entries = new ArrayList<>();
	
	public Menus(String displayText) {
		this.displayText = displayText;
	}
	
	public Menus() {
	}

	public String getDisplayText() {
		return displayText;
	}
	public void setDisplayText(String displayText) {
		this.displayText = displayText;
	}
	public List<MenuBase> getEntries() {
		return entries;
	}
	public void setEntries(List<MenuBase> entries) {
		this.entries = entries;
	}

}
