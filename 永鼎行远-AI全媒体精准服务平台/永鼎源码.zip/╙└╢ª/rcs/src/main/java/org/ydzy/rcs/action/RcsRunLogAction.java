package org.ydzy.rcs.action;

import java.sql.SQLException;

import javax.sql.DataSource;

import org.ydzy.rcs.db.XmlSqlGenerator;
import org.ydzy.util.SqlUtil;
import org.ydzy.util.Util;

public class RcsRunLogAction {
	static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(RcsRunLogAction.class);
    public static void recordLog(String action,String Desc,String reqIP,String status ,String simation,DataSource datasource,String mdn,String configid, String channel) {
    	String sql=XmlSqlGenerator.getSqlstr("insertRunning");
    		if(!Util.isNull(Desc)&&Desc.length()>2000)
    			Desc=Desc.substring(0,1999);
    		Object [] params= {action,Desc,reqIP,status,simation,mdn,Util.isNull(configid)||"{configid}".equals(configid)?"-1":configid,channel};
    		try {
				SqlUtil.updateRecords(datasource, sql,params);
				log.debug("write log to db sucess sql {} params {} ",sql,params);
			} catch (SQLException e) {
				e.printStackTrace();
			}
    }

	public static void recordLog(String action,String Desc,String reqIP,String status ,String simation,DataSource datasource,String mdn,String configid) {
		recordLog( action, Desc, reqIP, status , simation, datasource, mdn, configid, null);
	}
    public static void recordLog(String action,String Desc,String reqIP,String status ,String simation,String mdn,DataSource datasource) {
		recordLog(action,Desc,reqIP,status ,simation,datasource, mdn, null, null);
    }
    public static void recordLog(String action,String Desc,String reqIP,String status ,String simation,DataSource datasource) {
    	recordLog( action, Desc, reqIP, status , simation, datasource, null, null, null);
    }
}
