package org.ydzy.rcs.media;

import java.io.IOException;
import java.io.InputStream;
import java.security.MessageDigest;

public class SizedInputStream extends java.io.FilterInputStream{
	public SizedInputStream(InputStream in) {
		super(in);
	}

    /**
     * The message digest associated with this stream.
     */
    protected MessageDigest digest;
	public MessageDigest getDigest() {
		return digest;
	}
	public void setDigest(MessageDigest digest) {
		this.digest = digest;
	}
	
	private long offset = 0;
	public long getOffset() {
		return offset;
	}

	@Override
	public int read() throws IOException {
		int b = super.read();
		if(b>=0)offset++;
		if(digest!=null)digest.update((byte)b);
		return b;
	}

	@Override
	public int read(byte[] b, int off, int len) throws IOException {
		int l = super.read(b, off, len);
		if(l>0){
			offset+=l;
			if(digest!=null) digest.update(b, off, l);
		}
		return l;
	}
	
}