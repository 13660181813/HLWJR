package org.ydzy.rcs.action;

import org.ydzy.rcs.annotation.Description;
import org.ydzy.rcs.db.DBModule;

import com.google.inject.Binder;
import com.google.inject.Module;

@Description("RcsLogModule")
public class LogActionModule implements Module {
//	@Override
//	protected void configure() {
//		this.configure2(binder());
//	}
//	
	@Override
	public void configure(Binder binder) {
		configure2(binder);
		
	}
	
	protected void configure2(Binder binder) {
		binder.install(new DBModule());
		binder.bind(RcsLogAction.class).in(com.google.inject.Scopes.SINGLETON);
	}
	
}
