//
// ========================================================================
// Copyright (c) 1995-2020 Mort Bay Consulting Pty Ltd and others.
//
// This program and the accompanying materials are made available under
// the terms of the Eclipse Public License 2.0 which is available at
// https://www.eclipse.org/legal/epl-2.0
//
// This Source Code may also be made available under the following
// Secondary Licenses when the conditions for such availability set
// forth in the Eclipse Public License, v. 2.0 are satisfied:
// the Apache License v2.0 which is available at
// https://www.apache.org/licenses/LICENSE-2.0
//
// SPDX-License-Identifier: EPL-2.0 OR Apache-2.0
// ========================================================================
//

package org.ydzy.util;

import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.InvocationTargetException;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import org.apache.commons.beanutils.BeanUtils;
import org.eclipse.jetty.util.StringUtil;
import org.eclipse.jetty.util.resource.Resource;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonSyntaxException;

import jakarta.servlet.http.HttpServletRequest;

public class Util {

	public static String fileType(String filename) {
		java.util.regex.Pattern resges = Pattern.compile(
				"\\.((?:asf)|(?:asx)|(?:avi)|(?:IVF)|(?:m1v)|(?:m2v)|(?:m4e)|(?:movie)|(?:mp2v)|(?:mp4)|(?:mpa)|(?:mpe)|(?:mpg)|(?:mpeg)|(?:mps)|(?:mpv)|(?:mpv2)|(?:wm)|(?:wmv)|(?:wmx)|(?:wvx))");
		java.util.regex.Pattern imgeregex = Pattern.compile(
				"\\.(?:(?:tif)|(?:fax)|(?:gif)|(?:ico)|(?:jfif)|(?:jpe)|(?:jpeg)|(?:jpg)|(?:net)|(?:png)|(?:rp)|(?:tif)|(?:tiff)|(?:wbmp))");
		Matcher finded = resges.matcher(filename);
		if (!finded.find()) {
			finded = imgeregex.matcher(filename);
			if (finded.find())
				return "image";
			else {
				return "undefined";
			}
		} else {
			return "vedio";
		}
	}

	 static String regexParam = "\\{([^\\{\\}]*)\\}";
	    static Pattern regexPattern = Pattern.compile(regexParam);

		public static List<String> findParams(String msg) {
			if (Util.isNull(msg))
				return null;
			List<String> params = new ArrayList<String>();
			Matcher match = regexPattern.matcher(msg);
			while (match.find()) {
				params.add(match.group(1));
			}
			return params;
		}
		public static String replaceV(String rawstr, JsonObject param) {
			 Map<String, Object> map = (Map<String, Object>) new Gson().fromJson(param, Map.class);
			 return replaceV(rawstr,map);
		}
		public static Pattern findPattern(String param) {
			String findParam = "/\\*\\s*(and)?\\s*" + param + "\\s*=\\s*'?\\{\\s*"+param+"\\s*\\}'?\\s*\\*/"; // String findParam="\\*loadparam=.*\\*/";
			Pattern findP = Pattern.compile(findParam);
			return findP;

		}

		public static Map<String, String> findParameter(String param, String sql) {
			Map<String, String> params = new HashMap<String, String>();
			Pattern findP = findPattern(param);
			Matcher mater = findP.matcher(sql);
			if (mater.find()) {
					params.put(param, mater.group());
			}
			return params;

		}
		public static String replaceV(String rawstr, Map<String, Object> param) {
			List<String> params = findParams(rawstr);
			
			if (params == null)
				return rawstr;
			for (String p1 : params) {
				try {
					String v = BeanUtils.getNestedProperty(param, p1);
					try {
						if (!Util.isNull(v)) {
							rawstr = rawstr.replaceAll("\\{" + p1 + "\\}", v);
						} else {
							rawstr = rawstr.replaceAll("\\{" + p1 + "\\}", "");
						}
					} catch (Exception e) {
						rawstr = rawstr.replace("{" + p1 + "}", v);
					}
				} catch (IllegalAccessException | InvocationTargetException | NoSuchMethodException e) {
					e.printStackTrace();
				}
			}
			return rawstr;
		}

	/**
	 * @param result
	 * @return JsonObject
	 */
	public static  JsonObject str2JsonObject(String result) {
		try {
			if (!Util.isNull(result)) {
				JsonElement resultObject = JsonParser.parseString(result);
				if (resultObject != null && !resultObject.isJsonNull()) {
					JsonObject resultO = resultObject.getAsJsonObject();
					return resultO;
				}
			}
		} catch (JsonSyntaxException e) {
		}
		return null;
	}

	public static String spiltNumbers(String address) {
		if (!Util.isNull(address)) {
			String split = "@";
			address = address.split(split)[0].replace("+86", "");
			String[] tmps = address.split(":");
			address = tmps[tmps.length-1];
			return address;
		} else {
			return "";
		}
	}

	public static String realToString(String result) {
		return realToString(result, 4);
	}

	public static String realToString(String result, int offset) {
		if (offset < 0)
			offset = 0;
		final int length = result.length();
		// Remove leading zeros.
		int dotindex = result.indexOf(".");
		if (dotindex > -1 && length - dotindex > 3) {
			int endIndex = Math.min(dotindex + offset, length);
			return result.substring(0, endIndex);
		}
		else
			return result;
	}

	public static final String toString(Object obj, String defaultstr) {
		if (obj == null || isNull(obj.toString())) {
			return defaultstr;
		} else
			return obj.toString();
	}

	public static String getElementAsString(JsonObject object, String eleText) {
		return getElementAsString(object, eleText, "");
	}

	public static int getElementAsInt(JsonObject object, String eleKey, int defaultValue) {
		String elementAsString = getElementAsString(object, eleKey, "");
		if(Util.isNull(elementAsString))
			return defaultValue;
		try{
			return Integer.parseInt(elementAsString);
		}catch (NumberFormatException e){
			return defaultValue;
		}
	}

	public static String getElementAsString(JsonObject object, String eleText, String defaultv) {
		Gson gson =new Gson();
		if (object != null && object.get(eleText) != null && !object.get(eleText).isJsonNull()) {
			if (object.get(eleText).isJsonArray())
				return gson.toJson(object.get(eleText));
			else if (object.get(eleText).isJsonObject())
				return gson.toJson(object.get(eleText));
			else
				return object.get(eleText).getAsString();
		}
		return defaultv;
	}

	public static String getElementDeepAsString(JsonObject object, String eleText, String Objectkey, String defaultv) {
//		if (object != null && object.get(eleText) != null && !object.get(eleText).isJsonNull()) {
//				return getElementAsString(object,eleText);
//		}
		if (object != null && object.has(eleText) && !object.get(eleText).isJsonNull()
				&& object.getAsJsonObject(eleText).has(Objectkey)) {
			return getElementAsString(object.getAsJsonObject(eleText), (Objectkey));
		}
		return defaultv;
	}

	public static String getElementDeepAsString(JsonObject object, String eleText, String Objectkey) {
		return getElementDeepAsString(object, eleText, Objectkey, "");
	}

	private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(Util.class);

	/**
	 * Get a port, possibly configured from Command line or System property.
	 *
	 * @param args         the command line arguments
	 * @param propertyName the property name
	 * @param defValue     the default value
	 * @return the configured port
	 */
	public static int getPort(String[] args, String propertyName, int defValue) {
		for (String arg : args) {
			if (arg.startsWith(propertyName + "=")) {
				String value = arg.substring(propertyName.length() + 2);
				int port = toInt(value);
				if (isValidPort(port))
					return port;
			}
		}

		String value = System.getProperty(propertyName);
		int port = toInt(value);
		if (isValidPort(port))
			return port;

		return defValue;
	}

	/**
	 * Test if port is in the valid range to be used.
	 *
	 * @param port the port to test
	 * @return true if valid
	 */
	private static boolean isValidPort(int port) {
		return (port >= 0) && (port <= 65535);
	}

	/**
	 * Parse an int, ignoring any {@link NumberFormatException}
	 *
	 * @param value the string value to parse
	 * @return the int (if parsed), or -1 if not parsed.
	 */
	private static int toInt(String value) {
		if (StringUtil.isBlank(value))
			return -1;

		try {
			return Integer.parseInt(value);
		} catch (NumberFormatException ignored) {
			// ignored
			return -1;
		}
	}

	/**
	 * @param fileName
	 * @return find file from localfilesystem or jars
	 */
	public static Set<String> getjarAndLocalFilePath(String fileName) {
		Set<String> files = new HashSet<String>();
		String path = Util.class.getProtectionDomain().getCodeSource().getLocation().getPath();
		try {
			path = java.net.URLDecoder.decode(path, "utf-8");
			if (path.endsWith(".jar")) {
				JarFile localJarFile = new JarFile(new File(path));
				Enumeration<JarEntry> entries = localJarFile.entries();
				while (entries.hasMoreElements()) {
					JarEntry jarEntry = entries.nextElement();
					String name = jarEntry.getName();
					if (name.indexOf(fileName) > -1) {
						log.info("find fileName: {} in path {} ", name, path);
						files.add(name);
					}
				}
			} else {
				File f = new File(path, fileName);
				if (f.exists()) {
					if (f.isDirectory()) {
						List<String> childfils = java.util.Arrays.asList(f.list()).stream()
								.map((fs) -> fileName + File.separator + fs).collect(Collectors.toList());
						files.addAll(childfils);
					} else {
						files.add(f.getAbsolutePath());
					}
				}
			}

		} catch (UnsupportedEncodingException e) {
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			File localfile = Resource.newSystemResource(fileName).getFile();
			if (localfile.exists()) {
				if (localfile.isDirectory()) {
					List<String> childfils = java.util.Arrays.asList(localfile.list()).stream()
							.map((f) -> fileName + File.separator + f).collect(Collectors.toList());
					files.addAll(childfils);
				} else {
					files.add(localfile.getAbsolutePath());
				}

			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return files;
	}

	public static String trim(final String str) {
		return str == null ? null : str.trim();
	}

	public static String toString(Object o) {
		if (o == null) {
			return "";
		} else
			return o.toString();
	}

	public static String trim(final Object str) {
		return str == null ? null : toString(str).trim();
	}

	public static boolean isNull(String str) {
		return str == null || str.isEmpty() || str.isBlank() || "null".equalsIgnoreCase(str);
	}

	public static Class<?> loadClass(String classname) {
		ClassLoader currCtxCl = Thread.currentThread().getContextClassLoader();
		try {
			Class<?> clazz = (Class<?>) currCtxCl.loadClass(classname);
			return clazz;
		} catch (ClassNotFoundException e) {
			log.error("config error !  {} package error ", classname, e);
		} catch (SecurityException e) {
			log.error("config error !    Access error {}   ", classname, e);
		}
		return null;
	}

	public final static String PhoneReg = "\\(0\\d{2}\\)[- ]?\\d{8}|0\\d{2}[- ]?\\d{8}|\\(0\\d{3}\\)[- ]?\\d{7}|0\\d{3}[- ]?\\d{7}";

	/**
	 * �ж��Ƿ�绰����
	 * 
	 * @param phone �绰����str
	 * @return true:�� false������
	 */
	public static boolean istelphone(String phone) {
		return check("(" + PhoneReg + ")", phone);
	}

	public static boolean check(String regex, String value) {
		Pattern pattern = Pattern.compile(regex);
		Matcher reg = pattern.matcher(value);
		while (reg.find()) {
			return true;
		}
		return false;
	}

	public static <E> E reflect(Class<E> clazz, Object... initArgs) throws Exception {
		if (clazz == null)
			throw new NullPointerException();
		try {
			E instance = clazz.getDeclaredConstructor().newInstance(initArgs);
			return instance;
		} catch (InstantiationException e) {
			log.error("config error !  {}  ", clazz.getName(), e);
			throw e;
		} catch (IllegalAccessException e) {
			log.error("config error !  ", clazz.getName(), e);
			throw e;
		} catch (IllegalArgumentException e) {
			log.error("config error !  ", clazz.getName(), e);
			throw e;
		} catch (InvocationTargetException e) {
			log.error("config error ! ", clazz.getName(), e);
			throw e;
		} catch (NoSuchMethodException e) {
			log.error("config error ! ", clazz.getName(), e);
			throw e;
		}
	}

	public static <E> E reflect(Class<E> clazz) throws Exception {
		if (clazz == null)
			throw new NullPointerException();
		try {
			E instance = clazz.getDeclaredConstructor().newInstance();
			return instance;
		} catch (InstantiationException e) {
			log.error("config error !  {}  ", clazz.getName(), e);
			throw e;
		} catch (IllegalAccessException e) {
			log.error("config error !  ", clazz.getName(), e);
			throw e;
		} catch (IllegalArgumentException e) {
			log.error("config error !  ", clazz.getName(), e);
			throw e;
		} catch (InvocationTargetException e) {
			log.error("config error ! ", clazz.getName(), e);
			throw e;
		} catch (NoSuchMethodException e) {
			log.error("config error ! ", clazz.getName(), e);
			throw e;
		}
	}

	public static void main(String[] args) {
//    	Class<? extends DbAccessor> acc=(Class<? extends DbAccessor>) loadClass("org.ydzy.db.impl.OracleAccessor");
//		try {
//			DbAccessor	sor = reflect(acc);
//			System.out.println(sor);
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		System.out.println(Util.encrypt("sXR=D~LdIzk5_H-gP?y&vOF~l202105311716552B5A91EE20210531171655"));
		
		/*

		username=fz0707&timestamp=1626848492&signature=xpaBY3OeyoW2WNdAGZaQeHlDJwX1lnJp6hdluBOszG4=
		http://127.0.0.1:18084/rzlcfz/submit?username=fz0707&timestamp=1626848492&signature=xpaBY3OeyoW2WNdAGZaQeHlDJwX1lnJp6hdluBOszG4=
username=fz0707, password=399e835dfc7475a9, timestamp=1627615311


		mySign=jyY/s2bHn4PSbbNiKnZMUI3v6xcTOQvXFc+T6c6G3Ks= username=fz0707, password=399e835dfc7475a9, timestamp=1627027428
		 */

//		String username = "fz0707";
//		String password = "399e835dfc7475a9";
//		long timestamp = Instant.now().getEpochSecond();
//		timestamp = 1627616756;
//		byte[] sha256 = Util.digest(username, password, timestamp+"");
//		String mySign = Base64.getEncoder().encodeToString(sha256);
//		System.out.println(timestamp + "  " + mySign);
//		String url = "http://127.0.0.1:18084/rzlcfz/submit?username="+username+"&timestamp="+timestamp+"&signature="+mySign;
//		System.out.println(url);
//
//
//		byte[] sha256a = Util.digest(username, password, timestamp+"");
//		String mySigna = Base64.getEncoder().encodeToString(sha256a);
//		System.out.println(mySigna);
		String sql="SELECT o.status orderStatus, s.*, o.createdtime ocreatedtime,c.desc\r\n"
				+ "			FROM gz110_order o LEFT JOIN gz110_sessions s ON o.orderid=s.orderid left join rcs_company_grant c on s.skillGroup=c.username /*AND o.currentSkillGroup=s.skillGroup*/ WHERE o.status<20 AND o.createdTime>DATE_SUB(SYSDATE(),INTERVAL 60 DAY)\r\n"
				+ "			AND (o.phone='{phone}' OR s.orderid='{phone}') and o.chatbotid='{chatbotid}'\r\n"
				+ "			and s.sno in (select max(sno) from gz110_sessions where 1=1 /*and orderid='{orderid}'*/ /*and sid='{sid}'*/  group by sid,`status`)\r\n"
				+ "			ORDER BY o.createdtime asc,s.createdtime asc,orderid asc\r\n"
				+ "";
		Map<String, String> map = 	Util.findParameter("sid", sql);
		System.out.println(map);


	}

	public static byte[] getSHA256StrJava(String str) {
		MessageDigest messageDigest;
		try {
			messageDigest = MessageDigest.getInstance("SHA-256");
			messageDigest.update(str.getBytes("UTF-8"));
			return messageDigest.digest();
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * ��byteתΪ16����
	 * 
	 * @param bytes
	 * @return
	 */
	public static String byte2Hex(byte[] bytes) {
		StringBuffer stringBuffer = new StringBuffer();
		String temp = null;
		for (int i = 0; i < bytes.length; i++) {
			temp = Integer.toHexString(bytes[i] & 0xFF);
			if (temp.length() == 1) {
				// 1�õ�һλ�Ľ��в�0����
				stringBuffer.append("0");
			}
			stringBuffer.append(temp);
		}
		return stringBuffer.toString();
	}

	public static byte[] hex2Bytes(String hex) {
		if (hex == null || hex.length() == 0) {
			return null;
		}

		char[] hexChars = hex.toCharArray();
		// ��� hex �е��ַ�����ż����, ��������һ��
		byte[] bytes = new byte[hexChars.length / 2];

		for (int i = 0; i < bytes.length; i++) {
			bytes[i] = (byte) Integer.parseInt("" + hexChars[i * 2] + hexChars[i * 2 + 1], 16);
		}

		return bytes;
	}

	public static byte[] digest(String password, String nonce, String timestamp) {
		byte[] token = getSHA256StrJava(nonce + timestamp + password);
		return token;
	}

	public static boolean isNumber(String src) {
		boolean isNum = false;
		if (src == null || src.length() == 0) {
			return isNum;
		}
		Pattern pattern = Pattern.compile("\\d+");
		Matcher reg = pattern.matcher(src);
		isNum = reg.matches();
		return isNum;
	}

	public static String encrypt(String dataStr) {
		try {
			MessageDigest m = MessageDigest.getInstance("MD5");
			m.update(dataStr.getBytes(StandardCharsets.UTF_8));
			byte s[] = m.digest();
			return toString(s, 16);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return "";
	}

	public static String toString(byte[] bytes, int base) {
		StringBuilder buf = new StringBuilder();
		for (byte b : bytes) {
			int bi = 0xff & b;
			int c = '0' + (bi / base) % base;
			if (c > '9')
				c = 'a' + (c - '0' - 10);
			buf.append((char) c);
			c = '0' + bi % base;
			if (c > '9')
				c = 'a' + (c - '0' - 10);
			buf.append((char) c);
		}
		return buf.toString();
	}

	public static String getRandomString(int length) {
		// ����ַ���������ַ���
		String KeyString = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
		StringBuffer sb = new StringBuffer();
		int len = KeyString.length();
		for (int i = 0; i < length; i++) {
			sb.append(KeyString.charAt((int) Math.round(Math.random() * (len - 1))));
		}
		return sb.toString();
	}

	/**
	 * ���ַ���תΪ������
	 *
	 * @param src Դ�ַ���
	 * @param def ��ת��ʧ��ʱ���ص�Ĭ��ֵ
	 * @return ת����ĳ�����
	 */
	public static long toLong(String src, long def) {
		if (src == null || src.isEmpty()) {
			return def;
		}
		try {
			return Long.parseLong(src.trim());

		} catch (Exception e) {
			try {
				double test = Double.parseDouble(src);
				return (long) test;
			} catch (Exception ignored) {
			}
			return def;
		}
	}

	public static int toInt(String src, int def) {
		if (src == null || src.isEmpty()) {
			return def;
		}
		try {
			return Integer.parseInt(src.trim());
		} catch (Exception e) {
			return def;
		}
	}

	public static Map<String, String> buildQueryParams(HttpServletRequest req) {
		String queryParams = req.getHeader("query");
		Map<String, String> paramMap=buildQueryParams(queryParams);
		Map<String, String[]> reqMap = req.getParameterMap();
		if (reqMap.keySet().size() > 0) {
			reqMap.forEach((s, strings) -> {
				paramMap.put(s, strings[0]);
			});
		}
		return paramMap;
	}
	public static Map<String,String> buildQueryParams(String queryParams)
	{
		Map<String, String> paramMap = new HashMap<>();
		if(Util.isNull(queryParams))
			return paramMap;
		
		if (!Util.isNull(queryParams)) {
			String[] params = queryParams.split("&");
			for (String param : params) {
				String[] p = param.split("=");
				if (p.length == 2&& !Util.isNull(p[0]) ) {
					if(!Util.isNull(p[1]))
					paramMap.put(p[0], URLDecoder.decode(p[1].replaceAll("%20", "%2B"), StandardCharsets.UTF_8));
					else
						paramMap.put(p[0],"");	
				}
			}
		}
		
		return paramMap;
	}

	/**
	 * ����mapת��
	 * @param queryParams
	 * @return
	 */
	public static Map<String, String> convertMap(Map<String, String[]> queryParams) {
		Map<String, String> map = new HashMap<>();
		queryParams.forEach((key, valArray) -> {
			if (valArray != null && valArray.length > 0)
				map.put(key, valArray[0]);
		});
		return map;
	}
}
