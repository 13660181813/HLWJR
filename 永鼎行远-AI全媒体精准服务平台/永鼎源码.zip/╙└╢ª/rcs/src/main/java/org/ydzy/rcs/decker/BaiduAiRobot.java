package org.ydzy.rcs.decker;

import org.ydzy.rcs.BodyTransform;
import org.ydzy.rcs.annotation.Description;
import org.ydzy.util.Util;

import com.google.gson.JsonElement;
import com.google.inject.Singleton;

@Singleton
@Description(value = "baiduchatbot")
public class BaiduAiRobot implements DeckerRobot{

	@Override
	public JsonElement doTransform(BodyTransform transform, JsonElement efind) {
		
		//����ͷ�
		String uskf = Util.toString(transform.receiveEntity.getAnswersObject().get("callAi"));
		if(transform.session.get(transform.USER_STATE)==null&&!"1".equals(uskf)&&efind==null && transform.rcsConfig.getRobot()!=null && "1".equals(Util.getElementAsString(transform.rcsConfig.getChatbotInfo().get(transform.receiveEntity.getChatBotId()),"useAi"))){
			efind = transform.rcsConfig.getRobot().run(transform.receiveEntity);
		}
		if(efind!=null)
			transform.continued=false;
		return efind;
	}

}
