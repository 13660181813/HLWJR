package org.ydzy.rcs.template;

import org.ydzy.handler.BaseRcsContext;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

public abstract class MessageTemplate {
	public abstract JsonArray data2MsgCard(JsonObject paramTemplate,BaseRcsContext context); 
}
