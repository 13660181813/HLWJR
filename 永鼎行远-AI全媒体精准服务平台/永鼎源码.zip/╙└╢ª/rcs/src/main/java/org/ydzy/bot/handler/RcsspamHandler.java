package org.ydzy.bot.handler;
import java.io.IOException;
import java.nio.charset.Charset;

import org.eclipse.jetty.server.Request;
import org.ydzy.bot.BotInfo;
import org.ydzy.handler.BaseHandler;
import org.ydzy.util.StreamsUtil;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/*
 *  �ն˾ٱ�֪ͨ
 *  http://{notifyURL}/notifyInfoNotification/{chatbotId}/notice/rcsspam
 */
public  class RcsspamHandler extends BaseBotHandler {
	private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(RcsspamHandler.class);


	@Override
	public void handle(String target, Request baseRequest, HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException{
		baseRequest.setHandled(true);
		BotInfo bi = null;
		try {
			bi = verifyChatbot(request, response);
		}catch(VerifyError e) { 
			response.setStatus(HttpServletResponse.SC_FORBIDDEN);
			response.setContentType("application/json");
			JsonObject jo = new JsonObject();
			jo.addProperty("errorMsg", e.getMessage());
			// Write back response
			response.getWriter().println(jo.toString());
			log.debug("Sinagure error(" + e.getMessage() + "!");
			return;
		}
		String address=BaseHandler.getIpAddress(request);
		// Content-Type: text/xml; charset=utf-8
		String contentType = request.getContentType();
		if(contentType==null)contentType="application/json ";
		String body = StreamsUtil.copyToString(request.getInputStream(), Charset.forName("UTF-8"));
		if(log.isDebugEnabled())log.debug(",receive {} from remoteAddr {}  ", body, address);
		String code = null,msg = null;
		if(contentType.indexOf("json")>0) {
			JsonElement je = JsonParser.parseString(body);
			if(je!=null && je.isJsonObject()) {
				JsonObject jo = je.getAsJsonObject();
				log.info("Spam call botid=" + bi.getChatbotIdenty() + " info " + jo.toString());
			}else {
				code = "2001";
				msg = "No message found";
			}
		}else {
			code = "2002";
			msg = "Unknow contentType:" + contentType;
		}
		boolean succ = code==null;
		if(succ) {
			code = "0";
			msg = "success";
		}
		String resBody = resBodyJson(code, msg, null);
		sendResponse(address, resBody, HttpServletResponse.SC_OK, request, response);
	}

}