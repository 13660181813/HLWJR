package org.ydzy.util;

import java.io.File;
import java.io.FileFilter;
import java.io.IOException;
import java.lang.annotation.Annotation;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.JarURLConnection;
import java.net.URL;
import java.net.URLDecoder;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;

import org.ydzy.csp.service.BaseCspInter;
import org.ydzy.db.DbAccessor;
import org.ydzy.handler.AfterUpdate;
import org.ydzy.handler.dbHandler.IDbHandler;
import org.ydzy.isv.IsvBaseApi;
import org.ydzy.jdbc.control.result.datepattern.ITime;
import org.ydzy.publish.ISubscriber;
import org.ydzy.rcs.CardModel;
import org.ydzy.rcs.MessagesInter;
import org.ydzy.rcs.Provider;
import org.ydzy.rcs.RcsConfig;
import org.ydzy.rcs.SuggestionDisplay;
import org.ydzy.rcs.Upload;
import org.ydzy.rcs.annotation.Description;
import org.ydzy.rcs.decker.DeckerRobot;
import org.ydzy.rcs.decker.ReceiveHandle;
import org.ydzy.rcs.notify.NotifyThridParyBaseAbstract;
import org.ydzy.thirdparty.KFSkillGroupInter;
import org.ydzy.thirdparty.PostAction;
import org.ydzy.thirdparty.SkillGroupAssign;
import org.ydzy.thirdparty.gz110.IPushOnlineMsg;

import com.google.inject.Binder;
import com.google.inject.Guice;
import com.google.inject.Injector;
import com.google.inject.Module;
import com.google.inject.Singleton;
import com.google.inject.name.Names;
import org.ydzy.thirdparty.receivePush.ReceiveMessageAdapter;

public class ReflectionUtils {
	public static void main(String[] args) {

		// 包下面的类
		Set<Class<?>> classes = getClasses("org.ydzy");
		if (classes == null) {
			System.out.printf("null");
		} else {
			System.out.printf(classes.size() + "");
			// 某类或者接口的子类
			Set<Class<?>> inInterface = getByInterface(SuggestionDisplay.class, classes);
			System.out.printf(inInterface.size() + "");
			System.out.println(getByAnnotationMap(Description.class,classes));
			System.out.println(getByAnnotation(Description.class,classes));
			injectMoudles(Description.class, "org.ydzy");
		}

	}
	public static Injector injectMoudles(Class<? extends Annotation> clazz,String packageName)
	{
		Injector injector = Guice.createInjector();;
		// 包下面的类
				Set<Class<?>> classes = getClasses(packageName);
				if (classes == null) {
					System.out.printf("null");
				} else {
						Map<String,Class<?>>	classmap=getByAnnotationMap(clazz,classes);
					
						class BindModule implements Module {
							@Override
							public void configure(Binder binder) {
								if(classmap!=null)
								{
									classmap.forEach((k,v)->{
										if(v!=null)
										{ 
											if(SuggestionDisplay.class.isAssignableFrom(v))
											binder.bind(SuggestionDisplay.class).annotatedWith(Names.named(k)).to(v.asSubclass(SuggestionDisplay.class));
											else if(CardModel.class.isAssignableFrom(v))
											{
												binder.bind(CardModel.class).annotatedWith(Names.named(k)).to(v.asSubclass(CardModel.class));
											}else if (RcsConfig.class.isAssignableFrom(v))
											{
												binder.bind(RcsConfig.class).annotatedWith(Names.named(k)).to(v.asSubclass(RcsConfig.class));
											}else if (Module.class.isAssignableFrom(v)) {
												try {
													binder.install(v.asSubclass(Module.class).getDeclaredConstructor().newInstance());
												}catch(Throwable ignore) {}
											}else if (Upload.class.isAssignableFrom(v))
											{
												binder.bind(Upload.class).annotatedWith(Names.named(k)).to(v.asSubclass(Upload.class));
											}else if(IDbHandler.class.isAssignableFrom(v))
											{
												binder.bind(IDbHandler.class).annotatedWith(Names.named(k)).to(v.asSubclass(IDbHandler.class));
											}else if(BaseCspInter.class.isAssignableFrom(v))
											{
												binder.bind(BaseCspInter.class).annotatedWith(Names.named(k)).to(v.asSubclass(BaseCspInter.class));
											}else if(DbAccessor.class.isAssignableFrom(v))
											{
												binder.bind(DbAccessor.class).annotatedWith(Names.named(k)).to(v.asSubclass(DbAccessor.class));
											}else if(MessagesInter.class.isAssignableFrom(v))
											{
												binder.bind(MessagesInter.class).annotatedWith(Names.named(k)).to(v.asSubclass(MessagesInter.class));
											}else if(ISubscriber.class.isAssignableFrom(v))
											{
												binder.bind(ISubscriber.class).annotatedWith(Names.named(k)).to(v.asSubclass(ISubscriber.class));
											}
											else if(IPushOnlineMsg.class.isAssignableFrom(v))
											{
												binder.bind(IPushOnlineMsg.class).annotatedWith(Names.named(k)).to(v.asSubclass(IPushOnlineMsg.class));
											}
											else if(DeckerRobot.class.isAssignableFrom(v))
											{
												binder.bind(DeckerRobot.class).annotatedWith(Names.named(k)).to(v.asSubclass(DeckerRobot.class));
											}else if(ReceiveHandle.class.isAssignableFrom(v))
											{
												binder.bind(ReceiveHandle.class).annotatedWith(Names.named(k)).to(v.asSubclass(ReceiveHandle.class));
											}else if(AfterUpdate.class.isAssignableFrom(v))
											{
												binder.bind(AfterUpdate.class).annotatedWith(Names.named(k)).to(v.asSubclass(AfterUpdate.class));
											}else if (KFSkillGroupInter.class.isAssignableFrom(v))
											{
												binder.bind(KFSkillGroupInter.class).annotatedWith(Names.named(k)).to(v.asSubclass(KFSkillGroupInter.class));	
											}else if(SkillGroupAssign.class.isAssignableFrom(v))
											{
												binder.bind(SkillGroupAssign.class).annotatedWith(Names.named(k)).to(v.asSubclass(SkillGroupAssign.class));
											}
											else if(PostAction.class.isAssignableFrom(v))
											{
												binder.bind(PostAction.class).annotatedWith(Names.named(k)).to(v.asSubclass(PostAction.class));
											}
											else if(IsvBaseApi.class.isAssignableFrom(v))
											{
												binder.bind(IsvBaseApi.class).annotatedWith(Names.named(k)).to(v.asSubclass(IsvBaseApi.class));
											}else if(ITime.class.isAssignableFrom(v))
											{
												binder.bind(ITime.class).annotatedWith(Names.named(k)).to(v.asSubclass(ITime.class));
											}
											else if (NotifyThridParyBaseAbstract.class.isAssignableFrom(v)) {
												binder.bind(NotifyThridParyBaseAbstract.class).annotatedWith(Names.named(k)).to(v.asSubclass(NotifyThridParyBaseAbstract.class));
											} else if (ReceiveMessageAdapter.class.isAssignableFrom(v)) {
												binder.bind(ReceiveMessageAdapter.class).annotatedWith(Names.named(k)).to(v.asSubclass(ReceiveMessageAdapter.class));
											} else {
												binder.bind(v);
											}
											
										}
									});
								}
							}
						}
						injector = Guice.createInjector(new BindModule());
						
						Provider.injector=injector;
						if(classmap!=null)
						{
							classmap.forEach((k,v)->{
								if(v!=null)
								{
									
									Annotation findc = v.getAnnotation(Description.class);
									if(findc!=null) {
										if(((Description)findc).autoInstance()){
											Annotation single=v.getAnnotation(Singleton.class);

											if(single!=null)
											{
												Object o = Provider.injector.getInstance(v);
												try {
													Method m=v.getMethod("init");
													if( m!=null) {
														m.setAccessible(true);
														m.invoke(o);
													}
												} catch (NoSuchMethodException e) {
												} catch (SecurityException e) {
												} catch (IllegalAccessException e) {
												} catch (IllegalArgumentException e) {
													e.printStackTrace();
												} catch (InvocationTargetException e) {
													e.printStackTrace();
												}
												
//												System.out.println(o.hashCode());
//												Class<?> interfaces[] = v.getInterfaces();//获得所实现的所有接口
//												if(interfaces!=null)
//												{
//													for (Class<?> inte : interfaces) {//打印
//														try {
//															Provider.getInstance(inte, ((Description)findc).value());
//														} catch (Exception e) {
//															e.printStackTrace();
//														}
//													}
//													
//												}else if(!(v.getSuperclass() instanceof Object))
//													Provider.getInstance(v.getSuperclass(), ((Description)findc).value());
											}
										}
									}
								}
							});
					
						}
				}
				return injector;
	}

	/**
	 * 从包package中获取所有的Class
	 *
	 * @param pack
	 * @return
	 */
	public static Set<Class<?>> getClasses(String pack) {

		// 第一个class类的集合
		Set<Class<?>> classes = new LinkedHashSet<Class<?>>();
		// 是否循环迭代
		boolean recursive = true;
		// 获取包的名字 并进行替换
		String packageName = pack;
		String packageDirName = packageName.replace('.', '/');
		// 定义一个枚举的集合 并进行循环来处理这个目录下的things
		Enumeration<URL> dirs;
		try {
			dirs = Thread.currentThread().getContextClassLoader().getResources(packageDirName);
			// 循环迭代下去
			while (dirs.hasMoreElements()) {
				// 获取下一个元素
				URL url = dirs.nextElement();
				// 得到协议的名称
				String protocol = url.getProtocol();
				// 如果是以文件的形式保存在服务器上
				if ("file".equals(protocol)) {
					System.err.println("file类型的扫描");
					// 获取包的物理路径
					String filePath = URLDecoder.decode(url.getFile(), "UTF-8");
					// 以文件的方式扫描整个包下的文件 并添加到集合中
					findAndAddClassesInPackageByFile(packageName, filePath, recursive, classes);
				} else if ("jar".equals(protocol)) {
					// 如果是jar包文件
					// 定义一个JarFile
//                System.err.println("jar类型的扫描");
					JarFile jar;
					try {
						// 获取jar
						jar = ((JarURLConnection) url.openConnection()).getJarFile();
						// 从此jar包 得到一个枚举类
						Enumeration<JarEntry> entries = jar.entries();
						// 同样的进行循环迭代
						while (entries.hasMoreElements()) {
							// 获取jar里的一个实体 可以是目录 和一些jar包里的其他文件 如META-INF等文件
							JarEntry entry = entries.nextElement();
							String name = entry.getName();
							// 如果是以/开头的
							if (name.charAt(0) == '/') {
								// 获取后面的字符串
								name = name.substring(1);
							}
							// 如果前半部分和定义的包名相同
							if (name.startsWith(packageDirName)) {
								int idx = name.lastIndexOf('/');
								// 如果以"/"结尾 是一个包
								if (idx != -1) {
									// 获取包名 把"/"替换成"."
									packageName = name.substring(0, idx).replace('/', '.');
								}
								// 如果可以迭代下去 并且是一个包
								if ((idx != -1) || recursive) {
									// 如果是一个.class文件 而且不是目录
									if (name.endsWith(".class") && !entry.isDirectory()) {
										// 去掉后面的".class" 获取真正的类名
										String className = name.substring(packageName.length() + 1, name.length() - 6);
										try {
											// 添加到classes
											classes.add(Class.forName(packageName + '.' + className));
										} catch (ClassNotFoundException e) {
											e.printStackTrace();
										}
									}
								}
							}
						}
					} catch (IOException e) {
						// log.error("在扫描用户定义视图时从jar包获取文件出错");
						e.printStackTrace();
					}
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}

		return classes;
	}

	/**
	 * 以文件的形式来获取包下的所有Class
	 *
	 * @param packageName
	 * @param packagePath
	 * @param recursive
	 * @param classes
	 */
	public static void findAndAddClassesInPackageByFile(String packageName, String packagePath, final boolean recursive,
			Set<Class<?>> classes) {
		// 获取此包的目录 建立一个File
		File dir = new File(packagePath);
		// 如果不存在或者 也不是目录就直接返回
		if (!dir.exists() || !dir.isDirectory()) {
			// log.warn("用户定义包名 " + packageName + " 下没有任何文件");
			return;
		}
		// 如果存在 就获取包下的所有文件 包括目录
		File[] dirfiles = dir.listFiles(new FileFilter() {
			// 自定义过滤规则 如果可以循环(包含子目录) 或则是以.class结尾的文件(编译好的java类文件)
			public boolean accept(File file) {
				return (recursive && file.isDirectory()) || (file.getName().endsWith(".class"));
			}
		});
		// 循环所有文件
		for (File file : dirfiles) {
			// 如果是目录 则继续扫描
			if (file.isDirectory()) {
				findAndAddClassesInPackageByFile(packageName + "." + file.getName(), file.getAbsolutePath(), recursive,
						classes);
			} else {
				// 如果是java类文件 去掉后面的.class 只留下类名
				String className = file.getName().substring(0, file.getName().length() - 6);
				try {
					// 添加到集合中去
					// classes.add(Class.forName(packageName + '.' + className));
					// 经过回复同学的提醒，这里用forName有一些不好，会触发static方法，没有使用classLoader的load干净
					classes.add(
							Thread.currentThread().getContextClassLoader().loadClass(packageName + '.' + className));
				} catch (ClassNotFoundException e) {
					// log.error("添加用户自定义视图类错误 找不到此类的.class文件");
					e.printStackTrace();
				}
			}
		}
	}

// --------------------------------------------------------------------------------------------------------

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static Set<Class<?>> getByInterface(Class clazz, Set<Class<?>> classesAll) {
		Set<Class<?>> classes = new LinkedHashSet<Class<?>>();
		// 获取指定接口的实现类
		if (!clazz.isInterface()) {
			try {
				/**
				 * 循环判断路径下的所有类是否继承了指定类 并且排除父类自己
				 */
				Iterator<Class<?>> iterator = classesAll.iterator();
				while (iterator.hasNext()) {
					Class<?> cls = iterator.next();
					/**
					 */
					if (clazz.isAssignableFrom(cls)) {
						if (!clazz.equals(cls)) {// 自身并不加进去
							classes.add(cls);
						} else {

						}
					}
				}
			} catch (Exception e) {
				System.out.println("出现异常");
			}
		}
		return classes;
	}

	public static Set<Class<?>> getByAnnotation(Class<? extends Annotation> clazz, Set<Class<?>> classesAll) {
		Set<Class<?>> classes = new LinkedHashSet<Class<?>>();
		try {
			/**
			 * 循环判断路径下的所有类是否继承了指定类 并且排除父类自己
			 */
			Iterator<Class<?>> iterator = classesAll.iterator();
			while (iterator.hasNext()) {
				Class<?> cls = iterator.next();
				if (!cls.isAnnotation()) {
					Annotation findc = cls.getAnnotation(clazz);
					classes.add(cls);
				}
			}
		} catch (Exception e) {
			System.out.println("出现异常");
		}
		return classes;
	}
	
	public static Map<String,Class<?>> getByAnnotationMap(Class<? extends Annotation> clazz, Set<Class<?>> classesAll) {
		Map<String,Class<?>> classes = new HashMap<String,Class<?>>();
		try {
			/**
			 * 循环判断路径下的所有类是否继承了指定类 并且排除父类自己
			 */
			Iterator<Class<?>> iterator = classesAll.iterator();
			while (iterator.hasNext()) {
				Class<?> cls = iterator.next();
				if (!cls.isAnnotation()) {
					Annotation findc = cls.getAnnotation(clazz);
					if(findc!=null&&findc instanceof Description) {
//						if(!((Description)findc).autoInstance())
						classes.put(((Description)findc).value(), cls);
					}
				}
			}
		} catch (Exception e) {
			System.out.println("出现异常");
		}
		return classes;
	}
	
	
}
