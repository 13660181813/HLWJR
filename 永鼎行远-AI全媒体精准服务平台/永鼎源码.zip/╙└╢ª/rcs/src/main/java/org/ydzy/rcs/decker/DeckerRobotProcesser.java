package org.ydzy.rcs.decker;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.ydzy.config.ApplicationConfig;
import org.ydzy.rcs.BodyTransform;
import org.ydzy.rcs.Provider;
import org.ydzy.rcs.entity.ReceiveEntity;
import org.ydzy.util.Util;

import com.google.gson.JsonElement;
import com.google.inject.Inject;
import com.google.inject.Singleton;


@Singleton
public class DeckerRobotProcesser  {
	private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(DeckerRobotProcesser.class);
	@Inject
	ApplicationConfig applicationConfig;

	public void doTransform(BodyTransform transform, boolean send25gmsg) {
		JsonElement find = null;
		//TODO ADD SYSTEMCONFIG
		String chatbotId=transform.receiveEntity.getChatBotId();
		
		List<DeckerRobot> DeckerRobots = loadOrders(transform,chatbotId);
		for (DeckerRobot robots : DeckerRobots) {
			find = robots.doTransform(transform, find);
			if (!transform.continued||find!=null)
				break;
		}
		if(find!=null) {
			transform.receiveEntity.getAnswersObject().put("configid", Util.getElementAsString(find.getAsJsonObject(), "configid"));
			transform.responseBody=Provider.parseContent(transform.receiveEntity, find,transform.context, send25gmsg);
//			if("v2".equals(v))
//				transform.responseBody=new Gson().toJson(XML.toJSONObject(transform.responseBody));
		    transform.receiveEntity.getAnswersObject().put("responseBody", 1);
			transform.receiveEntity.getAnswersObject().put("responseBodyContent", transform.responseBody);
		}   
		transform.receiveEntity.getAnswersObject().put("compute", 1);
		//TODO  V2 
//		if( "v2".equals(v))
//		responseBody=new Gson().toJson(XML.toJSONObject(responseBody));
		
		addHeaders(transform);
	}
	private void addHeaders(BodyTransform transform)
	{
		String v=Util.toString(transform.receiveEntity.getAnswersObject().get("chatbotVersion"));
		
		
		String password = transform.rcsConfig.enterpriseProperty(transform.receiveEntity.getChatBotId(), "key");
		Map<String, Object> header =null;
		
		if(v.equals("v2"))
		{
			header=transform.headersV2(transform.rcsConfig,password,transform.receiveEntity.getChatBotId(),transform.receiveEntity.getMdn(),"application/json");
		}else
		{
			header=transform.headers(transform.rcsConfig,password,transform.receiveEntity.getChatBotId(),transform.receiveEntity.getMdn(),"application/xml");
		}
		
		transform.ResponseHeader=header;
	}
	private List<DeckerRobot> loadOrders(BodyTransform transform,String chatbotId)
	{
		String chatbotorder=transform.rcsConfig.enterpriseProperty(chatbotId, "loadOrder");
		String loadOrders=Util.toString(applicationConfig.applicationProp.get(chatbotorder));
		if(Util.isNull(loadOrders))
			loadOrders=Util.toString(applicationConfig.applicationProp.get("defaultChatBotorder"));
		if(Util.isNull(loadOrders))
		{
			log.error("chatbot {} loadOrder {}  or defaultChatbotOrder {} cannot be null ",chatbotId,chatbotorder,loadOrders);
			return null;
		}
		List<String> DeckerRobotsBeanName=java.util.Arrays.asList(loadOrders.split(","));
		if(DeckerRobotsBeanName==null||DeckerRobotsBeanName.size()==0)
		{
			log.error(" chatbot {} loadOrder {}  not defined in system  ",chatbotId,loadOrders);
			return null;
		}
		
		List<DeckerRobot> DeckerRobots =new ArrayList<DeckerRobot>();
		for(String chatbotOrder:DeckerRobotsBeanName)
		{
			DeckerRobot dr=Provider.getInstance(DeckerRobot.class, chatbotOrder);
			if(dr!=null)
			DeckerRobots.add(dr);
		}
		return DeckerRobots;
	}
	
	

	public ReceiveEntity requestHandler(BodyTransform transform,ReceiveEntity receiveEntity) {
		List<ReceiveHandle> ReceiveHandlers=loadReceiveHandlers(transform);
		for (ReceiveHandle hand : ReceiveHandlers) {
			receiveEntity = hand.requestHandler(transform,receiveEntity);
		}
		return receiveEntity;
	}
	
	private List<ReceiveHandle> loadReceiveHandlers(BodyTransform transform)
	{
		String chatbotId=transform.receiveEntity.getChatBotId();
		String chatbotorder=transform.rcsConfig.enterpriseProperty(chatbotId, "receiveLoadOrder");
		String receiveOrders=Util.toString(applicationConfig.applicationProp.get(chatbotorder));
		if(Util.isNull(receiveOrders))
			receiveOrders=Util.toString(applicationConfig.applicationProp.get("defaultReceiveOders"));
		if(Util.isNull(receiveOrders))
		{
			log.error("chatbot {}  ReceiveOders {}  or defaultReceiveOders {} cannot be null ",chatbotId,chatbotorder,receiveOrders);
			return null;
		}
		List<String> DeckerRobotsBeanName=java.util.Arrays.asList(receiveOrders.split(","));
		if(DeckerRobotsBeanName==null||DeckerRobotsBeanName.size()==0)
		{
			log.error(" chatbot {} loadOrder {}  not defined in system  ",chatbotId,receiveOrders);
			return null;
		}
		
		List<ReceiveHandle> rorders =new ArrayList<ReceiveHandle>();
		for(String chatbotOrder:DeckerRobotsBeanName)
		{
			ReceiveHandle dr=Provider.getInstance(ReceiveHandle.class, chatbotOrder);
			if(dr!=null)
				rorders.add(dr);
		}
		return rorders;
	}

}
