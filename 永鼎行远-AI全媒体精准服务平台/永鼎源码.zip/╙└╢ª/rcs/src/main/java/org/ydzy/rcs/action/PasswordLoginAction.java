package org.ydzy.rcs.action;

import com.google.common.collect.Maps;
import com.google.gson.JsonObject;
import com.google.inject.Singleton;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.ydzy.handler.BaseHandler;
import org.ydzy.handler.BaseRcsContext;
import org.ydzy.rcs.entity.LoginInfo;
import org.ydzy.util.Util;
import org.ydzy.util.crypto.CryptoAES;

import java.io.IOException;
import java.util.HashMap;

@Singleton
public class PasswordLoginAction extends LoginAction {
    public static final String LOGIN_PREFIX = "LOGIN:";

    @Override
    public void login(HttpServletRequest request, HttpServletResponse response, String remoteAddr, LoginInfo loginInfo, BaseRcsContext context) throws IOException {
        if (!super.checkLogin(request, response, remoteAddr, loginInfo)) {
            return;
        }
        // ��֤ͼ����֤��
        if (!isValidCaptcha(request, response, remoteAddr, loginInfo)) return;
        // ���ͼ����֤�뻺��
        cacheProvider.deleteCache(loginInfo.getUuid());
        // login
        String username = loginInfo.getPhoneNo();
        String password = CryptoAES.desEncrypt(loginInfo.getPassword(), applicationConfig.AES_KEY, applicationConfig.AES_KEY);
        if (Util.isNull(username) || Util.isNull(password)) {
            BaseHandler.sendResponse(remoteAddr, BaseHandler.resBodyJson(AuthAction.AUTH_CODE_INVALID_REQ_USERNP, "The required parameters are missing. username or password cannot be empty.", new JsonObject()),
                    HttpServletResponse.SC_OK, request, response);
            return;
        }
        HashMap<String, Object> payload = Maps.newHashMap();
        payload.put("type", "password");
        String accessToken = authAction.getAccessToekn(username, password, applicationConfig.LOGIN_LOGINMODE, applicationConfig.LOGIN_ACCESSTOKEN_URL, payload);

        super.afterLogin(request, response, remoteAddr, accessToken, username, payload, context);
    }

    @Override
    public boolean checkParams(LoginInfo loginInfo) {
        return !Util.isNull(loginInfo.getPhoneNo()) && !Util.isNull(loginInfo.getPassword()) && !Util.isNull(loginInfo.getCaptcha()) && !Util.isNull(loginInfo.getUuid());
    }

    private boolean isValidCaptcha(HttpServletRequest request, HttpServletResponse response, String remoteAddr, LoginInfo loginInfo) throws IOException {
        String uuid = loginInfo.getUuid();
        String capture = loginInfo.getCaptcha();
        if (!cacheProvider.isEqualsIgnoreCase(uuid, capture)) {
            BaseHandler.sendResponse(remoteAddr, BaseHandler.resBodyJson(AuthAction.AUTH_CODE_ERROR, "ͼ����֤�������ѹ���", null), HttpServletResponse.SC_OK, request, response);
            return false;
        }
        cacheProvider.deleteCache(uuid);
        return true;
    }
}
