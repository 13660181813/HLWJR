package org.ydzy.rcs.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.ydzy.handler.BaseRcsContext;
import org.ydzy.rcs.CardModel;
import org.ydzy.rcs.MessagesInter;
import org.ydzy.rcs.Provider;
import org.ydzy.rcs.annotation.Description;
import org.ydzy.rcs.entity.ReceiveEntity;
import org.ydzy.util.StringUtils;
import org.ydzy.util.Util;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonSyntaxException;
import com.google.inject.Singleton;

@Singleton
@Description("singlecard")
public class SingleCardContent implements CardModel {
	public static org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(SingleCardContent.class);
	public JsonObject constructMsgStructure(ReceiveEntity requestObject,JsonObject eobject,BaseRcsContext context,boolean send25gMsg)
	{
		if (!eobject.has("content") || eobject.get("content") == null || eobject.get("content").isJsonNull()) {
			return eobject;
		}
		Gson gson = new Gson();
		JsonArray content = eobject.get("content").getAsJsonArray();
		JsonObject myobject = content.get(0).getAsJsonObject();
		String msg = Util.getElementAsString(myobject, "msg");
		String params = Util.getElementAsString(myobject, "params");
		String msgid = Util.getElementAsString(myobject, "msgid");
		String paramtmp = Util.getElementAsString(myobject, "params");
		String suggestionid = Util.getElementAsString(myobject, "suggestionid");
		suggestionid = Util.isNull(suggestionid) ? Util.getElementAsString(myobject, "allsuggestionid") : suggestionid;

		String gloabl = replaceParam(MulitiCardContent.systemContextparams, requestObject, context);
		context.getAttributes().put("globalParam", gloabl);

		String isTemplate = Util.getElementAsString(myobject, "isTemplate");
		String suggestionInner = Util.getElementAsString(myobject, "suggestions");
		JsonElement ele = eobject.get("allsuggestions");
		if (ele != null && !ele.isJsonNull() && ele.isJsonArray()) {
			JsonArray array = ele.getAsJsonArray();
			for (JsonElement e1 : array) {
				if (suggestionInner.indexOf(e1.getAsString()) == -1)
					suggestionInner += " , " + e1.getAsString();
			}
		}
		JsonObject allModels=new JsonObject();
		String manager=Util.toString(requestObject.getAnswersObject().get("manager"));
		List<Map<String, Object>> models =null;
		if ("1".equals(isTemplate)) {
			JsonArray modelParam=new JsonArray();
			models= modelParams(msgid, context);
			if (models != null) {
				for (int i = 0; i < models.size(); i++) {
					Map<String, Object> e = models.get(i);
					Map<String, String> pav = e.get("params") == null ? null : (Map<String, String>) e.get("params");
					String msg1 = formatVues(msg, pav);
					suggestionInner = formatVues(suggestionInner, pav);
					params = replaceParam(params, requestObject, context);
					Object[] newObject = initParams(params, requestObject, context);

					JsonObject jobj = new JsonObject();
					jobj.addProperty("msgId", Util.toString(e.get("msgId")));
					jobj.addProperty("tempId", Util.toString(e.get("tempId")));
					jobj.add("param", JsonParser.parseString(gson.toJson(pav)));
					jobj.addProperty("defined", paramtmp);
					jobj.addProperty("msg", msg);
					modelParam.add(jobj);


					msg = StringUtils.format(msg1, newObject);
					break;
				}
			}
			allModels.add(msgid, modelParam);
			String tmp = Provider.sugestion(suggestionid + "|" + suggestionInner, context);
			if (Util.isNull(suggestionInner))
				tmp = Provider.sugestion(suggestionInner, context);

			suggestionInner = tmp;
		} else {
			msg = replaceParam(msg, requestObject, context);
			String tmp = Provider.sugestion(suggestionid + "|" + suggestionInner, context);
			if (Util.isNull(suggestionInner))
				tmp = Provider.sugestion(suggestionInner, context);
			suggestionInner = tmp;
			Object[] newObject = initParams(params, requestObject, context);
			msg = StringUtils.format(msg, newObject);
		}
		
		eobject.addProperty("msg", msg);
		eobject.addProperty("suggestions", suggestionInner);
		String[] tc2 = msg.split("\\Q|", -1);
		JsonObject contentObject2H5 = new JsonObject();

		contentObject2H5.addProperty("body",  (tc2 != null && tc2.length > 2 ? tc2[1] : msg));
		try {
			JsonElement tmp = JsonParser.parseString("["+suggestionInner+"]");
			contentObject2H5.add("globalSuggestion",tmp );
		} catch (JsonSyntaxException e1) {
			log.error("json format error {} ","["+suggestionInner+"]");
		}
//		if("true".equals(manager))
		{
			contentObject2H5.add("modelParam",allModels);
			requestObject.getAnswersObject().put("resObject", contentObject2H5);
		}
		return eobject;

	}
	/**
	 * contentType
	 * 
	 * Emun
	 * 
	 * O
	 * 
	 * text/plain ��ͨ�ı�(��������λ�����ͻ�����Ϣ)��
	 * application/vnd.gsma.rcs-ft-http+xml����ͨ�ļ���Ϣ��������ͼƬ����Ƶ����Ƶ��Ϣ��
	 * application/vnd.gsma.botsuggestion.response.v1.0+json ���ڽ���ظ���Ϣ�Ļظ���
	 * application/vnd.gsma.botsharedclientdata.v1.0+json �ն˹����������ݡ�
	 * application/vnd.gsma.rcsspam-report+xml Ͷ����Ϣ��
	 * 

	 * @return
	 */
	public String cardHtml(ReceiveEntity requestObject, JsonObject eobject, BaseRcsContext context,boolean send25gMsg) {
		constructMsgStructure(requestObject,eobject,context,send25gMsg);
//		JsonObject eobject = e.getAsJsonObject();
//		String keywords = eobject.get("keywords").getAsString();
		JsonObject contentObject2H5 = (JsonObject)requestObject.getAnswersObject().get("resObject");
		if(contentObject2H5==null||contentObject2H5.isJsonNull())
			return "";
		String suggestionInner=Util.getElementAsString(eobject, "suggestions");
		
		String msg =Util.getElementAsString(eobject,"msg");
		String[] tc2 = msg.split("\\Q|", -1);	
		try {
			String config = Util.toString(requestObject.getAnswersObject().get("configid"));
			context.getSession().put(config, contentObject2H5);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		String isp=context.getConfig().enterpriseProperty(requestObject.getChatBotId(), "isp");;
		
//		StringBuilder body = new StringBuilder();
//		body.append(String.format(bodyformat, tc2 != null && tc2.length > 2 ? tc2[1] : msg));
//		if(suggestionInner!=null&&!suggestionInner.isEmpty())
//			body.append(String.format(suggestionformat, suggestionInner));
//		body.append("--next--");
		List<MessagesInter.MessageBody> body1 = new ArrayList<>();
		MessagesInter.MessageBody m1 = new MessagesInter.MessageBody();
		m1.contentText = tc2 != null && tc2.length > 2 ? tc2[1] : msg;
		m1.contentType = "text/plain";
		body1.add(m1);
		
		//���ɶ������� ����Ĵ��ı�����
		requestObject.getAnswersObject().put("msg", m1.contentText);
		if(!Util.isNull(suggestionInner)) {
			MessagesInter.MessageBody m2 = new MessagesInter.MessageBody();
			m2.contentText = "{\"suggestions\":[" + suggestionInner + "]}";
			m2.contentType = "application/vnd.gsma.botsuggestion.v1.0+json";
			body1.add(m2);
		}
		MessagesInter msgimp=	null;
		try {
			msgimp=Provider.getInstance(MessagesInter.class, isp+"MessageImp");
		} catch (Exception e) {
			msgimp=Provider.getInstance(MessagesInter.class, "cmccMessageImp");
		}
		return msgimp.body(requestObject, eobject, context, body1);
//		
////		String suggesitions = Provider.sugestion(suggestionInner,context);
//		String[] args = { requestObject.getSenderAddress(), requestObject.getSenderAddress(),
//				tc2 != null && tc2.length > 2 ? tc2[1] : msg, suggestionInner,
//				UUID.randomUUID().toString().replace("-", "").toLowerCase(),
//				UUID.randomUUID().toString().replace("-", "").toLowerCase(),
//				context.getConfig().enterpriseProperty(requestObject.getChatBotId(), "capabilityId"),
//				context.getConfig().enterpriseProperty(requestObject.getChatBotId(), "version"),
//				// UUID.randomUUID().toString().replace("-", "").toLowerCase(),
//				requestObject.getSubject(), context.getConfig().enterpriseProperty(requestObject.getChatBotId(), "sp"),
//
//				context.getConfig().enterpriseProperty(requestObject.getChatBotId(), "defaultName") };
////			{
////				requestObject.getSenderAddress(), 
////				c2,
////				rcsConfig.enterpriseProperty(requestObject.getSpName(), "sp"),
////				requestObject.getSubject(),
////				rcsConfig.enterpriseProperty(requestObject.getSpName(), "version"),
////				rcsConfig.enterpriseProperty(requestObject.getSpName(), "defaultName"),
////				rcsConfig.enterpriseProperty(requestObject.getSpName(), "capabilityId"),
////				suggesitions
////				};
//		String responseBody = StringUtils.format(contentcard, args);
////		responseBody=replaceParam(responseBody,requestObject,context);
//		return responseBody;

	}

	private List<Map<String, Object>> modelParams(String msgid, BaseRcsContext context) {
		if (!Util.isNull(msgid)) {
			try {
				Map<String, List<Map<String, Object>>> modelParams = context.getConfig().modelParams;
//				 String configid=Util.toString(requestObject.getAnswersObject().get("configid"));
//				 JsonObject o =context.getConfig().getKeyWordsBysp(requestObject.getSpName(), configid);
//				v = BeanUtils.getNestedProperty(modelParams, msgid);
				List<Map<String, Object>> maps = modelParams.get(msgid);
				return maps;
			} catch (Exception e) {
			}
		}
		return null;
	}

}
