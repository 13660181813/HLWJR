//
// ========================================================================
// Copyright (c) 1995-2020 Mort Bay Consulting Pty Ltd and others.
//
// This program and the accompanying materials are made available under
// the terms of the Eclipse Public License 2.0 which is available at
// https://www.eclipse.org/legal/epl-2.0
//
// This Source Code may also be made available under the following
// Secondary Licenses when the conditions for such availability set
// forth in the Eclipse Public License, v. 2.0 are satisfied:
// the Apache License v2.0 which is available at
// https://www.apache.org/licenses/LICENSE-2.0
//
// SPDX-License-Identifier: EPL-2.0 OR Apache-2.0
// ========================================================================
//

package org.ydzy;

import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.server.ServerConnector;
import org.eclipse.jetty.servlet.ServletContextHandler;
import org.eclipse.jetty.util.resource.Resource;
import org.eclipse.jetty.websocket.server.config.JettyWebSocketServletContainerInitializer;
import org.eclipse.jetty.xml.XmlConfiguration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.ydzy.rcs.Provider;
import org.ydzy.rcs.RcsContainer;
import org.ydzy.thirdparty.policeStudy.PoliceStudyAction;
import org.ydzy.util.PdfConvertUtil;
import org.ydzy.util.Util;
import org.ydzy.wechat.miniProgram.gz110.WmpCommentAction;
import org.ydzy.ws.EventSocket;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Duration;

/**
 * A Jetty FileServer.
 * <p>
 * via an {@link XmlConfiguration} config file that does the identical work.
 * </p>
 */
public class FileServerXml{
    private static String TAG= "FileServerXml.main";
    private static final Logger log = LoggerFactory.getLogger(FileServerXml.class);
    public static Server createServer(int port, Path baseResource) throws Exception
    {
    	
//    	AddressResolutionUtil.init();
        // See src/main/resources/fileserver.xml
        Resource fileServerXml = Resource.newSystemResource("fileserver.xml");
        XmlConfiguration configuration = new XmlConfiguration(fileServerXml);
        configuration.getProperties().put("http.port", Integer.toString(port));
        configuration.getProperties().put("fileserver.baseresource", baseResource.toAbsolutePath().toString());
        return (Server)configuration.configure();
    }

    public static void main(String[] args) throws Exception {
        // ע��
    	Provider.load();
        int port = Util.getPort(args, "jetty.http.port", 8080);
        Path userDir = Paths.get(System.getProperty("user.dir"));
        Server server = null;
        try {
            server = createServer(port, userDir);
        }catch (Exception e){
            log.error("create Jetty Server error......, {}", e);
            System.exit(0);
        }
        //�� jetty �����е� Handler ʵ��ע��������Bean
        Provider.injector.getInstance(RcsContainer.class).setServer(server);
        try {
            server.start();
        } catch (Exception e) {
            log.error("Jetty Server start() error......, {}", e);
            System.exit(0);
        }

        log.info(TAG+ "WmpCommentAction init......start");
        WmpCommentAction.init();
        log.info(TAG+ "WmpCommentAction init......end");
        log.info(TAG+ "PdfConvertUtil createOfficeManagerServer ......start");
        PdfConvertUtil.createOfficeManagerServer(); // ����officeManager����  ��תpdf���ߣ�
        log.info(TAG+ "PdfConvertUtil createOfficeManagerServer ......end");
        log.info(TAG+ "PoliceStudyAction init......start");
        PoliceStudyAction.init(); // �زĸ�ʽת���첽�����߼�
        log.info(TAG+ "PoliceStudyAction init......end");
        log.info(TAG+ "start web socket......start");
        startWebSocket(args);
        log.info(TAG+ "start web socket......end");
    }
    
    public static void startWebSocket(String[] args) {
        int port = -1;
        try {
            port = Integer.parseInt(System.getProperty("jetty.websocket.port", "58080"));
            log.info("jetty.websocket.port:{}", port);
        } catch (Exception ignore) {
            log.error("set jetty.websocket.port ERROR��{}", ignore);
        }
        if (port <= 0 || port > 65535) return;
        String wssPath = System.getProperty("jetty.websocket.path");
        if (wssPath == null || wssPath.isEmpty()) wssPath = "/events";
        final String eventPath = wssPath;
        org.eclipse.jetty.util.thread.QueuedThreadPool pool = new org.eclipse.jetty.util.thread.QueuedThreadPool();
        int minThreads = Util.toInt(System.getProperty("jetty.websocket.minThreads"), 500);
        int maxThreads = Util.toInt(System.getProperty("jetty.websocket.maxThreads"), 20000);
        pool.setMinThreads(minThreads);
        pool.setMaxThreads(maxThreads);
        Server server = new Server(pool);
        ServerConnector connector = new ServerConnector(server);
        connector.setPort(port);
        server.addConnector(connector);

        // Setup the basic application "context" for this application at "/"
        // This is also known as the handler tree (in jetty speak)
        ServletContextHandler context = new ServletContextHandler(ServletContextHandler.SESSIONS);
        context.setContextPath("/");
        server.setHandler(context);

        // Configure specific websocket behavior
        JettyWebSocketServletContainerInitializer.configure(context, (servletContext, wsContainer) ->
        {
            // Configure default max size
            wsContainer.setMaxTextMessageSize(65535);
            wsContainer.setIdleTimeout(Duration.ofHours(10));
            // Add websockets
            wsContainer.addMapping(eventPath + "/*", EventSocket.class);
        });

        try{
            server.start();
            server.join();
        }
        catch (Throwable t)
        {
//            t.printStackTrace(System.err);
            log.error("Jetty Server websocket start() error......, {}", t);
            System.exit(0);
        }
    }
}
