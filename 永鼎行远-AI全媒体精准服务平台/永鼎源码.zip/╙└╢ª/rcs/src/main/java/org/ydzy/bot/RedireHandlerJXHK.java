package org.ydzy.bot;

import checkers.igj.quals.I;
import com.google.inject.Inject;
import com.google.inject.name.Named;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.ydzy.handler.BaseRcsContextProvidor;
import org.ydzy.handler.RcsSession;
import org.ydzy.util.URLUtil;
import org.ydzy.util.Util;
import org.ydzy.util.crypto.AesUtil;
import org.ydzy.util.crypto.ICipherEncrypt;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * @author zxw
 * @create 2021/11/30
 */

public class RedireHandlerJXHK implements IRedirectHandler {
    private static final Logger log = LoggerFactory.getLogger(RedireHandlerJXHK.class);

    public static final String KEY_REDIRECT_HANDLER_BEAN_NAME = IRedirectHandler.BEAN_INSTANCE_KEY_PREFIX + "redirect_handler_hk_jixiang";

    @Inject
    @Named("thirdpart.redirect.uri.jxhk")
    private String redirect_uri;

    private String[] needRedirectDomain = {
            "juneyaoair.com",
            "sss-xtm.com",
            "shrbank.com",
            "booking.com",
            "agiview.com"
    };

    @Override
    public String transForm(Map<String, String[]> paramsMap, BaseRcsContextProvidor contextProvidor) {
        if (paramsMap == null || paramsMap.isEmpty()) {
            return null;
        }
        // �����ֻ���
        StringBuilder newParams = new StringBuilder();
        Set<String> containsKey = new HashSet<>();

        URLUtil.buildParam(newParams, "channel", "hw5g");
        containsKey.add("channel");
//        String[] params = paramsMap.get("param");
//        String param = null;
//        if(params != null && params.length > 0){
//            try {
//                param=new String(Base64.getUrlDecoder().decode(params[0].replace("@", "=")),"UTF-8");
//                System.out.println(param);
//            } catch (UnsupportedEncodingException e) {
//                e.printStackTrace();
//            }
//        }

        String[] sids = paramsMap.get("sid");
        if (sids != null && sids.length > 0) {
            RcsSession session = contextProvidor.newBaseRcsContext().getSession(sids[0]);
            Map<String, Object> thirdUserInfo = (Map<String, Object>) session.get("thirdpartUserInfo");
            if (thirdUserInfo != null && !thirdUserInfo.isEmpty()) {
                thirdUserInfo.forEach((k, v) -> {
                    URLUtil.buildParam(newParams, k, v.toString());
                    containsKey.add(k);
                });
            }
        }

        String[] redirect_uris = paramsMap.get("redirect_uri");
        if (redirect_uris != null && redirect_uris.length > 0) {
            URLUtil.buildParam(newParams, "redirect_uri", redirect_uris[0]);
            containsKey.add("redirect_uri");
        }

        //�ų�����(�Ǽ��麽�ղ���)
        containsKey.add("serviceName");
        containsKey.add("sid");
        containsKey.add("configid");
        containsKey.add("mdn");
        containsKey.add("param");
        containsKey.add("banned");
        // ��������
        paramsMap.forEach((k, v) -> {
            if (!containsKey.contains(k)) {
                URLUtil.buildParam(newParams, k, v.length != 0 ? v[0] : "");
                containsKey.add(k);
            }
        });

        log.info("redire uri param is {}", newParams);
        if (redirect_uri.contains("?")) {
            return redirect_uri + "&" + newParams.toString();
        } else {
            return redirect_uri + "?" + newParams.toString();
        }
    }

    @Override
    public String transForm(String params, String url, BaseRcsContextProvidor contextProvidor, RcsSession session) {
        if (Util.isNull(url)) {
            return null;
        }

        boolean needRedirect = false;
        for (String domain : needRedirectDomain) {
            if (url.contains(domain)){
                needRedirect = true;
                break;
            }
        }

        if(!needRedirect){
            return URLUtil.appendParams(url, params, false);
        }

        StringBuilder newParams = new StringBuilder();
        Set<String> containsKey = new HashSet<>();
        URLUtil.buildParam(newParams, "channel", "hw5g");
        containsKey.add("channel");

        Map<String, Object> thirdUserInfo = (Map<String, Object>) session.get("thirdpartUserInfo");
        if (thirdUserInfo != null && !thirdUserInfo.isEmpty()) {
            thirdUserInfo.forEach((k, v) -> {
                URLUtil.buildParam(newParams, k, v.toString());
                containsKey.add(k);
            });
        } else {
            String mdn = (String) session.get("mdn");
            if (!Util.isNull(mdn)) {
                ICipherEncrypt cipherEncrypt = new AesUtil(AesUtil.AESEnum.CBC_PKCS5PADDING);
                try {
                    String encryptMdn = cipherEncrypt.encryptBase64(mdn, LoginJXHK.encrypt_key, LoginJXHK.encrypt_key);
                    URLUtil.buildParam(newParams, "mobile", encryptMdn);
                    containsKey.add("mobile");
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }


        url = buildRedireURL(url, params);
        if(redirect_uri.contains("mp.juneyaoair"))
            url = url.replace("m.juneyaoair", "mp.juneyaoair");
        URLUtil.buildParam(newParams, "redirect_uri", url);
        return URLUtil.appendParams(redirect_uri, newParams, false);
    }

    /**
     * �ų��ǵ���������
     *
     * @param url
     * @param params
     * @return
     */
    private String buildRedireURL(String url, String params) {
        if (Util.isNull(url)) {
            return null;
        }
        Set<String> containsKey = new HashSet<>();
        //�ų�����
        containsKey.add("serviceName");
        containsKey.add("sid");
        containsKey.add("configid");
        containsKey.add("mdn");
        containsKey.add("param");
        containsKey.add("banned");
        StringBuilder filtedParam = new StringBuilder();
        if (!Util.isNull(params)) {
            String[] split = params.split("&");
            if (split != null) {
                Arrays.stream(split).forEach(kv -> {
                    if (kv.contains("=")) {
                        String[] kvs = kv.split("=");
                        if (containsKey.contains(kvs[0]) || kvs.length < 2) return;
                        URLUtil.buildParam(filtedParam, kvs[0], kvs[1]);
                        containsKey.add(kvs[0]);
                    }
                });
            }
        }
        return URLUtil.appendParams(url, filtedParam, false);
    }

}
