package org.ydzy.bot.model;

/**
 * �˵�ӳ�����
 * @author ljp
 *
 */
public class MenuGroup extends MenuBase{
	
	public MenuGroup(int menuid, int parentid, String displayText) {
		super(menuid, parentid);
		menu = new Menus(displayText);
	}

	public MenuGroup(int menuid, int parentid, String displayText, String menutexttype) {
		super(menuid, parentid);
		this.menutexttype = menutexttype;
		menu = new Menus(displayText);
	}

	public MenuGroup(int menuid) {
		super(menuid);
		menu = new Menus();
	}

	private Menus menu;
	public Menus getMenu() {
		return menu;
	}

	public void setMenu(Menus menu) {
		this.menu = menu;
	}
	
}
