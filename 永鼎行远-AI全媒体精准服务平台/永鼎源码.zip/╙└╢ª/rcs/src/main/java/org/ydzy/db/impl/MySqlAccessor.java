package org.ydzy.db.impl;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.ydzy.db.DbAccessor;
import org.ydzy.rcs.annotation.Description;
import org.ydzy.util.TimeUtil;
import org.ydzy.util.Util;

import com.google.inject.Singleton;
@Singleton
@Description("mysqlAdaptor")
public class MySqlAccessor implements DbAccessor{

	@Override
	public Set<String> tableExist(String dsId, String tname) {
		String sql_trueTabNames = "SELECT UCASE(TABLE_NAME) TNAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA=DATABASE() AND (TABLE_TYPE='VIEW'  OR TABLE_TYPE='BASE TABLE') AND TABLE_NAME   IN ("+tname.toUpperCase()+")";
		try {
			List<Object> result =exeQueryForSingleCol(dsId,sql_trueTabNames);
			if(result!=null)
			{
				return result.stream().map(o->Util.toString(o)).collect(Collectors.toSet());
			}
		} catch ( Exception e) {
			 log.error(" datasource {}  sql {} check table exists error ",dsId,sql_trueTabNames,e);
		}
		return null;
		
	}

	@Override
	public String getDateExpress(long date) {
//		String miformat = "STR_TO_DATE";
		String miformat = "%Y-%m-%d %H:%i:%s";
		String format="yyyy-MM-dd HH:mm:ss";
		String strDate=TimeUtil.formatDay(date, format);
		return "STR_TO_DATE('"+strDate+"','"+miformat+"')";
	}

	@Override
	public String queryForPage(String sql, String where, int rmin, int rmax) {

		int max=(rmax-rmin);
		if (!Util.isNull(where))
			where = where + "  LIMIT " +rmin + " , " +max;
		else
			where = " LIMIT " + rmin+ ", " + max;
		String newsql = "   SELECT T.* FROM   (" + sql + " ) T  " + where;
		return newsql;
	
	}

}
