package org.ydzy.rcs;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;
import java.util.function.Supplier;
import java.util.stream.Collectors;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.ydzy.bot.BotInfo;
import org.ydzy.bot.BotManager;
import org.ydzy.handler.BaseRcsContextProvidor;
import org.ydzy.rcs.annotation.Description;
import org.ydzy.rcs.db.XmlSqlGenerator;
import org.ydzy.rcs.media.UploadFileEntity;
import org.ydzy.util.SqlUtil;
import org.ydzy.util.Util;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.inject.Inject;
import com.google.inject.Singleton;
import com.google.inject.name.Named;

@Singleton
@Description(value="MediaSyn", autoInstance = true)
public class MediaSyn {
	private static Logger log = LoggerFactory.getLogger(MediaSyn.class);
	@Inject
	@Named("rcsDb")
	protected DataSource ds;
	
	private String mediaSqlId="synchronizedMedias2MNO";
	private String modelMediaSqlId="synchronizedMediasModel2MNO";
	@Inject
	BotManager botmanager;
	
	/** �Զ�ͬ��ý���ļ����Ƶ��(��) Ĭ��:1800  */
	@Inject(optional = true)
	@Named("media.syn.interval")
	private int mediaSynInterval = 1800;
	/***
	 * Context�����ṩ��
	 */
	@Inject
	private BaseRcsContextProvidor contextProvidor = null;
	public BaseRcsContextProvidor getContextProvidor() {
		return contextProvidor;
	}
	
	public void init(){
		botmanager.getExecutor().scheduleWithFixedDelay(this::run, 15, mediaSynInterval, TimeUnit.SECONDS);
	}
		
	public void run() {
		log.info("Begin run media syn ...");
		String sql =XmlSqlGenerator.getSqlstr(mediaSqlId);
//		try {
//			JsonArray resultSet=	SqlUtil.queryForJson(ds, sql);
//			log.info("Found " + resultSet.size()+ "'s media tobe syn...");
//			synMedias(resultSet);
//		} catch (SQLException e) {
//			e.printStackTrace();
//		}
	}
	
	private void synMedias(JsonArray resultSet)
	{
		Gson gson =new Gson();
		List<?> result=gson.fromJson(resultSet, List.class);
		List<CompletableFuture<UploadFileEntity>> uploadComplete =result.stream().parallel().map(o->{
			Supplier<UploadFileEntity> supplier = ()->{
				if(o instanceof Map) {
					Map<?, ?> mObject = (Map<?, ?>)o;
					String chatbotid =Util.toString(mObject.get("chatbotid"));
					String mediaID =Util.toString(mObject.get("mediaID"));
					log.info("Uploading media(" + mediaID + ") of chatbotid(" + chatbotid + ") ...");
					String chatbotIdentify=contextProvidor.newBaseRcsContext().getConfig().enterpriseProperty(chatbotid, "chatbotIdenty");
					BotInfo chatbotinfo=botmanager.getChatBotInfo(chatbotIdentify);
					if(chatbotinfo==null) {
						log.warn("Uploading media(" + mediaID + ") failed because of chatbot null!");
						return null;
					}
					try{
						UploadFileEntity entity =null ;
						entity = new UploadFileEntity(null,null);
						entity.setMediaID(mediaID);
						if(!chatbotinfo.getDbOper().loadMedia(entity)) {
							log.warn("Uploading media(" + mediaID + ") failed because of load media info from db failed!");
							return null;
						}
						
						if(!chatbotinfo.getBotAccess().mediaUpload(chatbotinfo, entity)) {
							log.warn("Uploading media(" + mediaID + ") failed , maybe chatbot(" + chatbotid + ") is invalid!");
							return null;
						}else {
							log.info("Finished upload media(" + mediaID + ") of chatbotid(" + chatbotid + ").");
						}
						return entity;
					}catch(Exception e) {
						log.warn("Uploading media(" + mediaID + ") error(" + e.getMessage() + ")",e);
					}
				}
				return null;
			};
			return CompletableFuture.supplyAsync(supplier, botmanager.getExecutor());
		}).collect(Collectors.toList());
		List<UploadFileEntity> uploads = uploadComplete.stream().map(CompletableFuture::join).filter(o->o!=null).collect(Collectors.toList());
		log.info("upload medias to ISP {}",uploads.size());
		//List<CompletableFuture> uploads = 
		
//		uploadComplete.stream().map(entity->{
//			
//			try {
//				String chatbotid =entity.get().getChatbotid();
//				BotInfo chatbotinfo=botmanager.getChatBotInfo(chatbotid);
//				if(chatbotinfo==null)
//					return null;
//				else
//				{
//					String mediaId=entity.get().getMediaID();
//					return botmanager.getDeliveryStatusMap().get(mediaId);
//				}
//			} catch (InterruptedException e) {
//			} catch (ExecutionException e) {
//			}
//			return null;
//		}).forEach(f->{
//			f.whenComplete((r,e)->{
//				
//			});
//		});;
	}
}
