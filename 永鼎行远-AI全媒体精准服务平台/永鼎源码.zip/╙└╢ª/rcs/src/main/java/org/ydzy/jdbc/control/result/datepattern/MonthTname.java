package org.ydzy.jdbc.control.result.datepattern;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.ydzy.rcs.annotation.Description;
import org.ydzy.util.TimeUtil;

import com.google.inject.Singleton;

@Description(autoInstance = false,value = "monthTname")
@Singleton
public class MonthTname implements ITime{

	@Override
	public List<String> reckonName(String pattern,long timeInterval, String sDate, String eDate, Calendar c1, Calendar c2) throws ParseException {
		List<String> tablelist =new ArrayList<String>();
		if(pattern.indexOf("'")<0) {
			tablelist.add(pattern);
			return tablelist;
		}
		SimpleDateFormat sdfPattern = new SimpleDateFormat(pattern);
		
		String radiustable =pattern
				.substring(pattern.indexOf("'") + 1, pattern.lastIndexOf("'")).toUpperCase();
		if (timeInterval == 2592000) {
			long slDate=TimeUtil.convertDate(sDate);
			radiustable = radiustable.replace("$", "M");
			sdfPattern = new SimpleDateFormat("'"+radiustable+"'yyMM");
			String tn = sdfPattern.format(slDate);
			tablelist.add(tn);
			c1.setTime(TimeUtil.sdfmon.parse(sDate));
			c2.setTime(TimeUtil.sdfmon.parse(eDate));
			int dif = Math.abs((c1.get(Calendar.YEAR) - c2.get(Calendar.YEAR)) * 12 + c1.get(Calendar.MONTH) - c2.get(Calendar.MONTH));
			for (int i = 0; i < dif; i++) {
				c1.set(c1.get(Calendar.YEAR), c1.get(Calendar.MONTH) + 2, 0);
				tn = sdfPattern.format(c1.getTime());
				if (!tablelist.contains(tn)) {
					tablelist.add(tn);
				}
			}
		}
		return tablelist;
	}

}
