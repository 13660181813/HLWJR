package org.ydzy.rcs.impl;


import org.ydzy.rcs.SuggestionDisplay;
import org.ydzy.rcs.annotation.Description;

import com.google.inject.Singleton;

@Singleton
@Description(value="dialerAction")
public class DialerAction implements SuggestionDisplay{

	@Override
	public String suggestionHtml(String[] args) {
//		List<String> suggestList = new ArrayList<String>();
//		String display = args[1];
//		String[] dialObject = args[2].split("\\Q$", -1);
//		for (String dobject : dialObject) {
//			String[] dactions = dobject.split("\\Q-", -1);
//			String atype = dactions[0];
//			SuggestionDisplay instance=Provider.getInstance(SuggestionDisplay.class, atype);
//			dactions[0]=display;
//			suggestList.add(instance.suggestionHtml(dactions));
//		}
		return suggestionHtmlSubs(args);
	}

}
