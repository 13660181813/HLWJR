package org.ydzy.csp.service;

import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

import javax.sql.DataSource;

import org.ydzy.handler.BaseHandler;
import org.ydzy.rcs.action.RcsRunLogAction;
import org.ydzy.rcs.db.XmlSqlGenerator;
import org.ydzy.rcs.db.XmlSqlGenerator.innerSql;
import org.ydzy.rcs.module.LoadProperties;
import org.ydzy.util.FileUtils;
import org.ydzy.util.SqlUtil;
import org.ydzy.util.Util;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.inject.Inject;
import com.google.inject.name.Named;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public abstract class BaseCspInter {
	public volatile String accessToken = "";
	private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(BaseCspInter.class);

	public volatile LinkedBlockingQueue<TaskInner> waitNotifyDeveloperQueue=new LinkedBlockingQueue<BaseCspInter.TaskInner>();

	public BaseCspInter() {
		
	}
	public void init()
	{
		checkAccessToken(ds,null);
		startRetryTaskThread();
		startChatbotTask();
	}
	
	
	protected String resBodyJson(String code, String msg, JsonElement res) {
		JsonObject resBody = new JsonObject();
		resBody.addProperty("code", code);
		resBody.addProperty("message", msg);
		resBody.add("data", res);
		return new Gson().toJson(resBody);
	}

	/**
	 * Զ�̵������Դ���
	 */
	private int MaxDoretryRMITime = 3;
	public static class TaskInner {
		public HttpServletRequest request;
		public HttpServletResponse response;
		public DataSource ds;
		public JsonObject body;
		public String operatorType;
		public long lastRetryTime = 0;
		public long nextRetryTime = 0;	//�´�����ʱ��
		public boolean add2db=true;
		public boolean doretryRMI=true;
		public int doretryRMITime = 0;	//Զ�̵������Դ���
		public boolean sendResponse=true;
		
	}

//	protected BlockingQueue<JsonObject> retryQueue = new LinkedBlockingQueue<JsonObject>();
//
//	protected void startAddCustomerRetryTask() {
//		Thread thread = new Thread() {
//			public void run() {
//				
//				while (true) {
//					try {
//						JsonObject body =retryQueue.take();
//						JsonObject resbody = reBuildCustomers(body);
//						JsonObject rcsRegisterInfo=resbody.getAsJsonObject("rcsRegisterInfo");
//						String uri = LoadProperties.systemProperties.getProperty("csp.tel.addCspCustomerUri");
//						String r=post25gMsgAddCspCustomer(uri,resbody);
//						if(!Util.isNull(r))
//						{
//							JsonObject ro = requestBody2Json(r);
//							JsonObject data = ro.getAsJsonObject("data");
//							
//							String cspEcNo = Util.getElementAsString(data, "cspEcNo");
//							if(!Util.isNull(cspEcNo))
//							{
////								cspEcNo
//								Object[] updateParam = new Object[] { Util.getElementAsString(rcsRegisterInfo, "cspEcNo"), cspEcNo };
//								try {
//									String sqlId = "updateCspECNo";
//									String sql = XmlSqlGenerator.getSql(sqlId);
//									SqlUtil.updateRecords(ds, sql, updateParam);
//								} catch (SQLException ex) {
//									ex.printStackTrace();
//									retryQueue.put(body);
//								}
//							}
//						}
//						Thread.sleep(1000);
//					} catch (InterruptedException e1) {
//						e1.printStackTrace();
//					}
//					
//					
//				}
//
//			}
//		};
//		thread.setName("RetryTaskThread");
//		thread.start();
//	}
	protected BlockingQueue<TaskInner> retryTaskQueue = new LinkedBlockingQueue<>();

	protected void startRetryTaskThread() {
		Thread thread = new Thread(() -> {
			JsonArray array=getUnCommitCustomers();
			if(array!=null)
			{
				array.forEach(e->{
					{
						TaskInner task =new TaskInner();
						task.body=e.getAsJsonObject();
						task.ds=ds;
						task.operatorType="addCspCustomer";
						task.add2db=false;
						retryTaskQueue.add(task);
					}
				});
			}
			while (true) {
				try {
					TaskInner entity = retryTaskQueue.take();
					if(entity != null && entity.doretryRMI && entity.doretryRMITime >= MaxDoretryRMITime){
						entity.doretryRMI =false;
					}
					entity.doretryRMITime++;
					if(entity.nextRetryTime >0 && System.currentTimeMillis() > entity.nextRetryTime+600000){
						retryTaskQueue.add(entity);
					}else{
						entity.nextRetryTime = Instant.now().getEpochSecond() + 600000;
						runTask(entity,entity.request,"",entity.response);
					}
					//handler(entity.request, null, entity.ds, entity.body);
//					runTask(entity,entity.request,"",entity.response);
//					Thread.sleep(600000);
				} catch (InterruptedException e1) {
					e1.printStackTrace();
				}
			}

		});
		thread.setName("RetryTaskQueueThread");
		thread.start();
	}
	public void updateChatBotDev()
	{
		JsonArray array=getNotifyResult();
		if(array!=null)
		{
			array.forEach(  e->{
				{
					TaskInner task =new TaskInner();
					task.body=e.getAsJsonObject();
					task.ds=ds;
					task.operatorType="updateDeveloper";
					waitNotifyDeveloperQueue.add(task);
				}
			});
		}else
		{
			System.out.println("why");
		}
	}
	protected void startChatbotTask() {
		Thread thread = new Thread() {
			public void run() {
				while(ds==null)
				{
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {
					}
				}
				updateChatBotDev();
				while (true) {
					try {
						TaskInner entity = waitNotifyDeveloperQueue.take();
						runTask(entity,entity.request,"",entity.response);
//						JsonObject resbody = reBuildCustomers(entity.body);
//						JsonObject rcsRegisterInfo=resbody.getAsJsonObject("rcsRegisterInfo");
//						String r =selectCspCustomer(entity);
//						if(!Util.isNull(r))
//						{
//							JsonObject ro = requestBody2Json(r);
//							JsonObject data = ro.getAsJsonObject("data");
//							
//							String cspEcNo = Util.getElementAsString(data, "cspEcNo");
//							if(!Util.isNull(cspEcNo))
//							{
////								cspEcNo
//								Object[] updateParam = new Object[] { Util.getElementAsString(rcsRegisterInfo, "cspEcNo"), cspEcNo };
//								try {
//									String sqlId = "updateCspECNotify";
//									String sql = XmlSqlGenerator.getSql(sqlId);
//									SqlUtil.updateRecords(ds, sql, updateParam);
//								} catch (SQLException ex) {
//									ex.printStackTrace();
//								}
//							}
//						}
						Thread.sleep(1000);
					} catch (InterruptedException e1) {
						e1.printStackTrace();
					}
					
				}

			}
		};
		thread.setName("CheckCspCustomerNotifyThread");
		thread.start();
	}

	protected void sendResponse(String remoteAddr, String body, int status, HttpServletRequest request,
			HttpServletResponse response) throws IOException {
		if (response != null) {
			// Declare response encoding and types
			response.setContentType("application/json;charset=utf-8");
			// Declare response status code
			response.setStatus(status);
			// Write back response
			response.getWriter().println(body);
			// Inform jetty that this request has now been handled
			log.info("send response {} to remoteAddr {} ", body, remoteAddr);
//		request.setHandled(true);
		}
	}
	@Inject
	@Named("rcsDb")
	protected DataSource ds;
	protected boolean isTimeOutToken(long accessTokenTime, String timeoutKey) {
		LocalDateTime time = LocalDateTime.now();
		long timeend = time.toInstant(ZoneOffset.of("+8")).toEpochMilli();
		String timeoutstr = Util.toString(LoadProperties.systemProperties.get(timeoutKey));
		long timeout = Long.valueOf(timeoutstr);
		return timeend - accessTokenTime > timeout;
	}
	
	public TaskInner handler(HttpServletRequest request, HttpServletResponse response, DataSource ds, JsonObject body) {
		String remoteAddr = BaseHandler.getIpAddress(request);
		TaskInner task=new TaskInner();
		task.body=body;
		task.ds=ds!=null?ds:this.ds;
		String type =task.operatorType;
		if(request!=null)
		{
			task.request=request;
			type = request.getParameter("operatorType");
			task.operatorType=type;
			task.response=response;
			
		}
		runTask(task,request,remoteAddr,response);
		return task;
	}
	protected boolean runTask(TaskInner task,HttpServletRequest request,String remoteAddr,HttpServletResponse response)
	{
		boolean flag=false;
		String type =task.operatorType;
		//
		try {
			if ("uploadFile".equals(type)) {
				flag=doUploadFile(task);
			} else if ("getFile".equals(type)) {
				flag=getFile(task);
			} else if ("addCspCustomer".equals(type)) {
				flag=addCspCustomer(task);
			} else if ("showEcInfos".equals(type)) {
				showEcInfos(task);
				flag=true;
			} else if ("editCspCustomer".equals(type)) {
				flag=editCspCustomer(task);
			} else if ("deleteCustomer".equals(type)) {
				flag=deleteCustomer(task);
			} else if ("ChatbotManager".equals(type)) {
				flag=ChatbotManager(task);
			} else if ("isOnlineUpdate".equals(type)) {
				// �����ñ��chatbot״̬��ֱ�ӵ����˳�����״̬������quitTestStatus��
				flag=isOnlineUpdate(task);
			} else if ("updateDeveloper".equals(type)) {
				flag=updateDeveloper(task);
			} else if("selectCspCustomer".equals(type)){
				selectCspCustomer(task);
			}else if ("quitTestStatus".equals(type)) {
                flag = quitTestStatus(task);
            } else if ("updatePhoneNumber".equals(type)) {
                flag = updatePhoneNumber(task);
            } else if ("selOperationLog".equals(type)) {
				flag = selOperationLog(task);
			} else {
				String resbody1 = resBodyJson("500", "unknow action type", null);
				try {
					if(request!=null)
					sendResponse(remoteAddr, resbody1, 200, request, response);
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			flag=true;
		}
		if(!flag)
		{
			task.lastRetryTime=Instant.now().getEpochSecond();
			task.doretryRMITime++;
			if(task.doretryRMITime >= MaxDoretryRMITime){
				task.doretryRMI = false;
			}
			retryTaskQueue.add(task);
		}
		return flag;
	}

    protected void logger(DataSource ds, String level, String code, String desc, String msg, String remoteAddr,
			HttpServletRequest request, String module) throws IOException {

		switch (level) {
		case "warn": {
			log.warn("status {} desc {}  msg {} remoteAddr {}", code, desc, msg, remoteAddr);
			break;
		}
		case "info": {
			log.info("status {} desc {}  msg {} remoteAddr {}", code, desc, msg, remoteAddr);
			break;
		}
		case "debug": {
			log.debug("status {} desc {}  msg {} remoteAddr {}", code, desc, msg, remoteAddr);
			break;
		}
		case "error": {
			log.error("status {} desc {}  msg {} remoteAddr {}", code, desc, msg, remoteAddr);
			break;
		}
		default: {
			log.info("status {} desc {}  msg {} remoteAddr {}", code, desc, msg, remoteAddr);
			break;
		}

		}
		if (ds != null) {
			RcsRunLogAction.recordLog(desc, msg, remoteAddr, code, module, ds);
		}

	}

	protected JsonObject requestBody2Json(String response) {
		if(Util.isNull(response))
			return null;
		JsonElement resObj = null;
		try {
			resObj = JsonParser.parseString(response);
		} catch (Exception ignored) {}
		if (resObj != null && resObj.isJsonObject()) {
			JsonObject obj = resObj.getAsJsonObject();
			String code = Util.getElementAsString(obj, "code");
			if ("0".equals(code)) {
				String message = Util.getElementAsString(obj, "message");

				log.info("request  suecss ! message{} ", message);
			} else {
				log.info("request  failed  ! cod {} error {}  ", LoadProperties.systemProperties
						.getOrDefault(code, Util.toString(LoadProperties.systemProperties.get("other"))), response);
			}
			return obj;
		}
		return null;
	}

	DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");
	private static ThreadLocal<SimpleDateFormat> threadLocal = new ThreadLocal<SimpleDateFormat>() {
		@Override
		protected SimpleDateFormat initialValue() {
			return new SimpleDateFormat("yyyyMMddHHmmss");
		}
	};

	public static Date parse(String dateStr) {
		try {
			return threadLocal.get().parse(dateStr);
		} catch (ParseException e) {
			return new Date();
		}
	}

	public static String format(Date date) {
		return threadLocal.get().format(date);
	}
	
	protected Map<String, Object> headers(String accesskey, LocalDateTime time) {
		return headers(accesskey, time, "application/json");
	}

	protected Map<String, Object> headers(String accesskey, LocalDateTime time, String contenttype) {
		Map<String, Object> header = new HashMap<String, Object>();
		header.put("content-type", contenttype);
		header.put("host","isptest.189.cn");
		String times = time.format(formatter);
		header.put("timestamp", times);
		String ramdomchar = Util.getRandomString(8);
		String nonce = times + ramdomchar;
		header.put("nonce", nonce);

		String signature = Util.encrypt(accesskey + nonce + times);
		header.put("signature", signature);
		return header;
	}

	protected Map<String, Object> uploadFile(HttpServletRequest request) throws IOException, ServletException {

		Map<String, Object> responseMap = FileUtils.doUploadByMulti(request,"cspFile\\");
		return responseMap;
	}
	protected abstract JsonArray getUnCommitCustomers();
	protected abstract JsonArray getNotifyResult();
	public abstract void checkAccessToken(DataSource ds, HttpServletRequest request);
	public abstract JsonObject reBuildCustomers(JsonObject body);
	public abstract void accessToken(DataSource ds, HttpServletRequest request);

	public abstract boolean doUploadFile(TaskInner task);

	public abstract boolean addCspCustomer(TaskInner task);
	public abstract String selectCspCustomer(TaskInner task);
	public abstract String post25gMsgAddCspCustomer(String uri,JsonObject resbody);
	public abstract boolean getFile(TaskInner task);

	public abstract void showEcInfos(TaskInner task);

	public abstract boolean editCspCustomer(TaskInner task);

	public abstract boolean deleteCustomer(TaskInner task);

	public abstract boolean ChatbotManager(TaskInner task);

	public abstract boolean isOnlineUpdate(TaskInner task);

	public abstract boolean validateHeader(HttpServletRequest request, DataSource ds);

	public abstract boolean updateDeveloper(TaskInner task);

    protected abstract boolean updatePhoneNumber(TaskInner task);

	protected abstract boolean selOperationLog(TaskInner task);

	protected abstract boolean quitTestStatus(TaskInner task);
	
	protected boolean InsertUploadFiles(DataSource ds ,Object [] paramsUpdate)
	{
		try {
			if(paramsUpdate!=null)
			{
				String sqlID="insertuploadfiles";
				String sql=XmlSqlGenerator.getSql(sqlID).exeSql;
				SqlUtil.updateRecords(ds, sql, paramsUpdate);
			}
			return true;
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		return false;
	}
	protected boolean insertCspCustomer(Gson gson,JsonObject body,DataSource ds)
	{
		boolean flag=false;
		Map dbParam=gson.fromJson(body, Map.class);
		try {
			String sqlId = "insertcspecinfomap";
			innerSql sql = XmlSqlGenerator.getSqlByMap(sqlId, dbParam);//XmlSqlGenerator.getSql(sqlId);
			SqlUtil.updateRecords(ds, sql.exeSql,sql.sqlParams.toArray());
			
			sqlId = "insertrcsusermap";
			sql = XmlSqlGenerator.getSqlByMap(sqlId,dbParam);
			SqlUtil.updateRecords(ds, sql.exeSql,sql.sqlParams.toArray());

			Map<String, Object> rcsInfoMap = (Map<String, Object>) dbParam.get("rcsInfo");
			Map<String, Object> rcsLegalPMap = (Map<String, Object>) dbParam.get("rcsLegalP");

			String info_Phone = Util.trim(rcsInfoMap.get("operatorPhone"));
			String legalp_phone = Util.trim(rcsLegalPMap.get("operatorPhone"));

			if (!info_Phone.equals(legalp_phone)) {
				//���ӷ�����Ϣ
				sqlId="insertrcslegalmap";
				sql=XmlSqlGenerator.getSqlByMap(sqlId, dbParam);
				SqlUtil.updateRecords(ds, sql.exeSql,sql.sqlParams.toArray());
			}
			sqlId = "insertrconstractmap";
			sql = XmlSqlGenerator.getSqlByMap(sqlId, dbParam);
			SqlUtil.updateRecords(ds, sql.exeSql,sql.sqlParams.toArray());
			flag=true;
		} catch (SQLException e) {
			e.printStackTrace();
			flag=false;
		}
		return flag;
	}
	protected boolean updateCspNo(DataSource ds,Object [] updateParam)
	{
		try {
			String sqlId = "updatecspecinfo";
			String sql = XmlSqlGenerator.getSql(sqlId).exeSql;
			SqlUtil.updateRecords(ds, sql, updateParam);
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}
	protected boolean updateCspInfos(Gson gson,JsonObject body,DataSource ds)
	{
		Map dbParam=gson.fromJson(body, Map.class);
		try {
			String sqlId = "updatecspecinfoallmap";
			innerSql sql = XmlSqlGenerator.getSqlByMap(sqlId,dbParam);
			SqlUtil.updateRecords(ds, sql.exeSql,sql.sqlParams.toArray());

			Map<String, Object> rcsInfoMap = (Map<String, Object>) dbParam.get("rcsInfo");
			Map<String, Object> rcsLegalPMap = (Map<String, Object>) dbParam.get("rcsLegalP");
			String operatorRcsUserId = Util.trim(rcsInfoMap.get("operatorRcsUserId"));
			String legalRcsUserId = Util.trim(rcsLegalPMap.get("legalRcsUserId"));
			String info_Phone = Util.trim(rcsInfoMap.get("operatorPhone"));
			String legalp_phone = Util.trim(rcsLegalPMap.get("operatorPhone"));
			//����û�ID��ͬ
			if (operatorRcsUserId.equals(legalRcsUserId)) {
				// �ֻ�����ͬ��ֻ����һ��
				if (info_Phone.equals(legalp_phone)) {
					sqlId = "updatercsusermap";
					sql = XmlSqlGenerator.getSqlByMap(sqlId,dbParam);
					SqlUtil.updateRecords(ds, sql.exeSql,sql.sqlParams.toArray());
				}
				// �ֻ��Ų�ͬ
				else {
					sqlId = "queryRcsUserByUserId";
					sql = XmlSqlGenerator.getSql(sqlId, operatorRcsUserId);
					JsonArray array = SqlUtil.queryForJson(ds, sql.exeSql);
					String phone = "";
					if (array.size() > 0) {
						JsonObject userObject = array.get(0).getAsJsonObject();
						phone = userObject.get("phone").getAsString();
					}
					if (!info_Phone.equals(phone)) {
						//������ϵ����Ϣ
						sqlId="insertrcsusermap";
						sql=XmlSqlGenerator.getSqlByMap(sqlId, dbParam);
						SqlUtil.updateRecords(ds, sql.exeSql,sql.sqlParams.toArray());
					}
					if (!legalp_phone.equals(phone)) {
						//���ӷ�����Ϣ
						sqlId="insertrcslegalmap";
						sql=XmlSqlGenerator.getSqlByMap(sqlId, dbParam);
						SqlUtil.updateRecords(ds, sql.exeSql,sql.sqlParams.toArray());
					}
					if (!info_Phone.equals(phone) && !legalp_phone.equals(phone)) {
						sqlId = "deleteRcsUser";
						Map<String,Object> params = new HashMap<>();
						params.put("userid", operatorRcsUserId);
						sql=XmlSqlGenerator.getSqlByMap(sqlId, params);
						SqlUtil.updateRecords(ds, sql.exeSql,sql.sqlParams.toArray());
					}
				}
			}
			// �û�ID��ͬ
			else {
				sqlId = "updatercsusermap";
				sql = XmlSqlGenerator.getSqlByMap(sqlId,dbParam);
				SqlUtil.updateRecords(ds,  sql.exeSql,sql.sqlParams.toArray());
				if (info_Phone.equals(legalp_phone) && !Util.isNull(legalRcsUserId)) {
					sqlId = "deleteRcsUser";
					Map<String,Object> params = new HashMap<>();
					params.put("userid", legalRcsUserId);
					sql=XmlSqlGenerator.getSqlByMap(sqlId,  params);
					SqlUtil.updateRecords(ds, sql.exeSql,sql.sqlParams.toArray());
				}
				//����з���id�����·�����Ϣ
				else if (!Util.isNull(legalRcsUserId)){
					sqlId = "updatercslegalusemap";
					sql = XmlSqlGenerator.getSqlByMap(sqlId,dbParam);
					SqlUtil.updateRecords(ds, sql.exeSql,sql.sqlParams.toArray());
				}
				//û�з���id���½�������Ϣ
				else {
					sqlId = "insertrcslegalmap";
					sql = XmlSqlGenerator.getSqlByMap(sqlId, dbParam);
					SqlUtil.updateRecords(ds, sql.exeSql,sql.sqlParams.toArray());
				}
			}
			sqlId = "updaterconstractmap";
			sql = XmlSqlGenerator.getSqlByMap(sqlId,dbParam);
			SqlUtil.updateRecords(ds, sql.exeSql,sql.sqlParams.toArray());
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}
	protected boolean  deleteCustomer2Db(Gson gson,JsonObject body,DataSource ds)
	{
		String sqlid="deletecspecinfo";
		Map dbParam=gson.fromJson(body, Map.class);
		innerSql sql = XmlSqlGenerator.getSqlByMap(sqlid,dbParam);
		try {
			SqlUtil.updateRecords(ds, sql.exeSql,sql.sqlParams.toArray());
			return true;
		} catch (SQLException e) {
		}
		return false;
	}
	protected boolean insertChatBot(Gson gson,JsonObject body,DataSource ds)
	{
		String sqlId="insertintochatbotinfo";
		Map dbParam=gson.fromJson(body, Map.class);
		String auditStatus = String.valueOf(dbParam.get("auditStatus"));
		if (Util.isNull(auditStatus)) dbParam.put("auditStatus", 11);
		innerSql sql=XmlSqlGenerator.getSqlByMap(sqlId, dbParam);
		innerSql sql2=XmlSqlGenerator.getSqlByMap("insert2rcs_phone_roles", dbParam);
		try {
			SqlUtil.updateRecords(ds, sql.exeSql,sql.sqlParams.toArray());
			SqlUtil.updateRecords(ds, sql2.exeSql,sql2.sqlParams.toArray());
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}
	protected boolean updateChatbotAuditStatus(Gson gson,JsonObject body,DataSource ds)
	{
		String sqlid="updatechatbotaudit";
		Map dbParam=gson.fromJson(body, Map.class);
		innerSql sql=XmlSqlGenerator.getSqlByMap(sqlid, dbParam);
		try {
			SqlUtil.updateRecords(ds, sql.exeSql,sql.sqlParams.toArray());
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
		
	}
	protected boolean updateChatBot(Gson gson,JsonObject body,DataSource ds)
	{
		String sqlid="updatechatbotinfo";
		Map dbParam=gson.fromJson(body, Map.class);
		if (Util.isNull(String.valueOf(dbParam.get("auditStatus"))))
			dbParam.put("auditStatus", 14);
		innerSql sql=XmlSqlGenerator.getSqlByMap(sqlid, dbParam);
		try {
			SqlUtil.updateRecords(ds, sql.exeSql,sql.sqlParams.toArray());
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}

	protected boolean updateChatBotByChatbotId(Gson gson, JsonObject bodyclone, DataSource ds) {
		String sqlid = "updateChatBotByChatbotId";
		Map dbParam = gson.fromJson(bodyclone, Map.class);
		innerSql sql = XmlSqlGenerator.getSqlByMap(sqlid, dbParam);
		try {
			SqlUtil.updateRecords(ds, sql.exeSql, sql.sqlParams.toArray());
			return true;
		} catch (Exception e) {
			e.printStackTrace();
		}

		return false;
	}

	protected boolean optionalsChatbot(Gson gson, JsonObject body, DataSource ds) {

		String sqlid = "optionalsChatbot";
		Map param = gson.fromJson(body, Map.class);
		innerSql sql = XmlSqlGenerator.getSqlByMap(sqlid, param);
		try {
			SqlUtil.updateRecords(ds, sql.exeSql,sql.sqlParams.toArray());
			return true;
		} catch (Exception e) {
			e.printStackTrace();
		}

		return false;
	}
	protected boolean deleteChatbot(Gson gson,JsonObject body,DataSource ds)
	{
		String sqlid="deleteorofflinechatbot";
		Map dbParam=gson.fromJson(body, Map.class);
		if (Util.isNull(String.valueOf(dbParam.get("auditStatus"))))
			dbParam.put("auditStatus", 16);
		innerSql sql=XmlSqlGenerator.getSqlByMap(sqlid, dbParam);
		try {
			SqlUtil.updateRecords(ds, sql.exeSql,sql.sqlParams.toArray());
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}

	/**
	 * ���chatbot������״̬
	 * @param gson
	 * @param body
	 * @param ds
	 * @return
	 */
	protected boolean updateOnlineStatusChatbot(Gson gson,JsonObject body,DataSource ds)
	{
		String sqlid="updateOnlineStatusChatbot";
		Map dbParam=gson.fromJson(body, Map.class);
		innerSql sql=XmlSqlGenerator.getSqlByMap(sqlid, dbParam);
		try {
			SqlUtil.updateRecords(ds, sql.exeSql,sql.sqlParams.toArray());
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}

	protected boolean updateDeveloper(Gson gson,JsonObject data, DataSource ds)
	{
		if(data==null||data.isJsonNull())
			return false;
		String sqlid="updatechatbotdeveloperinfo";
		Map dbParam=gson.fromJson(data, Map.class);
		if (Util.isNull(String.valueOf(dbParam.get("auditStatus"))))
			dbParam.put("auditStatus", 15);
		innerSql sql=XmlSqlGenerator.getSqlByMap(sqlid, dbParam);
		try {
			SqlUtil.updateRecords(ds, sql.exeSql,sql.sqlParams.toArray());
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}

    protected boolean updateQuitTestStatusFile(Gson gson, JsonObject body, DataSource ds) {
        String sqlid = "updateChatbotQuitTestStatusFile";
        Map map = gson.fromJson(body, Map.class);
        innerSql sql = XmlSqlGenerator.getSqlByMap(sqlid, map);
        try {
            SqlUtil.updateRecords(ds, sql.exeSql, sql.sqlParams.toArray());
//            return deleteChatbot(gson, body, ds);
			return true;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    /**
     * �����ֻ��Ű�����
     *
     * @param gson
     * @param body
     * @param ds
     * @return
     */
    protected boolean updatechatbotWhitePhoneList(Gson gson, JsonObject body, DataSource ds) {
        String sqlid = "updatechatbotWhitePhoneList";
        Map map = gson.fromJson(body, Map.class);
        innerSql sql = XmlSqlGenerator.getSqlByMap(sqlid, map);
        try {
            SqlUtil.updateRecords(ds, sql.exeSql, sql.sqlParams.toArray());
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}
