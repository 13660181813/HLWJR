package org.ydzy.rcs.factory;

import org.ydzy.rcs.Provider;
import org.ydzy.rcs.action.LoginAction;
import org.ydzy.rcs.action.PasswordLoginAction;
import org.ydzy.rcs.action.SMSLoginAction;

public class LoginActionFactory {
    public static LoginAction getInstance(String loginType) {
        return switch (loginType) {
            case "password" -> Provider.injector.getInstance(PasswordLoginAction.class);
            case "sms" -> Provider.injector.getInstance(SMSLoginAction.class);
            default -> throw new RuntimeException("����֧�ֵĵ�½��ʽ");
        };
    }
}
