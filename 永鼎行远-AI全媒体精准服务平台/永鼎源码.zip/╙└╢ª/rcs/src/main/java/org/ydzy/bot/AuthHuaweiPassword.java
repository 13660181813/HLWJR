package org.ydzy.bot;

import java.util.Map;

public class AuthHuaweiPassword implements IAuthorize {
	public static final String KEY_AUTH_HUAWEI_PASSWORD = KEY_AUTH + "huaweipassword";

	@Override
	public String attach(String url, Map<String, Object> headers, BotInfo botInfo) {
		String appid = botInfo.getAppId();
		String password = botInfo.getAppKey(); // botInfo.token
		if(appid!=null && !appid.isEmpty() && password!=null) {
			String authValue;
			authValue = "Username=\"" + appid + "\",Password=\"" + password + "\"";
			headers.put("Authorization", authValue);
		}
		return url;
	}
}
