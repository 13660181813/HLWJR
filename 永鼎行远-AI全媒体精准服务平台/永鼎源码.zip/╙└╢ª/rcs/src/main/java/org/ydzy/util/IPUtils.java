/*
 * @(#)IPUtils.java v2.0
 * Modify by LeonYu 2008-04-18
 * Copyright 2006-2008 bjxczy.cn All rights reserved.
 */
package org.ydzy.util;

import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * IP ת������
 * @author xf
 * @version v2.0
 */
public class IPUtils {

	/**
	 * �Ƿ�Ϊ����
	 */
	public static boolean isNumeric(String src){
		if(src==null || src.isEmpty()){return false;}
		Pattern pattern=Pattern.compile("^-?\\d+$");
		Matcher reg=pattern.matcher(src);
		return reg.find();
		
	}
	/**
     * IPת��Ϊ����
     * 
     * @return
     */
    public static int ip2Int(String ip) throws Exception{
    	String[] ips = ip.split("[\\.]");
        if (ips == null || ips.length != 4) {
        	throw new Exception("SyStem Message:'" + ip + "'��ַ��ʽ��Ч,���������� !");
        }
        int seg1 = Util.toInt(ips[0], -1);
        int seg2 = Util.toInt(ips[1], -1);
        int seg3 = Util.toInt(ips[2], -1);
        int seg4 = Util.toInt(ips[3], -1);
        int ret = (seg4 << 24) & 0xff000000;
        ret = ((seg3 << 16) & 0x00ff0000) | ret;
        ret = ((seg2 << 8) & 0x0000ff00) | ret;
        ret = seg1 | ret;
        return ret;
    }
    /**
     * IPת��Ϊ������
     * 
     * @return
     */
    public static long ip2Long(String ip) throws Exception {
    	if(Util.isNull(ip))
    		return 0;
        String[] ips = ip.split("[\\.]");
        if (ips == null || ips.length != 4) {
        	throw new Exception("SyStem Message:'" + ip + "'��ַ��ʽ��Ч,���������� !");
        }
        long seg1 = Util.toInt(ips[0], -1);
        long seg2 = Util.toInt(ips[1], -1);
        long seg3 = Util.toInt(ips[2], -1);
        long seg4 = Util.toInt(ips[3], -1);
        long ret = (seg4 << 24) & 0xff000000L;
        ret = ((seg3 << 16) & 0x00ff0000L) | ret;
        ret = ((seg2 << 8) & 0x0000ff00L) | ret;
        ret = seg1 | ret;
        return ret;
    }
    /**
     * ����ת��ΪIP
     * 
     * @return
     */
    public static String int2Ip(int i) {
    		int seg1 = (i >> 24) & 0x000000ff;
    		int seg2 = (i >> 16) & 0x000000ff;
    		int seg3 = (i >> 8) & 0x000000ff;
    		int seg4 = i & 0x000000ff;
    		return seg4 + "." + seg3 + "." + seg2 + "." + seg1;
    }
    /**
     * ������ת��ΪIP
     * 
     * @return
     */
    public static String long2Ip(long l) {
    	if(l == 0){
    		return "";
    	}else{
    		long seg1 = (l >> 24) & 0x000000ffL;
    		long seg2 = (l >> 16) & 0x000000ffL;
    		long seg3 = (l >> 8) & 0x000000ffL;
    		long seg4 = l & 0x000000ffL;
    		return seg4 + "." + seg3 + "." + seg2 + "." + seg1;
    	}
    }
    
    /**
     * IPת��Ϊ������,������������ͬ��������������������ڱȽϴ�С
     * 
     * @return
	*/
    public static long ip2CompareLong(String ip) throws Exception {
        String[] ips = ip.split("[\\.]");
        if (ips == null || ips.length != 4) {
        	throw new Exception("SyStem Message:'" + ip + "'��ַ��ʽ��Ч,���������� !");
        }
        long seg1 = Util.toInt(ips[0], -1);
        long seg2 = Util.toInt(ips[1], -1);
        long seg3 = Util.toInt(ips[2], -1);
        long seg4 = Util.toInt(ips[3], -1);
        long ret = (seg1 << 24) & 0xff000000L;
        ret = ((seg2 << 16) & 0x00ff0000L) | ret;
        ret = ((seg3 << 8) & 0x0000ff00L) | ret;
        ret = seg4 | ret;
        return ret;
    }
    
    /**
     * ������ת��ΪIP
     * 
     * @return
     */
    public static String long2CampareIp(long l) {
        long seg4 = (l >> 24) & 0x000000ffL;
        long seg3 = (l >> 16) & 0x000000ffL;
        long seg2 = (l >> 8) & 0x000000ffL;
        long seg1 = l & 0x000000ffL;
        return seg4 + "." + seg3 + "." + seg2 + "." + seg1;
    }

    
    /**
     * IP�ͿɱȽ�IP��ת��
     * */
    public static long compareIP(long ip){
    	long ret = (ip>> 24) & 0x000000ffL;
    	ret = ((ip >> 8) & 0x0000ff00L) | ret;
    	ret = ((ip << 8) & 0x00ff0000L) | ret;
    	ret = ((ip << 24) & 0xff000000L) | ret;
        return ret;
    }
//cdj add 2014-6-16 ȡ����IP
	//mod by lirui �޸Ļ�ȡ����IP��ȡ������һ����127.0.0.1��IPv4��ַ�����ȡ������Ĭ�Ϸ���127.0.0.1
    public static String getLocalIP(){
    	Enumeration allNetInterfaces;
		try {
			allNetInterfaces = NetworkInterface.getNetworkInterfaces();
    	InetAddress ip = null;
    	while (allNetInterfaces.hasMoreElements())
    	{
    	NetworkInterface netInterface = (NetworkInterface) allNetInterfaces.nextElement();
    	Enumeration addresses = netInterface.getInetAddresses();
    	while (addresses.hasMoreElements())
    	{
    	ip = (InetAddress) addresses.nextElement();
    	if (ip != null && ip instanceof Inet4Address)
    	{
    		String localIP = ip.getHostAddress();
    		if (!localIP.equals("127.0.0.1"))
    			return localIP;
    	}
    	}
    	}
		} catch (SocketException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	return "127.0.0.1";
    }

	public static boolean isInRange(String ip, String cidr) {
		try {
			if (cidr.isEmpty())
				return false;
			if (cidr.contains("-")){
				String[] ips = cidr.split("\\-");
				long iplong = ip2CompareLong(ip);
				long rangeSip = ip2CompareLong(ips[0]);
				long rangeEip = ip2CompareLong(ips[1]);
				return (iplong >= rangeSip) && (iplong <= rangeEip);
			} else if (cidr.contains("/")) {
				String[] ips = ip.split("\\.");
				int ipAddr = (Integer.parseInt(ips[0]) << 24) | (Integer.parseInt(ips[1]) << 16) | (Integer.parseInt(ips[2]) << 8) | Integer.parseInt(ips[3]);
				int type = Integer.parseInt(cidr.replaceAll(".*/", ""));
				int mask = 0xFFFFFFFF << (32 - type);
				String cidrIp = cidr.replaceAll("/.*", "");
				String[] cidrIps = cidrIp.split("\\.");
				int cidrIpAddr = (Integer.parseInt(cidrIps[0]) << 24) | (Integer.parseInt(cidrIps[1]) << 16) | (Integer.parseInt(cidrIps[2]) << 8) | Integer.parseInt(cidrIps[3]);
				return (ipAddr & mask) == (cidrIpAddr & mask);
			} else
				return ip.equals(cidr);
		} catch (Exception e) {
		}
		return false;
	}
	//��׼IPv4��ַ���������ʽ
	private static final Pattern IPV4_REGEX = Pattern.compile("^(25[0-5]|2[0-4]\\d|[0-1]?\\d?\\d)(\\.(25[0-5]|2[0-4]\\d|[0-1]?\\d?\\d)){3}$");
	//��ȫ0�飬��׼IPv6��ַ���������ʽ
	private static final Pattern IPV6_STD_REGEX = Pattern.compile("^([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}$");
	//ѹ���������ʽ
	private static final Pattern IPV6_COMPRESS_REGEX = Pattern.compile("^(([0-9A-Fa-f]{1,4}(:[0-9A-Fa-f]{1,4})*)?)::((([0-9A-Fa-f]{1,4}:)*[0-9A-Fa-f]{1,4})?)$");

	//�ж��Ƿ�Ϊ�Ϸ�IPv4��ַ
	public static boolean isIPv4Address(String ipv4){
		return IPV4_REGEX.matcher(ipv4).matches();
	}

	//�ж��Ƿ�Ϊ�Ϸ�IPv6��ַ
	public static boolean isIPv6Address(String ipv6){
		return IPV6_STD_REGEX.matcher(ipv6).matches() || IPV6_COMPRESS_REGEX.matcher(ipv6).matches();
	}
	/**
	 * �� IPv6 ��ַתΪ long ���飬ֻ֧��ð��ʮ�����Ʊ�ʾ��
	 */
	public static long[] ip2Longs(String ipString) {
		if (ipString == null || ipString.isEmpty()) {
			throw new IllegalArgumentException("ipString cannot be null.");
		}
		String[] ipSlices = ipString.split(":");
		if (ipSlices.length != 8) {
			throw new IllegalArgumentException(ipString + " is not an ipv6 address.");
		}
		long[] ipv6 = new long[2];
		for (int i = 0; i < 8; i++) {
			String slice = ipSlices[i];
			// �� 16 ���ƽ���
			long num = Long.parseLong(slice, 16);
			// ÿ�� 16 λ
			long right = num << (16 * i);
			// ÿ�� long �������飬i >> 2 = i / 4
			ipv6[i >> 2] |= right;
		}
		return ipv6;
	}

	/**
	 * �� long ����תΪð��ʮ�����Ʊ�ʾ���� IPv6 ��ַ
	 */
	public static String longs2Ip(long[] numbers) {
		if (numbers == null || numbers.length != 2) {
			throw new IllegalArgumentException(Arrays.toString(numbers) + " is not an IPv6 address.");
		}
		StringBuilder sb = new StringBuilder(32);
		for (long numSlice : numbers) {
			// ÿ�� long ��������
			for (int j = 0; j < 4; j++) {
				// ȡ��� 16 λ
				long current = numSlice & 0xFFFF;
				sb.append(Long.toString(current, 16)).append(":");
				// ���� 16 λ����ȥ�����Ѿ��������� 16 λ
				numSlice >>= 16;
			}
		}
		// ȥ������ :
		return sb.substring(0, sb.length() - 1);
	}

	/**
	 * ��֤����IPv6��ַ�Ƿ�һ��
	 * @param ip1
	 * @param ip2
	 * @return
	 */
	public static boolean isSameIpV6(String ip1, String ip2) {
		if (!isIPv6Address(ip1) || !isIPv6Address(ip2))
			return false;
		long[] lip1 = ip2Longs(ip1);
		long[] lip2 = ip2Longs(ip2);
		return Arrays.equals(lip1, lip2);
	}

    public static void main(String[] args) {
	    System.out.println(getLocalIP());
	    System.out.println(isInRange("192.168.8.66", "192.168.8.1/16"));
	    System.out.println(isInRange("192.168.8.66", "192.168.8.1/24"));
	    System.out.println(isInRange("192.168.8.66", "192.168.8.1-192.168.8.128"));
	    System.out.println(isInRange("192.168.8.66", "192.168.8.1-192.168.8.64"));
	    System.out.println(isInRange("192.168.8.66", "192.168.8.1"));
	    System.out.println(isInRange("192.168.8.66", "192.168.8.66"));
	    System.out.println(isInRange("2001:0000:3238:00E1:0063:0000:0000:FEFB", "192.168.8.1/16"));

	    System.out.println(isIPv4Address("192.168.1.100"));
	    System.out.println(isIPv4Address("192.168.1.300"));
	    System.out.println(isIPv6Address("2001:0000:3238:00E1:0063:0000:0000:FEFB"));
	    System.out.println(isIPv6Address("2001:0:3238:e1:63:0:0:fefbAAAA"));
	    System.out.println(isSameIpV6("2001:0000:3238:00E1:0063:0000:0000:FEFB","2001:0:3238:e1:63:0:0:fefb"));

    }
}