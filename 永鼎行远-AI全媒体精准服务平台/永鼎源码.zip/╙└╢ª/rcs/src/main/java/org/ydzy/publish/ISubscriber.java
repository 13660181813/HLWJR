package org.ydzy.publish;

/**
 * @author XFDEP
 * ������
 *
 */
public interface ISubscriber<M> {
	public void subscribe(SubscribePublish<M> subscribePulish);
	
	public void unSubscribe(SubscribePublish<M> subscribePulish);
	
	public void update(String publisher,M message);

}
