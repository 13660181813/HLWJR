package org.ydzy.filter;

import java.io.IOException;
import java.util.EnumSet;
import java.util.Map;

import org.eclipse.jetty.server.Request;
import org.eclipse.jetty.server.handler.HandlerList;
import org.eclipse.jetty.servlet.FilterHolder;
import org.eclipse.jetty.servlet.ServletContextHandler;
import org.eclipse.jetty.servlet.ServletHandler;
import org.eclipse.jetty.servlet.ServletHolder;
import org.eclipse.jetty.servlet.Source;

import jakarta.servlet.DispatcherType;
import jakarta.servlet.Filter;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.UnavailableException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Filter load handler,  use in HandlerList
 * @author ljp
 * @see HandlerList
 *
 */
public class FilterContextHandler extends ServletContextHandler{
	
	public FilterContextHandler(String filterClass) throws ClassNotFoundException {
		this(filterClass, null, null);
	}
	
	public FilterContextHandler(String filterClass, String path) throws ClassNotFoundException {
		this(filterClass, null, path);
	}
	
	public FilterContextHandler(String filterClass, Map<String, String> initParameters) throws ClassNotFoundException {
		this(filterClass, initParameters, null);
	}
	
	public FilterContextHandler(String filterClass, Map<String, String> initParameters, String path) throws ClassNotFoundException {
		this(Thread.currentThread().getContextClassLoader().loadClass(filterClass).asSubclass(Filter.class), initParameters, path);
	}
	
	public FilterContextHandler(Class<? extends Filter> filter, Map<String, String> initParameters) {
		this(filter, initParameters, null);
	}
	public FilterContextHandler(Class<? extends Filter> filter, String path) {
		this(filter, null, path);
	}
	public FilterContextHandler(Class<? extends Filter> filter, Map<String, String> initParameters, String path) {
		super(ServletContextHandler.SESSIONS);
		this.setFilter(filter,initParameters, path);
	}
	protected void setFilter(Class<? extends Filter> filter, Map<String, String> initParameters, String path) {
		FilterHolder fh = new FilterHolder(filter);
		//fh.setInitParameter("initParamKey", "InitParamValue");
		if(initParameters!=null)fh.setInitParameters(initParameters);
		addFilter(fh, path==null?"/*":(path), EnumSet.of(DispatcherType.REQUEST));
		this.setDisplayName("Filter(" + filter.getName() + ")");
	}
	    

	@Override
	public void doScope(String target, Request baseRequest, HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException
	{
		super.doScope(target, baseRequest, request, response);
		baseRequest.setHandled(!needRun.get());
		needRun.remove();
	}

	ThreadLocal<Boolean> needRun = ThreadLocal.withInitial(() -> false);

	@Override
	protected ServletHandler newServletHandler(){
		return new FilterServletHandler();
	}
	
	class FilterServletHandler extends ServletHandler{
		@Override
		public ServletHolder newServletHolder(Source source){
			return new FilterServletHolder(source);
		}
	}
	
	class FilterServletHolder extends ServletHolder{
		public FilterServletHolder(Source creator) {
			super(creator);
		}

		@Override
		public void handle(Request baseRequest, ServletRequest request, ServletResponse response)
				throws ServletException, UnavailableException, IOException {
			// ignore
			needRun.set(true);
			//super.handle(baseRequest, request, response);
		}
		
	}
	
}