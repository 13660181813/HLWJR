package org.ydzy.bot;

import java.nio.ByteBuffer;
import java.security.MessageDigest;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Base64;
import java.util.Map;

import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.digest.DigestUtils;

/** �й��ƶ�����Ӫ������ʱ ���������֤��ʽ */
public class AuthCmcc implements IAuthorize {
	public static final String KEY_AUTH_CMCC = KEY_AUTH + "cmcc";
	
	@Override
	public String attach(String url, Map<String, Object> headers, BotInfo botInfo) {
		ZonedDateTime nowTime =ZonedDateTime.now(ZoneOffset.ofHours(0));
		String date = DateTimeFormatter.RFC_1123_DATE_TIME.format(nowTime);
		String token = getSiature(date, botInfo);
		if(token!=null) {
			headers.put("authorization", "Basic " + token);
			headers.put("date", date);
		}
		return url;
	}
	
	protected String getSiature(String date, BotInfo botInfo) {
		String appid = botInfo.getAppId();
		String password = botInfo.getAppKey(); // botInfo.token
		if(appid==null||appid.isEmpty() || password==null) {
			return null;
		}
//		Basic BASE64(appid:sha256(token+Dateͷ��ֵ))	token=SHA256(password))
		
		MessageDigest ctx;
		ctx = DigestUtils.getSha256Digest();
		ctx.update(password.getBytes(BotUtil.utf8));
		byte[] outBytes = ctx.digest();
		String token = Hex.encodeHexString(outBytes);
		
		ctx = DigestUtils.getSha256Digest();
		ctx.update((token+date).getBytes(BotUtil.utf8));
		outBytes = ctx.digest();
		String encodeToken = Hex.encodeHexString(outBytes);
		outBytes = encodeToken.getBytes(BotUtil.utf8);
		ByteBuffer buffer = ByteBuffer.allocate(2048);
		buffer.put(appid.getBytes(BotUtil.utf8));
		buffer.put((byte)':');
		buffer.put(outBytes);
		buffer.flip();
		outBytes = new byte[buffer.limit()];
		buffer.get(outBytes);
		String encodeStr = Base64.getEncoder().encodeToString(outBytes);
		return encodeStr;
		
	}
		

}
