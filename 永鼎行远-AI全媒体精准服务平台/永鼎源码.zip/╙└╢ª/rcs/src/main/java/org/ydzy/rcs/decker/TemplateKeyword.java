package org.ydzy.rcs.decker;

import org.ydzy.handler.BaseRcsContext;
import org.ydzy.rcs.BodyTransform;
import org.ydzy.rcs.IMsgProvidor;
import org.ydzy.rcs.annotation.Description;
import org.ydzy.rcs.entity.ReceiveEntity;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.inject.Singleton;

/**
 * ʹ�����ģ�� ƥ��ؼ���, ��ƥ���ټ���ģ���������
 * @author ljp
 *
 */
@Singleton
@Description(value = "templatechatbot")
public class TemplateKeyword  implements DeckerRobot{
	
	@Override
	public JsonElement doTransform(BodyTransform transform,JsonElement efind) {
		if(efind==null){
			BaseRcsContext context=transform.context;
			ReceiveEntity receiveEntity =transform.receiveEntity;
			IMsgProvidor ft = context.getConfig().getForeignTemplates(receiveEntity.getChatBotId());
			if(ft!=null){
				String reqKeyWords = receiveEntity.getContent();
				JsonObject jo = ft.getKeyWords(reqKeyWords);
				if(jo!=null && ft.loadParas(jo, context, receiveEntity, transform)) {
					transform.continued=false;
					return jo;
				}
			}
		}
		return efind;
	}

}
