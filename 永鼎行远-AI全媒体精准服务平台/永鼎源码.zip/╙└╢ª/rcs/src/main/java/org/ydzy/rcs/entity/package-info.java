@javax.xml.bind.annotation.XmlSchema(
		namespace = "urn:oma:xml:rest:netapi:messaging:1",
xmlns={
		@javax.xml.bind.annotation.XmlNs(prefix="msg",namespaceURI=""),
@javax.xml.bind.annotation.XmlNs(prefix="msg",namespaceURI="urn:oma:xml:rest:netapi:messaging:1")
		}
//, elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED
		)
package   org.ydzy.rcs.entity;
