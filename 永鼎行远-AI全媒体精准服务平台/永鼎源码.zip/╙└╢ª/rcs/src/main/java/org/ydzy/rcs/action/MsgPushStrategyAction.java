package org.ydzy.rcs.action;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.ydzy.config.ApplicationConfig;
import org.ydzy.rcs.db.XmlSqlGenerator;
import org.ydzy.rcs.db.XmlSqlGenerator.innerSql;
import org.ydzy.util.SqlUtil;
import org.ydzy.util.Util;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.inject.Inject;
import com.google.inject.name.Named;

/**
 * @author lirui
 * @Date 2021/6/7 7:46 ����
 */
public class MsgPushStrategyAction {
    static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(MsgPushStrategyAction.class);

    @Inject
    @Named("rcsDb")
    DataSource ds;
    @Inject
    private final ApplicationConfig applicationconfig = null;

    public long insertMsgPushStrategy(JsonObject object) {
        String sqlId = "insertMsgPush";
        innerSql sql = null;
        try {
            Map<String, Object> params = new HashMap<>();
            String chatbotid = Util.getElementAsString(object, "chatbotid");
//            String configid = Util.getElementAsString(object, "configid");
            String type = Util.getElementAsString(object, "type");
            String crontab = Util.getElementAsString(object, "crontab");
            if (Util.isNull(chatbotid) || Util.isNull(type) || Util.isNull(crontab))
                return -1;
            params.put("chatbotid", chatbotid);
//            params.put("configid", configid);
            params.put("type", type);
            params.put("crontab", crontab);
            String enable = Util.getElementAsString(object, "enable");
            params.put("enable", enable);
            sql = XmlSqlGenerator.getSqlByMap(sqlId, params);
            return SqlUtil.insert(ds, sql.exeSql,sql.sqlParams.toArray());
        } catch (Exception e) {
            log.error("insert msg push strategy error.sqlId={}, sql={}", sqlId, sql, e);
        }
        return -1;
    }

    public boolean insertPushRelation(long pushid, JsonObject object) {
        String sqlId = "insertMsgPushRelation";
        StringBuffer sqls = new StringBuffer();
        try {
            //insert into rcs_msg_push_relation values('{pushid}','{pushtype}','{uid}')
            Map<String, Object> params = new HashMap<>();
            params.put("pushid", pushid);
            JsonArray ids = null;
            String pushtype = "";
            if (object.has("usertagIds")) {
                ids = object.getAsJsonArray("usertagIds");
                pushtype = "1";
                params.put("pushtype", pushtype);
                for (JsonElement ele : ids) {
                    params.put("uid", ele.getAsString());
                    sqls.append(XmlSqlGenerator.getSqlstrByMap(sqlId, params)).append(";");
                }
            }
            if (object.has("userIds")) {
                ids = object.getAsJsonArray("userIds");
                pushtype = "2";
                params.put("pushtype", pushtype);
                for (JsonElement ele : ids) {
                    params.put("uid", ele.getAsString());
                    sqls.append(XmlSqlGenerator.getSqlstrByMap(sqlId, params)).append(";");
                }
            }
            if (object.has("userPhones")) {
                ids = object.getAsJsonArray("userPhones");
                pushtype = "3";
                params.put("pushtype", pushtype);
                for (JsonElement ele : ids) {
                    params.put("uid", ele.getAsString());
                    sqls.append(XmlSqlGenerator.getSqlstrByMap(sqlId, params)).append(";");
                }
            }
            if (ids == null)
                return true;
            return SqlUtil.updateRecords(ds, sqls.toString());
        } catch (Exception e) {
            log.error("insert msg push strategy error.sqlId={}, sql={}", sqlId, sqls, e);
        }
        return false;
    }

    public boolean updateMsgPush(JsonObject object) {
        String sqlId = "updateMsgPush";
        String delMsgPushRelationSqlId = "delMsgPushRelation";
        String delMsgPushConfigSqlId = "delMsgPushConfig";
        innerSql sql = null;
        try {
            String id = Util.getElementAsString(object, "id");
            String chatbotid = Util.getElementAsString(object, "chatbotid");
            String type = Util.getElementAsString(object, "type");
            String crontab = Util.getElementAsString(object, "crontab");
            if (Util.isNull(id) || Util.isNull(chatbotid) || Util.isNull(type) || Util.isNull(crontab))
                return false;
            Map<String, Object> params = new HashMap<>();
            params.put("id", id);
            params.put("chatbotid", chatbotid);
            params.put("type", type);
            params.put("crontab", crontab);
            String enable = Util.getElementAsString(object, "enable");
            params.put("enable", enable);
            sql = XmlSqlGenerator.getSqlByMap(sqlId, params);
            boolean flag = SqlUtil.updateRecords(ds, sql.exeSql,sql.sqlParams.toArray());
            if (!flag)
                return false;
            long lid = Util.toLong(id, 0);
            flag = delMsgPushRelation(lid, delMsgPushRelationSqlId) && delMsgPushRelation(lid, delMsgPushConfigSqlId);
            if (flag)
                return insertPushRelation(lid, object) && insertPushConfig(lid, object);
        } catch (Exception e) {
            log.error("update msg push strategy error.sqlId={}, sql={}", sqlId, sql, e);
        }
        return false;
    }

    public boolean delMsgPush(long pushid) {
        String sqlId = "delMsgPush";
        innerSql sql = null;
        try {
            Map<String, Object> params = new HashMap<>();
            params.put("id", pushid);
            sql = XmlSqlGenerator.getSqlByMap(sqlId, params);
            String delMsgPushRelationSqlId = "delMsgPushRelation";
            String delMsgPushConfigSqlId = "delMsgPushConfig";
            delMsgPushRelation(pushid, delMsgPushRelationSqlId);
            delMsgPushRelation(pushid, delMsgPushConfigSqlId);
            return SqlUtil.updateRecords(ds, sql.exeSql,sql.sqlParams.toArray());
        } catch (Exception e) {
            log.error("delte msg push error.sqlId={}, sql={}", sqlId, sql);
        }
        return false;
    }

    public boolean delMsgPushRelation(long pushid, String sqlId) {
        innerSql sql = null;
        try {
            Map<String, Object> params = new HashMap<>();
            params.put("pushid", pushid);
            sql = XmlSqlGenerator.getSqlByMap(sqlId, params);
            return SqlUtil.updateRecords(ds, sql.exeSql,sql.sqlParams.toArray());
        } catch (Exception e) {
            log.error("delte msg push error.sqlId={}, sql={}", sqlId, sql);
        }
        return false;
    }

    public JsonArray queryMsgPush(JsonObject params) {
        JsonArray msgPushArray = new JsonArray();
        String sqlId = "queryMsgPush";
        try {
        	int pageNum = 0;
        	int pageSize=-1;
        	try {
        		pageNum = Integer.parseInt(Util.getElementAsString(params, "pageNum"));
        	}catch(Exception ignore) {}
        	try {
        		pageSize = Integer.parseInt(Util.getElementAsString(params, "pageSize"));
        	}catch(Exception ignore) {}
        	JsonObject params1 = params.deepCopy();
        	params1.remove("pageNum");
        	params1.remove("pageSize");
        	ArrayList<String> ids = new ArrayList<>();
//            String sql = XmlSqlGenerator.getSqlByMap(sqlId, params);
            String sql = XmlSqlGenerator.getSqlByJson(sqlId, null, params1);
            JsonArray jsonArray = SqlUtil.queryForJson(ds, sql);
            Map<String, JsonObject> pushmsgMap = new HashMap<>();
            Map<String, JsonObject> userMap = new HashMap<>();
            for (JsonElement ele : jsonArray) {
                JsonObject pushobj = ele.getAsJsonObject();
                String id = Util.getElementAsString(pushobj, "id");
                String chatbotid = Util.getElementAsString(pushobj, "chatbotid");
                String chatbotname = Util.getElementAsString(pushobj, "chatbotname");
//                String configid = Util.getElementAsString(pushobj, "configid");
                String type = Util.getElementAsString(pushobj, "type");
                String crontab = Util.getElementAsString(pushobj, "crontab");
                String cdate = Util.getElementAsString(pushobj, "cdate");
                String mdate = Util.getElementAsString(pushobj, "mdate");
                String enable = Util.getElementAsString(pushobj, "enable");
                String userpushtype = Util.getElementAsString(pushobj, "userpushtype");
                String uid = Util.getElementAsString(pushobj, "uid");
                String configpushtype = Util.getElementAsString(pushobj, "configpushtype");
                String cid = Util.getElementAsString(pushobj, "cid");
                String keywords = Util.getElementAsString(pushobj, "keywords");
                String tagsubType = Util.getElementAsString(pushobj, "tagsubType");
                String username = Util.getElementAsString(pushobj, "username");
                String phone = Util.getElementAsString(pushobj, "phone");
                String usertag = Util.getElementAsString(pushobj, "usertag");
//                String description = Util.getElementAsString(pushobj, "description");
//                String mediaUrl = Util.getElementAsString(pushobj, "mediaUrl");
//                String thumbnailUrl = Util.getElementAsString(pushobj, "thumbnailUrl");
//                String mediaContentType = Util.getElementAsString(pushobj, "mediaContentType");
//                String thumbnailContentType = Util.getElementAsString(pushobj, "thumbnailContentType");
                if (!pushmsgMap.containsKey(id)) {
                	if(!ids.contains(id))ids.add(id);
                    JsonObject obj = new JsonObject();
                    obj.addProperty("id", id);
                    obj.addProperty("chatbotid", chatbotid);
                    obj.addProperty("chatbotname", chatbotname);
//                    obj.addProperty("configid", configid);
                    obj.addProperty("type", type);
                    obj.addProperty("crontab", crontab);
                    obj.addProperty("enable", enable);
                    obj.addProperty("keywords", keywords);
                    obj.addProperty("tagsubType", tagsubType);
//                    obj.addProperty("description", description);
                    obj.addProperty("cdate", cdate);
                    obj.addProperty("mdate", mdate);
//                    obj.addProperty("mediaUrl", mediaUrl);
//                    obj.addProperty("thumbnailUrl", thumbnailUrl);
//                    obj.addProperty("mediaContentType", mediaContentType);
//                    obj.addProperty("thumbnailContentType", thumbnailContentType);
                    pushmsgMap.put(id, obj);
                }
                JsonObject userObject = userMap.get(id);
                if (userObject == null) {
                    userObject = new JsonObject();
                    userMap.put(id, userObject);
//                    JsonArray tagArray = new JsonArray();
//                    JsonArray userArray = new JsonArray();
                    userObject.add("usertagIds", new JsonArray());
                    userObject.add("userIds", new JsonArray());
                    userObject.add("userPhones", new JsonArray());
                    userObject.add("configIds", new JsonArray());
                    userObject.add("configtagIds", new JsonArray());
                }
                JsonObject usertmp = new JsonObject();
                usertmp.addProperty("username", username);
                usertmp.addProperty("phone", phone);
                usertmp.addProperty("usertag", usertag);
                usertmp.addProperty("uid", uid);
                switch (userpushtype) {
                    // �û���ǩ
                    case "1" -> {
                    	JsonArray ja = userObject.getAsJsonArray("usertagIds");
                    	if(ja!=null) {
                    		JsonObject jo = jsonArrayContains(ja, usertmp, "uid");
                    		if(jo==null) {
                    			ja.add(usertmp);
                    		}else {
                    			JsonArray ja1 = jo.getAsJsonArray("phoneList");
                    			if(ja1==null) {
                    				ja1 = new JsonArray();
                    				ja1.add(Util.getElementAsString(jo, "phone"));
                    				jo.add("phoneList", ja1);
                    			}
                    			String tmpValue = Util.getElementAsString(usertmp, "phone");
                    			List<String> values = new ArrayList<>();
                    			ja1.forEach(e -> values.add(e.getAsString()));
                    			if(!values.contains(tmpValue))ja1.add(tmpValue);
                    		}
                    	}
                    }
                    //�û�
                    case "2" -> {
                        if (jsonArrayContains(userObject.getAsJsonArray("userIds"), usertmp, "uid")==null)
                            userObject.getAsJsonArray("userIds").add(usertmp);
                    }
                    //�ֻ�����
                    case "3" -> {
                        if (jsonArrayContains(userObject.getAsJsonArray("userPhones"), phone)==null)
                        userObject.getAsJsonArray("userPhones").add(phone);

                    }
                }

                JsonObject configtmp = new JsonObject();
                configtmp.addProperty("chatbotid", chatbotid);
                configtmp.addProperty("keywords", keywords);
                configtmp.addProperty("tagsubType", tagsubType);
                configtmp.addProperty("cid", cid);
                switch (configpushtype) {
                    case "1" :
                    case "role" :
                        {
                    	JsonArray ja = userObject.getAsJsonArray("configtagIds");
                    	if(ja!=null) {
                    		JsonObject jo = jsonArrayContains(ja, configtmp, "cid");
                    		if(jo==null) {
                    			ja.add(configtmp);
                    		}else {
                    			JsonArray ja1 = jo.getAsJsonArray("keywordsList");
                    			if(ja1==null) {
                    				ja1 = new JsonArray();
                    				ja1.add(Util.getElementAsString(jo, "keywords"));
                    				jo.add("keywordsList", ja1);
                    			}
                    			String tmpValue = Util.getElementAsString(configtmp, "keywords");
                    			List<String> values = new ArrayList<>();
                    			ja1.forEach(e -> values.add(e.getAsString()));
                    			if(!values.contains(tmpValue))ja1.add(tmpValue);
                    		}
                    	}
                    	break;
                    }
                    case "2" : {
                        if (jsonArrayContains(userObject.getAsJsonArray("configIds"), configtmp, "cid")==null)
                            userObject.getAsJsonArray("configIds").add(configtmp);
                        break;
                    }
                }
            }
            java.util.List<String> tmpIds;
            if(pageNum>=0 && pageSize>0) {
            	if(pageNum<ids.size()) {
            		int endPos = pageNum+pageSize;
            		tmpIds = ids.subList(pageNum, (endPos<=ids.size()?endPos:ids.size()));
            	}else {
            		tmpIds = new ArrayList<>();
            	}
            }else {
            	tmpIds = ids;
            }
            
            tmpIds.forEach((id) ->  {
            	JsonObject jsonObject = pushmsgMap.get(id);
                jsonObject.add("usertagIds", userMap.get(id).get("usertagIds"));
                jsonObject.add("userIds", userMap.get(id).get("userIds"));
                jsonObject.add("userPhones", userMap.get(id).get("userPhones"));
                jsonObject.add("configtagIds", userMap.get(id).get("configtagIds"));
                jsonObject.add("configIds", userMap.get(id).get("configIds"));
                msgPushArray.add(jsonObject);
            });
        } catch (Exception e) {
            log.error("query msg push error.sqlId={}", sqlId, e);
        }
        return msgPushArray;
    }

    public boolean insertPushConfig(long pushid, JsonObject object) {
        String sqlId = "insertMsgPushConfig";
        StringBuffer sqls = new StringBuffer();
        try {
            Map<String, Object> params = new HashMap<>();
            params.put("pushid", pushid);
            JsonArray ids = null;
            String pushtype = "";
            if (object.has("configtagIds")) {
                ids = object.getAsJsonArray("configtagIds");
                pushtype = "1";
                params.put("pushtype", pushtype);
                for (JsonElement ele : ids) {
                    String cid = ele.getAsString();
                    if (cid.contains(":"))
                        pushtype = cid.substring(0, cid.indexOf(":"));
                    params.put("pushtype", pushtype);
                    params.put("cid", cid);
                    sqls.append(XmlSqlGenerator.getSqlstrByMap(sqlId, params)).append(";");
                }
            }
            if (object.has("configIds")) {
                ids = object.getAsJsonArray("configIds");
                pushtype = "2";
                params.put("pushtype", pushtype);
                for (JsonElement ele : ids) {
                    params.put("cid", ele.getAsString());
                    sqls.append(XmlSqlGenerator.getSqlstrByMap(sqlId, params)).append(";");
                }
            }
            if (ids == null)
                return true;
            return SqlUtil.updateRecords(ds, sqls.toString());
        } catch (Exception e) {
            log.error("insert msg push config strategy error.sqlId={}, sql={}", sqlId, sqls, e);
        }
        return false;
    }

    public JsonArray queryConfigTags(String chatbotId) {
        String sqlId = "queryConfigTagsByChatbotid";
        JsonArray tagArray = new JsonArray();
        try {
            String sql = XmlSqlGenerator.getSqlstr(sqlId, chatbotId);
            JsonArray array = SqlUtil.queryForJson(ds, sql);
            Map<String, JsonArray> tagmap = new HashMap<>();
            for (JsonElement ele : array) {
                JsonObject object = ele.getAsJsonObject();
                String tagType = Util.getElementAsString(object, "tagType");
                JsonArray tagsArray = tagmap.get(tagType);
                if (tagsArray == null) {
                    tagsArray = new JsonArray();
                    tagmap.put(tagType, tagsArray);
                }
                JsonObject tagObj = new JsonObject();
                String tagsubType = Util.getElementAsString(object, "tagsubType");
                String tagNo = Util.getElementAsString(object, "tagNo");
                String type = Util.getElementAsString(object, "type");
                tagObj.addProperty("tagNo", tagNo);
                tagObj.addProperty("type", type);
                tagObj.addProperty("tagsubType", tagsubType);
                tagsArray.add(tagObj);
            }
            tagmap.forEach((s, jsonElements) -> {
                JsonObject obj = new JsonObject();
                obj.add(s, jsonElements);
                tagArray.add(obj);
            });
        } catch (Exception e) {
            log.error("queryConfigTags error.", e);
        }
        return tagArray;
    }

    /**
     * ɾ�����ݿ��в����õ���Ϣ���Ͳ������� , ������Ϣ�ж�Ӧ cid��uid��configidΪ�յļ�¼
     * @return
     */
    public List<String> deleteInvalidMsgPush() {
        List<String> invalidList = new ArrayList<>();
        String sqlId = "queryMsgPushInvalid";
        try {
            String sql = XmlSqlGenerator.getSqlByJson(sqlId, null, new JsonObject());
            JsonArray jsonArray = SqlUtil.queryForJson(ds, sql);
            for (JsonElement ele : jsonArray) {
                JsonObject pushobj = ele.getAsJsonObject();
                String id = Util.getElementAsString(pushobj, "id");
                invalidList.add(id);
            }
        } catch (Exception e) {
            log.error("query msg push error.sqlId={}", sqlId, e);
        }
        if(invalidList!=null && !invalidList.isEmpty()) {
        	log.info("Deleting invalid msgPush config, ids:" + invalidList);
        	// delMsgPush 		id
        	// delMsgPushConfig   pushid
        	// delMsgPushRelation   pushid
        	String[] sqlIds = new String[] {"delMsgPush", "delMsgPushConfig", "delMsgPushRelation"};
        	for(String id:invalidList) {
        		JsonObject para = new JsonObject();
        		para.addProperty("id", id);
        		para.addProperty("pushid", id);
        		for(String sqlid:sqlIds) {
        			try {
        				String sql = XmlSqlGenerator.getSqlByJson(sqlid, null, para);
        				SqlUtil.updateRecords(ds, sql);
        			} catch (Exception e) {
        				log.error("query msg push error.sqlId={}", sqlid, e);
        			}
        		}
        	}
        }
        return invalidList;
    }

    public JsonArray queryUserTags(JsonObject params) {
        String sqlId = "queryUserTags";
        JsonArray tagArray = new JsonArray();
        try {
            String sql = XmlSqlGenerator.getSqlByJson(sqlId, null, params);
            JsonArray array = SqlUtil.queryForJson(ds, sql);
            Map<String, JsonArray> tagmap = new HashMap<>();
            for (JsonElement ele : array) {
                JsonObject object = ele.getAsJsonObject();
                String tagType = Util.getElementAsString(object, "tagType");
                JsonArray tagsArray = tagmap.get(tagType);
                if (tagsArray == null) {
                    tagsArray = new JsonArray();
                    tagmap.put(tagType, tagsArray);
                }
                JsonObject tagObj = new JsonObject();
                String tagsubType = Util.getElementAsString(object, "tagsubType");
                String tagNo = Util.getElementAsString(object, "tagNo");
                tagObj.addProperty("tagNo", tagNo);
                tagObj.addProperty("tagsubType", tagsubType);
                tagsArray.add(tagObj);
            }
            tagmap.forEach((s, jsonElements) -> {
                JsonObject obj = new JsonObject();
                obj.add(s, jsonElements);
                tagArray.add(obj);
            });
        } catch (Exception e) {
            log.error("query user Tags error.", e);
        }
        return tagArray;
    }

    private JsonObject jsonArrayContains(JsonArray array, JsonObject value, String key) {
        if (array == null || array.isJsonNull())
            return null;
        String targetVal = Util.getElementAsString(value, key);
        for (JsonElement ele : array) {
            JsonObject obj = ele.getAsJsonObject();
            String source = Util.getElementAsString(obj, key);
            if (source.equals(targetVal))
                return obj;
        }
        return null;
    }

    private String jsonArrayContains(JsonArray array, String value) {
        if (array == null || array.isJsonNull())
            return null;
        for (JsonElement ele : array) {
            String source = ele.getAsString();
            if (source.equals(value))
                return value;
        }
        return null;
    }
}
