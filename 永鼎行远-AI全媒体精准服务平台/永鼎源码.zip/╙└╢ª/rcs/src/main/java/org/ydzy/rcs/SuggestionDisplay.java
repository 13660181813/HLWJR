package org.ydzy.rcs;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.ydzy.util.Util;

/**
 * @author XFDEP
 * ����ظ�/�˵���
 */
public interface SuggestionDisplay {
	public String suggestionHtml(String[] args);
    
	public default String suggestionHtmlSubs(String[] args)
	{

		List<String> suggestList = new ArrayList<String>();
		String display = args[1];
		if(args.length<3)
		{
			return "";
		}
		String[] mapactions = args[2].split("\\Q$", -1);
		for (String a : mapactions) {
			String[] aproperties = a.split("\\Q-", -1);
			String type = aproperties[0];
			SuggestionDisplay instance=Provider.getInstance(SuggestionDisplay.class, type);
			aproperties[0]=display;
			if(instance!=null)
			suggestList.add(instance.suggestionHtml(aproperties));
		}
		return suggestList.stream().filter((v)->!Util.isNull(v)).collect(Collectors.joining(","));
	
	}
}
