package org.ydzy.bot.handler;
import java.io.IOException;
import java.nio.charset.Charset;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Map;
import java.util.Set;

import javax.sql.DataSource;

import org.eclipse.jetty.server.Request;
import org.ydzy.bot.BotAccess;
import org.ydzy.bot.BotInfo;
import org.ydzy.bot.BotUtil;
import org.ydzy.handler.BaseHandler;
import org.ydzy.rcs.db.XmlSqlGenerator;
import org.ydzy.util.SqlUtil;
import org.ydzy.util.StreamsUtil;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.inject.Inject;
import com.google.inject.name.Named;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.ydzy.util.Util;

/**
 * �й����š���ͨMAAP�ӿ�
 * 12��Chatbot����������Ϣ��״̬����
 * http://{notifyURL}/bot/deliveryNotification/{chatbotId}/status
 */
public  class StatusHandler extends BaseBotHandler {
	private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(StatusHandler.class);

	@Inject
	@Named("rcsDb")
	protected DataSource ds;
	Gson gson = new Gson();
	/**
	 * ���� http://{notifyURL}/deliveryNotification/{chatbotId}/status 
	 * Chatbot����������Ϣ��״̬����
	 */
	@Override
	public void handle(String target, Request baseRequest, HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException{
		baseRequest.setHandled(true);
		String uri = request.getRequestURI();
		if(uri.indexOf("deliveryNotification")<0) {
			//ִ���г����е�chatbot״̬
			if(request.getRequestURI().indexOf("isplist/")>=0) {
				this.listIsp(request, response);
				return;
			}else if(request.getRequestURI().indexOf("list/")>=0) {
				this.listChatbot(request, response);
				return;
			}
		}
		BotInfo bi = null;
		try {
			bi = verifyChatbot(request, response);
		}catch(VerifyError e) { 
			response.setStatus(HttpServletResponse.SC_FORBIDDEN);
			response.setContentType("application/json");
			JsonObject jo = new JsonObject();
			jo.addProperty("errorMsg", e.getMessage());
			// Write back response
			response.getWriter().println(jo.toString());
			log.debug("fetch chatbot error(" + e.getMessage() + "!");
			return;
		}
		String address=BaseHandler.getIpAddress(request);
		// Content-Type: text/xml; charset=utf-8
		String contentType = request.getContentType();
		if(contentType==null)contentType="application/json";
		String body = StreamsUtil.copyToString(request.getInputStream(), Charset.forName("UTF-8"));
		if(log.isDebugEnabled())log.debug(",receive {} from remoteAddr {}  ", body, address);
		String code = null,msg = null;
		if(contentType.indexOf("json")>0) {
			JsonElement je = JsonParser.parseString(body);
			if(je!=null && je.isJsonObject()) {
				JsonObject jo = je.getAsJsonObject();
				log.info("Message delive botid=" + bi.getChatbotIdenty() + " info " + jo.toString());
				if(ds!=null) {
					String now = LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME).replace('T', ' ');
					//UPDATE rcs_logs SET deliveryStatus='{deliveryStatus}', deliveryTime='{deliveryTime}' WHERE messageId='{messageId}'
					je = jo.get("deliveryInfoList");
					if(je!=null && je.isJsonArray()) {
						JsonArray ja = je.getAsJsonArray();
						for(int i=0;i<ja.size();i++) {
							je = ja.get(i);
							if(je!=null && je.isJsonObject()) {
								JsonObject tmpJo = je.getAsJsonObject();
								tmpJo.addProperty("deliveryTime", now);;
								
								String status = BotUtil.getElementAsString(tmpJo, "status");
								tmpJo.addProperty("deliveryStatus", status);
								
								/*
								 * sent����Ϣ�ѷ���  failed����Ϣ����ʧ�� delivered����Ϣ���ʹ� 
									displayed����Ϣ���Ķ�
									deliveredToNetwork����ת���ŷ���
									revokeOk����Ϣ���سɹ�
									revokeFail����Ϣ����ʧ��
								 */
								String tmpStatus = String.valueOf(status).toLowerCase();
								tmpJo.addProperty("action_status", tmpStatus.indexOf("sent")>=0||tmpStatus.indexOf("delivered")>=0
										||tmpStatus.indexOf("displayed")>=0||tmpStatus.indexOf("deliveredtonetwork")>=0?"1":"0");
								String sql = XmlSqlGenerator.getSqlByJson("setRecordLogsStatus", "", tmpJo);
								try {
									SqlUtil.updateRecords(ds, sql);
								} catch (SQLException e1) {
									log.error("Insert log error,%s", sql, e1);
								}
							}
						}
					}
				}
			}else {
				code = "2001";
				msg = "No deliveryInfo message found";
			}
		}else {
			code = "2002";
			msg = "Unknow contentType:" + contentType;
		}
		if(code==null) {
			code = "0";
			msg = "success";
		}
		String resBody = resBodyJson(code, msg, null);
		sendResponse(address, resBody, HttpServletResponse.SC_OK, request, response);
	}

	/*
{
    "deliveryInfoList": [
        {
            "messageId": "AC6A9C00-78C8-4BCC-9845-0F3BDCBE45EE",
            "status": "delivered",
            "dateTime": "2020-03-17T14:42:20.840+08:00",
            "destinationAddress": "sip:106500@botplatform.rcs.domain.cn",
            "senderAddress": "tel:+8617928222350"
        },
        {
            "messageId": "AC6A9C00-78C8-4BCC-9845-0F3BDCBE45EE",
            "status": "delivered",
            "dateTime": "2020-01-17T14:42:20.840+08:00",
            "destinationAddress": "sip:106500@botplatform.rcs.domain.cn",
            "senderAddress": "tel:+8617928222351"
        },
        {
            "messageId": "4566A9C00-5562-4BCC-9845-0F3BDCBE4FEF",
            "status": "failed",
            "errorCode": 1,
            "errorMessage": "terminal not supported RCS and smsSupported is false",
            "dateTime": "2020-01-17T14:42:20.840+08:00",
            "destinationAddress": "sip:106500@botplatform.rcs.domain.cn",
            "senderAddress": "tel:+8617928222343"
        }
    ]
}
	 */


	/**
	 * 	��ӡ��ǰbot״̬
	 * @param request
	 * @param response
	 * @throws IOException
	 * @throws ServletException
	 */
	public void listChatbot(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException{
		String[] fields = new String[] {"isp", "chatbotname", "spName", "useAi"};
		String address=BaseHandler.getIpAddress(request);
		Set<BotInfo> bots = manager.getAllChatBotInfo();
		JsonArray ja = new JsonArray();
		for(BotInfo bi:bots) {
			JsonObject jo = new JsonObject();
			jo.addProperty("id", bi.getChatbotId());
			jo.addProperty("chatbotid", bi.getChatbotIdenty());
			jo.addProperty("enable", bi.isEnable());
			jo.addProperty("active", !bi.isExpire());
			for(int i=0;i<fields.length;i++) {
				jo.addProperty(fields[i], BotUtil.getElementAsString(bi.getInfos(), fields[i]));
			}
			BotAccess ba = bi.getBotAccess();
			if(ba!=null) {
				jo.addProperty("BotAccess", ba.getClass().getName());
				jo.addProperty("authorize", ba.getAuthorize()==null?"":ba.getAuthorize().getClass().getName());
				jo.addProperty("verify", ba.getVerify()==null?"":ba.getVerify().getClass().getName());
				String url = BotUtil.mustache(ba.getUrlMessages(), ba, bi.getInfos());
				jo.addProperty("urlMessages", url);
			}
			ja.add(jo);
		}
		String resBody = ja.toString();
		sendResponse(address, resBody, HttpServletResponse.SC_OK, request, response);
	}
	

	/**
	 * 	��ӡ֧��isp
	 * @param request
	 * @param response
	 * @throws IOException
	 * @throws ServletException
	 */
	public void listIsp(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException{
		String address=BaseHandler.getIpAddress(request);
		Map<String, String> map = manager.getBotIspMap();
		String resBody = new Gson().toJsonTree(map).toString();;
		sendResponse(address, resBody, HttpServletResponse.SC_OK, request, response);
	}
}