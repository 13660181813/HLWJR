package org.ydzy.bot;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.Queue;
import java.util.Set;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.ydzy.bot.model.BotInfoOptions;
import org.ydzy.bot.model.MenuBase;
import org.ydzy.bot.model.MenuGroup;
import org.ydzy.bot.model.MenuItem;
import org.ydzy.bot.model.MenuItemAction;
import org.ydzy.bot.model.MenuItemReply;
import org.ydzy.rcs.SuggestionDisplay;
import org.ydzy.rcs.db.XmlSqlGenerator;
import org.ydzy.rcs.impl.UrlAction;
import org.ydzy.rcs.media.UploadFileEntity;
import org.ydzy.util.SqlUtil;
import org.ydzy.util.Util;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.inject.Inject;
import com.google.inject.Key;
import com.google.inject.name.Named;
import com.google.inject.name.Names;

public class DbOperator {

	static final Logger log = LoggerFactory.getLogger(DbOperator.class);
	
	/** ���ݿ����� */
	@Inject
	@Named("rcsDb.DbType")
	private String dbTypestr;
	public String getDbTypestr() {
		return dbTypestr;
	}

	/** ���ݿ�����*/
	@Inject
	@Named("rcsDb")
	private DataSource dataSource;
	public DataSource getDataSource() {
		return dataSource;
	}

	Gson gson = new Gson();
	public BotInfoOptions getBotInfoOptionals(BotInfo botInfo) {
		BotInfoOptions options;
		options = gson.fromJson(botInfo.getInfos(), BotInfoOptions.class);
		return options;
	}
	
	/**
	 * ��ȡMenu
	 * @param botInfo
	 * @return
	 */
	public MenuGroup loadMenus(BotInfo botInfo,String username) {
		String sql=XmlSqlGenerator.getSql("queryChatbotMenus").exeSql;
		if(!Util.isNull(username))
			sql=XmlSqlGenerator.getSql("queryChatbotMenusByusername").exeSql;
		//SELECT menuid,parentid,suggestionid,suggestiontype,suggestions FROM v_rcs_bot_menus WHERE chatbotid=? ORDER BY menurank,menuid
		try(Connection con = getDataSource().getConnection();
				PreparedStatement prepare = con.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY)){
			prepare.setObject(1, botInfo.getChatbotId());
			if(!Util.isNull(username))
			{
				prepare.setObject(2, username);	
			}
			ResultSet rs = prepare.executeQuery();
			List<MenuBase> menus = new ArrayList<>();
			while(rs.next()){
				int menuid=rs.getInt("menuid");
				int parentid=rs.getInt("parentid");
				String mType=rs.getString("suggestiontype");
				String menuTextType = rs.getString("menutexttype");
				if("menu".equals(mType) || mType==null || mType.length()==0) {
					String displayText = rs.getString("suggestions");
					MenuGroup menu = new MenuGroup(menuid, parentid, displayText, menuTextType);
					menus.add(menu);
				}else {
					String suggestions = rs.getString("suggestions");
					String[] s1properties = suggestions.split("\\Q|", -1);
					JsonElement json;
					try {
						if(!Util.isNull(mType))
						{
							SuggestionDisplay instance = botInfo.manager.injector.getInstance(Key.get(SuggestionDisplay.class, Names.named(mType)));
							if(instance instanceof UrlAction){
								if(s1properties.length>=5)
								{
									String params=s1properties[5];
									s1properties[5]=params;
									
								}
							}
							String text = instance.suggestionHtml(s1properties);
							json = JsonParser.parseString(text);
							Optional<JsonElement> o = !json.isJsonObject()?null:json.getAsJsonObject().entrySet().stream().map(k ->k.getValue()).findFirst();
							if(!o.isEmpty()) {
								json = o.get();
								MenuItem menu = "reply".equalsIgnoreCase(mType)?new MenuItemReply(menuid, parentid,json):new MenuItemAction(menuid, parentid,json);
								menu.suggestiontype = mType;
								menu.suggestionid = rs.getInt("suggestionid");
								menu.suggestions = suggestions;
								menu.menutexttype = menuTextType;
								menus.add(menu);
							}else {
								throw new Exception("None json object get");
							}
						}
					} catch (Exception e) {
						log.warn("Error menu skiped, chatbotid:" + botInfo.chatbotId + " menuid:" + menuid + "(" + e.toString() + ")");
					}
				}
			}
			MenuGroup root = new MenuGroup(-1,-1, "root");
			Queue<MenuGroup> workMenus = new LinkedList<>();
			workMenus.offer(root);
			
			Set<Integer> worked = new HashSet<>();
			MenuGroup m;
			while((m=workMenus.poll())!=null) {
				for(MenuBase menu: menus) {
					if(menu.parentid == m.menuid) {
						m.getMenu().getEntries().add(menu);
						if(menu instanceof MenuGroup && !worked.contains(menu.menuid)) {
							workMenus.add((MenuGroup)menu);
						}
					}
				}
			}
			return root;
		}catch(Exception e) {
			log.error("sql execute error {} ",sql);
		}
		return null;
	}

	private boolean scanChatbotMenus(JsonObject jo, List<MenuBase> list, MenuBase parent) {
		JsonElement e = jo.get("menu");
		JsonObject o = e.isJsonObject()?e.getAsJsonObject():null;
		e = o.get("entries");
		if(e.isJsonArray()) {
			int baseMenuId = parent==null?1:(parent.menuid*100+1);
			int parentid = parent==null?-1:parent.menuid;
			JsonArray ja = e.getAsJsonArray();
			for(int i=0;i<ja.size();i++) {
				e = ja.get(i);
				if(e.isJsonObject()) {
					o = e.getAsJsonObject();
					String suggestiontype = BotUtil.getElementAsString(o, "suggestiontype");
					if(suggestiontype==null || suggestiontype.isEmpty() || "menu".equals(suggestiontype)) {
						e = o.get("menu");
						String menutexttype = Util.getElementAsString(o, "menutexttype");
						String text = e==null||!e.isJsonObject()?"Unknown": BotUtil.getElementAsString(e.getAsJsonObject(), "displayText");
						MenuGroup menu = new MenuGroup(baseMenuId+i, parentid, text, menutexttype);
						list.add(menu);
						scanChatbotMenus(o, list, menu);
					}else {
						MenuItem menu = new MenuItem(baseMenuId+i, parentid);
						menu.suggestiontype = suggestiontype;
						Number suggid = BotUtil.getElementAsNumber(o, "suggestionid");
						menu.suggestionid = suggid==null?0:suggid.intValue();
						menu.menutexttype = Util.getElementAsString(o, "menutexttype");
						list.add(menu);
					}
				}
			}
		}
		return true;
	}
	public boolean saveMenus(JsonObject jo, BotInfo botInfo,String user) {
		List<MenuBase> list = new ArrayList<>();
		scanChatbotMenus(jo, list, null);
		String sql = null;
		try(Connection con = getDataSource().getConnection()){
			try {
				con.setAutoCommit(false);
			}catch(Throwable ignore) {}
			String username = user==null?"":user.trim();
			sql=XmlSqlGenerator.getSql("deleteChatbotMenusByusername").exeSql;
			try(CallableStatement prepare = con.prepareCall(sql)){
				prepare.setObject(1, botInfo.getChatbotId());
				prepare.setObject(2, username);
				int c = prepare.executeUpdate();
				log.info("Delete chatbot("  + botInfo.getChatbotId() + ") menus count=" + c);
			}
//			int menutexttype = Util.getElementAsString(jo, "menutexttype")
			if(list.size()>0) {
				sql=XmlSqlGenerator.getSql("addChatbotMenusByusername").exeSql;
				//INSERT INTO rcs_bot_menus(chatbotid,menuid,parentid,suggestionid,suggestiontype,menutext,menurank) VALUES(?,?,?,?,?,?,?)
				try(CallableStatement prepare = con.prepareCall(sql)){
					for(MenuBase menu:list) {
						prepare.setObject(1, botInfo.getChatbotId());
						prepare.setInt(2, menu.menuid);
						prepare.setInt(3, menu.parentid);
						prepare.setInt(4, menu instanceof MenuItem?((MenuItem)menu).suggestionid:0);
						prepare.setString(5, menu instanceof MenuItem?((MenuItem)menu).suggestiontype:"menu");
						prepare.setString(6, menu instanceof MenuGroup?((MenuGroup)menu).getMenu().getDisplayText():"");
						prepare.setInt(7, menu.menuid);
						prepare.setString(8, menu instanceof MenuGroup?Util.isNull(((MenuGroup)menu).menutexttype)? "1" : ((MenuGroup)menu).menutexttype:"1");
						prepare.setString(9, username);

						prepare.addBatch();
					}
					int[] rcs = prepare.executeBatch();
					int c = Arrays.stream(rcs).sum();
					log.info("Insert chatbot("  + botInfo.getChatbotId() + ") menus count=" + c);
				}
				
			}
			try {
				con.setAutoCommit(false);
			}catch(Throwable ignore) {}
			return true;
		}catch(Exception e) {
			log.error("sql execute error {} ",sql);
		}
		return false;
	}

	public boolean saveMedia(BotInfo botInfo, UploadFileEntity media) {
		String sql = null;
		try(Connection con = getDataSource().getConnection()){
			if(media.getMediaID()==null) {
				sql=XmlSqlGenerator.getSql("insertUploadMedias").exeSql;
				if(sql==null)sql=
						"insert into rcs_medias(mediaUrl,status,mediaContentType,thumbnailUrl,contentLocalPath,interviewId,tid,thumbnailContentType,thumbnailLocalPath,filename,expriedTime,authStatus,createdDate,chatbotid,mediaSize) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
				Object[] insertParams = new Object[15];
				insertParams[0] = media.getMediaUrl();
				insertParams[1] = media.getStatus();
				insertParams[2] = media.getMediacontentType();
				insertParams[3] = media.getThumbnailUrl();
				insertParams[4] = media.getContentLocalPath();
				insertParams[5] = null;
				insertParams[6] = media.getTid();
				insertParams[7] = media.getThumbnailContentType();
				insertParams[8] = media.getThumbnailLocalPath();
				insertParams[9] = media.getFileName();
				insertParams[10] = new java.sql.Timestamp(media.getExpiredTime());
				insertParams[11] = 0;
				insertParams[12] = new java.util.Date();
				insertParams[13] = media.getChatbotid();
				insertParams[14] = media.getFileSize();
//				long id = SqlUtil.insert(getDataSource(), sql, insertParams);
//				media.setMediaID(String.valueOf(id));
				if(SqlUtil.updateRecords(getDataSource(), sql, insertParams)) {
					loadMedia(media);
					return true;
				}else {
					return false;
				}
			}else{
				sql=XmlSqlGenerator.getSql("updateUploadMedias").exeSql;
				if(sql==null)sql=
				"update rcs_medias set mediaUrl=?,status=?,mediaContentType=?,thumbnailUrl=?,interviewId=?,tid=?,thumbnailContentType=?,expriedTime=?,authStatus=?,mediaSize=?, thumbnailSize=?,updateDate=?,authDate=?,errorCode=?,errorDesc=?,chatbotMediaUrl=?,chatbotThumbnailUrl=? where mediaID=?";
				Object[] insertParams = new Object[18];
				insertParams[0] = media.getMediaUrl();
				insertParams[1] = media.getStatus();
				insertParams[2] = media.getMediacontentType();
				insertParams[3] = media.getThumbnailUrl();
				insertParams[4] = media.getInterviewId();
				insertParams[5] = media.getTid();
				insertParams[6] = media.getThumbnailContentType();
				insertParams[7] = new java.sql.Timestamp(media.getExpiredTime());
				insertParams[8] = media.getAuthStatus();
				insertParams[9] = media.getFileSize();
				insertParams[10] = media.getThumbFileSize();
				insertParams[11] = new java.util.Date();
				insertParams[12] = new java.util.Date();
				insertParams[13] = media.getErrorCode();
				insertParams[14] = media.getErrorDesc();
				insertParams[15] = media.getChatbotMediaUrl();
				insertParams[16] = media.getChatbotThumbnailUrl();
				insertParams[17] = media.getMediaID();
				return SqlUtil.updateRecords(getDataSource(), sql, insertParams);
			}
		}catch(Exception e) {
			log.error("sql execute error {} ",sql);
		}
		return false;
	}
	
	/**
	 * ����ý���ϴ�ʧ��
	 * 
	 * @param botInfo
	 * @param media
	 * @return
	 */
	public boolean saveMediaUploadFailed(BotInfo botInfo, UploadFileEntity media) {
		if(media==null || media.getMediaID()==null || media.getMediaID().isEmpty())return false;
		media.setAuthStatus("0");
		media.setStatus("2");
		this.saveMedia(botInfo, media);
		return false;
	}
	
	/**
	 * �����ݿ����ý����Ϣ
	 * 
	 * @param media mediaID�����Ѿ����ú�
	 * @return
	 */
	public boolean loadMedia(UploadFileEntity media) {
		String sql;
		Object[] paras;
		if(media.getMediaID()!=null && !media.getMediaID().isEmpty()) {
			paras = new Object[]{media.getMediaID()};
			sql=XmlSqlGenerator.getSqlstr("queryMediaInfoByMediaID");
			if(Util.isNull(sql))sql=
					"select * from rcs_medias WHERE mediaID=?";
		}else if(media.getTid()!=null && !media.getTid().isEmpty()){
			paras = new Object[]{media.getTid()};
			sql=XmlSqlGenerator.getSqlstr("queryMediaInfoByTid");
			if(Util.isNull(sql))sql=
					"select * from rcs_medias WHERE tid=?";
		}else if(media.getMediaUrl()!=null && !media.getMediaUrl().isEmpty()){
			paras = new Object[]{media.getMediaUrl(), media.getMediaUrl()};
			sql=XmlSqlGenerator.getSqlstr("queryMediaInfoByUrl");
			if(Util.isNull(sql))sql=
					"select * from rcs_medias WHERE chatbotMediaUrl=? or chatbotThumbnailUrl=?";
		}else {
			throw new RuntimeException("error load media info, mediaID is empty!!");
		}
		//"select mediaID,chatbotid,status,mediaUrl,mediaContentType,thumbnailUrl,thumbnailContentType, expriedTime,authStatus,createdDate from rcs_medias WHERE mediaID=?";
		try(Connection con = getDataSource().getConnection();
				PreparedStatement prepare = con.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY)){
			for(int i=1;i<=paras.length;i++) prepare.setObject(i, paras[i-1]);
			prepare.execute();
			ResultSet rs = prepare.getResultSet();
			if(rs.next()) {
				Timestamp time = rs.getTimestamp("createdDate");
				media.setMediaID(rs.getObject("mediaID").toString());
				media.setTid(rs.getString("tid"));
				media.setStatus(rs.getString("status"));
				media.setMediaUrl(rs.getString("mediaUrl"));
				media.setMediacontentType(rs.getString("mediaContentType"));
				media.setThumbnailUrl(rs.getString("thumbnailUrl"));
				media.setThumbnailContentType(rs.getString("thumbnailContentType"));
				media.setExpiredTime((time=rs.getTimestamp("expriedTime"))==null?0:time.getTime());
				media.setAuthStatus(rs.getString("authStatus"));
				media.setCreatedDate((time=rs.getTimestamp("createdDate"))==null?0:time.getTime());
				media.setChatbotid(rs.getString("chatbotid"));
				media.setContentLocalPath(rs.getString("contentLocalPath"));
				media.setThumbnailLocalPath(rs.getString("thumbnailLocalPath"));
				media.setAuthDate((time=rs.getTimestamp("authDate"))==null?0:time.getTime());
				media.setErrorCode(rs.getString("errorCode"));
				media.setErrorDesc(rs.getString("errorDesc"));
				media.setFileSize(rs.getInt("mediaSize"));
				media.setThumbFileSize(rs.getInt("thumbnailSize"));
				media.setFileName(rs.getString("fileName"));
				media.setChatbotMediaUrl(rs.getString("chatbotMediaUrl"));
				media.setChatbotThumbnailUrl(rs.getString("chatbotThumbnailUrl"));
				
				rs.close();
				return true;
			}
		}catch(Exception e) {
			log.error("sql execute error {} ",sql);
		}
		return false;
	}
	
	
}
