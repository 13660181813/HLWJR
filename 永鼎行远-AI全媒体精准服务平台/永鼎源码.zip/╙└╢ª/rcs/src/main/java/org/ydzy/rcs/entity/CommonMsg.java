package org.ydzy.rcs.entity;

import javax.xml.bind.annotation.XmlRootElement;

import org.ydzy.util.XmlUtils;


@XmlRootElement(name="outboundMessageRequest" )
public class CommonMsg {

	/**
	 * �û�URI list�� tel��ʽ
	 * ����ΪString[] �� String
	 */
	//@javax.xml.bind.annotation.XmlElement(namespace = "")
	private Object destinationAddress;
	/**
	 * ��Ϊ��ָ,ȡ��һ��
	 * @return
	 */
	public String getDestinationAddress() {
		if(destinationAddress==null)return null;
		if(destinationAddress instanceof String[]) {
			String[] tmps = (String[])destinationAddress;
			if(tmps.length>0) {
				return tmps[0];
			}else {
				return null;
			}
		}
		return destinationAddress.toString();
	}
	public void setDestinationAddress(Object destionationAddress) {
		this.destinationAddress = destionationAddress;
	}
	public void setDestinationAddress(String destionationAddress) {
		this.destinationAddress = destionationAddress;
	}

	/**
	 * ��ȷָ���ռ��˶�Ӧ�Ķ�����
	 */
	public transient String destinationEndPoint = null;
	
	/**
	 * ���ͷ���ַFrom��Ⱥ��ʱ��дChatbot��URI���㲥ʱ��дChatbot��URI���ݲ��ṩ��
	 */
	public String senderAddress;


	public String senderName;
	
	public static class DeliveryInfo{
		/**
		 * ���ͻ�ִ��Ϣ�ķ��ͷ���ַ��ԭ��Ϣ��Ŀ�ķ���ַ��
		 */
		public String address;
		/**
		 * 
		 */
		public String deliveryStatus;
	}


	
	@XmlRootElement
	public static  class serviceCapability {
		/**
		 * ֵΪ ChatbotSA��
		 */
		public String capabilityId;
		/**
		 * �汾�ţ���+g.gsma.rcs.botversion=\"#=1\"
		 */
		public String version;
	}

	public static void main(String[] args) {
		CommonMsg bean=new CommonMsg();
		String xml=		XmlUtils.toXml(CommonMsg.class, bean,true);
		System.out.println(xml);
		
		CommonMsg msg=XmlUtils.unmarshal(xml, CommonMsg.class);
		System.out.println(msg);
	}

}
