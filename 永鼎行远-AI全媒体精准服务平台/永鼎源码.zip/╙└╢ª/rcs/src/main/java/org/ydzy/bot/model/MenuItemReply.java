package org.ydzy.bot.model;

import com.google.gson.JsonElement;

public class MenuItemReply extends MenuItem{
	public MenuItemReply(int menuid, int parentid, JsonElement json) {
		super(menuid, parentid);
		this.reply = json;
	}

	public MenuItemReply(int menuid) {
		super(menuid);
	}

	/** reply */
	public JsonElement reply;
}
