package org.ydzy.util;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.beanutils.BeanUtils;
import org.ydzy.handler.BaseRcsContext;
import org.ydzy.rcs.entity.ReceiveEntity;
import org.ydzy.rcs.module.LoadProperties;

public class ParamUtils {
	static String regexParam = "\\{([^\\{\\}:]*)\\}";
	static Pattern regexPattern = Pattern.compile(regexParam);

	public static Set<String> findParams(String msg) {
		if(Util.isNull(msg))
			return null;
		Set<String> params = new HashSet<String>();
		Matcher match = regexPattern.matcher(msg);
		while (match.find()) {
			String pname =match.group(1);
			if(!Util.isNull(pname))
			params.add(pname.trim());
		}
		return params;
	}
	public static Map<String, String> initParams(Set<String> findParams, ReceiveEntity requestObject,
			BaseRcsContext context) {
		if (findParams == null)
			return null;
		Map<String, String> values = new HashMap<String, String>();
		for (String p1 : findParams) {
			String v =convertV(requestObject,context,p1);
			values.put(p1, v);
		}
		return values;
	}
	public static  String convertV(ReceiveEntity requestObject,
			BaseRcsContext context,String p1)
	{
		String v = "";
			try {
				if (p1.startsWith(replace_null_pattern)) {
					p1 = p1.substring(replace_null_pattern.length());
				}
				String tmp = p1.replaceAll("session.", "");
				v = Util.toString(BeanUtils.getNestedProperty(context.getSession(requestObject.getMdn(), requestObject.getChatBotId()), tmp));
			} catch (Exception e) {
			}
			if (Util.isNull(v)) {
				try {
					v = BeanUtils.getNestedProperty(requestObject, p1);
				} catch (Exception e) {
				}
			}
		if ((Util.isNull(v))) {
			try {
				v = BeanUtils.getNestedProperty(requestObject, "answersObject." + p1);
			} catch (Exception e) {
			}
		}
		if ((Util.isNull(v))) {
			v = Util.toString(LoadProperties.systemProperties.getProperty(p1));
		}
		return v;

	}

	public static String replaceParam(String content, ReceiveEntity requestObject, BaseRcsContext context) {
		String tmpsuggestion = content;
		Set<String> tmpsuggestionset = ParamUtils.findParams(tmpsuggestion);

		Map<String, String> valuessug = ParamUtils.initParams(tmpsuggestionset, requestObject, context);
		tmpsuggestion = formatVues(tmpsuggestion, valuessug);
		return tmpsuggestion;
	}

	public static final String replace_pattern = "nvl";
	public static final String replace_null_pattern = "nullVal$";

	public static String formatVues(String msg, Map<String, String> paramObject) {
		String[] newMsg = {msg};
		if (paramObject != null) {
			paramObject.forEach((k, v) -> {
				if (!Util.isNull(v) || k.startsWith(replace_pattern) || k.startsWith(replace_null_pattern))
					newMsg[0] = newMsg[0].replace("{" + k + "}", v);
			});
		}
		return newMsg[0];
	}

	public static String formatValues(String msg, Map<String, String> paramObject) {
		if (paramObject != null) {
			for (Map.Entry<String, String> entry : paramObject.entrySet()) {
				String value = entry.getValue();
				value = value == null ? "" : value;
				msg = msg.replace("{" + entry.getKey() + "}", value);
			}
		}
		return msg;
	}
}
