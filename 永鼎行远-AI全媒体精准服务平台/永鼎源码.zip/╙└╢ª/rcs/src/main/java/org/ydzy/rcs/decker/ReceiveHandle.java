package org.ydzy.rcs.decker;

import org.ydzy.rcs.BodyTransform;
import org.ydzy.rcs.entity.ReceiveEntity;

public interface ReceiveHandle {
	/**
	 * @param receiveEntity
	 * @return װ���������
	 */
	public ReceiveEntity  requestHandler(BodyTransform transform,ReceiveEntity receiveEntity);
}
