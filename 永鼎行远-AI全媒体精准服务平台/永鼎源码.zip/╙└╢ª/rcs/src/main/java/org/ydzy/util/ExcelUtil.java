package org.ydzy.util;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * @author lirui
 * @Date 2021/10/25 10:39 ����
 */
public class ExcelUtil {
    public static void main(String[] args) {
        String filePath = "/Users/lirui/Downloads/pub_temp.xlsx";
        List<Map<String, String>> list = getExcelData(filePath);
        if (list != null)
            //��������������list
            for (Map<String, String> map : list) {
                for (Map.Entry<String, String> entry : map.entrySet()) {
                    System.out.print(entry.getKey() + ":" + entry.getValue() + ",");
                }
                System.out.println();
            }
    }

    public static List<Map<String, String>> getExcelData(String filePath) {
        return getExcelData(filePath, 0);
    }

    public static List<Map<String, String>> getExcelData(String filePath, int firstRowNum) {
        Workbook wb;
        Sheet sheet;
        Row row;
        List<Map<String, String>> list = null;
        String cellData;
        wb = readExcel(filePath);
        if (wb != null) {
            //������ű�������
            list = new ArrayList<>();
            //��ȡ��һ��sheet
            sheet = wb.getSheetAt(0);
            //��ȡ�������
            int rownum = sheet.getPhysicalNumberOfRows();
            //��ȡ��һ��
            row = sheet.getRow(firstRowNum);
            //��ȡ�������
            int colnum = row.getPhysicalNumberOfCells();
            List<String> columns = getTitle(row, colnum);
            boolean isLastRow;
            for (int i = 1; i < rownum; i++) {
                isLastRow = true;
                Map<String, String> map = new LinkedHashMap<>();
                row = sheet.getRow(i);
                if (row != null) {
                    for (int j = 0; j < colnum; j++) {
                        Cell cell = row.getCell(j);
                        if (cell == null) {
                            map.put(columns.get(j), "");
                            continue;
                        }
                        cell.setCellType(CellType.STRING);
                        cellData = (String) getCellFormatValue(cell);
                        map.put(columns.get(j), cellData);
                        if (!Util.isNull(cellData))
                            isLastRow = false;
                    }
                } else {
                    break;
                }
                if (isLastRow) break;
                list.add(map);
            }
        }
        return list;
    }

    public static List<String> getTitle(Row firstRow, int maxColSize) {
        List<String> titles = new ArrayList<>();
        for (int c = 0; c < maxColSize; c++) {
//            String cellData = (String) getCellFormatValue(firstRow.getCell(c));
            String cellData = firstRow.getCell(c).getRichStringCellValue().getString();
            titles.add(cellData);
        }
        return titles;
    }

    //��ȡexcel
    public static Workbook readExcel(String filePath) {
        if (filePath == null) {
            return null;
        }
        String extString = filePath.substring(filePath.lastIndexOf("."));
        // �˴����ر�����Ӱ��ɾ���ļ�
        try (InputStream is = new FileInputStream(filePath)){
            if (".xls".equals(extString)) {
                return new HSSFWorkbook(is);
            } else if (".xlsx".equals(extString)) {
                return new XSSFWorkbook(is);
            } else {
                return null;
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static Object getCellFormatValue(Cell cell) {
        Object cellValue;
        if (cell != null) {
            //�ж�cell����
            switch (cell.getCellType()) {
                case NUMERIC -> {
                    cellValue = String.valueOf(cell.getNumericCellValue());
                }
                case FORMULA -> {
                    //�ж�cell�Ƿ�Ϊ���ڸ�ʽ
                    if (DateUtil.isCellDateFormatted(cell)) {
                        //ת��Ϊ���ڸ�ʽYYYY-mm-dd
                        cellValue = cell.getDateCellValue();
                    } else {
                        //����
                        cellValue = String.valueOf(cell.getNumericCellValue());
                    }
                }
                case STRING -> {
                    cellValue = cell.getRichStringCellValue().getString();
                }
                default -> cellValue = "";
            }
        } else {
            cellValue = "";
        }
        return cellValue;
    }
}
