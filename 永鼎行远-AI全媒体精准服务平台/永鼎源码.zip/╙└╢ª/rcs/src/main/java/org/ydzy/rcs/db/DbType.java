package org.ydzy.rcs.db;


import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.ydzy.util.Util;

public enum DbType {

	/**
	 * ���ݿ����ͣ�hbase
	 */
	Hbase("hbase", "nosql"),
	/**
	 * ���ݿ����ͣ�hive
	 */
	Hive("hive", "sql"),
	/**
	 * ���ݿ����ͣ�mysql
	 */
	Mysql("mysql", "sql"),
	/**
	 * ���ݿ����ͣ�oracle
	 */
	Oracle("Oracle", "sql"),
	/**
	 * ���ݿ����ͣ�phoenix
	 */
	phoenix("phoenix", "sql");
	private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(DbType.class);
	public String desc;
	public String sqlType;

	DbType(String desc, String sqlType) {
		this.desc = desc;
		this.sqlType = sqlType;
	}

	public static DbType valueof(String symbol) {
		if (Util.isNull(symbol)) {
			log.warn("db type is null, use default db type: {}", Mysql.desc);
			return Mysql;
		}
		List<DbType> str = Arrays.stream(values()).filter((s) -> symbol.equalsIgnoreCase(s.desc))
				.collect(Collectors.toList());
		if (str != null && str.size() > 0)
			return str.get(0);
		else {
			String arr[] = symbol.split("-");
			if (arr.length > 1)
				return valueof(arr[1]);
			log.debug("Undefined db type {}, use default db type: {}", symbol, Oracle.desc);
			return Mysql;
		}

	}

}
