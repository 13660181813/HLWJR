package org.ydzy.rcs.impl;

import org.ydzy.rcs.SuggestionDisplay;
import org.ydzy.rcs.annotation.Description;
import org.ydzy.util.StringUtils;

import com.google.inject.Singleton;

@Singleton
@Description("composeTextMessage")
public class ComposeTextMessage implements SuggestionDisplay{
	String composeAction = "{\r\n" 
			+ "	  \"action\":\r\n" 
			+ "		{\r\n" 
			+ "			\"displayText\":\"%s\",\r\n"
			+ "			\"composeAction\":\r\n" 
			+ "			{\r\n" 
			+ "				\"composeTextMessage\":{\r\n"
			+ "					\"phoneNumber\":\"%s\",\r\n" 
			+ "					\"text\":\"%s\"\r\n" 
			+ "				}\r\n" 
			+ "			}\r\n" 
			+ "		}\r\n" 
			+ "}\r\n";
	@Override
	public String suggestionHtml(String[] args) {
		int length=args.length;
		return 
				StringUtils.format(composeAction, length<=0?"":args[0], length<=1?"":args[1], length<=2?"":args[2]);
	}

}
