package org.ydzy.rcs.module;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.nio.file.Files;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Properties;
import java.util.regex.Pattern;

import org.eclipse.jetty.util.resource.Resource;
import org.ydzy.rcs.annotation.Description;
import org.ydzy.util.Util;

import com.google.inject.Binder;
import com.google.inject.Module;
import com.google.inject.name.Names;

@Description("SystemPropLoad")
public class LoadProperties implements Module {

	Map<String, String> publicValues = new LinkedHashMap<>();

	@Override
	public void configure(Binder binder) {
		loadResource("base.properties", binder);
		if (systemProperties == null)
			loadResource("system.properties", binder);
		Resource resource=null;
		try {
			 resource = Resource.newSystemResource("base.properties");
		} catch (IOException e) {
			e.printStackTrace();
		}
		String subPropertiesFileRegex = systemProperties.getProperty("subPropertiesFileRegex");
		if (Util.isNull(subPropertiesFileRegex))
			return;
		try {
			String	resourcePath = resource.getFile().getParent();
			Pattern pattern = Pattern.compile(subPropertiesFileRegex);
			File file = new File(resourcePath);
			for (File sfile : file.listFiles()) {
				String filename = sfile.getName();
				if (pattern.matcher(filename).find())
					loadResource(filename, binder);
			}
			binder.bind(Properties.class).annotatedWith(Names.named("SystemProp")).toInstance(systemProperties);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void loadResource(String resourceName, Binder binder) {
		try {
			Resource resource = Resource.newSystemResource(resourceName);
			if (resource.exists()) {
				OrderLoadProperties applicationProp = new OrderLoadProperties();
				applicationProp.load(Files.newInputStream(resource.getFile().toPath()));
//				systemProperties = applicationProp;
				if (systemProperties == null)
					systemProperties = applicationProp;
				else
					systemProperties.putAll(applicationProp);
				Map<String, String> envs = new LinkedHashMap<String, String>();
				applicationProp.keySet().forEach(k -> {
					String kstring = Util.toString(k);
					String vstring = applicationProp.getProperty(Util.toString(k));
					if (kstring.contains("publicenv.")) {
						String[] kstringv = kstring.split("\\Q.");
						publicValues.put(kstringv[kstringv.length - 1], vstring);
						binder.bindConstant().annotatedWith(Names.named(kstringv[kstringv.length - 1])).to(vstring);
					} else {
						envs.put(kstring, vstring);
					}
				});
				envs.forEach((k, v) -> {
					String cv = replaceEnv(k, v, publicValues);
					binder.bindConstant().annotatedWith(Names.named(k)).to(cv);
					systemProperties.put(k, cv);
				});
				//binder.bind(Properties.class).annotatedWith(Names.named("SystemProp")).toInstance(applicationProp);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private String replaceEnv(String key, String value, Map<String, String> publicValues) {
		if (publicValues != null && publicValues.size() > 0) {
			for (Map.Entry<String, String> o : publicValues.entrySet()) {
				if (value.indexOf(o.getKey()) > -1) {
					value=value.replace("{"+o.getKey()+"}", o.getValue());
				}
			}
			return value;
		}else
			return value;
	}
	public static Properties systemProperties;

}
