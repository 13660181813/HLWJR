package org.ydzy.rcs.decker;

import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Map;

import org.ydzy.handler.RcsSession;
import org.ydzy.rcs.BodyTransform;
import org.ydzy.rcs.annotation.Description;
import org.ydzy.thirdparty.KfAiBehavior;
import org.ydzy.thirdparty.MessageDispatcher;
import org.ydzy.thirdparty.gz110.Gz110ActionBehavior;
import org.ydzy.thirdparty.gz110.entity.InstantBean;
import org.ydzy.thirdparty.gz110.entity.OrdersInfo;
import org.ydzy.thirdparty.util.MsgUtils;
import org.ydzy.util.Util;

import com.google.gson.JsonElement;
import com.google.inject.Inject;
import com.google.inject.Singleton;

@Singleton
@Description(value = "thirdpartchatbot")
public class CallOtherAi implements DeckerRobot {
	static Map<String, String> healthcode = new HashMap<String, String>() {
		{
			put("red", "�¹ڷ���ȷ���߻������ƻ���");
			put("orange", "�¹ڷ������нӴ���");
			put("yellow", "��14����ȥ���з�������");
			put("green", "����");
		}
	};

	// �����г̿�����
	static enum ORDERS {
		SENDTC2POLICE("YDZYSYSTEM_sendtc2police");

		private String command;

		public String getCommand() {
			return command;
		}

		ORDERS(String command) {
			this.command = command;
		}

		public static ORDERS valueOfByCommand(String command) {
			ORDERS[] orders = ORDERS.values();
			for (ORDERS s : orders) {
				if (s.getCommand().equals(command))
					return s;
			}
			return null;
		}
	}

	@Inject
	MessageDispatcher msgDistr;

	@Inject
	KfAiBehavior aibehavior;
	@Inject
	protected MsgUtils msgUtil;
	@Inject
	Gz110ActionBehavior gzgzBehavior;

	@Override
	public JsonElement doTransform(BodyTransform transform, JsonElement efind) {

		String mdn = transform.receiveEntity.getMdn();
		String content = transform.receiveEntity.getContent();
		String ks = Util.toString(transform.receiveEntity.getAnswersObject().get("keywordsearch"));
		String reqKeyWords = transform.receiveEntity.getContent();
		;
		if ("1".equals(ks) || reqKeyWords.startsWith("#local#") || reqKeyWords.startsWith(DeckerRobot.ORDERS.LOCALKEYWORDS.getCommand()) || reqKeyWords.equals("ȷ��֪ͨ")) {
			reqKeyWords = reqKeyWords.replace("#local#", "");
//			if(reqKeyWords.equals("GZ110JQJD"))
//				reqKeyWords = "�������";
			String userName = Util.toString(transform.receiveEntity.getAnswersObject().get("userName"));
			efind = transform.context.getConfig().getKeyWordsLikeFilterByRole(transform.receiveEntity.getChatBotId(),
					reqKeyWords, userName);
			if (efind == null)
				efind = transform.context.getConfig().getDefaultElement(transform.receiveEntity.getChatBotId(),
						"��ѯ�޼�¼|���޿���֪ʶ��ƥ��||||||", "");
			transform.receiveEntity.getAnswersObject().remove("userName");
			transform.receiveEntity.sendTo = mdn;
			transform.receiveEntity.getAnswersObject().put("boxId", "system");
			// boxIdΪsystem nickΪ������
			transform.receiveEntity.getAnswersObject().put("nick", "���ܿͷ�");
//				send.destinationAddress=message.senderAddress;
			transform.receiveEntity.getAnswersObject().put("type", "accept");
			return efind;
		} else {
			InstantBean bean = msgDistr.InstantBean(mdn, transform.receiveEntity.getChatBotId());
//			OrdersInfo info = msgUtil.getOrdersInfo(transform.receiveEntity.getMdn(), true, bean,
//					transform.receiveEntity.sendTo, transform.receiveEntity.getChatBotId());
			OrdersInfo info =msgUtil.getOrdersInfo(transform.receiveEntity,bean);
//			String driving = Util.toString(transform.receiveEntity.getAnswersObject().get("driving"));
			// to
			String to = transform.receiveEntity.sendTo;
			String sid = Util.toString(transform.receiveEntity.getAnswersObject().get("sid"));
//		RcsSession  rcsSession=callPolice.getContextProvidor().newBaseRcsContext().getSession(sid);
//		if(bean!=null  && ("staffService".equals(content)||!Util.isNull(to)))
//		{
//			bean.status=1;
//		}
			// TODO ADD ORDERID
			InstantBean targetbean = msgDistr.InstantBean(to, transform.receiveEntity.getChatBotId());
			String username = Util.toString(transform.receiveEntity.getAnswersObject().get("userName"));
//			if(info!=null&&info.status==2&&"YDZYSYSTEM_staffService".equals(content)) {
////			if((bean.target!=null||!Util.isNull(to))&&!"reopen".equals(content)||"YDZYSYSTEM_staffService".equals(content)) {//reopen  �����»Ự
////			if((!"0".equals(driving)||bean.target!=null||!Util.isNull(to))&&!"reopen".equals(content)) {//reopen  �����»Ự
//				//driving==1 ����Ai
//				transform.receiveEntity.getAnswersObject().put("callAi","1");
//				aibehavior.setActionBehavior(gzgzBehavior);
//				aibehavior.publishEntity(transform.receiveEntity);
//			}
//			else {
////				transform.receiveEntity.getAnswersObject().put("callAi","1");
////				aibehavior.setActionBehavior(gzgzBehavior);
////				aibehavior.publishEntity(transform.receiveEntity);
//				//driving==1 ����Ai
//				//transform.receiveEntity.getAnswersObject().put("callAi","0");
//				if(!"policyApp".equals(username)&&!"closeDialog".equals(content))
//				{
//					
//				}
//			}
			ORDERS orders = ORDERS.valueOfByCommand(content);
			RcsSession sessions = msgDistr.getContextProvidor().newBaseRcsContext().getSession(mdn,
					transform.receiveEntity.getChatBotId());
			String hint = "";
			if (orders != null) {
				if (ORDERS.SENDTC2POLICE.command.equals(orders.command)) {
					if(   sessions.containsKey("address")) {
						try {
							String address = java.net.URLDecoder.decode(Util.toString(sessions.get("address")), "UTF-8");
							hint = "�����û����г�����|�û�" + mdn + " ���14��ȥ�� " + address + " ������ "
									+ healthcode.get(Util.toString(sessions.get("type")));
						} catch (UnsupportedEncodingException e) {
							hint = "�����û����г�����|�û�" + mdn + " ������ " + healthcode.get(Util.toString(sessions.get("type")));
						}
					}else
					{
						hint="�г������ѹ���|�û�" + mdn + "�г������ѹ��ڣ������»�ȡ";
						msgUtil.pushMessages(hint, transform.receiveEntity.getChatBotId(),
								transform.receiveEntity.getSenderAddress(), transform.receiveEntity.getChatBotId(),
								msgDistr.getContextProvidor());
						transform.continued = false;
						return null;
					}
				}
			}
			if ((((
					(
					(bean == null || bean.target == null) 
					&& (targetbean == null || bean.target == null||bean.target.onlineUrls==null||bean.target.onlineUrls.size()==0)
					)
					|| transform.session.get(transform.USER_STATE) != null)
					&& !"YDZYSYSTEM_staffService".equals(content)) 
					|| (info != null && info.status == 2))
					&& (Util.isNull(to)))// δ��������AIģʽ
			{
				// type={type}&address={address}&time={time}&phone={phone}
//				if (info != null && info.status == 2 && "YDZYSYSTEM_staffService".equals(content)) {
					bean.target = null;
					if(!Util.isNull(hint))
					transform.receiveEntity.setContent(hint);
					hint="";
					transform.receiveEntity.getAnswersObject().put("callAi", "1");
					aibehavior.setActionBehavior(gzgzBehavior);
					aibehavior.publishEntity(transform.receiveEntity);
//				} else {
//					hint = "��������ʧ��|δ�����Ի�";
//					transform.continued = true;
//					transform.receiveEntity.getAnswersObject().put("callAi", "0");
//				}
			} else {
//				if (((info != null && info.status > -1) || !Util.isNull(to) ||"YDZYSYSTEM_staffService".equals(content))
//						&& transform.session.get(transform.USER_STATE) == null) {
					transform.receiveEntity.getAnswersObject().put("callAi", "1");
					aibehavior.setActionBehavior(gzgzBehavior);
					if(!Util.isNull(hint))
					transform.receiveEntity.setContent(hint);
					hint="";
					aibehavior.publishEntity(transform.receiveEntity);
					transform.continued = false;
//				} 
//				else {
//					hint = "��������ʧ��|δ�����Ի�";
//					transform.continued = true;
//					transform.receiveEntity.getAnswersObject().put("callAi", "0");
//				}

			}
			if (orders != null) {
				if (ORDERS.SENDTC2POLICE.command.equals(orders.command)) {
					if (Util.isNull(hint)) {

					} else {
						msgUtil.pushMessages(hint, transform.receiveEntity.getChatBotId(),
								transform.receiveEntity.getSenderAddress(), transform.receiveEntity.getChatBotId(),
								msgDistr.getContextProvidor());
						transform.continued = false;
					}
					return null;
				}
			}
//			if((((bean==null||bean.target==null)&&(targetbean==null||bean.target==null))||transform.session.get(transform.USER_STATE)!=null) &&!"staffService".equals(content))//δ��������AIģʽ
//			{
//				transform.continued=true;
//			}else {
//				
//				transform.receiveEntity.getAnswersObject().put("callAi","1");
//				transform.continued=false;
//			}
		}
		return null;
	}

}
