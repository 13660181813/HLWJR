package org.ydzy.log;

import java.util.Set;

import org.ydzy.db.DbAccessor;
import org.ydzy.util.Util;

public class LogAction {
	static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(LogAction.class);
    private static final String operator_sql_create="create table EVT_OPERATOR_LOG\r\n"
    		+ "(\r\n"
    		+ "  LOG_ID      NUMBER(16) not null,\r\n"
    		+ "  LOG_DATE    DATE not null,\r\n"
    		+ "  ACTION      NVARCHAR2(500),\r\n"
    		+ "  DESCRIPTION NVARCHAR2(2000),\r\n"
    		+ "  SERVER_IP   NVARCHAR2(100),\r\n"
    		+ "  COUNTNUM    NUMBER(11),\r\n"
    		+ "  STATUS      NVARCHAR2(50),\r\n"
    		+ "  SIMACTION   NVARCHAR2(500)\r\n"
    		+ ")";
    private static final String operator_insert="insert into evt_operator_log (\r\n"
    		+ "  LOG_ID      ,\r\n"
    		+ "  LOG_DATE    ,\r\n"
    		+ "  ACTION      ,\r\n"
    		+ "  DESCRIPTION ,\r\n"
    		+ "  SERVER_IP   ,\r\n"
    		+ "  COUNTNUM    ,\r\n"
    		+ "  STATUS      ,\r\n"
    		+ "  SIMACTION"
    		+ ") "
    		+ "values("
    		+ "?,"
    		+ "sysdate,"
    		+ "?,"
    		+ "?,"
    		+ "?,"
    		+ "?,"
    		+ "?,"
    		+ "?"
    		+ ")";
    private static final String operator_tname="EVT_OPERATOR_LOG";
    private static int tableExist=0;
    public static void recordLog(String action,String Desc,String reqIP,int countNum,String status ,String simation,DbAccessor accessor,String dsId) {
    	if(tableExist==0)
    	{
    		Set<String> tname=accessor.tableExist(dsId,"'"+operator_tname+"'");
    		if(tname!=null&&tname.size()>0&&tname.contains(operator_tname))
    			tableExist=1;
    		else
    		{
    			int count=accessor.update(dsId, operator_sql_create);
    			if(count>0) {
    			log.info("{} not exist! create sucess!",operator_tname);
    			tableExist=1;
    			}
    			else
    				log.info("{} not exist! create failed!",operator_tname);	
    			
    		}
    	}
    	if(tableExist==1)
    	{
    		if(!Util.isNull(Desc)&&Desc.length()>2000)
    			Desc=Desc.substring(0,1999);
    		Object [] params= {System.currentTimeMillis(),action,Desc,reqIP,countNum,status,simation};
    		accessor.update(dsId, operator_insert, params);
    		log.info("write log to db sucess {} ",params);
    	}
    }
}
