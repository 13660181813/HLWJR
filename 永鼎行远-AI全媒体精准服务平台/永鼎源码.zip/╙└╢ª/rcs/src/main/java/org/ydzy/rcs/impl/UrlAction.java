package org.ydzy.rcs.impl;

import java.io.UnsupportedEncodingException;
import java.util.Arrays;
import java.util.Base64;
import java.util.List;

import org.ydzy.rcs.SuggestionDisplay;
import org.ydzy.rcs.annotation.Description;
import org.ydzy.rcs.module.LoadProperties;
import org.ydzy.util.StringUtils;

import com.google.inject.Singleton;
import org.ydzy.util.Util;

@Singleton
@Description(value="urlAction")
public class UrlAction  implements SuggestionDisplay{
  private 	String urlMsg = "{"
            + "	  \"action\":\r\n"
			+ "		{\r\n" 
            + "			\"displayText\":\"%s\",\r\n"
			+ "			\"urlAction\":\r\n"
			+ "			{\r\n" 
			+ "				\"openUrl\":{\r\n" 
			+ "				\"url\":\"%s\",\r\n" 
			+ "				\"application\":\"%s\",\r\n"
			+ "				%s\r\n"
//			+ "				\"viewMode\":\"%s\",\r\n"// \"viewMode\": full|half|tall
//			+ "				\"parameters\":\"%s\",\r\n"
		  + "				\"surl\":\"%s\"\r\n"
			+ "				}\r\n"
			+ "			},\r\n"
		    + "			\"sugCssClassName\":\"%s\"\r\n"
			+ "		}\r\n" 
			+ "		}\r\n";
	@Override
	public String suggestionHtml(String[] args) {
//		String suggestionType = args[0];
		int length=args.length;
		String url=length<=2?"":args[2];
		String surl = url;//java.net.URLEncoder.encode(url, StandardCharsets.UTF_8);
		String params=length<=5?"": args[5];
		try {
			url=new String(Base64.getUrlEncoder().encode(url.getBytes("UTF-8")));
		} catch (UnsupportedEncodingException e) {
		}
		try {
			params=new String(Base64.getUrlEncoder().encode(params.getBytes("UTF-8"))) ;
		} catch (UnsupportedEncodingException e) {
		}
		String rurl=LoadProperties.systemProperties.getProperty("webUrl")+"/redirect?forwardUri="+(url)+"&param="+(params);
		
		String application, others="", sugCssClassName="";
		if(args.length>3 &&"browser".equalsIgnoreCase(args[3])) {
			//ignore
			application = "browser";
		}else {
			application = "webview";
		}
		if("webview".equalsIgnoreCase(application)) {
			String mode = args.length>4?args[4]:null;
			if(mode==null||!MODES.contains(mode.toLowerCase()))mode = MODES.get(0);
			others+= "\"viewMode\": \"" + mode + "\",";
		}
		if (args.length > 6) {
			sugCssClassName = Util.toString(args[6], "");
		}
		return	StringUtils.format(urlMsg, length<=1?"":args[1], rurl,application,others,surl,sugCssClassName);
	}
	private static final List<String> MODES = Arrays.asList("full,half,tall".split(","));
}
