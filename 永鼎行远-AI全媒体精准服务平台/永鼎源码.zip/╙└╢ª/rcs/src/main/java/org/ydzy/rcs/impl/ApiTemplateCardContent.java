package org.ydzy.rcs.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.ydzy.handler.BaseRcsContext;
import org.ydzy.publish.ConstantTopics;
import org.ydzy.rcs.CardModel;
import org.ydzy.rcs.annotation.Description;
import org.ydzy.rcs.entity.ReceiveEntity;

import com.google.gson.JsonObject;
import com.google.inject.Singleton;
import org.ydzy.util.Util;

/**
 * @author zxw
 * api��ʽģ�忨Ƭ����
 */
@Singleton
@Description(ApiTemplateCardContent.TYPE)
public class ApiTemplateCardContent extends MulitiCardContent implements CardModel {
    private static final Logger log = LoggerFactory.getLogger(ApiTemplateCardContent.class);
    public static final String TYPE = "apitemplatecard";

    @Override
    protected List<Map<String, Object>> modelParams(ReceiveEntity requestObject, JsonObject contentObject, BaseRcsContext context) {
        String msgid = contentObject == null ? null : Util.getElementAsString(contentObject, "msgid");
        JsonElement jo = (JsonElement) requestObject.getAnswersObject().get(ConstantTopics.CHATBOT_THIRDPART_API_TEMPLATE_DATA);
        List<Map<String, Object>> list = buildDynamic(msgid, jo);
        if (list != null && !list.isEmpty()) {
            return list;
        }
        return super.modelParams(requestObject, contentObject, context);
    }

    public List<Map<String, Object>> buildDynamic(String msgId, JsonElement params) {
        if (Util.isNull(msgId) || params == null || params.isJsonNull()) {
            return null;
        }
        List<Map<String, Object>> modelParams = new ArrayList<>();
        if (params.isJsonArray()) {
            params.getAsJsonArray().forEach(el -> {
                List<Map<String, Object>> list = buildDynamic(msgId, el);
                if (list != null && !list.isEmpty()) modelParams.addAll(list);
            });
        } else if (params.isJsonObject()) {
            Gson gson = new Gson();
            JsonObject asJsonObject = params.getAsJsonObject();
            Map<String, Object> map = new HashMap<>();
            map.put("msgId", msgId);
            map.put("params", gson.fromJson(asJsonObject, Map.class));
            modelParams.add(map);
        } else {
            log.info("params should be JsonObject or JsonArray.");
        }
        if (!modelParams.isEmpty()) {
            return modelParams;
        }
        return null;
    }

}
