package org.ydzy.rcs.decker;

import org.ydzy.handler.BaseRcsContext;
import org.ydzy.rcs.BodyTransform;
import org.ydzy.rcs.entity.ReceiveEntity;
import org.ydzy.util.Util;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

public interface DeckerRobot {
	static enum ORDERS {
		STARTORDER("setOrder#"),
		CREATEORDER("createOrder#"),
		CLOSEORDER("closeOrder#"),
		LOCALKEYWORDS("localBack#");
		private String command;

		public String getCommand() {
			return command;
		}

		ORDERS(String command) {
			this.command = command;
		}

		public static ORDERS valueOfByCommand(String command) {
			ORDERS[] orders = ORDERS.values();
			for (ORDERS s : orders) {
				if (s.getCommand().equals(command))
					return s;
			}
			return null;
		}
	}
	/**
	 * @param receiveEntity
	 * @return �ӹ��������
	 */
	public  JsonElement doTransform(BodyTransform transform,JsonElement efind);
	public default  JsonElement checkIsKeyWords(ReceiveEntity receiveEntity,BaseRcsContext context)
	{
		String reqKeyWords = receiveEntity.getContent();;
		JsonObject eobject=context.getConfig().getKeyWordsBysp(receiveEntity.getChatBotId(),reqKeyWords);
		if(eobject==null||eobject.isJsonNull())
			return null;
		else
		{
			receiveEntity.getAnswersObject().put("configid", Util.getElementAsString(eobject, "configid"));
			return  eobject;
		}
		
	}
	
//	/**
//	 * @param decker
//	 */
//	public void nextDecker(DeckerRobot decker);
	 
}
