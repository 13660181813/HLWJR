package org.ydzy.rcs;

import java.net.URLDecoder;
import java.nio.charset.Charset;

import org.ydzy.bot.BotUtil;

/**
 *  5G��Ϣ�е� ��λ�������
 * @author ljp
 *
 */
public class RcsGeo {
	private static Charset utf8 = Charset.forName("UTF8");
	
	//geo:26.586435171316765,106.72470059207059;u=0;crs=gcj02;rcs-l=%E8%B4%B5%E5%B7%9E%E7%9C%81%E8%B4%B5%E9%98%B3%E5%B8%82%E4%BA%91%E5%B2%A9%E5%8C%BA%3B%E8%B4%B5%E5%B7%9E%E7%9C%81%E8%B4%B5%E9%98%B3%E5%B8%82%E4%BA%91%E5%B2%A9%E5%8C%BA%E6%A0%96%E9%9C%9E%E7%A4%BE%E5%8C%BA%E6%9C%8D%E5%8A%A1%E4%B8%AD%E5%BF%83%E8%9E%BA%E8%9B%B3%E5%B1%B1%E8%B7%AF%E4%BA%91%E5%B2%A9%E5%8C%BA%E6%94%BF%E5%BA%9C%E6%97%AD%E4%B8%9C%E5%B0%8F%E5%8C%BA
	/***
	 * ���� ���� geo:26.586435171316765,106.72470059207059;u=0...�� ����, ������geo���� , ����null
	 * @param raw
	 * @return
	 */
	public static RcsGeo parse(String raw) {
		if(raw!=null && raw.startsWith("geo:"))try {
			RcsGeo geo = new RcsGeo();
			String content = raw.substring(4);
			String[] tmps = content.split(";");
			String[] tmps1 = tmps[0].split(",",2);
			geo.lat = Double.parseDouble(tmps1[0]);
			geo.lng = Double.parseDouble(tmps1[1]);
			
			
			for(int i=1;i<tmps.length;i++) {
				tmps1 = tmps[i].split("=",2);
				if(tmps1.length>1) {
					if("u".equals(tmps1[0])) {
						geo.u = Integer.parseInt(tmps[1]);
					}else if("crs".equals(tmps1[0])) {
						geo.crs = tmps1[1];
					}else if("rcs-l".equals(tmps1[0])) {
						try {
							geo.rcs1 = java.net.URLDecoder.decode(tmps1[1], "UTF8");
						}catch(Exception ignore) {
							geo.rcs1 = tmps1[1];
						}
					}
				}
			}
			return geo;
		}catch(Exception e) {
			//ignore
		}
		return null;
	}
	
	private RcsGeo() {
	}
	
	
	private double lat;
	private double lng;
	
	private int u;
	private String crs;
	private String rcs1;
	public double getLat() {
		return lat;
	}

	public void setLat(double lat) {
		this.lat = lat;
	}

	public double getLng() {
		return lng;
	}

	public void setLng(double lng) {
		this.lng = lng;
	}

	public int getU() {
		return u;
	}

	public void setU(int u) {
		this.u = u;
	}

	public String getCrs() {
		return crs;
	}

	public void setCrs(String crs) {
		this.crs = crs;
	}

	public String getRcs1() {
		return rcs1;
	}

	public String getRcs1Decode() {
		return URLDecoder.decode(rcs1, utf8);
	}

	public void setRcs1(String rcs1) {
		this.rcs1 = rcs1;
	}

	@Override
	public String toString() {
		return "geo:" + lat + "," + lng + "; u=" + u + ";crs=" + crs + ";rcs1=" + rcs1 ;
	}


}
