package org.ydzy.rcs.decker;

import org.ydzy.rcs.BodyTransform;
import org.ydzy.rcs.annotation.Description;
import org.ydzy.thirdparty.DialogActionBehavior;
import org.ydzy.thirdparty.KfAiBehavior;
import org.ydzy.thirdparty.MessageDispatcher;
import org.ydzy.thirdparty.gz110.entity.InstantBean;
import org.ydzy.thirdparty.gz110.entity.OrdersInfo;
import org.ydzy.thirdparty.util.MsgUtils;
import org.ydzy.util.Util;

import com.google.gson.JsonElement;
import com.google.inject.Inject;
import com.google.inject.Singleton;


@Singleton
@Description(value = "commKfAi")
public class CallKfAi implements DeckerRobot{
	
	@Inject
	MessageDispatcher msgDistr;
	@Inject
	KfAiBehavior aibehavior;
	@Inject 
	DialogActionBehavior actionBehavior;
	
	@Override
	public JsonElement doTransform(BodyTransform transform, JsonElement efind) {
		String mdn =transform.receiveEntity.getMdn();
		String content=transform.receiveEntity.getContent();;
		InstantBean bean =msgUtil.getInstantBean(transform.receiveEntity);
		//to
		String to =transform.receiveEntity.sendTo;;
		
//		if(bean!=null  && ("staffService".equals(content)||!Util.isNull(to)))
//		{
//		}
		OrdersInfo info =msgUtil.getOrdersInfo(transform.receiveEntity,bean);
		DeckerRobot.ORDERS orders=null;
		if (content.indexOf("#") > 0) {
			String command = content.split("#")[0];
			orders =DeckerRobot.ORDERS.valueOfByCommand(command+"#");
		}
//		OrdersInfo info = msgUtil.getOrdersInfo(transform.receiveEntity.getMdn(), true, bean,
//				transform.receiveEntity.sendTo, transform.receiveEntity.getChatBotId());
		InstantBean targetbean= msgUtil.getInstantBean(to,transform.receiveEntity.getChatBotId());
		if(!Util.isNull(to))msgDistr.InstantBean(to,transform.receiveEntity.getChatBotId());
		if ((((((bean == null || bean.target == null||bean.target.onlineUrls.size()==0) && (targetbean == null || bean.target == null))
				|| transform.session.get(transform.USER_STATE) != null)
				&& !"staffService".equals(content))||(info!=null&&info.status==2))&&orders==null)//δ��������AIģʽ
		{
			if(info!=null&&info.status==2&&("staffService".equals(content))) {
				bean.target=null;
				transform.receiveEntity.getAnswersObject().put("callAi","1");
				transform.receiveEntity.getAnswersObject().put("orderId","1");
				aibehavior.setActionBehavior(actionBehavior);
				aibehavior.publishEntity(transform.receiveEntity);
			}else
			{
				transform.continued=true;
				transform.receiveEntity.getAnswersObject().put("callAi","0");
			}
		}else {
				transform.receiveEntity.getAnswersObject().put("callAi","1");
				transform.receiveEntity.getAnswersObject().put("orderId","1");
				aibehavior.setActionBehavior(actionBehavior);
				aibehavior.publishEntity(transform.receiveEntity);
				transform.continued=false;
		}
		return null;
	}
	@Inject
	protected MsgUtils msgUtil;
}
