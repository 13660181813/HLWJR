package org.ydzy.publish;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.atomic.AtomicLong;

/**
 * ��������
 * @author XFDEP
 *
 */
public class SubscribePublish<M> {
	private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(SubscribePublish.class);
	private String sName;
	
	final int CAPACITY=5000;
	
	private BlockingQueue<Msg<M>> queue=new ArrayBlockingQueue<Msg<M>>(CAPACITY);
	
	public BlockingQueue<Msg<M>> getQueue() {
		return queue;
	}
	private List<ISubscriber<M>> subscribers=new ArrayList<ISubscriber<M>>();
	
	private AtomicLong receiveIncreament=new AtomicLong();
	
	private long lastPrintTime=0;
	private void UpdateNotifyThread()
	{
		Thread UpdateNotifyThread=new Thread() {
			public void run()
			{
				while(true) {
					update();
					long current=System.currentTimeMillis();
		            if(current-lastPrintTime>600000)
		            {
		            	log.info("sName {} received {} unUpdate {} ",sName,receiveIncreament.get(),queue.size());
		            	lastPrintTime=current;
		            }
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
			}
		};
		UpdateNotifyThread.setName( this.sName+"UpdateNotifyThread");
		UpdateNotifyThread.start();
	}
	
	public SubscribePublish(String name) {
        this.sName = name;
        UpdateNotifyThread();
    }
 
    public void publish(String publisher, M message, boolean isInstantMsg) {
    	receiveIncreament.incrementAndGet();
        if (isInstantMsg) {
            update(publisher, message);
            return;
        }
        Msg<M> m = new Msg<M>(publisher, message);
        if (!queue.offer(m)) {
            update();
        }
    }
 
    public void subcribe(ISubscriber<M> subcriber) {
    	subscribers.add(subcriber);
    }
 
    public void unSubcribe(ISubscriber<M> subcriber) {
    	subscribers.remove(subcriber);
    }
 
    public void update() {
        Msg<M> m = null;
        while ((m = queue.poll()) != null) {
            this.update(m.getPublisher(), (M) m.getMsg());
            
        }
    }
 
    public void update(String publisher, M Msg) {
        for (ISubscriber<M> subcriber : subscribers) {
        	try {
        		subcriber.update(publisher, Msg);
        	}catch(Throwable t) {
        		log.error("publisher update error, ignore!", t);
        	}
        }
    }
    class Msg<M> {
        private String publisher;
        private M m;
     
        public Msg(String publisher, M m) {
            this.publisher = publisher;
            this.m = m;
        }
     
        public String getPublisher() {
            return publisher;
        }
     
        public void setPublisher(String publisher) {
            this.publisher = publisher;
        }
     
        public M getMsg() {
            return m;
        }
     
        public void setMsg(M m) {
            this.m = m;
        }
    }

}
