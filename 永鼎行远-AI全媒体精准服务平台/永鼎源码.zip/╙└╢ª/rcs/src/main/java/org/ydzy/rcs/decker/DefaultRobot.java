package org.ydzy.rcs.decker;

import org.ydzy.handler.BaseRcsContext;
import org.ydzy.rcs.BodyTransform;
import org.ydzy.rcs.annotation.Description;
import org.ydzy.rcs.entity.ReceiveEntity;
import org.ydzy.util.Util;

import com.google.gson.JsonElement;
import com.google.inject.Singleton;

@Singleton
@Description(value = "defaultchatbot")
public class DefaultRobot  implements DeckerRobot{
	
	@Override
	public JsonElement doTransform(BodyTransform transform,JsonElement efind) {
		if(efind==null)
		{
			BaseRcsContext context=transform.context;
			ReceiveEntity receiveEntity =transform.receiveEntity;
			String ks=Util.toString(receiveEntity.getAnswersObject().get("keywordsearch"));
			if("1".equals(ks))
			{
				String reqKeyWords = receiveEntity.getContent();;
				String userName=Util.toString(receiveEntity.getAnswersObject().get("userName"));
				efind=context.getConfig().getKeyWordsLikeFilterByRole(receiveEntity.getChatBotId(),reqKeyWords,userName);
			}else
			efind=checkIsKeyWords(receiveEntity,context);
		}
		transform.continued=true;
		return efind;
	}

}
