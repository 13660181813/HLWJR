package org.ydzy.rcs.impl;

import com.google.inject.Singleton;
import org.ydzy.rcs.annotation.Description;

/**
 * �й���ͨ���ݽṹ ��Ϣ����
 *
 * @author zxw
 * @create 2022/1/12
 */
@Singleton
@Description(value = "cuccMessageImp")
public class CuccMessagePack extends TelecomMessagePack {
}
