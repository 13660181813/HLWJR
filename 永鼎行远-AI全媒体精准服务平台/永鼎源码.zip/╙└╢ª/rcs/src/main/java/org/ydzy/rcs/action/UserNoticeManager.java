package org.ydzy.rcs.action;

import com.google.gson.*;
import com.google.inject.Inject;
import com.google.inject.name.Named;
import org.ydzy.rcs.db.XmlSqlGenerator;
import org.ydzy.util.SqlUtil;
import org.ydzy.util.Util;

import javax.sql.DataSource;

/**
 * @author lirui
 * @Date 2021/9/16 12:28 ����
 */
public class UserNoticeManager {

    static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(EvaluateManagerAction.class);
    Gson gson = new Gson();
    @Inject
    @Named("rcsDb")
    DataSource ds;

    public JsonArray queryNoticeByRUser(JsonObject object) {
        JsonArray array = new JsonArray();
        String sqlId = "queryNoticeByUserid";
        try {
            String sql = XmlSqlGenerator.getSqlByJson(sqlId, null, object);
            array = SqlUtil.queryForJson(ds, sql);
            for (JsonElement element : array) {
                JsonObject obj = element.getAsJsonObject();
                if (obj.has("scrollbar") && !Util.isNull(obj.get("scrollbar").toString())) {
                    JsonElement scrollbarele = obj.get("scrollbar");
                    if (scrollbarele != null && !scrollbarele.isJsonNull()) {
                        String scrollBar = obj.get("scrollbar").getAsString();
                        try {
                            JsonElement scrollEle = JsonParser.parseString(scrollBar);
                            obj.add("scrollbar", scrollEle);
                        } catch (Exception ignored) {}
                    }
                }

                JsonElement contentele = obj.get("content");
                if (contentele != null && !contentele.isJsonNull()) {
                    String content = obj.get("content").getAsString();
                    obj.addProperty("content", content.replace("\r", "").replace("\n", "").replace("\t", ""));
                }
            }
        } catch (Exception e) {
            log.error("query user notice err", e);
        }
        return array;
    }

    public boolean addNoticeToUser(JsonObject object) {
        String sqlId = "addNoticeToUser";
        String ruserid = Util.getElementAsString(object, "ruserid");
        try {
            String sql = XmlSqlGenerator.getSqlByJson(sqlId, null, object);
            return SqlUtil.updateRecords(ds, sql.replace("��", ","));
        } catch (Exception e) {
            log.error("add notice to userid {}", ruserid);
        }
        return false;
    }

    public boolean editNotice(JsonObject object) {
        String sqlId = "editNoticeToUser";
        String noticeid = Util.getElementAsString(object, "noticeid");
        try {
            if (object.has("scrollbar") && !Util.isNull(object.get("scrollbar").toString())) {
                JsonElement scrollbarele = object.get("scrollbar");
                if (scrollbarele != null && !scrollbarele.isJsonNull()) {
                    String scrollBar = object.get("scrollbar").toString();
                    object.addProperty("scrollbar", scrollBar);
                }
            }
            JsonElement contentele = object.get("content");
            if (contentele != null && !contentele.isJsonNull()) {
                String content = object.get("content").toString();
                object.addProperty("content", content.replace("\r", "").replace("\n", "").replace("\t", ""));
            }
            String sql = XmlSqlGenerator.getSqlByJson(sqlId, null, object);
            return SqlUtil.updateRecords(ds, sql.replace("��", ","));
        } catch (Exception e) {
            log.error("edit notice({}) error.", noticeid, e);
        }
        return false;
    }
}
