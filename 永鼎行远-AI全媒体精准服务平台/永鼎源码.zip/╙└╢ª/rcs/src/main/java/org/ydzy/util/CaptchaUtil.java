package org.ydzy.util;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.*;

/**
 * ��֤��������
 */
public class CaptchaUtil {
    private static final String randString = "23456789ABCDEFGHJKLMNPQRSTUVWXYZ";
    private static final Font font = new Font("Fixedsys", Font.BOLD, 18);

    private static Color getRandColor(int fc, int bc) {
        if (fc > 255) {
            fc = 255;
        }

        if (bc > 255) {
            bc = 255;
        }

        Random random = new Random();
        int r = fc + random.nextInt(bc - fc - 16);
        int g = fc + random.nextInt(bc - fc - 14);
        int b = fc + random.nextInt(bc - fc - 18);
        return new Color(r, g, b);
    }

    private static String drawString(Graphics g, String randomString, int i) {
        g.setFont(font);
        Random random = new Random();
        g.setColor(new Color(random.nextInt(101), random.nextInt(111), random.nextInt(121)));
        String rand = getRandomString(random.nextInt(randString.length()));
        randomString = randomString + rand;
        g.translate(random.nextInt(3), random.nextInt(3));
        g.drawString(rand, 13 * i, 16);
        return randomString;
    }

    private static void drawLine(Graphics g) {
        Random random = new Random();
        int x = random.nextInt(95);
        int y = random.nextInt(25);
        int xl = random.nextInt(13);
        int yl = random.nextInt(15);
        g.drawLine(x, y, x + xl, y + yl);
    }

    private static String getRandomString(int num) {
        return String.valueOf(randString.charAt(num));
    }

    public static Map<String, String> getCaptchaImg(int length) throws IOException {
        if (length < 4) {
            length = 4;
        }

        int width = 85 + 5 * (length - 4);
        int height = 25;
        int lineSize = 40 + 2 * (length - 4);
        int stringNum = length;
        BufferedImage image = new BufferedImage(width, height, 4);
        Graphics g = image.getGraphics();
        g.fillRect(0, 0, width, height);
        g.setFont(new Font("Times New Roman", Font.PLAIN, 18));
        g.setColor(getRandColor(110, 133));

        for (int i = 0; i <= lineSize; ++i) {
            drawLine(g);
        }

        String randomString = "";

        for (int i = 1; i <= stringNum; ++i) {
            randomString = drawString(g, randomString, i);
        }

        g.dispose();
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        ImageIO.write(image, "jpeg", out);
        String base64bytes = Base64.getEncoder().encodeToString(out.toByteArray());
        String src = "data:image/jpeg;base64," + base64bytes;
        Map<String, String> mapResult = new HashMap<>();
        mapResult.put("captcha", randomString);
        mapResult.put("img", src);
        return mapResult;
    }
}