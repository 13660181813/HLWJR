package org.ydzy.rcs.ai;

import java.io.Reader;
import java.io.Writer;
import java.nio.charset.Charset;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.function.Supplier;

import javax.net.ssl.HttpsURLConnection;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.ydzy.config.ApplicationConfig;
import org.ydzy.rcs.IAIRobot;
import org.ydzy.rcs.annotation.Description;
import org.ydzy.rcs.entity.ReceiveEntity;
import org.ydzy.util.NetUtils;
import org.ydzy.util.Util;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.inject.Binder;
import com.google.inject.Inject;
import com.google.inject.Module;
import com.google.inject.Provider;

@Description("AiModule")
public class BaiduChat  implements Module {
	static final Logger log = LoggerFactory.getLogger(BaiduChat.class);
	
//	public static void main(String[] args) throws IOException {
//		Robot r =  new BaiduChat().MyProvider().getRobot();
//		BufferedReader br = new BufferedReader(new java.io.InputStreamReader(System.in));
//		String text;
//		String sessionid = UUID.randomUUID().toString();
//		while(true) {
//			System.out.print(">");
//			System.out.flush();
//			if((text=br.readLine())==null)break;
//			String out = r.chat(sessionid, text);
//			System.out.println(out);
//		}
//	}
	
	
	//@Singleton
	private static class RobotProvider implements Provider<IAIRobot>{
		@Inject
		private ApplicationConfig applicationconfig;
		
		private BaiduAccessToken token = null;
		
		private Robot robot = null;
		
		@Inject(optional = true)
		@com.google.inject.name.Named("baiduai.leave.service_id")
		private String leave_sid = "S49613";
		private LeaveParse lp = null;
		
		protected synchronized BaiduAccessToken getBaiduAccessToken() {
			if(token==null) {
				String appKey = applicationconfig.BAIDUAI_APPKEY;
				String appSecret = applicationconfig.BAIDUAI_APPSECRET;
				token = new BaiduAccessToken(appKey, appSecret);
			}
			return token;
		}
		
		@Override
		public synchronized IAIRobot get() {
			if(robot==null) {
				String service_id = applicationconfig.BAIDUAI_SERVICE_ID;
				boolean naughty = true;
				String tmp=applicationconfig.BAIDUAI_NAUGHTY;
				if("false".equalsIgnoreCase(tmp)||"no".equalsIgnoreCase(tmp)||"0".equalsIgnoreCase(tmp))naughty=false;
				robot = new Robot(getBaiduAccessToken(), service_id);
				robot.setNaughty(naughty);
			}
			return robot;
		}
		
		protected synchronized ILeave getLeave() {
			if(lp==null) {
				lp = new LeaveParse(getBaiduAccessToken(), leave_sid);
			}
			return lp;
		}
		
		
	}
	@Override
	public void configure(Binder binder) {
		binder.bind(ApplicationConfig.class);
		RobotProvider providor = new RobotProvider();
		binder.bind(IAIRobot.class).toProvider(providor);
		binder.bind(ILeave.class).toProvider(providor::getLeave);
	}
	
	public static class Result{
		public String body;
		public JsonObject jObject;
		public Result(String body) {
			this.body = body;
			JsonElement ele = JsonParser.parseString(body);
			jObject = ele.getAsJsonObject();
		}
	}
	static Charset utf8 = Charset.forName("UTF8");
	static class BaiduUnit{
		// reference https://ai.baidu.com/ai-doc/UNIT/bkiy75fn9 
		String apiUrl="https://aip.baidubce.com/rpc/2.0/unit/service/chat?access_token=%s";
		
		
		protected Supplier<String> accessToken;
		private String service_id;
		//private String dataJson = "{\"log_id\":\"%s\",\"version\":\"2.0\",\"service_id\":\"%s\",\"session_id\":\"%s\",\"request\":{\"query\":\"%s\",\"user_id\":\"88888\"}}";
		
		private String sessionid = UUID.randomUUID().toString();
		int seq = 0;
		
		public BaiduUnit(Supplier<String> accessToken, String service_id) {
			super();
			this.accessToken = accessToken;
			this.service_id = service_id;
		}

		protected Result getBaiduUnit(String session_id, String query) {
			return this.getBaiduUnitWithRetry(session_id, query, 3);
		}
		
		protected Result getBaiduUnitWithRetry(String session_id, String query, int maxRetry) {
			int count = 0;
			while(true) {
				Result result = this.getBaiduUnitRaw(session_id, query);
				long errCode = result==null?-1:getElementAsLong(result.jObject, "error_code");
				if(errCode==0)return result;
				if(++count > maxRetry) {
					log.warn("exceed retry " + count + ">" + maxRetry + ", respone:" + result.body);
					return result;
				}else {
					log.info("call baidu unit error (" + count + "/" + maxRetry + "), respone:" + (result==null?"":result.body));
					try {
						Thread.sleep((1<<count)*1000);
					} catch (InterruptedException ignore) {
					}
				}
			}
		}
		
		protected Result getBaiduUnitRaw(String session_id, String query) {
			if(query==null || query.trim().isEmpty()) return null;
			if(session_id==null || session_id.isEmpty()) session_id = this.sessionid;
			String baseLogId = null;
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
			baseLogId = "chat" + sdf.format(new java.util.Date());
			String logId = baseLogId + String.format("%04d",seq++);
			
			JsonObject joData = new JsonObject();
			joData.addProperty("log_id", logId);
			joData.addProperty("version", "2.0");
			joData.addProperty("service_id", service_id);
			joData.addProperty("session_id", session_id);
			JsonObject joRequest = new JsonObject();
			joRequest.addProperty("query", query);
			joRequest.addProperty("user_id", "88888");
			joData.add("request", joRequest);
			String data = joData.toString();
			//"{\"log_id\":\"%s\",\"version\":\"2.0\",\"service_id\":\"%s\",\"session_id\":\"%s\",\"request\":{\"query\":\"%s\",\"user_id\":\"88888\"}}";
			//String data = String.format(dataJson, logId, service_id, session_id, query.replace('\"', '\''));
			
			String url = String.format(apiUrl, accessToken.get());
			try {
//				HttpURLConnection c = (HttpURLConnection)new URL(url).openConnection();
				HttpsURLConnection c =NetUtils.getHttpsURLConnection(url,"POST");
				c.setRequestMethod("POST");
				c.setConnectTimeout(15000);
				c.setReadTimeout(15000);
				c.setDoOutput(true);
				c.addRequestProperty("Content-Type", "application/json");
				c.connect();
				Writer writer = new java.io.OutputStreamWriter(c.getOutputStream(), utf8);
				writer.append(data);
				writer.close();
				if(log.isDebugEnabled()) log.debug("connecting baidu ai chat:" + url + " data:" + data);
				int rc = c.getResponseCode();
				if(rc>=300) throw new RuntimeException("get response core error(" + rc + ")");
				
				try(Reader reader = new java.io.InputStreamReader(c.getInputStream(),utf8)){
					char[] cbuff = new char[1024];
					int l;
					StringBuilder sb = new StringBuilder();
					while((l=reader.read(cbuff))>=0) {
						if(l>0)sb.append(new String(cbuff,0,l));
					}
					String body = sb.toString();
					if(log.isDebugEnabled()) log.debug("baidu ai chat resp:" + body);
					return new Result(body);
				}
			}catch(Exception e) {
				log.warn("get chat error from " + url + "(" + e.getMessage() + ")",e);
			}
			return null;
		} 
	} 
	
	static class Robot extends BaiduUnit implements IAIRobot{
		/** �����ȡ��� */
		private boolean naughty = true;
		public boolean isNaughty() {
			return naughty;
		}
		public void setNaughty(boolean naughty) {
			this.naughty = naughty;
		}

		public Robot(Supplier<String> accessToken, String service_id) {
			super(accessToken, service_id);
		}

		@Override
		public String runAi(ReceiveEntity receiveEntity) {
			String say="";
			String keyword = receiveEntity.getContent();
			if(!Util.isNull(keyword) && keyword.length()<256 && !(keyword.startsWith("<") || keyword.startsWith("{"))) {
				String sessionid = null;
				sessionid = receiveEntity.conversationID;
				if(sessionid==null && receiveEntity.getReceive5GMsg()!=null) {
					sessionid = getElementAsString(receiveEntity.getReceive5GMsg(), "conversationID");
				}
				if(sessionid==null || sessionid.isEmpty()) sessionid = receiveEntity.getMdn();
				say = this.chat(sessionid, keyword);
			}
			if(Util.isNull(say)) {
				if(receiveEntity.getAnswersObject().containsKey("download")) {
					List<?> dinofs=null;
					dinofs=(List<?>) receiveEntity.getAnswersObject().get("download");
					if(dinofs!=null&&dinofs.size()>0) {
						String contentType = null;
						Object o = dinofs.get(0);
						if(o instanceof Map) {
							Map<?, ?> map = (Map<?, ?>)o;
							o = map.get("filecontentType");
							if(o!=null) contentType = o.toString().toLowerCase();
						}
						say="�ļ�/ý��ɹ�";
						if(contentType!=null) {
							if(contentType.indexOf("image")>=0) {
								say="��ͼƬ�ɹ�";
							}else if(contentType.indexOf("vedio")>=0) {
								say="ý���ļ��ɹ�";
							}
						}
					}
				}
			}
			if(say==null)return null;
			return say;
		}
		

		protected String chat(String session_id, String query) {
			Result result = this.getBaiduUnit(session_id, query);
			JsonObject object = result.jObject;
			if(object!=null) {
				try {
					String text = selectSay(object, result.body, isNaughty());
					if(isWrongSay(text))text = selectSay(object, result.body, false);
					return text;
				}catch(Throwable t) {
					log.warn("call baiduUnit error(apiurl:" + apiUrl + " accessToken:" + accessToken.get() + " query:" + query + " response:" + result.body, t);
				}
			}
			return null;
		}
		
		String selectSay(JsonObject object, String body, boolean naughty) {
			StringBuilder objPath = new StringBuilder();
			String tagName;
			JsonElement o;
			JsonArray ja;
			int idx;
			tagName = "result";
			o = getElement(object, tagName);
			objPath.append(tagName);
			if(o==null)throw new RuntimeException("get resonse json error, not found(" + objPath.toString() + ") response:" + body);
			object = o.getAsJsonObject();
			
			tagName = "response_list";
			o = getElement(object, tagName);
			objPath.append('.').append(tagName);
			if(o==null)throw new RuntimeException("get resonse json error, not found(" + objPath.toString() + ")");
			ja = o.getAsJsonArray();
			idx=0;
			if(isNaughty()) {
				for(idx=0;idx<ja.size();idx++) {
					double d = Math.random();
					if(d>0.5)break;
				}
				if(idx>=ja.size())idx=0;
			}
			o = ja.get(idx);
			objPath.append("[" + idx+ "0]");
			object = o.getAsJsonObject();

			tagName = "action_list";
			o = getElement(object, tagName);
			objPath.append('.').append(tagName);
			if(o==null)throw new RuntimeException("get resonse json error, not found(" + objPath.toString() + ")");
			ja = o.getAsJsonArray();
			idx=0;
			if(isNaughty()) {
				for(idx=0;idx<ja.size();idx++) {
					double d = Math.random();
					if(d>0.5)break;
				}
				if(idx>=ja.size())idx=0;
			}
			o = ja.get(idx);
			objPath.append("[" + idx+ "]");
			object = o.getAsJsonObject();
			
			tagName = "say";
			o = getElement(object, tagName);
			objPath.append('.').append(tagName);
			if(o==null)throw new RuntimeException("get resonse json error, not found(" + objPath.toString() + ")");
			
			String text = o.getAsString();
			return text;
		}
		
		boolean isWrongSay(String text) {
			boolean flag =  text==null||text.contains("��֪��")||text.contains("������˼");
			return flag;
		}
	}
	
	
	static class LeaveParse extends BaiduUnit implements ILeave{

		protected class Info extends ILeave.Info{
			public String rawTime, rawType, rawPeriod, rawPerson;
			public Result result;
			boolean inner = false;
		}
		protected class Context{
			public Info info;
			public Result result;
			String query;
			String session_id;
			boolean inner = false;
		}
		public LeaveParse(Supplier<String> accessToken, String service_id) {
			super(accessToken, service_id);
		}

		@Override
		public ILeave.Info getLeaveInfo(String session_id, String query) {
			Result result = this.getBaiduUnit(session_id, query);
			Context context = new Context();
			context.info = new Info();
			context.query = query;
			context.session_id = session_id;
			context.result = result;
			return this.parseLeave(context);
		}
		
		protected Info parseLeave(Context context) {	
			String body = context.result.body;
			JsonObject object = context.result.jObject;
			StringBuilder objPath = new StringBuilder();
			String tagName;
			JsonElement o;
			tagName = "result";
			o = getElement(object, tagName);
			objPath.append(tagName);
			if(o==null)throw new RuntimeException("get resonse json error, not found(" + objPath.toString() + ") response:" + body);
			object = o.getAsJsonObject();
			
			tagName = "response_list";
			o = getElement(object, tagName);
			objPath.append('.').append(tagName);
			if(o==null)throw new RuntimeException("get resonse json error, not found(" + objPath.toString() + ")");
			scan(o, objPath, context, null);
			return context.info;
		}
		
		// û��д�� �ĳ�ʹ�õݹ�ķ�ʽ����
		protected void parse(JsonObject object, StringBuilder objPath, Context context) {
			String tagName;
			JsonElement o;
			JsonArray ja;
			int p1 = objPath.length();
			ja = object.getAsJsonArray();
			for(int i=0;i<ja.size();i++) {
				objPath.setLength(p1);
				o = ja.get(i);
				objPath.append("[" + i + "]");
				object = o.getAsJsonObject();
				
//				int p2 = objPath.length();
//				tagName = "qu_res";
//				o = getElement(object, tagName);
//				objPath.append('.').append(tagName);
				
				tagName = "schema";
				o = getElement(object, tagName);
				objPath.append('.').append(tagName);
				if(o==null)throw new RuntimeException("get resonse json error, not found(" + objPath.toString() + ")");
				
				tagName = "slots";
				o = getElement(object, tagName);
				objPath.append('.').append(tagName);
				if(o==null)throw new RuntimeException("get resonse json error, not found(" + objPath.toString() + ")");
				int p3 = objPath.length();
				JsonArray ja2 = o.getAsJsonArray();
				for(int j=0;j<ja2.size();j++) {
					objPath.setLength(p3);
					o = ja2.get(j);
					objPath.append("[" + j + "]");
					object = o.getAsJsonObject();
					
					//String sName = getElementAsString(object, "name");
					this.parseInfo(object, objPath, context, null);
				}
			}
		}
		
		protected static enum TagType{
			slots, 
			lexical_analysis
		}
		protected void scan(JsonElement ele, StringBuilder objPath, Context context, TagType tag) {
			JsonElement o;
			if(ele.isJsonArray()) {
				int p = objPath.length();
				JsonArray ja = ele.getAsJsonArray();
				for(int j=0;j<ja.size();j++) {
					o = ja.get(j);
					objPath.append("[" + j + "]");
					this.scan(o, objPath, context, tag);
					objPath.setLength(p);
				}
				return;
			}else if(ele.isJsonObject()){
				JsonObject object = ele.getAsJsonObject();
				boolean flag = false;
				if(tag!=null)flag = this.parseInfo(object, objPath, context, tag);
				if(!flag) {
					int p = objPath.length();
					for(Map.Entry<String, JsonElement> e: object.entrySet()) {
						try {
							tag = TagType.valueOf(e.getKey());
						}catch(Exception ignore) {}
						objPath.append('.').append(e.getKey());
						this.scan(e.getValue(), objPath, context, tag);
						objPath.setLength(p);
					}
				}
			}
		}
		
		protected boolean parseInfo(JsonObject object, StringBuilder objPath, Context context, TagType tag) {
			// JSON.result.response_list[4].qu_res.result.response_list[0].schema.slots[0].name
			// JSON.result.response_list[4].qu_res.result.response_list[0].schema.slots[0].normalized_word
//		{
//		    "word_type": "",
//		    "fuzzy_matches": [],
//		    "confidence": 0.8798008561134338,
//		    "length": 2,
//		    "name": "user_meeting",
//		    "original_word": "�¼�",
//		    "sub_slots": [],
//		    "session_offset": 0,
//		    "normalized_word": "�¼�",
//		    "begin": 8,
//		    "merge_method": "ADD"
//		}
			
			// JSON.result.response_list[4].qu_res.result.response_list[0].qu_res.lexical_analysis[1].term
//		[
//		    {
//		        "etypes": [
//		            "sys_time",
//		            "sys_time_day",
//		            "user_time",
//		            "user_time_or_period"
//		        ],
//		        "basic_word": [
//		            "3",
//		            "��",
//		            "31",
//		            "��"
//		        ],
//		        "weight": 0.46479764580726626,
//		        "term": "3��31��",
//		        "type": "sys_time"
//		    },
//		    {
//		        "etypes": [
//		            "user_name"
//		        ],
//		        "basic_word": [
//		            "��Ƽ"
//		        ],
//		        "weight": 0.2260260283946991,
//		        "term": "��Ƽ",
//		        "type": "user_name"
//		    },
//		    {
//		        "etypes": [],
//		        "basic_word": [
//		            "��"
//		        ],
//		        "weight": 0.08315032720565796,
//		        "term": "��",
//		        "type": "34"
//		    },
//		    {
//		        "etypes": [
//		            "user_meeting"
//		        ],
//		        "basic_word": [
//		            "�¼�"
//		        ],
//		        "weight": 0.2260260283946991,
//		        "term": "�¼�",
//		        "type": "user_meeting"
//		    }
//		]		
			
			// JSON.result.response_list[0].qu_res.lexical_analysis[2].type
			// JSON.result.response_list[0].qu_res.lexical_analysis[0].term
			String sType;
			switch(tag) {
				case slots:
					sType = getElementAsString(object, "name");
					break;
				case lexical_analysis:
					sType = getElementAsString(object, "type");
					break;
				default:
					return false;
			}
			if(sType==null || sType.isEmpty()) {
				return false;
			}
			
			Info info = context.info;
			if(info==null) {
				info = new Info();
				context.info = info;
			}
			if("user_time_or_period".equals(sType) || "sys_time".equals(sType)) {
				//ʱ��
				String value = getElementAsString(object, "normalized_word");
				if(value!=null && value.length()>0 && !value.equals(info.rawTime)) {
					info.rawTime = value;
					String sdfText;
					if( value.indexOf('|')>0) {
						value = value.replace('|', ' ');
						sdfText = "yyyy-MM-dd HH:mm:ss";
					}else {
						sdfText = "yyyy-MM-dd";
					}
					SimpleDateFormat sdf = new SimpleDateFormat(sdfText);
					if(value.length()<sdfText.length()) {
						log.debug("time value error:" + value);
					}else {
						if(value.length()>sdfText.length())value = value.substring(0, sdfText.length());
						try {
							info.time = sdf.parse(value);
						} catch (ParseException e) {
							log.debug("pasre time value error:" + value + "(" + e.getMessage() + ")");
						}
					}
				}else {
					value = getElementAsString(object, "term");
					if(value!=null && !value.isEmpty() && !context.inner) {
						//�ȴ�1�� ��ֹQPS����
						try {
							Thread.sleep(1000);
						} catch (InterruptedException e) {
						}
						Result result = this.getBaiduUnit(context.session_id, value);
						Context innerContext = new Context();
						innerContext.info = new Info();
						innerContext.query = value;
						innerContext.session_id = context.session_id;
						innerContext.result = result;
						innerContext.inner = true;
						Info innerInfo = this.parseLeave(innerContext);
						if(innerInfo.time!=null) {
							info.time = innerInfo.time;
							info.rawTime = value;
						}
						
					}
				}
				
			}else if("sys_unit".equals(sType)) {
				//�������
				String value = getElementAsString(object, "normalized_word");
				if(value==null||value.isEmpty())value = getElementAsString(object, "term");
				if(value!=null&&!value.isEmpty() && !value.equals(info.rawPeriod)) {
					//����
					double period = 0;
					if((value.indexOf("��")>=0)) {
						period += 0.5;
					}
					int p;;
					String text = value;
					if((p=text.indexOf("��"))>=0) {
						text = value.substring(0, p);
					}
					try {
						double days = Double.parseDouble(text);
						period += days;
					}catch(Exception ignore) {}
					
					info.rawPeriod = value;
					info.peroid = period;
				}

			}else if("user_meeting".equals(sType)) {
				//�������
				String value = getElementAsString(object, "normalized_word");
				if(value==null||value.isEmpty())value = getElementAsString(object, "term");
				if(value!=null&&!value.isEmpty() && !value.equals(info.type)) {
					info.type = value;
				}
			}else if("sys_per".equals(sType) || "user_name".equals(sType)) {
				//����
				//"sys_per"
				String value = getElementAsString(object, "normalized_word");
				if(value==null||value.isEmpty())value = getElementAsString(object, "term");
				if(value!=null&&!value.isEmpty() && !value.equals(info.person)) {
					info.person = value;
				}
			}else {
				return false;
			}
			return true;
		}
		
	}
	
	
	public static String getElementAsString(JsonObject object, String eleText) {
		JsonElement e  = getElement(object, eleText);
		return e==null?null:e.getAsString();
	}
	
	public static Long getElementAsLong(JsonObject object, String eleText) {
		JsonElement e  = getElement(object, eleText);
		return e==null?null:e.getAsLong();
	}
	
	public static JsonElement getElement(JsonObject object, String eleText) {
		JsonElement e = null;
		if (object != null && (e=object.get(eleText))!= null && !e.isJsonNull()){
			return e;
		}else {
			return null;
		}
	}
}
