package org.ydzy.rcs.display.bean;

public class DisplayBean {
    private String type;

    // ���ֻ���
    private String mdn;
    // �û��ֻ���
    private String phone;

    // Ӧ��Ψһ��ʶ
    private String accessTagNo;
    // �û���
    private String username;
    // sid
    private String sid;

    // ���ݲ�ͬ��ҵ�񳡾�·��
    private String driving;
    // ��ʶ�û��ͽ�ɫ
    public String id;
    public String chatbotid;

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getMdn() {
        return mdn;
    }

    public void setMdn(String mdn) {
        this.mdn = mdn;
    }

    public String getAccessTagNo() {
        return accessTagNo;
    }

    public void setAccessTagNo(String accessTagNo) {
        this.accessTagNo = accessTagNo;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getSid() {
        return sid;
    }

    public void setSid(String sid) {
        this.sid = sid;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getDriving() {
        return driving;
    }

    public void setDriving(String driving) {
        this.driving = driving;
    }

}
