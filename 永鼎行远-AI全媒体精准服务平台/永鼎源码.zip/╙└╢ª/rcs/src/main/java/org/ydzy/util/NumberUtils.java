package org.ydzy.util;

import java.security.SecureRandom;
import java.text.DecimalFormat;
import java.util.regex.Pattern;

public class NumberUtils {

    private static Pattern pattern = Pattern.compile("(-?\\d+\\.?\\d*)[Ee]{1}[\\+-]?[0-9]*");
    private static char[] CHAR_NUMS = {'0','7','5','4','8','2','9','1','3','6'};
    public static ThreadLocal<DecimalFormat> dsThreadLocal = ThreadLocal.withInitial(() -> new DecimalFormat("0"));

    //�ж������ַ����Ƿ�Ϊ��ѧ������
    public static boolean isENum(String input) {
        return pattern.matcher(input).matches();
    }

    public static String createSmsCode() {
        return createSmsCode(4);
    }

    public static String createSmsCode(int length) {
        StringBuilder smsCode = new StringBuilder();
        SecureRandom secureRandom = new SecureRandom();
        for (int i = 0; i < length; i++) {
            smsCode.append(CHAR_NUMS[secureRandom.nextInt(CHAR_NUMS.length)]);
        }
        return smsCode.toString();
    }

}
