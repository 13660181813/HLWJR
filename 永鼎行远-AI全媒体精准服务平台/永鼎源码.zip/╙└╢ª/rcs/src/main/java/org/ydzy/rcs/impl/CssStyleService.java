package org.ydzy.rcs.impl;

import com.google.gson.*;
import com.google.inject.Inject;
import com.google.inject.name.Named;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.ydzy.rcs.db.XmlSqlGenerator;
import org.ydzy.rcs.module.LoadProperties;
import org.ydzy.util.SqlUtil;
import org.ydzy.util.Util;

import javax.sql.DataSource;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * @author zxw
 * @create 2022/1/27
 */
public class  CssStyleService {
    private static final Logger log = LoggerFactory.getLogger(CssStyleService.class);
    private static volatile Map<String, Map<String, Object>>  cssStyle = new HashMap<>();

    @Inject
    @Named("rcsDb")
    private DataSource ds;

    @Inject(optional = true)
    @Named("cssStyle.cache.timeout")
    private long fileTimeOut = 60 * 60 * 24;

    /**
     * ������ʽjson����
     *
     * @param cssStyleId ��ʽID
     * @return
     */
    public String getCssStyleString(String cssStyleId) {
        Map<String, Object> map = cssStyle.get(cssStyleId);
        if (map == null || (long) map.get("timeOut") <= System.currentTimeMillis()) {
            loadCssSytleFromDB(cssStyleId, 1);
            map = cssStyle.get(cssStyleId);
            if (map == null)
                return null;
        }
        return (String) map.get("cssStyle");
    }

    /**
     * @param cssStyleId ��ʽ��Ƥ��ID
     * @return ��ʽ�ļ�URI
     */
    public String getCssStyleFileURI(String cssStyleId) {
        Map<String, Object> map = cssStyle.get(cssStyleId);
        if (map == null || (long) map.get("timeOut") <= System.currentTimeMillis()) {
            loadCssSytleFromDB(cssStyleId, 1);
            map = cssStyle.get(cssStyleId);
            if (map == null)
                return null;
        }
        String cssStylePath = (String) map.get("cssStylePath");
        if (!Util.isNull(cssStylePath) && cssStylePath.indexOf(".css") >= 0) {
            return cssStylePath;
        }
        return cssStylePath;
    }

    /**
     * @param cssStyleId ��ʽ��Ƥ��ID
     * @param type       ���ͣ�0Ƥ����1��ý�忨Ƭ��ʽ
     */
    private void loadCssSytleFromDB(String cssStyleId, int type) {
        String sqlId = "queryChatbotSkin";
        JsonObject dbParams = new JsonObject();
        if (!Util.isNull(cssStyleId)) {
            dbParams.addProperty("id", Integer.parseInt(cssStyleId));
        }
        dbParams.addProperty("type", type);
        String sql = XmlSqlGenerator.getSqlByJson(sqlId, null, dbParams);
        try {
            JsonArray array = SqlUtil.queryForJson(ds, sql);
            if (array == null) {
                return;
            }
            for (JsonElement el : array) {
                if (!el.isJsonNull() && el.isJsonObject()) {
                    String skinStyle = Util.getElementAsString(el.getAsJsonObject(), "skinStyle");
                    if (!Util.isNull(skinStyle)) {
                        Map<String, Object> map = new HashMap<>();
                        skinStyle = skinStyle.replaceAll("��", ",");
                        map.put("cssStyle", skinStyle);
                        map.put("cssStylePath", createCssFile(skinStyle, cssStyleId));
                        map.put("timeOut", System.currentTimeMillis() + fileTimeOut);
                        this.cssStyle.put(cssStyleId, map);
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private String createCssFile(String cssStyle, String cssStyleId) {
        if (Util.isNull(cssStyle)) return null;
        JsonElement jsonElement = JsonParser.parseString(cssStyle);

        String cssStyleStr = buildCssStyleStr(jsonElement);
        if (Util.isNull(cssStyleStr))
            log.warn("css is null, cssStyleId {}", cssStyleId);

        String cssFilePath = LoadProperties.systemProperties.getProperty("cssStyle.filePath");
        String webURL = LoadProperties.systemProperties.getProperty("cssStyle.WebUrl");
        String fileName = cssStyleId + "-" + UUID.randomUUID() + ".css";
        try {
            if (log.isDebugEnabled()) log.debug("createCssFile cssStyleId is {}", cssStyleId);
            Path path = Files.write(Path.of(cssFilePath + File.separator + fileName), cssStyleStr.getBytes());
            return webURL + "/css/" + path.getFileName().toString();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return "";
    }

    /**
     * @param jsonElement
     * @return
     */
    private String buildCssStyleStr(JsonElement jsonElement) {
        StringBuilder sb = new StringBuilder();
        if (jsonElement == null || jsonElement.isJsonNull() || !jsonElement.isJsonObject()) {
            return null;
        }
        sb.append("@charset \"utf-8\";\n");
        sb.append("/* CSS Document */\n");
        JsonObject message = jsonElement.getAsJsonObject();
        sb.append("message {\n");
        message.entrySet().forEach(el -> {
            if (el.getValue().isJsonPrimitive()) {
                sb.append(el.getKey() + ": " + Util.getElementAsString(message, el.getKey()) + ";\n");
            }
        });
        sb.append("}\n");

        JsonElement contentEl = message.get("content");
        if (contentEl != null && !contentEl.isJsonNull() && jsonElement.isJsonObject()) {
            JsonObject content = contentEl.getAsJsonObject();
            JsonElement titleEl = content.get("title");
            if (titleEl != null && !titleEl.isJsonNull() && titleEl.isJsonObject()) {
                JsonObject title = titleEl.getAsJsonObject();
                sb.append("message.content.tilte {\n");
                title.entrySet().forEach(el -> {
                    if (el.getValue().isJsonPrimitive()) {
                        sb.append(el.getKey() + ": " + Util.getElementAsString(title, el.getKey()) + ";\n");
                    }
                });
                sb.append("}\n");
            }
            JsonElement descriptionEl = content.get("description");
            if (descriptionEl != null && !descriptionEl.isJsonNull() && descriptionEl.isJsonObject()) {
                JsonObject description = descriptionEl.getAsJsonObject();
                sb.append("message.content.description {\n");
                description.entrySet().forEach(el -> {
                    if (el.getValue().isJsonPrimitive()) {
                        sb.append(el.getKey() + ": " + Util.getElementAsString(description, el.getKey()) + ";\n");
                    }
                });
                sb.append("}\n");
            }
            JsonElement suggestionsEl = content.get("suggestions");
            if (suggestionsEl != null && !suggestionsEl.isJsonNull() && suggestionsEl.isJsonObject()) {
                JsonObject suggestions = suggestionsEl.getAsJsonObject();
                sb.append("message.content.suggestions {\n");
                suggestions.entrySet().forEach(el -> {
                    if (el.getValue().isJsonPrimitive()) {
                        sb.append(el.getKey() + ": " + Util.getElementAsString(suggestions, el.getKey()) + ";\n");
                    }
                });
                sb.append("}\n");
            }
        }
        return sb.toString();
    }

    public JsonArray list(JsonObject params) {
        // TODO: 2022/2/18 ҵ���߼�
        String queryID = "queryChatbotSkinUnique";
        String sql = XmlSqlGenerator.getSqlByJson(queryID, null, params);
        JsonArray array = null;
        try {
            array = SqlUtil.queryForJson(ds, sql);
        } catch (Exception e){
        }
        Map<Integer, JsonObject> map = new HashMap<>();
        assert array != null;
        for (JsonElement e : array) {
            JsonObject object = e.getAsJsonObject();
            if(!map.containsKey(object.get("id").getAsInt()))
                map.put(object.get("id").getAsInt(),object);
        }
        JsonArray array1 = new JsonArray();
        for(Map.Entry<Integer, JsonObject> entry : map.entrySet()) {
            array1.add(entry.getValue());
        }
        return array1;
    }

    public JsonArray updateCssStyleByRcsUser(JsonObject params) {
        String queryId = "updateRcsUserField";
        String sql = XmlSqlGenerator.getSqlByJson(queryId, null, params);
        try {
            SqlUtil.updateRecords(ds, sql);
        }catch (Exception e){
        }
        JsonArray object = null;
        String queryId1 = "queryChatbotSkin";
        String skinId = Util.getElementAsString(params, "skinId");
        JsonObject object1 = new JsonObject();
        object1.addProperty("id", skinId);
        String sql1 = XmlSqlGenerator.getSqlByJson(queryId1, null, object1);
        try {
            object = SqlUtil.queryForJson(ds, sql1);
        }catch (Exception e){
        }
        return object;

    }
}
