package org.ydzy.bot;

import java.time.format.DateTimeFormatter;
import java.util.Map;

public class AuthHuaweiWsse implements IAuthorize {
	public static final String KEY_AUTH_HUAWEI_WSSE = KEY_AUTH + "huaweiwsse";

	@Override
	public String attach(String url, Map<String, Object> headers, BotInfo botInfo) {
		String appid = botInfo.getAppId();
		String password = botInfo.getAppKey(); // botInfo.token
		if(appid!=null && !appid.isEmpty() && password!=null) {
			String authValue;
			authValue = this.getWsse(appid, password);
			headers.put("X-WSSE: ", authValue);
		}
		return url;
	}
	
	public String getWsse(String username, String password) {
		
		String stTime = DateTimeFormatter.ISO_INSTANT.format(java.time.Instant.now());
		String stNonce;
		stNonce = java.util.UUID.randomUUID().toString().replace("-", "").toUpperCase();
		String appSecret = password;
		String stUserName = username;
		String stCombine = stNonce + stTime + appSecret;
		String stPassWordDigiest = SHA256Encrypt(stCombine);
	    String stXsse = "UsernameToken Username=" + "\"" + stUserName + "\"" + "," + "PasswordDigest=" + "\""
	            + stPassWordDigiest + "\"" + "," + "Nonce=" + "\"" + stNonce + "\"" + "," + "Created=" + "\"" + stTime
	            + "\"";
	    return stXsse;
	}
	
	public static String SHA256Encrypt(String strSrc){
		java.security.MessageDigest msgDigest = null;
		try{
		    //SHA-256 encrypt 
		    msgDigest = java.security.MessageDigest.getInstance("SHA-256");
			;
		}catch(java.security.NoSuchAlgorithmException e){
			throw new RuntimeException("SHA-256 unsuport", e);
		}

	    msgDigest.update(strSrc.getBytes());
	    byte[] buff = msgDigest.digest();
	    String string = org.apache.commons.codec.binary.Base64.encodeBase64String(buff);
	    return string;
	}

}
