package org.ydzy.bot.handler;

import org.eclipse.jetty.server.HandlerContainer;
import org.eclipse.jetty.server.handler.ContextHandler;

public class ContextAliasHandler extends ContextHandler {
	public ContextAliasHandler(HandlerContainer parent, String contextPath) {
		super(parent, contextPath);
		this.setAllowNullPathInfo(true);
		this.setDisplayName("Suffix(" + contextPath + ")");
	}

	public ContextAliasHandler(String contextPath) {
		this(null, contextPath);
	}

	public ContextAliasHandler() {
		 this(null, null);
	}

	private String aliasPath = null;
	public String getAliasPath() {
		return aliasPath;
	}
	public void setAliasPath(String aliasPath) {
		this.aliasPath = aliasPath;
	}

	@Override
	public boolean checkContextPath(String uri) {
		String contextPath = getAliasPath();
		if (contextPath!=null && contextPath.length() > 1)
		{
			if (uri.startsWith(contextPath)) return true;
		}
		return super.checkContextPath(uri);
	}

}
