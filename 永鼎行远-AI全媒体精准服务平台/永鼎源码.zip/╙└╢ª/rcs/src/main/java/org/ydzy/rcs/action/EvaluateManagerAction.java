package org.ydzy.rcs.action;

import com.google.gson.*;
import com.google.inject.Inject;
import com.google.inject.name.Named;

import org.ydzy.handler.BaseRcsContextProvidor;
import org.ydzy.handler.RcsSession;
import org.ydzy.rcs.db.XmlSqlGenerator;
import org.ydzy.rcs.db.XmlSqlGenerator.innerSql;
import org.ydzy.rcs.module.LoadProperties;
import org.ydzy.rcs.util.IShortUrl;
import org.ydzy.thirdparty.PostDataInter;
import org.ydzy.thirdparty.gz110.entity.InstantBean;
import org.ydzy.thirdparty.gz110.entity.OrderSessions;
import org.ydzy.thirdparty.gz110.entity.OrdersInfo;
import org.ydzy.thirdparty.util.MsgUtils;
import org.ydzy.util.ParamUtils;
import org.ydzy.util.SqlUtil;
import org.ydzy.util.Util;

import javax.sql.DataSource;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

/**
 * @author lirui
 * @Date 2021/6/23 12:33 ����
 */
public class EvaluateManagerAction {
    static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(EvaluateManagerAction.class);
    @Inject
    @Named("rcsDb")
    DataSource ds;
    static Gson gson = new Gson();

    @Inject
    IShortUrl shortUrl;

    public JsonObject queryEvaluateByNo(String serviceno, String servicetype) {
        JsonObject obj = new JsonObject();
        if (Util.isNull(serviceno))
            return obj;
        String sqlId = "qryEvaluateByNo";
        try {
            Map<String, Object> param = new HashMap<>();
            param.put("serviceno", serviceno);
            param.put("servicetype", servicetype);
            String sql = XmlSqlGenerator.getSqlstrByMap(sqlId, param);
            JsonArray jsonArray = SqlUtil.queryForJson(ds, sql);
            if (jsonArray.size() == 0)
                return obj;
            for (JsonElement ele : jsonArray) {
                JsonObject evalObj = ele.getAsJsonObject();
                if (!obj.has("serviceno")) {
                    String evaluateid = Util.getElementAsString(evalObj, "evaluateid");
                    String servicetime = Util.getElementAsString(evalObj, "servicetime");
                    String score = Util.getElementAsString(evalObj, "score");
                    String remark = Util.getElementAsString(evalObj, "remark");
                    String suggest = Util.getElementAsString(evalObj, "suggest");
                    String evaluator = Util.getElementAsString(evalObj, "evaluator");
                    String anonymous = Util.getElementAsString(evalObj, "anonymous");
                    String sid = Util.getElementAsString(evalObj, "sid");
                    String nick = Util.getElementAsString(evalObj, "nick");
                    String optype = Util.getElementAsString(evalObj, "optype");
                    obj.addProperty("evaluateid", evaluateid);
                    obj.addProperty("servicetype", servicetype);
                    obj.addProperty("servicetime", servicetime);
                    obj.addProperty("score", score);
                    obj.addProperty("remark", remark);
                    obj.addProperty("suggest", suggest);
                    obj.addProperty("evaluator", evaluator);
                    obj.addProperty("anonymous", anonymous);
                    obj.addProperty("sid", sid);
                    obj.addProperty("nick", nick);
                    obj.addProperty("optype", optype);
                    obj.add("addtionScores", evalObj.get("addtionScores"));
                }
                JsonArray taglist = obj.getAsJsonArray("tags");
                JsonArray tagnames = obj.getAsJsonArray("tagnames");
                if (taglist == null) {
                    taglist = new JsonArray();
                    obj.add("tags", taglist);
                }
                if (tagnames == null) {
                    tagnames = new JsonArray();
                    obj.add("tagnames", tagnames);
                }
                String tagid = Util.getElementAsString(evalObj, "tagid");
                String tagname = Util.getElementAsString(evalObj, "tagname");
                if (!Util.isNull(tagid))
                    taglist.add(tagid);
                if (!Util.isNull(tagname))
                    tagnames.add(tagname);
            }
        } catch (Exception e) {
            log.error("queryEvaluateByNo error. sqlId: {}, serviceno:{}" + sqlId, serviceno, e);
        }
        return obj;
    }

    public void calcQRCodeUrl(JsonObject resultObj, JsonObject reqData) {
        Map<String, Object> tmpParams = gson.fromJson(gson.toJson(reqData), Map.class);
        Map<String, String> params = new HashMap<>();
        for (Map.Entry<String, Object> entry : tmpParams.entrySet()) {
            params.put(entry.getKey(), Util.toString(entry.getValue()));
        }
        params.put("sid", Util.getElementAsString(resultObj, "sid"));
        params.put("evaluator", Util.getElementAsString(resultObj, "evaluator"));
        params.put("webUiFormUrl", LoadProperties.systemProperties.getProperty("webUiFormUrl"));
        String evaluateUrl = ParamUtils.formatValues("{webUiFormUrl}/evaluate?banned={banned}&chatbotid={chatbotid}&configid={configid}&evaluator={evaluator}&msgId={msgId}&optype={optype}&phone={phone}&serviceName={serviceName}&servicetype={servicetype}&sid={sid}&target={target}&targetName={targetName}", params);
        String tmpUrl = shortUrl.convert(evaluateUrl);
        if (!Util.isNull(tmpUrl)) {
            evaluateUrl = tmpUrl;
        }
        resultObj.addProperty("qrcodeUrl", evaluateUrl);
    }

    public boolean updateEvaluate(Map<String, Object> params) {
        String sqlId = "updateEvaluate";
        innerSql sql = XmlSqlGenerator.getSqlByMap(sqlId, params);
        try {
            return SqlUtil.updateRecords(ds, sql.exeSql,sql.sqlParams.toArray());
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return false;
    }

    public boolean delEvaluateTagRelation(String evaluateid) {
        String sqlId = "delEvaluateTagsRelation";
        Map<String, Object> param = new HashMap<>();
        param.put("evaluateid", evaluateid);
        innerSql sql = XmlSqlGenerator.getSqlByMap(sqlId, param);
        try {
            return SqlUtil.updateRecords(ds, sql.exeSql,sql.sqlParams.toArray());
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return false;
    }

    public long insertEvaluate(Map<String, Object> params) {
        String sqlId = "insertEvaluate";
        innerSql sql = XmlSqlGenerator.getSqlByMap(sqlId, params);
        try {
            return SqlUtil.insert(ds, sql.exeSql,sql.sqlParams.toArray());
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return -1;
    }

    public boolean insertEvaluateTags(long evaluateid, JsonArray tagids) {
        if (tagids == null || tagids.isJsonNull())
            return true;
        Map<String, Object> params = new HashMap<>();
        String sqlId = "insertEvaluateTags";
        StringBuffer sqls = new StringBuffer();
        tagids.forEach(jsonElement -> {
            if (jsonElement != null && !jsonElement.isJsonNull()) {
                params.put("tagid", jsonElement.getAsString());
                params.put("evaluateid", evaluateid);
                String sql = XmlSqlGenerator.getSqlstrByMap(sqlId, params);
                sqls.append(sql).append(";");
            }
        });
        try {
            return SqlUtil.updateRecords(ds, sqls.toString());
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return false;
    }

    public synchronized JsonArray insertTags(String servicetype, String level, JsonArray newTags) {
        if (evalTagsMap == null)
            getEvalTags();
        JsonArray array = new JsonArray();
        String sqlId = "insertNewTags";
        Map<String, Object> params = new HashMap<>();
        for (JsonElement jsonElement : newTags) {
            JsonObject obj = jsonElement.getAsJsonObject();
            String parentid = Util.getElementAsString(obj, "parentid");
            String tagname = Util.getElementAsString(obj, "tagname");
            if (evalTagsMap.get(servicetype) != null && evalTagsMap.get(servicetype).contains(tagname))
                continue;
            params.put("parentid", parentid);
            params.put("tagname", tagname);
            params.put("servicetype", servicetype);
            params.put("level", level);
            innerSql sql = XmlSqlGenerator.getSqlByMap(sqlId, params);
            try {
                long tagid = SqlUtil.insert(ds, sql.exeSql,sql.sqlParams.toArray());
                array.add(tagid);
                evalTagsMap.get(servicetype).add(tagname);
            } catch (SQLException e) {
                log.error("insert new tag {} error.", tagname, e);
            }
        }
        return array;
    }

    private static Map<String, Set<String>> evalTagsMap = null;

    public void getEvalTags() {
        try {
            if (evalTagsMap == null)
                evalTagsMap = new HashMap<>();
            String sqlId = "qryAllEvalTags";
            String sql = XmlSqlGenerator.getSqlstr(sqlId);
            JsonArray array = SqlUtil.queryForJson(ds, sql);
            for (JsonElement ele : array) {
                JsonObject obj = ele.getAsJsonObject();
                String servicetype = Util.getElementAsString(obj, "servicetype");
                String tagname = Util.getElementAsString(obj, "tagname");
                evalTagsMap.computeIfAbsent(servicetype, k -> new HashSet<>());
                evalTagsMap.get(servicetype).add(tagname);
            }
        } catch (SQLException e) {
            log.error("query all eval tags error.");
        }
    }
    @Inject
	private BaseRcsContextProvidor contextProvidor = null;
    @Inject
    private MsgUtils msgUtil;


    public void post2OtherApi(String target, JsonObject param) {
        if ( param == null || param.isJsonNull()) {
            log.warn("post evaluate failed. post url is null");
            return;
        }
        try {
            param.remove("servicetype");
            param.remove("nick");
            param.remove("evaluateid");
            param.remove("level");
            if (!param.has("evaluator"))
                param.addProperty("evaluator", "");
            if (!param.has("newtags"))
                param.add("newtags", new JsonArray());
//            String targetName = Util.getElementAsString(param, "sid");
//            if (!param.has("targetName"))
//                param.addProperty("targetName", targetName);
//            param.remove("sid");
            
            String targetName = Util.getElementAsString(param, "sid");
           
            if (!param.has("targetName"))
            	param.addProperty("targetName", targetName);
            param.remove("sid");
            String phone=Util.getElementAsString(param, "evaluator");;
            
            String url=Util.getElementAsString(param, "url");
            Map<String, String> paramMap = Util.buildQueryParams(url);
            String  sid =paramMap.get("sid");
            RcsSession rcssession=contextProvidor.newBaseRcsContext().getSession(sid);
            if(rcssession!=null)
            {
            	String chatbotid=Util.toString(rcssession.get("chatbotid"));
            	RcsSession targetrcssession=contextProvidor.newBaseRcsContext().getSession(phone,chatbotid);
            	InstantBean bean = msgUtil.getInstantBean(phone, chatbotid);;
            	String tid=targetName;
            	if(!Util.isNull(targetName)&&!targetName.startsWith("YDXY")&&!Util.isNull(phone))
            	{
            		tid=targetName+"_"+phone;
            	}
            	if(!rcssession.containsKey("driving"))
            		rcssession.put("driving", target);
            	if(!targetrcssession.containsKey("driving") || Util.isNull(Util.toString(targetrcssession.get("driving"))))
            		targetrcssession.put("driving", target);
            	OrdersInfo order=msgUtil.getOrdersInfo(tid, true, bean, phone, chatbotid);
            	if(order !=null  && order.getSessions()!=null)
            	{
            		JsonArray arrayResult=(JsonArray) order.bodyEle.get("evaluate");
            		if(arrayResult==null)
            			arrayResult=new JsonArray();
            		arrayResult.add(param);
            		order.bodyEle.add("evaluate", arrayResult);
            		for(OrderSessions s:order.getSessions())
            		{
            			if(s.sid.equals(tid)) {
            				target=s.skillGroup;
            				// status 5 ��ʾ���յ�����
            				msgUtil.updateOrderSessionStatus(phone, tid, chatbotid, 5, System.currentTimeMillis());
            			}
            		}
            		param.addProperty("_tid", tid); 
            		param.addProperty("_chatbotid", chatbotid); 
            		param.addProperty("_phone", phone); 
            	}
            	postData.post2OtherApi(target, param,null);
            }
        } catch (Exception e) {
            log.error("post evaluate data to  failed.", e);
        }
    }
    @Inject
    PostDataInter postData;
   
    public JsonObject getEvaluateTagsByServiceType(String serviceType) {
        String sqlId = "queryEvaluateTagsByServiceType";
        String sql = "";
        JsonObject param = new JsonObject();
        param.addProperty("servicetype", serviceType);
        JsonObject object = new JsonObject();
        object.addProperty("servicetype", serviceType);
        try {
            sql = XmlSqlGenerator.getSqlByJson(sqlId, null, param);
            JsonArray array = SqlUtil.queryForJson(ds, sql);
            Map<String, JsonObject> ratmap = new HashMap<>();
            Map<String, Map<String, JsonObject>> tagmap = new HashMap<>();
            for (JsonElement ele : array) {
                JsonObject rowObject = ele.getAsJsonObject();
                String rating = Util.getElementAsString(rowObject, "rating");
                JsonObject baseTagObject = ratmap.get(rating);
                if (baseTagObject == null) {
                    baseTagObject = new JsonObject();
                    ratmap.put(rating, baseTagObject);
                }
                baseTagObject.addProperty("rating", rating);
                if (!baseTagObject.has("tagnames")) {
                    JsonArray tagArray = new JsonArray();
                    baseTagObject.add("tagnames", tagArray);
                }
                String parentid = Util.getElementAsString(rowObject, "parentid");
                String parenttag = Util.getElementAsString(rowObject, "parenttag");
                String tagid = Util.getElementAsString(rowObject, "tagid");
                String tagname = Util.getElementAsString(rowObject, "tagname");
                Map<String, JsonObject> tagObjectMap = tagmap.get(rating);
                JsonObject tagObject = null;
                if (tagObjectMap == null) {
                    tagObjectMap = new HashMap<>();
                    tagObject = new JsonObject();
                    tagObjectMap.put(parentid, tagObject);
                    tagmap.put(rating, tagObjectMap);
                }
                tagObject = tagObjectMap.get(parentid);
                if (tagObject == null) {
                    tagObject = new JsonObject();
                    tagObjectMap.put(parentid, tagObject);
                }
                tagObject.addProperty("parentid", parentid);
                tagObject.addProperty("parenttag", parenttag);
                JsonArray subTagArray = tagObject.getAsJsonArray("subtag");
                if (subTagArray == null) {
                    subTagArray = new JsonArray();
                    tagObject.add("subtag", subTagArray);
                }
                JsonObject subTagObj = new JsonObject();
                subTagObj.addProperty("tagid", tagid);
                subTagObj.addProperty("tagname", tagname);
                subTagObj.addProperty("operator", "0");
                subTagArray.add(subTagObj);
            }
            ratmap.forEach((s, jsonObject) -> {
                Map<String, JsonObject> jsonmap = tagmap.get(s);
                jsonmap.forEach((s1, jsonObject1) -> {
                    jsonObject.getAsJsonArray("tagnames").add(jsonObject1);
                });
                object.add(s, jsonObject);
            });
        } catch (Exception e) {
            log.error("query EvaluateTags By ServiceType error. sqlId:{}", sqlId, e);
        }
        return object;
    }

    public boolean editEvalTags(JsonObject tagObject) {
        try {
            String servicetype = Util.getElementAsString(tagObject, "servicetype");
            JsonObject cObject = tagObject.getAsJsonObject("-1"); //��
            JsonObject bObject = tagObject.getAsJsonObject("0"); //��
            JsonObject aObject = tagObject.getAsJsonObject("1"); //��
            String sqls = getEditTagsSql(servicetype, "-1", cObject) +
                    getEditTagsSql(servicetype, "0", bObject) +
                    getEditTagsSql(servicetype, "1", aObject);
            return SqlUtil.updateRecords(ds, sqls);
        } catch (Exception e) {
            log.error(e.getMessage());
        }
        return false;
    }

    private String getEditTagsSql(String servicetype, String rating, JsonObject object) {
        JsonArray tagsArray = object.getAsJsonArray("tagnames");
        StringBuilder sqls = new StringBuilder();
        tagloop : for(JsonElement ele : tagsArray) {
            JsonObject tagObject = ele.getAsJsonObject();
            String parentOperator = Util.getElementAsString(tagObject, "operator");
            String parentid = Util.getElementAsString(tagObject, "parentid");
            switch (parentOperator) {
                //ɾ��
                case "-1" -> {
                    JsonObject params = new JsonObject();
                    params.addProperty("servicetype", servicetype);
                    params.addProperty("tagid", parentid);
                    params.addProperty("rating", rating);
                    String sql = XmlSqlGenerator.getSqlByJson("deleteParentEvalTagId", null, params);
                    sqls.append(sql).append(";");
                    continue tagloop;
                }
                //����
                case "1" -> {
                    String parenttag = Util.getElementAsString(tagObject, "parenttag");
                    String sql = XmlSqlGenerator.getSqlstr("addEvalTag", "-1", parenttag, servicetype, rating);
                    try {
                        long id = SqlUtil.insert(ds, sql);
                        parentid = id + "";
                    } catch (Exception e) {
                       log.error("add eval tag error.", e);
                       continue tagloop;
                    }
                }
                //�޸�
                case "2" -> {
                    String parenttag = Util.getElementAsString(tagObject, "parenttag");
                    String sql = XmlSqlGenerator.getSqlstr("editEvaluateTag", parenttag, parentid);
                    sqls.append(sql).append(";");
                }
            }
            JsonArray subTagArray = tagObject.getAsJsonArray("subtag");
            for(JsonElement subele : subTagArray) {
                JsonObject subtagObject = subele.getAsJsonObject();
                String tagid = Util.getElementAsString(subtagObject, "tagid");
                String tagname = Util.getElementAsString(subtagObject, "tagname");
                String operator = Util.getElementAsString(subtagObject, "operator");
                switch (operator) {
                    case "-1" -> {
                        String sql = XmlSqlGenerator.getSqlstr("delEvalTag",tagid, tagid);
                        sqls.append(sql).append(";");
                    }
                    case "1" -> {
                        String sql = XmlSqlGenerator.getSqlstr("addEvalTag",parentid,tagname,servicetype,rating);
                        sqls.append(sql).append(";");
                    }
                }
            }
        }
        return sqls.toString();
    }

    private boolean delEvalTag(String tagid) {
        String sqlId = "delEvalTag";
        String sql = "";
        try {
            JsonObject param = new JsonObject();
            param.addProperty("tagid", tagid);
            sql = XmlSqlGenerator.getSqlByJson(sqlId, null, param);
            return SqlUtil.updateRecords(ds, sql);
        } catch (Exception e) {
            log.error("delete evaluate tag error.sqlid:{}", sqlId, e);
        }
        return false;
    }

    private boolean addEvalTag(JsonObject tagObject) {
        String sqlId = "addEvalTag";
        try {
            String sql = XmlSqlGenerator.getSqlByJson(sqlId, null, tagObject);
            return SqlUtil.updateRecords(ds, sql);
        } catch (Exception e) {
            log.error("add eval tag error.sqlid:{}", sqlId, e);
        }
        return false;
    }

    public JsonArray evaluateCountByChatbot(JsonObject params) {
        JsonArray arary = new JsonArray();
        int intervalDay = params.get("intervalDay").getAsInt();
        if (intervalDay > 31)
            intervalDay = 31;
        String dateFormat = "%m-%d";
        String sqlid = "evaluateCountByChatbot";
        if (intervalDay == 1) {
            dateFormat = "%H";
            sqlid = "evaluateCountByChatbotHour";
        }
        List<String> days = getIntervalDay(intervalDay);
        params.addProperty("intervalDay", intervalDay);
        params.addProperty("dateFormat", dateFormat);
        try {
            String sql = XmlSqlGenerator.getSqlByJson(sqlid, null, params);
            JsonArray araryRs = SqlUtil.queryForJson(ds, sql);
            if (araryRs.size() < days.size()) {
                loop:
                for (String day : days) {
                    for (JsonElement element : araryRs) {
                        JsonObject o = element.getAsJsonObject();
                        String date = Util.getElementAsString(o, "date");
                        if (date.equals(day)) {
                            arary.add(o);
                            continue loop;
                        }
                    }
                    JsonObject emptyObject = new JsonObject();
                    emptyObject.addProperty("date", day);
                    emptyObject.addProperty("sumScore", "0");
                    emptyObject.addProperty("avgScore", "0");
                    emptyObject.addProperty("ct", "0");
                    arary.add(emptyObject);
                }
            }
//            jsonArray.forEach(jsonElement -> {
//                JsonObject object = jsonElement.getAsJsonObject();
//                String date = Util.getElementAsString(object, "date");
//                String ct = Util.getElementAsString(object, "ct");
//                String avgScore = Util.getElementAsString(object, "avgScore");
//                String sumScore = Util.getElementAsString(object, "sumScore");
//            });
            Calendar calendar = Calendar.getInstance();
            calendar.set(Calendar.DAY_OF_YEAR, calendar.get(Calendar.DAY_OF_YEAR) - 1);
        } catch (Exception e) {
            log.error("evaluateCountByChatbot error.", e);
        }
        return arary;
    }

    DateTimeFormatter formatter_MMdd = DateTimeFormatter.ofPattern("MM-dd");

    private List<String> getIntervalDay(int intervalDay) {
        List<String> days = new ArrayList<>();

        if (intervalDay == 1) {
            for (int i = 0; i < 24; i++) {
                String hour = "" + i;
                if (i < 10)
                    hour = "0" + i;
                days.add(hour);
            }
            return days;
        }

        LocalDate localDate = LocalDate.now();
        LocalDate afterDate = localDate.minusDays(intervalDay);
        // ��ȡ������
        List<LocalDateTime> localDateTimes = new ArrayList<>(intervalDay);
        for (LocalDate currentdate = afterDate; currentdate.isBefore(localDate) || currentdate.isEqual(localDate); currentdate = currentdate.plusDays(1)) {
            localDateTimes.add(LocalDateTime.of(currentdate.getYear(), currentdate.getMonth(), currentdate.getDayOfMonth(), 0, 0));
        }
        localDateTimes.forEach(localDateTime -> {
            days.add(localDateTime.format(formatter_MMdd));
        });
        return days;
    }

    public JsonArray evalSumScore24H(JsonObject params) {
        String sqlId = "evalSumScore24H2";
        Map<String, List<JsonObject>> resultMap = new LinkedHashMap<>();
        Map<String, JsonObject> nullServiceMap = new LinkedHashMap<>();
        for (int i = 0; i < 24; i++) {
            String key;
            if (i < 10)
                key = "0" + i;
            else
                key = i + "";
            resultMap.put(key + "ʱ", new ArrayList<>());
        }
        try {
            String sql = XmlSqlGenerator.getSqlByJson(sqlId, null, params);
            JsonArray result = SqlUtil.queryForJson(ds, sql);
            if (result.size() > 0) {
                result.forEach(jsonElement -> {
                    JsonObject newObject = new JsonObject();
                    JsonObject object = jsonElement.getAsJsonObject();
                    String serviceName = Util.getElementAsString(object, "servicename");
                    String date = Util.getElementAsString(object, "date");

                    String sumScore = Util.getElementAsString(object, "sumScore");
                    String avgScore = Util.getElementAsString(object, "avgScore");
                    String ct = Util.getElementAsString(object, "ct");
                    ct = Util.isNull(date) ? "0" : ct;
                    sumScore = Util.isNull(sumScore) ? "0.00" : sumScore;
                    avgScore = Util.isNull(avgScore) ? "0.00" : avgScore;
                    newObject.addProperty("serviceName", serviceName);
                    newObject.addProperty("date", date);
                    newObject.addProperty("sumScore", sumScore);
                    newObject.addProperty("avgScore", avgScore);
                    newObject.addProperty("ct", ct);
                    if (!Util.isNull(date)) {
                        List<JsonObject> list = resultMap.computeIfAbsent(date, k -> new ArrayList<>());
                        list.add(newObject);
                    }
                    if (!nullServiceMap.containsKey(serviceName)) {
                        if (!Util.isNull(date)) {
                            JsonObject emptyObject = new JsonObject();
                            emptyObject.addProperty("serviceName", serviceName);
                            emptyObject.addProperty("date", "");
                            emptyObject.addProperty("sumScore", "");
                            emptyObject.addProperty("avgScore", "");
                            emptyObject.addProperty("ct", "0");
                            nullServiceMap.put(serviceName, emptyObject);
                        } else
                            nullServiceMap.put(serviceName, newObject);
                    }
                });
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        JsonObject emptyServiceObject = new JsonObject();
        JsonObject result = new JsonObject();
        resultMap.forEach((s, jsonObjects) -> {
        });
        Gson gson = new Gson();
        return gson.toJsonTree(resultMap).getAsJsonArray();
    }
}
