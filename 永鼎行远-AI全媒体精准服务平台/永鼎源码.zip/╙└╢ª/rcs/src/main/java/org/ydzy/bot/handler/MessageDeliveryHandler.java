package org.ydzy.bot.handler;
import java.io.IOException;
import java.nio.charset.Charset;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Map;

import javax.sql.DataSource;

import org.eclipse.jetty.server.Request;
import org.ydzy.bot.BotUtil;
import org.ydzy.handler.BaseHandler;
import org.ydzy.rcs.db.XmlSqlGenerator;
import org.ydzy.util.SqlUtil;
import org.ydzy.util.StreamsUtil;

import com.google.gson.Gson;
import com.google.inject.Inject;
import com.google.inject.name.Named;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
  * �й��ƶ�MAAP�ӿ�
3.6	״̬����֪ͨ
3.6.1	��Ϣ��;
���ڹٷ�CSPƽ̨��Chatbot���ͻ�ִ��Ϣ�ĳ�����
3.6.2	����
HTTPS��POST
URL��https://{callbackURL}/DeliveryInfoNotification/{chatbotURI}
 */
public  class MessageDeliveryHandler extends BaseBotHandler {
	private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(MessageDeliveryHandler.class);

	@Inject
	@Named("rcsDb")
	protected DataSource ds;
	Gson gson = new Gson();
	@Override
	public void handle(String target, Request baseRequest, HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException{
		baseRequest.setHandled(true);
//		BotInfo bi = null;
//		try {
//			bi = verifyChatbot(request, response);
//		}catch(VerifyError e) { 
//			response.setStatus(HttpServletResponse.SC_FORBIDDEN);
//			response.setContentType("application/json");
//			JsonObject jo = new JsonObject();
//			jo.addProperty("errorMsg", e.getMessage());
//			// Write back response
//			response.getWriter().println(jo.toString());
//			log.debug("Sinagure error(" + e.getMessage() + "!");
//			return;
//		}
		String address=BaseHandler.getIpAddress(request);
		// Content-Type: text/xml; charset=utf-8
		String contentType = request.getContentType();
		if(contentType==null)contentType="text/xml";
		String body = StreamsUtil.copyToString(request.getInputStream(), Charset.forName("UTF-8"));
		if(log.isDebugEnabled())log.debug(",receive {} from remoteAddr {}  ", body, address);
		String code = null,msg = null;
		if(contentType.indexOf("xml")>0) {
			Map<String,String> map = BotUtil.xml2Map(body, "deliveryInfo");
			if(map!=null && map.size()>0) {
				if(ds!=null) {
					String now = LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME).replace('T', ' ');
					map.put("deliveryTime", now);
					map.put("action_status", String.valueOf(map.get("deliveryStatus")).indexOf("Delivered")>=0?"1":"0");
					String sql = XmlSqlGenerator.getSqlByJson("setRecordLogsStatus", "", gson.toJsonTree(map).getAsJsonObject());
					try {
						SqlUtil.updateRecords(ds, sql);
					} catch (SQLException e1) {
						log.error("Insert log error,%s", sql, e1);
					}
				}
			}else {
				code = "2001";
				msg = "No deliveryInfo message found";
			}
		}else {
			code = "2002";
			msg = "Unknow contentType:" + contentType;
		}
		if(code==null) {
			code = "0";
			msg = "success";
		}
		String resBody = resBodyJson(code, msg, null);
		sendResponse(address, resBody, HttpServletResponse.SC_OK, request, response);
	}

}