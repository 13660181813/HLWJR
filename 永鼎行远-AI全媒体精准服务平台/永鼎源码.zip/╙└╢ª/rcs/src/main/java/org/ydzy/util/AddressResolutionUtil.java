package org.ydzy.util;
 
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.eclipse.jetty.util.resource.Resource;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonSyntaxException;
 
public class AddressResolutionUtil {
	
	static  Map<String,String> provinces=new HashMap<String, String>();
	static  Map<String,Map<String,String>> citys=new HashMap<String, Map<String,String>>();
	static  Map<String,Map<String,String>> country=new HashMap<String, Map<String,String>>();
	static  Map<String,Map<String,String>> town=new HashMap<String, Map<String,String>>();
	public static JsonObject readJsonObjectFromFile(String file)
	{
		try {
			JsonObject	object= JsonParser.parseString(new String(Files.readAllBytes(Path.of(Resource.newSystemResource(file).getURI())))).getAsJsonObject();
			return object;
		} catch (JsonSyntaxException e) {
		} catch (IOException e) {
		}
		catch (Exception e) {
		}
		return null;
	}
	public static List<String> readContentFromFile(String file)
	{
		try {
			List<String> content=Files.readAllLines(Path.of(Resource.newSystemResource(file).getURI()),Charset.forName("GBK"));
			return content;
		} catch (JsonSyntaxException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	public static void  init(){
		List<String> content=readContentFromFile("province");
		if(content!=null&&content.size()>0)
		{
			content.stream().filter(e->!Util.isNull(e)).forEach(e->{
				String[] ls=e.split("\\Q|");
				if(ls!=null&&ls.length==2)
				provinces.put(ls[1], ls[0]);
			});
		}
		citys=readTreeHashMapFromFile("citys",citys);
		
		country=readTreeHashMapFromFile("country",country);
		town=readTreeHashMapFromFile("town",town);
	}
	public static Map<String,Map<String,String>> readTreeHashMapFromFile(String filename,Map<String,Map<String,String>> contentObjects)
	{
		List<String> content=readContentFromFile(filename);
		if(content!=null&&content.size()>0)
		{
			content.stream().filter(e->!Util.isNull(e)).forEach(e->{
				String[] ls=e.split("\\Q|");
				if(ls!=null&&ls.length==3)
				{
					String pid=ls[0];
					String cid=ls[1];
					String cname=ls[2];
					Map<String,String> crecord=	contentObjects.get(pid);
					if(crecord==null)
					{
						crecord=new HashMap<String, String>();
					}
					crecord.put(cname, cid);
					contentObjects.put(pid, crecord);
				}
			});
		}
		return contentObjects;
	}
	/**
     * ������ַ
     * @author xf
     * @param address
     * @return
     */
    public static List<Map<String,String>> addressResolution(String address){
        String regex="(?<province>[^ʡ]+������|.*?ʡ|.*?������|.*?��)(?<city>[^��]+������|.*?����|.*?������λ|.+��|��Ͻ��|.*?��|.*?��)?(?<county>[^��]+��|.+��|.+��|.+��|.+����|.+��)?(?<town>[^��]+��|.+��)?(?<village>.*)?";
        Matcher m=Pattern.compile(regex).matcher(address);
        String province=null,city=null,county=null,town=null,village=null;
        List<Map<String,String>> table=new ArrayList<Map<String,String>>();
        Map<String,String> row=null;
        boolean find=false;
        while(m.find()){
            row=new LinkedHashMap<String,String>();
            province=m.group("province");
            row.put("province", province==null?"":province.trim());
            city=m.group("city");
            row.put("city", city==null?"":city.trim());
            county=m.group("county");
            row.put("country", county==null?"":county.trim());
            town=m.group("town");
            row.put("town", town==null?"":town.trim());
            village=m.group("village");
            row.put("village", village==null?"":village.trim());
            table.add(row);
            find=true;
        }
        if(!find)
        	{
        	row=new LinkedHashMap<String,String>();
            province=address;
            row.put("province", province==null?"":province.trim());
            table.add(row);
        	}
        return table;
    }
 
    public static boolean checkLocations(Map<String,String> locations)
    {
    	if(locations==null||locations.size()==0)
    		return false;
    	String cp=locations.get("province");
    	if(Util.isNull(cp))
    		return false;
    	String[] pid= {provinces.get(cp)};
    	if(pid==null||pid.length==0||pid[0]==null)
    	{
    		provinces.forEach((k,v)->{
    			if(k.indexOf(cp)>-1||cp.indexOf(k)>-1)
    			{
    				pid[0]=v;
    				locations.put("provinceadvice", k);
    			}
    		});
    	}
    	if(pid==null||pid.length==0||pid[0]==null) {
    		locations.put("error", "province");
    		return false;
    	}
    	
    	
    	String []cid=checkZone(citys,"city",pid[0],locations);
    	final String []countryid=new String[1];
    	if(cid==null||cid.length==0||cid[0]==null) {
    		if((locations.containsKey("country")&&Util.isNull(locations.get("country")))||!locations.containsKey("country")) {
	    		locations.put("error", "city");
	    		return false;
    		}else
    		{
    			Map<String,String> cityMap=citys.get(pid[0]);
    			cityMap.forEach((k,v)->{
    				String [] tmpid=checkZone(country,"country",v,locations);
    				if(tmpid!=null&&tmpid.length==1&&!Util.isNull(tmpid[0])) {
    					countryid[0]=tmpid[0];
    					locations.put("cityadvice", k);
    				}
    			});
    		}
    	}else {
    		String [] tmpid=checkZone(country,"country",cid[0],locations);
    		if(tmpid!=null&&tmpid.length==1&&!Util.isNull(tmpid[0]))
    		countryid[0]=tmpid[0];
    	}
    		
    	 
    	
    	if(countryid!=null&&!Util.isNull(countryid[0]))
    	{
    		String [] townid=checkZone(town,"town",countryid[0],locations);
    		if(locations.containsKey("town")&&!Util.isNull(locations.get("town"))&&(townid==null||townid.length==0||Util.isNull(townid[0])))
    		{
    			locations.put("error", "town");
    			return false;
    		}
    		
    	}
//    	else if(locations.containsKey("country")&&!Util.isNull(locations.get("country")))
//    	{
//    		locations.put("error", "country");
//    		return false;
//    	}
//    	
    	
    	return true;
    	
    }
    public static String [] checkZone(Map<String,Map<String,String>> zoneConfig,String zkey,String pid,Map<String,String> locations)
    {
    	Map<String,String> cityMap=zoneConfig.get(pid);
    	if(cityMap==null||cityMap.size()==0)
    		return null;
    	String cityc=locations.get(zkey);
    	if(Util.isNull(cityc))
    		return null;
    	String [] cid= {cityMap.get(cityc)};
    	if(!cityMap.containsKey(cityc))
    	{
    		cityMap.forEach((k,v)->{
    			if(k.indexOf(cityc)>-1||cityc.indexOf(k)>-1)
    			{
    				cid[0]=v;
    				locations.put(zkey+"advice", k);
    			}
    		});
    	}
    	return cid;
    }
    public static String error2Display(String error)
    {
    	if("province".equals(error))
    	{
    		return "ʡ��";
    	}else if("city".equals(error))
    	{
    		return "��/��";
    	}else if("country".equals(error))
    	{
    		return "����";
    	}else if("town".equals(error))
    	{
    		return "��";
    	}
    	return "";
    }
	public static void main(String[] args) {
		List<Map<String,String>> table=addressResolution("����");
		for(Map<String,String> o:table)
		{
			boolean flag = checkLocations(o);
			if (!flag)
				System.out.println(o.get("error"));
			else
				System.out.println(o);
		}
	}
	
 
}