package org.ydzy.rcs.impl;

import org.ydzy.rcs.SuggestionDisplay;
import org.ydzy.rcs.annotation.Description;
import org.ydzy.util.StringUtils;

import com.google.inject.Singleton;

@Singleton
@Description("composeRecordingMessage")
public class ComposeRecordingMessage implements SuggestionDisplay{
	// composeRecordingMessage-phoneNumber-type
	String composeRecordingMessage = "{\r\n" 
	        + "	  \"action\":\r\n" 
			+ "		{\r\n"
			+ "			\"displayText\":\"%s\",\r\n" 
			+ "			\"composeAction\":\r\n" 
			+ "			{\r\n"
			+ "				\"composeRecordingMessage\":{\r\n" 
			+ "					\"phoneNumber\":\"%s\",\r\n" 
			+ "					\"type\":\"%s\"\r\n"// AUDIO|VIDEO
			+ "				 }\r\n" 
			+ "			}\r\n" 
			+ "		}\r\n" 
			+ "}\r\n";
	@Override
	public String suggestionHtml(String[] args) {
		int length=args.length;
		return StringUtils.format(composeRecordingMessage, length<=0?"":args[0], length<=1?"":args[1],
				length<=2?"":args[2]);
	}

}
