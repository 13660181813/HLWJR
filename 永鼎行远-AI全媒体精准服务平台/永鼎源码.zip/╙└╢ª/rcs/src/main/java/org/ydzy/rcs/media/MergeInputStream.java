package org.ydzy.rcs.media;

import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;

/**
 * �ϲ��������
 * @author ljp
 * 2019-08-12
 */
public class MergeInputStream extends FilterInputStream {

	private List<InputStream> heads;
	private List<InputStream> tails;
	
	/** stage 0: read head,  1: body,  2: tails */
	protected int stage = 0;
	
	/** ��ǰ����Input Stream index */
	protected int curIndex = -1;
	protected InputStream curIn = null;
	protected MergeInputStream(List<InputStream> heads, InputStream in, List<InputStream> tails) {
		super(in);
		this.heads = heads;
		this.tails = tails;
	}
	
	protected MergeInputStream(List<InputStream> heads, InputStream in) {
		this(heads, in, null);
	}
	
	@Override
	public int available() throws IOException {
		throw new IOException("available is not support");
	}
	
	@Override
	public boolean markSupported() {
		if(stage!=1)return false;
		return super.markSupported();
	}
	
	@Override
	public synchronized void reset() throws IOException {
		if(stage!=1) throw new IOException("reset is not support when deal not body");
		super.reset();
	}

	@Override
	public int read(byte[] b, int off, int len) throws IOException {
		int count = -1;
		switch (stage){
			case 0:{
				while(stage==0){
					boolean checkIn = curIn!=null || selectIn(heads);
					if(checkIn){
						count = curIn.read(b, off, len);
						if(count<=0){
							curIn=null;
						}else{
							return count;
						}
					}
				}
			}
			case 1:{
				count = super.read(b, off, len);
				if(count>0)return count;
				stage=2;
			}
			case 2:{
				while(stage==2){
					boolean checkIn = curIn!=null || selectIn(tails);
					if(checkIn){
						count = curIn.read(b, off, len);
						if(count<=0){
							curIn=null;
						}else{
							return count;
						}
					}
				}
			}
		}
		return -1;
	}

	@Override
	public int read() throws IOException {
		int count = -1;
		switch (stage){
			case 0:{
				while(stage==0){
					boolean checkIn = curIn!=null || selectIn(heads);
					if(checkIn){
						count = curIn.read();
						if(count<0){
							curIn=null;
						}else{
							return count;
						}
					}
				}
			}
			case 1:{
				count = super.read();
				if(count>=0)return count;
				stage=2;
			}
			case 2:{
				while(stage==2){
					boolean checkIn = curIn!=null || selectIn(tails);
					if(checkIn){
						count = curIn.read();
						if(count<0){
							curIn=null;
						}else{
							return count;
						}
					}
				}
			}
		}
		return -1;
	}
	
	protected boolean selectIn(List<InputStream> items){
		curIndex++;
		if(items==null || curIndex>= items.size()){
			stage++;
			curIndex=-1;
			return false;
		}else{
			curIn = items.get(curIndex);
			return true;
		}
	}

	@Override
	public long skip(long n) throws IOException {
		if(stage!=1) throw new IOException("skip is not support when deal not body");
		return super.skip(n);
	}

	@Override
	public void close() throws IOException {
		if(heads!=null)for(InputStream in:heads){
			try {
				in.close();
			} catch (Exception ignore) { }
		}
		if(tails!=null)for(InputStream in:tails){
			try {
				in.close();
			} catch (Exception ignore) { }
		}
		super.close();
	}
	
	
}
