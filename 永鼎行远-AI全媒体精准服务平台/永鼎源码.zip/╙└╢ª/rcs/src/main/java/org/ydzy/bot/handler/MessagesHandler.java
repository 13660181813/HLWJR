package org.ydzy.bot.handler;
import java.io.IOException;
import java.nio.charset.Charset;
import java.util.Base64;

import javax.sql.DataSource;

import org.eclipse.jetty.server.Request;
import org.ydzy.bot.BotInfo;
import org.ydzy.bot.BotUtil;
import org.ydzy.handler.BaseHandler;
import org.ydzy.publish.ConstantTopics;
import org.ydzy.publish.IPublisher;
import org.ydzy.publish.SubscribeCaches;
import org.ydzy.publish.SubscribePublish;
import org.ydzy.rcs.action.RcsLogAction;
import org.ydzy.rcs.action.RcsRunLogAction;
import org.ydzy.util.StreamsUtil;
import org.ydzy.util.Util;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.inject.Inject;
import com.google.inject.name.Named;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * �й�����
 * 11 Chatbot������Ϣ 
 *  http://{notifyURL}/messageNotification/{chatbotId}/messages
 */
public  class MessagesHandler extends BaseBotHandler  implements IPublisher<JsonObject>{
	private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(MessagesHandler.class);
//	/***
//	 * Context�����ṩ��
//	 */
//	@Inject
//	private BaseRcsContextProvidor contextProvidor = null;
//	public BaseRcsContextProvidor getContextProvidor() {
//		return contextProvidor;
//	}
	@Inject
	@Named("rcsDb")
	protected DataSource ds;
	@Inject(optional=true)
	protected RcsLogAction rcsLogAction = null;
	
	/** ����driving����,  0 ���������������˹���ϯ,ֱ��ת�� */
	@Inject(optional=true)
	@Named("transfer.defaultDriving")
	protected String defaultDriving = "0";

	@Inject
	SubscribeCaches subscribeCaches;
	
	private void bodyError( String remoteAddr,HttpServletRequest request, HttpServletResponse response) throws IOException
	{
		String content = "content/format error ! ContentType should be  application/json;charset=utf-8 ,But received null";
		log.error("(check paramBody) request failed ,receive {} from remoteAddr {},resbody{} ", null,
				remoteAddr, content);
		if(ds!=null)
		{
			RcsRunLogAction.recordLog("(check paramBody)","reqbody:"+null+" ; resbody :"+content, remoteAddr, "500", "SendMsg", ds);
		}
		
	}
	/**
	 */
	@Override
	public void handle(String target, Request baseRequest, HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException{
		baseRequest.setHandled(true);
		BotInfo bi = null;
		try {
			bi = verifyChatbot(request, response);
		}catch(VerifyError e) { 
			response.setStatus(HttpServletResponse.SC_FORBIDDEN);
			response.setContentType("application/json");
			JsonObject jo = new JsonObject();
			jo.addProperty("errorMsg", e.getMessage());
			// Write back response
			response.getWriter().println(jo.toString());
			log.debug("Sinagure error(" + e.getMessage() + "!");
			return;
		}

		String address=BaseHandler.getIpAddress(request);
		if(bi==null){
			bodyError(address,request,response);
			return;
		}
		long start = System.currentTimeMillis();
		// Content-Type: text/xml; charset=utf-8
		String contentType = request.getContentType();
		String body = StreamsUtil.copyToString(request.getInputStream(), Charset.forName("UTF-8"));
		if(log.isDebugEnabled())log.debug(",receive {} from remoteAddr {}  ", body, address);
		if(contentType==null)contentType="application/json";
		
		JsonObject object = null;
		String code = null,msg = null;

		if(contentType.indexOf("/json")>0) {
			if (!Util.isNull(body)) {
				log.info(",receive {} from remoteAddr {}  ", body,address);
				JsonElement ele = JsonParser.parseString(body);
				object = ele.getAsJsonObject();
				if(ds!=null) RcsRunLogAction.recordLog("receiveMessage","reqbody:"+body+" ; ", address, "200", "MessagesHandler", ds);
				this.handle(bi, object, address);
			}else {
				code = "2001";
				msg = "No inboundMessage message found";
			}
		}else {
			code = "2002";
			msg = "Unknow contentType:" + contentType;
		}
		boolean succ = code==null;
		if(succ) {
			code = "0";
			msg = "success";
		}
		String resBody = resBodyJson(code, msg, null);
		sendResponse(address, resBody, HttpServletResponse.SC_OK, request, response);
		if(rcsLogAction!=null && object!=null) {
			rcsLogAction.log(request, response, body, object, resBody, (int)(System.currentTimeMillis() - start), succ);
		}
		return;
	}
	
	public JsonObject handle(BotInfo bi,JsonObject object, String remoteAddr) {
		object.addProperty("remoteAddr", remoteAddr);
		object.addProperty("chatBotID", bi.getChatbotId());
		object.addProperty("driving", defaultDriving);
		//jo.addProperty("chatbodid", bi.getChatbotIdenty());
		JsonElement je = object.get("messageList");
		if(je!=null && je.isJsonArray() && je.getAsJsonArray().size()>0) {
			 je = je.getAsJsonArray().get(0);
			 if(je.isJsonObject()) {
				 JsonObject jo1 = je.getAsJsonObject();
				 String cType = BotUtil.getElementAsString(jo1, "contentType");
				 String content = "";
				 if(cType!=null && cType.startsWith("text/plain")) {
					 content = BotUtil.getElementAsString(jo1,"contentText");
					 if("base64".equalsIgnoreCase(BotUtil.getElementAsString(jo1, "contentEncoding"))){
						 byte[] buff = Base64.getDecoder().decode(content.getBytes(BotUtil.utf8));
						 content = new String(buff, BotUtil.utf8);
					 }
				 }else if(cType.startsWith("application/vnd.gsma.botsuggestion.response.v1.0+json")) {
					 je = BotUtil.getElement(jo1, new String[] {"contentText", "response","reply","postback", "data"});
					 if(je!=null && !je.isJsonNull()) {
						 content = je.getAsString();;
					 }else {
						 content = "";
					 }
				 }
				 object.addProperty("content", content);
			 }
			
		}
		SubscribePublish<JsonObject> sub= subscribeCaches.getSubscribePublishInstance(ConstantTopics.CHARTBOT_MSG_MOBILERECEIVE, JsonObject.class);
		this.publish(sub, object, false);
		return object;
	}
	@Override
	public void publish(SubscribePublish<JsonObject> subscribeObj, JsonObject message, boolean isInstantMsg) {
		subscribeObj.publish(ConstantTopics.CHARTBOT_MSG_MOBILERECEIVE+"_Subscribers", message, isInstantMsg);
	}

}