package org.ydzy.rcs.media;

import org.ydzy.util.NetUtils;

import com.google.gson.JsonObject;

public  class UploadFileEntity {
        private String mediaID;
        private String chatbotid;
        private String mediaUrl;
        /** 0:not upload 1:upload sucess 2 upload failed 3 media notify 4 media delete */
        private String status = "0";
        /** 0ý�����ͨ�� 1ý����˾ܾ� */
        private String authStatus = "0";
        private String mediacontentType;
        private String thumbnailUrl;
        private String contentLocalPath;
        private String interviewId;
        private String tid;
        private String thumbnailContentType;
        private String thumbnailLocalPath;
        
        private String fileName;
        
        private long expiredTime;
        
        private long createdDate;
        
        /** ��˷���ʱ�� */
        private long authDate;
        /** ĩ�β������ο�status������״̬��  */
        private String errorCode;
        /** ĩ�β������ο�status��������Ϣ */
        private String errorDesc;
        
        /**5G��Ϣmedia��ԴURL */
        private String chatbotMediaUrl;
        /** 5G��Ϣ����ͼ��ԴURL */
        private String chatbotThumbnailUrl;
        
        private long fileSize;
        private long thumbFileSize;
        public long getThumbFileSize() {
			return thumbFileSize;
		}
		public void setThumbFileSize(long thumbFileSize) {
			this.thumbFileSize = thumbFileSize;
		}

		private String validity;
        
        private JsonObject otherParam;
 

		public JsonObject getOtherParam() {
			return otherParam;
		}
		public void setOtherParam(JsonObject otherParam) {
			this.otherParam = otherParam;
		}
		/**
         * ��������
         *
       
         * @param s
         
         */
        public UploadFileEntity(String contentLocalPath,String thumbnailLocalPath,String mediacontentType,String thumbnailContentType) {
        	this.contentLocalPath=contentLocalPath;
        	this.thumbnailLocalPath=thumbnailLocalPath;
        	this.mediacontentType=mediacontentType;
        	this.thumbnailContentType=thumbnailContentType;
        }
        public UploadFileEntity(String contentLocalPath,String thumbnailLocalPath) {
        	this.contentLocalPath=contentLocalPath;
        	this.thumbnailLocalPath=thumbnailLocalPath;
        	this.mediacontentType=NetUtils.mimeContentType(thumbnailLocalPath);
        	this.thumbnailContentType=NetUtils.mimeContentType(contentLocalPath);
        	
        }
 
        public long getFileSize() {
            return fileSize;
        }
 
        public void setFileSize(long fileSize) {
            this.fileSize = fileSize;
        }
        /** 0:not upload 1:upload sucess 2 upload failed 3 media notify 4 media delete */
        public String getStatus() {
            return status;
        }
        /** 0:not upload 1:upload sucess 2 upload failed 3 media notify 4 media delete */
        public void setStatus(String status) {
            this.status = status;
        }
 
 
        public String getMediaID() {
			return mediaID;
		}


		public void setMediaID(String mediaID) {
			this.mediaID = mediaID;
		}


        public String getChatbotid() {
			return chatbotid;
		}


		public void setChatbotid(String chatbotid) {
			this.chatbotid = chatbotid;
		}


		public String getMediaUrl() {
			return mediaUrl;
		}


		public void setMediaUrl(String mediaUrl) {
			this.mediaUrl = mediaUrl;
		}


		public String getAuthStatus() {
			return authStatus;
		}


		public void setAuthStatus(String authStatus) {
			this.authStatus = authStatus;
		}


		public String getMediacontentType() {
			return mediacontentType;
		}


		public void setMediacontentType(String mediacontentType) {
			this.mediacontentType = mediacontentType;
		}


		public String getThumbnailUrl() {
			return thumbnailUrl;
		}


		public void setThumbnailUrl(String thumbnailUrl) {
			this.thumbnailUrl = thumbnailUrl;
		}


		public String getContentLocalPath() {
			return contentLocalPath;
		}


		public void setContentLocalPath(String contentLocalPath) {
			this.contentLocalPath = contentLocalPath;
		}


		public String getInterviewId() {
			return interviewId;
		}


		public void setInterviewId(String interviewId) {
			this.interviewId = interviewId;
		}


		public String getTid() {
			return tid;
		}


		public void setTid(String tid) {
			this.tid = tid;
		}


		public String getThumbnailContentType() {
			return thumbnailContentType;
		}


		public void setThumbnailContentType(String thumbnailContentType) {
			this.thumbnailContentType = thumbnailContentType;
		}


		public String getThumbnailLocalPath() {
			return thumbnailLocalPath;
		}


		public void setThumbnailLocalPath(String thumbnailLocalPath) {
			this.thumbnailLocalPath = thumbnailLocalPath;
		}


		public String getFileName() {
			return fileName;
		}


		public void setFileName(String fileName) {
			this.fileName = fileName;
		}


		public long getExpiredTime() {
			return expiredTime;
		}


		public void setExpiredTime(long expiredTime) {
			this.expiredTime = expiredTime;
		}


		public long getCreatedDate() {
			return createdDate;
		}


		public void setCreatedDate(long createdDate) {
			this.createdDate = createdDate;
		}


		public String getValidity() {
            return validity;
        }
 
        public void setValidity(String validity) {
            this.validity = validity;
        }
        
        /** ��˷���ʱ�� */
		public long getAuthDate() {
			return authDate;
		}
		 /** ��˷���ʱ�� */
		public void setAuthDate(long authDate) {
			this.authDate = authDate;
		}
		/** ĩ�β������ο�status������״̬��  */
		public String getErrorCode() {
			return errorCode;
		}
		/** ĩ�β������ο�status������״̬��  */
		public void setErrorCode(String errorCode) {
			this.errorCode = errorCode;
		}
		
		 /** ĩ�β������ο�status��������Ϣ */
		public String getErrorDesc() {
			return errorDesc;
		}
		 /** ĩ�β������ο�status��������Ϣ */
		public void setErrorDesc(String errorDesc) {
			this.errorDesc = errorDesc;
		}
        /**5G��Ϣmedia��ԴURL */
		public String getChatbotMediaUrl() {
			return chatbotMediaUrl;
		}
        /**5G��Ϣmedia��ԴURL */
		public void setChatbotMediaUrl(String chatbotMediaUrl) {
			this.chatbotMediaUrl = chatbotMediaUrl;
		}
	       /** 5G��Ϣ����ͼ��ԴURL */
		public String getChatbotThumbnailUrl() {
			return chatbotThumbnailUrl;
		}
	       /** 5G��Ϣ����ͼ��ԴURL */
		public void setChatbotThumbnailUrl(String chatbotThumbnailUrl) {
			this.chatbotThumbnailUrl = chatbotThumbnailUrl;
		}
    }