package org.ydzy.rcs.template.imp;

import org.ydzy.handler.BaseRcsContext;
import org.ydzy.rcs.template.MessageTemplate;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

public class UniversalityTemplate extends MessageTemplate {

	@Override
	public JsonArray data2MsgCard(JsonObject paramTemplate, BaseRcsContext context) {
		// TODO Auto-generated method stub
		return null;
	}

}
