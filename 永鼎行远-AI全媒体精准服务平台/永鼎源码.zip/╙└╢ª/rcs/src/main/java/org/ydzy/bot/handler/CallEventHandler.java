package org.ydzy.bot.handler;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.inject.Inject;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.eclipse.jetty.server.Request;
import org.eclipse.jetty.server.handler.ContextHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.ydzy.ability.privatenumber.CallEventCallBackAction;
import org.ydzy.rcs.BodyTransform;
import org.ydzy.util.StreamsUtil;
import org.ydzy.util.Util;

import java.io.IOException;
import java.nio.charset.StandardCharsets;

public class CallEventHandler extends ContextHandler {
    private static final Logger log = LoggerFactory.getLogger(CallEventHandler.class);
    @Inject
    private CallEventCallBackAction action;

    public JsonObject getRequestBody(HttpServletRequest request) {
        JsonObject req = new JsonObject();
        try {
            String body = StreamsUtil.copyToString(request.getInputStream(), StandardCharsets.UTF_8);
            if (!Util.isNull(body)) {
                req = JsonParser.parseString(body).getAsJsonObject();
            }
            log.info("request body is {}", req);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return req;
    }

    @Override
    public void doHandle(String target, Request baseRequest, HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        JsonObject body = getRequestBody(request);
        JsonObject res = new JsonObject();
        int httpCode = 200;
        if (action.handleMsg(body)) {
            res.addProperty("resultCode", "0");
            res.addProperty("resultMsg", "�ɹ�");
        } else {
            res.addProperty("resultCode", "600");
            res.addProperty("resultMsg", "ʧ��");
        }
        /**
         *  ��ʾ�������Ѿ���ɴ���������Ҫ������filter���д�����
         */
        sendResponse(BodyTransform.getIpAddress(request), res.toString(), httpCode, request, response);
        baseRequest.setHandled(true);
    }

    public void sendResponse(String remoteAddr, String body, int status,
                             HttpServletRequest request, HttpServletResponse response) throws IOException {
        // Declare response encoding and types
        response.setContentType("application/json;charset=utf-8");
        // Declare response status code
        response.setStatus(status);
        // Write back response
        response.getWriter().println(body);
        // Inform jetty that this request has now been handled
        log.info("send response.length={} to remoteAddr {} ", body == null ? 0 : body.length(), remoteAddr);
    }
}
