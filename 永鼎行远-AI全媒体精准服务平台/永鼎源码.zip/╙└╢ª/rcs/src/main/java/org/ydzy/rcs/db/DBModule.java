package org.ydzy.rcs.db;

import java.util.HashSet;
import java.util.Properties;
import java.util.Set;
import java.util.stream.Collectors;

import javax.inject.Provider;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.ydzy.rcs.RcsConfig;
import org.ydzy.rcs.annotation.Description;
import org.ydzy.util.Util;

import com.google.inject.Binder;
import com.google.inject.Guice;
import com.google.inject.Injector;
import com.google.inject.Module;
import com.google.inject.Scopes;
import com.google.inject.name.Named;
import com.google.inject.name.Names;

@Description("DbModule")
public class DBModule implements Module {
	private final static Logger log = LoggerFactory.getLogger(DBModule.class);
	private static Set<Binder> binded = new HashSet<>();
//	@Override
//	protected void configure() {
//		this.configure2(binder());
//	}
//	
	@Override
	public void configure(Binder binder) {
		synchronized(binded) {
			if(!binded.contains(binder)) {
				binded.add(binder);
				configure2(binder);
			}
		}
		
	}
	
	private Properties createProperties(String configFile) {
		Properties result = new Properties();
		try {
			result.load(DBModule.class.getClassLoader().getResourceAsStream(configFile));
			return result;
		} catch (Exception e) {
			throw new RuntimeException("can not load " + configFile + " .", e);
		}
	}
	protected void configure2(Binder binder) {
		Properties prop = createProperties("db.properties");
		Set<String> dbNames = prop.keySet().stream().map(k ->String.valueOf(k))
				.filter(k->k.endsWith(JDBC_URL))
				.map(k -> k.substring(0,k.length()-JDBC_URL.length()).trim())
				.collect(Collectors.toSet());
		
		for(String dbName:dbNames) {
			if(dbName.length()>0) {
				Properties dbProps = new Properties();
				dbProps.putAll(prop);
				prop.entrySet().stream()
				.filter(e -> String.valueOf(e.getKey()).startsWith(dbName) && String.valueOf(e.getKey()).length()>dbName.length())
				.forEach(e -> dbProps.put(String.valueOf(e.getKey()).substring(dbName.length()), e.getValue()));

				
				Named name = Names.named(dbName.endsWith(".")?dbName.substring(0, dbName.length()-1):dbName);
				
				javax.inject.Provider<DataSource> dsp = this.getDataSourceProvider(dbProps);
				if(dsp!=null) {
					binder.bind(DataSource.class).annotatedWith(name).toProvider(dsp).in(Scopes.SINGLETON);
					
					try {
//						if(!Util.isNull(dbProps.getProperty("DataSource")))
//						{
							binder.bindConstant().annotatedWith(Names.named(name.value()+".DbType")).to(dbProps.getProperty("DbType"));
//							binder.bindConstant().annotatedWith(Names.named(name.value()+".DataSource")).to(dbProps.getProperty("DataSource"));
							binder.bind(RcsConfig.class).annotatedWith(Names.named(name.value()+"Config")).toConstructor(RcsConfigFromDb.class.getDeclaredConstructor(String.class,DataSource.class));
//						}
					} catch (NoSuchMethodException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (SecurityException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					log.info("DataSource annotatedWith " + dbName + " binded @ " + dsp);
				}
			}
		}
		
		Provider<DataSource> dsp = getDataSourceProvider(prop);
		if(dsp!=null) {
			{
				binder.bind(DataSource.class).toProvider(dsp).in(Scopes.SINGLETON);
			}
			log.info("DataSource default binded @ " + dsp);
		}
		//expose(DBMapper.class);
	}
	protected static String JDBC_Driver = "JDBC.driver";
	protected static String JDBC_URL = "JDBC.url";
	protected javax.inject.Provider<DataSource> getDataSourceProvider(final Properties prop) {
		javax.inject.Provider<DataSource> dsp = null;
		if(prop.get("JDBC.driver")!=null && prop.get("JDBC.url")!=null) {
			Injector injector = Guice.createInjector(
					new com.google.inject.PrivateModule() {
						@Override
						protected void configure() {
							Names.bindProperties(binder(), prop);
							//C3p0
							binder().bind(org.mybatis.guice.datasource.c3p0.C3p0DataSourceProvider.class);
							binder().expose(org.mybatis.guice.datasource.c3p0.C3p0DataSourceProvider.class);
							
							// dbcp2
//							binder().bind(ClassLoader.class).annotatedWith(Names.named("JDBC.driverClassLoader")).toInstance(getClass().getClassLoader());
//							binder().bind(org.mybatis.guice.datasource.dbcp.BasicDataSourceProvider.class);
//							expose(org.mybatis.guice.datasource.dbcp.BasicDataSourceProvider.class);
							
						}
					});
			dsp = injector.getInstance(org.mybatis.guice.datasource.c3p0.C3p0DataSourceProvider.class);
//			dsp = injector.getInstance(org.mybatis.guice.datasource.dbcp.BasicDataSourceProvider.class);
		}
		return dsp;
	}


}