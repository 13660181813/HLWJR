package org.ydzy.jdbc.control.result.datepattern;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.ydzy.rcs.annotation.Description;
import org.ydzy.util.TimeUtil;

import com.google.inject.Singleton;

@Description(autoInstance = false,value = "quarterTname")
@Singleton
public class QuarterTname implements ITime{

	@Override
	public List<String> reckonName(String pattern,long timeInterval,  String sDate, String eDate, Calendar c1, Calendar c2) throws ParseException {
		List<String> tablelist =new ArrayList<String>();
		if(pattern.indexOf("'")<0) {
			tablelist.add(pattern);
			return tablelist;
		}
		SimpleDateFormat sdfPattern = new SimpleDateFormat(pattern);
		
		String radiustable =pattern
				.substring(pattern.indexOf("'") + 1, pattern.lastIndexOf("'")).toUpperCase();
		if(timeInterval == 7776000){
			radiustable = radiustable.replace("$", "Q");
			c1.setTime(TimeUtil.sdfmon.parse(sDate));
			c2.setTime(TimeUtil.sdfmon.parse(eDate));
			int[] q = new int[2];
			q[0] = c1.get(Calendar.MONTH) + 1;
			q[1] = c2.get(Calendar.MONTH) + 1;
			for(int i = 0 ; i <q.length ; i ++){
				if(q[i] >= 1 && q[i] <= 3)	q[i] = 1;
				if(q[i] >= 4 && q[i] <= 6)	q[i] = 2;
				if(q[i] >= 7 && q[i] <= 9)	q[i] = 3;
				if(q[i] >= 10 && q[i] <= 12)q[i] = 4;
			}
			sdfPattern = new SimpleDateFormat("yy");
			String tn = radiustable + sdfPattern.format(c1.getTime())+q[0];
			tablelist.add(tn);
			
			int dif = c2.get(Calendar.YEAR) - c1.get(Calendar.YEAR) ;
			if (dif != 0) {
				for (int i = 1; i <= 4 - q[0]; i++) {
					tn = radiustable + sdfPattern.format(c1.getTime()) + (q[0] + i);
					if (!tablelist.contains(tn)) {
						tablelist.add(tn);
					}
				}
				if(dif > 1){
					for(int i = 0 ; i < dif - 1; i++){
						c1.set(c1.get(Calendar.YEAR) + 1, 0, 1);
						tablelist.add(radiustable + sdfPattern.format(c1.getTime()) + 1 );
						tablelist.add(radiustable + sdfPattern.format(c1.getTime()) + 2 );
						tablelist.add(radiustable + sdfPattern.format(c1.getTime()) + 3 );
						tablelist.add(radiustable + sdfPattern.format(c1.getTime()) + 4 );
					}
				}
				for (int i = 1; i <= q[1]; i++) {
					tn = radiustable + sdfPattern.format(c2.getTime()) + i;
					if (!tablelist.contains(tn)) {
						tablelist.add(tn);
					}
				}
			} else {
				for (int i = 1; i <= q[1] - q[0] + 1; i++) {
					tn = radiustable + sdfPattern.format(c1.getTime()) + (q[0] + i);
					if (!tablelist.contains(tn)) {
						tablelist.add(tn);
					}
				}
			}
		}
		return tablelist;
	}

}
