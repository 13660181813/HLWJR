package org.ydzy.util.crypto;

import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.ydzy.util.Util;

public class CryptoAES {
	static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(CryptoAES.class);
	// ����
    public static String EncryptAes2Base64(String sSrc, String sKey)  {
        try {
			if (sKey == null) {
				log.warn("KeyΪ��null ,encryptAes failed ");
			    return null;
			}
			// �ж�Key�Ƿ�Ϊ16λ
			if (sKey.length() != 16) {
				log.warn("Key {} ���Ȳ���16λ",sKey);
			    return null;
			}
			byte[] raw = sKey.getBytes("utf-8");
			SecretKeySpec skeySpec = new SecretKeySpec(raw, "AES");
			Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");//"�㷨/ģʽ/���뷽ʽ"
			cipher.init(Cipher.ENCRYPT_MODE, skeySpec);
			byte[] encrypted = cipher.doFinal(sSrc.getBytes("utf-8"));
			return Base64.getEncoder().encodeToString(encrypted);//�˴�ʹ��BASE64��ת�빦�ܣ�ͬʱ����2�μ��ܵ����á�
		} catch (InvalidKeyException e) {
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		} catch (NoSuchPaddingException e) {
			e.printStackTrace();
		} catch (IllegalBlockSizeException e) {
			e.printStackTrace();
		} catch (BadPaddingException e) {
			e.printStackTrace();
		}
        return null;
    }
 
    // ����
    public static String DecryptAes(String sSrc, String sKey)   {
        try {
            // �ж�Key�Ƿ���ȷ
            if (sKey == null) {
            	log.warn("KeyΪ��null");
                return null;
            }
            // �ж�Key�Ƿ�Ϊ16λ
            if (sKey.length() != 16) {
            	log.warn("Key {} ���Ȳ���16λ",sKey);
                return null;
            }
            byte[] raw = sKey.getBytes("utf-8");
            SecretKeySpec skeySpec = new SecretKeySpec(raw, "AES");
            Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
            cipher.init(Cipher.DECRYPT_MODE, skeySpec);
            byte[] encrypted1 = Base64.getDecoder().decode(sSrc);//����base64����
            try {
                byte[] original = cipher.doFinal(encrypted1);
                String originalString = new String(original,"utf-8");
                return originalString;
            } catch (Exception e) {
            	log.error(e.toString());
                return null;
            }
        } catch (Exception ex) {
        	log.error(ex.toString());
            return null;
        }
    }

    /**
     * ���ܷ���
     * @param data  Ҫ���ܵ�����
     * @param key ����key
     * @param iv ����iv
     * @return ���ܵĽ��

     */
    public static String encrypt(String data, String key, String iv){
        try {
            //"�㷨/ģʽ/���뷽ʽ"NoPadding PkcsPadding
            Cipher cipher = Cipher.getInstance("AES/CBC/NoPadding");
            int blockSize = cipher.getBlockSize();

            byte[] dataBytes = data.getBytes();
            int plaintextLength = dataBytes.length;
            if (plaintextLength % blockSize != 0) {
                plaintextLength = plaintextLength + (blockSize - (plaintextLength % blockSize));
            }

            byte[] plaintext = new byte[plaintextLength];
            System.arraycopy(dataBytes, 0, plaintext, 0, dataBytes.length);

            SecretKeySpec keyspec = new SecretKeySpec(key.getBytes(), "AES");
            IvParameterSpec ivspec = new IvParameterSpec(iv.getBytes());

            cipher.init(Cipher.ENCRYPT_MODE, keyspec, ivspec);
            byte[] encrypted = cipher.doFinal(plaintext);
            return org.apache.commons.codec.binary.Base64.encodeBase64String(encrypted);

        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * ���ܷ���
     * @param data Ҫ���ܵ�����
     * @param key  ����key
     * @param iv ����iv
     * @return ���ܵĽ��
     */
    public static String desEncrypt(String data, String key, String iv){
        try {
            byte[] encrypted1 = Base64.getDecoder().decode(data);
            Cipher cipher = Cipher.getInstance("AES/CBC/NoPadding");
            SecretKeySpec keySpec = new SecretKeySpec(key.getBytes(), "AES");
            IvParameterSpec ivSpec = new IvParameterSpec(iv.getBytes());
            cipher.init(Cipher.DECRYPT_MODE, keySpec, ivSpec);
            byte[] original = cipher.doFinal(encrypted1);
            return new String(original).trim();
        } catch (Exception e) {
            return "[ERROR]";
        }
    }

    public static void main(String[] args) throws Exception {
        /*
         * �˴�ʹ��AES-128-ECB����ģʽ��key��ҪΪ16λ��
         */
        String cKey =  "tl#@fibVu#s%s221";
                       
        String c2k="9fk%c1*gv5M=e9@I";
        // ��Ҫ���ܵ��ִ�
        String cSrc = "123";
        System.out.println(cSrc);
        // ����
//        String enString = CryptoAES.EncryptAes2Base64(cSrc, cKey);
//        System.out.println("���ܺ���ִ��ǣ�" + enString);
   
        // ����
//        String DeString = CryptoAES.DecryptAes(enString, cKey);
//        System.out.println("���ܺ���ִ��ǣ�" + DeString);
//        System.out.println(Base64.getUrlEncoder().encodeToString("\"N/FEmJ/rotwP+lMR8ugf83LE6TJ7MDMpAibcNiuJ4EmbnavWft5TldLiLGlzW00HOZJ37lu7gEM79RT2kSpIdeFDmhjfZNXqrwVFCyQbMBO8VYviqa2RmHXwZ9dP4ezWO5V+1S1LoSrZNGRSFCvCEIu9c5HKxqFFPoCUmKQOUDNvsdnUu+Hjj7xoSpMtBGfl\", cKey".getBytes()));

        String val = encrypt(cSrc, cKey, cKey);
        System.out.println("���ܺ���ִ��ǣ�" + val);
        // ����2
        String DeString = desEncrypt(val, cKey, cKey);
        System.out.println("���ܺ���ִ��ǣ�" + DeString);
    }
}
