package org.ydzy.rcs.action;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.inject.Inject;
import com.google.inject.name.Named;
import org.ydzy.rcs.db.XmlSqlGenerator;
import org.ydzy.util.SqlUtil;
import org.ydzy.util.Util;

import javax.sql.DataSource;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * @author lirui
 * @Date 2021/7/1 5:57 ����
 */
public class AnalysisReportAction {
    static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(EvaluateManagerAction.class);
    static DecimalFormat  decimalFormat = new DecimalFormat("0.00");//���ñ���λ��
    @Inject
    @Named("rcsDb")
    DataSource ds;
    Gson gson = new Gson();

    public JsonObject get7daysAvgVals(JsonArray chatbots) {
        JsonObject params = new JsonObject();
        params.addProperty("day", 7);
        params.add("chatbots", chatbots);
        JsonObject object = new JsonObject();
        //���û�
        object.add("newUser", getCounterByDay("newUserCount", params));
        //��Ծ�û�
        object.add("activeUser", getCounterByDay("activeUserAvgCount", params));
        //TODO ����ת��
        object.add("introduce", getIntroduce());
        //TODO ʹ��ʱ��
        object.add("useTime", getUseTime());
        //��Ϣ�ɹ�
        params.addProperty("action_status", "1");
        object.add("msgSuccess", getCounterByDay("actionStatusCounterByDay", params));
        //��Ϣʧ��
        params.addProperty("action_status", "0");
        object.add("msgFailed", getCounterByDay("actionStatusCounterByDay", params));
        params.remove("action_status");
        //TODO ����������
        object.add("newSaveRate", getNewSaveRate());
        //��Ӧʱ��
        object.add("responseDelay", getCounterByDay("delayCounterByDay", params));
        return object;
    }

    public JsonObject getUserTotal(JsonArray chatbots) {
        JsonObject params = new JsonObject();
        params.add("chatbots", chatbots);
        JsonObject object = new JsonObject();
        params.addProperty("day", 7);
        object.add("7daysActiveUser", getCounterByDay("activeUserCount", params));
        params.addProperty("day", 30);
        object.add("30daysActiveUser", getCounterByDay("activeUserCount", params));
        params.remove("day");
        object.add("allUsers", getCounterByDay("allUsers", params));
        object.add("allTotal", getCounterByDay("allTotal", params));
        return object;
    }

    static DateFormat df = new SimpleDateFormat("yyyy-MM-dd");

    public JsonObject getChatbotUsers(JsonObject params) {
        String sqlId = "chatbotUserCount";
        JsonObject rstJsonObject = new JsonObject();
        try {
            String st = Util.getElementAsString(params, "st");
            String et = Util.getElementAsString(params, "et");
            String dateFormat = "%Y-%m-%d";
            String scale = Util.getElementAsString(params, "scale");
            switch (scale) {
                case "day" -> {
                    dateFormat = "%Y-%m-%d";
                    if (Util.isNull(st)) {
                        st = df.format(new Date(System.currentTimeMillis() - 7 * 3600 * 24 * 1000));
                        et = df.format(new Date());
                        params.addProperty("st", st);
                        params.addProperty("et", et);
                    }
                }
                case "week" -> {
                    dateFormat = "%Y��%u��";
                    if (Util.isNull(st)) {
                        st = df.format(new Date(System.currentTimeMillis() - 31L * 3600 * 24 * 1000));
                        et = df.format(new Date());
                        params.addProperty("st", st);
                        params.addProperty("et", et);
                    }
                }
                case "month" -> {
                    dateFormat = "%Y-%m";
                    if (Util.isNull(st)) {
                        st = df.format(new Date(System.currentTimeMillis() - 91L * 3600 * 24 * 1000));
                        et = df.format(new Date());
                        params.addProperty("st", st);
                        params.addProperty("et", et);
                    }
                }
                case "" -> {
                    long sdate = df.parse(st).getTime();
                    long edate = df.parse(et).getTime();
                    long diffDays = (edate - sdate) / 24 / 3600 / 1000;
                    if (diffDays > 31 && diffDays < 90)
                        dateFormat = "%Y��%u��";
                    else if (diffDays >= 90)
                        dateFormat = "%Y-%m";
                    else
                        dateFormat = "%Y-%m-%d";
                }
            }
            params.addProperty("dateFormat", dateFormat);
            String sql = XmlSqlGenerator.getSqlByJson(sqlId, null, params);
            JsonArray array = SqlUtil.queryForJson(ds, sql);
            for (JsonElement ele : array) {
                JsonObject object = ele.getAsJsonObject();
                String logdate = Util.getElementAsString(object, "log_date");
                if (!rstJsonObject.has(logdate)) {
                    JsonArray dateArray = new JsonArray();
                    rstJsonObject.add(logdate, dateArray);
                }
                JsonArray dateArray = rstJsonObject.getAsJsonArray(logdate);
                dateArray.add(object);
            }
        } catch (Exception e) {
            log.error("query chatbotUserCount error.", e);
        }
        return rstJsonObject;
    }

    public JsonObject newUserEveryDayByIndustry(JsonObject params) {
        String sqlId = "newUserEveryDayByIndustry";
        JsonObject object =new JsonObject();
        try {
            String sql = XmlSqlGenerator.getSqlByJson(sqlId, null, params);
            JsonArray jsonArray = SqlUtil.queryForJson(ds, sql);
            Map<String, JsonArray> map = new HashMap<>();
            for (JsonElement ele : jsonArray) {
                JsonObject newUserCtObject = ele.getAsJsonObject();
                String date = Util.getElementAsString(newUserCtObject, "date");
                JsonArray array;
                if (!object.has(date)) {
                    array = new JsonArray();
                    object.add(date, array);
                } else
                    array = object.getAsJsonArray(date);
                array.add(ele);
            }
        }catch (Exception e) {
            log.error("get new user every day by industry error.", e);
        }
        return object;
    }

    /**
     * ÿ�������û���
     *
     * @return
     */
    public JsonObject newUserEveryDay(JsonObject params) {
        String sqlId = "newUserEveryDay";
        JsonObject object = new JsonObject();
        try {
            String sql = XmlSqlGenerator.getSqlByJson(sqlId, null, params);
            Map<String, Set<String>> mainPhones = new HashMap<>();
            Map<String, Set<String>> comparePhones = new HashMap<>();
            JsonArray jsonArray = SqlUtil.queryForJson(ds, sql);
            for (JsonElement ele : jsonArray) {
                JsonObject jsonObject = ele.getAsJsonObject();
                String date = Util.getElementAsString(jsonObject, "date"); // ����ʱ��
                String phone = Util.getElementAsString(jsonObject, "phone"); // �����û�
                String cphone = Util.getElementAsString(jsonObject, "cphone"); // �Ƚ��û�
                String logtime = Util.getElementAsString(jsonObject, "logtime"); // ����ʱ��
                String clogtime = Util.getElementAsString(jsonObject, "clogtime"); // �Ƚ�ʱ��

                Set<String> mainPhoneSet = mainPhones.computeIfAbsent(date + ".main." + logtime, k -> new HashSet<>());
                Set<String> comparePhoneSet = comparePhones.computeIfAbsent(date + ".compare." + clogtime, k -> new HashSet<>());

                JsonObject dateObject = getOrCreateJsonObject(object, date);
                JsonObject mainObject = getOrCreateJsonObject(dateObject, "main");
                JsonObject compareObject = getOrCreateJsonObject(dateObject, "compare");
                mainObject.addProperty("logtime", logtime);
                compareObject.addProperty("logtime", clogtime);
                JsonArray mainPhoneArray = getOrCreateJsonArray(mainObject, "phones");
                JsonArray comparePhoneArray = getOrCreateJsonArray(compareObject, "phones");
                if (!Util.isNull(phone)) {
                    if (!isContains(mainPhones, phone)) {
                        mainPhoneSet.add(phone);
                        mainPhoneArray.add(phone);
                    }
                }
                if (!Util.isNull(cphone)) {
                    if (!isContains(comparePhones, cphone)) {
                        comparePhoneSet.add(cphone);
                        comparePhoneArray.add(cphone);
                    }
                }
            }
           Set<String> keys = object.keySet();
            for (String key : keys) {
                JsonObject obj = object.getAsJsonObject(key);
                JsonObject mainObject = obj.getAsJsonObject("main");
                JsonObject compareObject = obj.getAsJsonObject("compare");
                int mainUsers = mainObject.get("phones").getAsJsonArray().size();
                int compareUsers = compareObject.get("phones").getAsJsonArray().size();
                mainObject.addProperty("users", mainUsers + "");
                compareObject.addProperty("users", compareUsers + "");
                obj.addProperty("rate", decimalFormat.format((float)(mainUsers-compareUsers)/(compareUsers == 0 ? 1 : compareUsers)*100));
            }
        } catch (Exception e) {
            log.error("get new user every day error.", e);
        }
        return object;
    }

    private JsonObject getOrCreateJsonObject(JsonObject baseObject, String objectName) {
        JsonObject object = baseObject.getAsJsonObject(objectName);
        if (object == null) {
            object = new JsonObject();
            baseObject.add(objectName, object);
        }
        return object;
    }

    private JsonArray getOrCreateJsonArray(JsonObject baseObject, String objectName) {
        JsonArray array = baseObject.getAsJsonArray(objectName);
        if (array == null) {
            array = new JsonArray();
            baseObject.add(objectName, array);
        }
        return array;
    }

    /**
     * @param map
     * @param val
     * @return
     */
    private boolean isContains(Map<String, Set<String>> map, String val) {
        Collection<Set<String>> set = map.values();
        for(Set<String> o : set) {
            if (o.contains(val))
                return true;
        }
        return false;
    }

    /**
     *
     * @return
     */
    private JsonObject getCounterByDay(String sqlId, JsonObject params) {
        JsonObject obj = new JsonObject();
        String sql = XmlSqlGenerator.getSqlByJson(sqlId, null, params);
        try {
            JsonArray array = SqlUtil.queryForJson(ds, sql);
            if (array.size() == 0) {
                obj.addProperty("num", "0");
                obj.addProperty("grp", "0.00");
            } else {
                obj = array.get(0).getAsJsonObject();
            }
        }catch (Exception e) {
            log.error("get counter by day error. sqlid={}, sql={}", sqlId, sql, e);
        }
        return obj;
    }

    /**
     * ����ת��
     *
     * @return
     */
    private JsonObject getIntroduce() {
        JsonObject obj = new JsonObject();
        obj.addProperty("num", "0");
        obj.addProperty("grp", "0");
        return obj;
    }

    /**
     * ʹ��ʱ��
     *
     * @return
     */
    private JsonObject getUseTime() {
        JsonObject obj = new JsonObject();
        obj.addProperty("num", "0");
        obj.addProperty("grp", "0");
        return obj;
    }


    /**
     * ����������
     *
     * @return
     */
    private JsonObject getNewSaveRate() {
        JsonObject obj = new JsonObject();
        obj.addProperty("num", "0");
        obj.addProperty("grp", "0");
        return obj;
    }

    public JsonArray smsStatusCount(JsonObject object) {
        String sqlId = "smsStatusCt";
        try {
            String sql = XmlSqlGenerator.getSqlByJson(sqlId, null, object);
            JsonArray array = SqlUtil.queryForJson(ds, sql);
            Map<String,Map<String,String>> series=new HashMap<String,Map<String,String>>();
            Map<String, Map<String, JsonObject>> countMap = new HashMap<>();
            for (JsonElement element : array) {
                JsonObject jsonObject = element.getAsJsonObject();
//                String spName = Util.getElementAsString(jsonObject, "spName");
                String chatbotname = Util.getElementAsString(jsonObject, "chatbotname");
                String deliveryStatus = Util.getElementAsString(jsonObject, "deliveryStatus");
                Map<String, JsonObject> subMap = countMap.computeIfAbsent(chatbotname, k -> new HashMap<>());
                String uniformDesc =Util.getElementAsString(jsonObject, "uniformDesc");
                String uniformStatus =Util.getElementAsString(jsonObject, "uniformStatus");
                series.put(deliveryStatus, Map.of("uniformStatus",uniformStatus,"uniformDesc",uniformDesc));
                if (!subMap.containsKey(deliveryStatus))
                    subMap.put(deliveryStatus, jsonObject);
                else {
                    JsonObject target = subMap.get(deliveryStatus);
                    int sct = target.get("ct").getAsInt(); // ����ct
                    int nct = jsonObject.get("ct").getAsInt(); // ���ϲ�ct
                    target.addProperty("ct", sct + nct);
                }
            }
            JsonArray result = new JsonArray();
            countMap.forEach((s, stringJsonObjectMap) -> {
                JsonObject rsobj = new JsonObject();
                rsobj.addProperty("chatbotname", s);
                JsonArray subarr = new JsonArray();
                
                if(stringJsonObjectMap.size()>0)
                {
                	Set<String> allkey=new HashSet<String>();
                	List<JsonObject> allvalue=new ArrayList<JsonObject>();
                	allvalue.addAll(stringJsonObjectMap.values());
                	allkey.addAll(series.keySet());
                	allkey.removeAll(stringJsonObjectMap.keySet());
                	allkey.stream().forEach(k->{
                		JsonObject newObject=allvalue.get(0);
                		series.get(k);
                		newObject.addProperty("deliveryStatus", k);
                		newObject.addProperty("uniformDesc", series.get(k).get("uniformDesc"));
                		newObject.addProperty("uniformStatus", series.get(k).get("uniformStatus"));
                		newObject.addProperty("ct", "0");
                		stringJsonObjectMap.put(k, newObject);
                	});
                	subarr.addAll(gson.toJsonTree(stringJsonObjectMap.values()).getAsJsonArray());
                	rsobj.add("data", subarr);
                	result.add(rsobj);
                }
            });
            return result;
        }catch (Exception e) {
            log.error("sms status count error.", e);
        }
        return new JsonArray();
    }

    public JsonArray smsStatusInfo(JsonObject object) {
        String sqlId = "smsStatusInfo";
        try {
            /*
            String deliveryStatus = Util.getElementAsString(object, "deliveryStatus");
            if (Util.isNull(deliveryStatus))
                object.addProperty("deliveryStatus", "(deliveryStatus is null or deliveryStatus ='')");
            else
                object.addProperty("deliveryStatus", "deliveryStatus='" + deliveryStatus + "'");
             */
            String sql = XmlSqlGenerator.getSqlByJson(sqlId, null, object);
            return SqlUtil.queryForJson(ds, sql);
        } catch (Exception e) {
            log.error("query sms status info error.", e);
        }
        return new JsonArray();
    }
}
