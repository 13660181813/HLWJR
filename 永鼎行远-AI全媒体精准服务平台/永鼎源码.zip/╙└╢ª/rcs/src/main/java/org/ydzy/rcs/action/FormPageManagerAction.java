package org.ydzy.rcs.action;

import com.google.common.collect.Maps;
import com.google.gson.*;
import com.google.inject.Inject;
import com.google.inject.name.Named;
import org.ydzy.bot.BotUtil;
import org.ydzy.rcs.Provider;
import org.ydzy.rcs.db.XmlSqlGenerator;
import org.ydzy.thirdparty.gz110.GZGaPoliceCheckPostAction;
import org.ydzy.util.ExcelUtil;
import org.ydzy.util.SqlUtil;
import org.ydzy.util.Util;

import javax.sql.DataSource;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

/**
 * @author lirui
 * @Date 2021/8/4 3:53 ����
 */
public class FormPageManagerAction {
    static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(FormPageManagerAction.class);

    Gson gson = new Gson();

    @Inject
    @Named("rcsDb")
    DataSource ds;
    public JsonObject queryCustomPage(JsonObject params) {
        JsonObject result = new JsonObject();
        String chatbotid = Util.getElementAsString(params, "chatbotid");
        String pageid = Util.getElementAsString(params, "pageid");
        result.addProperty("chatbotid", chatbotid);
        result.addProperty("pageid", pageid);

        String sqlId = "queryCustomPageByPageId";
        try {
            String sql = XmlSqlGenerator.getSqlByJson(sqlId, null, params);
            JsonArray array = SqlUtil.queryForJson(ds, sql);
            if (array.size() == 0)
                return result;
            Map<String, JsonArray> stepMap = new LinkedHashMap<>();
            Map<String, JsonObject> collapseMap = new LinkedHashMap<>();
            Map<String, JsonObject> collapseSubMap = new LinkedHashMap<>();
            Map<String, JsonArray> footerMap = new LinkedHashMap<>();
            String pagetitle = "";
            String formClass = "";
            String csspath = "";
            Set<String> submitStep = new HashSet<>();
            JsonArray primaryKeys = new JsonArray();
            result.add("primaryKeys", primaryKeys);
            for (JsonElement ele : array) {
                JsonObject object = ele.getAsJsonObject();
                if (Util.isNull(pagetitle)) {
                    pagetitle = Util.getElementAsString(object, "pagetitle");
                    result.addProperty("pagetitle", pagetitle);
                }
                if (Util.isNull(formClass)) {
                    formClass = Util.getElementAsString(object, "formClass");
                    result.addProperty("formClass", formClass);
                }
                if (Util.isNull(csspath)) {
                    csspath = Util.getElementAsString(object, "csspath");
                    result.addProperty("csspath", csspath);
                }
                String issubmit = Util.getElementAsString(object, "issubmit");
                String step = Util.getElementAsString(object, "step");
                if (!issubmit.equals("0"))
                    submitStep.add(step);
                String formText = Util.getElementAsString(object, "formtext");
                JsonObject formTextObject = Util.isNull(formText)?new JsonObject():JsonParser.parseString(formText).getAsJsonObject();
                String primaryKey = Util.getElementAsString(object, "primarykey");
                //����
                if (primaryKey.equals("1")) {
                    primaryKeys.add(Util.getElementAsString(formTextObject, "field_name"));
                }
                JsonArray stepEleArray = stepMap.computeIfAbsent(step, k -> new JsonArray());
//                stepEleArray.add(object);

                String collapseId = Util.getElementAsString(formTextObject, "collapseId");
                String collapseName = Util.getElementAsString(formTextObject, "collapseName");
                String field_group = Util.getElementAsString(formTextObject, "field_group");



                //�۵����Ԫ��
                if (!Util.isNull(collapseId) && !Util.isNull(collapseName)) {
                    JsonObject collapseObject = collapseMap.get(step + collapseId);
                    if (collapseObject == null) {
                        collapseObject = formTextObject;
                        collapseObject.add("data", new JsonArray());
                        collapseMap.put(step + collapseId, collapseObject);
                        stepEleArray.add(collapseObject);
                    } else {
                        formTextObject.add("data", collapseObject.get("data"));
                        stepEleArray.add(formTextObject);
                    }
                    continue;
                }

                //�۵��������
                if (!Util.isNull(field_group)) {
                    JsonObject collapseObject = collapseMap.get(step + field_group);
                    if (collapseObject == null) {
                        collapseObject = new JsonObject();
                        collapseObject.add("data", new JsonArray());
                        collapseMap.put(step + field_group, buildFieldObject(collapseObject));
                    }
                    JsonObject collapseSubObject = collapseSubMap.get(step + field_group);
                    if (collapseSubObject == null) {
                        collapseSubObject = new JsonObject();
                        collapseSubMap.put(step + field_group, collapseSubObject);
                    }
                    JsonObject buildObject = buildFieldObject(formTextObject);
                    collapseSubObject.add(Util.getElementAsString(buildObject, "field_name"), buildObject);
//                    collapseObject.get("data").getAsJsonArray().add(buildObject);
                    JsonArray collapseDataArray = collapseObject.get("data").getAsJsonArray();
                    if (collapseDataArray.size() == 0)
                        collapseDataArray.add(new JsonObject());
                    collapseDataArray.get(0).getAsJsonObject().add(Util.getElementAsString(buildObject, "field_name"), buildObject);
                    continue;
                }

                //���۵����
                String position = Util.getElementAsString(formTextObject, "position");
                if (position.equals("footer")) {
                    JsonArray footerArray = footerMap.computeIfAbsent(step, k -> new JsonArray());
                    footerArray.add(formTextObject);
                } else
                    stepEleArray.add(formTextObject);
            }

            result.add("issubmit", gson.toJsonTree(submitStep));
            JsonArray stepArray = new JsonArray();
            result.add("step", stepArray);
            stepMap.forEach((s, jsonElements) -> {
                JsonArray footArray = footerMap.get(s);
                JsonObject footObject = new JsonObject();
                footObject.addProperty("position", "footer");
                footObject.add("data", footArray);
                jsonElements.add(footObject);
                stepArray.add(jsonElements);
            });
        } catch (Exception e) {
            log.error("query custom page error.", e);
        }
        return result;
    }

    private JsonObject buildFieldObject(JsonObject object) {
        object.remove("chatbotid");
        object.remove("pageid");
        object.remove("submitUrl");
        object.remove("collapseName");
        String datasource = Util.getElementAsString(object, "datasource");
        String relationSql = Util.getElementAsString(object, "relationSql");

        if (!Util.isNull(relationSql)) {
            try {
                datasource = Util.isNull(datasource) ? "rcsDb" : datasource;
                DataSource ds = Provider.getInstance(DataSource.class, datasource);
                JsonArray array = SqlUtil.queryForJson(ds, relationSql);
                object.add("relationValues", array);
            } catch (Exception e) {
                log.error("execute sql error, sql={}", relationSql, e);
            }
        }
        String relationValues = Util.getElementAsString(object, "relationValues");
        if (!Util.isNull(relationValues))
            object.add("relationValues", parseString2JsonElement(relationValues));
        String field_required = Util.getElementAsString(object, "field_required");
        if (!Util.isNull(field_required))
            object.add("field_required", parseString2JsonElement(field_required));
        String field_props = Util.getElementAsString(object, "field_props");
        if (!Util.isNull(field_props))
            object.add("field_props", parseString2JsonElement(field_props));

        if (!object.has("field_value"))
            object.addProperty("field_value", "");
        return object;
    }

    public boolean editFormFields(JsonObject fieldObject) {
        String delSqlId = "delCustomPage";
        try {
            String chatbotid = Util.getElementAsString(fieldObject, "chatbotid");
            String pageid = Util.getElementAsString(fieldObject, "pageid");
            JsonObject params = new JsonObject();
            params.addProperty("chatbotid", chatbotid);
            params.addProperty("pageid", pageid);
            String delSql = XmlSqlGenerator.getSqlByJson(delSqlId, null, params);
            boolean flag = SqlUtil.updateRecords(ds, delSql);
            if (!flag)
                return false;
            return !Util.isNull(submitFormFields(fieldObject));
        } catch (Exception e){
            log.error("edit form fields error.", e);
        }
        return false;
    }

    /**
     * ������form����
     *
     * @return
     */
    public String submitFormFields(JsonObject fieldObject) {
        StringBuilder sqls = new StringBuilder();
        String sqlId = "addCustomPage";
        try {
            String chatbotid = Util.getElementAsString(fieldObject, "chatbotid");
            String datasource = Util.getElementAsString(fieldObject, "datasource");
            String pagetitle = Util.getElementAsString(fieldObject, "pagetitle");
            String formClass = Util.getElementAsString(fieldObject, "formClass");
            String csspath = Util.getElementAsString(fieldObject, "csspath");
            String pageid = Util.getElementAsString(fieldObject, "pageid");
            if (Util.isNull(pageid))
                pageid = generatePageId(chatbotid);
            JsonArray stepArray = fieldObject.getAsJsonArray("step");
            JsonArray primarykey = fieldObject.getAsJsonArray("primaryKeys");
            JsonArray issubmitArray = fieldObject.getAsJsonArray("issubmit");
            Set<Integer> issubmitSet = new HashSet<>();
            if (issubmitArray != null && !issubmitArray.isJsonNull() && issubmitArray.size() > 0) {
                issubmitArray.forEach(jsonElement -> {
                    issubmitSet.add(jsonElement.getAsInt());
                });
            }
            Set<String> primaryKeys = new HashSet<>();
            if (primarykey != null && primarykey.size() > 0) {
                for (JsonElement ele : primarykey)
                    primaryKeys.add(ele.getAsString());
            }

            JsonObject params = new JsonObject();
            params.addProperty("chatbotid", chatbotid);
            params.addProperty("pageid", pageid);

            params.addProperty("datasource", datasource);
            params.addProperty("pagetitle", pagetitle);
            params.addProperty("formClass", formClass);
            params.addProperty("csspath", csspath);

            if (stepArray == null || stepArray.isJsonNull() || stepArray.size() == 0)
                return "";
            int step = 0;
            for (JsonElement stepElement : stepArray) {
                JsonArray stepFields = stepElement.getAsJsonArray();
                if (stepFields == null || stepFields.isJsonNull() || stepFields.size() == 0)
                    continue;
                if (issubmitSet.contains(step))
                    params.addProperty("issubmit", 1);
                else
                    params.addProperty("issubmit", 0);
                params.addProperty("step", step);
                for (JsonElement fieldElement : stepFields) {
                    JsonObject field = fieldElement.getAsJsonObject();
                    String position = field.get("position").getAsString();
                    if(position.equals("body") && field.keySet().size() == 1)
                        continue;
                    if (position.equals("body") && field.has("field_name"))
                        params.addProperty("primarykey", primaryKeys.contains(field.get("field_name").getAsString()) ? 1 : 0);
                    else
                        params.addProperty("primarykey", 0);
                    if (position.equals("footer")) {
                        JsonArray footers = field.getAsJsonArray("data");
                        for (JsonElement ele : footers) {
                            params.addProperty("formtext", ele.toString());
                            String sql = XmlSqlGenerator.getSqlByJson(sqlId, null, params);
                            sqls.append(sql).append(";");
                        }
                    } else {
                        params.addProperty("formtext", field.toString());
                        String sql = XmlSqlGenerator.getSqlByJson(sqlId, null, params);
                        sqls.append(sql).append(";");
                    }
                }
                step++;
            }
            boolean flag = SqlUtil.updateRecords(ds, sqls.toString().replace("��", ","));
            if (flag)
                return pageid;
        } catch (Exception e) {
            log.error("create new form error.", e);
        }
        return "";
    }

    public boolean doFormSubmit(JsonObject formObject, String type, String afterSqlId, String username) {
        boolean flag;
        try {
            String sqlId = "submitCustomForm";
            if (type.equals("update"))
                sqlId = "updateCustomForm";
            JsonObject params = formObject.getAsJsonObject("params");
            flag = insertFormData2db(sqlId, params);
            if (flag) {
                if (!Util.isNull(afterSqlId)) {
                    flag = doAfterSqlIdAction(params, afterSqlId, username);
                    if (!flag) {
                        // delete formid
                        sqlId = "deleteCustomForm";
                        String sql = XmlSqlGenerator.getSqlByJson(sqlId, null, params);
                        SqlUtil.updateRecords(ds, sql);
                    }
                }
            }
        } catch (Exception e) {
            return false;
        }
        return flag;
    }

    public boolean doFormData2db(JsonObject formObject, String type, JsonArray result) {
        String sqlId = "submitCustomForm";
        if (type.equals("update"))
            sqlId = "updateCustomForm";
        JsonObject params = formObject.getAsJsonObject("params");
        boolean flag = insertFormData2db(sqlId, params);
        if (flag) {
            // ��ѯ����ҵ����
            try {
                Map<String, Map<String, List<JsonObject>>> conditions = queryGzgyServicePolicy(ds);
                if (params != null && params.getAsJsonArray("form_value") != null) {
                    List<JsonObject> rewardlist = new ArrayList<>(calculate(conditions, params.getAsJsonArray("form_value")));
                    result.addAll(gson.toJsonTree(rewardlist).getAsJsonArray());
                }
            } catch (Exception e) {
                log.error("calculate error.", e);
                flag = false;
            }

        }
        return flag;
    }

    public boolean insertFormData2db(String sqlId, JsonObject formObject) {
        String sql = XmlSqlGenerator.getSqlstr(sqlId);
        try {
            SqlUtil.insertStat(ds, sql, formObject);
        }catch (Exception e) {
            log.error("insertFormData2db error.", e);
            return false;
        }
        return true;
    }

    private boolean doAfterSqlIdAction(JsonObject object, String sqlId, String username) {
        JsonObject params = new JsonObject();
        params.addProperty("username", username);
        try {
            Map<String, String> baseFieldMap = new HashMap<>();
            JsonArray formArray = object.getAsJsonArray("form_value");
            for (JsonElement element : formArray) {
                JsonArray fieldArray = element.getAsJsonArray();
                for (JsonElement ele : fieldArray) {
                    JsonObject obj = ele.getAsJsonObject();
                    if (obj.get("field_name") == null || obj.get("field_name").isJsonNull())
                        continue;

                    String base_field_gs = "";
                    String base_field_gs_value = Util.getElementAsString(obj, "field_value");
                    JsonArray relationValues = obj.getAsJsonArray("relationValues");
                    if (relationValues != null && relationValues.size() > 0) {
                        base_field_gs = Util.getElementAsString(relationValues.get(0).getAsJsonObject(), "field_value");
                        baseFieldMap.put(base_field_gs, base_field_gs_value);
                    }


                    String key = Util.getElementAsString(obj, "field_name");
                    String value = "";
                    if (obj.get("field_value") != null && !obj.get("field_value").isJsonNull()) {
                        value = Util.getElementAsString(obj, "field_value");
                        if (baseFieldMap.get(key).equals(value)) {
                            params.addProperty(key, value);
                        }
                    } else {
                        params.addProperty(key, value);
                    }
                }
            }
            String sql = XmlSqlGenerator.getSqlByJson(sqlId, null, params);
//            return SqlUtil.updateRecords(ds, sql);
            return true;
        } catch (Exception e) {
            log.error("add forward info error.", e);
        }
        return false;
    }


    private JsonArray getCollapseFiledArray(String collapseName, JsonArray fieldArray) {
        if (fieldArray == null || fieldArray.size() == 0)
            return new JsonArray();
        for (JsonElement ele : fieldArray) {
            JsonObject object = ele.getAsJsonObject();
            if (object.has("collapseName") && Util.getElementAsString(object, "collapseName").equals(collapseName)) {
                if (object.has("data") && object.get("data").isJsonArray())
                    return object.get("data").getAsJsonArray();
            }
        }
        return new JsonArray();
    }

    private JsonElement parseString2JsonElement(String json) {
        if (Util.isNull(json))
            return null;
        JsonElement element = JsonParser.parseString(json);
        if (element.isJsonArray() || element.isJsonObject())
            return element;
        return null;
    }

    public List<JsonObject> calculate(Map<String, Map<String, List<JsonObject>>> conditions, JsonArray formArray) {
        List<JsonObject> rewardlist = new ArrayList<>();
        for (JsonElement formElement : formArray) {
            JsonArray formValueArray = formElement.getAsJsonArray();
            formvalueLoop:
            for (JsonElement element : formValueArray) {
                JsonObject object = element.getAsJsonObject();
                String field_name = Util.getElementAsString(object, "field_name");
                String field_value = Util.getElementAsString(object, "field_value");
                if (conditions.containsKey(field_name)) {
                    Map<String, List<JsonObject>> conditionMap = conditions.get(field_name);
                    Set<String> conditionGroups = conditionMap.keySet();
                    for (String group : conditionGroups) {
                        if (Util.isNull(group))
                            continue;
                        List<JsonObject> conditionlist = conditionMap.get(group);
                        if (conditionlist.size() == 0)
                            continue;
                        boolean flag = false;
                        for (JsonObject condObject : conditionlist) {
                            boolean f1 = doCondition(condObject, field_value);
                            if (f1)
                                rewardlist.add(condObject);
                            flag = flag || f1;
                        }
                        if (flag)
                            continue formvalueLoop;
                    }
                }
            }
        }
        return rewardlist;
    }

    private boolean doCondition(JsonObject condObject, String value) {
        try {
            long maxVal = Util.toLong(Util.getElementAsString(condObject, "max_val"), -99999999L);
            long minVal = Util.toLong(Util.getElementAsString(condObject, "max_val"), -99999999L);
            long rewardVal = Util.toLong(Util.getElementAsString(condObject, "s_val"), 0);
            Number rateNumber = BotUtil.getElementAsNumber(condObject, "rate");
            double rate = 1;
            if (rateNumber != null)
                rate = rateNumber.doubleValue();
            long longVal = Util.toLong(value, -1);
            if ((maxVal == minVal && minVal == -99999999L) || (longVal >= minVal && minVal <= maxVal)) {
                condObject.addProperty("reward", String.format("%.2f", rate * rewardVal));
                return true;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public Map<String, Map<String, List<JsonObject>>> queryGzgyServicePolicy(DataSource ds) {
        Map<String, Map<String, List<JsonObject>>> conditionMap = new LinkedHashMap<>();
        try {
            String sqlId = "queryGzgyServicePolicy";
            String sql = XmlSqlGenerator.getSqlstr(sqlId);
            JsonArray array = SqlUtil.queryForJson(ds, sql);
            for (JsonElement element : array) {
                JsonObject condition = element.getAsJsonObject();
                String field_name = Util.getElementAsString(condition, "field_name");
                String condition_group = Util.getElementAsString(condition, "condition_group");
                if (Util.isNull(condition_group)) {
                    String seqid = Util.getElementAsString(condition, "seqid");
                    condition_group = field_name + "_" + seqid;
                }
                Map<String, List<JsonObject>> conditionGroupMap = conditionMap.computeIfAbsent(field_name, k -> new LinkedHashMap<>());
                List<JsonObject> list = conditionGroupMap.computeIfAbsent(condition_group, k -> new ArrayList<>());
                list.add(condition);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return conditionMap;
    }

    private String generatePageId(String chatbotid) {
        String sql = "select case when pageid is null then 1 else pageid+1 end as pageid from (select max(pageid) pageid from custom_page_fields where chatbotid='"+chatbotid+"') t";
        try {
            JsonArray array = SqlUtil.queryForJson(ds , sql);
            return array.get(0).getAsJsonObject().get("pageid").getAsString();
        }catch (Exception e) {
            log.error("generatePageId error.", e);
        }
        Random r = new Random();
        return "" + r.nextInt(10000);
    }

    public JsonArray queryResultList(JsonObject params) {
        JsonArray result = new JsonArray();
        String sqlId = "queryCustomSubmitFormList";
        try {
            int pageNum = 1;
            int pageSize = 50000;//Ĭ��50000
            try {
                pageNum = params.get("pageNum").getAsInt();
                pageSize = params.get("pageSize").getAsInt();
            } catch (Exception e) {
                log.error("parse pageNum or pageSize to int error. {}", params);
            }
            params.addProperty("pstart", (pageNum - 1) * pageSize);
            params.addProperty("pend", pageSize);
            String sql = XmlSqlGenerator.getSqlByJson(sqlId, null, params);
            JsonArray array = SqlUtil.queryForJson(ds, sql);
            array.forEach(jsonElement -> {
                JsonObject object = jsonElement.getAsJsonObject();
                String postData = getPostData(object);
                String submit_datetime = Util.getElementAsString(object, "submit_datetime");
                String postDate = Util.getElementAsString(object, "postDate");
                try {
                    JsonElement e = JsonParser.parseString(postData);
                    e.getAsJsonObject().addProperty("submit_datetime", submit_datetime);
                    e.getAsJsonObject().addProperty("postDate", postDate);
                    result.add(e);
                } catch (Exception e) {
                    log.error("parse json postData error, postData is not a json. {}", postData);
                }
            });
        } catch (Exception e) {
            log.error("query result list error.", e);
        }
        return result;
    }

    private String getPostData(JsonObject object) {
        String postData = Util.getElementAsString(object, "postData");
        if (!Util.isNull(postData))
           return postData.replace("��", ",");


        String lstr=Util.getElementAsString(object,"location");
        JsonObject location =Util.isNull(lstr)?new JsonObject(): JsonParser.parseString(lstr).getAsJsonObject();
        String qstr=Util.getElementAsString(object,"from_query");
        JsonObject query = Util.isNull(qstr)?new JsonObject():JsonParser.parseString(qstr).getAsJsonObject();
        JsonArray sendData =JsonParser.parseString(Util.getElementAsString(object,"form_value")).getAsJsonArray();
        object.add("query", query);
        object.add("form_value", sendData);
        object.add("location", location);

        String target = Util.getElementAsString(query, "userName");
        String sid = Util.getElementAsString(query, "reallysid");
        String phone = Util.getElementAsString(query, "phone");
        object.addProperty("userName", target);
        object.addProperty("sid", sid);
        object.addProperty("phone", phone);
        JsonArray newObjectdata=new JsonArray();
        GZGaPoliceCheckPostAction.rebuildData(object, newObjectdata);

        JsonObject data =new JsonObject();
        data.addProperty("phone",phone);
        data.addProperty("sid", sid);
        data.add("data", newObjectdata);
        data.addProperty("police_target_phone", "");
        data.add("location", object.get("location"));

        return data.toString();
    }

    public JsonObject importExcelData(String filepath, String tableSchema, String tablename) {
        JsonObject result = new JsonObject();
        List<Map<String, String>> datalist = ExcelUtil.getExcelData(filepath);
        if (datalist == null || datalist.size() == 0) {
            result.addProperty("importSize", 0);
            result.addProperty("msg", "No data in excel.");
            return result;
        }
        String sqlidQryFields = "queryTableFields";
        try {
            JsonObject params = new JsonObject();
            params.addProperty("table_schema", tableSchema);
            params.addProperty("source_tablename", tablename);
            String qryFieldsSql = XmlSqlGenerator.getSqlByJson(sqlidQryFields, null, params);
            JsonArray array = SqlUtil.queryForJson(ds, qryFieldsSql);
            if (array.size() == 0) {
                result.addProperty("importSize", 0);
                result.addProperty("msg", "Failed to query title from " + tableSchema + "." + tablename);
                return result;
            }

            Map<String, String> fieldmap = Maps.newHashMap();
            for (JsonElement element : array) {
                JsonObject obj = element.getAsJsonObject();
                String colName = Util.getElementAsString(obj, "column_name");
                String colComment = Util.getElementAsString(obj, "column_comment");
                fieldmap.put(colComment, colName);
            }

            List<List<String>> sqlParams = new ArrayList<>();
            StringBuilder sb = new StringBuilder("insert into " + tableSchema + "." + tablename + "(");
            boolean isAppend = false;
            int paramNum = 0;
            for (Map<String, String> map : datalist) {
                List<String> rowParams = new ArrayList<>();
                for (Map.Entry<String, String> entry : map.entrySet()) {
                    String dataKey = entry.getKey();
                    String dataVal = entry.getValue();
                    if (fieldmap.containsKey(dataKey)) {
                        if (!isAppend) {
                            sb.append(fieldmap.get(dataKey)).append(",");
                            paramNum++;
                        }

                        if ("publicdate".equals(fieldmap.get(dataKey)) || "submitdate".equals(fieldmap.get(dataKey))) {
                            dataVal = Util.isNull(dataVal) ? LocalDateTime.now().format(DateTimeFormatter.ofPattern("YYYY-MM-dd HH:mm:ss")) : dataVal;
                        }


                        rowParams.add(dataVal);
//                        map.put(fieldmap.get(dataKey), dataVal);
//                        map.remove(dataKey);
                    }
                }
                isAppend = true;
                sqlParams.add(rowParams);
            }
            sb.deleteCharAt(sb.length() - 1);
            sb.append(")");
            if (paramNum > 0) {
                sb.append(" values(");
                for (int n = 0 ; n < paramNum; n++) {
                    sb.append("?,");
                }
                sb.deleteCharAt(sb.length() - 1);
                sb.append(")");
            }
            sb.append(";");
            boolean flag = SqlUtil.batchUpdateRecords(ds, sb.toString(), sqlParams);
            if (flag) {
                result.addProperty("importSize", sqlParams.size());
                result.addProperty("msg", "import success.");
                return result;
            } else {
                result.addProperty("importSize", 0);
                result.addProperty("msg", "import failed.");
                return result;
            }
        } catch (Exception e) {
            log.error("import excel error.", e);
        }
        return result;
    }
}
