package org.ydzy.bot;

import java.util.Arrays;

import org.apache.commons.codec.DecoderException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.ydzy.util.Util;

/** ��ͨ�����Ż���sinature����֤���� */
public class VerifySignature implements IVerify {
	static final String KEY_VERIFY_SIGNATURE = KEY_VERIFY + "signature";
	static final Logger log = LoggerFactory.getLogger(VerifySignature.class);
	
	@Override
	public Object verify(RequestContext request, BotInfo bi) throws VerifyError{
		String error = null;
		String timestamp = request.getHeader("timestamp");
		String signature = request.getHeader("signature");
		String nonce = request.getHeader("nonce");
		if(signature==null || timestamp==null && nonce==null) {
			error = "One of parameter(signature, timestamp, nonce) is null";
		}else {
			// ���ʱ��ǩ������
			if(bi.getBotAccess().getSinatureTimeout() > 0) {
				long time = Long.parseLong(timestamp);
				long curTime = System.currentTimeMillis()/1000;
				if(curTime-time > bi.getBotAccess().getSinatureTimeout()) {
					throw new VerifyError("time is too old(" + timestamp + ")");
				}
			}
			if(!verify(timestamp, nonce, bi.getToken(), signature)) {
				error = "check sinature error";
			}else {
				return null;
			}
		}
		log.debug("check sinature error(" + error + ")");
		throw new VerifyError(error);
	}
	
	/***
	 * ��֤��¼�Ƿ���ȷ
	 * @param timestame
	 * @param nonce
	 * @param token
	 * @param signature
	 * @return
	 */
	public boolean verify(String timestame, String nonce, String token, String signature) {
		String[] tmps = new String[] {timestame, nonce, token};
		try {
			Arrays.sort(tmps);
		} catch (Exception e1) {
		}
		String text = String.join("", tmps);
		byte[] mine = Util.getSHA256StrJava(text);
		byte[] your = null;
		try {
			your = org.apache.commons.codec.binary.Hex.decodeHex(signature.toCharArray());
		} catch (DecoderException e) {
			log.debug("wrong parameter sinature(" + signature + ")",e);
		}
		return Arrays.compare(mine, your)==0;
	}
}
