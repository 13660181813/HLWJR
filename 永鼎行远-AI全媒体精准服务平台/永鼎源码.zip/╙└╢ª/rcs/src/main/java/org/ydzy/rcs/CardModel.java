package org.ydzy.rcs;

import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.ydzy.handler.BaseRcsContext;
import org.ydzy.rcs.entity.ReceiveEntity;
import org.ydzy.util.ParamUtils;
import org.ydzy.util.Util;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

/**
 * @author XFDEP card html
 */
public interface CardModel {
	public String cardHtml(ReceiveEntity requestObject, JsonObject eobject, BaseRcsContext context,boolean send25gMsg);
	/**ͨ������������ ԭʼ�������Ϣ�ṹ�������ٷ�װ
	 * @param  send25gMsg true ����5G��Ϣ; false ����H5��Ϣ
	 * @return ������Ϣ�ṹ�� 
	 */
	public JsonObject constructMsgStructure(ReceiveEntity requestObject,JsonObject eobject,BaseRcsContext context,boolean send25gMsg);
	public default Object[] initParams(String params, ReceiveEntity requestObject,BaseRcsContext context) {
		Gson gson = new Gson();
//		Map<String,Object> answersObject =requestObject.getAnswersObject();
		JsonObject all = JsonParser.parseString(gson.toJson(requestObject)).getAsJsonObject();
//		requestObject.setAnswersObject(answersObject);
		String[] paramsArray = Util.isNull(params) ? null : params.split(",");
		if (paramsArray == null)
			return null;
		Object[] newObject = new Object[paramsArray.length];
		for (int i = 0; i < paramsArray.length; i++) {
			String p1 = paramsArray[i];
//			newObject[i] = Util.getElementAsString(all, p1);
//			if ((newObject[i] == null || Util.isNull(newObject[i].toString())) && all.has("answersObject")
//					&& !all.get("answersObject").isJsonNull()) {
//				newObject[i] = Util.getElementAsString(all.get("answersObject").getAsJsonObject(), p1);
//			}
			String v =ParamUtils.convertV(requestObject,context,p1);
			newObject[i]=v;
		}
		return newObject;
	}
	public default String formatVues(String msg, Map<String, String> paramObject) {
		 return ParamUtils.formatVues(msg, paramObject);
	}
	public default String replaceParam(String content, ReceiveEntity requestObject, BaseRcsContext context) {
		return ParamUtils.replaceParam(content, requestObject, context);
	}

	public static void main(String[] args) {
		String regexParam = "\\{([^\\{\\}:]*)\\}";
		Pattern regexPattern = Pattern.compile(regexParam);
		String str = "{}";
		Matcher matcher = regexPattern.matcher(str);
		if(matcher.find()){
			String group = matcher.group(1);

			System.out.println(group);
		}

	}
}
