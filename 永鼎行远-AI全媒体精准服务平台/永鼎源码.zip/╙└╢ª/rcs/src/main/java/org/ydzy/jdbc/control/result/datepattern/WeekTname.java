package org.ydzy.jdbc.control.result.datepattern;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.ydzy.rcs.annotation.Description;

import com.google.inject.Singleton;

@Description(autoInstance = false,value = "weekTname")
@Singleton
public class WeekTname implements ITime {

	@Override
	public List<String> reckonName(String pattern,long timeInterval,  String sDate, String eDate, Calendar c1, Calendar c2) throws ParseException {
		{
			List<String> tablelist =new ArrayList<String>();
			if(pattern.indexOf("'")<0) {
				tablelist.add(pattern);
				return tablelist;
			}
			SimpleDateFormat sdfPattern = new SimpleDateFormat(pattern);
			
			String radiustable =pattern
					.substring(pattern.indexOf("'") + 1, pattern.lastIndexOf("'")).toUpperCase();
			// 绮掑害 - 1鍛� pfix$w1_yyw
			if (timeInterval == 604800) {
				int start0=-1;
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				c2.setFirstDayOfWeek(start0); // 璁剧疆姣忓懆浠庡懆鍑犲紑濮嬶紝榛樿涓哄懆涓�锛屽彲鍦▁ml涓厤缃�
				c1.setFirstDayOfWeek(start0); // 璁剧疆姣忓懆浠庡懆鍑犲紑濮嬶紝榛樿涓哄懆涓�锛屽彲鍦▁ml涓厤缃�
				c1.setMinimalDaysInFirstWeek(3);
				c2.setMinimalDaysInFirstWeek(3);
				c1.setTime(sdf.parse(sDate));
				c2.setTime(sdf.parse(eDate));
				radiustable = radiustable.replace("$", "W");
				java.text.DecimalFormat df = new java.text.DecimalFormat("00");
				sdfPattern = new SimpleDateFormat("'" + radiustable + "'yy");
				String tn = sdfPattern.format(c1.getTime()) + df.format(c1.get(Calendar.WEEK_OF_YEAR));
				tablelist.add(tn);
				long dif = c2.getTimeInMillis() - c1.getTimeInMillis();
				dif = dif % (24 * 60 * 60 * 1000 * 7) == 0 ? dif / (24 * 60 * 60 * 1000 * 7)
						: dif / (24 * 60 * 60 * 1000 * 7) + 1;
				for (int i = 1; i < dif; i++) {
					tn = sdfPattern.format(c1.getTime()) + df.format(c1.get(Calendar.WEEK_OF_YEAR) + i);
					if (!tablelist.contains(tn)) {
						tablelist.add(tn);
					}
				}

			}
			return tablelist;
		}
	}

}
