package org.ydzy.rcs.media;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.*;
import com.google.inject.Singleton;
import org.ydzy.rcs.Upload;
import org.ydzy.rcs.annotation.Description;
import org.ydzy.rcs.db.XmlSqlGenerator;
import org.ydzy.util.NetUtils;
import org.ydzy.util.SqlUtil;
import org.ydzy.util.Util;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Base64;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

import org.ydzy.rcs.RcsConfig;
import org.ydzy.rcs.Upload;
import org.ydzy.rcs.annotation.Description;
import org.ydzy.util.NetUtils;
import org.ydzy.util.Util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.inject.Inject;
import com.google.inject.Singleton;
@Singleton
@Description("uploadHw")
public class UploadByHw extends Upload{
	private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(UploadByHw.class);
	Gson gson=new Gson();
	@Inject
	RcsConfig rscconfig;
	public UploadByHw()
	{
		startMediaCheck();
	}
	private void startMediaCheck() {
		Thread thread=new Thread()
		{
	public void run()
	{
		while(true)
		{
			try {
				UploadFileEntity entity = retryQueue.take();
				if (entity.getOtherParam() == null)
					entity.setOtherParam(new JsonObject());
				entity.getOtherParam().addProperty("lastUpload", System.currentTimeMillis());
				doUpload(entity);
				Thread.sleep(1000);
			} catch (InterruptedException e1) {
				e1.printStackTrace();
			}
		}
		
	}
		};
		thread.setName("MediaNofiyCheckThread");
		thread.start();
	}
	/*
	 {
"resCode":"0",
"resMsg":"�ɹ�",
"result":[
{
"authStatus":0,
"createdBy":"00000000000000000001",
"createdBy.__objectType":"User",
"createdBy.name":"system",
"createdDate":"2021-03-16 10:02:31",
"currencyIsoCode":"USD",
"description":null,
"expriedTime":"2021-05-16 07:59:59",
"id":"0045000000i93HQmmhHs",
"installedPackage":null,
"lastModifiedBy":"00000000000000000001",
"lastModifiedBy.__objectType":"User",
"lastModifiedBy.name":"system",
"lastModifiedDate":"2021-03-16 10:02:31",
"mediaFileName":"default",
"mediaType":"image/jpeg",
"mediaURL":"https://http01.hn.rcs.chinamobile.com:9091/Access/PF?ID=OTczQzA3RjlBMDNBRTlGRUI2QkEwNDQ4MTkyQkREMzM4MEZCMDA5ODY0RTZFRkYyMDUyMENBRjU0Qjg0NjAyRUY0QjMzNUMwREMwMjBENjYxMzU0MTA0QzYxNjMwMkU0",
"name":"7732205616924966183",
"owner":"00000000000000000001",
"owner.__objectType":"User",
"owner.name":"system",
"size":9953,
"thumbnailFileName":"default",
"thumbnailType":"image/jpeg",
"thumbnailURL":"https://http01.hn.rcs.chinamobile.com:9091/Access/PF?ID=MzMzMkJBQzQ5QjU4QUY4REJEMzQ1OUU3QTgyNzFERjA4MUE4NjgyRjJGRTFCNERGQzFCOEI1Qjg2NzZCOTYwRjhCODkzMzA0OTUyQTBCNzFBQjY4NjI2OTczNDQ2RkMw",
"tid":"7732205616924966183",
"zoujiabing__dirID__CST":null,
"zoujiabing__mediaOBSURL__CST":null,
"zoujiabing__newTid__CST":"",
"zoujiabing__processNum__CST":0,
"zoujiabing__processTime__CST":"2021-03-16",
"zoujiabing__thumbnailOBSURL__CST":null
}
],
"count":1
}
	 */
	DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	public  void doUpload(UploadFileEntity param)
	{
		try {
			JsonArray resultArray=upload(param.getContentLocalPath(), param.getThumbnailLocalPath());
			if(resultArray!=null&&!resultArray.isJsonNull()&&resultArray.size()>0)
				{
					for(int i=0;i<resultArray.size();i++)
					{
						JsonObject eo=resultArray.get(i).getAsJsonObject();
						param.setAuthStatus(Util.getElementAsString(eo, "authStatus"));
						Date expriedDate = df.parse(Util.getElementAsString(eo, "expriedTime")+"");
						param.setExpiredTime(expriedDate.getTime());
//						Instant it=Instant.parse(Util.getElementAsString(eo, "expriedTime"));
//						param.setExpiredTime(it.getLong(ChronoField.MILLI_OF_SECOND));

						param.setMediacontentType(Util.getElementAsString(eo, "mediaType"));
						param.setMediaUrl(Util.getElementAsString(eo, "mediaURL"));
						param.setTid(Util.getElementAsString(eo, "tid"));
						param.setThumbnailContentType(Util.getElementAsString(eo, "thumbnailType"));
						param.setThumbnailUrl(Util.getElementAsString(eo, "thumbnailURL"));
						param.setOtherParam(eo);
						param.setFileSize(Long.valueOf(Util.getElementAsString(eo, "size")));
						String sqlId = "updateUploadMedias";
						try {
							String sql = XmlSqlGenerator.getSqlstr(sqlId);
							Object[] insertParams = new Object[11];
							insertParams[0] = param.getMediaUrl();
							insertParams[1] = 1;
							insertParams[2] = param.getMediacontentType();
							insertParams[3] = param.getThumbnailUrl();
							insertParams[4] = param.getInterviewId();
							insertParams[5] = param.getTid();
							insertParams[6] = param.getThumbnailContentType();
							insertParams[7] = new java.util.Date(param.getExpiredTime());
							insertParams[8] = param.getAuthStatus();
							insertParams[9] = new java.util.Date();
							insertParams[10] = param.getMediaID();
							boolean result = SqlUtil.updateRecords(dbSource, sql, insertParams);
							log.info("medias insert to db {}", result);
						} catch (SQLException e) {
							log.error("medias insert to db failed. sqlId={}", sqlId, e);
						}
					}
					log.info("upload sucess ! fileinfo {} " ,gson.toJson(param));
				}else
				{
					if(param.getOtherParam() == null || !param.getOtherParam().has("lastUpload"))
					retryQueue.add(param);
				}
		} catch (IOException | ParseException e) {
			e.printStackTrace();
		}
	}
	private static final String uploadurl ="https://appcube.cn-north-4.huaweicloud.com/u-route/baas/flow/v1.0/nasc__MediaLib_UploadFile?version=1.0.1";
	public  JsonArray upload(String mediaSrc,String thumbSrc) throws IOException
	{
		String token =getToken();
		
//		String url="http://192.168.8.241:20080/";
		Map<String,Object> map=newHeaders(token,"application/json");
		
		//
		Map<String,String> files =new HashMap<String,String>();
		try {
			byte [] medirbytes=Files.readAllBytes(Path.of(mediaSrc));
			files.put("content",  "data:image/jpeg;base64,"+new String(Base64.getEncoder().encode(medirbytes)));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			byte [] medirbytes=Files.readAllBytes(Path.of(thumbSrc));
			files.put("thumbnail", "data:image/jpeg;base64,"+new String(Base64.getEncoder().encode(medirbytes)));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String fileName=Path.of(mediaSrc).getFileName().toString();
		files.put("fileName", fileName);
		 ObjectMapper objectMapper = new ObjectMapper();
		 
		String content=NetUtils.doHttps(uploadurl, 
				objectMapper.writeValueAsString(files)
				,map,
				"application/json");
		log.info(content);
		JsonElement e =JsonParser.parseString(content);
		/*
		 {
    "resCode":"0",
    "resMsg":"�ɹ�",
    "result":{
        "interviewId":"002N000000i8DfkP081I",
        "outputs":{
            "uploadResult":{
                "fileName":"1.jpg",
                "file_type":"image/jpeg",
                "status":"success",
                "thumbnail_type":"image/jpeg",
                "tid":"3509032668649686731"
            }
        }
    }
}
		 * */
		if(e!=null&& !e.isJsonNull())
		{
			JsonObject object=e.getAsJsonObject();
			int resCode=object.get("resCode").getAsInt();
			String resMsg=object.get("resMsg").getAsString();
			JsonObject result=object.getAsJsonObject("result");
			if(result!=null&&!result.isJsonNull()&&resCode==0)
			{
				String interviewId=result.get("interviewId").getAsString();
				 JsonObject outputs=result.getAsJsonObject("outputs");
				 if(outputs!=null&&!outputs.isJsonNull())
				 {
					JsonObject uploadResult= outputs.getAsJsonObject("uploadResult");
					
					String tid=uploadResult.get("tid").getAsString();
					JsonArray array= baseMedia(tid,token,fileName);
					return array;
				 }
			}else
			{
				log.info(resMsg);
			}
			
		}
		return null;
		
	}
	private static final String mediaCheckUrl="https://appcube.cn-north-4.huaweicloud.com/u-route/baas/data/v1.0/query/Media?base=N";
	private  BlockingQueue<UploadFileEntity> retryQueue=new LinkedBlockingQueue<UploadFileEntity>();
	private  JsonArray baseMedia(String tid,String token,String fileName)
	{
		//{"condition":{"conjunction":"AND","conditions":[{"field":"tid","operator":"eq","value":"1443871121605637055"}]}}
	
		JsonObject params=new JsonObject();
		params.addProperty("field", "tid");
		params.addProperty("operator", "eq");
		params.addProperty("value", tid);
		
		JsonArray conditions=new JsonArray();
		conditions.add(params);
		
		JsonObject allParams=new JsonObject();
		
		allParams.addProperty("conjunction", "AND");
		allParams.add("conditions", conditions);
		
		JsonObject all=new JsonObject();
		all.add("condition", allParams);
		
		Map<String,Object> header=newHeaders(token,"application/json");
		 int retry=0;
			try {
				while(retry<5) {
					String content=NetUtils.doHttps(mediaCheckUrl, 
							new Gson().toJson(all)
							,header,
							"application/json");
//					System.out.println(content);
					JsonElement resultObject=JsonParser.parseString(content);
					if(resultObject!=null&&!resultObject.isJsonNull())
					{
						JsonObject obj=resultObject.getAsJsonObject();
						if(obj!=null&&!obj.isJsonNull())
						{
							int resCode=obj.get("resCode").getAsInt();
							JsonArray resultArray=obj.get("result").getAsJsonArray();
							if(resCode==0&&resultArray!=null&&!resultArray.isJsonNull()&&resultArray.size()>0)
							{
								return resultArray;
//								if()
//								{
//									for(int i=0;i<resultArray.size();i++)
//									{
//										JsonObject eo=resultArray.get(i).getAsJsonObject();
//										MediaConfirm(eo,fileName,token);
//									}
//									break;
//								}
							}
						}
					}
					retry++;
					Thread.sleep(3000);
				}
				
				/*
				 {
    "resCode":"0",
    "resMsg":"�ɹ�",
    "result":[
        {
            "authStatus":0,
            "createdBy":"00000000000000000001",
            "createdBy.__objectType":"User",
            "createdBy.name":"system",
            "createdDate":"2021-03-16 10:02:31",
            "currencyIsoCode":"USD",
            "description":null,
            "expriedTime":"2021-05-16 07:59:59",
            "id":"0045000000i93HQmmhHs",
            "installedPackage":null,
            "lastModifiedBy":"00000000000000000001",
            "lastModifiedBy.__objectType":"User",
            "lastModifiedBy.name":"system",
            "lastModifiedDate":"2021-03-16 10:02:31",
            "mediaFileName":"default",
            "mediaType":"image/jpeg",
            "mediaURL":"https://http01.hn.rcs.chinamobile.com:9091/Access/PF?ID=OTczQzA3RjlBMDNBRTlGRUI2QkEwNDQ4MTkyQkREMzM4MEZCMDA5ODY0RTZFRkYyMDUyMENBRjU0Qjg0NjAyRUY0QjMzNUMwREMwMjBENjYxMzU0MTA0QzYxNjMwMkU0",
            "name":"7732205616924966183",
            "owner":"00000000000000000001",
            "owner.__objectType":"User",
            "owner.name":"system",
            "size":9953,
            "thumbnailFileName":"default",
            "thumbnailType":"image/jpeg",
            "thumbnailURL":"https://http01.hn.rcs.chinamobile.com:9091/Access/PF?ID=MzMzMkJBQzQ5QjU4QUY4REJEMzQ1OUU3QTgyNzFERjA4MUE4NjgyRjJGRTFCNERGQzFCOEI1Qjg2NzZCOTYwRjhCODkzMzA0OTUyQTBCNzFBQjY4NjI2OTczNDQ2RkMw",
            "tid":"7732205616924966183",
            "zoujiabing__dirID__CST":null,
            "zoujiabing__mediaOBSURL__CST":null,
            "zoujiabing__newTid__CST":"",
            "zoujiabing__processNum__CST":0,
            "zoujiabing__processTime__CST":"2021-03-16",
            "zoujiabing__thumbnailOBSURL__CST":null
        }
    ],
    "count":1
}
				 */
				
			
			} catch (JsonProcessingException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return null;
	}
	private  void MediaConfirm(JsonObject result,String fileName,String token)
	{
		String url="https://appcube.cn-north-4.huaweicloud.com/u-route/baas/data/v1.0/bobject/Media";
		/*
		 {
    "records":[
        {
            "name":"1443871121605637055",
            "tid":"1443871121605637055",
            "size":9953,
            "mediaType":"image/jpeg",
            "thumbnailType":"image/jpeg",
            "mediaFileName":"1.jpg",
            "thumbnailFileName":"1.jpg",
            "authStatus":1,
            "mediaURL":"non-checked",
            "thumbnailURL":"",
            "expriedTime":null,
            "zoujiabing__dirID__CST":"cMdU000000h3g0Lrz34q",
            "zoujiabing__processNum__CST":0,
            "zoujiabing__processTime__CST":"2021-03-15"
        }
    ]
}
		 */
		JsonObject myrequest=new JsonObject();
		myrequest.addProperty("name", Util.getElementAsString(result, "tid"));
		myrequest.addProperty("tid", Util.getElementAsString(result, "tid"));
		myrequest.addProperty("size", Util.getElementAsString(result, "size"));
		myrequest.addProperty("mediaType", Util.getElementAsString(result, "mediaType"));
		myrequest.addProperty("thumbnailType", Util.getElementAsString(result, "thumbnailType"));
		
		myrequest.addProperty("mediaFileName", fileName);
		myrequest.addProperty("thumbnailFileName", fileName);
		myrequest.addProperty("authStatus", 1);
		
		myrequest.addProperty("mediaURL", Util.getElementAsString(result, "mediaURL"));
		myrequest.addProperty("thumbnailURL", Util.getElementAsString(result, "thumbnailURL"));
		myrequest.addProperty("expriedTime", Util.getElementAsString(result, "expriedTime"));
		
		JsonArray records =new JsonArray();
		records.add(myrequest);
		JsonObject all =new JsonObject();
		all.add("records", records);
		Map<String,Object> header=newHeaders(token,"application/json");
		try {
			String content=NetUtils.doHttps(url, 
					new Gson().toJson(all)
					,header,
					"application/json");
//			System.out.println(content);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	public static Map<String, Object> newHeaders(String access_token,String content_type)
	{
		Map<String,Object> map=new HashMap<String,Object>();
		   map.put("Connection","keep-alive");
		   map.put("User-Agent","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.82 Safari/537.36");
		   map.put("csrf-token", "4Nqfp7FFhfZaNE6z5suhTob10fkvBzEPTRZw8x+EOkE=");
		   map.put("access-token", access_token);
		   map.put("Content-Type", content_type);
		   map.put("Accept-Language", "zh-CN,zh;q=0.9");
		   map.put("Accept", "*/*");
		   map.put("Origin", "https://appcube.cn-north-4.huaweicloud.com");
		   map.put("sec-ch-ua","Google Chrome\";v=\"89\", \"Chromium\";v=\"89\", \";Not A Brand\";v=\"99\"");
//		   map.put("Origin","https://appcube.cn-north-4.huaweicloud.com");
		   map.put("Sec-Fetch-Site","same-origin");
		   map.put("Sec-Fetch-Mode","cors");
		   map.put("Sec-Fetch-Dest","empty");
		   map.put("Referer","https://appcube.cn-north-4.huaweicloud.com/magno/render/nasc__MediaLibSuite_0000000000dMF1m99Nq4/companyMediaLib?securityKey=yd");
//		   map.put("cookie", " vk=3d762e49-78d4-45e9-946d-69b79567de8a; deviceid=2VX18xsD; _ga=GA1.2.232746351.1614917756; locale=zh-cn; __ozlvd1791=1614919793;"
//		 		+ " HWWAFSESID=95a9573e47ffddecdf; HWWAFSESTIME=1615803020292; ");
		   return map;
	}
	private static final String tokenurl="https://appcube.cn-north-4.huaweicloud.com/baas/auth/v1.0/oauth2/token";
	public static String getToken()
	{
	
		try {
			//
			Map<String,Object> map=newHeaders("","application/x-www-form-urlencoded");

			String content=NetUtils.doHttps(tokenurl, 
					"grant_type=client_credentials&client_id=0def07cb84824112a05ad3f345f4a499&client_secret=1ec92c083ff04b2fd116c6c6cdda28786ef27ded3cdecf84"
					,map,
					"application/x-www-form-urlencoded");
//			System.out.println(content);
			JsonElement e = JsonParser.parseString(content);
			if(e!=null && !e.isJsonNull()&& e.isJsonObject())
			{
				return e.getAsJsonObject().get("access_token").getAsString();
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "";
	}
	public static void main(String[] args) throws IOException {
//		upload("C:\\Users\\XFDEP\\Desktop\\23434343.jpg","C:\\Users\\XFDEP\\Desktop\\23434343.jpg");
	}
}
