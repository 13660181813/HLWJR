package org.ydzy.rcs.action;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.inject.Inject;
import com.google.inject.name.Named;
import org.ydzy.rcs.db.XmlSqlGenerator;
import org.ydzy.rcs.db.XmlSqlGenerator.innerSql;
import org.ydzy.util.SqlUtil;
import org.ydzy.util.Util;

import javax.sql.DataSource;
import java.util.HashMap;
import java.util.Map;

/**
 * @author lirui
 * @Date 2021/7/19 6:21 ����
 */
public class TagManagerAction {
    static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(TagManagerAction.class);
    @Inject
    @Named("rcsDb")
    DataSource ds;

    public JsonArray queryTags(JsonObject params) {
        JsonArray array = new JsonArray();
        String sqlId = "queryTags";
        try {
            String sql = XmlSqlGenerator.getSqlByJson(sqlId, null, params);
            JsonArray jsonArray = SqlUtil.queryForJson(ds, sql);
            Map<String, JsonObject> parentmap = new HashMap<>();
            Map<String, JsonArray> submap = new HashMap<>();
            for(JsonElement ele : jsonArray) {
                JsonObject object = ele.getAsJsonObject();
                String parentid = Util.getElementAsString(object, "parentid");
                if (!parentmap.containsKey(parentid)) {
                    String parenttype = Util.getElementAsString(object, "parenttype");
                    JsonObject parentObject = new JsonObject();
                    parentObject.addProperty("parentid", parentid);
                    parentObject.addProperty("tagsubtype", parenttype);
                    parentObject.addProperty("ISP", Util.getElementAsString(object, "ISP"));
                    parentObject.addProperty("hasChildren", Util.getElementAsString(object, "hasChildren"));
                    parentObject.addProperty("tagno", Util.getElementAsString(object, "tagno"));
                    parentmap.put(parentid, parentObject);
                }

                JsonArray subArray = submap.computeIfAbsent(parentid, k-> new JsonArray());
                object.remove("parentid");
                object.remove("parenttype");
                subArray.add(object);
            }
            parentmap.forEach((s, jsonObject) -> {
                if (submap.containsKey(s) && submap.get(s).size() > 0) {
                    JsonArray subArray = submap.get(s);
                    if (subArray == null)
                        subArray = new JsonArray();
                    jsonObject.add("children", subArray);
                    if (subArray.size() == 1 && Util.isNull(Util.getElementAsString(subArray.get(0).getAsJsonObject(), "tagsubtype")))
                        jsonObject.addProperty("hasChildren", "0");
                    else
                        jsonObject.addProperty("hasChildren", "1");
                }
                array.add(jsonObject);
            });
        } catch (Exception e) {
            log.error("query tags error.", e);
        }
        return array;
    }

    public boolean editTag(JsonObject params) {
        boolean flag = false;
        String sqlId = "editTagsByTagId";
        try {
            String owner = params.getAsJsonArray("owner").toString().replace("[", "").replace("]", "");
            Map<String, Object> mapParams = new HashMap<>();
            mapParams.put("editby", Util.getElementAsString(params, "username"));
            mapParams.put("tagtype", Util.getElementAsString(params, "tagtype"));
            mapParams.put("tagsubType", Util.getElementAsString(params, "tagsubType"));
            mapParams.put("ISP", Util.getElementAsString(params, "ISP"));
            mapParams.put("tagId", Util.getElementAsString(params, "tagId"));
            mapParams.put("owner", owner);
            mapParams.put("visibleChatbot", Util.getElementAsString(params, "visibleChatbot"));
            innerSql sql = XmlSqlGenerator.getSqlByMap(sqlId, mapParams);
            return SqlUtil.updateRecords(ds, sql.exeSql,sql.sqlParams.toArray());
        } catch (Exception e) {
            log.error("edit tags error.", e);
        }
        return flag;
    }

    public boolean addTag(JsonObject params) {
        String sqlId = "insertTagsByTagId";
        try {
            long nextTagId = getNextTagId();
            String owner = params.getAsJsonArray("owner").toString().replace("[", "").replace("]", "");
            Map<String, Object> mapParams = new HashMap<>();
            mapParams.put("editby", Util.getElementAsString(params, "username"));
            mapParams.put("tagtype", Util.getElementAsString(params, "tagtype"));
            mapParams.put("tagsubType", Util.getElementAsString(params, "tagsubType"));
            mapParams.put("ISP", Util.getElementAsString(params, "ISP"));
            mapParams.put("tagId", nextTagId);
            mapParams.put("owner", owner);
            mapParams.put("visibleChatbot", Util.getElementAsString(params, "visibleChatbot"));
            innerSql sql = XmlSqlGenerator.getSqlByMap(sqlId, mapParams);
            return SqlUtil.updateRecords(ds, sql.exeSql,sql.sqlParams.toArray());
        } catch (Exception e) {
            log.error("add tags error.", e);
        }
        return false;
    }

    public boolean deleteTag(String tagId) {
        String sqlId = "deleteTagsByTagId";
        try {
            String sql = XmlSqlGenerator.getSqlstr(sqlId, tagId);
            return SqlUtil.updateRecords(ds, sql);
        } catch (Exception e) {
            log.error("delete tags error.", e);
        }
        return false;
    }

    private long getNextTagId() {
        String sqlId = "getNextTagId";
        try {
            String sql = XmlSqlGenerator.getSqlstr(sqlId);
            return SqlUtil.getLastInsertId(ds, sql);
        }catch (Exception e) {
            log.error("get netxt tagid error.", e);
        }
        return -1;
    }

    public boolean allot2config(JsonObject object, String username) {
        if (object == null || !object.has("tags"))
            return false;
        try {
            JsonArray tags = object.getAsJsonArray("tags");
            String deleleAllotConfigSqlId = "delAllotConfigTags";
            String allotConfigSqlId = "allotConfigTags";
            String configid = Util.getElementAsString(object, "configid");
            StringBuilder sqlBuilder = new StringBuilder();
            allottag : for (JsonElement ele : tags) {
                JsonObject tagObject = ele.getAsJsonObject();
                String tagno = Util.getElementAsString(tagObject, "tagno");
                String operator = Util.getElementAsString(tagObject, "operator");
                JsonObject params = new JsonObject();
                params.addProperty("configid", configid);
                params.addProperty("tagno", tagno);
                params.addProperty("alloter", username);
                String sqlid = "";
                switch (operator) {
                    case "-1" -> {
                        sqlid = deleleAllotConfigSqlId;
                    }
                    case "1" -> {
                        sqlid = allotConfigSqlId;
                    }
                    default -> {
                        continue allottag;
                    }
                }
                String sql = XmlSqlGenerator.getSqlByJson(sqlid, null, params);
                sqlBuilder.append(sql).append(";");
            }
            return SqlUtil.updateRecords(ds, sqlBuilder.toString());
        }catch (Exception e) {
            log.error("allot tags 2 config error.", e);
        }
        return false;
    }
}
