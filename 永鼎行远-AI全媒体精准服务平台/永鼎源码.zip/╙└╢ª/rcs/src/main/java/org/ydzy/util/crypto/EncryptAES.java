package org.ydzy.util.crypto;

import java.io.UnsupportedEncodingException;

import java.security.InvalidAlgorithmParameterException;

import java.security.InvalidKeyException;

import java.security.NoSuchAlgorithmException;

import java.security.SecureRandom;

import java.util.HashMap;

import java.util.Iterator;

import java.util.Map;

import java.util.Set;

import java.util.TreeMap;

import javax.crypto.BadPaddingException;

import javax.crypto.Cipher;

import javax.crypto.IllegalBlockSizeException;

import javax.crypto.KeyGenerator;

import javax.crypto.Mac;

import javax.crypto.NoSuchPaddingException;

import javax.crypto.SecretKey;

import javax.crypto.spec.IvParameterSpec;

import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.binary.Base64;
import org.ydzy.util.Util;

public class EncryptAES {

// ���뷽ʽ

	private static final String CHARSET = "UTF-8";

// �������� 256���ܣ�AES256_CBC_PKCS5Padding��ʱ��1��128���ܣ�AES128_CBC_PKCS5Padding��ʱ��2

	private static final String ENCRYPT_TYPE_256 = "1";

// ��������Ϣ�����keyֵ����Ҫ�滻Ϊ�Լ���key��

	private static final String ACCESS_KEY = "ydxy!@#$%";

	public static void main(String args[]) throws Exception {

// ------------��������֤����---------------

// ������ת��Ϊmap��ģ���request�л�ȡ����������request.getParameterMap()��

		Map<String, String[]> paramsMap = getTestUrlMap();

// �������� 256���ܣ�AES256_CBC_PKCS5Padding����128���ܣ�AES128_CBC_PKCS5Padding��

		System.out.println("��������֤����:" + verificateRequestParams(paramsMap, ACCESS_KEY, 256));

// ��Ҫ���ܵ��ֻ��������

		String needEncryptStr = "15905222222";

		String encryptStr = generateSaaSUsernameOrPwd(needEncryptStr, ACCESS_KEY, ENCRYPT_TYPE_256);

		System.out.println("���ܵ��ֻ��������:" + encryptStr);

// ����

		String decryptStr = decryptMobilePhoneOrEMail(ACCESS_KEY, encryptStr, ENCRYPT_TYPE_256);

		System.out.println("���ܵ��ֻ��������:" + decryptStr);

// bodyǩ��

		String needEncryptBody =

				"{\"resultCode\":\"00000\",\"resultMsg\":\"����ɹ�\",\"encryptType\":\"1\",\"instanceId\":\"000bd4e1-5726-4ce9-8fe4-fd081a179304\",\"appInfo\"{\"userName\":\"3LQvu8363e5O4zqwYnXyJGWz8y+GAcu0rpM0wQ==\",\"password\":\"RY31aEnR5GMCFmt3iG1hW7UF1HK09MuAL2sgxA==\"}}";

		String encryptBody = generateResponseBodySignature(ACCESS_KEY, needEncryptBody);

		System.out.println("bodyǩ��:" + encryptBody);

	}
	public static String decryptStr(String encryptStr)
	{
		return decryptMobilePhoneOrEMail(ACCESS_KEY, encryptStr, ENCRYPT_TYPE_256);
	}
	public static String encryptStr(String needEncryptStr)
	{
		return generateSaaSUsernameOrPwd(needEncryptStr, ACCESS_KEY, ENCRYPT_TYPE_256);
	}
	private static Map<String, String[]> getTestUrlMap() {

// ԭʼ����http://bzapic.natappfree.cc?activity=newInstance&businessId=61e834ba-7b97-4418-b8f7-e5345137278c&customerId=68cbc86abc2018ab880d92f36422fa0e&expireTime=20200727153156&orderId=CS1906666666ABCDE&productId=00301-666666-0--0&testFlag=1&timeStamp=20200727073711903&authToken=Gzbfjf9LHRBcI3bFVi++sLinCNOBF6qa7is1fvjEgYQ=

		Map<String, String[]> paramsMap = new HashMap<String, String[]>();

		paramsMap.put("activity", new String[] { "newInstance" });

		paramsMap.put("businessId", new String[] { "61e834ba-7b97-4418-b8f7-e5345137278c" });

		paramsMap.put("customerId", new String[] { "68cbc86abc2018ab880d92f36422fa0e" });

		paramsMap.put("expireTime", new String[] { "20200727153156" });

		paramsMap.put("orderId", new String[] { "CS1906666666ABCDE" });

		paramsMap.put("productId", new String[] { "00301-666666-0--0" });

		paramsMap.put("testFlag", new String[] { "1" });

		paramsMap.put("timeStamp", new String[] { "20200727073711903" });

		paramsMap.put("authToken", new String[] { "Gzbfjf9LHRBcI3bFVi++sLinCNOBF6qa7is1fvjEgYQ=" });

		return paramsMap;

	}

	/**
	 * 
	 * У��֪ͨ��Ϣ�ĺϷ���
	 *
	 * 
	 * 
	 * @param accessKey     ������
	 * 
	 * @param encryptLength ���ܳ���
	 * 
	 * @return ��֤���
	 * 
	 */

	public static boolean verificateRequestParams(Map<String, String[]> paramsMap, String accessKey,

			int encryptLength) {

		String timeStamp = null;

		String authToken = null;

		String[] timeStampArray = paramsMap.get("timeStamp");

		if (null != timeStampArray && timeStampArray.length > 0) {

			timeStamp = timeStampArray[0];

		}

		String[] authTokenArray = paramsMap.get("authToken");

		if (null != authTokenArray && authTokenArray.length > 0) {

			authToken = authTokenArray[0];

		}

// ��ʣ�µĲ�����������ƴ�ӳɼ�������

		Map<String, String[]> sortedMap = new TreeMap<String, String[]>();

		sortedMap.putAll(paramsMap);

		sortedMap.remove("authToken");

		StringBuffer strBuffer = new StringBuffer();

		Set<String> keySet = sortedMap.keySet();

		Iterator<String> iter = keySet.iterator();

		while (iter.hasNext()) {

			String key = iter.next();

			String value = sortedMap.get(key)[0];

			strBuffer.append("&").append(key).append("=").append(value);

		}

// ������Ϣ��,ȥ����һ������ǰ���&

		String reqParams = strBuffer.toString().substring(1);

		String key = accessKey + timeStamp;

		String signature = null;

		try {

			signature = generateResponseBodySignature(key, reqParams);

		} catch (InvalidKeyException | NoSuchAlgorithmException | IllegalStateException

				| UnsupportedEncodingException e) {

// TODO Auto-generated catch block

		}

		return authToken.equals(signature);

	}

	public static String generateResponseBodySignature(String key, String body)

			throws InvalidKeyException, NoSuchAlgorithmException, IllegalStateException, UnsupportedEncodingException {

		return base_64(hmacSHA256(key, body));

	}

	public static byte[] hmacSHA256(String macKey, String macData) {

		try {

			try {

				SecretKeySpec secret = new SecretKeySpec(macKey.getBytes(CHARSET), "HmacSHA256");

				Mac mac = Mac.getInstance("HmacSHA256");

				mac.init(secret);

				return mac.doFinal(macData.getBytes(CHARSET));

			} catch (UnsupportedEncodingException e) {

			} catch (InvalidKeyException e) {

			}

		} catch (NoSuchAlgorithmException e) {

		}

		return new byte[0];

	}

// ������bodyǩ��

	public static String generateSaaSUsernameOrPwd(String isvBody, String decryptAccessKey, String sEncryptType) {

		String iv = getRandomChars(16);

		int iEncryptType = 0;

		try {

			iEncryptType = Integer.parseInt(sEncryptType);

		} catch (NumberFormatException exception) {

			iEncryptType = 1;

		}

		int encryptType;

		if (1 == iEncryptType) {

			encryptType = 256;

		} else {

			encryptType = 128;

		}

		String isvEncryptBody = encryptAESCBCEncode(isvBody, decryptAccessKey, iv, encryptType);

		return iv + isvEncryptBody;

	}

	/**
	 * 
	 * AES CBC 256λ����
	 *
	 * 
	 * 
	 * @param content ��������
	 * 
	 * @param key     ������Կ
	 * 
	 * @param iv      ������ֵ
	 * 
	 * @return ���ܽ��
	 * 
	 */

	public static String encryptAESCBCEncode(String content, String key, String iv, int encryptType) {

		if (Util.isNull(content) || Util.isNull(key) || Util.isNull(iv)) {

			return null;

		}

		try {

			byte[] encrypContent =

					encryptAESCBC(content.getBytes(CHARSET), key.getBytes(CHARSET), iv.getBytes(CHARSET), encryptType);

			if (null != encrypContent) {

				return base_64(encrypContent);

			} else {

				return null;

			}

		} catch (UnsupportedEncodingException e) {

			return null;

		}

	}

	public static byte[] encryptAESCBC(byte[] content, byte[] keyBytes, byte[] iv, int encryptType) {

		try {

			KeyGenerator keyGenerator = KeyGenerator.getInstance("AES");

			SecureRandom secureRandom = SecureRandom.getInstance("SHA1PRNG");

			secureRandom.setSeed(keyBytes);

			keyGenerator.init(encryptType, secureRandom);

			SecretKey key = keyGenerator.generateKey();

			Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");

			cipher.init(Cipher.ENCRYPT_MODE, key, new IvParameterSpec(iv));

			return cipher.doFinal(content);

		} catch (Exception e) {

		}

		return null;

	}

	public static String base_64(byte[] bytes) {

		try {

			return new String(Base64.encodeBase64(bytes), CHARSET);

		} catch (UnsupportedEncodingException e) {

			return null;

		}

	}

	static String decryptMobilePhoneOrEMail(String accessKey, String encryptStr, String sEncryptType) {

		String iv = encryptStr.substring(0, 16);

		int iEncryptType = 1;

		try {

			iEncryptType = Integer.parseInt(sEncryptType);

		} catch (NumberFormatException exception) {

			exception.printStackTrace();

		}

		int encryptType;

		if (1 == iEncryptType) {

			encryptType = 256;

		} else {

			encryptType = 128;

		}

		String decryptBody = null;

		try {

			decryptBody = decryptAESCBCEncode(encryptStr.substring(16), accessKey, iv, encryptType);

		} catch (Exception e) {

			e.printStackTrace();

			return decryptBody;

		}

		return decryptBody;

	}

	public static String decryptAESCBCEncode(String content, String key, String iv, int encryptType)

			throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException,

			InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {

		if (Util.isNull(content) || Util.isNull(key) || Util.isNull(iv)) {

			return null;

		}

		return new String(decryptAESCBC(org.apache.commons.codec.binary.Base64.decodeBase64(content.getBytes()),

				key.getBytes(), iv.getBytes(), encryptType));

	}

	public static byte[] decryptAESCBC(byte[] content, byte[] keyBytes, byte[] iv, int encryptType)

			throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException,

			InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {

		KeyGenerator keyGenerator = KeyGenerator.getInstance("AES");

		SecureRandom secureRandom = SecureRandom.getInstance("SHA1PRNG");

		secureRandom.setSeed(keyBytes);

		keyGenerator.init(encryptType, secureRandom);

		SecretKey key = keyGenerator.generateKey();

		Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");

		cipher.init(Cipher.DECRYPT_MODE, key, new IvParameterSpec(iv));

		byte[] result = cipher.doFinal(content);

		return result;

	}

	/**
	 * 
	 * ��ȡ����ַ���
	 *
	 * 
	 * 
	 * @param length �ַ�������
	 * 
	 * @return
	 * 
	 * @author d00420944
	 * 
	 */

	public static String getRandomChars(int length) {

		StringBuffer randomCharsBuf = new StringBuffer(1024);

		SecureRandom random = new SecureRandom();

		for (int i = 0; i < length; i++) {
// ��ĸ�����������
			if (random.nextInt(2) % 2 == 0) {
// ����Ǵ�д��ĸ����Сд��ĸ
				int letterIndex = random.nextInt(2) % 2 == 0 ? 65 : 97;
				randomCharsBuf.append((char) (random.nextInt(26) + letterIndex));
			} else {
				randomCharsBuf.append(String.valueOf(random.nextInt(10)));
			}
		}
		String randomChars = randomCharsBuf.toString();
		return randomChars;
	}

}