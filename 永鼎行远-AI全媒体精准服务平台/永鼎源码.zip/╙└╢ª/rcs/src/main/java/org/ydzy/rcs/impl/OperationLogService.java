package org.ydzy.rcs.impl;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.inject.Inject;
import com.google.inject.name.Named;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.ydzy.rcs.db.XmlSqlGenerator;
import org.ydzy.util.SqlUtil;

import javax.sql.DataSource;

import java.util.List;
import java.util.Map;

/**
 * @author fsq
 * @create 2022/2/9
 */
public class OperationLogService {
    private static final Logger log = LoggerFactory.getLogger(OperationLogService.class);

    @Inject
    @Named("rcsDb")
    private DataSource ds;

    /**
     * ���Ӳ�����־
     */
    public void addOperationLog(Map map) {
        if (map.isEmpty()) return;
        try {
            log.info("������־��{}", map);
            String sqlId = "addOperationLog";
            XmlSqlGenerator.innerSql sql = XmlSqlGenerator.getSqlByMap(sqlId, map);
            SqlUtil.updateRecords(ds, sql.exeSql,sql.sqlParams.toArray());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * ��ѯ������־
     */
    public JsonArray selOperationLog(String operationUse, String cspEcNo) {
        try {
            log.info("��ѯ��־��{}", operationUse, cspEcNo);
            String sqlID = "selOperationLog";
            JsonObject json = new JsonObject();
            json.addProperty("operationUse", operationUse);
            json.addProperty("cspEcNo", cspEcNo);
            String sql = XmlSqlGenerator.getSqlByJson(sqlID, null, json);
            JsonArray array = SqlUtil.queryForJson(ds, sql);
            return array;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}
