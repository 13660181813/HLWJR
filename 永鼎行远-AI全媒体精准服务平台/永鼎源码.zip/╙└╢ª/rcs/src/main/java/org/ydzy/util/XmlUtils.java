package org.ydzy.util;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Reader;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.Writer;
import java.lang.ref.WeakReference;
import java.lang.reflect.Proxy;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.net.URLConnection;

import javax.xml.bind.DataBindingException;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.stream.FactoryConfigurationError;
import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import org.dom4j.dom.DOMDocument;
import org.ydzy.util.xml.CDataHandler;

import com.sun.xml.bind.marshaller.CharacterEscapeHandler;

public class XmlUtils {
	private static final class Cache {
        final Class type;
        final JAXBContext context;

        public Cache(Class type) throws JAXBException {
            this.type = type;
            this.context = JAXBContext.newInstance(type);
        }
    }
    /**
     * Cache. We don't want to prevent the {@link Cache#type} from GC-ed,
     * hence {@link WeakReference}.
     */
    private static volatile WeakReference<Cache> cache;

    /**
     * Obtains the {@link JAXBContext} from the given type,
     * by using the cache if possible.
     *
     * <p>
     * We don't use locks to control access to {@link #cache}, but this code
     * should be thread-safe thanks to the immutable {@link Cache} and {@code volatile}.
     */
    private static <T> JAXBContext getContext(Class<T> type) throws JAXBException {
        WeakReference<Cache> c = cache;
        if(c!=null) {
            Cache d = c.get();
            if(d!=null && d.type==type)
                return d.context;
        }

        // overwrite the cache
        Cache d = new Cache(type);
        cache = new WeakReference<Cache>(d);

        return d.context;
    }
    public static String indentFormat(String xml) {
        try {
            TransformerFactory factory = TransformerFactory.newInstance();
            Transformer transformer = factory.newTransformer();
            // *) �򿪶��뿪��
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            // *) ���Ե�xml����ͷ��Ϣ
            transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
            transformer.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
            transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "4");
     
            StringWriter formattedStringWriter = new StringWriter();
            transformer.transform(new StreamSource(new StringReader(xml)),
                    new StreamResult(formattedStringWriter));
     
            return "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
                    + formattedStringWriter.toString();
        } catch (TransformerException e) {
        }
        return null;
    }
    public static  String	toXml(Class<?> classBean,Object bean,boolean formated)
    {
    	try {
    		
    		StringWriter writer = new StringWriter();  
    		XMLStreamWriter streamWriter = XMLOutputFactory.newInstance()
                    .createXMLStreamWriter(writer);
            // *) ʹ�ö�̬����ģʽ, ��streamWriter���ܽ��и������
            XMLStreamWriter cdataStreamWriter = (XMLStreamWriter) Proxy.newProxyInstance(
                    streamWriter.getClass().getClassLoader(),
                    streamWriter.getClass().getInterfaces(),
                    new CDataHandler(streamWriter)
            );
			JAXBContext context=JAXBContext.newInstance(classBean);
			Marshaller marshaller=context.createMarshaller();
//			DOMDocument doc = new DOMDocument();
			 marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT,true);
//			 marshaller.marshal(bean, toResult(xml));
			 marshaller.marshal(bean, cdataStreamWriter);
			 if ( formated ) {
		            return indentFormat(writer.toString());
		        } else {
		        	
		        	return writer.toString();
		        }
//			Result result;
//			marshaller.marshal(bean, result);
		} catch (JAXBException | XMLStreamException | FactoryConfigurationError e) {
			e.printStackTrace();
		}
    	return null;
    }
//    /**
//     * Creates {@link Result} from various XML representation.
//     * See {@link #_marshal(Object,Object)} for the conversion rules.
//     */
//    private static javax.xml.transform.Result toResult(Object xml) throws IOException {
//        if(xml==null)
//            throw new IllegalArgumentException("no XML is given");
//
//        if (xml instanceof String) {
//            try {
//                xml=new URI((String)xml);
//            } catch (URISyntaxException e) {
//                xml=new File((String)xml);
//            }
//        }        
//        if (xml instanceof  Result) {
//            return   (Result)xml;
//        }
//        throw new IllegalArgumentException("I don't understand how to handle "+xml.getClass());
//    }
    /**
     * Reads in a Java object tree from the given XML input.
     *
     * @param xml
     *      The string is first interpreted as an absolute {@code URI}.
     *      If it's not {@link URI#isAbsolute() a valid absolute URI},
     *      then it's interpreted as a {@code File}
     */
    public static <T> T unmarshal( String xml, Class<T> type ) {
        try {
        	StringReader sr = new StringReader(xml);
            JAXBElement<T> item = getContext(type).createUnmarshaller().unmarshal(toSource(sr), type);
            return item.getValue();
        } catch (JAXBException e) {
            throw new DataBindingException(e);
        } catch (IOException e) {
            throw new DataBindingException(e);
        }
    }
    private static Source toSource(Object xml) throws IOException {
        if(xml==null)
            throw new IllegalArgumentException("no XML is given");

        if (xml instanceof String) {
            try {
                xml=new URI((String)xml);
            } catch (URISyntaxException e) {
                xml=new File((String)xml);
            }
        }
        if (xml instanceof File) {
            File file = (File) xml;
            return new StreamSource(file);
        }
        if (xml instanceof URI) {
            URI uri = (URI) xml;
            xml=uri.toURL();
        }
        if (xml instanceof URL) {
            URL url = (URL) xml;
            return new StreamSource(url.toExternalForm());
        }
        if (xml instanceof InputStream) {
            InputStream in = (InputStream) xml;
            return new StreamSource(in);
        }
        if (xml instanceof Reader) {
            Reader r = (Reader) xml;
            return new StreamSource(r);
        }
        if (xml instanceof Source) {
            return (Source) xml;
        }
        throw new IllegalArgumentException("I don't understand how to handle "+xml.getClass());
    }
}
