package org.ydzy.rcs.entity;

import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.ydzy.util.Util;

import com.google.gson.JsonObject;

public class ReceiveEntity extends CommonMsg{
	public static final String PREFIX_TEXT = "prefixText";
		private String keywords;
		private String remoteAddr;
		private String encode;
		private String messageId;
		public String conversationID;
		public String contributionID;
		public String contentType;
		public String contentEncoding;
		public transient String msgId;
		public String requestMSGID;
		public String getMsgId() {
			if(Util.isNull(msgId)) {
				Instant time =Instant.now() ;
				msgId=this.hashCode()+""+time.getNano();
			}
			return msgId;
		}
		public void setMsgId(String msgId) {
			this.msgId = msgId;
		}
		public String getMediaOrContent()
		{
			String value = this.getContent();
				List<Map<String, Object>> dinofs=new ArrayList<Map<String,Object>>();
				if(this.getAnswersObject().containsKey("download")) {
					dinofs=(List<Map<String, Object>>) this.getAnswersObject().get("download");
				}
				if(dinofs!=null &&dinofs.size()>0) {
					  value = Util.toString(dinofs.get(0).get("url"));
				}
				return value;
				
		}
		public String serviceCapability;
		public String trafficType;
		public String smssupported;
		public String imFormat;
		
		public String reportRequest;
		public String storeSupported;
		
		public String smsContent;
		public String deliveryStatus;
		public String description;
		public String errorCode;
		
		public String download;
		public String inReplyToContributionID;
		public String fallbackSupported;
		public String rcsBodyText;
		public String sendTo;

		//�յ���Ϣʱ��
		public String receiveMsgTime;
		//��Ϣ��Ӧʱ��
		public String responseMsgTime;
		
         public String getMessageId() {
			return messageId;
		}
		public void setMessageId(String messageId) {
			this.messageId = messageId;
		}

		//		private String spName;
		private String chatBotId;
		public String getChatBotId() {
			return chatBotId;
		}
		public void setChatBotId(String chatBotId) {
			this.chatBotId = chatBotId;
		}
		private String mdn;
		private String content;
		private String contentresponse;
		private String subject;
		public String getSubject() {
			return subject;
		}
		public void setSubject(String subject) {
			this.subject = subject;
		}
		private transient Map<String,Object> answersObject =new HashMap<String,Object>();
		public Map<String,Object> getAnswersObject() {
			return answersObject;
		}
		public void setAnswersObject(Map<String,Object> answersObject) {
			this.answersObject = answersObject;
		}
		private String contentresponserecord;
		public String getContentresponserecord() {
			return contentresponserecord;
		}
		public void setContentresponserecord(String contentresponserecord) {
			this.contentresponserecord = contentresponserecord;
		}
		private String rawcontent;
		private String queryMsg;
		public String getQueryMsg() {
			return queryMsg;
		}
		public void setQueryMsg(String queryMsg) {
			this.queryMsg = queryMsg;
		}
		public String getContentresponse() {
			return contentresponse;
		}
		public void setContentresponse(String contentresponse) {
			if(this.getAnswersObject()!=null&&this.getAnswersObject().containsKey(PREFIX_TEXT)) {
				String text = Util.toString(this.getAnswersObject().get(PREFIX_TEXT));
				this.contentresponse = text + "\r\n------------------\r\n" + contentresponse;
			}else {
				this.contentresponse = contentresponse;
			}
		}
		public String getRawcontent() {
			return rawcontent;
		}
		public void setRawcontent(String rawcontent) {
			this.rawcontent = rawcontent;
		}
		private JsonObject receive5GMsg;
		public String getSenderAddress() {
			return senderAddress;
		}
		public void setSenderAddress(String senderAddress) {
			this.senderAddress = senderAddress;
		}
		public String getKeywords() {
			return keywords;
		}
		public void setKeywords(String keywords) {
			this.keywords = keywords;
		}
		public String getRemoteAddr() {
			return remoteAddr;
		}
		public void setRemoteAddr(String remoteAddr) {
			this.remoteAddr = remoteAddr;
		}
		public String getEncode() {
			return encode;
		}
		public void setEncode(String encode) {
			this.encode = encode;
		}
//		public String getSpName() {
//			return spName;
//		}
//		public void setSpName(String spName) {
//			this.spName = spName;
//		}
		public String getMdn() {
			return mdn;
		}
		public void setMdn(String mdn) {
			this.mdn = mdn;
		}
		public String getContent() {
			return content;
		}
		public void setContent(String content) {
			this.content = content;
		}
		public JsonObject getReceive5GMsg() {
			return receive5GMsg;
		}
		public void setReceive5GMsg(JsonObject receive5gMsg) {
			receive5GMsg = receive5gMsg;
		}
		
}