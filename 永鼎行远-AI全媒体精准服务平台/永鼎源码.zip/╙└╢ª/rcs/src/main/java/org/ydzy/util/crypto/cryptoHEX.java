/*
 * @(#)HEX.java
 */
package org.ydzy.util.crypto;


/**
 * ʮ�����Ʊ���
 */
public class cryptoHEX {
    /**
     * ����
     * @param src
     * @return
     */
    public static String encode(byte[] src) {
        if (src == null) {
            return null;
        }
        if (src.length == 0) {
            return "";
        }
        StringBuffer ret = new StringBuffer();
        for (int i = 0; i < src.length; i++) {
            String t = Integer.toHexString(src[i]);
            if (t != null & t.length() > 2) {
                t = t.substring(t.length() - 2);
            } else if ((t != null & t.length() < 2)) {
                t = padString(t, 2, '0', true);
            }
            ret.append(t);
        }
        return ret.toString();
    }

    /**
     * ����
     * @param src
     * @return
     */
    public static byte[] decode(String src) {
        if (src == null) {
            return null;
        }
        if (src.length() == 0) {
            return new byte[0];
        }
        byte[] ret = new byte[src.length() / 2];
        for (int i = 0; i < ret.length; i++) {
            ret[i] = (byte) (Short.parseShort(src.substring(i * 2, i * 2 + 2), 16));
        }
        return ret;
    }
    
    /**
     * ��ָ���ַ�����ַ�����ָ������
     * 
     * @param string
     *            ԭ�ַ���
     * @param length
     *            ����ĳ���
     * @param paddingChar
     *            ����ַ�
     * @param head
     *            true:��ǰ����� false:�ں������
     * @return
     */
    private static final String padString(String string, int length, char paddingChar, boolean head) {
        // ����ַ���ΪNULL,����0�����ַ���������
        if (string == null) {
            string = "";
        }
        if (string.length() >= length) {
            return string;
        }
        StringBuffer buf = new StringBuffer();
        for (int i = 0; i < length - string.length(); i++) {
            buf.append(paddingChar);
        }
        if (head) {
            return buf.append(string).toString();
        } else {
            return string + buf.toString();
        }
    }

}
