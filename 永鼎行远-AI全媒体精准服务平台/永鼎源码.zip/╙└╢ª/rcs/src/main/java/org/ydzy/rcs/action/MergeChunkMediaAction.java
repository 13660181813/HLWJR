package org.ydzy.rcs.action;

import com.google.gson.JsonObject;
import org.ydzy.rcs.module.LoadProperties;
import org.ydzy.util.FileUtils;
import org.ydzy.util.Util;

import java.io.*;
import java.nio.file.Files;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * @author lirui
 * @Date 2021/12/10 6:28 ����
 */

public class MergeChunkMediaAction {

    static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(MergeChunkMediaAction.class);
    // �ļ���Ϣ
    public Map<String, JsonObject> fileinfoMap = new ConcurrentHashMap<>();
    // ��Ƭ�ļ�
    public Map<String, ArrayList<String>> fragmentFileMap = new ConcurrentHashMap<>();

    public static Map<String, String> thumbnailMaps = new ConcurrentHashMap<>();

    public void putFileinfo(JsonObject jsonObject) {
        String chunkName = Util.getElementAsString(jsonObject, "chunkName");
        fileinfoMap.put(chunkName, jsonObject);
    }

    public Map<String, String> putChunkFile(String chunkName, String chunkPath) {
        if (Util.isNull(chunkName) || Util.isNull(chunkPath) || !fileinfoMap.containsKey(chunkName))
            return null;
        ArrayList<String> paths = fragmentFileMap.computeIfAbsent(chunkName, k -> new ArrayList<>());
        paths.add(chunkPath);

        JsonObject jsonObject = fileinfoMap.get(chunkName);
        int chunkTotal = Util.toInt(Util.getElementAsString(jsonObject, "chunkTotal"), 0);
        if (chunkTotal == 0) {
            clearChunkFile(chunkName);
            return null;
        }
        if (paths.size() < chunkTotal)
            return null;
        String chunkBasePath = chunkPath.substring(0, chunkPath.lastIndexOf(File.separatorChar));
        Map<String, String> map = startMergeChunk(chunkName, chunkBasePath, jsonObject);

        if (map == null)
            return null;
        String mergefilePath = map.get("localPath");
        String localMediaPath = FileUtils.moveChunkMergeFile2Media(mergefilePath);
        map.put("localPath", localMediaPath);
        clearChunkFile(chunkBasePath);
        return map;
    }

    private Map<String, String> startMergeChunk(String chunkName, String chunkPath, JsonObject jsonObject) {
        String fileMd5 = Util.getElementAsString(jsonObject, "fileMd5");
        ArrayList<String> chunklist = fragmentFileMap.get(chunkName);
        String filename = Util.getElementAsString(jsonObject, "filename");
        String targetName = chunkName + filename.substring(filename.lastIndexOf("."));
        String targetPathName = chunkPath + File.separator + targetName;
        boolean flag = true;
        if (chunklist.size() == 1) {
            String chunkpath = chunklist.get(0);
            File chunkFile = new File(chunkpath);
            chunkFile.renameTo(new File(targetPathName));
        } else
            flag = mergeChunk(chunklist, targetPathName);
        if (flag) {
            Map<String, String> map = new HashMap<>();
            map.put("filename", targetName);
            map.put("localPath", targetPathName);
            String baseUrl = LoadProperties.systemProperties.getProperty("webUrl");
            baseUrl += (baseUrl.endsWith("/") ? "" : "/") + "media";
            String mediaUrl = baseUrl + "/" + targetName;
            map.put("mediaUrl", mediaUrl);
            return map;
        }
        return null;
    }

    private void clearChunkFile(String chunkBasePath) {
        try {
            File basepath = new File(chunkBasePath);
            if (basepath.exists()) {
                if (basepath.isDirectory()) {
                    File[] files = basepath.listFiles();
                    if (files.length > 0) {
                        for (File f : files) {
                            Files.deleteIfExists(f.toPath());
                        }
                    }
                }
                Files.delete(basepath.toPath());
            }
        } catch (Exception e) {
            log.error("delete file error.", e);
        }
    }

    private boolean mergeChunk(ArrayList<String> chunks, String targetFile) {
        try (OutputStream out = new FileOutputStream(targetFile);
        ) {
            Collections.sort(chunks);
            for (String path : chunks) {
                File file = new File(path);
                InputStream in = new FileInputStream(file);

                byte[] b = new byte[1024 * 1024];
                while (in.read(b) != -1) {
                    out.write(b);
                }
                in.close();
            }
            return true;
        } catch (Exception e) {
            log.error("merge chunk file error.", e);
            return false;
        }
    }

    static Set<String> imageTypes = new HashSet<>();

    static {
        imageTypes.add("webp");
        imageTypes.add("bmp");
        imageTypes.add("pcx");
        imageTypes.add("tif");
        imageTypes.add("gif");
        imageTypes.add("jpeg");
        imageTypes.add("tga");
        imageTypes.add("fpx");
        imageTypes.add("exif");
        imageTypes.add("svg");
        imageTypes.add("psd");
        imageTypes.add("cdr");
        imageTypes.add("pcd");
        imageTypes.add("dxf");
        imageTypes.add("ufo");
        imageTypes.add("eps");
        imageTypes.add("ai");
        imageTypes.add("png");
        imageTypes.add("hdri");
        imageTypes.add("raw");
        imageTypes.add("wmf");
        imageTypes.add("flic");
        imageTypes.add("emf");
        imageTypes.add("ico");
    }

    public boolean isImage(String extName) {
        if (Util.isNull(extName))
            return false;
        return imageTypes.contains(extName.replace(".", "").toLowerCase());
    }

    public static void main(String[] args) throws IOException {
        File dir = new File("/Users/lirui/java/workspace/simpleQuery/hw/media/mediaChunkDir/eWRRMi1639144491974");
        File[] chunks = dir.listFiles();

        if (chunks.length == 0)
            return;

        List<File> files = Arrays.asList(dir.listFiles());
        files.sort((o1, o2) -> {
            if (o1.isDirectory() && o2.isFile())
                return -1;
            if (o1.isFile() && o2.isDirectory())
                return 1;
            return o1.getName().compareTo(o2.getName());
        });


        OutputStream out = new FileOutputStream("/Users/lirui/java/workspace/simpleQuery/hw/media/mediaChunkDir/merge.mp4");
        for (File file : files) {
            InputStream in = new FileInputStream(file);

            byte[] b = new byte[1024 * 1024];
            int len = 0;
            while ((len = in.read(b)) != -1) {
                out.write(b);
            }
            in.close();
        }
        out.close();

    }

}
