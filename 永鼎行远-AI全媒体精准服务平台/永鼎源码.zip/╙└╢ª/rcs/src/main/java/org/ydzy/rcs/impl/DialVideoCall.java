package org.ydzy.rcs.impl;

import com.google.inject.Singleton;

import org.ydzy.rcs.SuggestionDisplay;
import org.ydzy.rcs.annotation.Description;
import org.ydzy.util.StringUtils;

@Singleton
@Description(value="dialVideoCall")
public class DialVideoCall implements SuggestionDisplay {

	private  String dialVideoCall = "{\r\n" 
	        + "\"action\":\r\n" 
			+ "	{\r\n" 
	        + "		\"displayText\":\"%s\",\r\n"
			+ "		\"dialerAction\":\r\n" 
	        + "		{\r\n" 
			+ "			\"dialVideoCall\":{\r\n" 
			+ "			\"phoneNumber\":\"%s\",\r\n"
			+ "			\"fallbackUrl\":\"%s\"\r\n"
			+ "			}\r\n" 
			+ "		}\r\n" 
			+ "	}\r\n" 
			+ "}\r\n";
	@Override
	public String suggestionHtml(String[] args) {
		int length=args.length;
		//TODO ARGS[0] DISPLAY TEXT
		return StringUtils.format(dialVideoCall, length<=0?"":args[0], length<=1?"":args[1].replace("��", ","), length<=2?"":args[2]);
	}

}
