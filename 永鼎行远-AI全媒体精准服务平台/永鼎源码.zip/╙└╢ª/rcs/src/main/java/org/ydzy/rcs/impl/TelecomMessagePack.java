package org.ydzy.rcs.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

import org.ydzy.handler.BaseRcsContext;
import org.ydzy.rcs.MessagesInter;
import org.ydzy.rcs.annotation.Description;
import org.ydzy.rcs.entity.ReceiveEntity;
import org.ydzy.rcs.entity.TelcomMsg;
import org.ydzy.util.Util;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.inject.Singleton;

/**�й��������ݽṹ ��Ϣ����
 * @author XFDEP
 *
 */
@Singleton
@Description(value="telecomMessageImp")
public class TelecomMessagePack implements MessagesInter {
	@Override
	public String body(ReceiveEntity requestObject, JsonObject eobject, BaseRcsContext context,List<MessageBody> body) {
		TelcomMsg msg=new TelcomMsg();
		msg.messageId=UUID.randomUUID().toString().replace("-", "").toLowerCase();
		msg.setDestinationAddress(new String[] {requestObject.getSenderAddress()});
		msg.senderAddress=context.getConfig().enterpriseProperty(requestObject.getChatBotId(), "sp");
		msg.senderName=context.getConfig().enterpriseProperty(requestObject.getChatBotId(), "defaultName");
		msg.contributionId=UUID.randomUUID().toString().replace("-", "").toLowerCase();
		msg.conversationId=UUID.randomUUID().toString().replace("-", "").toLowerCase();
		TelcomMsg.serviceCapability service=new TelcomMsg.serviceCapability();
		service.capabilityId=context.getConfig().enterpriseProperty(requestObject.getChatBotId(), "capabilityId");
		service.version=context.getConfig().enterpriseProperty(requestObject.getChatBotId(), "version");
		msg.serviceCapability= new TelcomMsg.serviceCapability[]{service};
		msg.trafficType=Util.getElementAsString(eobject, "trafficType", null);
		msg.storeSupported=true;
		msg.smsSupported=false;
		msg.imFormat="IM";
		Object orignMsg= context.getAttributes().get("origMsg");
		if(orignMsg!=null&&orignMsg instanceof JsonObject)
			msg.inReplyTo=requestObject.contributionID;
		msg.smsContent=Util.getElementAsString(eobject, "smsContent");
		msg.reportRequest = new ArrayList<>();
		String[] gg = {"sent","failed","delivered","displayed","deliveredToNetwork"};
		msg.reportRequest.addAll(Arrays.asList(gg));

		msg.messageList = new ArrayList<>();
		for(MessageBody e:body) {
			if(e.contentText==null)continue;
			TelcomMsg.message outmsg=new TelcomMsg.message();
			outmsg.contentType = e.contentType;
			if(e.contentEncoding==null) {
				outmsg.contentEncoding="utf8";
			}else {
				outmsg.contentEncoding=e.contentEncoding;
			}
			if("text/plain".equalsIgnoreCase(e.contentType)) {
				if(e.contentText instanceof String) {
					outmsg.contentText=e.contentText;
				}else {
					outmsg.contentText=e.contentText.toString();
				}
			}else {
				if(e.contentText instanceof String) {
					outmsg.contentText=JsonParser.parseString((String)e.contentText);
				}else if(e.contentText instanceof JsonElement){
					outmsg.contentText=e.contentText;
				}else {
					//error
				}
			}
			msg.messageList.add(outmsg);
			
		}
//		msg.reportRequest=new ArrayList<String>(){{ add("Delivered");add("Failed");}};
		requestObject.getAnswersObject().put("messagePack", msg);
		String rst;
		rst = new Gson().toJson(msg);
		return rst;
	}

	
}
