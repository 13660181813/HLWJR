package org.ydzy.rcs.action;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.inject.Inject;
import com.google.inject.name.Named;
import org.ydzy.rcs.db.XmlSqlGenerator;
import org.ydzy.rcs.impl.MoveTaskService;
import org.ydzy.util.SqlUtil;
import org.ydzy.util.Util;

import javax.sql.DataSource;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.*;

/**
 * @author lirui
 * @Date 2021/7/27 6:36 ����
 */
public class MoveConfigAction {

    static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(MoveConfigAction.class);
    @Inject
    @Named("rcsDb")
    DataSource ds;

    @Inject
    @Named("taskService")
    MoveTaskService taskService;

    // taskName
    private static final Map<String, String> taskName = new HashMap<>() {{
        put("tempParams", "ģ��Ǩ������");
        put("dialog", "���ֶԻ�Ǩ������");
        put("bottomMenu", "�ײ��˵�Ǩ������");
        put("material", "�ز�Ǩ������");
        put("channel", "����Ǩ������");
        put("clear_copymsgid", "��ʱ�������");
        put("configinfo", "���á���Ϣ���������ݼ���ϵǨ������");
    }};


    public boolean doAction(JsonObject object) {
        String save = Util.getElementAsString(object, "save");
        try {
            JsonArray configs = object.getAsJsonArray("configs");
            if (configs != null && configs.size() > 0)
                object.add("configid", configs);
            String sql = "";
            if (save.equals("y")) {
                sql = mergeCopySql(object);
            }
            return SqlUtil.updateRecords(ds, sql);
//            return true;
        } catch (Exception e) {
            log.error("move config error.", e);
            return false;
        }
    }

    private String mergeCopySql(JsonObject object) {
        StringBuilder sqls = new StringBuilder();
        sqls.append(XmlSqlGenerator.getSqlByJson("oneKeyCopy_configinfo", null, object));
        JsonArray partdatas = object.getAsJsonArray("partdata");
        for (JsonElement ele : partdatas) {
            JsonObject part = ele.getAsJsonObject();
            String value = Util.getElementAsString(part, "value");
            String params = Util.getElementAsString(part, "params");
            if (value.equals("1")) {
                String sqlid = "oneKeyCopy_" + params;
                String sql = XmlSqlGenerator.getSqlByJson(sqlid, null, object);
                sqls.append(sql).append(";");
            }
        }
        String clearCopyId = XmlSqlGenerator.getSqlByJson("clear_copymsgid", null, object);
        sqls.append(clearCopyId);
        return sqls.toString();
    }


    /**
     * Ǩ���������
     *
     * @param object
     * @return �������id
     */
    public JsonObject doMoveAction(JsonObject object) {
        return taskService.doMoveConfigAction(object);
    }

    /**
     * �жϵ�ǰ�Ƿ�����chatbot origin �� target ֮���Ǩ������
     *
     * @param object
     * @return
     */
    public synchronized boolean isDuplicateTask(JsonObject object) {
        String origin = Util.getElementAsString(object, "fromChatbotid");
        if (MoveTaskService.taskMap.containsKey(origin)) {
            return false;
        } else {
            return true;
        }
    }

}
