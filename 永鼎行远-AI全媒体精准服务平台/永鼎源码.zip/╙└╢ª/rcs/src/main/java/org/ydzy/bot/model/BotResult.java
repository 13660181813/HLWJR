package org.ydzy.bot.model;

import com.google.gson.annotations.SerializedName;

public class BotResult {
	@SerializedName(value = "errorCode", alternate = {"code"})
	private int errorCode;
	
	@SerializedName(value = "errorMessage", alternate = {"msg"})
	private String errorMessage;
	
	public int getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	
	@Override
	public String toString() {
		return "BotResult [errorCode=" + errorCode + ", errorMessage=" + errorMessage + "]";
	}
	
}
