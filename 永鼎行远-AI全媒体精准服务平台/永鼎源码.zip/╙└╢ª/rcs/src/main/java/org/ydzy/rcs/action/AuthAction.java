package org.ydzy.rcs.action;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.inject.Inject;
import com.google.inject.Singleton;
import com.google.inject.name.Named;
import io.jsonwebtoken.Claims;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.ydzy.config.ApplicationConfig;
import org.ydzy.handler.BaseHandler;
import org.ydzy.rcs.Provider;
import org.ydzy.rcs.db.XmlSqlGenerator;
import org.ydzy.rcs.db.XmlSqlGenerator.innerSql;
import org.ydzy.util.*;
import org.ydzy.util.crypto.CryptoAES;
import org.ydzy.util.crypto.cryptoDES;

import javax.sql.DataSource;
import java.io.IOException;
import java.sql.SQLException;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.ConcurrentLinkedQueue;

import static org.ydzy.util.SqlUtil.queryForJson;

/**
 * @author lirui
 * @Date 2021/5/11 12:07 ����
 */
@Singleton
public class AuthAction {
    static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(AuthAction.class);

//    public static final long refreshTokenExpirationTimeInSecond = 3600 * 24 * 30; // refresh_token ��Ч��
//    public static final long expirationTimeInSecond = 3600L;

    private DataSource ds = null;
    private DataSource ydzyds = null;
    @Inject
    private ApplicationConfig applicationconfig = null;
    private static final Map<String, String> userGroupMap = new HashMap<>();
    @Inject
    protected MenuAction menuAction;
    public static Queue<String> logoutTokenQueue = new ConcurrentLinkedQueue<>();

    @Inject
    public AuthAction(@Named("rcsDb") DataSource ds, @Named("ydzyDb") DataSource ydzyds) {
        super();
        this.ds = ds;
        this.ydzyds = ydzyds;
        applicationconfig = Provider.injector.getProvider(ApplicationConfig.class).get();
        startCheckLogoutTokenThread();
    }

    @Inject
    JwtOperatorUtil jwtOperatorUtil;

    /**
     * ͨ���û�����ѯ�����û���Ϣ
     *
     * @param username
     * @return
     */
    public JsonObject getPasswdByUsername(String username, String accessTagNo) {
        if (Util.isNull(username))
            username = "";
        String sqlId = "queryPasswdByNameAndAccessTagNo";
        String password = "";
        String sql="";
        if(Util.isNull(accessTagNo)) {
        	sqlId="queryPasswdByName";
        	 sql =XmlSqlGenerator.getSqlstr(sqlId, username);
        }else
        {
        	JsonObject params = new JsonObject();
            params.addProperty("username", username);
            params.addProperty("accessTagNo", accessTagNo);
        	 sql = XmlSqlGenerator.getSqlByJson(sqlId, null, params);
        }
        try {

            JsonArray array = SqlUtil.queryForJson(ds, sql);
            if (!array.isJsonNull() && array.size() > 0) {
                return array.get(0).getAsJsonObject();
            }
        } catch (Exception e) {
            log.error("query password by username error. username={}", username, e);
        }
        return new JsonObject();
    }

    public String generateSign(String username, String accessTagNo, String nonce, String timestamp) {
        JsonObject userObj = getPasswdByUsername(username, accessTagNo);
        String password = Util.getElementAsString(userObj, "password");
        byte[] sha256 = Util.digest(password, nonce, timestamp);
        return Base64.getEncoder().encodeToString(sha256);
    }

    /**
     * ����accessToken
     *
     * @param username
     * @param password
     * @param loginMode
     * @param accessTokenUrl
     * @return
     * @throws IOException
     */
    public String getAccessToekn(String username, String password, String loginMode, String accessTokenUrl, Map<String, Object> payload) throws IOException {
        if (Util.isNull(username)) {
            return "";
        }
        if (loginMode.equals("signature")) {
            return jwtOperatorUtil.generateToken(payload, applicationconfig.LOGIN_SIGNATURE_EXPIREIN_SECOND);
        }
        JsonObject jobj = getRcsUserPermission(username);
        if (jobj == null)
            return "";
        String customerId = Util.getElementAsString(jobj, "customerId");
        String enable = Util.getElementAsString(jobj, "enable");
        payload.put("enable", enable);
        if (!enable.equals("1"))
            return "";
        if (loginMode.equals("server")) {
            JsonObject jsonObject = new JsonObject();
            jsonObject.addProperty("username", username);
            jsonObject.addProperty("password", password);
            String rst = NetUtils.doHttps(accessTokenUrl, jsonObject.toString(), null, "application/json");
            if (Util.isNull(rst)) {
                return rst;
            }
            try {
                JsonElement tokenElement = JsonParser.parseString(rst);
                String code = Util.getElementAsString(tokenElement.getAsJsonObject(), "code");
                String desc = Util.getElementAsString(tokenElement.getAsJsonObject(), "desc");
                String accessToken = Util.getElementAsString(tokenElement.getAsJsonObject(), "data");
                Claims claims = jwtOperatorUtil.getClaimsFromToken(accessToken);
                claims.put("customerId", customerId);
                accessToken = jwtOperatorUtil.generateToken(claims);
                if (!code.equals("200")) {
                    log.error("get accessToken from server error. {}", desc);
                    return "";
                }
                return accessToken;
            } catch (Exception e) {
                log.error("get access token error.", e);
            }
        } else {
            try {
                JsonObject obj = getUserByUnamePass(username, password);
                if (obj == null)
                    return "";
                String userid = Util.getElementAsString(obj, "USERID");
                String groupid = Util.getElementAsString(obj, "GROUPID");
                String levels = Util.getElementAsString(obj, "LEVELS");
                String isadmin = Util.getElementAsString(obj, "ISADMIN");
                String status = Util.getElementAsString(obj, "STATUS");
//                String truename = Util.getElementAsString(obj, "TRUENAME");
//                String userdesc = Util.getElementAsString(obj, "USERDESC");
//                String email = Util.getElementAsString(obj, "EMAIL");
//                String phone = Util.getElementAsString(obj, "PHONE");
//                String mobile = Util.getElementAsString(obj, "MOBILE");
                payload.put("loginname", username);
                payload.put("userid", userid);
                payload.put("groupid", groupid);
                payload.put("levels", levels);
                payload.put("isAdmin", isadmin);
                payload.put("customerId", customerId);
                payload.put("status", status); //����״̬
                return jwtOperatorUtil.generateToken(payload);

            } catch (Exception e) {
                log.error("get access token error.", e);
            }
        }
        return "";
    }

    /**
     * ͨ����token���ɶ�token
     *
     * @return
     */
    public String generateAccessToken(String refreshToken) {
        Claims claims = jwtOperatorUtil.getClaimsFromToken(refreshToken);
        return jwtOperatorUtil.generateToken(claims, null);
    }

    public String grantPermission(String accessToken, String grantPermissionUrl) {
        try {
            String data = "{\"accessToken\":\"" + accessToken + "\"}";
            return NetUtils.doHttps(grantPermissionUrl, data, null, "application/json");
        } catch (Exception e) {
            log.error("grantPermission error. requestUrl:{}", grantPermissionUrl);
        }
        return "";
    }

    public JsonArray getApps(String groupId) {
        String sqlId = "getAppsByGroup";
        try {
        	String sql = XmlSqlGenerator.getSql(sqlId, groupId).exeSql;
            JsonArray array = queryForJson(ydzyds, sql);
            log.info("load apps success. apps size: {}", array.size());
            JsonArray appsArray = new JsonArray();
            for (JsonElement e : array) {
                appsArray.add(Util.getElementAsString(e.getAsJsonObject(), "APP_SERVER_NAME"));
            }
            return appsArray;
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return new JsonArray();
    }

    public JsonArray getChatBotArrayByUser(String userPhone) {
        String sqlId = "queryChatbotByUser";
        if (Util.isNull(userPhone))
            sqlId = "queryAllChatbot";
        try {
        	String sql = XmlSqlGenerator.getSql(sqlId, userPhone).exeSql;
            return queryForJson(ds, sql);

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return null;
    }


    public JsonObject getRcsUser(String userPhone) {
        String sqlId = "queryRcsUser";
        JsonObject object = null;
        try {
        	String sql = XmlSqlGenerator.getSql(sqlId, userPhone).exeSql;
            JsonArray array = queryForJson(ds, sql);
            if (array.size() == 0)
                return object;
            object = array.get(0).getAsJsonObject();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return object;
    }

    //���� phone ��ѯ rcs_user ������Ϣ
    public JsonObject getRcsUserByPhone(String userPhone){
        String sqlId = "queryRcsUserByPhone";
        JsonObject object = null;
        try {
            String sql = XmlSqlGenerator.getSql(sqlId,userPhone).exeSql;
            JsonArray array = queryForJson(ds,sql);
            if(array.size() == 0){
                return object;
            }
            object = array.get(0).getAsJsonObject();
        } catch (Exception e) {
            log.error("get access token error.", e);
        }
        return object;
    }

    public JsonObject getRcsUserPermission(String userPhone) {
        log.info("start load rcs_user permission info");
        String sqlId = "queryRcsUserAndChatBot";
        JsonObject object = null;
        JsonArray chatBotArray = new JsonArray();
        try {
        	String sql = XmlSqlGenerator.getSql(sqlId, userPhone).exeSql;
            JsonArray array = queryForJson(ds, sql);
            if (array.size() == 0)
                return object;
            object = new JsonObject();
            int i = 0;
            for (JsonElement ele : array) {
                i++;
                JsonObject obj = ele.getAsJsonObject();
                if (i == array.size()) {
                    String userid = Util.getElementAsString(obj, "userid");
                    String username = Util.getElementAsString(obj, "username");
                    String picture = Util.getElementAsString(obj, "picture");
                    String phone = Util.getElementAsString(obj, "phone");
                    String area = Util.getElementAsString(obj, "area");
                    String sex = Util.getElementAsString(obj, "sex");
                    String ipfrom = Util.getElementAsString(obj, "ipfrom");
                    String operatorCard = Util.getElementAsString(obj, "operatorCard");
                    String emailAddress = Util.getElementAsString(obj, "emailAddress");
                    String operatorIdentityPic1 = Util.getElementAsString(obj, "operatorIdentityPic1");
                    String operatorIdentityPic2 = Util.getElementAsString(obj, "operatorIdentityPic2");
                    String customerId = Util.getElementAsString(obj, "customerId");
                    String enable = Util.getElementAsString(obj, "enable");
                    object.addProperty("userid", userid);
                    object.addProperty("username", username);
                    object.addProperty("picture", picture);
                    object.addProperty("phone", phone);
                    object.addProperty("area", area);
                    object.addProperty("sex", sex);
                    object.addProperty("ipfrom", ipfrom);
                    object.addProperty("operatorCard", operatorCard);
                    object.addProperty("emailAddress", emailAddress);
                    object.addProperty("operatorIdentityPic1", operatorIdentityPic1);
                    object.addProperty("operatorIdentityPic2", operatorIdentityPic2);
                    object.addProperty("customerId", customerId);
                    object.addProperty("enable", enable);
                }
                String chatbotid = Util.getElementAsString(obj, "chatbotid");
                String iseditable = Util.getElementAsString(obj, "iseditable");
                String isquery = Util.getElementAsString(obj, "isquery");
                String isdelete = Util.getElementAsString(obj, "isdelete");
                String isadmin = Util.getElementAsString(obj, "isadmin");
                String chatbotname = Util.getElementAsString(obj, "chatbotname");
                String chatbotIdenty = Util.getElementAsString(obj, "chatbotIdenty");
                String spName = Util.getElementAsString(obj, "spName");

                JsonObject o = new JsonObject();
                o.addProperty("chatbotid", chatbotid);
                o.addProperty("iseditable", iseditable);
                o.addProperty("isquery", isquery);
                o.addProperty("isdelete", isdelete);
                o.addProperty("isadmin", isadmin);
                o.addProperty("chatbotname", chatbotname);
                o.addProperty("chatbotIdenty", chatbotIdenty);
                o.addProperty("spName", spName);
                chatBotArray.add(o);
            }
            object.add("chatbotInfos", chatBotArray);
            log.info("load rcs_user permission info success. rcs_user size: {}", array.size());
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return object;
    }

    public boolean validateUri(List<String> whitelistUri, String uri) {
        if (whitelistUri == null || whitelistUri.size() == 0)
            return false;
        for (String regex : whitelistUri) {
            if (regex.contains("**")) {
                String prefix = regex.substring(0, regex.indexOf("**"));
                if (uri.startsWith(prefix)) {
                    return true;
                }
            } else {
                if (uri.equals(regex) || uri.matches(regex)) {
                    return true;
                }

            }
        }
        return false;
    }

    /**
     * ǩ����֤ʧ��
     *
     * @param sign
     * @param remoteAddr
     * @param request
     * @param response
     * @throws IOException
     */
    public static void signatureValidateFailed(String sign, String remoteAddr, HttpServletRequest request, HttpServletResponse response) throws IOException {
        log.error("get access token error. accessToken verification failed. {}", sign);
        JsonObject reason = new JsonObject();
        reason.addProperty("reason", "");
        BaseHandler.sendResponse(remoteAddr, BaseHandler.resBodyJson(AUTH_CODE_INVALID_TOKEN, "validate signature failed.", reason), HttpServletResponse.SC_FORBIDDEN, request, response);
    }

    /**
     * token��֤ʧ��
     *
     * @param token
     * @param remoteAddr
     * @param request
     * @param response
     * @throws IOException
     */
    public static void tokenValidateFailed(String token, String remoteAddr, HttpServletRequest request, HttpServletResponse response) throws IOException {
        log.error("get access token error. accessToken verification failed. {}", token);
        JsonObject reason = new JsonObject();
        reason.addProperty("reason", "accessToken verification failed.");
        BaseHandler.sendResponse(remoteAddr, BaseHandler.resBodyJson(AUTH_CODE_INVALID_TOKEN, "Get accessToken error.", reason), HttpServletResponse.SC_UNAUTHORIZED, request, response);
    }

    public void refreshTokenValidateFailed(String token, String remoteAddr, HttpServletRequest request, HttpServletResponse response) throws IOException {
        log.error("get access token error. accessToken verification failed. {}", token);
        JsonObject reason = new JsonObject();
        reason.addProperty("reason", "accessToken verification failed.");
        BaseHandler.sendResponse(remoteAddr, BaseHandler.resBodyJson(AUTH_CODE_INVALID_TOKEN, "Get accessToken error.", reason), HttpServletResponse.SC_FORBIDDEN, request, response);
    }

    public void denyloginByIp(String remoteAddr, HttpServletRequest request, HttpServletResponse response) throws IOException {
        log.error("Deny IP login. {}", remoteAddr);
        JsonObject reason = new JsonObject();
        reason.addProperty("reason", "Deny IP login");
        BaseHandler.sendResponse(remoteAddr, BaseHandler.resBodyJson(AUTH_CODE_DENY_IP, "Deny IP login.", reason), HttpServletResponse.SC_OK, request, response);
    }

    //�����û��� rcs_user
    public boolean insertRcsUser(String phone, String area, int sex, String ipfrom, String operatorCard, String emailAddress, String operatorIdentityPic1, String operatorIdentityPic2) {
        return insertRcsUser(phone, area, sex, ipfrom, operatorCard, emailAddress, operatorIdentityPic1, operatorIdentityPic2, phone, "");
    }

    public boolean insertRcsUser(String phone, String area, int sex, String ipfrom, String operatorCard, String emailAddress, String operatorIdentityPic1, String operatorIdentityPic2,
                                 String username, String picture) {
        try {
            String sqlId = "insertrcsuser";
            String sql = XmlSqlGenerator.getSql(sqlId).exeSql;
            Object[] params = new Object[10];
            params[0] = username;
            params[1] = phone;
            params[2] = area;
            params[3] = sex;
            params[4] = ipfrom;
            params[5] = operatorCard;
            params[6] = emailAddress;
            params[7] = operatorIdentityPic1;
            params[8] = operatorIdentityPic2;
            params[9] = picture;
            return SqlUtil.updateRecords(ds, sql, params);
        } catch (SQLException e) {
            log.error("insert rcs_user error.", e);
            return false;
        }
    }

    public boolean insertChannelUser(String username, String phone, String channelid, String openid) {
        try {
            String sqlId = "insertChannelUser";
            String sql = XmlSqlGenerator.getSql(sqlId).exeSql;
            Object[] params = new Object[4];
            params[0] = username;
            params[1] = phone;
            params[2] = channelid;
            params[3] = openid;
            return SqlUtil.updateRecords(ds, sql, params);
        } catch (SQLException e) {
            log.error("insert rcs_user error.", e);
            return false;
        }
    }

    //�����ֻ��Ų����û�(mobile -> user_info ->userid)
    public JsonObject getUserByMobile(String mobile) {
        String sqlId = "getUserByMobile";
        try {
        	String sql = XmlSqlGenerator.getSql(sqlId, mobile).exeSql;
            JsonArray array = queryForJson(ydzyds, sql);
            if (array.size() == 0) {
                return null;
            }
            return array.get(0).getAsJsonObject();
        } catch (Exception e) {
            log.error("get access token error.", e);
        }
        return null;
    }

    public JsonObject getUserGrantByUid(long userid) {
        String sqlId = "getUserGrantByUid";
        try {
        	String sql = XmlSqlGenerator.getSql(sqlId, userid, 4).exeSql;
            JsonArray array = queryForJson(ydzyds, sql);
            if (array.size() == 0) {
                return null;
            }
            return array.get(0).getAsJsonObject();
        } catch (Exception e) {
            log.error("get access token error.", e);
        }
        return null;
    }

    public JsonObject getUserByUnamePass(String username, String password) {
        password = cryptoDES.encode(password);
        String sqlId = "getUserByUserPass";
        Map<String, Object> paramMap = new HashMap<>();
        paramMap.put("IDENTIFIER", username);
        paramMap.put("CREDENTIAL", password);
        paramMap.put("IDENTITY_TYPE", 4);
        String sql = XmlSqlGenerator.getSqlstrByMap(sqlId, paramMap);
        try {
            JsonArray array = queryForJson(ydzyds, sql);
            if (array.size() == 0) {
                return null;
            }
            return array.get(0).getAsJsonObject();
        } catch (Exception e) {
            log.error("get access token error.", e);
        }
        return null;
    }

    public long insertYdzyUser(String mdn) {
        String vistorGroupId = "52";
        return insertYdzyUser(mdn, vistorGroupId, "", "", "5G��Ϣ�ÿ�", "", "", "1");
    }

    public long insertYdzyUser(String mobile,String groupid,String phone) {  //  ��ע���û�״̬Ϊ�����
        return insertYdzyUser(mobile,groupid , "", "", "5G��Ϣ��ҵ����Ա", "", phone, "2");
    }

    public long insertRcsUser(String truename, String email, String phone, String customerId) {
        try {
            String sqlId = "addRcsUser";
            Map<String, Object> paramMap = new HashMap<>();
            paramMap.put("TRUENAME", truename);
            paramMap.put("EMAIL", email);
            paramMap.put("PHONE", phone);
            paramMap.put("customerId", customerId);
            innerSql sql = XmlSqlGenerator.getSqlByMap(sqlId, paramMap);
            return SqlUtil.insert(ds, sql.exeSql,sql.sqlParams.toArray());
        } catch (Exception e) {
            log.error("insert rcs_user error.", e);
            return 0;
        }
    }

    public long insertRcsUser(String phone) {
        return insertRcsUser("","",phone,"");
    }



        public long insertYdzyUser(String mdn, String groupid, String truename, String identity, String userdesc, String email, String phone, String enable) {
        try {
            Map<String, Object> paramMap = new HashMap<>();
            paramMap.put("GROUPID", groupid);
            paramMap.put("TRUENAME", truename);
            paramMap.put("IDENTITY", identity);
            paramMap.put("USERDESC", userdesc);
            paramMap.put("EMAIL", email);
            paramMap.put("PHONE", phone);
            paramMap.put("MOBILE", mdn);
            paramMap.put("ENABLE", enable);
            String sqlId = "addUserInfo";
            innerSql sql = XmlSqlGenerator.getSqlByMap(sqlId, paramMap);
            return SqlUtil.insert(ydzyds, sql.exeSql,sql.sqlParams.toArray());
        } catch (SQLException e) {
            log.error("insert rcs_user error.", e);
            return System.currentTimeMillis();
        }
    }

    public boolean insertYdzyUserGrant(long userId, String identifier) {
        return insertYdzyUserGrant(userId, identifier, "000000", null, null) > 0; //��ʼ���룺000000
    }

    public long insertYdzyUserGrant(long userId, String identifier, String credential, String identity_type, String status) {
        try {
            if (Util.isNull(status))
                status = "2";
            if (Util.isNull(identity_type))
                identity_type = "4";
            Map<String, Object> paramMap = new HashMap<>();
            paramMap.put("USERID", userId);
            paramMap.put("IDENTITY_TYPE", identity_type);
            paramMap.put("IDENTIFIER", identifier);
            credential = cryptoDES.encode(credential);
            paramMap.put("CREDENTIAL", credential);
            paramMap.put("STATUS", status);
            String sqlId = "addUserGrant";
            innerSql sql = XmlSqlGenerator.getSqlByMap(sqlId, paramMap);
            return SqlUtil.insert(ydzyds, sql.exeSql,sql.sqlParams.toArray());
        } catch (SQLException e) {
            log.error("insert rcs_user error.", e);
            return -1;
        }
    }

    public void buildLoginResult(JsonObject loginRst, String groupId, String phone) {
        JsonObject userPermission = getRcsUserPermission(phone);
        JsonArray menuArray = menuAction.getMenus(groupId, applicationconfig.LOGIN_APP_SERVERCODE);
        JsonArray routeArray = menuAction.getRoutes(menuArray, applicationconfig.LOGIN_APP_SERVERCODE, groupId);
        loginRst.add("ROUTES", routeArray);
        loginRst.addProperty("APP", applicationconfig.LOGIN_APP_SERVERNAME);
        loginRst.add("MENUS", menuArray);
        loginRst.add("PERMISSION", userPermission);
    }

    /**
     * ��֤ǩ���Ƿ���ȷ
     *
     * @return JsonObject
     */
    public JsonObject validateSignature(String signature, String timestamp, String nonce, String username,String accessTagNo) {
        JsonObject userObj = getPasswdByUsername(username, accessTagNo);
        String mySign = generateSign(username, accessTagNo, nonce, timestamp);
        if (Util.isNull(mySign) || Util.isNull(signature) || !signature.equals(mySign))
            return null;
        return userObj;
    }

    public void recordLog(String action, String Desc, String remoteAddr, String status, String simation, String phone, String configid, String channel) {
        RcsRunLogAction.recordLog(action, Desc, remoteAddr, status, simation, ds, phone, configid, channel);
    }

    public static final String AUTH_CODE_SUCCESS = "200";
    public static final String AUTH_CODE_ERROR = "500"; //ϵͳ�ڲ�����
    public static final String AUTH_CODE_INVALID_TOKEN = "401";  //���Ϸ���accessToken
    public static final String AUTH_CODE_INVALID_REQ_PARAMS = "40001"; //���Ϸ����������
    public static final String AUTH_CODE_INVALID_REQ_USERNP = "40002"; //��Ч�û�����������
    public static final String AUTH_CODE_MISS_HEADER_PARAM = "40003"; //ȱ������ͷ��Ϣ
    public static final String AUTH_CODE_SYS_BUSY = "40004"; //ϵͳ��æ�����Ժ�����
    public static final String AUTH_CODE_DENY_IP = "40005"; //�ܾ�IP������

    public Map<String, JsonArray> queryRcsPhoneRoles() {
        Map<String, JsonArray> rst = new LinkedHashMap<>();
        try {
            String sqlId = "queryRcsPhoneRoles";
            String sql = XmlSqlGenerator.getSql(sqlId).exeSql;
            JsonArray array = SqlUtil.queryForJson(ds, sql);
            for (JsonElement ele : array) {
                JsonObject obj = ele.getAsJsonObject();
                String chatbotid = Util.getElementAsString(obj, "chatbotid");
                String userphone = Util.getElementAsString(obj, "userphone");
                JsonArray chatbots = rst.computeIfAbsent(userphone, k -> new JsonArray());
                chatbots.add(chatbotid);
            }
        } catch (Exception e) {
            log.error("queryRcsPhoneRoles error.", e);
        }
        return rst;
    }

    public JsonArray getAllRcsUsers(String groupId, String levels, String username) {
        JsonArray jsonArray = new JsonArray();
        try {
            String sqlId = "query5gRcsUsers";
            JsonObject params = new JsonObject();
            params.addProperty("groupid", groupId);
            params.addProperty("levels", levels);
            String sql = XmlSqlGenerator.getSqlByJson(sqlId, null, params);
            JsonArray array = queryForJson(ydzyds, sql);
            if (array.isJsonNull())
                return jsonArray;
            Map<String, JsonObject> groupMap = new LinkedHashMap<>();
            Map<String, Map<String, JsonObject>> userMap = new LinkedHashMap<>();
            Map<String, Map<String, JsonObject>> grantMap = new LinkedHashMap<>();
            Map<String, JsonArray> userChatbotSet = queryRcsPhoneRoles();
            JsonArray loginUserChatbotArray = userChatbotSet.get(username);
            if (!levels.equals("0") && (loginUserChatbotArray == null || loginUserChatbotArray.size() == 0))
                return jsonArray;
            if (null == loginUserChatbotArray)
                loginUserChatbotArray = new JsonArray();
            Set<String> loginUserChatbots = new HashSet<>();
            loginUserChatbotArray.forEach(jsonElement -> {
                loginUserChatbots.add(jsonElement.getAsString());
            });
            for (JsonElement element : array) {
                JsonObject obj = element.getAsJsonObject();
                String identifier = Util.getElementAsString(obj, "identifier");
                JsonArray userChatbotArray = userChatbotSet.get(identifier);

                String groupid = Util.getElementAsString(obj, "groupid");
                String parentid = Util.getElementAsString(obj, "parentid");
                String isadmin = Util.getElementAsString(obj, "isadmin");
                String groupname = Util.getElementAsString(obj, "groupname");
                String groupdesc = Util.getElementAsString(obj, "groupdesc");
                String cdate = Util.getElementAsString(obj, "cdate");
                String mdate = Util.getElementAsString(obj, "mdate");
                JsonObject groupJson = groupMap.get(groupid);
                if (groupJson == null) {
                    groupJson = new JsonObject();
                    groupJson.addProperty("groupid", groupid);
                    groupJson.addProperty("groupname", groupname);
                    groupJson.addProperty("parentid", parentid);
                    groupJson.addProperty("isadmin", isadmin);
                    groupJson.addProperty("groupdesc", groupdesc);
                    groupJson.addProperty("cdate", cdate);
                    groupJson.addProperty("mdate", mdate);
                    groupMap.put(groupid, groupJson);
                }
                //����������Ա�⣬�������Լ�chatbot���û������ܱ���ѯ
                if (!levels.equals("0") && (userChatbotArray == null || userChatbotArray.size() == 0))
                    continue;
                Set<String> userChatbots = new HashSet<>();
                boolean f = false;
                if (levels.equals("0"))
                    f = true;
                else {
                    userChatbotArray.forEach(jsonElement -> {
                        userChatbots.add(jsonElement.getAsString());
                    });
                    qryLoginChatbot : for(String loginChatbot : loginUserChatbots) {
                        for(String userChatbot : userChatbots) {
                            if (loginChatbot.equals(userChatbot)) {
                                f = true;
                                break qryLoginChatbot;
                            }
                        }
                    }
                }

                if (!f)
                    continue;
                String userid = Util.getElementAsString(obj, "userid");
                String truename = Util.getElementAsString(obj, "truename");
                String userdesc = Util.getElementAsString(obj, "userdesc");
                String email = Util.getElementAsString(obj, "email");
                String phone = Util.getElementAsString(obj, "phone");
                String mobile = Util.getElementAsString(obj, "mobile");
                String enable = Util.getElementAsString(obj, "enable");
                String id = Util.getElementAsString(obj, "id");
                String identity_type = Util.getElementAsString(obj, "identity_type");
                String credential = Util.getElementAsString(obj, "credential");
                String status = Util.getElementAsString(obj, "status");

                Map<String, JsonObject> userinfoMap = userMap.computeIfAbsent(groupid, k -> new HashMap<>());
                if (!Util.isNull(userid) && !identifier.equals(username)) {
                    JsonObject userJson = userinfoMap.get(userid);
                    if (userJson == null) {
                        userJson = new JsonObject();
                        userJson.addProperty("userid", userid);
                        userJson.addProperty("truename", truename);
                        userJson.addProperty("userdesc", userdesc);
                        userJson.addProperty("email", email);
                        userJson.addProperty("phone", phone);
                        userJson.addProperty("mobile", mobile);
                        userJson.addProperty("enable", enable);
                        JsonArray chatbots = userChatbotSet.get(identifier);
                        if(chatbots == null)
                            chatbots = new JsonArray();
                        userJson.add("chatbots", chatbots);
                        userinfoMap.put(userid, userJson);
                    }
                }
                Map<String, JsonObject> usergrantMap = grantMap.computeIfAbsent(userid, k -> new HashMap<>());
                if (!Util.isNull(id)) {
                    JsonObject grantObj = new JsonObject();
                    grantObj.addProperty("id", id);
                    grantObj.addProperty("identity_type", identity_type);
                    grantObj.addProperty("identifier", identifier);
                    grantObj.addProperty("oldcredential", credential);
                    grantObj.addProperty("credential", credential);
                    grantObj.addProperty("status", status);
                    grantObj.addProperty("operator", "0");
                    usergrantMap.put(id, grantObj);
                }
            }
            for (Map.Entry<String, JsonObject> entry : groupMap.entrySet()) {
                JsonObject groupObj = entry.getValue();
                JsonArray userarray = new JsonArray();
                String groupid = Util.getElementAsString(groupObj, "groupid");
                Map<String, JsonObject> userinfos = userMap.get(groupid);
                if (userinfos != null) {
                    for (Map.Entry<String, JsonObject> userEntry : userinfos.entrySet()) {
                        String userid = userEntry.getKey();
                        JsonObject userObj = userEntry.getValue();
                        JsonArray grantarray = new JsonArray();
                        Map<String, JsonObject> grants = grantMap.get(userid);
                        for (Map.Entry<String, JsonObject> grantEntry : grants.entrySet()) {
                            grantarray.add(grantEntry.getValue());
                        }
                        userObj.add("grants", grantarray);
                        userarray.add(userObj);
                    }
                }
                groupObj.add("users", userarray);
                jsonArray.add(groupObj);
            }
        } catch (SQLException e) {
            log.error("query 5g rcs users error.", e);
        }
        return jsonArray;
    }

    public JsonArray getUserGroupByGroupId(String groupid) {
        String sqlId = "queryUserGroup";
        Map<String, Object> params = new HashMap<>();
        params.put("groupid", groupid);
        JsonArray jsonArray = new JsonArray();
        try {
        	String sql = XmlSqlGenerator.getSqlByMap(sqlId, params).exeSql;
            jsonArray = queryForJson(ydzyds, sql);
        } catch (Exception e) {
            log.error("query user group error. {}", sqlId);
        }
        return jsonArray;
    }


    public JsonObject register(JsonObject userObj, String customerId) {
        JsonObject userObject = new JsonObject();
        try {
            userObj.addProperty("customerId", customerId);
            userObject = addUser(userObj);
            if (!Util.isNull(customerId) && userObject.has("rcsuserid")) {
                String rcsuserid = userObject.get("rcsuserid").toString();
                String sqlId = "edit_saas_user";
                JsonObject params = new JsonObject();
                params.addProperty("customerId", customerId);
                params.addProperty("rcs_userid", rcsuserid);
                String sql = XmlSqlGenerator.getSqlByJson(sqlId, null, params);
                SqlUtil.updateRecords(ds, sql);
            }
        } catch (Exception e) {
            log.error("register user error. customerId={}", customerId, e);
        }
        return userObject;
    }





    //�����û�
    public JsonObject addUser(JsonObject userObj) {
        String userSql = "";
        JsonObject rtnObj = new JsonObject();
        try {
            String mdn = Util.getElementAsString(userObj, "mobile");
            String truename = Util.getElementAsString(userObj, "truename");
            String groupid = Util.getElementAsString(userObj, "groupid");
            String identity = Util.getElementAsString(userObj, "identity");
            String userdesc = Util.getElementAsString(userObj, "userdesc");
            String email = Util.getElementAsString(userObj, "email");
            String phone = Util.getElementAsString(userObj, "phone");
            String enable = Util.getElementAsString(userObj, "enable");
            String exist = Util.getElementAsString(userObj, "exist");
            String customerId = Util.getElementAsString(userObj, "customerId");
            JsonArray chatbots = userObj.getAsJsonArray("chatbots");
            if(!exist.equals("true")) {    //��ѡ�����˻� exist:""
                long rcsuserid = insertRcsUser(truename, email, phone, customerId);
                if (rcsuserid <= 0)
                    return rtnObj;
                rtnObj.addProperty("rcsuserid", rcsuserid);
                StringBuilder insertGrantSqls = new StringBuilder();
                String insertGrantSqlId = "addRcsPhoneRole";
                if (chatbots != null) {
                    for (JsonElement ele : chatbots) {
                        String chatbotid = ele.getAsString();
                        if (Util.isNull(chatbotid))
                            continue;
                        String sql = XmlSqlGenerator.getSql(insertGrantSqlId, chatbotid, phone).exeSql; //���� phone �����û�Ȩ�� chatbotid
                        insertGrantSqls.append(sql).append(";");
                    }
                }
                String insertGrantSql = insertGrantSqls.toString();
                if (!Util.isNull(insertGrantSql))
                    SqlUtil.updateRecords(ds, insertGrantSql);
            }
            long userid = insertYdzyUser(mdn, groupid, truename, identity, userdesc, email, phone, enable); // ����user_info
            if (userid > 0) {
                rtnObj.addProperty("userid", userid);
                JsonArray grants = userObj.getAsJsonArray("grants");
                JsonArray grantArray = new JsonArray();
                if (!grants.isJsonNull() && grants.size() > 0) {
                    for (JsonElement ele : grants) {
                        JsonObject gobj = ele.getAsJsonObject();
                        String identity_type = Util.getElementAsString(gobj, "identity_type");
                        String identifier = Util.getElementAsString(gobj, "identifier");
                        String credential = Util.getElementAsString(gobj, "credential");
                        credential = CryptoAES.desEncrypt(credential, applicationconfig.AES_KEY, applicationconfig.AES_KEY);
                        String status = Util.getElementAsString(gobj, "status");
                        long grantid = insertYdzyUserGrant(userid, identifier, credential, identity_type, status);// ��ɲ��뵽 user_grant
                            grantArray.add(grantid);
                    }
                }
                rtnObj.add("grants", grantArray);
            }
        } catch (Exception e) {
            log.error("add user error. sql={}", userSql, e);
        }
        return rtnObj;
    }

    //  ע�� rcsUser
    public JsonObject registerRcsUser(JsonObject userObj) {

        JsonObject rtnObj = new JsonObject();
        String phone = Util.getElementAsString(userObj, "phone");
        String mobile = phone;
        String groupid = "50";   //  5G��Ϣ��ҵ����Ա��    ע��rcsUser�����ֲ���ֱ�ӹ̶�
        String identity_type = "4";
        String identifier = phone;
        String credential = Util.getElementAsString(userObj, "credential");
        credential = CryptoAES.desEncrypt(credential, applicationconfig.AES_KEY, applicationconfig.AES_KEY);
        String status = "2";

        long rcsuserid = insertRcsUser(phone); //rcs_user���ע��
        if(rcsuserid <= 0){
            return rtnObj;
        }
        rtnObj.addProperty("rcsuserid",rcsuserid);
        long userid = insertYdzyUser(mobile,groupid,phone);  //����user_info
        if (userid > 0) {
            rtnObj.addProperty("userid", userid); // rtnObj: {"rcsuserid":107508,"userid":446}
            JsonArray grantArray = new JsonArray();

            long grantid = insertYdzyUserGrant(userid, identifier, credential, identity_type, status);// ��ɲ��뵽 user_grant

            grantArray.add(grantid);
            rtnObj.add("grants", grantArray);
        }
        return rtnObj;
    }

    public boolean deleteUser(String userid, String phone) {
        String sqlId = "delUserInfo";
        String delRcsUserSqlId = "delRcsUserInfo";
        String sql = "";
        try {
            Map<String, Object> params = new HashMap<>();
            params.put("userid", userid);
            innerSql sqlObject = XmlSqlGenerator.getSqlByMap(sqlId, params);
            
            sql=sqlObject.exeSql;
            boolean flag = SqlUtil.updateRecords(ydzyds, sql,sqlObject.sqlParams.toArray());
            if (flag) {
                Map<String, Object> p = new HashMap<>();
                p.put("phone", phone);
                sqlObject = XmlSqlGenerator.getSqlByMap(delRcsUserSqlId, p);
                sql=sqlObject.exeSql;
                flag = SqlUtil.updateRecords(ds, sql,sqlObject.sqlParams.toArray());
                return flag;
            }
        } catch (Exception e) {
            log.error("delete userinfo error. userid:" + userid, e);
        }
        return false;
    }

    public boolean editUser(JsonObject userObj) {
        boolean flag = false;
        try {
            String operator = Util.getElementAsString(userObj, "operator");
            String userid = Util.getElementAsString(userObj, "userid");
            JsonArray grantArray = userObj.getAsJsonArray("grants");
            switch (operator) {
                // delete
                case "-1" -> {
                    flag = delUserInfo(userid);
                }
                // edit
                case "2" -> {
                    flag = editUserInfo(userObj);
                    if (flag)
                    flag = editUserGrant(userid, grantArray);
                }
            }
        } catch (Exception e) {
            log.error("edit user error.", e);
        }
        return flag;
    }

    public boolean editRcsUser(JsonObject userObj) {
        String operator = Util.getElementAsString(userObj, "operator");
        // delete
        if (operator.equals("-1")) {  //���� operator ����ִ�еĲ���
            String sqlId = "deleteRcsUser";
            try {
                String userid = Util.getElementAsString(userObj, "userid");
                Map<String, Object> params = new HashMap<>();
                params.put("userid", userid);
                innerSql sql = XmlSqlGenerator.getSqlByMap(sqlId, params);
                return SqlUtil.updateRecords(ds, sql.exeSql,sql.sqlParams.toArray());
            } catch (Exception e) {
                log.error("delete rcs_user error.", e);
            }
            return false;
        }
        // edit
        if (operator.equals("2")) {
            String sqlId = "updateRcsUser";
            try {
                String userid = Util.getElementAsString(userObj, "userid");
                if (Util.isNull(userid))
                    return false;
                String truename = Util.getElementAsString(userObj, "truename");
                String picture = Util.getElementAsString(userObj, "picture");
                String phone = Util.getElementAsString(userObj, "phone");
                String email = Util.getElementAsString(userObj, "email");
                String area = Util.getElementAsString(userObj, "area");
                String sex = Util.getElementAsString(userObj, "sex");
                Map<String, Object> params = new HashMap<>();
                params.put("username", truename);
                params.put("picture", picture);
                params.put("phone", phone);
                params.put("email", email);
                params.put("area", area);
                params.put("sex", sex);
                params.put("userid", userid);
                innerSql sql = XmlSqlGenerator.getSqlByMap(sqlId, params);
                return SqlUtil.updateRecords(ds, sql.exeSql,sql.sqlParams.toArray());
            } catch (Exception e) {
                log.error("edit rcs_user error.", e);
            }
        }

        return false;
    }

    public boolean editUserInfo(JsonObject userObj) {
        String sqlId = "updateUserInfo";
        try {
            String userid = Util.getElementAsString(userObj, "userid");
            if (Util.isNull(userid))
                return false;
            String groupid = Util.getElementAsString(userObj, "groupid");
            String truename = Util.getElementAsString(userObj, "truename");
            String userdesc = Util.getElementAsString(userObj, "userdesc");
            String enable = Util.getElementAsString(userObj, "enable");
            String email = Util.getElementAsString(userObj, "email");
            String phone = Util.getElementAsString(userObj, "phone");
            String mobile = Util.getElementAsString(userObj, "mobile");
            String identity = Util.getElementAsString(userObj, "identity");
            Map<String, Object> params = new HashMap<>();
            params.put("groupid", groupid);
            params.put("truename", truename);
            params.put("identity", identity);
            params.put("userdesc", userdesc);
            params.put("email", email);
            params.put("mobile", mobile);
            params.put("enable", enable);
            params.put("userid", userid);
            params.put("phone", phone);
            innerSql sql =  XmlSqlGenerator.getSqlByMap(sqlId, params);
            String from = Util.getElementAsString(userObj, "from");
            if (Util.isNull(from) || !from.equals("maillist")) {
                JsonArray chatbots = userObj.getAsJsonArray("chatbots");
                StringBuilder insertGrantSqls = new StringBuilder();
                String delRcsPhoneRoleSqlId = "delRcsPhoneRole";
                String delRcsPhoneRoleSql = XmlSqlGenerator.getSql(delRcsPhoneRoleSqlId, phone).exeSql;
                insertGrantSqls.append(delRcsPhoneRoleSql).append(";");
                if (chatbots != null) {
                    String insertGrantSqlId = "addRcsPhoneRole";
                    for (JsonElement ele : chatbots) {
                        String chatbotid = ele.getAsString();
                        String delsql = XmlSqlGenerator.getSql(insertGrantSqlId, chatbotid, phone).exeSql;  //rcs_phone_roles chatbotId userPhone
                        insertGrantSqls.append(delsql).append(";");  //�����д�ִ��sqlƴ��һ������
                    }
                    SqlUtil.updateRecords(ds, insertGrantSqls.toString());
                }
            }
            return SqlUtil.updateRecords(ydzyds, sql.exeSql,sql.sqlParams.toArray());
        } catch (Exception e) {
            log.error("edit userinfo error.", e);
        }
        return false;
    }

    public boolean editUserGrant(String userid, JsonArray grantArray) {
        try {
            if (grantArray==null||grantArray.isJsonNull()||grantArray.size() == 0)
                return true;
            for (JsonElement ele : grantArray) {
                JsonObject grantObj = ele.getAsJsonObject();
                String operator = Util.getElementAsString(grantObj, "operator");
                String id = Util.getElementAsString(grantObj, "id");
                boolean flag = false;
                switch (operator) {
                    // delete
                    case "-1" -> {
                        flag = delUserGrant(id);
                        if (!flag)
                            log.error("delete user grant failed. grantid:" + id);
                    }
                    case "1" -> {
                        String identifier = Util.getElementAsString(grantObj, "identifier");
                        String credential = Util.getElementAsString(grantObj, "credential");
                        credential = CryptoAES.desEncrypt(credential, applicationconfig.AES_KEY, applicationconfig.AES_KEY);
                        String identity_type = Util.getElementAsString(grantObj, "identity_type");
                        String status = Util.getElementAsString(grantObj, "status");
                        long grantid = insertYdzyUserGrant(Util.toLong(userid, 0), identifier, credential, identity_type, status);
                        if (grantid < 0)
                            log.error("create grent " + identifier + " failed. userid:" + userid);
                    }
                    // edit
                    case "2" -> {
                        flag = editGrant(grantObj);
                        if (!flag)
                            log.error("modify grent failed. userid:" + userid);
                    }
                }
            }
        } catch (Exception e) {
            log.error("edit userinfo error.", e);
            return false;
        }
        return true;
    }
    //�޸�����
    public boolean changePassword(JsonObject object) {
        String sqlId = "changeUserPwd";
        try {
            String userid = Util.getElementAsString(object, "ydzyUserId");
            String oldcredential = Util.getElementAsString(object, "oldcredential");
            oldcredential = CryptoAES.desEncrypt(oldcredential, applicationconfig.AES_KEY, applicationconfig.AES_KEY); //����
            oldcredential = cryptoDES.encode(oldcredential); //����
            JsonObject userobj = getUserGrantByUid(Util.toLong(userid, 0L));//����userid�õ��û���Ȩ��ԭ����
            if (userobj == null)
                return false;
            String dbcredential = Util.getElementAsString(userobj, "credential");
            if (!dbcredential.equals(oldcredential)) { //�����ݿ��д洢��ԭ�������û���������Ƚ�
                return false;
            }
            String credential = Util.getElementAsString(object, "credential"); //credential="hoF++fhD4L98R4OWdJJaQQ=="
            credential = CryptoAES.desEncrypt(credential, applicationconfig.AES_KEY, applicationconfig.AES_KEY);//����credential="qwer2021"
            object.addProperty("credential", cryptoDES.encode(credential)); //����
            String sql = XmlSqlGenerator.getSqlByJson(sqlId, null, object);//update user_grant set credential='8332b5dd379a14e92884b236680add0a'/*,status='{status}'*/ where userid='107'
            return SqlUtil.updateRecords(ydzyds, sql);
        } catch (Exception e) {
            log.error("change password error.", e);
        }
        return false;
    }

    //TODO
    //��������,��������
    public boolean shortMessageReset(JsonObject object) {
        String sqlId = "resetUserPwd";
        try {
            String credential = Util.getElementAsString(object, "credential");
            credential = CryptoAES.desEncrypt(credential, applicationconfig.AES_KEY, applicationconfig.AES_KEY);//����credential="qwer2021"
            object.addProperty("credential", cryptoDES.encode(credential)); //����  credential: "[ERROR]"
            String sql = XmlSqlGenerator.getSqlByJson(sqlId, null, object);
            return SqlUtil.updateRecords(ydzyds, sql);
        } catch (SQLException e) {
            log.error("reset password error.", e);
        }
        return false;
    }

    public boolean editGrant(JsonObject grantObj) {
        String sqlId = "updateUserGrant";
        innerSql sql = null;
        String id = "";
        try {
            id = Util.getElementAsString(grantObj, "id");
            String identifier = Util.getElementAsString(grantObj, "identifier");
            String credential = Util.getElementAsString(grantObj, "credential");
            String oldcredential = Util.getElementAsString(grantObj, "oldcredential");
            String status = Util.getElementAsString(grantObj, "status");
            Map<String, Object> params = new HashMap<>();
            params.put("id", id);
            params.put("identifier", identifier);
            if (!credential.equals(oldcredential)) {
                credential = CryptoAES.desEncrypt(credential, applicationconfig.AES_KEY, applicationconfig.AES_KEY);
                credential = cryptoDES.encode(credential);
            }
            params.put("credential", credential);
            params.put("status", status);
            sql = XmlSqlGenerator.getSqlByMap(sqlId, params);
            if(sql==null) {
            	 log.error("edit grant error. sqlId:" + sqlId );
            	return false;
            }
            return SqlUtil.updateRecords(ydzyds, sql.exeSql,sql.sqlParams.toArray());
        } catch (Exception e) {
            log.error("edit grant error. grantid:" + id + "  sql:" + sql, e);
        }
        return false;
    }

    public boolean delUserGrant(String id) {
        String sqlId = "deleteUserGrant";
        try {
            Map<String, Object> params = new HashMap<>();
            params.put("id", id);
            innerSql sql = XmlSqlGenerator.getSqlByMap(sqlId, params);
            if(sql==null) {
           	 log.error("cannot find . sqlId:" + sqlId );
           	return false;
           }
            return SqlUtil.updateRecords(ydzyds, sql.exeSql,sql.sqlParams.toArray());
        } catch (Exception e) {
            log.error("delete user grant error. grant id={}", id);
        }
        return false;
    }

    public boolean delUserInfo(String userid) {
        String sqlId = "delUserInfo";
        innerSql sql = null;
        try {
            Map<String, Object> params = new HashMap<>();
            params.put("userid", userid);
            sql = XmlSqlGenerator.getSqlByMap(sqlId, params);
            if(sql==null) {
              	 log.error("cannot find . sqlId:" + sqlId );
              	return false;
              }
            return SqlUtil.updateRecords(ydzyds, sql.exeSql,sql.sqlParams.toArray());
        } catch (Exception e) {
            log.error("delete user info error.sql={}", sql, e);
        }
        return false;
    }

    public JsonArray queryUserGroupMenuRelation() {
        String sqlId = "queryUserGroupMenuRelation";
        JsonArray jsonArray = new JsonArray();
        Map<String, JsonObject> groupMap = new HashMap<>();
        try {
        	String sql = XmlSqlGenerator.getSql(sqlId).exeSql;
            JsonArray array = SqlUtil.queryForJson(ydzyds, sql);
            if (array.size() == 0)
                return jsonArray;
            for (JsonElement ele : array) {
                JsonObject obj = ele.getAsJsonObject();
                String groupid = Util.getElementAsString(obj, "groupid");
                JsonObject menuObject = groupMap.get(groupid);
                if (menuObject == null) {
                    menuObject = new JsonObject();
                    menuObject.addProperty("groupid", Util.getElementAsString(obj, "groupid"));
                    menuObject.addProperty("groupname", Util.getElementAsString(obj, "groupname"));
                    menuObject.addProperty("groupdesc", Util.getElementAsString(obj, "groupdesc"));
                    groupMap.put(groupid, menuObject);
                }
                JsonArray menuArray = menuObject.getAsJsonArray("menus");
                if (menuArray == null) {
                    menuArray = new JsonArray();
                    menuObject.add("menus", menuArray);
                }
                JsonObject subMenuObj = new JsonObject();
                String menu_id = Util.getElementAsString(obj, "menu_id");
                if(!Util.isNull(menu_id)){
                    subMenuObj.addProperty("menu_id", Util.getElementAsString(obj, "menu_id"));
                    subMenuObj.addProperty("parentid", Util.getElementAsString(obj, "parentid"));
                    subMenuObj.addProperty("rank", Util.getElementAsString(obj, "rank"));
                    subMenuObj.addProperty("menu_name", Util.getElementAsString(obj, "menu_name"));
                    subMenuObj.addProperty("menu_text", Util.getElementAsString(obj, "menu_text"));
                    subMenuObj.addProperty("menu_url", Util.getElementAsString(obj, "menu_url"));
                    subMenuObj.addProperty("parameter", Util.getElementAsString(obj, "parameter"));
                    subMenuObj.addProperty("parameter_type", Util.getElementAsString(obj, "parameter_type"));
                    subMenuObj.addProperty("icon_uri", Util.getElementAsString(obj, "icon_uri"));
                    subMenuObj.addProperty("operator", "0");
                    menuArray.add(subMenuObj);
                }
            }
            groupMap.forEach((s, jsonObject) -> {
                jsonArray.add(jsonObject);
            });
        } catch (Exception e) {
            log.error("queryUserGroupMenuRelation error.sqlid={}", sqlId, e);
        }
        return jsonArray;
    }

    public boolean editGroupMenuRelation(JsonObject object) {
        String groupid = Util.getElementAsString(object, "groupid");
        JsonArray menuArray = object.getAsJsonArray("menus");
        if (Util.isNull(groupid) || menuArray.size() == 0)
            return true;
        StringBuilder sqls = new StringBuilder("");
        for (JsonElement ele : menuArray) {
            JsonObject obj = ele.getAsJsonObject();
            String operator = Util.getElementAsString(obj, "operator");
            String menuid = Util.getElementAsString(obj, "menu_id");
            String sql = "";
            switch (operator) {
                case "-1" -> {sql = delGroupMenuRelation(groupid, menuid);}
                case "1" -> {sql = addGroupMenuRelation(groupid, menuid);}
            }
            if (!Util.isNull(sql))
                sqls.append(sql).append(";");
        }
        if (!Util.isNull(sqls.toString())) {
            try {
                return SqlUtil.updateRecords(ydzyds, sqls.toString());
            } catch (SQLException throwables) {
                log.error("editMenuRouteRelation error.", throwables);
                return false;
            }
        }
        return true;
    }

    private String addGroupMenuRelation(String groupid, String menuid) {
        String sqlId = "addUserGroupMenuRelation";
        return XmlSqlGenerator.getSql(sqlId, groupid, menuid).exeSql;
    }

    private String delGroupMenuRelation(String groupid, String menuid) {
        String sqlId = "deleteUserGroupMenuRelation";
        return  XmlSqlGenerator.getSql(sqlId, groupid, menuid).exeSql;
    }

    public JsonArray queryUserGroupRouteRelation(JsonObject object) {
        String sqlId = "queryUserGroupRouteRelation";
        String sql = XmlSqlGenerator.getSqlByJson(sqlId, null, object);
        JsonArray jsonArray = new JsonArray();
        Map<String, JsonObject> groupMap = new HashMap<>();
        try {
            JsonArray array = SqlUtil.queryForJson(ydzyds, sql);
            if (array.size() == 0)
                return jsonArray;
            for (JsonElement ele : array) {
                JsonObject obj = ele.getAsJsonObject();
                String groupid = Util.getElementAsString(obj, "groupid");
                JsonObject menuObject = groupMap.get(groupid);
                if (menuObject == null) {
                    menuObject = new JsonObject();
                    menuObject.addProperty("groupid", Util.getElementAsString(obj, "groupid"));
                    menuObject.addProperty("groupname", Util.getElementAsString(obj, "groupname"));
                    menuObject.addProperty("groupdesc", Util.getElementAsString(obj, "groupdesc"));
                    groupMap.put(groupid, menuObject);
                }
                JsonArray routeRightArray = menuObject.getAsJsonArray("routes");
                if (routeRightArray == null) {
                    routeRightArray = new JsonArray();
                    menuObject.add("routes", routeRightArray);
                }
                JsonObject routeRightObj = new JsonObject();
                String id = Util.getElementAsString(obj, "id");
                if(!Util.isNull(id)){
                    routeRightObj.addProperty("id", Util.getElementAsString(obj, "id"));
                    routeRightObj.addProperty("apiinfo", Util.getElementAsString(obj, "apiinfo"));
                    routeRightObj.addProperty("apiname", Util.getElementAsString(obj, "apiname"));
                    routeRightObj.addProperty("isdelete", Util.getElementAsString(obj, "isdelete"));
                    routeRightObj.addProperty("isedit", Util.getElementAsString(obj, "isedit"));
                    routeRightObj.addProperty("isexport", Util.getElementAsString(obj, "isexport"));
                    routeRightObj.addProperty("operator", Util.getElementAsString(obj, "0"));
                    routeRightArray.add(routeRightObj);
                }
            }
            groupMap.forEach((s, jsonObject) -> {
                jsonArray.add(jsonObject);
            });
        } catch (Exception e) {
            log.error("queryUserGroupRouteRelation error.sql={}", sql, e);
        }
        return jsonArray;
    }

    public boolean editUserGroupRouteRelation(JsonObject object) {
        String groupid = Util.getElementAsString(object, "groupid");
        JsonArray routeRightArray = object.getAsJsonArray("routes");
        if (Util.isNull(groupid) || routeRightArray.size() == 0)
            return true;
        StringBuilder sqls = new StringBuilder("");
        String sqlId = "editUserGroupRouteRelation";
        String insertSql = "addGroupRouteRelation";
        for (JsonElement ele : routeRightArray) {
            JsonObject routeObj = ele.getAsJsonObject();
            String operator = Util.getElementAsString(routeObj, "operator");
            String sql = "";
            String id = Util.getElementAsString(routeObj, "id");
            String isdelete = Util.getElementAsString(routeObj, "isdelete");
            String isedit = Util.getElementAsString(routeObj, "isedit");
            String isexport = Util.getElementAsString(routeObj, "isexport");
            String apiname = Util.getElementAsString(routeObj, "apiname");
            switch (operator) {
                //insert into user_group_route_right(groupid,route,isdelete,isedit,isexport) values('{0}','{1}','{2}','{3}','{4}')
                case "1" -> sql = XmlSqlGenerator.getSql(insertSql, groupid, apiname, isdelete, isedit, isexport).exeSql;
                case "2" -> sql = XmlSqlGenerator.getSql(sqlId, isdelete, isedit, isexport, id).exeSql;
            }
            sqls.append(sql).append(";");
        }
        String sql = sqls.toString();
        if (Util.isNull(sql))
            return true;
        try {
            return SqlUtil.updateRecords(ydzyds, sql);
        } catch (SQLException e) {
            log.error("editUserGroupRouteRelation error. sqlId:{}", sqlId, e);
        }
        return false;
    }

    public JsonObject getChatbotidByIdenty(String chatbotIndenty) {
        String sqlId = "getChatbotidByIdenty";
        try {
            String sql = XmlSqlGenerator.getSql(sqlId, chatbotIndenty).exeSql;
            JsonArray array = SqlUtil.queryForJson(ds, sql);
            if (array.size() == 0)
                return new JsonObject();
            return array.get(0).getAsJsonObject();
        }catch (Exception e) {
            log.error("getChatbotidByIdenty error.", e);
        }
        return new JsonObject();
    }

    public long addUserGroup(JsonObject userObj) {
        String sqlId = "addUserGroup";
        try {
            String sql = XmlSqlGenerator.getSqlByJson(sqlId, null, userObj);
            long groupid = SqlUtil.insert(ydzyds, sql);
            if (groupid > 0) {
                String addUserGroupAppSqlId = "addUserGroupApp";
                sql = XmlSqlGenerator.getSql(addUserGroupAppSqlId, groupid).exeSql;
                SqlUtil.updateRecords(ydzyds, sql);
                return groupid;
            }
        } catch (Exception e) {
            log.error("add user group error.", e);
        }
        return -1;
    }

    public JsonObject maillist(String chatbotid) {
        JsonArray companyUsers = getCompanyUser(chatbotid);
        JsonArray users = getRcsUserByChatbotid(chatbotid);
        JsonObject object = new JsonObject();
        object.add("companyUsers", companyUsers);
        object.add("users", users);
        return object;
    }
    public JsonArray getCompanyUser(String chatbotid) {
        queryYdzyGroup();
        String sqlId = "queryCompanyUsers";
        JsonArray array = new JsonArray();
        try {
            JsonObject params = new JsonObject();
            params.addProperty("chatbotId", chatbotid.replace("'",""));
            String sql = XmlSqlGenerator.getSqlByJson(sqlId, null, params);
            array = SqlUtil.queryForJson(ds, sql);
            for (JsonElement ele : array) {
                JsonObject obj = ele.getAsJsonObject();
                String username = Util.getElementAsString(obj, "username");
                String password = Util.getElementAsString(obj, "password");
                String groupid = Util.getElementAsString(obj, "groupid");
                obj.addProperty("groupname", userGroupMap.get(groupid));
                obj.remove("username");
                obj.remove("password");
                JsonObject grantObj = new JsonObject();
                grantObj.addProperty("identifier", username);
                grantObj.addProperty("credential", password);
                JsonArray grantArray = new JsonArray();
                grantArray.add(grantObj);
                obj.add("grants", grantArray);
            }
        } catch (Exception e) {
            log.error("get company user info error.", e);
        }
        return array;
    }

    public boolean editCompanyUser(JsonObject userObject) {
        String sqlId = "updateCompanyUser";
        try {
            JsonArray grants = userObject.getAsJsonArray("grants");
            if (grants.size() == 0)
                return false;
            JsonObject grant = userObject.getAsJsonArray("grants").get(0).getAsJsonObject();
            String password = Util.getElementAsString(grant, "credential");
            String oldpassword = Util.getElementAsString(grant, "oldcredential");
            if (!password.equals(oldpassword))
                password = cryptoDES.encode(password);
            userObject.addProperty("password", password);
            userObject.addProperty("username", Util.getElementAsString(grant, "identifier"));
            if (userObject.has("subscribeDataUrl"))
                userObject.addProperty("subscribeDataUrl", userObject.get("subscribeDataUrl").toString());
            String sql = XmlSqlGenerator.getSqlByJson(sqlId, null, userObject);
            return SqlUtil.updateRecords(ds, sql);
        }catch (Exception e) {
            log.error("edit company user error.", e);
        }
        return false;
    }

    public boolean delCompanyUser(String id) {
        String sqlId= "delCompanyUser";
        try {
            String sql = XmlSqlGenerator.getSql(sqlId, id).exeSql;
            return SqlUtil.updateRecords(ds, sql);
        } catch (Exception e) {
            log.error("delete company user error.", e);
        }
        return false;
    }

    public boolean addCompanyUser(JsonObject userObject) {
        String sqlId = "addCompanyUser";
        try {
            JsonArray grants = userObject.getAsJsonArray("grants");
            if (grants.size() == 0)
                return false;
            JsonObject grant = userObject.getAsJsonArray("grants").get(0).getAsJsonObject();
            String password = Util.getElementAsString(grant, "credential");
            password = cryptoDES.encode(password);
            userObject.addProperty("password", password);
            userObject.addProperty("username", Util.getElementAsString(grant, "identifier"));
            if (userObject.has("subscribeDataUrl"))
                userObject.addProperty("subscribeDataUrl", userObject.get("subscribeDataUrl").toString());
            String sql = XmlSqlGenerator.getSqlByJson(sqlId, null, userObject);
            return SqlUtil.updateRecords(ds, sql);
        }catch (Exception e) {
            log.error("edit company user error.", e);
        }
        return false;
    }

    public JsonArray getRcsUserByChatbotid(String chatbotid) {
        Map<String, String> adminPhoneSet = getAdminUser();
        String sqlId = "queryRcsUsers";
        JsonArray rstArray = new JsonArray();
        try {
            Map<String,JsonArray> indexUsers = new LinkedHashMap<>();
            JsonObject params = new JsonObject();
            params.addProperty("chatbotId", chatbotid.replace("'", ""));
            String sql = XmlSqlGenerator.getSqlByJson(sqlId, null, params);
            JsonArray array = SqlUtil.queryForJson(ds, sql);
            for(JsonElement ele : array) {
                JsonObject obj = ele.getAsJsonObject();
                String phone = Util.getElementAsString(obj, "phone");
                String idtype = adminPhoneSet.get(phone);
                if (!Util.isNull(idtype) && idtype.equals("superAdmin"))
                    continue;

                String username = Util.getElementAsString(obj, "truename");
                String index = Util.isNull(username) ? "" : PinYinUtil.getFirstSpell(username).toUpperCase().substring(0,1);
                JsonArray users = indexUsers.get(index);
                if (users == null) {
                    users = new JsonArray();
                    indexUsers.put(index, users);
                }
                boolean isAdmin = false;
                if (!Util.isNull(idtype)) {
                    isAdmin = idtype.equals("companyAdmin");
                    obj.addProperty("isAdmin", isAdmin);
                }
                users.add(obj);
            }
            indexUsers.forEach((index, jsonElements) -> {
                JsonObject obj = new JsonObject();
                obj.addProperty("index", index);
                obj.add("children", jsonElements);
                rstArray.add(obj);
            });
        } catch (Exception e) {
            log.error("get rcs user info error.", e);
        }
        return rstArray;
    }

    public void queryYdzyGroup() {
        if (userGroupMap.size() != 0)
            return;
        String sqlId = "queryYdzyGroup";
        try {
            String sql = XmlSqlGenerator.getSql(sqlId).exeSql;
            JsonArray array = SqlUtil.queryForJson(ydzyds, sql);
            if (array.size() == 0)
                return;
            for(JsonElement ele : array) {
                JsonObject obj = ele.getAsJsonObject();
                String groupid = Util.getElementAsString(obj, "groupid");
                String groupdesc = Util.getElementAsString(obj, "groupdesc");
                userGroupMap.put(groupid, groupdesc);
            }
        }catch (Exception e) {
            log.error("query ydzy group error.", e);
        }
    }

    private Map<String, String> getAdminUser() {
        String sqlId = "queryAdminUser";
        Map<String, String> adminPhones = new HashMap<>();
        try {
            String sql = XmlSqlGenerator.getSql(sqlId).exeSql;
            JsonArray array = SqlUtil.queryForJson(ydzyds, sql);
            for(JsonElement ele : array) {
                JsonObject obj = ele.getAsJsonObject();
                adminPhones.put(Util.getElementAsString(obj, "identifier"), Util.getElementAsString(obj, "idtype"));
            }
        }catch (Exception e) {
            log.error("query error.", e);
        }
        return adminPhones;
    }

    public JsonArray getExistUsers(JsonObject object) {
        JsonArray newArray = new JsonArray();
        try {
            JsonArray ydzyUsers = getYdzyUserInfos();
            JsonArray rcsUsers = getRcsUsers(object);
            rcs : for(JsonElement rcsEle : rcsUsers) {
                JsonObject rcsUserObject = rcsEle.getAsJsonObject();
                String rcsPhone = Util.getElementAsString(rcsUserObject, "phone");
                for(JsonElement ydzyEle : ydzyUsers) {
                    JsonObject ydzyUserObject = ydzyEle.getAsJsonObject();
                    String ydzyPhone = Util.getElementAsString(ydzyUserObject, "identifier");
                    if (rcsPhone.equals(ydzyPhone))
                        continue rcs;
                }
                newArray.add(rcsEle);
            }
            return newArray;
        } catch (Exception e) {
            log.error("get exist user error.", e);
        }
        return newArray;
    }

    public boolean allotUserCluster(JsonObject object) {
        if (!object.has("data"))
            return true;
        JsonObject dataObject = object.getAsJsonObject("data");
        Set<String> clusters = dataObject.keySet();
        if (clusters == null || clusters.size() == 0)
            return true;
        String delSqlId = "delRcsUserClusterRelation"; //delete from rcs_user_cluster_relation where userid='{userid}' and cluster_id='{cluster_id}'
        String addSqlId = "addRcsUserClusterRelation"; //insert into rcs_user_cluster_relation(userid,cluster_id) values('{userid}', '{cluster_id}')
        StringBuilder sqlBuilder = new StringBuilder();
        JsonObject params = new JsonObject();
        clusters.forEach(clusterId -> {
            JsonArray userIds = dataObject.getAsJsonArray(clusterId);
            params.addProperty("cluster_id", clusterId);
            userIds.forEach(jsonElement -> {
                JsonObject userObject = jsonElement.getAsJsonObject();
                String userid = Util.getElementAsString(userObject, "userid");
                String optype = Util.getElementAsString(userObject, "optype");
                params.addProperty("userid", userid);
                // -1��ɾ��  1������
                switch (optype) {
                    case "-1" -> sqlBuilder.append(XmlSqlGenerator.getSqlByJson(delSqlId, null, params)).append(";");
                    case "1" -> sqlBuilder.append(XmlSqlGenerator.getSqlByJson(addSqlId, null, params)).append(";");
                }
            });
        });

        try {
            String sql = sqlBuilder.toString();
            return SqlUtil.updateRecords(ds, sql);
        } catch (Exception e) {
            log.error("allotUserCluster error", e);
            return false;
        }
    }
    private JsonArray getYdzyUserInfos() {
        String sqlId = "getUserGrants";
        try {
            String sql = XmlSqlGenerator.getSql(sqlId).exeSql;
            return SqlUtil.queryForJson(ydzyds, sql);
        }catch (Exception e) {
            log.error("query ydzy userinfo error.", e);
        }
        return new JsonArray();
    }

    private JsonArray getRcsUsers(JsonObject object) {
        String sqlId = "queryAllRcsUser";
        try {
            String sql = XmlSqlGenerator.getSqlByJson(sqlId, null, object);
            return SqlUtil.queryForJson(ds, sql);
        }catch (Exception e) {
            log.error("query rcs user error.", e);
        }
        return new JsonArray();
    }

    public boolean allotUserTags(JsonObject object) {
        String sqlId = "allotUserTags";
        StringBuilder sqls = new StringBuilder();
        try {
            String phone = Util.getElementAsString(object, "phone");
            if (Util.isNull(phone))
                return false;
            JsonArray allotArray = object.getAsJsonArray("1");
            JsonArray deleteArray = object.getAsJsonArray("-1");
            if (allotArray != null && !allotArray.isJsonNull() && allotArray.size() > 0) {
                for (JsonElement ele : allotArray) {
                    String tag = ele.getAsString();
                    sqls.append(XmlSqlGenerator.getSql("allotUserTags", phone, tag).exeSql).append(";");
                }
            }
            if (deleteArray != null && !deleteArray.isJsonNull() && deleteArray.size() > 0) {
                for (JsonElement ele : deleteArray) {
                    String tag = ele.getAsString();
                    sqls.append(XmlSqlGenerator.getSql("deleteUserTags", phone, tag).exeSql).append(";");
                }
            }
            String sql = sqls.toString();
            return SqlUtil.updateRecords(ds, sql);
        }catch (Exception e) {
            log.error("allot user tags error.", e);
        }
        return false;
    }

    public boolean addRcsPhoneRole(String chatbotid, String phone) {
        String querySqlId = "queryUserCount";
        String sqlid = "addRcsPhoneRole";
        try {
            JsonObject param = new JsonObject();
            param.addProperty("phone", phone);
            String qsql = XmlSqlGenerator.getSqlByJson(querySqlId, null, param);
            JsonObject o = SqlUtil.queryForJson(ds, qsql).get(0).getAsJsonObject();
            int ct = o.get("ct").getAsInt();
            if (ct == 0) {
                String sql = XmlSqlGenerator.getSql(sqlid, chatbotid, phone).exeSql;
                return SqlUtil.updateRecords(ds, sql);
            }
            return true;
        } catch (SQLException throwables) {
            log.error("addRcsPhoneRole error", throwables);
            return false;
        }
    }



    public void startCheckLogoutTokenThread() {
        Thread thread = new Thread(() -> {
            while (true) {
                try {
                    for (String token : logoutTokenQueue) {
                        boolean isExpired = true;
                        if (!Util.isNull(token)) {
                            try {
                                isExpired = jwtOperatorUtil.isTokenExpired(token);
                            } catch (Exception ignored) {
                            }
                        }
                        if (isExpired)
                            logoutTokenQueue.remove();
                    }
                    Thread.sleep(10000L);
                } catch (Exception ignored) {
                }
            }
        });
        thread.start();
    }

    public static void main(String[] args) {
        /*
        String username = "policyApp";
        String password = "a37958a9bcb5d5882884b236680add0a";
        String nonce = "67.63244978920625";
        String cacheRst = "";
        for (int i = 0; i < 1; i++) {
            Instant i1 = Instant.now();
            long timestamp = i1.getEpochSecond();
            byte[] sha256 = Util.digest(password, nonce, timestamp + "");
            String mySign = Base64.getEncoder().encodeToString(sha256);

            String url = "http://192.168.8.68:18080/delivery/chat/box?accessTagNo=2&Username="+username+"&nonce=" + nonce + "&signature=" + mySign + "&timestamp=" + timestamp + "&openid=1001&phone" +
                    "=17752318899";
            System.out.println("do request:" + url);
            try {
                String rst = NetUtils.doHttps(url, null, null, "application/json");
                if (Util.isNull(cacheRst))
                    cacheRst = rst;
                else {
                    if (!rst.equals(cacheRst)) {
                        System.out.println(url);
                        System.exit(0);
                    }
                }
                Thread.sleep(1000L);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
*/
//        getWeixinMPUrl();
//        getPoliceUrl();
//        getWeixinUrl();
//        getRgzxUrl();
        getJxptUrl();
    }

    private static void getWeixinMPUrl() {
        /*
timestamp: 1645710945905
nonce: 0.306186
Username: policeCheck
password:qwer123
         */
        String username = "policeCheck";
        String password = "qwer123";
        String phone = "18600000001";
        String nonce = "0.306186";
        Instant i1 = Instant.now();
        long timestamp = 1645710945905L;
        byte[] sha256 = Util.digest(password, nonce, timestamp + "");
        String mySign = Base64.getEncoder().encodeToString(sha256);
        System.out.println(mySign);
        String url =
                "http://192.168.8.68:18080/delivery/chat/box?accessTagNo=2&Username=" + username + "&nonce=" + nonce + "" +
                        "&signature=" + mySign + "&timestamp=" + timestamp + "&openid=1001&phone=" + phone + "&driving=0";
        System.out.println("���ڶˣ�" + url);
    }

    private static void getWeixinUrl() {
        String username = "weixinApp";
        String password = "0ab900cd15d21efa2884b236680add0a";
        String phone = "15588887788";
        String nonce = "67.63244978920625";
        Instant i1 = Instant.now();
        long timestamp = i1.getEpochSecond();
        byte[] sha256 = Util.digest(password, nonce, timestamp + "");
        String mySign = Base64.getEncoder().encodeToString(sha256);
        String url =
                "http://192.168.8.68:18080/delivery/chat/box?accessTagNo=2&Username="+username+"&nonce="+nonce+"" +
                        "&signature="+mySign+"&timestamp="+timestamp+"&openid=1001&phone="+phone+"&driving=0";
        System.out.println("���ڶˣ�" + url);
    }

    private static void getPoliceUrl() {
        String username = "policyApp";
        String password = "a37958a9bcb5d5882884b236680add0a";
        String sendTo = "15588887788";
        String sid = "00GZ896";
        String nonce = "67.63244978920625";
        Instant i1 = Instant.now();
        long timestamp = i1.getEpochSecond();
        byte[] sha256 = Util.digest(password, nonce, timestamp + "");
        String mySign = Base64.getEncoder().encodeToString(sha256);
        String url =
                "http://192.168.8.68:18080/delivery/chat/box?accessTagNo=94411f9cbed64460bfed5b76b7850fcc&Username="+username+"&nonce=" + nonce + "&signature=" + mySign + "&sid="+sid+"&timestamp=" + timestamp + "&sendTo=" + sendTo + "&driving=0";
        System.out.println("�񾯶ˣ�" + url);
    }

    private static void getRgzxUrl() {
        String username = "weixinApp";
        String password = "0ab900cd15d21efa2884b236680add0a";
        String phone = "15555555555";
        String nonce = "67.63244978920625";
        Instant i1 = Instant.now();
        long timestamp = i1.getEpochSecond();
        byte[] sha256 = Util.digest(password, nonce, timestamp + "");
        String mySign = Base64.getEncoder().encodeToString(sha256);
        String url =
                "http://192.168.8.68:18080/delivery/chat/box?accessTagNo=2&Username="+username+"&nonce="+nonce+"" +
                        "&signature="+mySign+"&timestamp="+timestamp+"&phone="+phone;
        System.out.println("ֱ�ӽ������ƽ̨�˹���ϯ��" + url);
    }

    private static void getJxptUrl() {
        String username = "serviceAgent";
        String password = "84dfd583de292d222884b236680add0a";
        String sendTo = "15555555555";
        String sid = "GZS12345789";
        String nonce = "67.63244978920625";
        Instant i1 = Instant.now();
        long timestamp = i1.getEpochSecond();
        byte[] sha256 = Util.digest(password, nonce, timestamp + "");
        String mySign = Base64.getEncoder().encodeToString(sha256);
        //https://ga.bjydzy.com/delivery/chat/box?accessTagNo=2&Username=serviceAgent&timestamp=1624983154
        // &nonce=ikDhcFJHpyL7WjU8QVKSP1TmInXrZ59a&signature=NY5HA5/5kUfc8l8k04fv/Syl3Nh9hpRXMg2C2H1pFaI=&sid=GZS12345789&sendTo=15801542363&driving=0

        String url = "http://192.168.8.68:18080/delivery/chat/box?accessTagNo=2&Username="+username+"&timestamp="+timestamp+"&nonce="+nonce+"&signature="+mySign+"&sid="+sid+"&sendTo="+sendTo+"&driving" +
                "=0";
        System.out.println("ģ�� ����ƽ̨�˹���ϯ�����Ի�:" + url);
    }

    /**
     * �����û���֤��Ϣ����˽��
     * @param object
     * @return
     */
    public JsonObject dealWithAuditResult(JsonObject object) {
        int auditStatus = Util.getElementAsInt(object, "auditStatus", 1);
        JsonObject ans = new JsonObject();
        String updateLogSqlId = "updateUserInfoOperationLog";
        if(auditStatus == 3) { // ���ͨ��, ��Ҫ����user_info, rcs_user, user_info_operation_log
            object.addProperty("enable",1); // �û���Ϊ����״̬
            String updateUserSqlId = "updateUserAuditInfo";
            String updateRcsUserSqlId = "updateRcsUserAuditInfoByPhone";
            StringBuilder sb = new StringBuilder();
            sb.append(XmlSqlGenerator.getSqlByJson(updateLogSqlId, null, object));
            sb.append(XmlSqlGenerator.getSqlByJson(updateUserSqlId,null, object));
            try {
                SqlUtil.updateRecords(ydzyds, sb.toString()); // ����user_info, operation_log
            } catch (SQLException e) {
                e.printStackTrace();
            }
            String sqlstr = XmlSqlGenerator.getSqlByJson(updateRcsUserSqlId, null, object);// object����Ҫphone
            try {
                SqlUtil.updateRecords(ds, sqlstr); // ����rcs_user
            } catch (SQLException e) {
                e.printStackTrace();
            }
            ans.addProperty("result", "���ͨ���ɹ�");
        }else if(auditStatus == 2) { // ��˲���, ֻ�޸�rcs_user_info_operation_log
            String updateLogSql = XmlSqlGenerator.getSqlByJson(updateLogSqlId, null, object);
            try {
                SqlUtil.updateRecords(ydzyds, updateLogSql);  // ������˽������˷��������ʱ��
                ans.addProperty("result", "���سɹ�");
            }catch (Exception e) {
//                e.printStackTrace();
            }
        }
        return ans;
    }
}
