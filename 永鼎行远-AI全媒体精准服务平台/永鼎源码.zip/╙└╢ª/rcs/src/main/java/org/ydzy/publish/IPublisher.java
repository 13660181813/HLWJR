package org.ydzy.publish;

/**
 * �����߽ӿ�
 * @author XFDEP
 *
 */
public interface IPublisher<M> {
	public void publish(SubscribePublish<M> subscribeObj, M message,boolean isInstantMsg);

}
