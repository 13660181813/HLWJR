package org.ydzy.util;


import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import java.time.LocalDateTime;

import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;


public class TimeUtil {
	private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(TimeUtil.class);
	public static final long ONE_HOUR_TIME=3600*1000;
	public static final long ONE_DAY_TIME=ONE_HOUR_TIME*24;
	static final ThreadLocal<Map<String,SimpleDateFormat>> dateFormat = new ThreadLocal<Map<String,SimpleDateFormat>>() {
		@SuppressWarnings("serial")
		@Override
		protected Map<String,SimpleDateFormat> initialValue() {
			return new HashMap<String,SimpleDateFormat>(){
				{
					put("yyyy-MM-dd HH:mm:ss",new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"));
					put("yyyyMMddHHmmss",new SimpleDateFormat("yyyyMMddHHmmss"));
				}
				};
		}
	};
	
	
	
	public static String formatDay(long date,String format)
	{
		try {
			return getThreadLocalSimpleDateFormat(format).format(new Date(date));
		} catch (Exception e) {
			log.error("date format error ",e);
			return "";
		}
	}
	private static SimpleDateFormat  getThreadLocalSimpleDateFormat(String format)
	{
		if(!dateFormat.get().containsKey(format)||dateFormat.get().get(format)==null)
		{
			dateFormat.get().put(format, new SimpleDateFormat(format));
		}
		return dateFormat.get().get(format);
		
	}
	public static String format(long ts) {
		return ts > 0 ? String.valueOf(getThreadLocalSimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date(ts))) : "N/A";
	}
	
	public static long format(String date) {
		try {
			return getThreadLocalSimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(date).getTime();
		} catch (ParseException e) {
			log.error("date format error ",e);
			return 0;
		}
	}

	public static Date format(String date, String pattern) {
		try {
			return getThreadLocalSimpleDateFormat(pattern).parse(date);
		} catch (ParseException e) {
			log.error("date format error ",e);
			return null;
		}
	}

	public static int  formatStep(String format)
	{
		String suffix=format.substring(format.length()-2);
		int step =0;
		switch(suffix)
		{
		
		case "dd":step =3600*24*1000;break;
		case "HH":step=3600*1000;break;
		case "MM":step=3600*1000*24*31;break;
		case "yy":step=3600*1000*24*367;
		default:step=3600*24*1000;;
		}
		return step;
	}
	/**
	 * ת�������ַ���,�����Ժ���(long)��ʾ����ʽ
	 * @param String datestr:�����ַ���
	 * @return long
	 * @throws ParseException
	 */
	public static long convertDate(String datestr) throws ParseException{
		long millis = sdf.parse(fillDate(datestr)).getTime();
		return millis;
	}
	
	
	public static String fillDate(String source){
		if(source.length()<11){source=source+" 00:00:00";}
		else if(source.length()<14){source=source+":00:00";}
		else if(source.length()<18){source=source+":00";}
		return source;
	}
	public static SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	public static SimpleDateFormat sdfday=new SimpleDateFormat("yyyy-MM-dd");
	public static long oneHour = 1000 * 60 * 60;
	public static SimpleDateFormat sdfmon = new SimpleDateFormat("yyyy-MM");
	
	public static String [] fillDefaultTimeRange(String [] params,String autoLoaddays,String autoLoad) {

		if (Util.isNull(params[0]) || Util.isNull(params[1])) {
			
			Date start = new Date();
			Date end=new Date();
			
			
			long s=start.getTime();
			if(!Util.isNull(autoLoaddays)&&"true".equals(autoLoad))
			{
				String [] days=autoLoaddays.split("\\Q|");
				String trunc="0";
				if(days.length>=2)
				{
					if(days.length==3)
						trunc=days[2];
					
					int d=Util.toInt(days[0],0);
					if("day".equals(days[1]))
					{
						s=s-d*3600*24*1000;
						if(trunc.equals("1")) {
							s=s-s%86400000;
							start.setHours(0);
							start.setMinutes(0);
							start.setSeconds(0);
							end.setHours(0);
							end.setMinutes(0);
						      end.setSeconds(0);
						}
						start.setTime(s);
						
					}else if("month".equals(days[1]))
					{
						Calendar cale = Calendar.getInstance();
					    cale.add(Calendar.MONTH,  d*(-1));
					    if(trunc.equals("1"))
					    {
					    	cale.set(Calendar.DAY_OF_MONTH, 1);
					    	cale.set(Calendar.HOUR_OF_DAY,0);
					    	cale.set(Calendar.MINUTE,0);
					    	cale.set(Calendar.SECOND,0);
					    	
						      end.setDate(1);
						      end.setHours(0);
						      end.setMinutes(0);
						      end.setSeconds(0);
					    }
					    start.setTime(cale.getTimeInMillis());
					}
					else if("second".equals(days[1]))
					{
						s=s-d*1000;
						start.setTime(s);
						String snow = TimeUtil.sdf.format(start);
						String endn=TimeUtil.sdf.format(end);
						params[0] = snow  ;
						params[1] = endn  ;
					}else if("minute".equals(days[1]))
					{
						s=s-d*1000*60;
						if(trunc.equals("1")) {
						   s=s-s%60000;
						   end.setSeconds(0);
						}
						start.setTime(s);
						
					}else if("hour".equals(days[1]))
					{
						s=s-d*1000*60*60;
						if(trunc.equals("1")) {
							s=s-s%3600000;
							start.setMinutes(0);
							start.setSeconds(0);
							end.setMinutes(0);
						      end.setSeconds(0);
						}
						start.setTime(s);
					}
					String snow = TimeUtil.sdf.format(start);
					String endn=TimeUtil.sdf.format(end);
					params[0] = snow  ;
					params[1] = endn  ;
				}
			
			}
			else
			{
				String snow = TimeUtil.sdfday.format(start);
				if(Util.isNull(params[0]))
					params[0] = snow + " 00:00:00";
				if(Util.isNull(params[1]))
					params[1] = snow + " 23:59:59";
				
			}
			
		}
//		if (!StringUtils.isNull(tb.getBaseElement(CommonConfigureKeys.TABLE_SHOWTYPE))) {
//			params[0] += " 00:00:00";
//			params[1] += " 23:59:59";
//		}
		if(params[0].length()==10)
			params[0] += " 00:00:00";
		if(params[1].length()==10)
			params[1] += " 23:59:59";
		return params;
	
	}
	public static String formatTime2DDHHMMSS(long ms )
	{
		int ss=1000;
		int mi=ss*60;
		int hh = mi*60;
		int dd=hh*24;
		long day = ms/dd;
		long hour=(ms-day*dd)/hh;
		long minute=(ms-day*dd-hour*hh)/mi;
		long second=(ms-day*dd-hour*hh-minute*mi)/ss;
		if(day>0)
			return day+"��"+hour+"Сʱ"+minute+"����"+second+"��";
		else if(hour>0)
			return hour+"Сʱ"+minute+"����"+second+"��";
		else if(minute>0)
			return minute+"����"+second+"��";
		else
				return second+"��";
	}
    public static String bettween(String start, String end, String format) {
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern(format);
        LocalDateTime day1 = LocalDateTime.parse(start, dateTimeFormatter);
        LocalDateTime day2 = LocalDateTime.parse(end, dateTimeFormatter);
        if (day2.isBefore(day1)) {
            log.info("end time {} must more than start time{}.", start, end);
            return null;
        }
        long days = ChronoUnit.DAYS.between(day1, day2);
        long hours = ChronoUnit.HOURS.between(day1, day2) % 24;
        long minutes = ChronoUnit.MINUTES.between(day1, day2) % 60;
        long seconds = ChronoUnit.SECONDS.between(day1, day2) % 60;
        if (days > 0) {
            return days + "�� " + (hours < 10 ? "0" : "") + hours + ":" + (minutes < 10 ? "0" : "") + minutes + ":" + (seconds < 10 ? "0" : "") + seconds;
        } else if (hours > 0) {
            return hours + ":" + (minutes < 10 ? "0" : "") + minutes + ":" + (seconds < 10 ? "0" : "") + seconds;
        } else if (minutes > 0 || seconds > 0) {
            return (minutes <= 10 ? "0" : "") + minutes + ":" + (seconds < 10 ? "0" : "") + seconds;
        } else if (seconds > 0) {
            return seconds + "��";
        } else {
            return null;
        }
    }

    public static void main(String[] args) {

    }

    public static String Test(String start, String end, String format, boolean chinese) {
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern(format);
        LocalDateTime day1 = LocalDateTime.parse(start, dateTimeFormatter);
        LocalDateTime day2 = LocalDateTime.parse(end, dateTimeFormatter);
        long days = ChronoUnit.DAYS.between(day1, day2);
        char[] hoursChar = new char[2];
        char[] minutesChar = new char[2];
        char[] secondsChar = new char[2];
        long hours = ChronoUnit.HOURS.between(day1, day2) % 24;
        long minutes = ChronoUnit.MINUTES.between(day1, day2) % 60;
        long seconds = ChronoUnit.SECONDS.between(day1, day2) % 60;
        packageCharArray(hoursChar, String.valueOf(hours));
        packageCharArray(minutesChar, String.valueOf(minutes));
        packageCharArray(secondsChar, String.valueOf(seconds));
        StringBuilder sb = new StringBuilder();
        if (days > 0) {
            sb.append(days);
            sb = chinese ? sb.append("�� ") : sb.append(" ");
        }
        //Сʱ
        if (sb.length() > 0) {
            sb.append(hoursChar);
            sb = chinese ? sb.append("ʱ") : sb.append(":");
        } else {
            if (hours > 0) {
                sb.append(hours);
                sb = chinese ? sb.append("ʱ") : sb.append(":");
            }
        }
        //����
        if (sb.length() > 0) {
            sb.append(minutesChar);
            sb = chinese ? sb.append("��") : sb.append(":");
        } else {
            if (minutes > 0) {
                sb.append(minutes);
                sb = chinese ? sb.append("��") : sb.append(":");
            }
        }
        //��
        if (sb.length() > 0) {
            sb.append(secondsChar);
            sb = chinese ? sb.append("��") : sb.append("");
        } else {
            if (seconds > 0) {
                sb.append(seconds);
                sb = chinese ? sb.append("��") : sb.append("");
            }
        }
        return sb.length() > 0 ? sb.toString() : null;
    }

    public static void packageCharArray(char[] chars, String str) {
        int strIndex = str.length() - 1;

        for (int i = chars.length - 1; i >= 0; i--) {
            if (strIndex >= 0) {
                chars[i] = str.charAt(strIndex--);
            } else {
                chars[i] = '0';
            }
        }
    }

}
