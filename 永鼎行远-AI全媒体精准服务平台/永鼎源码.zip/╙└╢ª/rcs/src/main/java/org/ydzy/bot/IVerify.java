package org.ydzy.bot;

public interface IVerify {
	static final String KEY_VERIFY = "bot.verify.";
	static final String KEY_VERIFY_DEFAULT = KEY_VERIFY + "default";
	
	static interface RequestContext{
		String getHeader(String key);
		String getParameter(String key);
	}
	
	/** ��֤����httprequest
	 * ��֤ʧ���׳� VerifyError�쳣
	 * */
	default Object verify(final jakarta.servlet.http.HttpServletRequest request, BotInfo bi) throws VerifyError{
		return verify(new RequestContext() {

			@Override
			public String getHeader(String key) {
				return request.getHeader(key);
			}

			@Override
			public String getParameter(String key) {
				return request.getParameter(key);
			}
		}, bi);
	}
	
	/** ��֤����httprequest
	 * ��֤ʧ���׳� VerifyError�쳣
	 * */
	default Object verify(final javax.servlet.http.HttpServletRequest request, BotInfo bi) throws VerifyError{
		return verify(new RequestContext() {
			@Override
			public String getHeader(String key) {
				return request.getHeader(key);
			}

			@Override
			public String getParameter(String key) {
				return request.getParameter(key);
			}
		}, bi);
	}
	
	Object verify(RequestContext request, BotInfo bi) throws VerifyError;
}
