package org.ydzy.rcs;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.LinkedBlockingQueue;

import com.google.common.collect.Maps;
import org.ydzy.config.ApplicationConfig;
import org.ydzy.handler.impl.ProcessStore;
import org.ydzy.rcs.module.LoadProperties;
import org.ydzy.util.Util;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.inject.Inject;

/**
 * Configuration
 * @author XFDEP
 *
 */
public abstract class RcsConfig {
	public Map<String, List<Map<String, Object>>> getSubscribers() {
		return subscribers;
	}

	public void setSubscribers(Map<String, List<Map<String, Object>>> subscribers) {
		this.subscribers = subscribers;
	}

	static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(RcsConfig.class);
	// �洢suggestType+suggestid, clickAction
	public static Map<String, String> suggestionClickActionMap = Maps.newHashMap();

	public synchronized String chatBotId() {
		String accessNum = LoadProperties.systemProperties.getProperty("csp.tel.accessNumber");
		return accessNum;
	}

	public String[] queryMediaRealAddress(String mediaUrl, boolean raw) {
		return null;
	}

	/**
	 * @param chatbotid chatbotid
	 * @param keywords  ��Ϣ����
	 * @return ��Ϣbody
	 */
	public JsonObject getKeyWordsBysp(String chatbotid,String keywords)
	{
		if(Util.isNull(keywords))
			return null;
		JsonObject spObject=null;
		if(spKeyWords.containsKey(chatbotid))
		{
			spObject=spKeyWords.get(chatbotid);
			if(spObject!=null)
			{
				if(spObject.has(keywords))
				{
					return spObject.getAsJsonObject(keywords);
				}else
				{
					Set<String> keys=spObject.keySet();
					for(String k:keys)
					{
						String kv = spObject.getAsJsonObject(k).get("keywords").getAsString();
						String fuzzy=Util.getElementAsString(spObject.getAsJsonObject(k), "isfuzzy");
						if (!"0".equals(fuzzy)&&(keywords.equalsIgnoreCase(kv) || (keywords.indexOf(kv) > -1 && kv.length()>0)||kv.indexOf(keywords)>-1)) {
							return  spObject.getAsJsonObject(k);
						}
					}
				}
			}
		}
		return null;
	}
	public JsonObject getKeyWordsLikeFilterByRole(String chatbotid,String keywords,String roleName)
	{
		LinkedBlockingQueue<String> configids=null;
		if(!Util.isNull(roleName))
		{
			if(roleConfigs.containsKey(roleName))
			{
				configids=roleConfigs.get(roleName);
			}
		}
		List<JsonObject> eobject=getKeyWordsArrayBysp(chatbotid,keywords);
		JsonObject jo = new JsonObject();
		jo.addProperty("type", "multicard");
		jo.addProperty("spName", chatbotid);
		
		if(eobject!=null   && eobject.size()>1)
		{
//			jo.addProperty("suggestions", "");
			boolean canreturn =false;
			Set<String> addmsgid=new HashSet<String>();
			JsonArray ja = new JsonArray();
			JsonObject contentouterlast=new JsonObject();
			for(int m =0;m<eobject.size();m++)
			{
				JsonObject o=eobject.get(m);
				
					JsonObject contentouter = new JsonObject();
					String keywordst=Util.getElementAsString(o, "keywords");
					JsonElement content =o.get("content");
					String type =Util.getElementAsString(o, "type");
					String configid =Util.getElementAsString(o, "configid");
					String msgid="";
					contentouter.addProperty("configid", configid);	
					if(content!=null && !content.isJsonNull())
					{
						
						if(content.isJsonArray())
						{
							JsonArray array =content.getAsJsonArray();
							if(array!=null && array.size()>0)
							{
								JsonObject j2o=array.get(0).getAsJsonObject();
								String params =Util.getElementAsString(j2o, "params");
								String msg = Util.getElementAsString(j2o,"msg");
								msgid =Util.getElementAsString(j2o, "msgid");
										
								if(Util.isNull(params))
								contentouter.addProperty("msg", msg);
								else {
									contentouter.addProperty("msg", keywordst + "|�鿴" + keywordst + "ģ������||||||");
								}
								contentouter.addProperty("msgid", msgid);

							}
						} else {
							contentouter.addProperty("msg", Util.toString(content));
						}
						String sg = "reply|" + keywordst + "֪ʶ������|#local#" + keywordst;

						if (!Util.isNull(roleName) && (configids != null && configids.size() > 0)) {
							sg += ",reply|����" + keywordst + "|" + keywordst;
						}
						contentouter.addProperty("suggestions", sg);
						contentouter.addProperty("params", "");
						if (!addmsgid.contains(msgid)) {
							if (configids == null || (configids != null && configids.contains(configid))) {
								if (addmsgid.size()<5)
								{
									ja.add(contentouter);
									addmsgid.add(msgid);
								} else {
									contentouterlast.addProperty("msg", "����֪ʶ��|����·����鰴ť�鿴����֪ʶ����||||||");
									String old = Util.getElementAsString(contentouterlast, "suggestions");
									if (!Util.isNull(old))
										old += "," + sg;
									else old = sg;
									contentouterlast.addProperty("suggestions", old);
									addmsgid.add(msgid);
								}
							}
						}
					}
					
				
				
			}
			if(ja.size()>0) {
				if(contentouterlast.size()>0) {
					ja.add(contentouterlast);
					String sg=Util.getElementAsString(jo, "suggestions");
					String keywordst=Util.getElementAsString(contentouterlast, "keywords");
					if(!Util.isNull(roleName) && (configids!=null && configids.size()>0)) {
						if (!Util.isNull(sg))
							sg += ",reply|����" + keywordst + "|" + keywordst;
						else
							sg = ",reply|����" + keywordst + "|"+keywordst;
						jo.addProperty("suggestions", sg);
					}
					
				}
				
			jo.add("content", ja);
			canreturn=true;
			}
			if(canreturn)
			 return jo;
		}else if(eobject!=null   && eobject.size()==1)
		{
			JsonObject jot=eobject.get(0);
			String configid =Util.getElementAsString(jot, "configid");
			if(configids==null|| ( configids!=null   && configids.contains(configid))  ) 		
			return jot;
		}
		return null;
	
	
	}
	
	public JsonObject getDefaultElement(String chatbotid,String msg,String sms)
	{
		JsonObject jo = new JsonObject();
		jo.addProperty("type", "singlecard");
		jo.addProperty("spName", chatbotid);
		jo.addProperty("suggestions", "");
		JsonArray ja = new JsonArray();
		JsonObject content = new JsonObject();
		content.addProperty("msg", msg);
		content.addProperty("smsContent", sms);
		content.addProperty("suggestions", "");
		content.addProperty("params", "");
		ja.add(content);
		jo.add("content", ja);
		return jo;
	}
	public JsonObject getKeyWordsLike(String chatbotid,String keywords)
	{
		return getKeyWordsLikeFilterByRole(chatbotid,keywords,null);
	}
	public List<JsonObject> getKeyWordsArrayBysp(String chatbotid,String keywords)
	{
		if(Util.isNull(keywords))
			return null;
		List<JsonObject> results =new ArrayList<JsonObject>();
		JsonObject spObject=null;
		if(spKeyWords.containsKey(chatbotid))
		{
			spObject=spKeyWords.get(chatbotid);
			if(spObject!=null)
			{
				if(spObject.has(keywords))
				{
					 JsonObject jtmp= spObject.getAsJsonObject(keywords);
					 if(!results.contains(jtmp))
					results.add(jtmp);
				}else
				{
					Set<String> keys=spObject.keySet();
					for(String k:keys)
					{
						String kv = spObject.getAsJsonObject(k).get("keywords").getAsString();
						String fuzzy=Util.getElementAsString(spObject.getAsJsonObject(k), "isfuzzy");
						if (!"0".equals(fuzzy)&&(keywords.equalsIgnoreCase(kv) || (keywords.indexOf(kv) > -1 && kv.length()>0)||kv.indexOf(keywords)>-1)) {
							 JsonObject jtmp=spObject.getAsJsonObject(k);
							 if(!results.contains(jtmp))
							results.add(jtmp);
						}
					}
				}
			}
		}
		return results;
	}

	/**
	 * @param chatbotid chatbotid
	 * @param keywords ��Ϣ����
	 * @return ��Ϣbody
	 */
	public JsonObject getKeyWordsByspExtract(String chatbotid,String keywords)
	{
		if(Util.isNull(keywords))
			return null;
		JsonObject spObject=null;
		if(spKeyWords.containsKey(chatbotid))
		{
			spObject=spKeyWords.get(chatbotid);
			if(spObject!=null)
			{
				if(spObject.has(keywords))
				{
					return spObject.getAsJsonObject(keywords);
				}
			}
		}
		return null;
	}

	/**
	 * �ؼ���ģ��ƥ��
	 * @param chatbotid
	 * @param keywords
	 * @return
	 */
	public JsonObject getKeyWordsByspExtractFuzzy(String chatbotid,String keywords) {
		JsonObject object = new JsonObject();
		JsonArray keyArray = new JsonArray(); //�ؼ���
		JsonArray contentArray = new JsonArray(); //����
		JsonArray sugArray = new JsonArray(); //�˵�
		JsonArray footSugArray = new JsonArray(); //�ײ�����
		object.add("keywords", keyArray);
		object.add("content", contentArray);
		object.add("menu", sugArray);
		object.add("suggestion", footSugArray);
		if (Util.isNull(keywords))
			return object;
		Set<String> allKeyowrds = new HashSet<>();
		JsonObject spObject = null;
		boolean noSearch = false;
		if (spKeyWords.containsKey(chatbotid)) {
			spObject = spKeyWords.get(chatbotid);
			if (spObject != null) {
				Set<String> keys = spObject.keySet();
				for (String s : keys) {
					if (allKeyowrds.contains(s))
						continue;
					String kw = spObject.get(s).getAsJsonObject().get("keywords") == null ? "" : spObject.get(s).getAsJsonObject().get("keywords").getAsString();
					if (allKeyowrds.contains(kw))
						continue;
					// �ؼ���
					if (s.contains(keywords)) {
						keyArray.add(spObject.get(s));
						allKeyowrds.add(s);
						noSearch = true;
						continue;
					}
					// ����
					JsonElement content = spObject.get(s).getAsJsonObject().get("content");
					if (content != null && content.toString().contains(keywords)) {
						contentArray.add(spObject.get(s));
						allKeyowrds.add(s);
						noSearch = true;
						continue;
					}
					// �˵�
					JsonElement menus = spObject.get(s).getAsJsonObject().get("allsuggestions");
					if (menus != null && menus.toString().contains(keywords)) {
						sugArray.add(spObject.get(s));
						allKeyowrds.add(s);
						noSearch = true;
						continue;
					}
					// �ײ�����
					JsonElement suggestions = spObject.get(s).getAsJsonObject().get("allrelationName");
					if (suggestions != null && suggestions.toString().contains(keywords)) {
						footSugArray.add(spObject.get(s));
						allKeyowrds.add(s);
						noSearch = true;
					}
				}

				/*
				if(spObject.has(keywords))
				{
					spObject.getAsJsonObject(keywords);
					return null;
				}
				 */
			}
		}
		return !noSearch ? null : object;
	}
	public void reloadThread() {
		Thread reloadThread=new Thread() {
			public void run()
			{
				while(true)
				{
					log.info("reloading");
					reload();
					log.info(" reloadend");
					try {
						Thread.sleep(60*10*1000L);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
			}
		};
		reloadThread.setName("ConfigReloadThread");
		reloadThread.setDaemon(true);
		reloadThread.start();
	}
	@Inject
	public ApplicationConfig applicationConfig;
	/**
	 * AI����
	 */
	protected  IAIRobot robot=null;
	public IAIRobot getRobot() {
		return robot;
	}
	@Inject
	public void setRobot(IAIRobot robot) {
		this.robot = robot;
	}

	private RcsContainer container = null;
	@Inject
	public void setContainer(RcsContainer container) {
		this.container = container;
		//���ڼ������ģ����Ҫ�õ�container����,������ﴥ��һ�����¼���
		rcsConfig2SpMap();
	}
	public RcsContainer getContainer() {
		return container;
	}

	private ProcessStore processStore;
	public ProcessStore getProcessStore() {
		return processStore;
	}
	public void setProcessStore(ProcessStore processStore) {
		this.processStore = processStore;
	}

	public Map<String,List<Map<String,Object>>> modelParams=new ConcurrentHashMap<String, List<Map<String,Object>>>();
	/**
	 * �����б�
	 */
	protected  Map<String,Map<String,Integer>> AiMap=new ConcurrentHashMap<String,Map<String,Integer>>();

	/**
	 * �����б�
	 */
	protected Map<String,List<Map<String,Object>>> subscribers=new ConcurrentHashMap<String, List<Map<String,Object>>>();


	/**
	 * chatbotinfos
	 */
	protected  volatile Map<String, JsonObject> chatbotInfo=new ConcurrentHashMap<String,JsonObject>();
	protected  JsonArray rcsConfig=new JsonArray();

	public void reload()
	{
		this.load();
		this.rcsConfig2SpMap();
	}

	public RcsConfig()
	{
		reload();
		reloadThread();
	}
	protected Map<String,JsonObject> spKeyWords=new ConcurrentHashMap<String,JsonObject>();
	protected Map<String,LinkedBlockingQueue<String>> roleConfigs=new ConcurrentHashMap<String, LinkedBlockingQueue<String>>();
	public abstract void load();
	public Map<String, JsonObject> getChatbotInfo() {
		return chatbotInfo;
	}
	public void setChatbotInfo(Map<String, JsonObject> chatbotInfo) {
		this.chatbotInfo = chatbotInfo;
	}
	public JsonArray getRcsConfig() {
		return rcsConfig;
	}
	public void setRcsConfig(JsonArray rcsConfig) {
		this.rcsConfig = rcsConfig;
	}

	public  String enterpriseProperty(String spName, String name) {
		if (chatbotInfo!=null &&!Util.isNull(spName) && chatbotInfo.containsKey(spName)  && chatbotInfo.get(spName)!=null && chatbotInfo.get(spName).has(name)) {
			return  Util.getElementAsString(chatbotInfo.get(spName),name);
		}
		return "";
	}
	public Map<String, Map<String,Integer>> getAiMap() {
		return AiMap;
	}
	public void setAiMap(Map<String, Map<String,Integer>> aiMap) {
		AiMap = aiMap;
	}


	/**
	 * ͷ��
	 * */
	protected  Map<String,String> avatarCompany = new HashMap<String,String>();
	protected  Map<String,String> avatarUser = new HashMap<String,String>();

	public String getAvatar(String company, String phone) {
		String avatar = "/{webPath}/dialog/static/img/user.png";//Ĭ��ͷ�����ȼ����
		if (!Util.isNull(company)) {
			if (avatarCompany.containsKey(company)) {
				//������ͷ�����ȼ��Ը�
				avatar = avatarCompany.get(company);
			}
			if (company.equals("weixinMP") || company.equals("weixinApp")) {
				//��������ڣ������ڵ�ͷ�����ȼ����
				if (avatarUser.containsKey(phone)) {
					avatar = avatarUser.get(phone);
				}
			}
		}
		return avatar;
	}

	/**
	 * keywords  convert to hashMap key is chatbotName value is keywords,bodys
	 */
	protected void rcsConfig2SpMap()
	{
		if(rcsConfig!=null)
		{
			Map<String,JsonObject> spKeyWordsTemp=new ConcurrentHashMap<String,JsonObject>();
			Map<String,IMsgProvidor> foriegnTemplate=new ConcurrentHashMap<String,IMsgProvidor>();
			for (JsonElement e : rcsConfig) {
				JsonObject eobject = JsonParser.parseString(e.getAsString()).getAsJsonObject();
				String keywords = Util.getElementAsString(eobject,"keywords");
				String configid = Util.getElementAsString(eobject,"configid");
				String spName = Util.getElementAsString(eobject,"chatbotIdenty");
//				String chatbotid=eobject.get("").getAsString();
				String recompute=Util.getElementAsString(eobject, "recompute");
				

				if("1".equals(recompute))
				{
					keywords=keywords.replace("|"+spName, "");
				}
				JsonObject spObject = null;
				if (spKeyWordsTemp.containsKey(spName)) {
					spObject = spKeyWordsTemp.get(spName);
				} else {
					spObject = new JsonObject();
					spKeyWordsTemp.put(spName, spObject);
				}
				spObject.add(keywords, eobject);
				spObject.add(configid, eobject);

				// �ж��Ƿ�ʱ���ģ��
				try {
					IMsgProvidor mp = foriegnTemplate.get(spName);
					if (mp == null && getContainer() != null) {
						mp = new MsgProvidorForeignTemplate(spName);
						getContainer().injectObject(mp);
						foriegnTemplate.put(spName, mp);
					}
					if (mp != null && mp.checkAddConfig(eobject)) continue;
				} catch (Exception ex) {
					log.warn("Error, create foreign template object(MsgProvidorForeignTemplate)", ex);
				}

			}
			spKeyWords = spKeyWordsTemp;
			this.foreignTemplates = foriegnTemplate;
		}
		for (String k : spKeyWords.keySet()) {
			log.info("{} has KeyWords records {} ", k, spKeyWords.get(k).size());
		}
//		spKeyWords.put("kdzj", contentobject);
	}

	/**
	 * chatbot-���ģ��
	 */
	protected Map<String, IMsgProvidor> foreignTemplates = new ConcurrentHashMap<String, IMsgProvidor>();

	/***
	 * ��ȡchatbot�����ģ�嶨��
	 * @param chatbotid
	 * @return
	 */
	public IMsgProvidor getForeignTemplates(String chatbotid) {
		return foreignTemplates.get(chatbotid);
	}
	
}
