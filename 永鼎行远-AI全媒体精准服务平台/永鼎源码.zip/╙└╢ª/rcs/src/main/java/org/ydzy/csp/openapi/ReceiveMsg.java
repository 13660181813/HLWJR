package org.ydzy.csp.openapi;

import java.io.IOException;
import java.nio.charset.Charset;
import java.util.Base64;

import org.ydzy.handler.BaseHandler;
import org.ydzy.handler.BaseRcsContext;
import org.ydzy.handler.RcsSession;
import org.ydzy.publish.ConstantTopics;
import org.ydzy.publish.IPublisher;
import org.ydzy.publish.SubscribeCaches;
import org.ydzy.publish.SubscribePublish;
import org.ydzy.rcs.BodyTransform;
import org.ydzy.rcs.action.RcsLogAction;
import org.ydzy.rcs.action.RcsRunLogAction;
import org.ydzy.rcs.entity.ReceiveEntity;
import org.ydzy.rcs.module.LoadProperties;
import org.ydzy.thirdparty.util.MsgUtils;
import org.ydzy.util.StreamsUtil;
import org.ydzy.util.Util;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.inject.Inject;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class ReceiveMsg extends BaseHandler {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Inject
	SubscribeCaches subscribeCaches;
	@Inject
	RcsLogAction rcsLogAction = null;
	@Inject
	protected MsgUtils msgUtil;
	@Override
	public void handle(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		BaseRcsContext context = getContextProvidor().newBaseRcsContext();
		
		long startTime = System.currentTimeMillis();
		String body = StreamsUtil.copyToString(request.getInputStream(), Charset.forName("UTF-8"));
		String remoteAddr=getIpAddress(request);	
		
		JsonElement eObject=JsonParser.parseString(body);
		
		String status="200";
		String message="sucess";
		BodyTransform transform=null;
		JsonObject eobject =eObject.getAsJsonObject();
		String sender=Util.getElementAsString(eobject, "senderAddress");
		String sendto=Util.getElementAsString(eobject, "sendTo");
		if(!sender.startsWith("YDXY")&&!Util.isNull(sendto))
			eobject.addProperty("senderAddress", sender+"_"+sendto);
		try {
			String userName = request.getHeader("Username");
			String chatbotId = msgUtil.chatbotId(userName);
			eobject.addProperty("Username", userName);
			eobject.addProperty("userName", userName);
			context.getSession(userName + "_" + sender + "_" + sendto).put("chatbotid", chatbotId);

			transform = new BodyTransform(eobject, request, context);
			ReceiveEntity entity = transform.receiveEntity;
			entity.getAnswersObject().put("reallysid", sender);
			String weburl = request.getHeader("weburl");
			if (!Util.isNull(weburl)) {
				entity.getAnswersObject().put("weburl", weburl + "/" + Util.toString(LoadProperties.systemProperties.get("publicenv.webPath")));
				entity.getAnswersObject().put("webapiurl", weburl + "/" + Util.toString(LoadProperties.systemProperties.get("publicenv.apiPath")));
			}
//			String nick=URLDecoder.decode(request.getHeader("nick"),"UTF-8");//"iso-8859-1"
			String nickraw = request.getHeader("nick");
			String nick = "";
			try {
				nick = Util.isNull(nickraw) ? "" : new String(Base64.getDecoder().decode(request.getHeader("nick")), "UTF-8");
			} catch (Exception e) {
				e.printStackTrace();
			}
			String sid = Util.toString(entity.getAnswersObject().get("sid"));
			RcsSession session = context.getSession(sid);
			session.put("userName", userName);
			String oldnick=Util.toString(session.get("nick"));
			if(Util.isNull(nick))
				nick=oldnick;
			if(Util.isNull(nick))
				nick="����";
			entity.getAnswersObject().put("police_nick", nick);
			session.put("nick", nick);
			
			if (!Util.isNull(sendto)) {
				RcsSession targetSession = context.getSession(sendto, chatbotId);
				targetSession.put("police_nick", nick);
			}
			
			String policePhone=request.getHeader("mdn");
//			entity.getAnswersObject().put("police_target_phone",policePhone);
			if(!Util.isNull(policePhone))
			session.put("police_target_phone",policePhone);
			
			entity.setChatBotId(chatbotId);
			String sendTo=entity.sendTo;
			RcsSession targetsession=context.getSession(entity.sendTo, chatbotId);
			
			if(!Util.isNull(policePhone))
			targetsession.put("police_target_phone", policePhone);
			SubscribePublish sub=subscribeCaches.getSubscribePublishInstance(ConstantTopics.CHARTBOT_MSG_RECEIVE+userName);
			IPublisher<ReceiveEntity> publishObj =new IPublisher<ReceiveEntity>() {
				@Override
				public void publish(SubscribePublish subscribeObj, ReceiveEntity message, boolean isInstantMsg) {
					subscribeObj.publish(ConstantTopics.CHARTBOT_MSG_RECEIVE+userName+"_Subscribers", message, isInstantMsg);
				}};
			publishObj.publish(sub, transform.receiveEntity, false);
		} catch (Exception e) {
			e.printStackTrace();
			status="500";
			message="parse error !"+e;
		}
		String content2 = resBodyJson(status, message, null);
		sendResponse(remoteAddr, content2, HttpServletResponse.SC_OK, request, response);
		if(ds!=null)
		{
			RcsRunLogAction.recordLog("reponse sucess!","reqbody:"+body+" ; resbody :"+content2, remoteAddr, "200", "ReceiveMsg", ds);
		}
		if(rcsLogAction!=null) {
			long endTime = System.currentTimeMillis();
			int delayMs = (int)(endTime-startTime);
			if(transform!=null)
			rcsLogAction.log( request, response, body, transform, delayMs, true);
		}
	}
	

}
