package org.ydzy.util.crypto;

/**
 * @author zxw
 * @create 2021/11/30
 */
public interface ICipherEncrypt<E extends Enum<?>> {
    String encryptBase64(String content) throws Exception;

    String decryptBase64(String content) throws Exception;

    /**
     * @param content   ����������
     * @param slatKey   ��Կkey
     * @param vectorKey ƫ����key
     * @return ���ܺ������
     * @throws Exception
     */
    String encryptBase64(String content, String slatKey, String vectorKey) throws Exception;

    /**
     * @param content   ����������
     * @param slatKey   ������Կ
     * @param vectorKey ��������
     * @return ���ܺ������
     * @throws Exception
     */
    String decryptBase64(String content, String slatKey, String vectorKey) throws Exception;

    /**
     * @param content
     * @param encryptType
     * @return
     * @throws Exception
     */
    String encryptBase64(String content, E encryptType) throws Exception;

    /**
     * @param content
     * @param encryptType
     * @return
     * @throws Exception
     */
    String decryptBase64(String content, E encryptType) throws Exception;

    String encryptBase64(String content, String slatKey, String vectorKey, E encryptType) throws Exception;

    String decryptBase64(String content, String slatKey, String vectorKey, E encryptType) throws Exception;


    /**
     * @param content
     * @return
     * @throws Exception
     */
    String encryptHex(String content) throws Exception;

    String decryptHex(String content) throws Exception;

    String encryptHex(String content, String slatKey, String vectorKey) throws Exception;

    String decryptHex(String content, String slatKey, String vectorKey) throws Exception;

    String encryptHex(String content, E encryptType) throws Exception;

    String decryptHex(String content, E encryptType) throws Exception;

    String encryptHex(String content, String slatKey, String vectorKey, E encryptType) throws Exception;

    String decryptHex(String content, String slatKey, String vectorKey, E encryptType) throws Exception;
}
