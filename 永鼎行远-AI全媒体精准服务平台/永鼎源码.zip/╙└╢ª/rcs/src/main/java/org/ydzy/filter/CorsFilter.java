package org.ydzy.filter;

import jakarta.servlet.*;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.List;

import org.ydzy.rcs.module.LoadProperties;
import org.ydzy.util.Util;

/**
 * @author lirui
 * @Date 2021/3/19 3:59 ����
 */
public class CorsFilter implements Filter {
	private List<String> allow_origns;
    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain filterChain) throws IOException, ServletException {
        if(response instanceof HttpServletResponse){
            HttpServletResponse alteredResponse = ((HttpServletResponse)response);
            addCorsHeader(alteredResponse,request);
        }
        filterChain.doFilter(request, response);
        
    }

    private void addCorsHeader(HttpServletResponse response,ServletRequest request){
    	if(allow_origns==null)
    	{
    		String tmp=LoadProperties.systemProperties.getProperty("allow-Origin");
    		if(!Util.isNull(tmp))
    		allow_origns=java.util.Arrays.asList(tmp.split(","));
    	}
    	String host= ((HttpServletRequest)request).getHeader("Host") ;
		String allow_o = host;
		if (allow_origns != null && allow_origns.size() > 0) {
			String origin = ((HttpServletRequest) request).getHeader("Origin");
			if (!Util.isNull(origin) && !Util.isNull(host) && !host.equals(origin)) {
				for (String s : allow_origns) {
					if (origin.indexOf(s) > -1) {
						allow_o = origin;
						break;
					}
				}
			}

		}
		response.addHeader("Access-Control-Expose-Headers", "Access-Token,Cookie,Set-Cookie, Vary,Access-Control-Allow-Credentials,Access-Control-Allow-Origin,Authorization,Content-Type,query,position,weburl");
//        response.addHeader("Access-Control-Allow-Origin", "http://127.0.0.1:18080");
		response.addHeader("Access-Control-Allow-Origin", allow_o);
		response.addHeader("access-control-allow-headers", "username ,logintype ,content-security-policy, access-control-allow-headers, access-control-allow-methods,access-control-expose-headers," +
				"X-PINGOTHER, Cookie,Set-Cookie, Vary,Access-Control-Allow-Credentials,Access-Control-Allow-Origin,Authorization,Content-Type,query,position,weburl,nonce,sid,signature,timestamp");
		response.addHeader("Access-Control-Allow-Methods", "POST, GET, OPTIONS, PUT, DELETE, HEAD");
		response.addHeader("Access-Control-Max-Age", "1728000");
		response.addHeader("Access-Control-Allow-Credentials", "true");
	}

}
