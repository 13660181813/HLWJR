package org.ydzy.bot;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.time.temporal.ChronoField;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.concurrent.Callable;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.ydzy.handler.BaseRcsContext;
import org.ydzy.handler.BaseRcsContextProvidor;
import org.ydzy.publish.ISubscriber;
import org.ydzy.publish.SubscribePublish;
import org.ydzy.rcs.action.MsgPushStrategyAction;
import org.ydzy.rcs.entity.ReceiveEntity;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.inject.Inject;
import com.google.inject.name.Named;

public class MsgPushManager implements ISubscriber<String>{
	static final Logger log = LoggerFactory.getLogger(MsgPushManager.class);
	
	@Inject
	protected BotManager manager;
	/** ���ݿ�����*/
	@Inject
	@Named("rcsDb")
	private DataSource dataSource;
	public DataSource getDataSource() {
		return dataSource;
	}

	/** ��Ϣ���Բ������� */
    @Inject
    MsgPushStrategyAction msgPushStrategyAction;
    
	/***
	 * Context�����ṩ��
	 */
	@Inject
	private BaseRcsContextProvidor contextProvidor;
	public BaseRcsContextProvidor getContextProvidor() {
		return contextProvidor;
	}
    
    /** ��Ϣ�ַ��Ƿ��Ƿ����� */
	@Inject(optional = true)
	@Named("bot.msg.push.enable")
	private boolean enable = false;
	public boolean isEnable() {
		return enable;
	}
	
	static DateTimeFormatter DB_DATE_TIME = new DateTimeFormatterBuilder()
            .parseCaseInsensitive()
            .append(DateTimeFormatter.ISO_LOCAL_DATE)
            .appendLiteral(' ')
            .append(DateTimeFormatter.ISO_LOCAL_TIME)
            .toFormatter();
	
	protected List<PushBean> loadBeans(){
		List<PushBean> list = new ArrayList<>();
		JsonObject para = new JsonObject();
		JsonArray ja = msgPushStrategyAction.queryMsgPush(para);
		for(int i=0;i<ja.size();i++) try{
			String tmp;
			JsonObject obj = ja.get(i).getAsJsonObject();
			PushBean bean = new PushBean();
			bean.id  = BotUtil.getElementAsInt(obj, "id", -1);
			bean.chatbotid = BotUtil.getElementAsString(obj, "chatbotid");
			bean.crontab = BotUtil.getElementAsString(obj, "crontab");
			tmp = BotUtil.getElementAsString(obj, "type");
			bean.type = ScheduleType.valueOf(tmp);
			tmp = BotUtil.getElementAsString(obj, "enable");
			bean.enable = tmp!=null&&tmp.length()>0?tmp.charAt(0):'0';
			tmp = BotUtil.getElementAsString(obj, "mdate");
			bean.mdate = DB_DATE_TIME.parse(tmp, LocalDateTime::from);
			bean.type.parse(bean);
			
			JsonArray jaTmp;
			JsonObject joTmp;
			Set<String> keywords = new TreeSet<>();
			jaTmp = obj.getAsJsonArray("configtagIds");
			if(jaTmp!=null) {
				for(int j=0;j<jaTmp.size();j++) {
					joTmp = jaTmp.get(j).getAsJsonObject();
					keywords.add(BotUtil.getElementAsString(joTmp, "keywords"));
					if(joTmp.getAsJsonArray("keywordsList")!=null) {
						joTmp.getAsJsonArray("keywordsList").forEach(e -> keywords.add(e.getAsString()));
					}
				}
			}
			jaTmp = obj.getAsJsonArray("configIds");
			if(jaTmp!=null) {
				for(int j=0;j<jaTmp.size();j++) {
					joTmp = jaTmp.get(j).getAsJsonObject();
					keywords.add(BotUtil.getElementAsString(joTmp, "keywords"));
				}
			}
			bean.keywords = keywords;
			
			Set<String> phones = new TreeSet<>();
			jaTmp = obj.getAsJsonArray("usertagIds");
			if(jaTmp!=null) {
				for(int j=0;j<jaTmp.size();j++) {
					joTmp = jaTmp.get(j).getAsJsonObject();
					phones.add(BotUtil.getElementAsString(joTmp, "phone"));
					if(joTmp.getAsJsonArray("phoneList")!=null) {
						joTmp.getAsJsonArray("phoneList").forEach(e -> phones.add(e.getAsString()));
					}
				}
			}
			jaTmp = obj.getAsJsonArray("userIds");
			if(jaTmp!=null) {
				for(int j=0;j<jaTmp.size();j++) {
					joTmp = jaTmp.get(j).getAsJsonObject();
					phones.add(BotUtil.getElementAsString(joTmp, "phone"));
				}
			}
			bean.users = phones;
			
			list.add(bean);
		}catch(Exception e) {
			log.warn("Load msg push config error(" + e.getMessage() + ")",e);
		}

		log.info(list.size() + "'s msg push loaded form " + ja.size() + "'s db config!");
		return list;
	}

	private Map<Integer, PushBean> currentBeans = new ConcurrentHashMap<>();
	private Map<PushBean, LocalDateTime> scheduleBeans = new ConcurrentHashMap<>();
	protected boolean scheduleAt(final PushBean bean, final LocalDateTime runTime) {
		if(bean==null || runTime==null || bean.enable!='1' 
				|| bean.keywords==null || bean.keywords.isEmpty()	//û���زĹؼ���
				|| bean.users==null || bean.users.isEmpty()			//û��Ŀ���û�
				) return false;

		Callable<Boolean> caller = ()->{
			if(!currentBeans.containsValue(bean))return false;
			BotInfo bi = manager.getChatBotInfo(bean.chatbotid);
			String chatbotid = bi.getChatbotIdenty();
			int count = 0;
			for(String keyword:bean.keywords) {
				JsonObject msgJo = manager.getConfig().getKeyWordsByspExtract(chatbotid, keyword);
				if(msgJo==null)log.debug("Not found msg{} in chatbot config, skiped!", keyword, chatbotid);
				if(msgJo!=null && bi!=null) {
					for(String e:bean.users) {
						log.info("Sending msg(" + keyword + ") to user(" + e + ")...");
						ReceiveEntity message = new ReceiveEntity();
						message.setDestinationAddress(e);
						message.setSenderAddress(bi.getChatbotIdenty());
						message.getAnswersObject().put("elementFind", msgJo);
						message.getAnswersObject().put("keywords", keyword);
						message.setMdn(e);
						message.sendTo = e;
						
						message.setContent(keyword);
						message.getAnswersObject().put("boxId", "system");
						message.getAnswersObject().remove("userName");
						message.getAnswersObject().put("nick", "������");
						message.getAnswersObject().put("type", "accept");
						message.setChatBotId(chatbotid);
						
						BaseRcsContext context = getContextProvidor().newBaseRcsContext();
						context.getSession(e, bi.chatbotId);
						if(bi.getBotAccess().cspUnSendMsg(bi, message, context))count++;
					}
				}
			}
			LocalDateTime nextTime = bean.type.getNext(bean, runTime);
			if(nextTime!=null) {
				scheduleAt(bean, nextTime);
			}
			return count>0;
		};
		LocalDateTime time = LocalDateTime.now();
		long diff = time.until(runTime, ChronoUnit.SECONDS);
		if(diff<30)diff = 0;
		if(diff>=0) {
			scheduleBeans.put(bean, runTime);
			manager.getExecutor().schedule(caller, diff, TimeUnit.SECONDS);
			log.debug("Scheduling " + bean + " run @ " + runTime);
		}
		return true;
	}
	
	/** �Զ�ˢ������ */
	ScheduledFuture<?> autoRefresh;
	/** �Զ�ˢ������ */
	ScheduledFuture<?> deleteInvalidConfig;
	/** ��Ϣ�ַ��Զ��������� */
	@Inject(optional = true)
	@Named("bot.msg.push.load.interval")
	protected int msgPushLoadInterval = 120;
	public boolean loadFromDb() {
		if(deleteInvalidConfig==null) {
			deleteInvalidConfig = manager.getExecutor().scheduleAtFixedRate(msgPushStrategyAction::deleteInvalidMsgPush, 120, 3600, TimeUnit.SECONDS);
		}
		if(autoRefresh!=null) {
			autoRefresh.cancel(enable);
			autoRefresh = null;
		}
		try {
			List<PushBean> list = loadBeans();
			if(list==null || list.isEmpty())return false;
			List<PushBean> newList = new ArrayList<>(list);
			List<PushBean> updList = new ArrayList<>();
			HashMap<Integer, PushBean> tmpMap = new HashMap<>();
			if(currentBeans!=null||currentBeans.isEmpty()) {
				tmpMap.putAll(currentBeans);
				Iterator<PushBean> it = newList.iterator();
				while(it.hasNext()) {
					PushBean e = it.next();
					PushBean o = tmpMap.remove(e.id);
					if(o!=null) {
						if(!e.equals(o)) {
							updList.add(e);
						}
						it.remove();
					}
				}
			}
			if(newList.isEmpty() && updList.isEmpty() && tmpMap.isEmpty()) {
				log.debug("No new msg push config infos from {}'s db record", list.size());
				return false;
			}
			log.info("Found {}'s new, {}'s updated and {}'s tobe delete from {}'s db msg push config infos!" , newList.size(), updList.size(), tmpMap.size(), list.size());
			
			currentBeans.clear();
			scheduleBeans.clear();
			list.forEach(e -> currentBeans.put(e.id, e));
			if(list!=null) {
				LocalDateTime time = LocalDateTime.now();
				long count = list.stream()
						.filter((e) -> scheduleAt(e,e.type.getFirst(e, time)))
						.count();
				log.info("{}'s push task scheduled!", count);
			}
			return true;
		}finally {
			try {
				autoRefresh = manager.getExecutor().schedule(this::loadFromDb, msgPushLoadInterval, TimeUnit.SECONDS);
			}catch(Throwable t) {
				log.warn("Schedule auto load msgPush error",t);
			}
		}
	}
	
	/** �յ��޸�׃����Ϣ  */
	@Override
	public void update(String publisher, String message) {
		try {
			int pushid = Integer.parseInt(message);
			if("insert".equalsIgnoreCase(publisher) || "edit".equalsIgnoreCase(publisher)) {
				if(pushid>0) {
					//���Ծ�׼����
				}
			}
			this.loadFromDb();
		}catch(Exception e) {
			
		}
	}

	@Override
	public void subscribe(SubscribePublish<String> subscribePulish) {
		subscribePulish.subcribe(this);
	}

	@Override
	public void unSubscribe(SubscribePublish<String> subscribePulish) {
		subscribePulish.unSubcribe(this);
	}
	
	static class PushBean{
		int id;
		String chatbotid;
		
		int configid;
		
		Collection<String> keywords;
		
		/** 1�����Σ�single 2�����ڣ�cycle  3��ÿ�ܼ�:week 4��ÿ��n��:month */
		ScheduleType type;	//varchar(20) NULL
		
		/** 1������ 2021-06-20 10:00 2��ÿ��n�� n/12:00(��ʼʱ��Ϊmdate) 3��ÿ��n/12:00 */
		String crontab;
		
		LocalDateTime mdate;
		/** �Ƿ����� 0:�� 1:�� */
		char enable;	
		
		/** �������б� */
		Collection<String> users;
		
		/** ѭ�h����ʱ�䲿�� */
		transient LocalDateTime crontabDate;
		/** ѭ������ֵ */
		transient List<Integer> crontabCycle = java.util.Arrays.asList(1);
		
		@Override
		public String toString() {
			return "MsgPush(id=" + id + " keyworks=" + keywords + ")";
		}
		
		transient String json;
		
		@Override
		public int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime * result + ((chatbotid == null) ? 0 : chatbotid.hashCode());
			result = prime * result + configid;
			result = prime * result + ((crontab == null) ? 0 : crontab.hashCode());
			result = prime * result + enable;
			result = prime * result + id;
			result = prime * result + ((keywords == null) ? 0 : keywords.hashCode());
			result = prime * result + ((mdate == null) ? 0 : mdate.hashCode());
			result = prime * result + ((type == null) ? 0 : type.hashCode());
			result = prime * result + ((users == null) ? 0 : users.hashCode());
			return result;
		}
		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			PushBean other = (PushBean) obj;
			if (chatbotid == null) {
				if (other.chatbotid != null)
					return false;
			} else if (!chatbotid.equals(other.chatbotid))
				return false;
			if (configid != other.configid)
				return false;
			if (crontab == null) {
				if (other.crontab != null)
					return false;
			} else if (!crontab.equals(other.crontab))
				return false;
			if (enable != other.enable)
				return false;
			if (id != other.id)
				return false;
			if (keywords == null) {
				if (other.keywords != null)
					return false;
			} else if (!keywords.equals(other.keywords))
				return false;
			if (mdate == null) {
				if (other.mdate != null)
					return false;
			} else if (!mdate.equals(other.mdate))
				return false;
			if (type != other.type)
				return false;
			if (users == null) {
				if (other.users != null)
					return false;
			} else if (!users.equals(other.users))
				return false;
			return true;
		}
		
		
	}


	/**
	 * �����������Ͷ���
	 * @author ljp
	 *
	 */
	static enum ScheduleType{
		single{
			@Override
			public boolean parse(PushBean bean) {
				//ÿ��n�� ÿ��n n/12:00
				bean.crontabDate = DB_DATE_TIME.parse(bean.crontab, LocalDateTime::from);
				return true;
			}
			@Override
			public LocalDateTime getFirst(PushBean bean, LocalDateTime currentTime) {
				LocalDateTime time = bean.crontabDate;
				if(time.isBefore(currentTime)) {
					// ���ʱ���Ѿ���ȥ����2Сʱ, ��������
					if(time.until(currentTime, ChronoUnit.HOURS)>2) {
						return null;
					}
					time = currentTime;
				}
				return time;
			}
		},
		cycle{
			@Override
			protected LocalDateTime next(LocalDateTime currentTime,int crontabCycle) {
				return currentTime.plusDays(crontabCycle);
			}
		},
		week{
			@Override
			protected int getOffset(LocalDateTime currentTime) {
				return (int)currentTime.getLong(ChronoField.DAY_OF_WEEK);
			}
			
			@Override
			protected int checkCrontabCycle(int n) {
				if(n>6)n=6;
				if(n<-6)n=-6;
				return n;
			}
			
			@Override
			protected LocalDateTime next(LocalDateTime currentTime,int crontabCycle) {
				int c = 0;
				if(crontabCycle>=0) {
					LocalDateTime time = currentTime;
					do{
						time = time.plusDays(1);
						if(c++ > 365) return null;
					}while(getOffset(time)==crontabCycle);
					return time;
				}else {
					LocalDateTime nextFirst = currentTime.plusWeeks(1);
					nextFirst = nextFirst.plusDays(-getOffset(nextFirst));
					LocalDateTime time = nextFirst.plusDays(crontabCycle);
					while(!time.isAfter(currentTime)) {
						time = time.plusWeeks(1);
					}
					return time;
				}
			}
		},
		month{
			@Override
			protected int getOffset(LocalDateTime currentTime) {
				return currentTime.getDayOfMonth();
			}
			
			@Override
			protected int checkCrontabCycle(int n) {
				if(n>30)n=30;
				if(n<-30)n=-30;
				return n;
			}

			@Override
			protected LocalDateTime next(LocalDateTime currentTime,int crontabCycle) {
				int c = 0;
				if(crontabCycle>=0) {
					LocalDateTime time = currentTime;
					do{
						time = time.plusDays(1);
						if(c++ > 365) return null;
					}while(getOffset(time)==crontabCycle);
					return time;
				}else {
					LocalDateTime nextFirst = currentTime.plusWeeks(1);
					nextFirst = nextFirst.plusDays(-getOffset(nextFirst));
					LocalDateTime time = nextFirst.plusDays(crontabCycle);
					while(!time.isAfter(currentTime)) {
						time = time.plusMonths(1);
					}
					return time;
				}
			}
		};
		/**  ����bean�е�crontab ���� */
		public boolean parse(PushBean bean) {
			//ÿ��n�� ÿ��n n/12:00
			String dateTime;
			String[] tmps = bean.crontab.split("/",2);
			if(tmps.length==2) {
				String[] tmp2 = tmps[0].split(",");
				bean.crontabCycle = new ArrayList<>();
				for(String tmp:tmp2) {
					int n = Integer.parseInt(tmp);
					bean.crontabCycle.add(n);
				}
				dateTime = tmps[1];
			}else {
				bean.crontabCycle = java.util.Arrays.asList(0);
				dateTime = tmps[0];
			}
			LocalTime time = null;
			try {
				time = java.time.format.DateTimeFormatter.ISO_LOCAL_TIME.parse(dateTime, LocalTime::from);
			}catch(java.time.format.DateTimeParseException e) {
				//ignore
			}
			if(time==null) {
				time = DB_DATE_TIME.parse(dateTime, LocalTime::from);
			}
			bean.crontabDate = LocalDateTime.of(LocalDate.now(), time);
			return true;
		}
		
		/** �״�����ʱ�� */
		public LocalDateTime getFirst(PushBean bean, LocalDateTime currentTime) {
			int offset=getOffset(currentTime);
			if(offset<0) {
				//�ж��Ǽ��ظ�, ������һ����Ȼ���ڵĵ�n��
				int crontabCycle = bean.crontabCycle.size()>0?bean.crontabCycle.get(0):1;
				LocalDateTime time = LocalDateTime.of(bean.mdate.toLocalDate(), bean.crontabDate.toLocalTime());
				while(time.isBefore(currentTime)) {
					time = next(time, crontabCycle);
				}
				return time;
			}else {
				
				LocalDateTime theTime = null;
				for(int n:bean.crontabCycle) {
					LocalDateTime time = first(checkCrontabCycle(n), bean.crontabDate, currentTime);
					if(time!=null && (theTime==null || theTime.isAfter(time)))theTime=time;
				}
				return theTime;
			}
		}
		
		/** ��һ������ʱ�� */
		public LocalDateTime getNext(PushBean bean, LocalDateTime currentTime) {
			int offset=getOffset(currentTime);
			if(offset<0) {
				//�ж��Ǽ��ظ�, ������һ����Ȼ���ڵĵ�n��
				int crontabCycle = bean.crontabCycle.size()>0?bean.crontabCycle.get(0):1;
				LocalDateTime time = next(currentTime, crontabCycle);
				return time;
			}else {
				
				LocalDateTime theTime = null;
				for(int n:bean.crontabCycle) {
					LocalDateTime time = next(currentTime, checkCrontabCycle(n));
					if(time!=null && (theTime==null || theTime.isAfter(time)))theTime=time;
				}
				return theTime;
			}
		}
		
		/** ����crontabֵn �Ͳο�ʱ��craontDate������״�ִ��ʱ�� */
		protected LocalDateTime first(int n, LocalDateTime crontabDate, LocalDateTime currentTime) {
			int offset = getOffset(currentTime);
			LocalDateTime time = LocalDateTime.of(currentTime.toLocalDate(), crontabDate.toLocalTime());
			time = time.plus(n-offset, getChronoUnit());
			while(time.isBefore(currentTime)) {
				time = next(time, n);
			}
			return time;
		}
		
		/** ���ڵ���һ��ʱ�� */
		protected LocalDateTime next(LocalDateTime currentTime,int crontabCycle) {
			return null;
		}
		
		/** У��ѭ�����ڲ��� */
		protected int checkCrontabCycle(int n) {
			return n;
		}

		/** ��������Ȼ�����е�ƫ�� */
		protected int getOffset(LocalDateTime currentTime) {
			return -1;
		}
		/** ʱ������ĵ�λ Ĭ��DAYS */
		protected ChronoUnit getChronoUnit() {
			return ChronoUnit.DAYS;
		}
	}
	
}
