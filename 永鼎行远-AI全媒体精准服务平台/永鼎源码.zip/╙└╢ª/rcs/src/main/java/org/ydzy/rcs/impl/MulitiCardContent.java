package org.ydzy.rcs.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.google.inject.Inject;
import org.ydzy.bot.BotInfo;
import org.ydzy.bot.BotManager;
import org.ydzy.handler.BaseRcsContext;
import org.ydzy.rcs.CardModel;
import org.ydzy.rcs.MessagesInter;
import org.ydzy.rcs.Provider;
import org.ydzy.rcs.annotation.Description;
import org.ydzy.rcs.entity.ReceiveEntity;
import org.ydzy.util.ParamUtils;
import org.ydzy.util.StringUtils;
import org.ydzy.util.Util;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonSyntaxException;
import com.google.inject.Singleton;

import static org.ydzy.util.Util.*;

@Singleton
@Description("multicard")
public class MulitiCardContent implements CardModel{
	public static org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(MulitiCardContent.class);
	public final static String systemContextparams="sid={session.sid}&configid={configid}";

	@Inject
	BotManager botManager;

	/** ��ȡģ����� */
	protected List<Map<String,Object>> modelParams(ReceiveEntity requestObject,JsonObject contentObject,BaseRcsContext context)
	{
		String msgid=contentObject==null?null: getElementAsString(contentObject,"msgid");
		if (!isNull(msgid)) {
			try {
				Object o;
				o = context.getAttributes().get("modelParams_" + msgid);
				if(o==null || !(o instanceof List)) {
					o = context.getSession().get("modelParams_" + msgid);
					if(o==null || !(o instanceof List)) o = null;
				}
				if(o!=null) {
					return (List<Map<String,Object>>)o;
				}
				
				 Map<String,List<Map<String,Object>>> modelParams=	context.getConfig().modelParams;
				 List<Map<String,Object>> maps=modelParams.get(msgid);
				 return maps;
			} catch (Exception e) {
			}
		}
		return null;
	}
	
	/**ͨ��ģ�����ֵ 
	 * @param requestObject
	 * @param eobject
	 * @param context
	 * @return
	 */
	private JsonObject template(ReceiveEntity requestObject,JsonObject eobject,BaseRcsContext context,boolean send25gMsg)
	{
		JsonArray content = eobject.get("content").getAsJsonArray();
		List<CardMsg> cstrs = new ArrayList<>();
		int contelen = content.size();
//		String manager=Util.toString(requestObject.getAnswersObject().get("manager"));
		String manager = "false";
		if (requestObject != null)
			manager = Util.toString(requestObject.getAnswersObject().get("manager"));
		JsonArray newContent = new JsonArray();
		JsonObject allModels = new JsonObject();
		for (JsonElement c1 : content) {
			JsonObject cobject = c1.getAsJsonObject();
			String isTemplate = getElementAsString(cobject, "isTemplate");
			String msgid = getElementAsString(cobject, "msgid");

			String suggestionssingle = getElementAsString(cobject, "suggestions");
			String paramtmp = getElementAsString(cobject, "params");
			String suggestionid = Util.getElementAsString(cobject, "suggestionid");

			boolean modeluse = false;
			Map dbParam = gson.fromJson(cobject, Map.class);
			dbParam.remove("params");
			dbParam.remove("suggestionsSet");
			dbParam.remove("suggestionsWithId");
			if ("1".equals(isTemplate)) {
				JsonArray modelParam = new JsonArray();
				List<?> models = modelParams(requestObject, cobject, context);
//					allModels.addAll(models);
				if(models!=null&&models.size()>0)
				{
					modeluse=true;
					for(int i =0;i<models.size();i++)
					{
						String msg = getElementAsString(cobject,"msg");
						JsonObject jobj=cobject.deepCopy();
						Map<String,Object> e=(Map<String,Object>)(models.get(i));
						Map<String,String> pav = e.get("params")==null?null:(Map<String,String>)e.get("params");
						pav.putAll(dbParam);
						pav.put("tempId", Util.toString(e.get("tempId")));
						String msg1 =formatVues(msg, pav);
						msg=replaceParam(msg1,requestObject,context);
						String paraSugg = pav.get("suggestionssingle");
						if(!isNull(paraSugg)) {
							suggestionssingle = paraSugg;
						}else {
							suggestionssingle=replaceParam(suggestionssingle,requestObject,context);
						}
						String suggestionssingle1 = formatVues(suggestionssingle, pav);
						String params = replaceParam(paramtmp, requestObject, context);
						jobj.addProperty("msgId", Util.toString(e.get("msgId")));
						jobj.addProperty("tempId", Util.toString(e.get("tempId")));
						jobj.add("param", JsonParser.parseString(gson.toJson(pav)));
						jobj.addProperty("defined", paramtmp);
						jobj.addProperty("msg", msg);
						jobj.addProperty("suggestions", suggestionssingle);
						modelParam.add(jobj);
						Object[] newObject = initParams(params, requestObject, context);
						String tmp = Provider.sugestion(suggestionid + "|" + suggestionssingle1, context);
						if (Util.isNull(suggestionssingle1))
							tmp = Provider.sugestion(suggestionssingle1, context);
						CardMsg c2 = media2Str(msg1 + "|" + msgid, tmp, newObject, requestObject, context, send25gMsg);
						cstrs.add(c2);
//							 String mytitle=msg1.split("\\Q|")[0];
//							 String reqtitle=requestObject.getContent();
						if (contelen > 1) {
							break;
						}
						//at most show seven 
						if (i > 7 && !"true".equals(manager))
							break;
						
					}
				}
				
				allModels.add(msgid,modelParam);
				newContent.addAll(modelParam);
			}
			if(!modeluse) {
				String msg = getElementAsString(cobject, "msg");
				requestObject.getAnswersObject().putAll(dbParam);
				msg = replaceParam(msg, requestObject, context);
				suggestionssingle = replaceParam(suggestionssingle, requestObject, context);
				String params = replaceParam(paramtmp, requestObject, context);
				Object[] newObject = initParams(params, requestObject, context);
				;
				String webapiurl = Util.toString(requestObject.getAnswersObject().get("webapiurl"));
				if (!Util.isNull(webapiurl))
					context.getSession().put("webapiurl", webapiurl);
				String tmp = Provider.sugestion(suggestionid + "|" + suggestionssingle, context);
				if (Util.isNull(suggestionssingle))
					tmp = Provider.sugestion(suggestionssingle, context);
				CardMsg c2 = media2Str(msg + "|" + msgid, tmp, newObject, requestObject, context, send25gMsg);
				cstrs.add(c2);
			}
			
		}
		if(cstrs!=null && !cstrs.isEmpty()) {
			//���ɶ������� ����Ĵ��ı�����
			String plainText = cstrs.get(0).description;
			if(plainText==null || plainText.isEmpty()) {
				plainText = cstrs.get(0).title;
			}
			if(plainText!=null && !plainText.isEmpty()) {
				requestObject.getAnswersObject().put("msg", plainText);
			}
		}
		if(newContent!=null && !newContent.isJsonNull() && newContent.size()>0)
		eobject.add("content",newContent);
		JsonObject contentObject2H5=new JsonObject();
		//FORMAT 2 JSON //TODO
		ContentTextMessage message = cards(cstrs,eobject,send25gMsg);
		JsonElement bodyJo = gson.toJsonTree(message);
		contentObject2H5.add("body", bodyJo);
		contentObject2H5.add("modelParam",allModels);
		return contentObject2H5;
	}
	/**ͨ������������ ԭʼ�������Ϣ�ṹ�������ٷ�װ
	 * @return ������Ϣ�ṹ�� 
	 */
	public JsonObject constructMsgStructure(ReceiveEntity requestObject,JsonObject eobject,BaseRcsContext context,boolean send25gMsg) {
		if (eobject == null || eobject.isJsonNull() || eobject.get("content") == null || eobject.get("content").isJsonNull())
			return eobject;
		String suggestions = getElementAsString(eobject, "suggestions");
		//TODO
		String suggestionid = Util.getElementAsString(eobject, "suggestionid");
		String allsuggestionid = Util.getElementAsString(eobject, "allsuggestionid");
		String gloabl = replaceParam(systemContextparams, requestObject, context);
		context.getAttributes().put("globalParam", gloabl);

		String tmpsuggestion = replaceParam(suggestions, requestObject, context);
		String tmp = allsuggestionid + "|" + tmpsuggestion;
		if (!Util.isNull(tmpsuggestion))
			tmpsuggestion = Provider.sugestion(tmp, context);
		else
			tmpsuggestion = Provider.sugestion(tmpsuggestion, context);

		eobject.addProperty("suggestions", tmpsuggestion);

		//String cards = cards(cstrs,eobject);
		//JsonElement bodyJo = JsonParser.parseString(cards);
		JsonObject contentObject2H5 = template(requestObject, eobject, context, send25gMsg);
		contentObject2H5.addProperty("isShowMenu", getElementAsString(eobject, "isShowMenu"));
		contentObject2H5.addProperty("qrcode", getElementAsString(eobject, "qrcode"));
		contentObject2H5.addProperty("serverIcon", getElementAsString(eobject, "serverIcon"));
		contentObject2H5.add("globalSuggestion", JsonParser.parseString("[" + tmpsuggestion + "]"));
		// �����ֶ������زķ���5G��Ϣʱʹ��
		//if("true".equals(manager))
		{
			
			
			requestObject.getAnswersObject().put("resObject", contentObject2H5);
		}
		try {
			String config=Util.toString(requestObject.getAnswersObject().get("configid"));
			context.getSession().put(config, contentObject2H5);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return eobject;
	}
	
    public String cardHtml(ReceiveEntity requestObject,JsonObject eobject,BaseRcsContext context,boolean send25gMsg)  {
//		String keywords = eobject.get("keywords").getAsString();
    	constructMsgStructure(requestObject,eobject,context,send25gMsg);
    	JsonObject contentObject2H5 =(JsonObject) requestObject.getAnswersObject().get("resObject");
    	if(contentObject2H5==null||contentObject2H5.isJsonNull())
    		return "";
    	JsonElement bodyJo=contentObject2H5.get("body");
    	if(bodyJo==null||bodyJo.isJsonNull())
    		return "";
    	
		String isp=context.getConfig().enterpriseProperty(requestObject.getChatBotId(), "isp");
		String configCssClassName = getElementAsString(eobject, "configCssClassName","");
		requestObject.getAnswersObject().put("configCssClassName", configCssClassName);
		List<MessagesInter.MessageBody> body1 = new ArrayList<>();
		MessagesInter.MessageBody m1 = new MessagesInter.MessageBody();
		m1.contentText = bodyJo;
		m1.contentType = "application/vnd.gsma.botmessage.v1.0+json";
		body1.add(m1);
		String tmpsuggestion= getElementAsString(eobject, "suggestions");
		if(!isNull(tmpsuggestion)) {
			MessagesInter.MessageBody m2 = new MessagesInter.MessageBody();
			m2.contentText = "{\"suggestions\":["+tmpsuggestion+"]}";
			m2.contentType = "application/vnd.gsma.botsuggestion.v1.0+json";
			body1.add(m2);
		}
		MessagesInter msgimp=	null;
		try {
			msgimp= Provider.getInstance(MessagesInter.class, isp+"MessageImp");
		} catch (Exception e) {
			msgimp=Provider.getInstance(MessagesInter.class,  "cmccMessageImp");
		}
		
		return msgimp.body(requestObject, eobject, context, body1);
	}
    private String[] queryMediaRealAddress(BaseRcsContext context,String mediaUrl,boolean raw)
    {
    	return context.getConfig().queryMediaRealAddress(mediaUrl, raw);    	
    }
    private  CardMsg media2Str(String media, String suggestions, Object[] newObject,ReceiveEntity requestObject,BaseRcsContext context, boolean send25gMsg) {
    	media=StringUtils.format(media, newObject);
		media=replaceParam(media,requestObject,context);
		String manager=Util.toString(requestObject.getAnswersObject().get("manager"));
		suggestions=replaceParam(suggestions,requestObject,context);
		String tmpsuggestion=StringUtils.format(suggestions, newObject);
		
		String[] msg = media.split("\\Q|");
		CardMsg cm = new CardMsg();
		int length=msg.length;
		if(length>2&&!isNull(msg[2])) {
			String[] medis =null;
			if("true".equals(manager)){
				medis=new String [] {msg[2],msg.length>6?msg[6]:msg[2]};
			}else {
				medis=queryMediaRealAddress(context,msg[2],true);
				if(medis==null)
					medis=new String [] {msg[2],msg.length>6?msg[6]:msg[2]};
			}
//		return StringUtils.format(cardsAll, StringUtils.escapeJS(msg[0],true), StringUtils.escapeJS(msg[1],true), msg[2],length<=3?"": msg[3], length<=4?"":msg[4],length<=5?"": msg[5],length<=6?"": msg[6], tmpsuggestion,length<=7?"": msg[7]);
			//return StringUtils.format(cardsAll, msg[0], msg[1], msg[2],length<=3?"": msg[3], length<=4?"":msg[4],length<=5?"": msg[5],length<=6?"": msg[6], tmpsuggestion,length<=7?"": msg[7]);
			if(length>0 && msg[0].length()>0)cm.title = msg[0];
			if(length>1 && msg[1].length()>0)cm.description = msg[1];

			//H5 OR 5gMSG
			if (send25gMsg){
				cm.media = new CardMedia();
				if(length>2 && msg[2].length()>0)cm.media.mediaUrl = medis[0];
				if(length>3 && msg[3].length()>0)cm.media.mediaContentType = msg[3];
				if(length>4 && msg[4].length()>0)cm.media.thumbnailContentType = msg[4];
				if(length>5 && msg[5].length()>0)cm.media.height = msg[5];
				if(length>6 && msg[6].length()>0)cm.media.thumbnailUrl = medis[1];
				if(length>7 && msg[7].length()>0)cm.msgid = msg[7];
			}else{
				cm.H5media=new CardMedia();
				if(length>2 && msg[2].length()>0)cm.H5media.mediaUrl = msg[2];
				if(length>3 && msg[3].length()>0)cm.H5media.mediaContentType = msg[3];
				if(length>4 && msg[4].length()>0)cm.H5media.thumbnailContentType = msg[4];
				if(length>5 && msg[5].length()>0)cm.H5media.height = msg[5];
				if(length>6 && msg[6].length()>0)cm.H5media.thumbnailUrl = msg[6];
				if(length>7 && msg[7].length()>0)cm.msgid = msg[7];
			}

			Integer i;
			i = null;
			if(length>8 && msg[8].length()>0) try{
				i = Integer.parseInt(msg[8]);
			}catch(Throwable ignore) {}
			if(i!=null)cm.media.mediaFileSize = i;
			i = null;
			if(length>9 && msg[9].length()>0) try{
				i = Integer.parseInt(msg[8]);
			}catch(Throwable ignore) {}
			if(i!=null)cm.media.thumbnailFileSize = i;
		}else
		{
			//return StringUtils.format(cardsimple, length<=0?"�� ":msg[0],  length<=1?"�� ":msg[1], tmpsuggestion,length<=2?"":msg[2]);
			if(length>0 && msg[0].length()>0)cm.title = msg[0];
			if(length>1 && msg[1].length()>0)cm.description = msg[1];
			if(length>2 && msg[2].length()>0)cm.msgid = msg[2];
		}
		if(tmpsuggestion!=null&&tmpsuggestion.length()>0){
			try {
				JsonElement je = JsonParser.parseString("[" + tmpsuggestion + "]");
				if(je.isJsonArray()) {
					cm.suggestions = je;
				}else {
					JsonArray ja = new JsonArray();
					ja.add(je);
					cm.suggestions = ja;
				}
			} catch (JsonSyntaxException e) {
			log.error("parse error element {} ",tmpsuggestion, e );
			}
		}
		return cm;
    
    }

	private  ContentTextMessage cards(List<CardMsg> cstrs,JsonObject eobject,boolean send25gMsg) {
		if(cstrs==null|| cstrs.size()==0) {
			return null;
		}
		CardLayout layout = new CardLayout();
		layout.cardOrientation = getElementAsString(eobject, "direction","VERTICAL");
		layout.cardWidth = getElementAsString(eobject, "cardwidth","MEDIUM_WIDTH");
		layout.imageAlignment = getElementAsString(eobject, "alignment","LEFT");
		//ADD H5LAYOUT STYLE JSON
		//send25gMsg=true LAYOUT DEFAULT CSSPATH

		CssStyleService cssStyleService = Provider.getInstance(CssStyleService.class, "cssStyleService");
		String cssStyleId = getElementAsString(eobject, "cssStyleId");
		if(Util.isNull(cssStyleId) || "0".equals(cssStyleId)){
			//use chabot's cssStyleId
			BotInfo botInfo = botManager.getChatBotInfo(getElementAsString(eobject, "chatbotIdenty"));
			if (botInfo != null) {
				cssStyleId = botInfo.getInfo("cssStyleId");
			}
		}
		if(!Util.isNull(cssStyleId) && !"0".equals(cssStyleId)){
			if(send25gMsg){
				layout.style = cssStyleService.getCssStyleFileURI(cssStyleId);
			}else{
				layout.style = cssStyleService.getCssStyleString(cssStyleId);
			}
		}

		BasePurposeCardMessage pc;
		if(cstrs.size()==1) {
			PurposeCardMessage card = new PurposeCardMessage();
			card.generalPurposeCard.content = cstrs.get(0);
			card.generalPurposeCard.layout = layout;
			pc = card;
		}else {
			PurposeCardCarouselMessage card = new PurposeCardCarouselMessage();
			card.generalPurposeCardCarousel.content = cstrs;
			card.generalPurposeCardCarousel.layout = layout;
			pc = card;
		
		}
		ContentTextMessage contentText = new ContentTextMessage();
		contentText.message = pc;
		return contentText;
	}
	
	public String formatVues(String msg, Map<String, String> paramObject) {
		String[] newMsg = { msg };
		if (paramObject != null) {
			try {
				paramObject.forEach((k, v) -> {
					if(k.startsWith(ParamUtils.replace_pattern)){
						v = v == null ? "" : v;
					}
					if (v != null)
						try {
							newMsg[0] = newMsg[0].replace("{" + k + "}", v.replace("\n", "\\n").replace("\r", "\\r").replace("\"", "\\\""));
						} catch (Exception e) {
							e.printStackTrace();
							System.out.println(v);
						}
				});
			} catch (Exception ignored) {
			}
		}
		return newMsg[0];
	}
	
	protected Gson gson = new Gson();
	
	/** ��Ƭ��Ϣ�е�media */
	public static class CardMedia{
		/*
			require:[ "mediaUrl", "mediaContentType",  "mediaFileSize",  "height" ]
		 */
		public String mediaUrl;
		public String mediaContentType = "";
		public Integer mediaFileSize = 0;
		public String thumbnailUrl;
		public String thumbnailContentType;
		public Integer thumbnailFileSize = 0;
		/** "SHORT_HEIGHT", "MEDIUM_HEIGHT", "TALL_HEIGHT" */
		public String height = "MEDIUM_HEIGHT";
		public String contentDescription;
	}
	/** ��Ƭ��Ϣ */
	public static class CardMsg{
		public String title;
		public String description;
		public String msgid;
		public CardMedia media;
		//����h5Ԥ��ҳ���ý�� ��Ϣ ��5g��Ϣ�ֿ� 5g��Ϣ��ý�� ��Ҫ��Ȩ����ܷ��� �޷�ʹ��h5����
		public CardMedia H5media;
		public Object suggestions;

	}

	
	/** ��Ƭ���� */
	public static class CardLayout{
		/**  VERTICAL	HORIZONTAL */
		public String cardOrientation = "HORIZONTAL";
		/** HORIZONTALʱ������ "LEFT", "RIGHT" */
		public String imageAlignment = "LEFT";
		/**
			"type": "string",
			"enum": [
				"SMALL_WIDTH",
				"MEDIUM_WIDTH"
			],
			"default": "SMALL_WIDTH"
		 */
		public String cardWidth = "SMALL_WIDTH";
		public String[] titleFontStyle = new String[] {"underline", "bold"};
		public String[] descriptionFontStyle = new String[] {"bold"};
		public String style = "http://example.com/default.css";
	}

	/** ����Ƭ��࿨Ƭ��Ϣ�Ļ��� */
	public static abstract class basePurposeCard{
		public CardLayout layout;
	}
	public static class PurposeCard extends basePurposeCard{
		public CardMsg content;
	}
	public static class PurposeCardCarousel extends basePurposeCard{
		public List<CardMsg> content;
	}
	public static abstract class BasePurposeCardMessage{
		
	}
	public static class PurposeCardMessage extends BasePurposeCardMessage{
		public PurposeCard generalPurposeCard = new PurposeCard();
	}
	public static class PurposeCardCarouselMessage extends BasePurposeCardMessage{
		public PurposeCardCarousel generalPurposeCardCarousel = new PurposeCardCarousel();
	}
	public static class ContentTextMessage{
		public BasePurposeCardMessage message;
	}
}
