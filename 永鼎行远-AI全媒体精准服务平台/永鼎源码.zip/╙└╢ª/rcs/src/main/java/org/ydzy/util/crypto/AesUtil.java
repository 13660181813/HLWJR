package org.ydzy.util.crypto;

/**
 * @author zxw
 * @create 2021/11/30
 */

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/**
 * AES���ܹ�����
 */
public class AesUtil extends CipherEencryptImp<AesUtil.AESEnum> {
    public AesUtil(AESEnum defaultEncrypt) {
        this.defaultAlgorithm = defaultEncrypt == null ? AESEnum.CBC_NO_PADDING : defaultEncrypt;
    }
    private static final Logger logger = LoggerFactory.getLogger(AesUtil.class);
    private final static String AES_ALGORITHM_NAME = "AES";
    private final static int SLAT_KEY_LENGTH = 16;
    private final static int VECTOR_KEY_LENGTH = 16;

    @Override
    protected byte[] encrypt(String content, String slatKey, String vectorKey, AESEnum encryptType) throws Exception {
        byte[] encrypted = null;
        try {
            if (slatKey == null || slatKey.length() != SLAT_KEY_LENGTH) {
                throw new Exception("slatKey is null or slatKey is not at " + SLAT_KEY_LENGTH + "-bytes.");
            }
            if (encryptType == null) {
                throw new Exception("encryptType is null");
            }
            Cipher cipher = Cipher.getInstance(encryptType.getEncryptType());
            SecretKey secretKey = new SecretKeySpec(slatKey.getBytes(), AES_ALGORITHM_NAME);
            byte[] plaintext = null;
            if (AESEnum.CBC_NO_PADDING.equals(encryptType) || AESEnum.ECB_NO_PADDING.equals(encryptType)) {
                plaintext = handleNoPaddingEncryptFormat(cipher, content);
            } else {
                plaintext = content.getBytes();
            }
            if (AESEnum.CBC_NO_PADDING.equals(encryptType) || AESEnum.CBC_PKCS5PADDING.equals(encryptType)) {
                if (vectorKey == null || vectorKey.length() != VECTOR_KEY_LENGTH) {
                    throw new Exception("vectorKey is null or vectorKey is not at " + VECTOR_KEY_LENGTH + "-bytes.");
                }
                IvParameterSpec iv = new IvParameterSpec(vectorKey.getBytes());
                cipher.init(Cipher.ENCRYPT_MODE, secretKey, iv);
            } else {
                cipher.init(Cipher.ENCRYPT_MODE, secretKey);
            }
            encrypted = cipher.doFinal(plaintext);
        } catch (Exception e) {
			logger.error("Aes Util encryption failed, errors: {}", e.getMessage());
            throw new Exception(encryptException);
        }
        return encrypted;
    }

    @Override
    protected String decrypt(byte[] content, String slatKey, String vectorKey, AESEnum encryptType) throws Exception {
        String result = null;
        try {
            if (slatKey == null || slatKey.length() != SLAT_KEY_LENGTH) {
                throw new Exception("slatKey is null or slatKey is not at " + SLAT_KEY_LENGTH + "-bytes.");
            }
            if (encryptType == null) {
                throw new Exception("encryptType is null");
            }
            Cipher cipher = Cipher.getInstance(encryptType.getEncryptType());
            SecretKey secretKey = new SecretKeySpec(slatKey.getBytes(), AES_ALGORITHM_NAME);
            if (AESEnum.CBC_NO_PADDING.equals(encryptType) || AESEnum.CBC_PKCS5PADDING.equals(encryptType)) {
                if (vectorKey == null || vectorKey.length() != VECTOR_KEY_LENGTH) {
                    throw new Exception("vectorKey is null or vectorKey is not at " + VECTOR_KEY_LENGTH + "-bytes.");
                }
                IvParameterSpec iv = new IvParameterSpec(vectorKey.getBytes());
                cipher.init(Cipher.DECRYPT_MODE, secretKey, iv);
            } else {
                cipher.init(Cipher.DECRYPT_MODE, secretKey);
            }
            byte[] original = cipher.doFinal(content);
            String originalString = new String(original);
            result = originalString.trim();
        } catch (Exception e) {
			logger.error("Aes Util decryption failed, errors: {}", e.getMessage());
            throw new Exception(decryptException);
        }
        return result;
    }

    public static void main(String[] args) {
        ICipherEncrypt cipher = new AesUtil(AESEnum.CBC_PKCS5PADDING);
        String data = "18701336339";
        String ckey = "nj66E9lxMI8nnk+9";
        try {
            String s = cipher.encryptBase64(data, ckey, ckey);
            System.out.println(s);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * @author zxw
     * @create 2021/11/30
     */
    public enum AESEnum {
        /**
         * ����������ģʽ, ����8λ��0����8λ, ������������������0, ��{65,65,65,0,0,0,0,0}
         */
        CBC_NO_PADDING("AES/CBC/NoPadding"),
        /**
         * ����������ģʽ, ����8λ����λ������8λ, ��{65,65,65,5,5,5,5,5}��{97,97,97,97,97,97,2,2}; �պ�8λ��8λ8
         */
        CBC_PKCS5PADDING("AES/CBC/PKCS5Padding"),
        /**
         * ����������ģʽ, ����8λ��0����8λ, ������������������0
         */
        ECB_NO_PADDING("AES/ECB/NoPadding"),
        /**
         * ����������ģʽ, ����8λ����λ������8λ
         */
        ECB_PKCS5PADDING("AES/ECB/PKCS5Padding");

        private AESEnum(String encryptType) {
            this.encryptType = encryptType;
        }

        private String encryptType;

        public String getEncryptType() {
            return encryptType;
        }

        public void setEncryptType(String encryptType) {
            this.encryptType = encryptType;
        }
    }
}