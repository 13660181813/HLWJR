package org.ydzy.rcs.impl;

import org.ydzy.rcs.SuggestionDisplay;
import org.ydzy.rcs.annotation.Description;

import com.google.inject.Singleton;

@Singleton
@Description("composeAction")
public class ComposeAction implements SuggestionDisplay{

	@Override
	public String suggestionHtml(String[] args) {
		return suggestionHtmlSubs(args);
	}

}
