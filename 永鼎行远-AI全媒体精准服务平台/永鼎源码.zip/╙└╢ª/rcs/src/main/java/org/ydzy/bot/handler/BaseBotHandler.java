package org.ydzy.bot.handler;

import java.io.IOException;

import org.eclipse.jetty.server.handler.HandlerWrapper;
import org.ydzy.bot.BotInfo;
import org.ydzy.bot.BotManager;
import org.ydzy.bot.IVerify;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.inject.Inject;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class BaseBotHandler extends HandlerWrapper {
	private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(BaseBotHandler.class);

	@Inject
	protected BotManager manager;

	private static final String SIP = "sip:";
	private static final String[] botTag = {SIP, "/bot:", "notifyInfoNotification/", "messageNotification/", "deliveryNotification/"};
	public static String getChatBotIdFromPath(String uri) {
		String path;
		try {
			path = java.net.URLDecoder.decode(uri, "UTF-8");
			for(String tag:botTag) {
				int p = path.indexOf(tag);
				if(p>0) {
					if(!tag.equals(SIP))p+=tag.length();
					int p1 = path.indexOf('/',p);
					if(p1<=0)p1=path.length();
					String text = path.substring(p, p1);
					return text;
				}
			}
		} catch (Exception ignore) {

		}
		return null;
	}

	/*
1  signature     string  M  ���ݼ����������ɵ�ǩ�� 
2  timestamp       long  M  Linuxʱ�������1970��1��1����������������
3  nonce  string  M  ����UUID�㷨���� 
4  echoStr  string  C  ����ַ�������֤Chatbot��Ϣ����urlʹ�� 
5  chatbotId  string  M  ChatbotID 
	 */
	/**
	 * ��֤bot����ͷ�е���Ϣ, ��ȡChatBot��Ϣ
	 *  
	 * @param request
	 * @param response
	 * @return �ɹ�����BotInfo���� �����׳��쳣VerifyError
	 * @throws VerifyError ��֤������Ϣ
	 */
	protected BotInfo verifyChatbot(HttpServletRequest request, HttpServletResponse response) throws VerifyError{
		String chatbotid = request.getHeader("chatbotId");

		if(chatbotid==null) {
			chatbotid = getChatBotIdFromPath(request.getRequestURI());
		}
		// /notifications/notifyInfoNotification/sip%3A106500%40botplatform.rcs.domain.cn/check
		BotInfo bi;
		if(chatbotid==null) {
			bi = null;
		}else {
			bi = manager.getChatBotInfo(chatbotid);
			if(bi==null) {
				int p;
				if((p=chatbotid.indexOf('@'))>0) {
					String cid = chatbotid.substring(0,p);
					bi = manager.getChatBotInfo(cid);
				}
			}
		}


		String error = null;
		if(bi==null) {
			error = "chatbotid is undefined(" + chatbotid + ")";
		}else {
			try {
				IVerify verify = bi.getBotAccess().getVerify();
				if(verify!=null)verify.verify(request, bi);
				return bi;
			}catch(VerifyError e) {
				//��֤��֤ʧ��
				throw e;
			}
		}
		log.debug("check sinature error(" + error + ")");
		throw new VerifyError(error);
	}

	public static String resBodyJson(String code, String msg, JsonElement res) {
		JsonObject jo = new JsonObject();
		jo.addProperty("code", code);
		jo.addProperty("msg", msg);
		if(res!=null)jo.add("data", res);
		return jo.toString();
	}
	
	public static void sendResponse(String remoteAddr, String body, int status,
			HttpServletRequest request, HttpServletResponse response) throws IOException {
		// Declare response encoding and types
		response.setContentType("application/json;charset=utf-8");
		// Declare response status code
		response.setStatus(status);
		// Write back response
		response.getWriter().println(body);
		// Inform jetty that this request has now been handled
		log.debug("send response {} to remoteAddr {} ", body, remoteAddr);
	}

}
