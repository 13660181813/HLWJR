package org.ydzy.bot;

import org.ydzy.util.Util;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

/**
 * bot��Ϣ
 * @author ljp
 *
 */
public class BotInfo {
	protected String chatbotId;
	
	protected String appId;
	
	protected String appKey;
	
	/** CatBot ��Ϣ */
	protected JsonObject infos;
	
	/** ���� */
	protected String type;

	public String getType() {
		return type;
	}

	protected transient BotManager manager;
	
	/** ���ݿ�������� */
	protected transient DbOperator dbOper;
	public DbOperator getDbOper() {
		return dbOper;
	}

	/** maap���ʽӿ� */
	private transient BotAccess botAccess;
	
	/** �����������������֤��ʽ */
	private transient IAuthorize authorize;

	/** ��װ��¼������Ӧ�õ��û���¼��Ϣ */
	private transient ILogin loginServer;

	/** �ض��������H5ʱ�Բ������ж��ƴ��� */
	private transient IRedirectHandler redirectHandler;

	/** �����������������֤��ʽ */
	public IAuthorize getAuthorize() {
		return authorize==null?botAccess.getAuthorize():authorize;
	}

	public ILogin getLoginServer() {
		return loginServer;
	}

	public IRedirectHandler getRedirectHandler() {
		return redirectHandler;
	}

	public BotInfo(String chatbotId, String appId, String appKey, String token, JsonObject infos) {
		this.chatbotId = chatbotId;
		this.appId = appId;
		this.appKey = appKey;
		this.infos = infos==null?new JsonObject():infos;
		this.token = token;
	}
	
	public BotInfo(String chatbotId, String appId, String appKey, String token) {
		this(chatbotId, appId, appKey, token, null);
	}
	public BotInfo(String chatbotId, String appId, String appKey) {
		this(chatbotId, appId, appKey, null, null);
	}
	
	/** ����catbot 
	 *  @param manager
	 * @param botAccess
	 * @param authorize
	 * @param loginServer
	 * @param redirectHandler
	 */
	protected void register(BotManager manager, BotAccess botAccess, IAuthorize authorize, DbOperator dbOper, ILogin loginServer, IRedirectHandler redirectHandler) {
		this.manager = manager;
		this.botAccess = botAccess;
		this.authorize = authorize;
		this.dbOper = dbOper;
		this.token=Util.getElementAsString(this.getInfos(),"token");
		this.loginServer = loginServer;
		this.redirectHandler = redirectHandler;
	}
	
	/***
	 * �ж��Ƿ���ͬһ��
	 * @param bi
	 * @return
	 */
	public boolean isSame(BotInfo bi) {
		 return ((bi.getAppKey()==null || bi.getAppKey().equals(this.getAppKey())) 
					&& (bi.getAppId()==null || bi.getAppId().equals(this.getAppId())) 
					&& (bi.type==null || bi.type.equals(this.type))
					&& (bi.infos==null || this.infos==null || bi.infos.equals(this.infos))
					);
	}
	
	
	/** "spName":"�ǻۼ�װ" */
	public static final String KEY_SPNAME = "spName";

	/** "isp":"telecom" */
	public static final String KEY_ISP = "isp";

	/** �������� sip:106598858801001917985@botplatform.rcs.vnet.cn */
	public String getChatbotIdenty(){
		String text = getInfo("chatbotIdenty");
		return text;
	}
	
	public String getInfo(String key) {
		if(infos!=null) {
			JsonElement je = infos.get(key);
			if(je!=null && je.isJsonPrimitive())return je.getAsString();
			
		}
		return null;
	}
	
	public JsonObject getInfos() {
		return infos;
	}

	public String getChatbotId() {
		return chatbotId;
	}

	public String getAppId() {
		return appId;
	}

	/**  ��ӦAppSecretKey */
	public String getAppKey() {
		return appKey;
	}

	public String getCallUrl() {
		return callUrl;
	}

	public BotAccess getBotAccess() {
		return botAccess;
	}

	String token = null;
	/** chatbot ��Կ */
	public String getToken() {
		return token;
	}
	
	/**
	 * ����enable �������ͨ��
	 * @return
	 */
	public boolean isEnable() {
		boolean isEnable = true;
		int auditStatus=BotUtil.getElementAsInt(infos, "auditStatus", 0);
		int enable=BotUtil.getElementAsInt(infos, "enable", 0);
		if(auditStatus!=1 || enable!=1) {
			isEnable = false;
		}
		return isEnable;
	}
	
	/** ����chatbot, ����Ӫ�̲�ע�� */
	public synchronized boolean active() {
		if(botAccess!=null && isExpire() ) {
			return botAccess.active(this);
		}
		return false;
	}
	
	/** ���ʱʱ�� */
	long expire = 0;
	/** ������token ���ŵ�¼��Ϣ �ƶ�Ϊ���ַ���""
	 * @see BotInfo#active()
	 *   */
	String accessToken = null;
	/** ���ŵ�¼��Ϣ  */
	String callUrl = null;
	
	public boolean isExpire() {
		if(accessToken==null)return true;
		long curTime=System.currentTimeMillis();
		boolean flag = curTime>expire;
		return flag;
	}
	
	/** ǿ����Chatbot ����,��һ�غ��Զ����� */
	public void setExpire() {
		accessToken = null;
	}
	
	/** ������token ���ŵ�¼��Ϣ �ƶ�Ϊ���ַ���""
	 * @see BotInfo#active()
	 *   */
	public String getAccessToken() {
		return accessToken;
	}
	
	
}