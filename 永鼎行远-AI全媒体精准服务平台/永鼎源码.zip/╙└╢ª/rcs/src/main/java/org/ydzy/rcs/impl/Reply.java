package org.ydzy.rcs.impl;

import org.ydzy.rcs.SuggestionDisplay;
import org.ydzy.rcs.annotation.Description;
import org.ydzy.util.StringUtils;

import com.google.inject.Singleton;

@Singleton
@Description("reply")
public class Reply implements SuggestionDisplay{
	// reply|displayText|data,
	String reply = "{"
			+ "		\"reply\":\r\n"
			+ "		{\r\n"
			+ "			\"displayText\":\"%s\",\r\n"
			+ "			\"postback\":\r\n"
			+ "			{\r\n"
			+ "				\"data\":\"%s\"\r\n"
			+ "			},\r\n"
			+ "			\"sugCssClassName\":\"%s\"\r\n"
			+ "		}\r\n"
			+ "}\r\n";
	@Override
	public String suggestionHtml(String[] args) {
		int length = args.length;
		return StringUtils.format(reply, length <= 1 ? "" : args[1], length <= 2 ? "" : args[2], args.length >= 4 ? args[3] : "");
	}

}
