package org.ydzy.rcs.action;

import com.google.common.collect.Maps;
import com.google.gson.JsonObject;
import com.google.inject.Singleton;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.eclipse.jetty.util.StringUtil;
import org.ydzy.handler.BaseHandler;
import org.ydzy.handler.BaseRcsContext;
import org.ydzy.rcs.entity.LoginInfo;
import org.ydzy.util.NumberUtils;
import org.ydzy.util.Util;
import org.ydzy.util.crypto.cryptoDES;

import java.io.IOException;
import java.util.HashMap;
import java.util.concurrent.TimeUnit;

@Singleton
public class SMSLoginAction extends LoginAction {
    public static final String SMS_LOGIN_PREFIX = "SMS:";

    @Override
    public void login(HttpServletRequest request, HttpServletResponse response, String remoteAddr, LoginInfo loginInfo, BaseRcsContext context) throws IOException {
        if (!super.checkLogin(request, response, remoteAddr, loginInfo)) {
            return;
        }
        // ��֤������֤��
        if (!isValidSMSCode(request, response, remoteAddr, loginInfo)) return;
        // ��ն�����֤��
        String phoneNo = loginInfo.getPhoneNo();
        cacheProvider.deleteCache(SMS_LOGIN_PREFIX + phoneNo);
        // login
        JsonObject userInfo = authAction.getUserByMobile(phoneNo);
        long userId = StringUtil.toLong(Util.getElementAsString(userInfo, "userid", "0"));
        if (userId <= 0) {
            BaseHandler.sendResponse(remoteAddr, BaseHandler.resBodyJson("500", "δ�ҵ���Ч���û�", null), HttpServletResponse.SC_OK, request, response);
            return;
        }
        JsonObject grantObj = authAction.getUserGrantByUid(userId);
        String password;
        if (grantObj == null) {
            BaseHandler.sendResponse(remoteAddr, BaseHandler.resBodyJson("500", "δ�ҵ���Ч����Ȩ��½��Ϣ", null), HttpServletResponse.SC_OK, request, response);
            return;
        } else {
            password = Util.getElementAsString(grantObj, "credential");
            if (!Util.isNull(password))
                password = cryptoDES.decode(password);
        }
        HashMap<String, Object> payload = Maps.newHashMap();
        payload.put("type", "password");
        String accessToken = authAction.getAccessToekn(phoneNo, password, applicationConfig.LOGIN_LOGINMODE, applicationConfig.LOGIN_ACCESSTOKEN_URL, payload);

        super.afterLogin(request, response, remoteAddr, accessToken, phoneNo, payload, context);
    }

    @Override
    public boolean checkParams(LoginInfo loginInfo) {
        return !Util.isNull(loginInfo.getPhoneNo()) && !Util.isNull(loginInfo.getSmsCode()) && !Util.isNull(loginInfo.getUuid());
    }

    public boolean isValidSMSCode(HttpServletRequest request, HttpServletResponse response, String remoteAddr, LoginInfo loginInfo) throws IOException {
        String uuid = "SMS:" + loginInfo.getPhoneNo();
        String smsCode = loginInfo.getSmsCode();
        if (cacheProvider.isEqualsIgnoreCase(uuid, smsCode)) {
            return true;
        }
        BaseHandler.sendResponse(remoteAddr, BaseHandler.resBodyJson("500", "������֤��ͨ��", null), HttpServletResponse.SC_OK, request, response);
        return false;
    }

    public void sendSmsCode(HttpServletRequest request, HttpServletResponse response, String remoteAddr, String phoneNo) throws IOException {
        if (Util.isNull(phoneNo)) {
            BaseHandler.sendResponse(remoteAddr, BaseHandler.resBodyJson("500", "ȱʧ�ش�����", null), HttpServletResponse.SC_OK, request, response);
            return;
        }
        String timeControlKey = SMS_LOGIN_PREFIX + phoneNo + ":ts";
        Long timestamp = cacheProvider.getCache(timeControlKey);
        long curTimestamp = System.currentTimeMillis();
        if (timestamp != null && (curTimestamp - timestamp) <= 60 * 1000) {
            BaseHandler.sendResponse(remoteAddr, BaseHandler.resBodyJson(AuthAction.AUTH_CODE_ERROR, String.format("������֤���������Ƶ������%ds�����ԣ�", (60 - (int) (curTimestamp - timestamp) / 1000)), null), HttpServletResponse.SC_OK, request, response);
            return;
        }
        String uuid = SMS_LOGIN_PREFIX + phoneNo;
        String smsCode = NumberUtils.createSmsCode();
        cacheProvider.putCache(timeControlKey, curTimestamp, 60 * 1000, TimeUnit.MILLISECONDS);
        // TODO �ݹ̶�ֵ����
        cacheProvider.putCache(uuid, "123456");
        BaseHandler.sendResponse(remoteAddr, BaseHandler.resBodyJson(AuthAction.AUTH_CODE_SUCCESS, "success", null), HttpServletResponse.SC_OK, request, response);
    }
}
