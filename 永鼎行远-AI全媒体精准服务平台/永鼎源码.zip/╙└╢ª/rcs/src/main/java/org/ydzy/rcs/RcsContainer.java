package org.ydzy.rcs;

import java.lang.reflect.Method;
import java.security.SecureRandom;
import java.util.HashSet;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

import org.eclipse.jetty.server.HandlerContainer;
import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.servlet.ServletContextHandler;
import org.eclipse.jetty.servlet.ServletHolder;
import org.eclipse.jetty.util.StringUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.ydzy.handler.BaseRcsContext;
import org.ydzy.handler.BaseRcsContextProvidor;
import org.ydzy.handler.RcsSession;
import org.ydzy.rcs.annotation.Description;

import com.google.inject.Binder;
import com.google.inject.Inject;
import com.google.inject.Injector;
import com.google.inject.Key;
import com.google.inject.Module;
import com.google.inject.Provider;
import com.google.inject.Scopes;
import com.google.inject.Singleton;
import com.google.inject.name.Named;
import com.google.inject.name.Names;


/**
 * ��������, ʹ���ڲ��� ���贴��, ����������ע��
 * @author ljp
 *
 */
@Description("RcsContainer")
@Singleton
public class RcsContainer implements Module  {
	private static Logger log = LoggerFactory.getLogger(RcsContainer.class);
	
	@Override
	public void configure(Binder binder) {
		binder.bind(BaseRcsContextProvidor.class).toProvider(ContextContainer.class).in(Scopes.SINGLETON);
		binder.bind(RcsContainer.class).toInstance(this);
		binder.bind(Server.class).toProvider(this::getServer);
		binder.bind(RcsConfig.class).toProvider(this::getRcsConfig);
	}
	
	@Inject
	Injector injector = null;
	private Server server = null;
	public Server getServer() {
		return server;
	}
	public void setServer(Server server) {
		this.server = server;
		if(server!=null)initHandler();
	}
	protected void initHandler() {
		HashSet<Object> set = new HashSet<>();
		injectObject(server.getHandler(), set);
		injectObject(server.getHandlers(), set);
	}
	
	public <T> T  injectObject(T obj) {
		return injectObject(obj, null);
	}
	
	private void injectObject(Object[] handlers, Set<Object> finishedSet) {
		if(handlers==null)return;
		for(Object handler: handlers) {
			injectObject(handler, finishedSet);
		}
	}
	private <T> T injectObject(T obj, Set<Object> finishedSet) {
		if(obj!=null && (finishedSet==null || !finishedSet.contains(obj))) {
			if(finishedSet!=null)finishedSet.add(obj);
			injector.injectMembers(obj);
			if(obj instanceof HandlerContainer) {
				injectObject(((HandlerContainer)obj).getHandlers(), finishedSet);
			}
			if(obj instanceof ServletContextHandler) {
				ServletContextHandler sh = (ServletContextHandler)obj;
				if(sh.getServletHandler()!=null) {
					ServletHolder[] holders = sh.getServletHandler().getServlets();
					if(holders!=null && holders.length>0) {
						for(ServletHolder holder:holders) {
							Method m = null;
							Class<?> clazz = holder.getClass();
							while(!clazz.equals(Object.class)) {
								try {
									m =clazz.getDeclaredMethod("getInstance", new Class<?>[0]);
									break;
								}catch(Exception e) {
									//ignore
								}
								clazz = clazz.getSuperclass();
							}
							
							if(m!=null)try {
								m.setAccessible(true);
								Object o = m.invoke(holder, new Object[0]);
								injectObject(o, finishedSet);
							}catch(Exception e) {
								e.printStackTrace();
								//ignore
							}
						}
					}
				}
			}
			
		}
		return obj;
	}

	public < E > E reflect(Class<E> clazz) throws Exception{
		E instance;
	    if(clazz==null)
	    	throw new NullPointerException();
	    try {
	    	instance =   clazz.getDeclaredConstructor().newInstance();
	    }  catch (Exception e) {
	    	String msg = "new instance error" + clazz.getName() + "!";
	    	log.error(msg,e);
	    	throw new RuntimeException(msg, e);
	    }  
	    
		return injectObject(instance, null);
	}

	private RcsConfig rcsConfig = null;
	private static final String configFrom = "rcs.configFrom";
	private RcsConfig getRcsConfig() {
		synchronized (this) {
			if(rcsConfig==null) {
				String from = null;
				try {
					from = injector.getInstance(Key.get(String.class, Names.named(configFrom)));
				}catch(Exception e) {
					log.debug("No name(" + configFrom + ") config from injector!");
				}
				if((from==null || from.isEmpty()) && server!=null) {
					Object o = server.getAttribute(configFrom);
					if(o!=null) {
						from = o.toString();
					}else {
						log.debug("No name(" + configFrom + ") config from jetty server attribute!");
					}
				}
				if(from==null || from.isEmpty()) {
					from = "rcsDbConfig"; //Jsonfile
				}
				log.info("Load rcs config from name(" + from + ")...");
				Named nm = Names.named(String.valueOf(from));
				rcsConfig = injector.getInstance(Key.get(RcsConfig.class, nm));
			}
		}
		return rcsConfig;
	}
	
	@Singleton
	protected static class ContextContainer implements Provider<BaseRcsContextProvidor>,BaseRcsContextProvidor{
		@Override
		public BaseRcsContextProvidor get() {
			return this;
		}
		
		@Override
		public BaseRcsContext newBaseRcsContext() {
			return new BaseRcsContext(getRcsConfig()) {
				@Override
				public RcsSession getOrCreateSession(String sessionid) {
					return ContextContainer.this.getSession(sessionid);
				}

				@Override
				protected String newSessionId() {
					return ContextContainer.this.newSessionId(System.currentTimeMillis());
				}
			};
		}
		
		private RcsConfig rcsConfig = null;
		@Inject
		public void setRcsConfig(RcsConfig rcsConfig) {
			this.rcsConfig = rcsConfig;
		}
		
		public RcsConfig getRcsConfig() {
			return rcsConfig;
		}
		/**  ȫ�ֻỰ���� */
		private Map<String, RcsSessionMap> sessionManager = new ConcurrentHashMap<String, RcsSessionMap>();
		public RcsSessionMap getSession(String key) {
			if(key==null)return null;
			RcsSessionMap s = sessionManager.get(key);
			if(s==null)s= new RcsSessionMap(key);
			sessionManager.put(key, s);
			return s;
		}
		
		
	    protected Random _random = new java.util.Random();
	    protected boolean _weakRandom = false;
	    protected String _workerName = "rcs";
	    protected static final AtomicLong COUNTER = new AtomicLong();
	    protected long _reseed = 100000L;
	    /**
	     * @param seedTerm the seed for RNG
	     * @return a new unique session id
	     */
	    public String newSessionId(long seedTerm)
	    {
	    	// pick a new unique ID!
	    	String id = null;
	    	while (id == null || id.length() == 0)
	    	{
	    		long r0 = _weakRandom
	    				? (hashCode() ^ Runtime.getRuntime().freeMemory() ^ _random.nextInt() ^ ((seedTerm) << 32))
	    						: _random.nextLong();
	    				if (r0 < 0)
	    					r0 = -r0;

	    				// random chance to reseed
	    				if (_reseed > 0 && (r0 % _reseed) == 1L)
	    				{
	    					if (log.isDebugEnabled())
	    						log.debug("Reseeding {}", this);
	    					if (_random instanceof SecureRandom)
	    					{
	    						SecureRandom secure = (SecureRandom)_random;
	    						secure.setSeed(secure.generateSeed(8));
	    					}
	    					else
	    					{
	    						_random.setSeed(_random.nextLong() ^ System.currentTimeMillis() ^ seedTerm ^ Runtime.getRuntime().freeMemory());
	    					}
	    				}

	    				long r1 = _weakRandom
	    						? (hashCode() ^ Runtime.getRuntime().freeMemory() ^ _random.nextInt() ^ ((seedTerm) << 32))
	    								: _random.nextLong();
	    						if (r1 < 0)
	    							r1 = -r1;

	    						id = Long.toString(r0, 36) + Long.toString(r1, 36);

	    						//add in the id of the node to ensure unique id across cluster
	    						//NOTE this is different to the node suffix which denotes which node the request was received on
	    						if (!StringUtil.isBlank(_workerName))
	    							id = _workerName + id;

	    						id = id + Long.toString(COUNTER.getAndIncrement());
	    	}
	    	return id;
	    }

	}

	protected static class RcsSessionMap extends ConcurrentHashMap<String, Object> implements RcsSession{

		private String id;
		private long createTime;
		public RcsSessionMap(String id) {
			super();
			this.id = id;
			this.createTime = System.currentTimeMillis();
		}

		@Override
		public long getCreateTime() {
			return createTime;
		}

		@Override
		public String getSessionId() {
			return id;
		}
		
	}


}
