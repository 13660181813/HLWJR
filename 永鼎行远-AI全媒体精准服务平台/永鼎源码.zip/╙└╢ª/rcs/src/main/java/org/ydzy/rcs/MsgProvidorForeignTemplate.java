package org.ydzy.rcs;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.concurrent.ConcurrentHashMap;

import javax.sql.DataSource;

import org.ydzy.bot.BotUtil;
import org.ydzy.handler.BaseRcsContext;
import org.ydzy.rcs.entity.ReceiveEntity;
import org.ydzy.rcs.impl.TemplateCardContent;
import org.ydzy.util.SqlUtil;
import org.ydzy.util.Util;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.inject.Inject;
import com.google.inject.name.Named;

/**
 * ���ģ�� �ؼ��ֹ�������
 * @author ljp
 *
 */
public class MsgProvidorForeignTemplate implements IMsgProvidor {

	static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(MsgProvidorForeignTemplate.class);
	
	protected static class ForeignTemplate{
		JsonObject msgObject;
		
		String sourceTable;
		String keywordField;
		String sql;
	}
	
	/** ���ݿ����� */
	@Inject
	@Named("rcsDb.DbType")
	private String dbTypestr;
	public String getDbTypestr() {
		return dbTypestr;
	}

	/** ���ݿ�����*/
	@Inject
	@Named("rcsDb")
	private DataSource dataSource;
	public DataSource getDataSource() {
		return dataSource;
	}

	String name;
	public MsgProvidorForeignTemplate(String name){
		this.name = name;
	}
	protected Map<String, ForeignTemplate> cacheKeyword = new ConcurrentHashMap<String,ForeignTemplate>();
	protected Map<String, ForeignTemplate> msgList = new ConcurrentHashMap<String,ForeignTemplate>();
	
	@Override
	public boolean checkAddConfig(JsonObject eobject) {
		// �ж��Ƿ�ʱ���ģ��
		JsonElement je = eobject==null?null:eobject.get("content");
		JsonArray content = je!=null&&je.isJsonArray()? je.getAsJsonArray():null;
		if(content!=null && content.isJsonArray() && content.getAsJsonArray().size()>=1) {
			JsonObject cobject = content.getAsJsonArray().get(0).getAsJsonObject();
			String isTemplate=Util.getElementAsString(cobject,"isTemplate");
			String source_tablename =Util.getElementAsString(cobject, "source_tablename");
			
			if("1".equals(isTemplate) && !Util.isNull(source_tablename)){
				ForeignTemplate ft = new ForeignTemplate();
				ft.sourceTable=source_tablename;
				ft.keywordField = isTemplate=Util.getElementAsString(cobject,"source_keywordField");
				ft.sql = isTemplate=Util.getElementAsString(cobject,"source_paramSql");
				
				ft.msgObject = eobject.deepCopy();
				JsonArray ja = new JsonArray();
				ja.add(cobject);
				ft.msgObject.remove("content");
				ft.msgObject.add("content", ja);
				
				String type = Util.getElementAsString(eobject,"type");
				if("multicard".equals(type) || "singlecard".equals(type)) {
					ft.msgObject.addProperty("type", TemplateCardContent.TYPE);
				}
				
				String configid = Util.getElementAsString(eobject,"configid");
				msgList.put(configid, ft);
				return true;
			}
		}
		return false;
		
	}
	
	/** �Ƿ���ɳ�ʼ��*/
	protected boolean inited = false;
	/**
	 * ���ݳ�ʼ��
	 */
	protected synchronized void init() {
		if(inited)return;
		try {
			for(Map.Entry<String, ForeignTemplate> e:msgList.entrySet()) {
				ForeignTemplate ft = e.getValue();
				String sql = null;
				if(!Util.isNull(ft.keywordField)) {
					if(ft.keywordField.toUpperCase().indexOf(" FROM ")>0) {
						sql = ft.keywordField;
					}else {
						sql = String.format("SELECT distinct %s keywords from %s", ft.keywordField, ft.sourceTable);
					}
				}
				if(!Util.isNull(sql))try {
					List<String> keywordList = new ArrayList<>();
					JsonArray results = SqlUtil.queryForJson(dataSource, sql);
					if(results!=null&&results.size()>0)for(int i=0;i<results.size();i++){
						JsonObject ro = results.get(i).getAsJsonObject();
						String key=Util.getElementAsString(ro, "keywords");
						if(!Util.isNull(key))keywordList.add(key);
						log.debug("Got {} keywords for msg({}) by sql:", keywordList.size(), e.getKey(), sql);
					}
					keywordList.forEach( k -> cacheKeyword.put(k, ft));
				} catch (SQLException e1) {
					log.warn("Error, get keyword for msg(" + e.getKey() + ") by sql:" + sql, e1);
				}
			}
			log.info("Load {} foreign template keywords finished, total {} words loaded", name, cacheKeyword.size());
		}finally {
			inited = true;
		}
	}
	
	public void reset() {
		cacheKeyword.clear();
		msgList.clear();
		inited = false;
	}
	
	@Override
	public List<JsonObject> getKeyWordsArray(String keywords, int maxCount) {
		if(!inited)init();
		ForeignTemplate o = cacheKeyword.get(keywords);
		return (o==null)?null:Arrays.asList(o.msgObject);
	}

	@Override
	public boolean loadParas(JsonElement efind, BaseRcsContext context, ReceiveEntity receiveEntity, BodyTransform transform) {
		if(efind==null || !efind.isJsonObject())return false;
		JsonObject eobject = efind.getAsJsonObject();
		String configid = Util.getElementAsString(eobject,"configid");
		ForeignTemplate ft = msgList.get(configid);
		if(ft==null)return false;
		String rawSql = ft.sql;;
		if(Util.isNull(rawSql)) {
			rawSql = String.format("select * from %s where %s='{content}'", ft.sourceTable, ft.keywordField);
		}
		String sql = BotUtil.mustache(rawSql, receiveEntity, context);
		try {
			List<Map<String,Object>> list = new ArrayList<>();
			JsonArray results = SqlUtil.queryForJson(dataSource, sql);
			if(results!=null&&results.size()>0)for(int i=0;i<results.size();i++){
				//{msgId=3707, tempId=609, params={image=https://csp.bjydzy.com:20443/hw/media/uploadHw01630382748767.jpg, title=����, desc=��ī�̡���ͭ�����ŵú�ʱ��}}
				//List<Map<String,Object>>
				Map<String, Object> map = new TreeMap<>();
				map.put("msgId", configid);
				map.put("tempId", String.valueOf(i));
				Map<String, Object> params = new TreeMap<>();
				if(results.get(i).isJsonObject()) {
					results.get(i).getAsJsonObject().entrySet().forEach(e -> params.put(e.getKey(), e.getValue().isJsonNull()?"":e.getValue().getAsString()));
				}
				map.put("params", params);
				list.add(map);
			}
			context.getAttributes().put(TemplateCardContent.FOREIGN_TEMPLATE_MODEL_PARAM, list);
			//�����ϵ�д��
			context.getAttributes().put("modelParams_"+configid, list);
			return true;
		} catch (SQLException e1) {
			log.warn("Error, loadParas for msg(" + configid + ") by sql:" + sql, e1);
		}
		return false;
	}

	@Override
	public  Map<String, JsonObject> getKeysV() {
		if(!inited)init();
		if(cacheKeyword!=null&&cacheKeyword.size()>0)
		{
			Map<String, JsonObject> result =new HashMap<String,JsonObject>();
			cacheKeyword.forEach((k,v)->{
				result.put(k, v.msgObject);
			});
			return result;
		}
		else
			return null;
	}
}
