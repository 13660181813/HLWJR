package org.ydzy.util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**�ֻ����� ��ȡ
 * @author XFDEP
 *
 */
public class ValidateUtil {
	public static Pattern  mdnnumber = Pattern.compile("(\\+86)?(14[75]|13[0-9]|15[0-9]|153|156|1[7-9][0-9])[0-9]{8}|\\d{3}-\\d{7,8}|\\d{4}-\\d{7,8}");
 
	/**��ȡ�ֻ�����  
	 * @param phone
	 * @return
	 */
	public static String validatePhone(String phone)
	{
		Matcher number_callerID = mdnnumber.matcher(phone);
		if(number_callerID.find())
		return number_callerID.group();
		else
			return "";
	}
	public static void main(String[] args) {
		System.out.println("dd+8617095586236 ========"+validatePhone("dd+8617095586236"));
		System.out.println("17095586236    ========"+validatePhone("17095586236"));
		System.out.println("19899445865    ========"+validatePhone("19899445865"));
		System.out.println("1989944585     ========"+validatePhone("1989944585"));
		System.out.println("010-8128731     ========"+validatePhone("010-8128731"));
		System.out.println("01081287312    ========"+validatePhone("01081287312"));
		System.out.println("012381287312   ========"+validatePhone("012381287312"));
		System.out.println("012-38128731    ========"+validatePhone("0123-8128731"));
		System.out.println("0123812873     ========"+validatePhone("012381287"));
	}
	
}
