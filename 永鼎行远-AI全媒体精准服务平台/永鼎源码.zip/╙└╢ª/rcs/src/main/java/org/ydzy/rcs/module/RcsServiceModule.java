package org.ydzy.rcs.module;

import com.google.inject.Binder;
import com.google.inject.Module;
import com.google.inject.Scope;
import com.google.inject.Scopes;
import com.google.inject.name.Names;
import org.ydzy.rcs.annotation.Description;
import org.ydzy.rcs.impl.CssStyleService;
import org.ydzy.rcs.impl.MoveTaskService;
import org.ydzy.rcs.impl.OperationLogService;

/**
 * @author zxw
 * @create 2022/1/28
 */
@Description("rcsServiceModule")
public class RcsServiceModule implements Module {
    @Override
    public void configure(Binder binder) {
        binder.bind(CssStyleService.class).annotatedWith(Names.named("cssStyleService")).to(CssStyleService.class).in(Scopes.SINGLETON);
        binder.bind(OperationLogService.class).annotatedWith(Names.named("operationLogService")).to(OperationLogService.class).in(Scopes.SINGLETON);
        binder.bind(MoveTaskService.class).annotatedWith(Names.named("taskService")).to(MoveTaskService.class).in(Scopes.SINGLETON);
    }
}
