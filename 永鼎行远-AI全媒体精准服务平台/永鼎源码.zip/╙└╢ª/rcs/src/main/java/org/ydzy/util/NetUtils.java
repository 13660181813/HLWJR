package org.ydzy.util;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.security.KeyManagementException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.text.SimpleDateFormat;
import java.util.Base64;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.KeyManager;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.eclipse.jetty.http.MimeTypes;
import org.eclipse.jetty.util.IO;
import org.ydzy.rcs.media.FileUpload;

import com.google.gson.Gson;
import com.google.gson.JsonElement;


public class NetUtils {
	private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(NetUtils.class);
	 /** ���ڸ�ʽ����Ȩͷ��,��"X-WSSE"������ֵ */
    public static final String WSSE_HEADER_FORMAT = "UsernameToken Username=\"%s\",PasswordDigest=\"%s\",Nonce=\"%s\",Created=\"%s\"";
    /**
     * ����X-WSSE����ֵ
     * 
     * @param appKey
     * @param appSecret
     * @return
     */
    public static String buildWsseHeader(String appKey, String appSecret) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
        String time = sdf.format(new Date());
        String nonce = UUID.randomUUID().toString().replace("-", "");

        MessageDigest md;
        byte[] passwordDigest = null;

        try {
            md = MessageDigest.getInstance("SHA-256");
            md.update((nonce + time + appSecret).getBytes());
            passwordDigest = md.digest();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        String passwordDigestBase64Str = Base64.getEncoder().encodeToString(passwordDigest);
        return String.format(WSSE_HEADER_FORMAT, appKey, passwordDigestBase64Str, nonce, time);
    }
    public static  Map<String, Object> buildHwCommonHeader(String appKey,String appSecret)
    {
    	 Map<String, Object> headers =new HashMap<String,Object>();
         headers.put("Accept", "application/json");
         headers.put("Content-Type", "application/json;charset=UTF-8");
         headers.put("Authorization",
                 "WSSE realm=\"SDP\", profile=\"UsernameToken\", type=\"Appkey\"");
         headers.put("X-WSSE", NetUtils.buildWsseHeader(appKey, appSecret));
         return headers;
    }
    /**
     * ��ֵ��ת��ѯurl
     * 
     * @param map
     * @return
     */
    public static String map2UrlEncodeString(Map<String, Object> map) {
        if(null == map || map.isEmpty()) {
            return "";
        }
        StringBuilder sb = new StringBuilder();
        String temp = "";

        for (String s : map.keySet()) {
            try {
                temp = URLEncoder.encode(String.valueOf(map.get(s)), "UTF-8");
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }
            sb.append(s).append("=").append(temp).append("&");
        }
        return sb.deleteCharAt(sb.length() - 1).toString();
    }
	private static final org.slf4j.Logger logger = org.slf4j.LoggerFactory.getLogger(NetUtils.class);
	// ����ֵ�ķ��سɹ�״̬��
	static final int SUCCESS_200_RES = 200;

	// ����ֵ�ķ��سɹ�״̬��
	static final int SUCCESS_201_RES = 201;

	// ����ֵ�ķ��سɹ�״̬��
	static final int SUCCESS_204_RES = 204;
	
	static final Charset UTF_8 = Charset.forName("UTF-8");

	/**
	 * ���ò���֤����
	 */

	private static final HostnameVerifier DO_NOT_VERIFY = (hostname, session) -> true;

	public static ByteBuffer getMultiPartBody( String filepath,String contentType,String boundary)
	{
		ByteBuffer buffer=ByteBuffer.allocateDirect(214000000); 
			String url=filepath;
			
			java.io.File file=new java.io.File(url);
			if(file.exists())
			{
				String filename=file.getName();
				StringBuffer strtBuf=new StringBuffer();
				strtBuf.append("\r\n").append("--").append(boundary).append("\r\n");
				strtBuf.append("Content-Disposition: form-data; name=\"file\"; filename=\""+filename+"\"\r\n");
//	    	strtBuf.append("Content-Length=\""+file.length()+"\"");
				strtBuf.append("Content-Type: "+contentType+"\r\n\r\n");//\r\nContent-Transfer-Encoding: base64
				buffer.put(strtBuf.toString().getBytes());
				try {
					buffer.put((Files.readAllBytes(Path.of(url))));
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			buffer.put(("\r\n--"+boundary+"--\r\n").getBytes());
			return buffer;
	}
	public static String doHttps(String url, Object body, Map<String, Object> headers, String contentType,String method)throws IOException 
	{

		if(Util.isNull(url))
			return null;
		URL realUrl = new URL(url);
		String protocol=realUrl.getProtocol();
		 
		final URLConnection connection ;
		if("https".equals(protocol))
		{
			if(body==null)
				connection=	getHttpsURLConnection(url, Util.isNull(method)?"GET":method);
			else
				connection=getHttpsURLConnection(url, Util.isNull(method)?"POST":method);	
		}else
			connection	=  realUrl.openConnection();
//		URLConnection connection =  realUrl.openConnection();
		if(headers!=null)
		{
			headers.forEach((k, v) -> {
				connection.addRequestProperty(k, Util.toString(v));
			});
		}
		connection.setConnectTimeout(2000);
		connection.setReadTimeout(360000);
		// ��������ʽ
		connection.setDoOutput(true);
//		        connection.setHostnameVerifier(DO_NOT_VERIFY);
		
		if (connection instanceof HttpsURLConnection) {
			if(body==null) {
				((HttpsURLConnection) connection).setRequestMethod(Util.isNull(method)?"GET":method);
			}
			else			
				((HttpsURLConnection) connection).setRequestMethod(Util.isNull(method)?"POST":method);
		}
		else {
			if (connection instanceof HttpURLConnection) {
				if(body==null)
					((HttpURLConnection) connection).setRequestMethod(Util.isNull(method)?"GET":method);
				else			
					((HttpURLConnection) connection).setRequestMethod(Util.isNull(method)?"POST":method);
				 
			}
		}
		
//	        connection.setRequestProperty("Authorization", "Username=\"chatbottest12swt96\", Password=\"123456\"");
		if (body != null) {
			if(!Util.isNull(contentType))
			connection.setRequestProperty("Content-Type", contentType);
			if(body instanceof JsonElement)
			{
				body=new Gson().toJson(body);
			}
			if (body instanceof String && !Util.isNull(body.toString())) {
				PrintWriter pw = new PrintWriter(new OutputStreamWriter(connection.getOutputStream(), UTF_8));
				pw.write(body.toString());
				pw.close();
			}else if (body instanceof byte[]) {
				OutputStream pw = new DataOutputStream(connection.getOutputStream());
				pw.write((byte[]) body);
				pw.flush();
				pw.close();
			}else if(body instanceof ByteBuffer) {
				OutputStream out = connection.getOutputStream();
				ByteBuffer buff = (ByteBuffer) body;
				buff.flip();
				byte[] bytes = new byte[1024];
				while(buff.remaining()>0) {
					int l;
					if(buff.remaining()>bytes.length) {
						l = bytes.length;
					}else {
						l = buff.remaining();
					}
					buff.get(bytes, 0, l);
					out.write(bytes);
				}
				out.close();
			}

		}
		if (connection instanceof HttpsURLConnection) {
			((HttpsURLConnection) connection).setHostnameVerifier(DO_NOT_VERIFY);
		}

		connection.connect();
		// ���������Ϣ��ʵ��ʹ��ʱȥ��
		outConnInfo(connection, realUrl);
		int status=0;
		if (connection instanceof HttpsURLConnection) {
			status = ((HttpsURLConnection) connection).getResponseCode();
		}
		else {
			status = ((HttpURLConnection) connection).getResponseCode();
		}
	
		InputStream is;
		if (status != SUCCESS_200_RES) {
			logger.error("http Error,url{}  status:{} headers {} body {}" , url,status,headers,body);
			if (status == SUCCESS_201_RES) {
				is = connection.getInputStream();
			} else if (status == SUCCESS_204_RES) {
				logger.warn("No Content Success");
				is = connection.getInputStream();
			} else { // error
			
				
				if (connection instanceof HttpsURLConnection) {
					is = ((HttpsURLConnection) connection).getErrorStream();
				}
				else {
					is = ((HttpURLConnection) connection).getErrorStream();
				}
			}
		} else { // 200
			//logger.warn("OK, Success,  status: " + status);
			is = connection.getInputStream();
		}

		if (is != null) {
			BufferedReader br;
			br = new BufferedReader(new InputStreamReader(is, "UTF-8"));
			String line;
			StringBuilder result = new StringBuilder();

			// ��ȡ����
			while ((line = br.readLine()) != null) {
				result.append(line + System.lineSeparator().intern());
			}
			br.close();
//			logger.warn("Content: " + result.toString());

			// ����
			is.close();
			return result.toString();
		}
		// �ر�����
		return "";
	
	}
	public static String doHttps(String url, Object body, Map<String, Object> headers, String contentType)
			throws IOException {
		return doHttps(url, body, headers, contentType,null);
	}

	
	public static String doHttpsWriteFiles(String url, Object body, Map<String, Object> headers, String contentType,String outputFile)
			throws IOException {
		URL realUrl = new URL(url);
		String protocol=realUrl.getProtocol();
		 
		final URLConnection connection ;
		if("https".equals(protocol))
		{
			if(body==null)
				connection=	getHttpsURLConnection(url, "GET");
			else
				connection=getHttpsURLConnection(url, "POST");	
		}else
			connection	=  realUrl.openConnection();
		if(headers!=null)
		{
			headers.entrySet().forEach(k -> {
				connection.addRequestProperty(k.getKey(), Util.toString(k.getValue()));
			});
		}
		// ��������ʽ
		connection.setDoOutput(true);
//		        connection.setHostnameVerifier(DO_NOT_VERIFY);
		if(connection instanceof HttpURLConnection)
		if(body==null)
			((HttpURLConnection)connection).setRequestMethod("GET");
		else			
			((HttpURLConnection)connection).setRequestMethod("POST");
//	        connection.setRequestProperty("Authorization", "Username=\"chatbottest12swt96\", Password=\"123456\"");
		if (body != null) {
			if(!Util.isNull(contentType))
			connection.setRequestProperty("Content-Type", contentType);
			if (body instanceof String) {
				PrintWriter pw = new PrintWriter(new OutputStreamWriter(connection.getOutputStream(), UTF_8));
				pw.write(body.toString());
				pw.close();
			}else if (body instanceof byte[]) {
				OutputStream pw = new DataOutputStream(connection.getOutputStream());
				pw.write((byte[]) body);
				pw.flush();
				pw.close();
			}else if(body instanceof ByteBuffer) {
				OutputStream out = connection.getOutputStream();
				ByteBuffer buff = (ByteBuffer) body;
				buff.flip();
				byte[] bytes = new byte[1024];
				while(buff.remaining()>0) {
					int l;
					if(buff.remaining()>bytes.length) {
						l = bytes.length;
					}else {
						l = buff.remaining();
					}
					buff.get(bytes, 0, l);
					out.write(bytes);
				}
				out.close();
			}

		}
		if (connection instanceof HttpsURLConnection) {
			((HttpsURLConnection) connection).setHostnameVerifier(DO_NOT_VERIFY);
		}

		connection.connect();
		// ���������Ϣ��ʵ��ʹ��ʱȥ��
		outConnInfo(connection, realUrl);
		int status =0;
		if(connection instanceof HttpURLConnection)
			status=((HttpURLConnection)connection).getResponseCode();
		else
			status=((HttpsURLConnection) connection).getResponseCode();
		InputStream is;
		if (status != SUCCESS_200_RES) {
			if (status == SUCCESS_201_RES) {
				is = connection.getInputStream();
			} else if (status == SUCCESS_204_RES) {
				logger.warn("No Content Success");
				is = connection.getInputStream();
			} else { // error
				logger.warn("Error,  status: " + status);
				if(connection instanceof HttpURLConnection)
				is = ((HttpURLConnection)connection).getErrorStream();
				else
					is = ((HttpsURLConnection) connection).getErrorStream();
			}
		} else { // 200
			logger.warn("OK, Success,  status: " + status);
			is = connection.getInputStream();
		}
		try ( 
				OutputStream outputStream = Files.newOutputStream(new File(outputFile).toPath(), StandardOpenOption.CREATE,
						 StandardOpenOption.TRUNCATE_EXISTING)) {
				IO.copy(is, outputStream);
			} catch (Exception e) {
				e.toString();
			}
		// �ر�����
//		connection.disconnect();
		return "";
	}

	/**
	 * ���������Ϣ ,ʵ��ҵ���漰
	 */
	private static void outConnInfo(URLConnection conn, URL url) throws IOException {
		Logger logger = Logger.getLogger(FileUpload.class.getName());
		logger.setLevel(Level.WARNING);
//		logger.warning("conn.getResponseCode():" + conn.getResponseCode());
//		logger.warning("conn.getURL():" + conn.getURL());
//		logger.warning("conn.getRequestMethod():" + conn.getRequestMethod());
//		logger.warning("conn.getContentType():" + conn.getContentType());
//		logger.warning("conn.getReadTimeout():" + conn.getReadTimeout());
//		logger.warning("conn.getResponseMessage():" + conn.getResponseMessage());
//		logger.warning("url.getDefaultPort():" + url.getDefaultPort());
//		logger.warning("url.getFile():" + url.getFile());
//		logger.warning("url.getHost():" + url.getHost());
//		logger.warning("url.getPath():" + url.getPath());
//		logger.warning("url.getPort():" + url.getPort());
//		logger.warning("url.getProtocol():" + url.getProtocol());
	}
	
	public static  String mimeContentType(String filename)
    {
		return  MimeTypes.getDefaultMimeByExtension(filename);
    	
    }
	public static void main(String[] args) throws IOException {
		
		String url="http://192.168.9.132:8080/1/1.zip";
		doHttps(url, null, null, "application/zip");
		
	}
	private static final class DefaultTrustManager implements X509TrustManager {
        @Override
        public void checkClientTrusted(X509Certificate[] chain, String authType) throws CertificateException {
        }

        @Override
        public void checkServerTrusted(X509Certificate[] chain, String authType) throws CertificateException {
        }

        @Override
        public X509Certificate[] getAcceptedIssuers() {
            return null;
        }
    }
	
	public static HttpsURLConnection getHttpsURLConnection(String uri, String method) throws IOException {
		TrustManager[] trustAllCerts = new TrustManager[] { new X509TrustManager() {
            public void checkClientTrusted(X509Certificate[] chain, String authType) throws CertificateException {
                return;
            }

            public void checkServerTrusted(X509Certificate[] chain, String authType) throws CertificateException {
                return;
            }

            public X509Certificate[] getAcceptedIssuers() {
                return null;
            }
        } };
        SSLContext ctx = null;
        try {
            ctx = SSLContext.getInstance("TLS");
//            ctx.init(new KeyManager[0], new TrustManager[] { new DefaultTrustManager() }, new SecureRandom());
            ctx.init(new KeyManager[0], trustAllCerts, new SecureRandom());
        } catch (KeyManagementException e) {
            e.printStackTrace();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        SSLSocketFactory ssf = ctx.getSocketFactory();

        URL url = new URL(uri);
        HttpsURLConnection httpsConn = (HttpsURLConnection) url.openConnection();
        httpsConn.setSSLSocketFactory(ssf);
        httpsConn.setHostnameVerifier(new HostnameVerifier() {
            @Override
            public boolean verify(String arg0, SSLSession arg1) {
                return true;
            }
        });
        httpsConn.setRequestMethod(method);
//        httpsConn.setDoInput(true);
        httpsConn.setDoOutput(true);
        return httpsConn;
    }
}
