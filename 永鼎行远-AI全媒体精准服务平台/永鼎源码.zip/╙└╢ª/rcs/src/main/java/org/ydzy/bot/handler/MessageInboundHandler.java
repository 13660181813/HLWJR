package org.ydzy.bot.handler;
import java.io.IOException;
import java.nio.charset.Charset;
import java.util.Base64;
import java.util.Map;

import javax.sql.DataSource;

import org.eclipse.jetty.server.Request;
import org.ydzy.bot.BotInfo;
import org.ydzy.bot.BotUtil;
import org.ydzy.handler.BaseHandler;
import org.ydzy.publish.ConstantTopics;
import org.ydzy.publish.IPublisher;
import org.ydzy.publish.SubscribeCaches;
import org.ydzy.publish.SubscribePublish;
import org.ydzy.rcs.action.RcsLogAction;
import org.ydzy.rcs.action.RcsRunLogAction;
import org.ydzy.util.StreamsUtil;
import org.ydzy.util.Util;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.inject.Inject;
import com.google.inject.name.Named;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
  * �й��ƶ�MAAP�ӿ�
  *  3.5	��Ϣ����֪ͨ
3.5.1	��Ϣ��;
���ڹٷ�CSPƽ̨��Chatbot����������Ϣ�ĳ�����
3.5.2	����
HTTPS��POST
URL��https://{callbackURL}/InboundMessageNotification/{chatbotURI}
 */
public  class MessageInboundHandler extends BaseBotHandler  implements IPublisher<JsonObject>{
	private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(MessageInboundHandler.class);


	@Inject
	@Named("rcsDb")
	protected DataSource ds;
	
	@Inject(optional=true)
	protected RcsLogAction rcsLogAction = null;
	
	/** ����driving����,  0 ���������������˹���ϯ,ֱ��ת�� */
	@Inject(optional=true)
	@Named("transfer.defaultDriving")
	protected String defaultDriving = "0";

	@Inject
	SubscribeCaches subscribeCaches;

	Gson gson = new Gson();
	
	@Override
	public void handle(String target, Request baseRequest, HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException{
		baseRequest.setHandled(true);
		BotInfo bi = null;
		try {
			bi = verifyChatbot(request, response);
		}catch(VerifyError e) { 
			response.setStatus(HttpServletResponse.SC_FORBIDDEN);
			response.setContentType("application/json");
			JsonObject jo = new JsonObject();
			jo.addProperty("errorMsg", e.getMessage());
			// Write back response
			response.getWriter().println(jo.toString());
			log.debug("Sinagure error(" + e.getMessage() + "!");
			return;
		}
		long start = System.currentTimeMillis();
		String address=BaseHandler.getIpAddress(request);
		// Content-Type: text/xml; charset=utf-8
		String contentType = request.getContentType();
		String body = StreamsUtil.copyToString(request.getInputStream(), Charset.forName("UTF-8"));
		if(log.isDebugEnabled())log.debug(",receive {} from remoteAddr {}  ", body, address);
		if(contentType==null)contentType="text/xml";
		
		JsonObject object = null;
		String code = null,msg = null;
		if(contentType.startsWith("text/xml")) {
			Map<String,String> map = BotUtil.xml2Map(body, "inboundMessage");
			if(map!=null && map.size()>0) {
				if(ds!=null)RcsRunLogAction.recordLog("receiveMessage","reqbody:"+body+" ; ", address, "200", "MessagesHandler", ds);
				object = handle(bi, gson.toJsonTree(map).getAsJsonObject(), address);
			}else {
				code = "2001";
				msg = "No inboundMessage message found";
			}
		}else if(contentType.startsWith("application/json")) {
			if (!Util.isNull(body)) {
				JsonElement ele = JsonParser.parseString(body);
				object = ele.getAsJsonObject();
				if(ds!=null)RcsRunLogAction.recordLog("receiveMessage","reqbody:"+body+" ; ", address, "200", "MessagesHandler", ds);
				this.handle(bi, object, address);
			}else {
				code = "2001";
				msg = "No inboundMessage message found";
			}
		}else {
			code = "2002";
			msg = "Unknow contentType:" + contentType;
		}
		boolean succ = code==null;
		if(succ) {
			code = "0";
			msg = "success";
		}
		String resBody = resBodyJson(code, msg, null);
		sendResponse(address, resBody, HttpServletResponse.SC_OK, request, response);
		if(rcsLogAction!=null && object!=null) {
			rcsLogAction.log(request, response, body, object, resBody, (int)(System.currentTimeMillis() - start), succ);
		}
		return;
	}

	public JsonObject handle(BotInfo bi,JsonObject object, String remoteAddr) {
		JsonObject jo = new JsonObject();
		jo.add("receive5GMsg", object);
		jo.addProperty("remoteAddr", remoteAddr);
		jo.addProperty("chatBotID", bi.getChatbotId());
		jo.addProperty("driving", defaultDriving);
		//jo.addProperty("chatbodid", Util.getElementAsString(bi.getInfos(),"chatbotIdenty"));
		String content = BotUtil.getElementAsString(object, "bodyText");
		if(content!=null && content.length()>0) {
			String cType = BotUtil.getElementAsString(object, "contentType");
			if(cType!=null && cType.startsWith("text/plain")) {
				if("base64".equalsIgnoreCase(BotUtil.getElementAsString(object, "contentEncoding"))){
					byte[] buff = Base64.getDecoder().decode(content.getBytes(BotUtil.utf8));
					content = new String(buff, BotUtil.utf8);
				}
			}else if(cType.startsWith("application/vnd.gsma.botsuggestion.response.v1.0+json")) {
				 JsonElement je = JsonParser.parseString(content);
				 JsonObject jo1 = je.getAsJsonObject();
				 je = BotUtil.getElement(jo1, new String[] {"response","reply","postback", "data"});
				 if(je!=null && !je.isJsonNull()) {
					 content = je.getAsString();;
				 }else {
					 content = "";
				 }
			}
			jo.addProperty("content", content);
		}
		SubscribePublish<JsonObject> sub= subscribeCaches.getSubscribePublishInstance(ConstantTopics.CHARTBOT_MSG_MOBILERECEIVE, JsonObject.class);
		this.publish(sub, jo, false);
		return jo;
	}
	
	@Override
	public void publish(SubscribePublish<JsonObject> subscribeObj, JsonObject message, boolean isInstantMsg) {
		subscribeObj.publish(ConstantTopics.CHARTBOT_MSG_MOBILERECEIVE+"_Subscribers", message, isInstantMsg);
	}
	
}