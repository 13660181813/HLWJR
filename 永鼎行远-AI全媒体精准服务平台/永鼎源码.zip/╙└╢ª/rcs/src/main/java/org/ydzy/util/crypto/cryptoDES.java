/*
 * @(#)DES.java
 */
package org.ydzy.util.crypto;

import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;

import javax.crypto.Cipher;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;

import org.ydzy.util.Util;

public class cryptoDES {

    /**
     * 瀵嗛挜
     */
    private static final byte[] KEY = "tl#$ddi@fibjxczymdsoss2008".getBytes();

    /**
     * 鍔犲瘑
     * 
     * @param encryptdata
     * @return
     * @throws Exception
     */
    public static String encode(String encryptdata) {
        try {
            return encode(KEY,encryptdata);
        } catch (Exception e) {
            return "[ERROR]";
        }
    }
    public static String encode(String key,String encryptdata) {
    	try {
    		if(Util.isNull(key))
    			return "[ERROR]" +"瀵嗛挜涓虹┖";
    		if(Util.isNull(encryptdata))
    			return "";
    		byte [] keys=key.getBytes();
    		return encode(keys,encryptdata);
    	} catch (Exception e) {
    		return "[ERROR]";
    	}
    }
    static  SecureRandom sr = new SecureRandom();
    static SecretKeyFactory keyFactory ;
    static Cipher cipher ;
    static
    {
    	try {
			keyFactory = SecretKeyFactory.getInstance("DES");
			cipher = Cipher.getInstance("DES/ECB/PKCS5Padding");
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		} catch (NoSuchPaddingException e) {
			e.printStackTrace();
		}
    }
    /**
     * 鍔犲瘑
     * 
     * @param encryptdata
     * @return
     * @throws Exception
     */
    public static String encode(byte[] KEY1,String encryptdata) {
        try {
        	 try {
                 DESKeySpec dks = new DESKeySpec(KEY1);
                 SecretKey key = keyFactory.generateSecret(dks);
                 cipher.init(Cipher.ENCRYPT_MODE, key, sr);
                 byte[] data = encryptdata.getBytes();
                 byte[] encryptedData = cipher.doFinal(data);
                 return cryptoHEX.encode(encryptedData);
             } catch (Exception e) {
                 return "[ERROR]";
             }
        } catch (Exception e) {
            return "[ERROR]";
        }
    }
    public static String decode(String decryptdata)
    {
    	if(Util.isNull(decryptdata))
    		return "";
    	return decode(KEY, decryptdata);
    }
    public static String decode(String key,String decryptdata)
    {
    	try {
    		if(Util.isNull(key))
    			return "[ERROR]" +"瀵嗛挜涓虹┖";
    		if(Util.isNull(decryptdata))
        		return "";
    		byte [] keys=key.getBytes();
    		return decode(keys,decryptdata);
    	} catch (Exception e) {
    		return "[ERROR]";
    	}
    }
    /**
     * 瑙ｅ瘑
     * 
     * @param decryptdata
     * @return
     * @throws Exception
     */
    public static String decode(byte[] KEY1,String decryptdata) {
        try {
            SecureRandom sr = new SecureRandom();
            DESKeySpec dks = new DESKeySpec(KEY1);
            SecretKey key = keyFactory.generateSecret(dks);
            cipher.init(Cipher.DECRYPT_MODE, key, sr);
            byte[] encryptedData = cryptoHEX.decode(decryptdata);
            byte[] decryptedData = cipher.doFinal(encryptedData);
            return new String(decryptedData);
        } catch (Exception e) {
            // 涓嶄細鍑虹幇璇ラ敊璇�
            return "[ERROR]";
        }
    }
    public static void main(String[] args) {
    	System.out.println(cryptoDES.decode("a8bb20f762a6f6756714972d7bb74a9d"));
//		System.out.println(encode("#gx20200225!"));
//		System.out.println(decode("615f5835528b6ab568bdecdaf9a28f0b"));
	}

}
