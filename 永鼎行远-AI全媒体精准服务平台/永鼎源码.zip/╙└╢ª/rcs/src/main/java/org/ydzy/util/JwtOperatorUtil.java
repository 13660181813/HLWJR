package org.ydzy.util;

import com.google.common.collect.Maps;
import com.google.inject.Singleton;
import io.jsonwebtoken.*;
import io.jsonwebtoken.security.Keys;
import org.apache.commons.codec.binary.Base64;
import org.ydzy.rcs.module.LoadProperties;

import javax.crypto.SecretKey;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * @author lirui
 * @Desc
 */
@SuppressWarnings("WeakerAccess")
@Singleton
public class JwtOperatorUtil {
    private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(JwtOperatorUtil.class);
    /**
     * 秘钥
     */
    private String secret = "bjydzy@BJy!_0Qaq1bbjydzy@BJy!_0Qaq12583YD@zyjydzy@BJy!_0Qaq1258bjydzy@BJy!_0Qaq12583YD@zy3YD@zy2583YD@zy";

    /**
     * 从token中获取claim
     *
     * @param token token
     * @return claim
     */
    public Claims getClaimsFromToken(String token) {
        try {
            return Jwts.parser()
                    .setSigningKey(this.secret.getBytes())
                    .parseClaimsJws(token)
                    .getBody();
        } catch (ExpiredJwtException | UnsupportedJwtException | MalformedJwtException | IllegalArgumentException e) {
            log.error("token parse error: {}", e.getMessage());
            throw new IllegalArgumentException("Token invalided.");
        }
    }

    /**
     * 获取token的过期时间
     *
     * @param token token
     * @return 过期时间
     */
    public Date getExpirationDateFromToken(String token) {
        return getClaimsFromToken(token).getExpiration();
    }

    /**
     * 判断token是否过期
     *
     * @param token token
     * @return 已过期返回true，未过期返回false
     */
    public Boolean isTokenExpired(String token) {
        try {
            Date expiration = getExpirationDateFromToken(token);
            return expiration.before(new Date());
        } catch (Exception ignored) {
            return true;
        }
    }

    /**
     * 计算token的过期时间
     *
     * @return 过期时间
     */
    private Date getExpirationTime() {
        long expireInSecond = Util.toLong(LoadProperties.systemProperties.getProperty("login.accessToken.expireInSecond"), 3600);
        return new Date(System.currentTimeMillis() + expireInSecond * 1000);
    }

    /**
     * 为指定用户生成token
     *
     * @param claims 用户信息
     * @return token
     */
    public String generateToken(Map<String, Object> claims) {
        Date createdTime = new Date();
        Date expirationTime = this.getExpirationTime();

        byte[] keyBytes = secret.getBytes();
        SecretKey key = Keys.hmacShaKeyFor(keyBytes);

        return Jwts.builder()
                .setClaims(claims)
                .setIssuedAt(createdTime)
                .setExpiration(expirationTime)
                .signWith(key, SignatureAlgorithm.HS256)
                .compact();
    }

    /**
     * 为指定用户生成token
     *
     * @param claims                 用户信息
     * @param expirationTimeInSecond 过期时间
     * @return token
     */
    public String generateToken(Map<String, Object> claims, Long expirationTimeInSecond) {
        Date createdTime = new Date();
        if (expirationTimeInSecond == null || expirationTimeInSecond < 0)
            expirationTimeInSecond = Util.toLong(LoadProperties.systemProperties.getProperty("login.accessToken.expireInSecond"), 3600);
        Date expirationTime = new Date(System.currentTimeMillis() + expirationTimeInSecond * 1000);

        byte[] keyBytes = secret.getBytes();
        SecretKey key = Keys.hmacShaKeyFor(keyBytes);

        return Jwts.builder()
                .setClaims(claims)
                .setIssuedAt(createdTime)
                .setExpiration(expirationTime)
                .signWith(key, SignatureAlgorithm.HS256)
                .compact();
    }

    /**
     * 判断token是否非法
     *
     * @param token token
     * @return 未过期返回true，否则返回false
     */
    public boolean validateToken(String token) {
        if (Util.isNull(token))
            return false;
        try {
            return !isTokenExpired(token);
        } catch (Exception e) {
            return false;
        }
    }

    public String generatorAccessToken(String username, String userid, String groupid) {
        // 存储用户相关信息 
        HashMap<String, Object> payload = Maps.newHashMap();
        payload.put("loginname", username);
        payload.put("userid", userid);
        payload.put("groupid", groupid);
        return generateToken(payload);
    }


    public static void main(String[] args) {
        // 1. 初始化
        JwtOperatorUtil jwtOperator = new JwtOperatorUtil();
        long expirationTimeInSecond = 1209600L;
        jwtOperator.secret = "bjydzy@BJy!_0Qaq1bbjydzy@BJy!_0Qaq12583YD@zyjydzy@BJy!_0Qaq1258bjydzy@BJy!_0Qaq12583YD@zy3YD@zy2583YD@zy";

        // 2.设置用户信息
        HashMap<String, Object> objectObjectHashMap = Maps.newHashMap();
        objectObjectHashMap.put("username", "testUser");
        objectObjectHashMap.put("userid", 10);

        // 测试1: 生成token
        String token = jwtOperator.generateToken(objectObjectHashMap);
        // 会生成类似该字符串的内容: eyJhbGciOiJIUzI1NiJ9.eyJpZCI6IjEiLCJpYXQiOjE1NjU1ODk4MTcsImV4cCI6MTU2Njc5OTQxN30.27_QgdtTg4SUgxidW6ALHFsZPgMtjCQ4ZYTRmZroKCQ
        System.out.println(token);

        // 将我改成上面生成的token!!!

//		String someToken = "eyJhbGciOiJIUzI1NiJ9.eyJsb2dpbm5hbWUiOiJsaXJ1aSIsInVzZXJpZCI6MSwic2lkIjoiYTI2MGE4MjMtNjgwZi00ZDhkLWE5ZjMtMGU1MGU1YWUxYWQyIiwiaWF0IjoxNjIwMjE2NTg4LCJleHAiOjE2MjAyMjM3ODh9.CcUa7hOVDry9O_kER6S1fT95Lfgq0_FYM0QPWyx3XtI";
        String someToken = token;
        // 测试2: 如果能token合法且未过期，返回true
        Boolean validateToken = jwtOperator.validateToken(someToken);
        System.out.println(validateToken);

        // 测试3: 获取用户信息
        Claims claims = jwtOperator.getClaimsFromToken(someToken);
        System.out.println(claims);
        // 将我改成你生成的token的第一段（以.为边界）
        String encodedHeader = "eyJhbGciOiJIUzI1NiJ9";
        // 测试4: 解密Header
        byte[] header = Base64.decodeBase64(encodedHeader.getBytes());
        System.out.println(new String(header));

        // 将我改成你生成的token的第二段（以.为边界）
        String encodedPayload = "eyJpZCI6IjEiLCJpYXQiOjE1ODYzOTQ3MzgsImV4cCI6MTU4NzYwNDMzOH0";
        // 测试5: 解密Payload
        byte[] payload = Base64.decodeBase64(encodedPayload.getBytes());
        System.out.println(new String(payload));

        // 测试6: 这是一个被篡改的token，因此会报异常，说明JWT是安全的
        jwtOperator.validateToken("eyJhbGciOiJIUzI1NiJ9.eyJpZCI6IjEiLCJpYXQiOjE1NjU1ODk3MzIsImV4cCI6MTU2Njc5OTMzMn0.nDv25ex7XuTlmXgNzGX46LqMZItVFyNHQpmL9UQf-aUx");
    }
}

