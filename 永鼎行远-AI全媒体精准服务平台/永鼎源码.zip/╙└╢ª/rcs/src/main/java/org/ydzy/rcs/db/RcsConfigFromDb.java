package org.ydzy.rcs.db;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.stream.Collectors;

import javax.sql.DataSource;

import org.ydzy.handler.impl.Process;
import org.ydzy.handler.impl.ProcessStore;
import org.ydzy.handler.impl.ProcessStoreBase;
import org.ydzy.rcs.RcsConfig;
import org.ydzy.rcs.module.LoadProperties;
import org.ydzy.util.SqlUtil;
import org.ydzy.util.Util;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonSyntaxException;
import com.google.inject.Inject;
import com.google.inject.Singleton;
import com.google.inject.name.Named;

@Singleton
public class RcsConfigFromDb  extends RcsConfig{
	static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(RcsConfigFromDb.class);
	DbType dbType;
	String dbTypeStr;
	public String getDbTypeStr() {
		return dbTypeStr;
	}
	public RcsConfigFromDb()
	{

	}
	public String [] queryMediaRealAddress(String mediaUrl,boolean raw)
	{
		String sqlId="MediasQuery";
		String sql =XmlSqlGenerator.getSqlstr(sqlId, mediaUrl);
		try {
			JsonArray results = SqlUtil.queryForJson(dataSource, sql);
			if(results!=null&&results.size()>0)
			{
				JsonObject ro = results.get(0).getAsJsonObject();
				String mUrl=Util.getElementAsString(ro, "chatbotMediaUrl");
				String tUrl=Util.getElementAsString(ro, "chatbotThumbnailUrl");
				return new String []{mUrl,tUrl};
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	@Inject
	public RcsConfigFromDb(@Named("rcsDb.DbType") String dbTypestr,@Named("rcsDb") DataSource dataSource)
	{
		this.dataSource=dataSource;
		this.dbTypeStr = dbTypestr;
		this.dbType=DbType.valueof(dbTypestr);
		XmlSqlGenerator.init(dbType.desc, "sqls/current");
		this.load();
		this.rcsConfig2SpMap();
		
	}
	
	private void loadRoleConfigs()
	{
		 Map<String,LinkedBlockingQueue<String>> roleConfigstmp=new ConcurrentHashMap<String, LinkedBlockingQueue<String>>();
		//Map<String,LinkedBlockingQueue<String>> roleConfigs
		//roleConfigs
		String sqlid ="configRoleTag";
		try {
			JsonArray result = 	SqlUtil.queryForJson(dataSource, XmlSqlGenerator.getSqlstr(sqlid));
			if(result!=null  && result.size()>0)
			{
				for(int i =0;i<result.size();i++)
				{
					JsonObject jo =result.get(i).getAsJsonObject();
					String key = Util.getElementAsString(jo, "tagSubNo");
					LinkedBlockingQueue<String> values ;
					values=roleConfigstmp.get(key);
					if(values==null)
					values = new LinkedBlockingQueue<String>();
					String v1= Util.getElementAsString(jo, "configid");
					values.add(v1);
					roleConfigstmp.put(key, values);
				}
				log.info("roleConfigs size {} ",roleConfigs.size());
			}
			this.roleConfigs=roleConfigstmp;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}


	DataSource dataSource;
	//title|desc|mediaUrl|mediaContentType|thumbnailContentType|height|thumbnailUrl|suggestions
	List<String> exclude=new ArrayList<String>() {
		{
			add("msgsuggestions");
			add("params");
			add("msg");
			add("msgid");
			add("suggestionid");
			add("isTemplate");
			add("relationName");
			add("isShowH5");
			add("templateName");
			add("params");
			add("msgconfigid");
			add("source_tablename");
			add("source_keywordField");
			add("source_paramSql");
			//add("configCssClassName");
			add("sugCssClassName");
			add("suggestiontype");
		}
	};
	/*
      JsonParser.parseString("{ "
                + "\"sp\" : \"sip:1065051210646@botplatform.rcs.chinamobile.com\","
                + "\"key\" : \"Huawei@123\", "
                + "\"appId\" : \"60429\",\r\n"
                + "\"terminal\" :	\"Chatbot\", "
                + "\"capabilityId\" : \"ChatbotSA\", "
                + "\"version\" : '+g.gsma.rcs.botversion=\"#=2\"',"
                + "\"defaultName\" :  \"�Ϻ���������4s��\" "
                + "}").getAsJsonObject())
     */
	Map<String,String> chatBotKeysMap=new HashMap<String,String>(){
		{
			put("chatbotIdenty","sp");
			put("secretkey","key");
			put("chatbotid","appId");
			put("terminalType","terminal");
			put("ability","capabilityId");
			put("version","version");
			put("chatbotname","defaultName");
			put("spName","spName");
			put("msgNotifyUrl","msgNotifyUrl");
			put("useAi","useAi");
			put("serverIcon","serverIcon");
			put("qrcode","qrcode");
			put("accessTagNo","accessTagNo");
		}
	};

	@Override
	public synchronized void load() {
		if(dataSource==null)
			return ;
		String sql=XmlSqlGenerator.getSqlstr("loadconfig");
		log.info("load config from {} sql \r\n {} ",this.dbTypeStr,sql);
		if(Util.isNull(sql))
		{
			log.error("rcsConfig load failed ! sql is null");
			return ;
		}
		
		JsonArray rcsConfigtmp=new  JsonArray();
		try(Connection con = dataSource.getConnection();
			Statement stat = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY)){
			ResultSet rs=stat.executeQuery(sql);
			ResultSetMetaData rsmd = rs.getMetaData();
			int numberOfColumns = rsmd.getColumnCount();
			Set<String> columnnames=new HashSet<String>();

			for(int i=1;i<=numberOfColumns;i++)
			{
				columnnames.add(rsmd.getColumnLabel(i));
			}

//				 JsonObject all=new JsonObject();
			Map<String,Map<String,Object>> all =new HashMap<String,Map<String,Object>>();
			while(rs.next())
			{
				String keywords=rs.getString("keywords");
				String spName=rs.getString("chatbotIdenty");
				Map<String,Integer> myaimap=null;
				if(!Util.isNull(spName))
				{
					if(AiMap.containsKey(spName))
						myaimap=AiMap.get(spName);
					else
					{
						myaimap = new ConcurrentHashMap<String, Integer>();
						AiMap.put(spName, myaimap);
					}

				} else {
					log.error(keywords + " has no chatbotid,skipped");
				}
				int aistepid = rs.getInt("aistepid");
				String suggesionid = rs.getString("suggestionid");
				String suggestiontype = rs.getString("suggestiontype");
				String allsuggestionsid = rs.getString("allsuggestionsid");
				String allsuggestionstype = rs.getString("allsuggestiontype");
				String clickAction = rs.getString("clickAction");
				if (!Util.isNull(clickAction)) {
					if (!Util.isNull(allsuggestionsid))
						suggestionClickActionMap.put(allsuggestionsid + allsuggestionstype, clickAction);
					if (!Util.isNull(suggesionid))
						suggestionClickActionMap.put(suggesionid + suggestiontype, clickAction);
				}
				if (aistepid != 0) {
					myaimap.put(keywords, aistepid);
					if (keywords.indexOf("|") > -1) {
						String[] splits = keywords.split("\\Q|");
						for (String s : splits) {
							myaimap.put(s, aistepid);
						}
					}
				}
				Map<String,Object> row;
				Set<String> s3=new LinkedHashSet<String>();
				Set<String> s3withId=new LinkedHashSet<String>();
				if(all.containsKey(keywords)) {
					row=all.get(keywords);
					if(row.get("chatbotIdenty") != null && row.get("chatbotIdenty").equals(spName))
					{
						s3=(Set<String>) (row.get("allsuggestions"));
						s3withId=(Set<String>) (row.get("allsuggestionsWithId"));
					}else
					{
						keywords=keywords+"|"+spName;
						if(all.containsKey(keywords)) {
							row=all.get(keywords);
							s3=(Set<String>) (row.get("allsuggestions"));
							s3withId=(Set<String>) (row.get("allsuggestionsWithId"));
						}
						else {
							row=new HashMap<String,Object>();
						}
						row.put("recompute", 1);
					}
				}else {
					row=new HashMap<String,Object>();
				}
				Map<String,Object> content=new LinkedHashMap<String,Object>();
//					JsonObject chats=new JsonObject();
				for(String c:columnnames)
				{
					if(!exclude.contains(c))
					{
						row.put(c, rs.getString(c));
					}
					else
					{
						//title|desc|mediaUrl|mediaContentType|thumbnailContentType|height|thumbnailUrl|suggestions
						content.put(c, rs.getString(c));
					}
//						if(chatBotKeysMap.containsKey(c))
//						{
//							chats.addProperty(chatBotKeysMap.get(c), rs.getString(c));
//						}
				}
				Map<String,Object> c1=content;
				String msg=Util.toString(content.get("msg"));
				if(!Util.isNull(msg)&&!Util.isNull(msg.replace("|", ""))) {
					c1.put("msg",msg );
					String sug=Util.toString(content.get("msgsuggestions"));
					if(!Util.isNull(sug)) {
						sug = replaceUrlSuggestion(sug);
						c1.put("suggestions", sug);
					}



					Set<Map<String,Object>> contentrow;
					if(row.containsKey("content"))
					{
						contentrow=(LinkedHashSet<Map<String,Object>>) row.get("content");
					}else
					{
						contentrow=new LinkedHashSet<Map<String,Object>>();
					}
					boolean find =false;
					for(Map<String,Object> e2:contentrow)
					{
						if(e2!=null&&c1!=null&&e2.get("msg")!=null&&e2.get("msg").equals(c1.get("msg")))
						{
							Set<String> s2=(Set<String>) e2.get("suggestionsSet");
							Set<String> s2withId=(Set<String>) e2.get("suggestionsWithId");
							String s1=Util.toString(c1.get("suggestions"));
							if(s2!=null&&!s2.contains(s1))
							{
								s2.add(s1);
								s2withId.add(suggesionid+ "|" + s1);
							}else if(s2==null)
							{
								s2=new LinkedHashSet<String>();
								s2.add(s1);
								s2withId=new LinkedHashSet<String>();
								s2withId.add(suggesionid+ "|" + s1);
							}
							e2.put("suggestionsSet",s2);
							e2.put("suggestionsWithId", s2withId);
							e2.put("suggestions",s2.stream().collect(Collectors.joining(",")));
							find=true;
						}

					}
					if(!find&&!Util.isNull(Util.toString(c1.get("msg"))))
					{
						Set<String> s2 =new LinkedHashSet<String>();
						Set<String> s2withId=new LinkedHashSet<String>();
						String isSHowH5=Util.toString(c1.get("isShowH5"));

						if(!"-1".equals(isSHowH5))
						{
							String url=LoadProperties.systemProperties.getProperty("webUiManagerUrl")+"/preview";
							String patternu="urlAction|H5��Ϣ|"+url+"|webview||";
							s2.add(patternu);
							s2withId.add("-1|"+patternu);
						}
						s2.add(sug);
						s2withId.add(suggesionid+ "|" + sug);
						c1.put("suggestionsSet", s2);
						c1.put("suggestionsWithId", s2withId);
						contentrow.add(c1);
					}
					row.put("content", contentrow);
				}
				else
				{
					c1.remove("msg");
				}
//					String param= Util.getElementAsString(content, "params");
//					if(!Util.isNull(param))
//					c1.addProperty("params",param);



				String s5=Util.toString(row.get("suggestions"));
				if(!s3.contains(s5))
				{
					s5 = replaceUrlSuggestion(s5);
					s3.add(s5);
					s3withId.add(allsuggestionsid + "|" + s5);
				}
				row.put("allsuggestions", s3);
				row.put("allsuggestionsWithId", s3withId);
				row.put("suggestions", s3.stream().collect(Collectors.joining(",")));

				all.put(keywords, row);
//					chatbotInfo.put(spName, chats);

			}
			if(all!=null)
			{
				Set<String> keys = all.keySet();
				for(String s:keys)
				{
					rcsConfigtmp.add(gson.toJson(all.get(s)));
				}
			}
			this.rcsConfig=rcsConfigtmp;
		}catch(SQLException e) {
			log.error("query,%s", sql,e );
		}
		log.info("load rcsConfig records size {}",rcsConfig.size());
		this.loadChatBotInfos();
		this.loadModelParams();
		this.setProcessStore(loadProcessStoreBase());
		this.loadAvatar();
		this.loadRoleConfigs();
	}


	Gson gson=new Gson();
	private void loadModelParams()
	{
		Map<String,List<Map<String,Object>>> modelParamsV=new HashMap<>();
//		modelParams
		String sql=XmlSqlGenerator.getSqlstr("modelParams");
		try {
			JsonArray array = SqlUtil.queryForJson(dataSource, sql);
			for(int i =0;i<array.size();i++)
			{
				String msgid=Util.getElementAsString(array.get(i).getAsJsonObject(), "msgId");
				String params=Util.getElementAsString(array.get(i).getAsJsonObject(), "params");
				String tempId=Util.getElementAsString(array.get(i).getAsJsonObject(), "tempId");
				Map<String,Object> value=new ConcurrentHashMap<String, Object>(){
					{
						//[{"id":"p1","type":"string","desc":"��ѧ��֪","val":"2323"},{"id":"p2","type":"textarea","desc":"ע������","val":"3232"}]
						put("msgId",msgid);

						try {
							JsonElement e=JsonParser.parseString(params);
							Map<String,String> pav=new HashMap<String, String>();
							if( e!=null&&!e.isJsonNull())
							{
								JsonArray ar=e.getAsJsonArray();
								for(int m=0;m<ar.size();m++)
								{
									JsonObject o =ar.get(m).getAsJsonObject();
									pav.put(Util.getElementAsString(o, "id"), Util.getElementAsString(o, "val"));
								}
							}
							put("params",pav);
							put("tempId",tempId);
						} catch (JsonSyntaxException e) {
							log.error("json parse error  content {}",params);
						}
					}
				};

				if(modelParamsV.containsKey(msgid))
				{
					List<Map<String,Object>> modelobj=modelParamsV.get(msgid);
					Map<String,Object> ofind=null;
					for(Map<String,Object> o:modelobj)
					{
						if(o.get("tempId")!=null &&value.get("tempId")!=null && o.get("tempId").equals(value.get("tempId")))
						{
							ofind=o;

						}
					}
					if(ofind!=null) {
						modelobj.remove(ofind);
					}
					modelobj.add(value);
				}
				else
				{
					List<Map<String,Object>> v=new Vector<Map<String,Object>>();
					v.add(value);
					modelParamsV.put(msgid, v);
				}
			}
			synchronized (modelParams)
			{
				modelParams=modelParamsV;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	protected ProcessStore loadProcessStoreBase() {
		List<Process> list = new ArrayList<>();
		String sql=XmlSqlGenerator.getSqlstr("stateprocedures");
		//rcs_stateprocedures
		log.info("load stateprocedures from {} sql \r\n {} ",this.dbTypeStr,sql);
		ResultSet rs=null;
		try(Connection con = dataSource.getConnection();
			Statement stat = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY)){
			rs=stat.executeQuery(sql);
			while(rs.next()){
				int stepid = rs.getInt("stepid");
				String question = rs.getString("question");
				int backid = rs.getInt("backid");
				int nextid = rs.getInt("nextid");
				String display = rs.getString("display");
				String stateClassName = rs.getString("stateClassName");
				String tag = rs.getString("tag");
				String tmp = rs.getString("outParameters");
				String[] outParameters = tmp==null?null:tmp.split("\\|");
				int acceptContentTypes = rs.getInt("acceptContentTypes");
				Process p = new Process(stepid, question,backid,nextid,stateClassName,display, tag, outParameters, acceptContentTypes);
				list.add(p);
			}
			/*
CREATE TABLE `rcs_stateprocedures` (
  `stepid` int NOT NULL,
  `question` varchar(255) DEFAULT NULL,
  `backid` int DEFAULT NULL COMMENT '�ع�ID',
  `nextid` int DEFAULT NULL COMMENT '��һ��ID',
  `display` varchar(255) DEFAULT NULL COMMENT '��ʾ����',
  `stateClassName` varchar(64) DEFAULT NULL COMMENT '����У��ʵ����',
  `tag` varchar(32) DEFAULT '' COMMENT '�����������б�,ʹ�ö��ŷָ� Ŀǰ֧��3�� FINISHED RUN_FINISHED SET_CONTENT',
  `outParameters` varchar(128) DEFAULT NULL COMMENT '������������б�,��|�ָ�',
  `acceptContentTypes` int DEFAULT '0' COMMENT '�����������Ͱ��ձ���λ���ƶ�ѡ 0:����֤ 1:λ��geo���� 2:ͼƬimage/* 4:��Ƶvedio/* 8:����audio/* 16:�����ϴ�ý����Ϣ',
  PRIMARY KEY (`stepid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8
			 */
		}catch(SQLException e) {
			log.error("query,%s", sql,e );
		}
		finally {
			if(rs!=null)
				try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		ProcessStoreBase processStore = new ProcessStoreDB(list);
		return processStore;
	}
	/**  */
	static class ProcessStoreDB  extends ProcessStoreBase implements ProcessStore{
		public ProcessStoreDB(List<Process> processes){
			processes.forEach( p -> add(String.valueOf(p.stepid), p));
		}

	}

	private void loadChatBotInfos(){
//		modelParams
		String sql=XmlSqlGenerator.getSqlstr("loadChatbotinfos");
		try {

			JsonArray array = SqlUtil.queryForJson(dataSource, sql);
			for(int i =0;i<array.size();i++){
				JsonObject chats = array.get(i).getAsJsonObject();
				String spName=Util.getElementAsString(chats, "spName");
				String chatbotIdenty=Util.getElementAsString(chats, "chatbotIdenty");
				String chatbotid =Util.getElementAsString(chats, "chatbotid");
				String accessTagNo=Util.getElementAsString(chats, "accessTagNo");
				chatBotKeysMap.forEach((k,v)->{
					String dbv=Util.getElementAsString(chats, k);
					if(!Util.isNull(dbv))
						chats.addProperty(v, dbv);
				});

				String enable=Util.getElementAsString(chats, "enable");//����״̬
				synchronized (chatbotInfo) {
					/**
					 * enableֵ��
					 * 0
					 * 1 ����
					 * 2 ����
					 * 3 ����
					 */
					if("1".equals(enable) || "3".equals(enable))//���߻����״̬
					{
						chatbotInfo.put(spName, chats);
						chatbotInfo.put(chatbotIdenty, chats);
						chatbotInfo.put(chatbotid, chats);
						chatbotInfo.put(accessTagNo, chats);
					}
					else
					{
						log.error("chats auditStatus error ,please check !,{} ",chats);
					}
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	private void loadAvatar(){
		avatarCompany.clear();
		String sql=XmlSqlGenerator.getSqlstr("queryAvatarForCompany");
		try {
			String webPath=Util.toString(LoadProperties.systemProperties.get("publicenv.webPath"));
			String path =Util.toString("/"+webPath+"/dialog/static/img/system.png","/delivery/static/img/system.png");
			avatarCompany.put("system",path);
			JsonArray array = SqlUtil.queryForJson(dataSource, sql);
			for(int i =0;i<array.size();i++){
				JsonObject obj = array.get(i).getAsJsonObject();
				String key = Util.getElementAsString(obj, "key");
				String avatar = Util.getElementAsString(obj, "avatar");
				if(!Util.isNull(key)&&!Util.isNull(avatar)) {
					avatar = avatar.replace("{webPath}", webPath + "/dialog");
					avatarCompany.put(key, avatar);
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		String sql2 = XmlSqlGenerator.getSqlstr("queryAvatarForUser");
		avatarUser.clear();
		try {
			JsonArray array = SqlUtil.queryForJson(dataSource, sql2);
			for(int i =0;i<array.size();i++){
				JsonObject obj = array.get(i).getAsJsonObject();
				String key = Util.getElementAsString(obj, "key");
				String avatar = Util.getElementAsString(obj, "avatar");
				if(!Util.isNull(key)&&!Util.isNull(avatar)){
					avatarUser.put(key,avatar);
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	private String replaceUrlSuggestion(String suggestions) {
		if (Util.isNull(suggestions))
			return suggestions;
		String weburl = LoadProperties.systemProperties.getProperty("webUiUrl");
		String apiurl = LoadProperties.systemProperties.getProperty("webUrl");
		String webUiManagerUrl = LoadProperties.systemProperties.getProperty("webUiManagerUrl");
		String webUiFormUrl = LoadProperties.systemProperties.getProperty("webUiFormUrl");
		String webUiDialogUrl = LoadProperties.systemProperties.getProperty("webUiDialogUrl");
		suggestions = suggestions.replace("{apiurl}",apiurl);
		suggestions = suggestions.replace("{weburl}",weburl);
		
		suggestions = suggestions.replace("{webUiManagerUrl}",webUiManagerUrl);
		suggestions = suggestions.replace("{webUiFormUrl}",webUiFormUrl);
		suggestions = suggestions.replace("{webUiDialogUrl}",webUiDialogUrl);
		return suggestions;
	}
}
