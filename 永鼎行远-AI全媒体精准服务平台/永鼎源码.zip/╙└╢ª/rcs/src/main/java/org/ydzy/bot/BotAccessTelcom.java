package org.ydzy.bot;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.Callable;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;
import java.util.function.BiConsumer;

import org.ydzy.bot.BotUtil.HttpInfo;
import org.ydzy.bot.model.BotInfoOptions;
import org.ydzy.bot.model.BotResult;
import org.ydzy.bot.model.MenuGroup;
import org.ydzy.handler.BaseRcsContext;
import org.ydzy.rcs.action.RcsRunLogAction;
import org.ydzy.rcs.media.MediaEnclosure;
import org.ydzy.rcs.media.MediaEnclosure.IMediaFileInfo;
import org.ydzy.rcs.media.UploadFileEntity;
import org.ydzy.util.Util;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.inject.Inject;
import com.google.inject.name.Named;

/**
 * 
 * �й����� bot�ӿ�ģ��
 * @author ljp
 *
 */
public class BotAccessTelcom extends BotAccess {

	public BotAccessTelcom() {
		this.authorizeName = AuthAccessToken.KEY_AUTH_ACCESS_TOKEN;
		this.verifyName =VerifySignature.KEY_VERIFY_SIGNATURE;
	}
	
	@Inject(optional = true)
	@Named("bot.serverRoot")
	private String serverRoot;
	public String getServerRoot() {
		return serverRoot.startsWith("http")?serverRoot:("https://"+serverRoot);
	}

	@Inject(optional = true)
	@Named("bot.apiVersion")
	private String apiVersion = "v1";
	public String getApiVersion() {
		return apiVersion;
	}
	
	@Inject(optional = true)
	@Named("bot.url.accessToken")
	//https://{serverRoot}/bot/{apiVersion}/{chatbotId}/accessToken
	private String urlAccessToken = "{serverRoot}/bot/{apiVersion}/{urlencode(chatbotIdenty)}/accessToken";
	public String getUrlAccessToken() {
		return urlAccessToken;
	}
	
	@Inject(optional = true)
	@Named("bot.url.chatBotInfo.optionals")
	//https://{serverRoot}/bot/{apiVersion}/{chatbotId}/update/chatBotInfo/optionals 
	private String urlChatBotInfoOptionals = "{serverRoot}/bot/{apiVersion}/{urlencode(chatbotIdenty)}/update/chatBotInfo/optionals";
	public String getUrlChatBotInfoOptionals() {
		return urlChatBotInfoOptionals;
	}
	
	@Inject(optional = true)
	@Named("bot.url.chatBotInfo.menu")
	// https://{serverRoot}/bot/{apiVersion}/{chatbotId}/update/chatBotInfo/menu
	private String urlChatBotInfoMenu = "{serverRoot}/bot/{apiVersion}/{urlencode(chatbotIdenty)}/update/chatBotInfo/menu";
	public String getUrlChatBotInfoMenu() {
		return urlChatBotInfoMenu;
	}
	
	@Inject(optional = true)
	@Named("bot.url.find.chatBotInfo")
	// https://{serverRoot}/bot/{apiVersion}/{chatbotId}/find/chatBotInfo
	private String urlFindChatBotInfo = "{serverRoot}/bot/{apiVersion}/{urlencode(chatbotIdenty)}/find/chatBotInfo";
	
	public String getUrlFindChatBotInfo() {
		return urlFindChatBotInfo;
	}
	
	@Inject(optional = true)
	@Named("bot.url.medias.upload")
	// https://{serverRoot}/bot/{apiVersion}/{chatbotId}/medias/upload
	private String urlMediasUpload = "{serverRoot}/bot/{apiVersion}/{urlencode(chatbotIdenty)}/medias/upload";
	public String getUrlMediasUpload() {
		return urlMediasUpload;
	}
	
	/**  ý���ز����� */
	@Inject(optional = true)
	@Named("bot.url.medias.download")
	// https://{serverRoot}/bot/{apiVersion}/{chatbotId}/medias/download
	private String urlMediasDownload = "{serverRoot}/bot/{apiVersion}/{urlencode(chatbotIdenty)}/medias/download";
	public String getUrlMediasDownload() {
		return urlMediasDownload;
	}
	
	/**  ý���ز�ɾ�� */
	@Inject(optional = true)
	@Named("bot.url.medias.delete")
	// https://{serverRoot}/bot/{apiVersion}/{chatbotId}/medias/delete
	private String urlMediasDelete = "{serverRoot}/bot/{apiVersion}/{urlencode(chatbotIdenty)}/medias/delete";
	public String getUrlMediasDelete() {
		return urlMediasDelete;
	}
	
	/** ������Ϣ */
	@Inject(optional = true)
	@Named("bot.url.messages")
	// https://{serverRoot}/bot/{apiVersion}/{chatbotId}/messages
	private String urlMessages = "{serverRoot}/bot/{apiVersion}/{urlencode(chatbotIdenty)}/messages";
	public String getUrlMessages() {
		return urlMessages;
	}
	
	/** ��Ϣ���� */
	@Inject(optional = true)
	@Named("bot.url.revoke")
	// https://{serverRoot}/bot/{apiVersion}/{chatbotId}/revoke
	private String urlRevoke = "{serverRoot}/bot/{apiVersion}/{urlencode(chatbotIdenty)}/revoke";
	public String getUrlRevoke() {
		return urlRevoke;
	}

	private static String UPLOAD_MODE_PERM = "perm";
	private static String UPLOAD_MODE_TEMP = "temp";
	/** �ϴ�ģʽ perm:�����ļ�    temp:��ʱ�ļ� */
	private String uploadMode = UPLOAD_MODE_PERM;
	@Inject(optional = true)
	public void setUploadMode(@Named("bot.upload.mode")String uploadMode) {
		if(UPLOAD_MODE_TEMP.equalsIgnoreCase(uploadMode)) {
			this.uploadMode = UPLOAD_MODE_TEMP;
		}else if(UPLOAD_MODE_PERM.equalsIgnoreCase(uploadMode)) {
			this.uploadMode = UPLOAD_MODE_PERM;
		}
	}
	public String getUploadMode() {
		return uploadMode;
	}

	@Override
	public boolean active(BotInfo botInfo) {
		boolean flag = newAccessToken(botInfo);
		if(flag) {
			this.chatBotInfoOptionals(botInfo);
			this.chatBotInfoMenus(botInfo);
		}
		return flag;
	}
	
	/**
	 * ˢ�� chatbot��accessToken
	 * @param botInfo
	 * @return
	 */
	protected boolean newAccessToken(BotInfo botInfo) {
		String url = BotUtil.mustache(getUrlAccessToken(), this, botInfo, botInfo.getInfos());
		if(log.isDebugEnabled())log.debug("getting access token " + url);
		try {
			if(Util.isNull(botInfo.getAppId()) || Util.isNull(botInfo.getAppKey())){
				log.info("newAccessToken failed, appid or appkey is null. indentyId:{}, appid:{}, appkey:{}", botInfo.getChatbotIdenty(), botInfo.getAppId(), botInfo.getAppKey());
				return false;
			}
			String outBody = String.format("{\"appId\": \"%s\", \"appKey\": \"%s\"}", botInfo.getAppId(), botInfo.getAppKey());
			String body = BotUtil.doHttp(url,outBody,null);
			if(body!=null){
/*
{ 
  "accessToken": "xxxxxxxx", 
  "expires": 7200, 
  "errorCode":0, 
  "url": "xxxxxx" 
}
 */
				JsonObject object = null;
				JsonElement ele = JsonParser.parseString(body);
				object = ele.getAsJsonObject();
				Number exp = BotUtil.getElementAsNumber(object, "expires");
				String at = BotUtil.getElementAsString(object, "accessToken");
				String callUrl = BotUtil.getElementAsString(object, "url");
				if(exp==null || at==null) throw new RuntimeException("get access token error, resBody(" + body + ")");
				long expire = System.currentTimeMillis() + exp.longValue()*1000-10000;
				botInfo.expire = expire;
				botInfo.accessToken = at;
				botInfo.callUrl = callUrl;
				if(log.isDebugEnabled()) log.debug("token:" + at + " expired:" + new java.util.Date(exp.longValue()));
				return true;
			}
		}catch(Exception e) {
			log.warn("Can't get access token from url(" + url + "), " + e.getMessage() + "");
		}
		return false;
	}

	/**
	 * �޸�Chatbot ��Ϣ
	 * �ɸ���Chatbot�������������Chatbot��ѡ�������Ϣ����ͨ���ӿڽ���Ϣ���ݸ�ƽ̨��ƽ̨���ͨ������Ϣ��Ч���ɹ��ն˲鿴�� 
	 * �������������������˷��࣬ �ز����� ����λ�þ��� ����λ��γ��  ��
	 * @param botInfo
	 * @return
	 */
	public boolean chatBotInfoOptionals(BotInfo botInfo) {
		try {
			BotInfoOptions options = botInfo.getDbOper().getBotInfoOptionals(botInfo);
			String body = gson.toJson(options);;
			Map<String, Object> headers = new HashMap<>();
			String url=getUrl(botInfo,getUrlChatBotInfoOptionals(), headers);
			if(log.isDebugEnabled())log.debug("posting chatbot info optionals " + url);
			String rspBody = BotUtil.doHttp(url, body, headers);
			BotResult result = gson.fromJson(rspBody, BotResult.class);
			if(result.getErrorCode()!=0) {
				log.warn("do chatBotInfoOptionals error,"  + result + " (" + body + ")");
				return false;
			}
			return true;
		}catch(Exception e) {
			log.warn("do chatBotInfoOptionals error, (" + e.toString() + ")",e);
		}
		return false;
	}
	
	/**
	 * �ύ�޸�Chatbot �˵�
	 * �ɶ�Chatbotָ��һ�����õĹ̶��˵�����ΪChatbot��Ϣ��һ���֣�δ������Ϣ����ʱ��Ϊ�ն��ṩ��������ͽ���ظ���
	 * �̶��˵����2��������1���˵����3����Ŀ��2���˵����5����Ŀ��ÿ����Ŀ��Ϊ��һ���˵��������������ظ��� 
	 * @param botInfo
	 * @return
	 */
	public boolean chatBotInfoMenus(BotInfo botInfo) {
		try {
			MenuGroup m = botInfo.getDbOper().loadMenus(botInfo,"");
			if(m==null || m.getMenu()==null || m.getMenu().getEntries()==null || m.getMenu().getEntries().size()==0){
				log.debug("No menu defined for chatbot(" + botInfo.chatbotId + ")");
			}else {
				String body = gson.toJson(m);
				Map<String, Object> headers = new HashMap<>();
				String url=getUrl(botInfo,getUrlChatBotInfoMenu(), headers);
				if(log.isDebugEnabled())log.debug("posting chatbot menus " + url);
				String rspBody = BotUtil.doHttp(url, body, headers);
				BotResult result = gson.fromJson(rspBody, BotResult.class);
				if(result.getErrorCode()!=0) {
					throw new IOException("do http url" + url + " result error," + result + " (" + body + ")");
				}
				return true;
			}
		}catch(Exception e) {
			if(botInfo.getDbOper().getDataSource()!=null){
				RcsRunLogAction.recordLog("chatBotInfoMenus", "submit menu error", "", "100", "chatBotInfoMenus", botInfo.getDbOper().getDataSource());
			}
			log.warn("do chatBotInfoMenus error, (" + e.toString() + ")",e);
		}

		return false;
	}
	
	/**
	 * 7.2 Chatbot ��Ϣ��ȡ 
	 * �ӿڷ���Chatbot �� 5G��Ϣҵ��ƽ̨ 
	 * �ӿ�˵��
	 * Chatbot�ı�����Ϣ��ƽ̨ά����Chatbot��ѡ����Ϣ�ɽӿ�APIά����ѡ����Ϣ���ͨ���� �ɴ�ƽ̨��ȡ������Ϣ�������̶��˵����� 
	 * @param botInfo
	 * @return
	 */
	public JsonObject findchatBotInfo(BotInfo botInfo) {
		try {
			String body = null;
			Map<String, Object> headers = new HashMap<>();
			String url=getUrl(botInfo,getUrlFindChatBotInfo(), headers);
			if(log.isDebugEnabled())log.debug("Finding chatbot info " + url);
			String rspBody = BotUtil.doHttp(url, body, headers);
			JsonElement je = JsonParser.parseString(rspBody);
			if(je!=null && je.isJsonObject()) {
				return je.getAsJsonObject();
			}
		}catch(Exception e) {
			if(botInfo.getDbOper().getDataSource()!=null){
				RcsRunLogAction.recordLog("findchatBotInfo", "findChatbotInfo error", "", "100", "findchatBotInfo", botInfo.getDbOper().getDataSource());
			}
			log.warn("do findchatBotInfo error, (" + e.toString() + ")",e);
		}
		return null;
	}
	
	protected static final String FORMNAME_FILE = "media";
	protected static final String FORMNAME_THUMBNAIL = "thumbnail";
	/** �������ͼ�ļ���С */
	@Inject(optional = true)
	@Named("bot.thumbnail.max.filesize")
	private long maxThumbnailFilesize = 100*1024;

	/** �Ƿ����һ���ϴ�����ļ� */
	@Inject(optional = true)
	@Named("bot.media.multi.upload")
	private boolean mediaMultiUpload = true;

	/***
	 * �ϴ�ý��
	 * @param botInfo
	 * @param headers
	 * @param body
	 */
	@Override
	public boolean mediaUpload(final BotInfo botInfo, final UploadFileEntity fileEntity) {
		final String[] filenames = {"", ""};
		
		class MediaUpload extends HttpCallable{
			List<String> mediaTypes;
			boolean isCheckStatus;
			MediaUpload(BotInfo bi, String[] mediaTypes, boolean isCheckStatus) {
				super(bi);
				this.mediaTypes = java.util.Arrays.asList(mediaTypes);
				this.isCheckStatus = isCheckStatus;
			}
			final MediaEnclosure enclosure = new MediaEnclosure();
			public boolean isNeedUpload() {
				String mediaID = fileEntity.getMediaID();
				if(mediaID==null || mediaID.isEmpty())return true;
				botInfo.getDbOper().loadMedia(fileEntity);
				if("0".equals(fileEntity.getStatus()) || (!isCheckStatus))return true;
				if(fileEntity.getExpiredTime()>3600000 && fileEntity.getExpiredTime()<System.currentTimeMillis()) {
					// �ѳ�ʱ
					log.debug("Media(" + mediaID + " is expired, upload again!");
					return true;
				}
				
				log.debug("Media(" + mediaID + " is ok, break upload!");
				return false;
				
			}
			public String call() throws Exception{
				if(!isNeedUpload())throw new SpecialException("Media(" +fileEntity.getMediaID() + ") is Ok, exit upload!");
				String boundary="--------"+UUID.randomUUID().toString().replace("-", "");
				Map<String, Object> headers= new HashMap<>();
				headers.put("Content-Type", "multipart/form-data; boundary="+boundary);
				//perm:�����ļ�    temp:��ʱ�ļ�
				headers.put("uploadMode", getUploadMode());
				//ByteBuffer body = enclosure.convertBody(fileEntity, boundary);
				String url=getUrl(botInfo,getUrlMediasUpload(), headers);
				if(log.isDebugEnabled())log.debug("posting chatbot media upload " + url);
				if(url==null)throw new SpecialException("Create catbot(" +botInfo.getChatbotId() + ") authorized error, maybe this token is null!!!");
				
				List<Map.Entry<String, IMediaFileInfo>> list = new ArrayList<>();
				if(mediaTypes.contains(FORMNAME_FILE)) {
					IMediaFileInfo mediaInfo = enclosure.getMediaFileInfo(fileEntity, false);
					if(mediaInfo!=null) {
						list.add(Map.entry(FORMNAME_FILE, mediaInfo));
						fileEntity.setFileName(mediaInfo.getFilename());
						filenames[0] = mediaInfo.getFilename();
					}
				}
				if(mediaTypes.contains(FORMNAME_THUMBNAIL)) {
					IMediaFileInfo thumbnailInfo = enclosure.getMediaFileInfo(fileEntity, true);
					if(thumbnailInfo!=null) {
						boolean flag = thumbnailInfo.getFileSize() < maxThumbnailFilesize;
						if(!flag) {
							if(thumbnailInfo.resizeTo(maxThumbnailFilesize)) {
								flag = true;
							}else {
								log.warn("Can't resize thumbnail file(" + thumbnailInfo.getFilename() + ") to limit size, skip!!!");;
							}
						}
						if(flag){
							list.add(Map.entry(FORMNAME_THUMBNAIL, thumbnailInfo));;
							fileEntity.setThumbFileSize(thumbnailInfo.getFileSize());
							filenames[1] = thumbnailInfo.getFilename();
						}
					}
				}
				if(list==null || list.size()==0) throw new SpecialException("No media file loaded!!!");
				if(fileEntity.getMediaID()==null|| fileEntity.getMediaID().isEmpty()) {
					botInfo.getDbOper().saveMedia(botInfo, fileEntity);
					String mediaID = fileEntity.getMediaID();
					if(mediaID!=null && !mediaID.isEmpty() && botInfo.manager.getMediaUploadFuture()!=null) {
						CompletableFuture<UploadFileEntity> authorFuture = new CompletableFuture<>();
						botInfo.manager.getMediaUploadFuture().put(mediaID, authorFuture);
					}
				}
				final CompletableFuture<HttpInfo> putFuture = new CompletableFuture<>();
				String rspBody = null;
				try (
						InputStream body = enclosure.convertBodyInputStream(list, boundary);
						){
					rspBody = doHttp(url, body, headers, null, BotUtil.utf8, null, putFuture);
				}catch(IOException e) {
					//ignore
				}
				log.debug("Upload media(" + fileEntity.getMediaID() + "-" + mediaTypes+ ") rsp:" + rspBody);
				if(rspBody==null || rspBody.isEmpty())throw new IOException("do http error, no content!");
				BotResult result = gson.fromJson(rspBody, BotResult.class);
				if(result.getErrorCode()!=0) {
					fileEntity.setErrorCode(result.getErrorCode()+"");
					fileEntity.setErrorDesc(result.getErrorMessage());
					throw new IOException("result error," + result + " mediaid(" + fileEntity.getMediaID() + "-" + mediaTypes + ")");
				}
				return rspBody;
			}
		};
		
		try {
			CompletableFuture<Void> future = new CompletableFuture<>();
			BiConsumer<? super String, ? super Throwable> callDb = (rspBody, t)->{
				/**
{ 
"fileInfo": [ 
{ 
"url":http://124.127.121.100/temp/src/2020062217asdfkjaoskd/836ee/view/37,3c3504f6e4cc
6c5274f0.jpeg", 
"fileName": "AA.jpeg", 
"contentType": "image/jpeg", 
"fileSize": 22347, 
"until": "2017-04-25T12:17:07Z" 
} 
], 
"fileCount": 100, 
"totalCount": 300, 
"errorCode": 0 
} 
				 */
				try {
					if(rspBody==null || rspBody.isEmpty()) {
						if(t!=null){
							future.completeExceptionally(t);
						}else {
							future.complete(null);
						}
						return;
					}
					JsonObject jo = null;
					JsonArray ja = null;
					boolean isFileInfo = true;
					try {
						jo = JsonParser.parseString(rspBody).getAsJsonObject();
						JsonElement je=jo.get("fileInfo");
						if(je==null) {
							je = jo.get("fileIdList");
							isFileInfo = false;
						}
						ja = je.getAsJsonArray();
					}catch(Exception e) {
						log.warn("Error, parse media upload rsp:" + rspBody, e);
						future.complete(null);
						return;
					}
					
					String result = Util.getElementAsString(jo, "errorCode");
					String desc = Util.getElementAsString(jo, "fileCount") + "/" + Util.getElementAsString(jo, "totalCount");
					botInfo.getDbOper().loadMedia(fileEntity);
					String errCode = fileEntity.getErrorCode();
					String errDesc = fileEntity.getErrorDesc();
					if(!Util.isNull(errCode))errCode += "|" + result;
					else if(!Util.isNull(errCode)&&errCode.length()>16)errCode=errCode.substring(errCode.length()-16);
					errDesc =(!Util.isNull(errDesc))?(errDesc + "|" + desc):desc;
					fileEntity.setErrorCode(errCode);
					fileEntity.setErrorDesc(errDesc);
					DateTimeFormatter df = DateTimeFormatter.ISO_INSTANT;
					////mediaUrl mediaContentType thumbnailUrl thumbnailContentType expriedTime status authStatus
					String mediaUrl = null, mediaContentType = null;
					int mediaFileSize = 0;
					String thumbnailUrl = "", thumbnailContentType = "";
					int thumbnailFileSize = 0;;
					long expriedTime = 0;
					if(!isFileInfo) {
						if(ja.size()>=1) {
							String fid = ja.get(0).getAsString();
							fileEntity.setChatbotMediaUrl("fileId: " + fid);
							fileEntity.setTid(fid);
						}
						if(ja.size()>=2) {
							fileEntity.setChatbotThumbnailUrl("fileId: " + ja.get(1).getAsString());
						}
					}else {
						for(int i=0;i<ja.size();i++) {
							JsonObject fo = ja.get(i).getAsJsonObject();
							String fileName = BotUtil.getElementAsString(fo, "fileName");
							if(FORMNAME_FILE.equals(fileName) || filenames[0].equals(fileName)) {
								String until = BotUtil.getElementAsString(fo, "until");
								if(until!=null&&!until.isEmpty()) {
									Instant ins = df.parse(until, Instant::from);
									expriedTime = ins.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli();
								}else {
									expriedTime = Integer.MAX_VALUE;
								}
								mediaUrl = (BotUtil.getElementAsString(fo, "url"));
								mediaContentType = (BotUtil.getElementAsString(fo, "contentType"));
								mediaFileSize = BotUtil.getElementAsNumber(fo, "fileSize").intValue();
								fileEntity.setFileSize(mediaFileSize);
								fileEntity.setChatbotMediaUrl(mediaUrl);
								fileEntity.setMediacontentType(mediaContentType);
							}else if(FORMNAME_THUMBNAIL.equals(fileName) || filenames[1].equals(fileName)) {
								thumbnailUrl = (BotUtil.getElementAsString(fo, "url"));
								thumbnailContentType = (BotUtil.getElementAsString(fo, "contentType"));
								thumbnailFileSize = BotUtil.getElementAsNumber(fo, "fileSize").intValue();
								fileEntity.setThumbFileSize(thumbnailFileSize);
								fileEntity.setChatbotThumbnailUrl(thumbnailUrl);
								fileEntity.setThumbnailContentType(thumbnailContentType);
							}
						}
					}
					fileEntity.setStatus("1");
					if(expriedTime>3600000 && expriedTime<fileEntity.getExpiredTime()) {
						fileEntity.setExpiredTime(expriedTime);
					}
					
					//fileEntity.setErrorCode("0");
					//fileEntity.setErrorDesc("success");
//				botInfo.dbOper.saveMediaUploaded(botInfo, param, mediaUrl, mediaContentType, mediaFileSize
//						, thumbnailUrl, thumbnailContentType, thumbnailFileSize, expriedTime);
					botInfo.dbOper.saveMedia(botInfo, fileEntity);
					future.complete(null);
				}catch(Exception e) {
					log.warn("Writer to media info to database error!",e);
				}			
			};
			
			String mediaID = fileEntity.getMediaID();
			if(mediaID!=null && !mediaID.isEmpty()) {
				if(botInfo.manager.getMediaUploadFuture().containsKey(mediaID)) {
					log.debug("Media(" + mediaID + " upload is running, skip!");
					return true;
				}
				CompletableFuture<UploadFileEntity> authorFuture = new CompletableFuture<>();
				botInfo.manager.getMediaUploadFuture().put(mediaID, authorFuture);
			}else {
				fileEntity.setErrorCode("");
				fileEntity.setErrorDesc("");
				botInfo.getDbOper().saveMedia(botInfo, fileEntity);
				mediaID = fileEntity.getMediaID();
				CompletableFuture<UploadFileEntity> authorFuture = new CompletableFuture<>();
				botInfo.manager.getMediaUploadFuture().put(mediaID, authorFuture);
			}
			if(mediaMultiUpload) {
				MediaUpload caller = new MediaUpload(botInfo, new String[] {FORMNAME_FILE, FORMNAME_THUMBNAIL}, true);
				callWithRetry(botInfo,caller, "mediaUpload(" + mediaID +")"
						, () -> botInfo.getDbOper().saveMediaUploadFailed(botInfo, fileEntity))
				.whenComplete(callDb);
			}else {
				MediaUpload caller = new MediaUpload(botInfo, new String[] {FORMNAME_FILE}, true);
				callWithRetry(botInfo,caller, "mediaUpload(" + mediaID + "-" + FORMNAME_FILE +")"
						, () -> botInfo.getDbOper().saveMediaUploadFailed(botInfo, fileEntity))
				.whenComplete(callDb);
				caller = new MediaUpload(botInfo, new String[] {FORMNAME_THUMBNAIL}, false);
				callWithRetry(botInfo,caller, "mediaUpload(" + mediaID + "-" + FORMNAME_THUMBNAIL +")"
						, () -> botInfo.getDbOper().saveMediaUploadFailed(botInfo, fileEntity))
				.whenComplete(callDb);
			}
			
			future.whenComplete((v,t) ->{
				if(t!=null)log.warn("Error, upload media(" + fileEntity.getMediaID() + ") failed. " + t.getMessage()+ "",t);
			});
			LocalDateTime waitToTime = LocalDateTime.now().plusSeconds(60);
			while(!future.isDone() && LocalDateTime.now().isBefore(waitToTime)) {
				future.wait(100);
			}
			if(future.isDone()) {
				//future.get();
				return true;
			}
		} catch (Exception e) {}
		return false;
	}
	
	/***
	 * ɾ��ý��
	 * 
	 * @param botInfo
	 * @param media
	 * @return
	 */
	@Override
	public boolean mediaDelete(final BotInfo botInfo, final UploadFileEntity media) {
		class DeleteMediaCallable extends HttpCallable{
			String deleteUrl = null;
			DeleteMediaCallable(BotInfo botInfo, String url){
				super(botInfo);
				this.deleteUrl = url;
			}
			public String call() throws Exception{
				Map<String, Object> headers= new HashMap<>();
				headers.put("Content-Type", "application/json");
				headers.put("url", this.deleteUrl);
				ZonedDateTime nowTime =ZonedDateTime.now(ZoneOffset.ofHours(0));
				String date = DateTimeFormatter.RFC_1123_DATE_TIME.format(nowTime);
				headers.put("date", date);
				String url=getUrl(botInfo,getUrlMediasDelete(), headers);
				if(log.isDebugEnabled())log.debug("deleting chatbot media " + url);
				String body = null;
				String rspBody = doHttp(url, body, headers, null, BotUtil.utf8, "DELETE", null);
				if(log.isDebugEnabled())log.debug("Deleted media(" + media.getMediaID() + ") url:" + deleteUrl + " rsp:" + rspBody);
				if(rspBody==null || rspBody.isEmpty())throw new IOException("do http error, no content!");
				BotResult result = gson.fromJson(rspBody, BotResult.class);
				if(result.getErrorCode()!=0) {
					throw new IOException("result error," + result + " (" + body + ")");
				}

				return rspBody;
			}
		};
		
		try {
			final CompletableFuture<Boolean> mediaFuture = new CompletableFuture<>();
			final CompletableFuture<Boolean> thumbnailFuture = new CompletableFuture<>();
			if(media.getChatbotMediaUrl()!=null && !media.getChatbotMediaUrl().isEmpty()) {
				callWithRetry(botInfo, new DeleteMediaCallable(botInfo, media.getChatbotMediaUrl()), "mediaDelete")
				.whenComplete((rspBody, t)->{
					/**
{ 
  "deleteMode": "perm", 
  "fileCount": 20,   
  "totalCount": 100, 
  "errorCode": 0, 
  "errorMessage": "success" 
} 
					 */
					mediaFuture.complete(true);	
				});
			}else {
				mediaFuture.complete(true);	
			}
			if(media.getChatbotThumbnailUrl()!=null && !media.getChatbotThumbnailUrl().isEmpty()) {
				callWithRetry(botInfo, new DeleteMediaCallable(botInfo, media.getChatbotThumbnailUrl()), "thumdnailMediaDelete")
				.whenComplete((rspBody, t)->{
					/**
{ 
  "deleteMode": "perm", 
  "fileCount": 20,   
  "totalCount": 100, 
  "errorCode": 0, 
  "errorMessage": "success" 
} 
					 */
					thumbnailFuture.complete(true);	
				});
			}else {
				thumbnailFuture.complete(true);	
			}
			CompletableFuture<Void> future = CompletableFuture.allOf(mediaFuture, thumbnailFuture);
			LocalDateTime waitToTime = LocalDateTime.now().plusSeconds(60);
			while(!future.isDone() && LocalDateTime.now().isBefore(waitToTime)) {
				future.get(100, TimeUnit.MILLISECONDS);
			}
			if(future.isDone()) {
				media.setStatus("4");
				botInfo.getDbOper().saveMedia(botInfo, media);
				return mediaFuture.get() && thumbnailFuture.get();
			}
		} catch (Exception e) {}
		return false;
	}
	
	/**
	 * ����Url, ������header��֤��Ϣ
	 * @param botInfo
	 * @param baseUrl
	 * @param headers
	 * @return
	 * @throws IOException
	 */
	protected String getUrl(BotInfo botInfo, String baseUrl, Map<String, Object> headers) throws SpecialException{
		String filledurl=BotUtil.mustache(baseUrl, this, botInfo, botInfo.getInfos());
		String url=botInfo.getAuthorize().attach(filledurl, headers, botInfo);
		if(url==null) {
			if(botInfo.active()) url=botInfo.getAuthorize().attach(filledurl, headers, botInfo);
			if(url==null){
				throw new SpecialException("Create catbot(" +botInfo.getChatbotId() + ") authorized error, maybe this token is null!!!");
				//throw new IOException("Call chatbot authorize error, not active, so no token!");
			}
		}
		return url;
	}
	
	/**
	 * ִ�з�����Ϣ
	 * @param botInfo
	 * @param msgObj
	 * @param context
	 * @param body
	 * @return
	 * @throws IOException
	 */
	protected boolean sendMessage(BotInfo botInfo, JsonObject msgObj, BaseRcsContext context, String body, CompletableFuture<HttpInfo> future) throws IOException {
		
		Callable<String> caller = new HttpCallable(botInfo) {
			@Override
			public String call() throws Exception {
				Map<String, Object> headers = new HashMap<>();
				String url=getUrl(botInfo,getUrlMessages(), headers);
				if(log.isDebugEnabled())log.debug("posting url :" + url + " data:" + body);
				String outBody = doHttp(url, body, headers, "application/json", BotUtil.utf8, null, future);
				return outBody;
			}
		};
		String outBody;
		try {
			outBody = caller.call();
		} catch (Exception e) {
			throw e instanceof IOException?(IOException)e:new IOException("Call send message error(" + e.getMessage() + ")" ,e);
		}
		if(!Util.isNull(outBody)){
			if(log.isDebugEnabled())log.debug("result:" + outBody);
			HttpInfo conn = null;
			JsonElement jsonElement = JsonParser.parseString(outBody);
			JsonObject res = null;
			if (jsonElement != null && jsonElement.isJsonObject()) res = jsonElement.getAsJsonObject();
			if(future.isDone())
				try {
					conn = future.get(0, TimeUnit.MILLISECONDS);
				} catch (Exception ignore) {}
			if (conn != null) {
				if (res != null) {
					conn.getAttributes().put("errorCode", Util.getElementAsString(res, "errorCode"));
					conn.getAttributes().put("description", Util.getElementAsString(res, "description"));
				}
				if ("0".equals(Util.getElementAsString(res, "errorCode"))) {
					if (conn != null)
						conn.getAttributes().put("messageId", Util.getElementAsString(jsonElement.getAsJsonObject(), "messageId"));
				} else {
					log.warn("do sendMsg error,(" + outBody + ")");
					return false;
				}
			}
			return true;
		}
		return false;
	}

	@Override
	public void mediaDownload(BotInfo botInfo, String mediaUrl,String outputfile) {
		CompletableFuture<HttpInfo> future = new CompletableFuture<>();
		//����ֻ��ý���
		boolean isRawUrl = mediaUrl!=null && mediaUrl.indexOf("/media/")>0;
		if(isRawUrl) {
			try {
				if(log.isDebugEnabled())log.debug("posting chatbot media upload " + mediaUrl);
				Map<String, Object> headers= new HashMap<>();
				BotUtil.doHttp(mediaUrl, null, headers, null, BotUtil.utf8, null, future);
			}catch(Exception e) {
				log.warn("call download error",e);
			}
		}else {
			
			Map<String, Object> headers= new HashMap<>();
			headers.put("Content-Type", "application/json");
			headers.put("url", mediaUrl);
			ZonedDateTime nowTime =ZonedDateTime.now(ZoneOffset.ofHours(0));
			String date = DateTimeFormatter.RFC_1123_DATE_TIME.format(nowTime);
			headers.put("date", date);
			try {
				String url=getUrl(botInfo,getUrlMediasDownload(), headers);
				if(log.isDebugEnabled())log.debug("posting chatbot media upload " + url);
				BotUtil.doHttp(url, null, headers, null, BotUtil.utf8, null, future);
			}catch(Exception e) {
				log.warn("call download error",e);
			}
		}
		HttpInfo conn = null;
		try {
			conn = future.get(0, TimeUnit.SECONDS);
			if(conn!=null) {
				//content-Type: image/jpeg   
				//content-disposition: attachment; filename="MEDIA_ID.jpeg" 
				String contentDisp = conn.getResponseHeader("content-disposition");
				if(conn.getResponseCode()>0 && conn.getResponseCode()<300 && (isRawUrl || contentDisp!=null)) {
					if(contentDisp!=null) {
						String tag = "fileName=";
						int p = contentDisp.indexOf(tag);
						String filename = p<0?contentDisp:contentDisp.substring(p+tag.length());
						filename =filename.replace("\"", "");
					}
					
					Path target = Paths.get(outputfile);
					try(InputStream in = conn.getInputStream()){
						Files.copy(in, target, StandardCopyOption.REPLACE_EXISTING);
					}
					log.debug("Downloaded chatbot media " + mediaUrl + "->" + target);
				}else {
					log.warn("Download chatbot media error code:" + conn.getResponseCode() + " resBody:" + conn.getResponseBody());
				}
			}
		}catch(Exception e) {
			log.warn("Download chatbot media error",e);
		}

		return;
		
	}
	
	/** ֧�� ����accessToken ��ʱ����, ���Լ�������� */
	abstract class HttpCallable implements Callable<String>{
		BotInfo botInfo;
		HttpCallable(BotInfo bi){
			this.botInfo = bi;
		}
		String rspText;
		CompletableFuture<HttpInfo> innerfuture;
		boolean fixError = false;
		String doHttp(String url, final Object outBody, final Map<String, Object> headers, String contentType, final Charset chatset, String method, CompletableFuture<HttpInfo> future) throws IOException{
			this.innerfuture = future;
			rspText = BotUtil.doHttp(url, outBody, headers, contentType, chatset, method, innerfuture);
			
			//  ����accessToken ��ʱ����, ���Լ�������� 
			if(!fixError && rspText!=null && !rspText.isEmpty() && botInfo!=null) {
				try {
					fixError = true;
					BotResult result = gson.fromJson(rspText, BotResult.class);
					//{"messageId":null��"conversationId":null��"contributionId":null��"errorCode":"40014"��"errorMessage":"���Ϸ���accessToken"}
					//{"messageId":null,"conversationId":null,"contributionId":null,"errorCode":"60001","errorMessage":"���Ϸ���accessToken"}
					if(result.getErrorCode()==40014 || result.getErrorCode()==60001 || result.getErrorCode()==42001 ) {
						log.warn("AccessToken illegal, tring active again(" + botInfo.getChatbotId() + ")!");
						botInfo.setExpire();
						botInfo.active();
						rspText = this.call();
					}
				}catch(Exception e) {
					throw (e instanceof IOException)?(IOException)e:new IOException("call chatbot error(" + e.getMessage() + ")",e);
				}finally {
					fixError = false;
				}
			}
			return rspText;
		}
	}
}
