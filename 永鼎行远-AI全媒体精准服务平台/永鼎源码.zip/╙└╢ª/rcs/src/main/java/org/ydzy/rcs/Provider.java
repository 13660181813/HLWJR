package org.ydzy.rcs;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.ydzy.handler.BaseRcsContext;
import org.ydzy.rcs.annotation.Description;
import org.ydzy.rcs.entity.ReceiveEntity;
import org.ydzy.rcs.impl.UrlAction;
import org.ydzy.thirdparty.gz110.entity.InstantBean;
import org.ydzy.util.ReflectionUtils;
import org.ydzy.util.Util;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.inject.Injector;
import com.google.inject.Key;
import com.google.inject.name.Names;

public  class Provider  {
	
	public static Injector injector;
	public static void load()
	{
		injector =ReflectionUtils.injectMoudles(Description.class, "org.ydzy");
	}
	//TODO getFromDb 0r File
	public static <T> T getInstance(Class<T> claz,String beanname)
	{
		if(!Util.isNull(beanname))
	     return 	injector.getInstance(Key.get(claz, Names.named(beanname.trim())));
		else
			return null;
	}
	public static String sugestion(String suggestions,BaseRcsContext context) {
		if (Util.isNull(suggestions))
			return suggestions;
		if (suggestions.startsWith("{"))
			return suggestions;
		String[] sgs = suggestions.split(",", -1);
		;
		List<String> suggestList = new ArrayList<String>();
		String gloablParam = Util.toString(context.getAttributes().get("globalParam"));
		String weburl = "";
		if (context.getSession() != null)
			weburl = Util.toString(context.getSession().get("weburl"));
		int sidx = 0;
		for (String s1 : sgs) {
			s1 += "|" + weburl;
			String[] tmp = s1.split("\\Q|", -1);
			String suggestionkey = tmp[0] + tmp[1];
			String[] s1properties = null;
			if (sidx == 0)
				s1properties = s1.substring(s1.indexOf("|") + 1).split("\\Q|", -1);
			else
				s1properties = s1.split("\\Q|", -1);
			String suggestionType = s1properties[0];
			if (!Util.isNull(suggestionType)) {
				try {
					SuggestionDisplay instance = Provider.getInstance(SuggestionDisplay.class, suggestionType);
					if (instance instanceof UrlAction) {
						if (s1properties.length > 5) {
							String params = s1properties[5];
							s1properties[5] = params + "&" + gloablParam;

						}
					}
					String suggestionClickAction = Util.toString(RcsConfig.suggestionClickActionMap.get(suggestionkey));
					if (Util.isNull(suggestionClickAction))
						suggestionClickAction = "\"clickAction\":{},";
					else
						suggestionClickAction = "\"clickAction\":" + suggestionClickAction + ",";
					String suggestionHtml = instance.suggestionHtml(s1properties);
					int num = suggestionHtml.indexOf("displayText");
					String header = suggestionHtml.substring(0, num - 1);
					String foot = suggestionHtml.substring(num - 1);
					suggestionHtml = header + suggestionClickAction + foot;
					suggestList.add(suggestionHtml);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			sidx++;
		}
		return suggestList.stream().collect(Collectors.joining(","));
	}
	public static String parseContent(ReceiveEntity requestObject,JsonElement e,BaseRcsContext context) {
		return parseContent(requestObject,e,context,false);
	}
	public static String parseContent(ReceiveEntity requestObject,JsonElement e,BaseRcsContext context,boolean send25gMsg) {
//		String reqKeyWords = getElementAsString(allObject, "content");
		try {
			if(e==null||e.isJsonNull())
				return "";
			
			InstantBean bean =(InstantBean)requestObject.getAnswersObject().get("sessionBean");
			if(bean!=null&&bean.target!=null) {
				String target=bean.target.fromNo;
				if(!target.equals(requestObject.getMdn()))
				requestObject.getAnswersObject().put("targetId", target);
				else
					requestObject.getAnswersObject().put("targetId", bean.fromNo);
			}
			
				JsonObject eobject = e.getAsJsonObject();
				if(eobject != null)
					eobject = eobject.deepCopy();
//				String keywords = eobject.get("keywords").getAsString();
				String type = Util.getElementAsString(eobject, "type");
				if(Util.isNull(type))
				{

				}else
				{
					CardModel instance=Provider.getInstance(CardModel.class, type);
					return instance.cardHtml(requestObject, eobject,context,send25gMsg);
				}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return "";
	}
  
}
