package org.ydzy.rebuild;

import java.util.List;
import java.util.Map;

/**
 * Record Column Rebuild
 * @author XFDEP
 *
 */
public interface RecordBuildWrap {
	/**
	 * @param resultSet DB select 
	 * @param result XML config
	 * @return rebuild sucess result
	 */
	public List<Map<String,String>>  rebuild(List<Map<String,String>>  resultSet,Map<String, Object> result);
}
