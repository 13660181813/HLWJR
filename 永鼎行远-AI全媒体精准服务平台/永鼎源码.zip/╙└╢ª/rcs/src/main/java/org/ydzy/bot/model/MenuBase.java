package org.ydzy.bot.model;

/**
 * �˵�����
 * @author ljp
 *
 */
public class MenuBase {
 
	public int menuid;

	public String menutexttype;

	public transient int parentid;

	public MenuBase(int menuid, int parentid) {
		super();
		this.menuid = menuid;
		this.parentid = parentid;
	}

	public MenuBase(int menuid) {
		this(menuid, -1);
	}
	
}
