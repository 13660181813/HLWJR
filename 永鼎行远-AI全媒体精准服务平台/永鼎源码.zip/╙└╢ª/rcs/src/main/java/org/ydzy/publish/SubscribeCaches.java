package org.ydzy.publish;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.ydzy.rcs.annotation.Description;

import com.google.inject.Singleton;

@Singleton
@Description(value="SubscribeCaches")
public class SubscribeCaches {
	
	Map<String,SubscribePublish<?>> caches=new ConcurrentHashMap<>(5000);
	
	public SubscribePublish<Object> getSubscribePublishInstance(String name)
	{
		if(caches.containsKey(name))
		{
			return (SubscribePublish<Object>)caches.get(name);
		}
		else
		{
			SubscribePublish<Object> sub=new SubscribePublish<Object>(name);
			caches.put(name, sub);
			return sub;
		}
	}

	public <T> SubscribePublish<T> getSubscribePublishInstance(String name, Class<T> clazz)
	{
		if(caches.containsKey(name))
		{
			return (SubscribePublish<T>)caches.get(name);
		}
		else
		{
			SubscribePublish<T> sub=new SubscribePublish<T>(name);
			caches.put(name, sub);
			return sub;
		}
	}
}
