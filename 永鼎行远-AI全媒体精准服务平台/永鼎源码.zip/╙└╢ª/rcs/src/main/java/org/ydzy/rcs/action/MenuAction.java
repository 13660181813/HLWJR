package org.ydzy.rcs.action;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.inject.Inject;
import com.google.inject.name.Named;
import org.ydzy.rcs.db.XmlSqlGenerator;
import org.ydzy.rcs.db.XmlSqlGenerator.innerSql;
import org.ydzy.util.SqlUtil;
import org.ydzy.util.Util;

import javax.sql.DataSource;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import static org.ydzy.util.SqlUtil.queryForJson;

/**
 * @author lirui
 * @Date 2021/6/16 8:52 ����
 */
public class MenuAction {
    static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(MenuAction.class);

    @Inject
    @Named("ydzyDb")
    private DataSource ydzyds;

    private long addi18n(String text) {
        String sql = "insert into ti18n(zh_cn,zh_tw,en_us) values('" + text + "','" + text + "','" + text + "')";
        try {
            return SqlUtil.insert(ydzyds, sql);
        } catch (SQLException e) {
            log.error("insert ti18n error.", e);
        }
        return -1;
    }

    private boolean updatei18n(String text, String menuid) {
        String sql = "update ti18n set zh_cn='" + text + "', zh_tw='" + text + "',en_us='" + text + "' where id=(select menu_text_i18nid from menu_info where menu_id=" + menuid + ")";
        try {
            return SqlUtil.updateRecords(ydzyds, sql);
        } catch (SQLException e) {
            log.error("update ti18n error.", e);
        }
        return false;
    }

    public long addMenu(JsonObject menuObj) {
        String sqlId = "addYdzyMenuInfo";
        String sql = "";
        long menuid = -1;
        try {
            String menuname = Util.getElementAsString(menuObj, "menu_text");
            long i18nid = addi18n(menuname);
            menuObj.addProperty("app_id", 38);
            menuObj.addProperty("menu_text_i18nid", i18nid);
            sql = XmlSqlGenerator.getSqlByJson(sqlId, null, menuObj);
            menuid = SqlUtil.insert(ydzyds, sql);
        } catch (Exception e) {
            log.error("add menu error. menujson: {}", menuObj, e);
        }
        return menuid;
    }

    public boolean updateMenu(JsonObject menuObj) {
        boolean flag = false;
        String sqlId = "updateYdzyMenuInfo";
        try {
            String menuid = Util.getElementAsString(menuObj, "menu_id");
            if (Util.isNull(menuid))
                return false;
            String menuname = Util.getElementAsString(menuObj, "menu_text");
            flag = updatei18n(menuname, menuid);
            if (!flag)
                return false;
            String sql = XmlSqlGenerator.getSqlByJson(sqlId, null, menuObj);
            flag = SqlUtil.updateRecords(ydzyds, sql);

        } catch (Exception e) {
            flag = false;
            log.error("update menu error. menujson: {}", menuObj, e);
        }
        return flag;
    }

    public boolean delMenu(String menuid) {
        try {
            String sqlId = "deleteYdzyMenuInfo";
            Map<String, Object> param = new HashMap<>();
            param.put("menu_id", menuid);
            innerSql sql = XmlSqlGenerator.getSqlByMap(sqlId, param);
            return SqlUtil.updateRecords(ydzyds, sql.exeSql,sql.sqlParams.toArray());
        } catch (Exception e) {
            log.error("delete menu error. menuid: {}", menuid, e);
        }
        return false;
    }

    /**
     * ��ѯ�˵���·�ɹ�ϵ
     *
     * @return
     */
    public JsonArray queryMenuRouteRelation(JsonObject params) {
        JsonArray jsonArray = new JsonArray();
        String sqlId = "queryMenuRouteRelation";
        String sql = XmlSqlGenerator.getSqlByJson(sqlId, null, params);
        try {
            Map<String, JsonObject> menuMap = new HashMap<>();
            JsonArray array = SqlUtil.queryForJson(ydzyds, sql);
            if (array.isJsonNull() || array.size() == 0)
                return jsonArray;
            for (JsonElement ele : array) {
                JsonObject obj = ele.getAsJsonObject();
                String menuid = Util.getElementAsString(obj, "menuid");
                JsonObject menuObject = menuMap.get(menuid);
                if (menuObject == null) {
                    menuObject = new JsonObject();
                    menuObject.addProperty("menuid", menuid);
                    menuObject.addProperty("parentid", Util.getElementAsString(obj, "parentid"));
                    menuObject.addProperty("rank", Util.getElementAsString(obj, "rank"));
                    menuObject.addProperty("menu_text", Util.getElementAsString(obj, "menu_text"));
                    menuObject.addProperty("menu_url", Util.getElementAsString(obj, "menu_url"));
                    menuObject.addProperty("icon_uri", Util.getElementAsString(obj, "icon_uri"));
                    menuObject.addProperty("parameter", Util.getElementAsString(obj, "parameter"));
                    menuObject.addProperty("parameter_type", Util.getElementAsString(obj, "parameter_type"));
                    menuMap.put(menuid, menuObject);
                }
                JsonArray routeArray = menuObject.getAsJsonArray("routes");
                if (routeArray == null) {
                    routeArray = new JsonArray();
                    menuObject.add("routes", routeArray);
                }
                JsonObject routeObject = new JsonObject();
                String apiid = Util.getElementAsString(obj, "apiid");
                if(!Util.isNull(apiid)){
                    routeObject.addProperty("apiid", apiid);
                    routeObject.addProperty("apiname", Util.getElementAsString(obj, "apiname"));
                    routeObject.addProperty("apiinfo", Util.getElementAsString(obj, "apiinfo"));
                    routeObject.addProperty("apitype", Util.getElementAsString(obj, "apitype"));
                    routeObject.addProperty("updatdate", Util.getElementAsString(obj, "updatdate"));
                    routeObject.addProperty("operator", "0");
                    routeArray.add(routeObject);
                }
            }
            menuMap.forEach((s, jsonObject) -> {
                jsonArray.add(jsonObject);
            });

        } catch (Exception e) {
            log.error("query menu route relation error.", e);
        }
        return jsonArray;
    }
    public boolean editMenuRouteRelation(JsonObject object) {
        String menuid = Util.getElementAsString(object, "menuid");
        JsonArray routeArray = object.getAsJsonArray("routes");
        if (Util.isNull(menuid) || routeArray.size() == 0)
            return true;
        StringBuilder sqls = new StringBuilder("");
        for (JsonElement ele : routeArray) {
            JsonObject obj = ele.getAsJsonObject();
            String operator = Util.getElementAsString(obj, "operator");
            String apiid = Util.getElementAsString(obj, "apiid");
            String sql = "";
            switch (operator) {
                case "-1" -> {sql = delMenuRouteRelation(menuid, apiid);}
                case "1" -> {sql = addMenuRouteRelation(menuid, apiid);}
            }
            if (!Util.isNull(sql))
                sqls.append(sql).append(";");
        }
        if (!Util.isNull(sqls.toString())) {
            try {
                return SqlUtil.updateRecords(ydzyds, sqls.toString());
            } catch (SQLException throwables) {
                log.error("editMenuRouteRelation error.", throwables);
                return false;
            }
        }
        return true;
    }

    public String addMenuRouteRelation(String menuid, String apiid) {
        String sqlId = "addMenuRouteRelation";
        return XmlSqlGenerator.getSqlstr(sqlId, menuid, apiid);
    }

    public String delMenuRouteRelation(String menuid, String apiid) {
        String sqlId = "delMenuRouteRelation";
        return XmlSqlGenerator.getSqlstr(sqlId, menuid, apiid);
    }

    public JsonArray getMenus(String groupId, String appId) {
        return getMenus(groupId, appId, "H5");
    }

    public JsonArray getMenus(String groupId, String appId, String levels) {
        log.info("start load menu info");
        String sqlId = "queryYdzyMenuByGroup";
        JsonObject param = new JsonObject();
        param.addProperty("groupid", groupId);
        param.addProperty("levels", levels);
        String sql = XmlSqlGenerator.getSqlByJson(sqlId, null, param);
        try {
            JsonArray array = queryForJson(ydzyds, sql);
            log.info("load menu info success. menu size: {}", array.size());
            return array;
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return new JsonArray();
    }

    public JsonArray getRoutes(JsonArray menuArray, String serverCode, String groupId) {
        return getRoutes(menuArray, serverCode, groupId, "H5");
    }

    public JsonArray getRoutes(JsonArray menuArray, String serverCode, String groupId, String agent) {
        StringBuffer menuids = new StringBuffer("");
        try {
            if (!menuArray.isJsonNull() && menuArray.size() > 0) {
                menuArray.forEach(jsonElement -> {
                    menuids.append(jsonElement.getAsJsonObject().get("menu_id").getAsInt()).append(",");
                });
            }
            if (!Util.isNull(menuids.toString())) {
                String s = menuids.toString();
                s = s.substring(0, s.length() - 1);
                return getRouteByMenus(serverCode, s, groupId, agent);
            }
        } catch (Exception e) {
            log.error("load menu route error.", e);
        }
        return new JsonArray();
    }

    public JsonArray getRouteByMenus(String appid, String menuids, String groupid, String agent) {
        String sqlId = "queryRouteByMenus";
        try {
            JsonObject params = new JsonObject();
//            Map<String, Object> params = Maps.newHashMap();
            params.addProperty("appid", appid);
            params.addProperty("menuid", menuids);
            params.addProperty("groupid", groupid);
            params.addProperty("levels", agent);
            String sql = XmlSqlGenerator.getSqlByJson(sqlId, null, params).replace("��", ",");
//        	String sql = XmlSqlGenerator.getSql(sqlId, appid, menuids, groupid).exeSql;
            JsonArray array = queryForJson(ydzyds, sql);
            for (JsonElement element : array) {
                JsonObject jsonObject = element.getAsJsonObject();
                JsonObject rightObject = new JsonObject();
                JsonElement rightElement = jsonObject.get("operatorRight");
                if (rightElement != null) {
                    try {
                        rightObject = JsonParser.parseString(rightElement.getAsString()).getAsJsonObject();
                    } catch (Exception e) {
                        log.error("parse route right error.");
                    }
                }
                rightObject.addProperty("isquery", 1);
                jsonObject.add("operatorRight", rightObject);
            }
            return array;
        } catch (Exception e) {
            log.error("query route error.", e);
        }
        return null;
    }

    /*
    public JsonArray getMenus(String groupId, String appId) {
        log.info("start load menu info");
        String sqlId = "getMenusByGroupId4PC";
        JsonObject param = new JsonObject();
        param.addProperty("groupid",groupId);
        String sql = XmlSqlGenerator.getSqlByJson(sqlId, null, param);
        try {
            JsonArray array = queryForJson(ydzyds, sql);
            log.info("load menu info success. menu size: {}", array.size());
            return array;
        } catch (SQLException e) {
            log.error("getMenus error:", e);
        }
        return new JsonArray();
    }*/
}
