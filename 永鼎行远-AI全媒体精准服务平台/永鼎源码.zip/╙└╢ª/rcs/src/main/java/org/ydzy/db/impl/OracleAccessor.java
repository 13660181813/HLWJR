package org.ydzy.db.impl;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.ydzy.db.DbAccessor;
import org.ydzy.rcs.annotation.Description;
import org.ydzy.util.TimeUtil;
import org.ydzy.util.Util;

import com.google.inject.Singleton;
@Singleton
@Description("oracleAdaptor")
public class OracleAccessor  implements DbAccessor{
	 

	@Override
	public Set<String> tableExist(String dsId,String tname  ) {
		String sql_trueTabNames="SELECT TNAME FROM TAB WHERE (TABTYPE='TABLE' OR TABTYPE='VIEW') AND TNAME IN ("+tname.toUpperCase()+") ORDER BY TNAME ASC";
		try {
			List<Object> result =exeQueryForSingleCol(dsId,sql_trueTabNames);
			if(result!=null)
			{
				return result.stream().map(o->Util.toString(o)).collect(Collectors.toSet());
			}
		} catch ( Exception e) {
			 log.error(" datasource {}  sql {} check table exists error ",dsId,sql_trueTabNames,e);
		}
		return null;
	}

	@Override
	public String getDateExpress(long date) {
		String format="yyyy-MM-dd HH:mm:ss";
		String strDate=TimeUtil.formatDay(date, format);
		return "to_date('"+strDate+"','yyyy-MM-dd HH24:mi:ss')";
	}
	public String queryForPage(String sql, String where,int rmin,int rmax) {
		if(!Util.isNull(where))
			where=where+" AND RNUM BETWEEN "+rmin+" AND "+rmax;
		else
			where=" WHERE  RNUM BETWEEN "+rmin+" AND "+rmax;
		String newsql="  select T1.* FROM (SELECT T.*,rownum RNUM FROM   ("+sql+" ) T ) T1 "+ where;
		return newsql;
	}
}
