package org.ydzy.rcs.impl;

import org.ydzy.rcs.SuggestionDisplay;
import org.ydzy.rcs.annotation.Description;
import org.ydzy.util.StringUtils;

import com.google.inject.Singleton;

@Singleton
@Description("requestLocationPush")
public class RequestLocationPush implements SuggestionDisplay{
	private 	 String locationPush = "    {\r\n" 
			+ "        \"action\":{\r\n" 
			+ "            \"displayText\":\"%s\",\r\n" 
			+ "            \"mapAction\":{\r\n"
			+ "                \"requestLocationPush\":{}\r\n" 
			+ "            },\r\n"
			+ "            \"postback\":{\r\n"
			+ "                \"data\":\"set_by_chatbot_open_map\"\r\n" 
			+ "            }\r\n"
			+ "        }\r\n" + "}";
	@Override
	public String suggestionHtml(String[] args) {
		int length=args.length;
		return StringUtils.format(locationPush, length<=1?"":args[0]);
	}

}
