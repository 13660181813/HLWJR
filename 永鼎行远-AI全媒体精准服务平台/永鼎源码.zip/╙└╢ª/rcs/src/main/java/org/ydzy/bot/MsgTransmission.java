package org.ydzy.bot;

import java.io.IOException;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;

import javax.sql.DataSource;

import org.ydzy.handler.BaseRcsContextProvidor;
import org.ydzy.publish.ConstantTopics;
import org.ydzy.publish.ISubscriber;
import org.ydzy.publish.SubscribeCaches;
import org.ydzy.publish.SubscribePublish;
import org.ydzy.rcs.Provider;
import org.ydzy.rcs.action.RcsRunLogAction;
import org.ydzy.rcs.annotation.Description;
import org.ydzy.rcs.entity.ReceiveEntity;
import org.ydzy.util.NetUtils;
import org.ydzy.util.Util;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonSyntaxException;
import com.google.inject.Inject;
import com.google.inject.Singleton;
import com.google.inject.name.Named;

@Singleton
@Description(value="MsgTransmit",autoInstance=true)
public class MsgTransmission   implements ISubscriber<ReceiveEntity> {
	private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(MsgTransmission.class);
	private AtomicLong sendNum=new AtomicLong();
	public MsgTransmission() {
		
	}

	public void init()
	{
		if(subscribeCaches==null)
			subscribeCaches=Provider.injector.getInstance(SubscribeCaches.class);
		SubscribePublish sub=subscribeCaches.getSubscribePublishInstance(ConstantTopics.CHARTBOT_MSG_DISPOSED);
		this.subscribe(sub);
	}
	@Inject
	SubscribeCaches subscribeCaches;
	@Inject
	private BaseRcsContextProvidor contextProvidor = null;
	public BaseRcsContextProvidor getContextProvidor() {
		return contextProvidor;
	}
	@Inject
	BotManager botmanager;
	@Override
	public void subscribe(SubscribePublish subscribePulish) {
		subscribePulish.subcribe(this);
	}

	@Override
	public void unSubscribe(SubscribePublish subscribePulish) {
		subscribePulish.unSubcribe(this);
		
	}
	@Inject
	@Named("rcsDb")
	protected DataSource ds;
	@Override
	public void update(String publisher, ReceiveEntity message) {
		BotInfo bi = null;
		String chatBotID=message.getChatBotId();
		bi = botmanager.getChatBotInfo(chatBotID);
		if(bi==null) {
			chatBotID = message.getSenderAddress();
			bi = botmanager.getChatBotInfo(chatBotID);
		}
		
		if(bi==null)
		{
			log.error("unAuthorised chatbot ,id is error  {} ",chatBotID);
			return ;
		}
		BotInfo info = bi;
		org.ydzy.handler.BaseRcsContext context = contextProvidor.newBaseRcsContext();
		
		ThirdPartyApiAccessToken token =new ThirdPartyApiAccessToken();
		Map<String, List<Map<String, Object>>> sub=	context.getConfig().getSubscribers();
		if(sub!=null)
		{
			//TODO ���Ӷ��Ķ���
			sub.forEach((k,v)->{
				if(v!=null)
				{
					
					for(Map<String, Object> subobj:v)
					{
						String actionType=Util.toString(subobj.get("actionType"));
						if("1".equals(actionType))
						{
							try {
								String params=Util.toString(subobj.get("parameters"));
								if(!Util.isNull(params))
								{
									JsonElement paramObj=JsonParser.parseString(params);
									if(paramObj!=null)
									{
										JsonObject pO=paramObj.getAsJsonObject();
										String url=Util.getElementAsString(pO, "url");
										
										Map<String, Object> headers =new HashMap<String,Object>();
//									if(message.getAnswersObject().containsKey("botInfo"))
										headers=token.headers(info);
										JsonObject bodys=new JsonObject();
										if(!Util.isNull(url))
										{
											//TODO send msg to url
											List<Map<String, Object>> dinofs=null;
											
											if(message.getAnswersObject().containsKey("download"))
											{
												 dinofs =(List<Map<String, Object>>) message.getAnswersObject().get("download");
											}
											if(dinofs!=null)
											{
												JsonArray contentText =new JsonArray();
												for(Map<String, Object> io:dinofs)
												{
													
													if(io.containsKey("thhumbnailurl"))
													{
														JsonObject obj=new JsonObject();
														obj.addProperty("type","thumbnail");
														obj.addProperty("fileSize", Util.toString(io.get("thhumbnailLFilesize")));
														obj.addProperty("contentType", Util.toString(io.get("thumbcontentType")));
														obj.addProperty("url", Util.toString(io.get("thhumbnailurl")));
														obj.addProperty("fileName", Util.toString(io.get("thhumbnailLFilename")));
														contentText.add(obj);
													}
													if(io.containsKey("url"))
													{
														JsonObject obj=new JsonObject();
														obj.addProperty("type", "file");
														obj.addProperty("fileSize", Util.toString(io.get("FileSize")));
														obj.addProperty("contentType", Util.toString(io.get("filecontentType")));
														obj.addProperty("url", Util.toString(io.get("url")));
														obj.addProperty("fileName", Util.toString(io.get("Filename")));
														contentText.add(obj);
													}
													
												}
												bodys.add("contentText", contentText);
												String contentEncoding="utf8";
												String contentType="application/vnd.gsma.rcs-ft-http";
												bodys.addProperty("contentType", contentType);
												bodys.addProperty("contentEncoding", contentEncoding);
											}
											
										}else
										{
											String contentEncoding="base64";
											bodys.addProperty("contentType", "text/plain");
											bodys.addProperty("contentEncoding", contentEncoding);
											String content=										message.getContent();
											bodys.addProperty("contentText", new String(Base64.getEncoder().encode(content.getBytes())));
										}
										try {
											String content=new Gson().toJson(bodys);
											String res=NetUtils.doHttps(url,content , headers, "");
											long num=sendNum.incrementAndGet();
											log.debug("subscribersId {}  chatbotid {} transmission records  {} ,message {} response {}",subobj.get("subscribersId"),subobj.get("chatbotid"),content,num,res);
											
											if(ds!=null)
											{
												RcsRunLogAction.recordLog("subscriberd transmission sucess !",Util.toString(subobj.get("subscribersId")), url, content, "MsgTransimission", ds);
											}
										} catch (IOException e) {
											e.printStackTrace();
										}
									}
								}
							} catch (JsonSyntaxException e) {
								e.printStackTrace();
							}
						}
					}
				}
			});
		}
		
	}

}
