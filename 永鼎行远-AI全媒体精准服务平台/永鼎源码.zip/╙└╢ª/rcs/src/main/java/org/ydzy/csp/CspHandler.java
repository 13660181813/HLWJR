package org.ydzy.csp;

import java.io.IOException;
import java.nio.charset.Charset;

import org.ydzy.csp.service.BaseCspInter;
import org.ydzy.handler.BaseHandler;
import org.ydzy.rcs.Provider;
import org.ydzy.util.StreamsUtil;
import org.ydzy.util.Util;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class CspHandler extends BaseHandler{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Override
	public void handle(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		String isp=request.getParameter("isp");
		String remoteAddr=getIpAddress(request);
		if(Util.isNull(isp))
		{
				String content = resBody("500",
				"content/format error ! ContentType should be  application/json;charset=utf-8 ,But received null isp is null",
				null);
				logger("error","500","body is null",content,remoteAddr,request,response,"CspHandler","","");
				sendResponse(remoteAddr, content, HttpServletResponse.SC_OK, request, response);
				return;
		}
		BaseCspInter cspimp=null;
		
		try {
			cspimp=Provider.getInstance(BaseCspInter.class, isp+"Csp");
		} catch (Exception e) {
			cspimp=Provider.getInstance(BaseCspInter.class, "cmccCsp");
		}
		cspimp.checkAccessToken(ds,request);
		String contentType=request.getContentType();
		
		JsonObject object = null;
		if(!Util.isNull(contentType)&&(contentType.equals("multipart/form-data")||contentType.indexOf("multipart")>-1))
		{
			cspimp.handler(request, response, ds, object);
		}else
		{
			String body = StreamsUtil.copyToString(request.getInputStream(), Charset.forName("UTF-8"));
			if (!Util.isNull(body)) {
				JsonElement ele = JsonParser.parseString(body);;
				object = ele.getAsJsonObject();
			}
			if (object == null) {
				String content = resBody("500",
						"content/format error ! ContentType should be  application/json;charset=utf-8 ,But received "
								+ body,
						null);
				logger("error","500","body is null",content,remoteAddr,request,response,"CspHandler","","");
				sendResponse(remoteAddr, content, HttpServletResponse.SC_OK, request, response);
				return;
				
			}
			cspimp.handler(request, response, ds, object);
		}
		
	}
	private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(CspHandler.class);
	
	
  
    
   
    
}
