package org.ydzy.rcs.impl;

import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;

import org.eclipse.jetty.util.resource.Resource;
import org.ydzy.rcs.RcsConfig;
import org.ydzy.rcs.annotation.Description;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.inject.Singleton;

@Singleton
@Description("Jsonfile")
public class RcsConfigFromfile extends RcsConfig {
	
	
	@Override
	public void load() {
		String records="";
		try {
			records = Files.readString(Path.of(Resource.newSystemResource("config").getURI()),Charset.forName("GBK"));
			JsonElement element = JsonParser.parseString(records);
			JsonArray contentobject = element.getAsJsonArray();
			this.rcsConfig=contentobject;
			this.chatbotInfo=getDefaultChatBot();
			
//			this.AiMap= getDefaultAiMap();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		this.setProcessStore(ProcessStoreImp.getInstance());
	}
	private Map<String,Integer> getDefaultAiMap()
	{
		Map<String,Integer> AiMap=new HashMap<String, Integer>(){
			{
				put("�˷�ʱЧ",(ProcessStoreImp.FROM.stepid));
				put("timeQuery_0",(ProcessStoreImp.FROM.stepid));
//				put("��Ҫ�ļ�",(ProcedureStatus.process.sendername.stepid));
				put("��Ҫ���",(ProcessStoreImp.querystart.stepid));
				put("��ݼļ�",(ProcessStoreImp.sendQuack.stepid));
			}
		};
		return AiMap;
	}
	private  Map<String, JsonObject>  getDefaultChatBot()
	{
		 Map<String, JsonObject> chatbot = new HashMap<String, JsonObject>() {
				{
					put("dccar", JsonParser.parseString("{ "
							+ "\"sp\" : \"sip:1065051210646@botplatform.rcs.chinamobile.com\","
							+ "\"key\" : \"Huawei@123\", "
							+ "\"appId\" : \"60429\",\r\n"
							+ "\"terminal\" :	\"Chatbot\", "
							+ "\"capabilityId\" : \"ChatbotSA\", "
							+ "\"version\" : '+g.gsma.rcs.botversion=\"#=2\"',"
							+ "\"defaultName\" :  \"�Ϻ���������4s��\" "
							+ "}").getAsJsonObject());
					put("kdzj",JsonParser.parseString(" {"
							+ "\"sp\" : \"sip:1065051210681@botplatform.rcs.chinamobile.com\", "
							+ "\"key\" : \"Huawei@123\", "
							+ "\"appId\" : \"60445\","
							+ "\"terminal\" :	\"Chatbot\", "
							+ "\"capabilityId\" : \"ChatbotSA\", "
							+ "\"version\" : '+g.gsma.rcs.botversion=\"#=2\"', "
							+ "\"defaultName\" : \"���֮��\""
							+ "}").getAsJsonObject()
							 );
				}
			};
			return chatbot;
	}

}
