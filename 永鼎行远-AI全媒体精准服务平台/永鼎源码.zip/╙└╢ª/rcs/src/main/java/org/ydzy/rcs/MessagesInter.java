package org.ydzy.rcs;

import java.util.List;

import org.ydzy.handler.BaseRcsContext;
import org.ydzy.rcs.entity.ReceiveEntity;

import com.google.gson.JsonObject;

public interface MessagesInter {
	
	public String body(ReceiveEntity requestObject,JsonObject eobject,BaseRcsContext context,List<MessageBody> body);
	
	public static class MessageBody{
		/**
		 * contentType  �� text/plain ,  application/vnd.gsma.botmessage.v1.0+json  application/vnd.gsma.botsuggestion.v1.0+json application/vnd.gsma.rcs-ft-http ��
		 * */
		public String contentType;
		
		/**
		 * utf8 base64 
		 * */
		public String contentEncoding;
		
		public Object contentText;
	}
	

	default public String multipart(String bondary, List<MessageBody> body) {
//	String body=
//			 "--next\r\n"
//			+ "Content-Type: application/vnd.gsma.botmessage.v1.0+json\r\n" 
//			+ "Transfer-Encoding: chunked\r\n"
//			+ "\r\n" 
//			+ "%s\r\n"// text content msg
//			+ "--next\r\n" 
//			+ "Content-Type: application/vnd.gsma.botsuggestion.v1.0+json\r\n"//
//			+ "Transfer-Encoding: chunked\r\n" 
//			+ "\r\n" 
//			+ "{" 
//			+ "\"suggestions\":[%s]" 
//			+ "}\r\n" 
//			+ "--next--\r\n"
//			;
		StringBuilder sb = new StringBuilder();
		String newLine = "\r\n";
		for(MessageBody e:body) {
			if(e.contentText==null)continue;
			sb.append("--").append(bondary).append(newLine);
			sb.append("Content-Type: ").append(e.contentType).append(newLine);
			if(e.contentEncoding!=null) {
				sb.append("Transfer-Encoding: ").append(e.contentEncoding).append(newLine);
			}
			sb.append(newLine);
			sb.append(e.contentText).append(newLine);
		}
		sb.append("--").append(bondary).append("--").append(newLine);
		return sb.toString();
	}
}
