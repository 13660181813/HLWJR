package org.ydzy.rcs.decker;

import org.ydzy.publish.ConstantTopics;
import org.ydzy.publish.IPublisher;
import org.ydzy.publish.SubscribeCaches;
import org.ydzy.publish.SubscribePublish;
import org.ydzy.rcs.BodyTransform;
import org.ydzy.rcs.annotation.Description;
import org.ydzy.rcs.entity.ReceiveEntity;

import com.google.gson.JsonElement;
import com.google.inject.Inject;
import com.google.inject.Singleton;
@Singleton
@Description(value = "publicTOPICS")
public class PublishTopic  implements DeckerRobot{
	@Inject
	SubscribeCaches subscribeCaches;
	@Override
	public JsonElement doTransform(BodyTransform transform, JsonElement efind) {
		publishTopic(transform);
		transform.continued=true;
		return null;
	}
	private void publishTopic(BodyTransform transform)
	{
		SubscribePublish sub = subscribeCaches.getSubscribePublishInstance(ConstantTopics.CHARTBOT_MSG_RECEIVE);
		IPublisher<ReceiveEntity> publishObj = new IPublisher<ReceiveEntity>() {
			@Override
			public void publish(SubscribePublish subscribeObj, ReceiveEntity message, boolean isInstantMsg) {
				subscribeObj.publish(ConstantTopics.CHARTBOT_MSG_RECEIVE + "_Subscribers", message, isInstantMsg);
			}
		};
		publishObj.publish(sub, transform.receiveEntity, false);
	}

}
