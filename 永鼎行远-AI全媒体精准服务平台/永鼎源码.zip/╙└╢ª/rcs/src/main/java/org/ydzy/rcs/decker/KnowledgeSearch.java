package org.ydzy.rcs.decker;

import org.ydzy.handler.BaseRcsContext;
import org.ydzy.rcs.BodyTransform;
import org.ydzy.rcs.annotation.Description;
import org.ydzy.rcs.entity.ReceiveEntity;

import com.google.gson.JsonElement;
import com.google.inject.Singleton;

@Singleton
@Description(value = "knowledgeSearchchatbot")
public class KnowledgeSearch  implements DeckerRobot{
	
	@Override
	public JsonElement doTransform(BodyTransform transform,JsonElement efind) {
		if(efind==null)
		{
			BaseRcsContext context=transform.context;
			ReceiveEntity receiveEntity =transform.receiveEntity;
//			efind=checkIsKeyWords(receiveEntity,context);
			String reqKeyWords = receiveEntity.getContent();;
			efind=context.getConfig().getKeyWordsLike(receiveEntity.getChatBotId(),reqKeyWords);
		}
		transform.continued=true;
		return efind;
	}

}
