package org.ydzy.jdbc.control.result.datepattern;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.ydzy.rcs.annotation.Description;
import org.ydzy.util.TimeUtil;

import com.google.inject.Singleton;

@Description(autoInstance = false,value = "hourTname")
@Singleton
public class HourTname implements ITime{

	@Override
	public List<String> reckonName(String pattname,long timeInterval,  String sDate, String eDate, Calendar c1, Calendar c2) throws ParseException {
		
		List<String> tablelist =new ArrayList<String>();

		SimpleDateFormat sdfPattern = new SimpleDateFormat(pattname);
		
		String radiustable =pattname
				.substring(pattname.indexOf("'") + 1, pattname.lastIndexOf("'")).toUpperCase();


		if(pattname.indexOf("'")<0)
			tablelist.add(pattname);
			long slDate=TimeUtil.convertDate(sDate);
			long elDate=TimeUtil.convertDate(eDate);
			if(pattname.indexOf("$")>-1){
				String moreflag= pattname.substring(pattname.indexOf("$"),pattname.lastIndexOf("'"));
				pattname = pattname.replace(moreflag, "");
			}
			sdfPattern = new SimpleDateFormat(pattname);
			long time=slDate;
			String eName = sdfPattern.format(elDate);
			for(String tn;(tn=sdfPattern.format(time)).compareTo(eName)<=0;time+=TimeUtil.oneHour){
				if(!tablelist.contains(tn)) tablelist.add(tn);
			}
		return tablelist;
	}

}
