package org.ydzy.rcs.impl;


import org.ydzy.rcs.SuggestionDisplay;
import org.ydzy.rcs.annotation.Description;
import org.ydzy.util.StringUtils;

import com.google.inject.Singleton;

@Singleton
@Description(value="dialEnrichedCall")
public class DialEnrichedCall implements SuggestionDisplay{
	private  String dialerrich = "{\r\n" 
			+ "\"action\":\r\n" 
			+ "		{\r\n" 
			+ "			\"displayText\":\"%s\",\r\n"
			+ "			\"dialerAction\":\r\n" 
			+ "			{\r\n" 
			+ "				\"dialEnrichedCall\":{\r\n"
			+ "				\"phoneNumber\":\"%s\",\r\n" 
			+  "			\"fallbackUrl\":\"%s\",\r\n" 
			+ "				\"subject\":\"%s\"\r\n" 
			+ "				}\r\n"
			+ "			}\r\n"
			+ "		}\r\n" 
			+ "}\r\n";
	@Override
	public String suggestionHtml(String[] args) {
		//TODO ARGS[0] DISPLAY TEXT subject order
		int length=args.length;
		return StringUtils.format(dialerrich, length<=0?"":args[0], length<=1?"":args[1].replace("��", ","), length<=2?"":args[2], length<=3?"":args[3]);
		
		
	}

}
