package org.ydzy.rcs.impl;

import org.ydzy.rcs.SuggestionDisplay;
import org.ydzy.rcs.annotation.Description;

import com.google.inject.Singleton;

@Singleton
@Description("mapAction")
public class MapAction implements SuggestionDisplay {

	@Override
	public String suggestionHtml(String[] args) {
		return suggestionHtmlSubs(args);
	}

}
