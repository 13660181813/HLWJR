package org.ydzy.rcs;

import javax.sql.DataSource;

import org.ydzy.rcs.media.UploadFileEntity;

public abstract class Upload {
	public abstract void doUpload(UploadFileEntity param);

	protected DataSource dbSource;
	public void setDbSource(DataSource dbSource) {
		this.dbSource = dbSource;
	}
}
