package org.ydzy.csp;

import java.io.IOException;
import java.nio.charset.Charset;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

import com.google.gson.JsonArray;
import org.slf4j.LoggerFactory;
import org.ydzy.csp.service.BaseCspInter;
import org.ydzy.csp.service.CuccCsp;
import org.ydzy.handler.BaseHandler;
import org.ydzy.rcs.Provider;
import org.ydzy.rcs.db.XmlSqlGenerator;
import org.ydzy.rcs.impl.OperationLogService;
import org.ydzy.rcs.module.LoadProperties;
import org.ydzy.util.SqlUtil;
import org.ydzy.util.StreamsUtil;
import org.ydzy.util.Util;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class NotifyCspAudit extends BaseHandler {

    /**
     *
     */
    private static final long serialVersionUID = -6887206568528860217L;
    private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(NotifyCspAudit.class);
    private String ispName = "";//String name="telcsp"

    public String getIspName() {
        return ispName;
    }

    public void setIspName(String ispName) {
        this.ispName = ispName;
    }

    /**
     *
     */
    @Override
    public void handle(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        BaseCspInter cspimp = Provider.getInstance(BaseCspInter.class, ispName + "Csp");
        String body = StreamsUtil.copyToString(request.getInputStream(), Charset.forName("UTF-8"));
        JsonObject object = null;
        HashMap<String, String> map = null;
        log.info("NotifyCspAudit receive data: {} ", body);
        if (!Util.isNull(body)) {
            JsonElement ele = JsonParser.parseString(body);
            object = ele.getAsJsonObject();
        }
        String type = Util.getElementAsString(object, "type");
        boolean flag = true;//	cspimp.validateHeader(request,ds);
        String operationType = "";
        if (!flag) {
            //TODO unknown Type
            String resbody1 = resBodyJson("500", "accessToken validate failed or timeout", null);
            try {
                sendResponse(BaseHandler.getIpAddress(request), resbody1, 200, request, response);
                return;
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else {
			/*
			 *11 ���ڽ���˲�������� CSP ����
			 ֪ͨ���ͣ�1���ͻ���2��chatbot
			 
			 */
            String sqlid = "";
            if ("1".equals(type)) {

                //update rcs_csp_ecinfo set auditStatus={'auditStatus'} , description='opType:{opType} desc: {description}' where cspEcNo='{auditNo}'
                sqlid = "updatescpecaudit";

            } else if ("2".equals(type)) {
                int auditStatus = Util.getElementAsInt(object, "auditStatus", 13) == 1 ? 12 : 13;
                operationType = 12 == auditStatus ? "�����Ϣ���ͨ��":"�����Ϣ��˲�ͨ��";
                // TODO ������״̬��Ҫȥ�޸�
                String accessTagNo = object.get("auditNo").getAsString();
                map = getOrgAuditStatus(accessTagNo);
                String orgAuditStatus = map.get("auditStatus");
                String orgEnable = map.get("enable");
                // 12Ϊ���ͨ���� 13Ϊ��˲�ͨ��

                 object.addProperty("enable", orgEnable);
                // �˳�����״̬ ���� ���ͨ����� �ſ��Է����޸�enableΪ1���ò���Ϊ��0->1 �ĵ������
                if ("18".equals(orgAuditStatus) && auditStatus == 12) {
                    object.addProperty("enable", 1);
                    operationType = "�˳�����״̬���ͨ��";
                }
                boolean isTrue = "10".equals(orgAuditStatus) || "11".equals(orgAuditStatus) || "13".equals(orgAuditStatus);
                // ���ܴ��ڳ��� enable Ϊ 1��2״̬�� auditStatus Ϊ 10��11״̬
                // (1) ���ܴ��ڳ��� enable Ϊ 1��2״̬�� auditStatus Ϊ 10��11״̬; ��ʱenable ���޸�
                // (2) ���ܴ��ڳ��� enable Ϊ 1��2״̬�� auditStatus Ϊ 10��11״̬;
                if ( isTrue && auditStatus == 12) {
                    String newEnable  = ("1".equals(orgEnable) || "2".equals(orgEnable)) ? orgEnable : "3";
                    object.addProperty("enable", newEnable);
                    map.put("accessTagNo", accessTagNo);
                    operationType = "�����ڲ�׶����ͨ��";
                }

                object.addProperty("auditStatus", auditStatus);
//                //update rcs_chatbotinfo set auditStatus='{auditStatus}', enable = '{enable}'
//                     , description='opType:{opType} desc: {description}' where accessTagNo='{auditNo}'
                sqlid = "updatechatbotaudit";
                if (auditStatus == 12 && "15".equals(orgAuditStatus)) {
                    object.addProperty("type", "3");
                    sqlid = "deleteorofflinechatbot";
                    operationType = "ע��chatbot���ͨ��";
                }
            } else {
                //TODO unknown Type
                String resbody1 = resBodyJson("500", "unknow  type", null);
                try {
                    sendResponse(BaseHandler.getIpAddress(request), resbody1, 200, request, response);
                    return;
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            Map dbParam = gson.fromJson(body, Map.class);
            String sql = XmlSqlGenerator.getSqlByJson(sqlid, null, object);
            try {
                SqlUtil.updateRecords(ds, sql);
            } catch (SQLException e) {
                e.printStackTrace();
            }
            // ���Ի���
//            if ("2".equals(type)) {
//                cspimp.updateChatBotDev();
//            }
            String resbody1 = resBodyJson("200", "success", null);
            sendResponse(BaseHandler.getIpAddress(request), resbody1, 200, request, response);
//			String opType=Util.getElementAsString(object, "opType");
            // �������ͨ���������¼��־
            if ("2".equals(type)) {
                // ��¼��־��Ϣ

                int auditStatus = object.get("auditStatus").getAsInt();
                insertOperationLog("System", operationType, auditStatus, resbody1
                        , object.get("auditNo").getAsString(), type, "", map.get("isp"));
            }

//			/*
//			 �������ͣ�1��������2�������3��ɾ��
//			 * */
//			if("1".equals(opType)) //add
//			{
//			}else if("2".equals(opType))
//			{
//			}else if("3".equals(opType))
//			{
//			}
        }
    }




    /**
     * ��ȡ����״̬����Ҫ����accessTagNo
     * @param accessTagNo : chatbot��Ψһʶ���ʶ
     * @return map �� {auditStatus=xx,enable=yy}
     * @throws SQLException
     */
    private HashMap getOrgAuditStatus(String accessTagNo) {
        String sqlid = "selectchatbotinfoById";
        HashMap map = new HashMap<>(1);
        map.put("accessTagNo", accessTagNo);
        String sql = XmlSqlGenerator.getSqlstrByMap(sqlid, map);
        JsonArray jsonElements = null;
        try {
            jsonElements = SqlUtil.queryForJson(ds, sql);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        // accessTagNo Ψһ��ʶ
        JsonElement jsonElement = jsonElements.get(0);
        String auditStatus = jsonElement.getAsJsonObject().get("auditStatus").getAsString();
        String enable = jsonElement.getAsJsonObject().get("enable").getAsString();
        String isp = jsonElement.getAsJsonObject().get("isp").getAsString();
        HashMap<String, String> backMap = new HashMap<>(2);
        backMap.put("auditStatus", auditStatus);
        backMap.put("enable", enable);
        backMap.put("isp", isp);
        return backMap;
    }

    // ��װ������־��Ϣ
    public void insertOperationLog(String operationUse, String operationType, Integer operationStatus
            , String operationResult, String cspEcNo, String type, String requestBody, String isp) {

        try {
            OperationLogService operation = Provider.injector.getInstance(OperationLogService.class);
            Map map = new HashMap();
            map.put("operationTime", String.valueOf(LocalDateTime.now()));
            map.put("operationUse", operationUse);
            map.put("operationType", operationType);
            map.put("operationStatus", operationStatus);
            map.put("operationResult", operationResult);
            map.put("cspEcNo", cspEcNo);
            map.put("requestBody", requestBody);
            map.put("type", type);
            map.put("ISP", isp);
            operation.addOperationLog(map);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
