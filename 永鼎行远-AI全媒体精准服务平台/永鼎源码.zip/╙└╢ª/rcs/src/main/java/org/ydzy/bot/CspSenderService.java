package org.ydzy.bot;

import org.ydzy.handler.BaseRcsContextProvidor;
import org.ydzy.publish.ConstantTopics;
import org.ydzy.publish.ISubscriber;
import org.ydzy.publish.SubscribeCaches;
import org.ydzy.publish.SubscribePublish;
import org.ydzy.rcs.Provider;
import org.ydzy.rcs.annotation.Description;
import org.ydzy.util.Util;

import com.google.gson.JsonObject;
import com.google.inject.Inject;
import com.google.inject.Singleton;

@Singleton
@Description(value="AutoMsgSubscriber",autoInstance=true)
public class CspSenderService   implements ISubscriber<JsonObject> {
	@Inject
	SubscribeCaches subscribeCaches;
	public CspSenderService() {
		
	}
	public void init()
	{
		if(subscribeCaches==null)
			subscribeCaches=Provider.injector.getInstance(SubscribeCaches.class);
		SubscribePublish<JsonObject> sub=subscribeCaches.getSubscribePublishInstance(ConstantTopics.CHARTBOT_MSG_MOBILERECEIVE, JsonObject.class);
		this.subscribe(sub);
	}

	@Inject
	private BaseRcsContextProvidor contextProvidor = null;
	public BaseRcsContextProvidor getContextProvidor() {
		return contextProvidor;
	}
	@Inject
	BotManager botmanager;
	@Override
	public void subscribe(SubscribePublish<JsonObject> subscribePulish) {
		subscribePulish.subcribe(this);
	}

	@Override
	public void unSubscribe(SubscribePublish<JsonObject> subscribePulish) {
		subscribePulish.unSubcribe(this);
		
	}

	@Override
	public void update(String publisher, JsonObject message) {
		String chatBotID=Util.getElementAsString(message, "chatBotID");
		BotInfo info = botmanager.getChatBotInfo(chatBotID);
		
		org.ydzy.handler.BaseRcsContext context = contextProvidor.newBaseRcsContext();
		info.getBotAccess().cspSendMsg(info, message,context);
	}

}
