package org.ydzy.rcs.action;

import com.google.gson.*;
import com.google.inject.Inject;
import com.google.inject.name.Named;
import io.jsonwebtoken.Claims;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.ydzy.config.ApplicationConfig;
import org.ydzy.handler.BaseHandler;
import org.ydzy.handler.BaseRcsContext;
import org.ydzy.handler.RcsSession;
import org.ydzy.rcs.cache.CacheProvider;
import org.ydzy.rcs.entity.LoginInfo;
import org.ydzy.util.JwtOperatorUtil;
import org.ydzy.util.TimeUtil;
import org.ydzy.util.Util;

import javax.sql.DataSource;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public abstract class LoginAction {
    private static final Logger log = LoggerFactory.getLogger(LoginAction.class);
    @Inject
    protected ApplicationConfig applicationConfig;

    @Inject
    protected AuthAction authAction;

    @Inject
    protected JwtOperatorUtil jwtOperatorUtil;

    @Inject
    @Named("rcsDb")
    protected DataSource ds;

    @Inject
    protected CacheProvider cacheProvider;

    @Inject
    protected MenuAction menuAction;

    protected static final Gson gson = new Gson();

    protected static final Map<String, Map<String, String>> LOGIN_LOCK = new ConcurrentHashMap<>();

    boolean checkLogin(HttpServletRequest request, HttpServletResponse response, String remoteAddr, LoginInfo loginInfo) throws IOException {
        // У��IP��½�������
        int error_count = applicationConfig.LOGIN_ERROR_COUNT;
        long error_blocked = applicationConfig.LOGIN_ERROR_BLOCKED * 60000L;
        if (LOGIN_LOCK.containsKey(remoteAddr)) {
            Map<String, String> lockInfo = LOGIN_LOCK.get(remoteAddr);
            int errorCount = Integer.parseInt(lockInfo.getOrDefault("errorCount", "0"));
            long lastLogin = Long.parseLong(lockInfo.getOrDefault("lastLogin", "0"));
            if (System.currentTimeMillis() - lastLogin <= error_blocked && errorCount >= error_count) {
                JsonObject rst = new JsonObject();
                rst.addProperty("error_blocked", error_blocked);
                rst.addProperty("error_count", error_count);
                BaseHandler.sendResponse(remoteAddr, BaseHandler.resBodyJson(AuthAction.AUTH_CODE_DENY_IP, "����IP�ѱ�����������" + TimeUtil.format(lastLogin + error_blocked) + "���Ե�¼��", rst), HttpServletResponse.SC_OK, request, response);
                return false;
            }
        }
        // У�����
        if (!this.checkParams(loginInfo)) {
            BaseHandler.sendResponse(remoteAddr, BaseHandler.resBodyJson("500", "ȱ�ٱش�����", null), HttpServletResponse.SC_OK, request, response);
            return false;
        }
        return true;
    }

    public abstract void login(HttpServletRequest request, HttpServletResponse response, String remoteAddr, LoginInfo loginInfo, BaseRcsContext context) throws IOException;

    void afterLogin(HttpServletRequest request, HttpServletResponse response, String remoteAddr, String accessToken, String username, HashMap<String, Object> payload, BaseRcsContext context) throws IOException {
        int error_count = applicationConfig.LOGIN_ERROR_COUNT;
        long error_blocked = applicationConfig.LOGIN_ERROR_BLOCKED * 60000L;
        if (Util.isNull(accessToken)) {
            Map<String, String> lockInfo = LOGIN_LOCK.computeIfAbsent(remoteAddr, k -> new HashMap<>());
            long lastLogin = System.currentTimeMillis();
            int errorCount = Integer.parseInt(lockInfo.getOrDefault("errorCount", "0"));
            lockInfo.put("errorCount", (errorCount + 1) + "");
            lockInfo.put("lastLogin", lastLogin + "");
            RcsRunLogAction.recordLog("login-" + applicationConfig.LOGIN_LOGINMODE, "Get accessToken failed. user does not exist or username or password incorrect.", remoteAddr, "500", "login", username, ds);
            int tryCount = Math.max(error_count - errorCount - 1, 0);
            String enable = Util.toString(payload.get("enable"), "1");
            String code = AuthAction.AUTH_CODE_INVALID_REQ_USERNP;
            String msg = "�û�������������������Գ��Ե�¼" + tryCount + "��";
            if (!Util.isNull(enable) && !enable.equals("1")) {
                msg = "���ĵ�¼�ʺ��ѹ���";
            }

            JsonObject rst = new JsonObject();
            if (tryCount == 0) {
                msg = "����IP�ѱ�����������" + TimeUtil.format(lastLogin + error_blocked) + "���Ե�¼��";
                code = AuthAction.AUTH_CODE_DENY_IP;
                rst.addProperty("error_blocked", error_blocked);
                rst.addProperty("error_count", error_count);
            }

            BaseHandler.sendResponse(remoteAddr, BaseHandler.resBodyJson(code, msg, rst), HttpServletResponse.SC_OK, request, response);
            return;
        }
        LOGIN_LOCK.remove(remoteAddr);
        try {
            Claims claims = jwtOperatorUtil.getClaimsFromToken(accessToken);
            String ydzyUserId = Util.toString(claims.get("userid"));
            String groupId = Util.toString(claims.get("groupid"));
            String levels = Util.toString(claims.get("levels")); // �Ƿ񳬼�����Ա 0��  ������
            String isAdmin = Util.toString(claims.get("isAdmin"));
            String passwordStaus = Util.toString(claims.get("status"));
            String refreshToken = jwtOperatorUtil.generateToken(claims, applicationConfig.LOGIN_REFRESHTOKEN_EXPIREIN_SECOND);
            JsonObject tokenObject = new JsonObject();
            tokenObject.addProperty("accessToken", accessToken);
            tokenObject.addProperty("refreshToken", refreshToken);
            JsonObject loginRst = new JsonObject();
            loginRst.add("token", tokenObject);
            boolean hasRight = false;
            JsonArray appsArray = null;
            if (applicationConfig.LOGIN_LOGINMODE.equals("server")) {
                String rights = authAction.grantPermission(accessToken, applicationConfig.LOGIN_GRANT_PERMISSION_URL);

                if (Util.isNull(rights)) {
                    log.error("load user right failed");
                } else {
                    JsonObject rightsObj = JsonParser.parseString(rights).getAsJsonObject();
                    String rcode = Util.getElementAsString(rightsObj, "code");
                    String rdesc = Util.getElementAsString(rightsObj, "desc");
                    if (!rcode.equals("200")) {
                        log.error("load user right failed. accessToken {}, reason:{}", accessToken, rdesc);
                    } else {
                        try {
                            JsonObject mo = rightsObj.getAsJsonObject("data");
                            appsArray = JsonParser.parseString(mo.get("APPS").getAsString()).getAsJsonArray();
                        } catch (Exception e) {
                            log.error("parse right json error.", e);
                        }
                    }
                }
            } else {
                appsArray = authAction.getApps(groupId);
            }
            if (appsArray != null) {
                for (JsonElement ele : appsArray) {
                    if (ele.getAsString().equals(applicationConfig.LOGIN_APP_SERVERNAME)) {
                        hasRight = true;
                        break;
                    }
                }
            }

            if (hasRight) {
                JsonObject userPermission = authAction.getRcsUser(username);
                userPermission.addProperty("superAdmin", levels.equals("0"));
                userPermission.addProperty("isAdmin", isAdmin.equals("1"));
                userPermission.addProperty("customerId", Util.toString(payload.get("customerId")));
                userPermission.addProperty("ydzyUserId", ydzyUserId);
                JsonArray chatBotArray = authAction.getChatBotArrayByUser(levels.equals("0") ? null : username);
                userPermission.add("chatbotInfos", chatBotArray);
                JsonArray menuArray = menuAction.getMenus(groupId, applicationConfig.LOGIN_APP_SERVERCODE, "PC");
                JsonArray routeArray = menuAction.getRoutes(menuArray, applicationConfig.LOGIN_APP_SERVERCODE, groupId, "PC");
                if (levels.equals("0")) {
                    routeArray.forEach(jsonElement -> {
                        JsonObject obj = jsonElement.getAsJsonObject();
                        obj.addProperty("isedit", "1");
                        obj.addProperty("isexport", "1");
                        obj.addProperty("isdelete", "1");
                    });
                }
                loginRst.add("ROUTES", routeArray);
                loginRst.addProperty("APP", applicationConfig.LOGIN_APP_SERVERNAME);
                loginRst.add("MENUS", menuArray);
                loginRst.add("MENUSTree", JsonParser.parseString(gson.toJson(getMenuInfos(menuArray))));
                loginRst.add("PERMISSION", userPermission);
                if (!Util.isNull(passwordStaus))
                    loginRst.addProperty("passwordStaus", passwordStaus);
            }
            String skey = "tokenKey".hashCode() + "";
            RcsSession session = context.getOrCreateSession(skey);
            session.put("token-" + accessToken, refreshToken);
            String result = BaseHandler.resBodyJson(AuthAction.AUTH_CODE_SUCCESS, "login sucess!", loginRst);
            BaseHandler.sendResponse(remoteAddr, result, HttpServletResponse.SC_OK, request, response);
        } catch (Exception e) {
            RcsRunLogAction.recordLog("login-" + applicationConfig.LOGIN_LOGINMODE, "login exception. " + e.getMessage(), remoteAddr, "500", "login", username, ds);
            BaseHandler.sendResponse(remoteAddr, BaseHandler.resBodyJson(AuthAction.AUTH_CODE_ERROR, "Get accessToken failed.", new JsonObject()), HttpServletResponse.SC_OK, request, response);
            log.error("Get accessToken failed.", e);
        }
    }

    public abstract boolean checkParams(LoginInfo loginInfo);

    // ת��Ŀ¼���ݽṹ
    public static List<MenuInfo> getMenuInfos(JsonArray menuArray) {
        List<MenuInfo> menuRoots = new ArrayList<>();
        for (JsonElement element : menuArray) {
            JsonObject obj = element.getAsJsonObject();
            if ("0".equals(obj.get("parentid").getAsString())) {
                MenuInfo menuInfo = new MenuInfo(Util.getElementAsString(obj, "menu_text"), Util.getElementAsString(obj, "parameter"), Util.getElementAsString(obj, "menu_url"), Util.getElementAsString(obj, "rank"), Util.getElementAsString(obj, "parameter_type"), Util.getElementAsString(obj, "app_id"), Util.getElementAsString(obj, "menu_id"), Util.getElementAsString(obj, "parentid"), Util.getElementAsString(obj, "levels"), Util.getElementAsString(obj, "icon_uri"), Util.getElementAsString(obj, "menu_type"));
                menuRoots.add(menuInfo);
                buildMenuTree(menuArray, menuInfo);
            }
        }
        return menuRoots;
    }

    /**
     * ��������Ŀ¼���ݽṹ
     */
    public static void buildMenuTree(JsonArray menuArray, MenuInfo menuRoot) {
        for (JsonElement element : menuArray) {
            JsonObject obj = element.getAsJsonObject();
            if (menuRoot.menu_id.equals(obj.get("parentid").getAsString())) {
                String menu_type = Util.getElementAsString(obj, "menu_type");
                MenuInfo menuInfo = new MenuInfo(Util.getElementAsString(obj, "menu_text"), Util.getElementAsString(obj, "parameter"), Util.getElementAsString(obj, "menu_url"), Util.getElementAsString(obj, "rank"), Util.getElementAsString(obj, "parameter_type"), Util.getElementAsString(obj, "app_id"), Util.getElementAsString(obj, "menu_id"), Util.getElementAsString(obj, "parentid"), Util.getElementAsString(obj, "levels"), Util.getElementAsString(obj, "icon_uri"), menu_type);
                menuRoot.childs.add(menuInfo);
                buildMenuTree(menuArray, menuInfo);
            }
        }
    }

    // �˵���Ϣ
    public static class MenuInfo {
        String menu_text;
        String parameter;
        String menu_url;
        String rank;
        String parameter_type;
        String app_id;
        String menu_id;
        String parentid;
        String levels;
        String icon_uri;
        String menu_type;

        // �Ӳ˵�
        private List<MenuInfo> childs = new ArrayList<>();

        public MenuInfo(String menu_text, String parameter, String menu_url, String rank, String parameter_type, String app_id, String menu_id, String parentid, String levels, String icon_uri) {
            this(menu_text, parameter, menu_url, rank, parameter_type, app_id, menu_id, parentid, levels, icon_uri, "0");
        }

        public MenuInfo(String menuText, String parameter, String menuUrl, String rank, String parameterType, String appId, String menuId, String parentId, String levels, String iconUri, String menuType) {
            this.menu_text = menuText;
            this.parameter = parameter;
            this.menu_url = menuUrl;
            this.rank = rank;
            this.parameter_type = parameterType;
            this.app_id = appId;
            this.menu_id = menuId;
            this.parentid = parentId;
            this.levels = levels;
            this.icon_uri = iconUri;
            this.menu_type = menuType;
        }
    }
}
