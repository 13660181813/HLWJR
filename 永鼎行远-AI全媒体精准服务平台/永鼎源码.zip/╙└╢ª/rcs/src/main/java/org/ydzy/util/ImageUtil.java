package org.ydzy.util;

import com.google.gson.Gson;
import com.google.gson.JsonArray;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
import java.awt.image.ColorModel;
import java.awt.image.WritableRaster;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * @author lirui
 * @Date 2021/4/12 7:01 ����
 */
public class ImageUtil {
    /**
     * �ϲ���������ͼƬ��һ��ͼƬ
     *
     * @param isHorizontal true����ˮƽ�ϲ���fasle������ֱ�ϲ�
     * @param imgs         ���ϲ���ͼƬ����
     * @return
     */
    public static boolean mergeImage(boolean isHorizontal, Path dstPic, String type, BufferedImage... imgs) {
        try {
            // ������ͼƬ
            BufferedImage destImage = null;
            // ������ͼƬ�ĳ��͸�
            int allw = 0, allh = 0, allwMax = 0, allhMax = 0;
            // ��ȡ�ܳ����ܿ���������
            for (BufferedImage img : imgs) {
                allw += img.getWidth();
                allh += img.getHeight();
                if (img.getWidth() > allwMax) {
                    allwMax = img.getWidth();
                }
                if (img.getHeight() > allhMax) {
                    allhMax = img.getHeight();
                }
            }
            // ������ͼƬ
            if (isHorizontal) {
                destImage = new BufferedImage(allw, allhMax, BufferedImage.TYPE_INT_RGB);
            } else {
                destImage = new BufferedImage(allwMax, allh, BufferedImage.TYPE_INT_RGB);
            }
            // �ϲ�������ͼƬ����ͼƬ
            int wx = 0, wy = 0;
            for (BufferedImage img : imgs) {
                int w1 = img.getWidth();
                int h1 = img.getHeight();
                // ��ͼƬ�ж�ȡRGB
                int[] ImageArrayOne = new int[w1 * h1];
                ImageArrayOne = img.getRGB(0, 0, w1, h1, ImageArrayOne, 0, w1); // ����ɨ��ͼ���и������ص�RGB��������
                if (isHorizontal) { // ˮƽ����ϲ�
                    destImage.setRGB(wx, 0, w1, h1, ImageArrayOne, 0, w1); // �����ϰ벿�ֻ���벿�ֵ�RGB
                } else { // ��ֱ����ϲ�
                    destImage.setRGB(0, wy, w1, h1, ImageArrayOne, 0, w1); // �����ϰ벿�ֻ���벿�ֵ�RGB
                }
                wx += w1;
                wy += h1;
            }
            File outFile = dstPic.toFile();
            ImageIO.write(destImage, type, outFile);// дͼƬ
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }

    public static boolean mergeImage(boolean isHorizontal, Path sorcePath, Path dstPic, String type, JsonArray filenames) {
        try {
            BufferedImage[] images = new BufferedImage[filenames.size()];
            for (int i = 0; i < filenames.size(); i++) {
                String filename = filenames.get(i).getAsString();
                File image = sorcePath.resolve(filename).toFile();
                images[i] = ImageIO.read(image);
            }
            return mergeImage(isHorizontal, dstPic, type, images);
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public static boolean mergeGIF(Path localPath, Path outputFileName, Path watermark, int height, int width, JsonArray filenames) {
        try {
            // ָ��Frame���ļ�
            AnimatedGifEncoder e = new AnimatedGifEncoder();
            OutputStream os = new FileOutputStream(outputFileName.toString()); //���ͼƬ
            e.start(os);// ��ʼ����
            e.setQuality(90); //����ͼƬ����
            e.setRepeat(0);  //����ѭ��
            e.setDelay(1000); // �����ӳ�ʱ��
            for (int i = 0; i < filenames.size(); i++) {
                String filename = filenames.get(i).getAsString();
                BufferedImage image = ImageIO.read(localPath.resolve(filename).toFile());
                BufferedImage im = pressImage(watermark.toString(), image, width, height);
                e.addFrame(im);// ѭ������Frame
            }
            e.finish();
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }


    private static BufferedImage pressImage(String pressImg, BufferedImage targetImg, int width, int height) {
        try {
            // Ŀ���ļ�
//            File _file = new File(targetImg);
//            Image src = ImageIO.read(_file);
//            Image src = reSize(_file, null, width, height, true); //�ȱ����� ԭͼ����
//            assert targetImg != null;
//            width = src.getWidth(null);
//            height = src.getHeight(null);
            BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
            Graphics g = image.createGraphics();
            g.drawImage(targetImg, 0, 0, width, height, null);
            // ˮӡ�ļ�
//            File _filebiao = new File(pressImg);
//            Image src_biao = ImageIO.read(_filebiao);
//            int wideth_biao = src_biao.getWidth(null);
//            int height_biao = src_biao.getHeight(null);
//            g.drawImage(src_biao, x, y, wideth_biao, height_biao, null);
            // ˮӡ�ļ�����
            g.dispose();
            return image;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * @param srcImg     ԭͼƬ
     * @param destImg    Ŀ��λ��
     * @param width      ������
     * @param height     ������
     * @param equalScale �Ƿ�ȱ�������
     */
    public static BufferedImage reSize(File srcImg, File destImg, int width, int height, boolean equalScale) {
        String type = getImageType(srcImg);
        type = Util.isNull(type) ? "jpg" : type;
        width = width < 0 ? 82 : 82;
        height = height < 0 ? 395 : height;
        BufferedImage srcImage = null;
        try {
            srcImage = ImageIO.read(srcImg);
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
        // targetW��targetH�ֱ��ʾĿ�곤�Ϳ�
        BufferedImage target = null;
        double sx = (double) width / srcImage.getWidth();
        double sy = (double) height / srcImage.getHeight();
        // �ȱ�����
        if (equalScale) {
            if (sx > sy) {
                sx = sy;
                width = (int) (sx * srcImage.getWidth());
            } else {
                sy = sx;
                height = (int) (sy * srcImage.getHeight());
            }
        }
        ColorModel cm = srcImage.getColorModel();
        WritableRaster raster = cm.createCompatibleWritableRaster(width, height);
        boolean alphaPremultiplied = cm.isAlphaPremultiplied();

        target = new BufferedImage(cm, raster, alphaPremultiplied, null);


        Graphics2D g = target.createGraphics();
        // smoother than exlax:
        g.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        g.drawRenderedImage(srcImage, AffineTransform.getScaleInstance(sx, sy));
        g.dispose();
        return target;
        /*
        // ��ת�����ͼƬ����
        try {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            ImageIO.write(target, type, baos);
            FileOutputStream fos = new FileOutputStream(destImg);
            fos.write(baos.toByteArray());
            fos.flush();
            fos.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
         */
    }

    /**
     * ��ȡ�ļ���׺����.
     *
     * @param file �ļ���׺��
     * @return
     */
    private static String getImageType(File file) {
        if (file != null && file.exists() && file.isFile()) {
            String fileName = file.getName();
            int index = fileName.lastIndexOf(".");
            if (index != -1 && index < fileName.length() - 1) {
                return fileName.substring(index + 1);
            }
        }
        return null;
    }

    public static void main(String[] args) throws IOException {
        //String[] pics, String type, String dst_pic
        String[] pics = new String[3];
        pics[0] = "/Users/lirui/Desktop/H5/WechatIMG172.jpeg";
        pics[1] = "/Users/lirui/Desktop/H5/WechatIMG173.jpeg";
        pics[2] = "/Users/lirui/Desktop/H5/WechatIMG171.jpeg";
        String type = "jpg";
        String dst_pic = "/Users/lirui/Desktop/H5/merge2.jpg";
//        merge(pics, type, dst_pic);

        BufferedImage images1 = ImageIO.read(new File(pics[0]));
        BufferedImage images2 = ImageIO.read(new File(pics[1]));
        BufferedImage images3 = ImageIO.read(new File(pics[2]));
//        boolean flag = mergeImage(false, Paths.get(dst_pic), type, images1, images2, images3);
        Gson g = new Gson();

        JsonArray jsonArray = g.toJsonTree(pics).getAsJsonArray();
        Path p1 = Paths.get("/Users/lirui/Desktop/H5/mergeA.gif");
        Path p2 = Paths.get("");
        mergeGIF(Paths.get("/Users/lirui/Desktop/H5/"), p1, p2, 300, 300, jsonArray);
    }
}
