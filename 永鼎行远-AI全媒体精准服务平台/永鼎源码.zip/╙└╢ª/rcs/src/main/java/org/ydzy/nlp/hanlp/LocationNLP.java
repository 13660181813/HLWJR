package org.ydzy.nlp.hanlp;

import java.util.List;

import com.hankcs.hanlp.seg.common.Term;
import com.hankcs.hanlp.tokenizer.NLPTokenizer;

public class LocationNLP {
	public static void segment(String  word ,List<Term> words) {
		List<Term> locations =NLPTokenizer.segment(word);
		if(locations!=null )
		{
			if( locations.size()==1)
				words.add(locations.get(0));
			else
			{
				for(Term t1:locations)
				{
					segment(t1.word,words);
				}
			}
		}
	}
}
