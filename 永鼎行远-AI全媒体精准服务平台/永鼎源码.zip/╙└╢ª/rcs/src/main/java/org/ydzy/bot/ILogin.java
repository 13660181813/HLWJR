package org.ydzy.bot;

import jakarta.servlet.http.HttpServletRequest;
import org.ydzy.handler.RcsSession;
import org.ydzy.rcs.BodyTransform;

import java.util.Map;

/**
 * @author zxw
 * @create 2021/11/29
 */
public interface ILogin {
    public static final String BEAN_INSTANCE_KEY_PREFIX = "bot.login.server.";
    /**
     * ��װ������ƽ̨��¼��Ϣ
     * @param bodyTransform
     */
    Map<String, Object> login(BodyTransform bodyTransform, HttpServletRequest request);

    Map<String, Object> login(RcsSession session, HttpServletRequest request);


}
