package org.ydzy.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;
import java.util.stream.Collectors;

import org.ydzy.util.TimeUtil;
import org.ydzy.util.Util;
import org.ydzy.xml.DataSetXmlConfig;

import com.google.gson.Gson;

public interface DbAccessor {
	static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(DbAccessor.class);
	static Gson gson = new Gson();

	public default Connection getConnection(String url, String user, String password) throws SQLException {
		return DriverManager.getConnection(url, user, password);
	}

	public java.util.Set<String> tableExist(String dsId, String tname);

	public String getDateExpress(long date);

	public default List<Map<String, String>> queryForResult(String id, long sDate, long eDate) {
		Map<String, Object> result = DataSetXmlConfig.getConfigContent().get(id);
		Set<String> selectorsset = DataSetXmlConfig.selector(id);

		String table = Util.toString(result.get("table"));
		String datecol = Util.toString(result.get("datecol"));
		String sDateCol = Util.toString(result.get("sDateCol"));
		String eDateCol = Util.toString(result.get("eDateCol"));
		if (!Util.isNull(datecol)) {
			if (Util.isNull(sDateCol))
				sDateCol = datecol;
			if (Util.isNull(eDateCol))
				eDateCol = datecol;
		}
		String dsId = Util.toString(result.get("datasource"));

		try {
			selectorsset.add(eDateCol);
			selectorsset.add(sDateCol);
			String selectors = DataSetXmlConfig.selector2Str(selectorsset);
			String innersql = innerSql(dsId, sDate, eDate, table, selectors);
			if (Util.isNull(innersql))
				return null;
			String wholeSql = wholeSqls(innersql, sDate, eDate, sDateCol, eDateCol,result);
			log.info("datasource {} ready to  execQuery sqls {} ", dsId, wholeSql);
			List<SortedMap<String, Object>> resultSet = exeQuery(dsId, wholeSql);
			List<Map<String, String>> returnSet = new ArrayList<Map<String, String>>();
//			 JsonArray array=new JsonArray();
			Map<String, Map<String, Object>> fieldsList = (Map<String, Map<String, Object>>) result.get("fields");
			if (resultSet != null && resultSet.size() > 0) {
				resultSet.stream().forEach(row -> {
					Map<String, String> newrow = new HashMap<String, String>();
//					 JsonObject newrow=new JsonObject();
					fieldsList.forEach((k, v) -> {
						String from = Util.toString(v.get("from"));
						String to = Util.toString(v.get("to"));
						String toV = Util.toString(row.get(to));
						if (Util.isNull(toV))
							toV = Util.toString(row.get(to.toUpperCase()));
//						 newrow.addProperty(from, toV);		
						newrow.put(from, toV);
					});
//					 array.add(newrow);
					returnSet.add(newrow);
				});
				return returnSet;
			}
		} catch (Exception e) {
			log.error("result {}  query datasource {} exec error !", id, dsId, e);
		}
		return null;
	}

	private String innerSql(String dsId, long sDate, long eDate, String table, String selectors) {

		if (table.indexOf("'") > -1) {
			java.util.Set<String> tablelist = builderTnames(sDate, eDate, table);
			if (tablelist != null && tablelist.size() > 0) {
				String tableName = tablelist.stream().map(o -> "'" + o + "'").collect(Collectors.joining(","));
				Set<String> existTable = tableExist(dsId, tableName);

				if (existTable == null || existTable.size() == 0)
					return "";
				String innersql = existTable.stream().map(t -> {
					StringBuilder sqls = new StringBuilder();
					sqls.append(" SELECT ").append(selectors).append("  FROM ").append(t);
					return sqls.toString();
				}).collect(Collectors.joining(" UNION ALL "));
				return innersql;
			} else
				return "";
		} else {
			return "SELECT " + selectors + " FROM " + table;
		}
	}

	private String wholeSqls(String innersql, long sDate, long eDate, String sDateCol, String eDateCol,Map<String, Object> result ) {
		StringBuilder allSql = new StringBuilder();
		allSql.append(" SELECT * FROM ( ").append(innersql).append(" ) T ");
		String sdateExpress = sDateCol + " >= " + getDateExpress(sDate);
		String edateExpress = eDateCol + " < " + getDateExpress(eDate);
		StringBuilder where = new StringBuilder();
		String condition=result.get("condition").toString();
		boolean addwhere = false;
		if (!Util.isNull(sdateExpress) && !Util.isNull(edateExpress)) {
			where.append(" WHERE ").append(sdateExpress);
			where.append(" AND ").append(edateExpress);
			addwhere = true;
		} else if (!Util.isNull(sdateExpress)) {
			where.append(" WHERE ").append(sdateExpress);
			addwhere = true;
		} else if (!Util.isNull(edateExpress)) {
			where.append(" WHERE ").append(edateExpress);
			addwhere = true;
		}
		if (addwhere) {
			allSql.append(" ").append(where);
			if(!Util.isNull(condition))
				allSql.append(" AND ").append(condition );
		}else {
			if(!Util.isNull(condition))
				allSql.append(" WHERE ").append(condition );
		}
		return allSql.toString();
	}

	public default java.util.Set<String> builderTnames(long sDate, long eDate, String table) {
		java.util.Set<String> tablelist = new HashSet<String>();
		String radiustable = table.substring(table.indexOf("'") + 1, table.lastIndexOf("'")).toUpperCase();
		int step = TimeUtil.formatStep(radiustable);
		String format = table.substring(table.lastIndexOf("'") + 1);
		String tn = radiustable + TimeUtil.formatDay(sDate, format);
		tablelist.add(tn);
		while (sDate <= eDate) {
			sDate += step;
			tn = radiustable + TimeUtil.formatDay(sDate, format);
			tablelist.add(tn);
		}
		return tablelist;
	};

	public static void main(String[] args) {
		String table = "'PRF'yyyyMMdd";
		long sDate = System.currentTimeMillis();
		long eDate = sDate + 3600000 * 24 * 10;
		java.util.Set<String> tablelist = new HashSet<String>();
		String radiustable = table.substring(table.indexOf("'") + 1, table.lastIndexOf("'")).toUpperCase();
		int step = TimeUtil.formatStep(radiustable);
		String format = table.substring(table.lastIndexOf("'") + 1);
		String tn = radiustable + TimeUtil.formatDay(sDate, format);
		tablelist.add(tn);
		while (sDate <= eDate) {
			sDate += step;
			tn = radiustable + TimeUtil.formatDay(sDate, format);
			tablelist.add(tn);

		}
		String tableName = tablelist != null
				? tablelist.stream().map(o -> "'" + o + "'").collect(Collectors.joining(","))
				: "";
		System.out.println(tableName);
	}

	public default List<SortedMap<String, Object>> exeQuery(String dsId, String sql) {
		try (Connection conn = DataSetXmlConfig.createConnection(dsId);
				PreparedStatement stmt = conn.prepareStatement(sql);
				ResultSet rs = stmt.executeQuery();) {
			List<SortedMap<String, Object>> records = new ArrayList<SortedMap<String, Object>>();
			long rownum = 0;
			while (rs.next()) {
				int colsize = rs.getMetaData().getColumnCount();
				SortedMap<String, Object> row = new TreeMap<String, Object>();
				for (int i = 1; i <= colsize; i++) {
					String label = rs.getMetaData().getColumnLabel(i);
					Object o = rs.getObject(i);
					row.put(label, o);
				}
				records.add(row);
				rownum++;
			}
			log.info("datasource {} execQuery sql {} rowCount {} ", dsId, sql, rownum);
			return records;
		} catch (SQLException ignore) {
			log.error("datasource {} execQuery sql {}   catch errors ", dsId, sql, ignore);
		}
		return null;
	}

	public default List<Object> exeQueryForSingleCol(String dsId, String sql) {
		try (Connection conn = DataSetXmlConfig.createConnection(dsId);
				PreparedStatement stmt = conn.prepareStatement(sql);
				ResultSet rs = stmt.executeQuery();) {
			List<Object> records = new ArrayList<Object>();
			long rownum = 0;
			while (rs.next()) {
				records.add(rs.getObject(1));
				rownum++;
			}
			log.info("datasource {} execQuery sql {} rowCount {} ", dsId, sql, rownum);
			return records;
		} catch (SQLException ignore) {
			log.error("datasource {} execQuery sql {}   catch errors ", dsId, sql, ignore);
		}
		return null;
	}

	public default long exeQueryForCount(String dsId, String sql) {
		try (Connection conn = DataSetXmlConfig.createConnection(dsId);
				PreparedStatement stmt = conn.prepareStatement(sql);
				ResultSet rs = stmt.executeQuery();) {
			long rownum = 0;
			while (rs.next()) {
				rownum++;
			}
			log.info("datasource {} execQuery sql {} rowCount {} ", dsId, sql, rownum);
			return rownum;
		} catch (SQLException ignore) {
			log.error("datasource {} execQuery sql {}   catch errors ", dsId, sql, ignore);
		}
		return 0;
	}

	public default long update(String dsId,String sql, Object[] params) {
		try (Connection conn = DataSetXmlConfig.createConnection(dsId);
				PreparedStatement update = conn.prepareStatement(sql);
				 ) {
			update.clearParameters();
			for(int i =0 ;i<params.length;i++)
			{
				update.setObject(i+1, params[i]);
			}
			int rownum = update.executeUpdate();
			log.info("datasource {} execQuery sql {} rowCount {} ", dsId, sql, rownum);
			return rownum;
		} catch (SQLException ignore) {
			log.error("datasource {} execQuery sql {}   catch errors ", dsId, sql, ignore);
		}
		return 0;

	}
	public default int update(String dsId,String sql) {
		try (Connection conn = DataSetXmlConfig.createConnection(dsId);
				PreparedStatement update = conn.prepareStatement(sql);
				 ) {
			update.clearParameters();
			int rownum = update.executeUpdate();
			log.info("datasource {} execQuery sql {} rowCount {} ", dsId, sql, rownum);
			return rownum;
		} catch (SQLException ignore) {
			log.error("datasource {} execQuery sql {}   catch errors ", dsId, sql, ignore);
		}
		return 0;

	}
	public String queryForPage(String sql, String where,int rmin,int rmax) ;
}
