package org.ydzy.jdbc.control.result.datepattern;

import java.text.ParseException;
import java.util.Calendar;
import java.util.List;


public interface ITime {
	public List<String> reckonName(String tablePattern,long timeInterval,String sDate, String eDate,Calendar c1,Calendar c2)throws ParseException;
	
}
