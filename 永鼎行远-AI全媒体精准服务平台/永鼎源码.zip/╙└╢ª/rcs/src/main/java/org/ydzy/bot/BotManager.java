package org.ydzy.bot;

import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.ydzy.publish.ConstantTopics;
import org.ydzy.publish.ISubscriber;
import org.ydzy.publish.SubscribeCaches;
import org.ydzy.publish.SubscribePublish;
import org.ydzy.rcs.RcsConfig;
import org.ydzy.rcs.entity.CommonMsg;
import org.ydzy.rcs.media.UploadFileEntity;

import com.google.common.util.concurrent.ThreadFactoryBuilder;
import com.google.inject.Inject;
import com.google.inject.Injector;
import com.google.inject.Key;
import com.google.inject.name.Named;
import com.google.inject.name.Names;
import org.ydzy.util.Util;

public class BotManager{
	static final Logger log = LoggerFactory.getLogger(BotManager.class);
	protected static final String BOTINFO_LIST = "botinfo.list";
	protected static final String BOTISP_LIST = "botisp.list";
	
	@Inject
	protected Injector injector = null;
	
	/** rcs������Ϣ */
	@Inject
	private RcsConfig config;
	public RcsConfig getConfig() {
		return config;
	}

	@Inject
	private SubscribeCaches subscribeCaches;
	
	@Inject
	@Named(BOTISP_LIST)
	protected Map<String, String> botIspMap = null;
	/** ֧�ֵ�csp�����б� */
	public Map<String, String> getBotIspMap() {
		return botIspMap;
	}

	protected Map<String, BotInfo> botInfoMap = new ConcurrentHashMap<>();
	public BotInfo getChatBotInfo(String chatbotid) {
		BotInfo bi = null;
		bi = botInfoMap.get(chatbotid);
		if(bi==null) {
			String v = chatbotid;
			if(chatbotid.indexOf('@')<0) v = v+"@botplatform.rcs.chinamobile.com";
			if(chatbotid.indexOf(':')<0) v = "sip:" + v;
			bi = botInfoMap.get(v);
		}
		return bi;
	}
	public Set<BotInfo> getAllChatBotInfo(){
		HashSet<BotInfo> bots = new HashSet<>(botInfoMap.values());
		return bots;
	}
	
	private java.util.concurrent.ScheduledExecutorService executor;
	public BotManager(){
		executor = Executors.newScheduledThreadPool(2
				, new ThreadFactoryBuilder().setNameFormat("BotRun%d").setDaemon(true).build());
		executor.scheduleWithFixedDelay(this::refresh, 2500, 1000, TimeUnit.MILLISECONDS);
	}
	
	/***
	 * ִ���̳߳�
	 * @return
	 */
	public java.util.concurrent.ScheduledExecutorService getExecutor() {
		return executor;
	}

	/** ��Ϣ�ַ�״̬Future����  */
	private Map<String, CompletableFuture<String>> deliveryStatusMap = new ConcurrentHashMap<>();
	public Map<String, CompletableFuture<String>> getDeliveryStatusMap(){
		return deliveryStatusMap;
	}

	/***
	 * ������Ϣ����
	 */
	private ISubscriber<CommonMsg> receiveMsgService = null;
	
	/** ��Ϣ���ͷ��� */
	private MsgPushManager msgPushManager = null;
	
	private int runCount =0;
	/**
	 * һ����ִ��һ��
	 */
	protected void refresh() {
		try {
			runCount++;
			boolean flag = false;
			//60 ��ִ��һ��
			if(botInfoMap.size()==0 || runCount%60==0)
				flag = loadBotInfo();
			
			// 60��ִ��һ��
			if(flag || runCount%60==0) {
				HashSet<BotInfo> bots = new HashSet<>(botInfoMap.values());
				for(BotInfo k:bots) {
					if(k.isEnable() && k.getBotAccess().isEnable() && k.isExpire()) {
						//�Զ�������
						k.active();
					}
				}
			}
			
			if(receiveMsgService==null && subscribeCaches!=null) {
				receiveMsgService =	new ISubscriber<CommonMsg>() {
					@Override
					public void subscribe(SubscribePublish<CommonMsg> subscribePulish) {
						//ignore
					}
					@Override
					public void unSubscribe(SubscribePublish<CommonMsg> subscribePulish) {
						// ignore						
					}
					
					@Override
					public void update(String publisher, CommonMsg message) {
						if(message instanceof CommonMsg) {
							CommonMsg msg = (CommonMsg)message;
							String id = msg.senderAddress;
							BotInfo bi = getChatBotInfo(id);
							bi.getBotAccess().cspSendMsg(bi, null, null);
						}
						
					}
				};
				subscribeCaches.getSubscribePublishInstance(ConstantTopics.CHARTBOT_MSG_SEND, CommonMsg.class).subcribe(receiveMsgService);
				
				subscribeCaches.getSubscribePublishInstance(ConstantTopics.CHATBOT_MENU_CONFIG, String.class).subcribe(new ISubscriber<String>() {
					@Override
					public void subscribe(SubscribePublish<String> subscribePulish) {
						// ignore
					}
					@Override
					public void unSubscribe(SubscribePublish<String> subscribePulish) {
						// ignore
					}
					@Override
					public void update(String publisher, String message) {
						String chatbotid = message;
						try {
							BotInfo bi;
							if((bi=getChatBotInfo(chatbotid))!=null && bi.isEnable() && bi.getBotAccess() instanceof BotAccessTelcom) {
								if(((BotAccessTelcom)bi.getBotAccess()).chatBotInfoMenus(bi)) {
									log.info("Success do update chatbot(" + chatbotid + ") menu.");
								}
								
							}
						}catch(Exception e) {
							log.warn("Error do update chatbot(" + chatbotid + ") menu." + e.getMessage(),e);
						}
					}
					
				});
			}
			if(msgPushManager==null && subscribeCaches!=null) {
				msgPushManager = new MsgPushManager();
				injector.injectMembers(msgPushManager);
				if(msgPushManager.isEnable()) {
					msgPushManager.loadFromDb();
					subscribeCaches.getSubscribePublishInstance(ConstantTopics.CHATBOT_MSG_PUSH_CONFIG, String.class).subcribe(msgPushManager);
				}
			}
		}catch(Exception e) {
			log.warn("new token error",e);
		}
	}
	
	/**��ȡchatbot������Ϣ
	 * @return  û���µ���Ϣ���� ���� false, ���� true
	 */
	protected boolean loadBotInfo() {
		int modified = 0;
		List<?> botInfos = injector==null?null:injector.getInstance(Key.get(List.class, Names.named(BOTINFO_LIST)));
		if(botInfos==null || botInfos.size()==0) {
			log.debug("No chat bot info defined!");
		}else {
			for(Object o:botInfos) {
				BotInfo bi = (BotInfo)o;
				BotInfo mine = botInfoMap.get(bi.getChatbotId());
				boolean flag = false;
				String botType = bi.type;
				if(botType==null)botType=BotUtil.getElementAsString(bi.infos, "isp");
				if(mine==null) {
					flag = true;
				}else if(mine.isSame(bi)) {
					//ignore
				}else {
					flag = true;
				}
				if(flag) {
					if(bi.manager==null)bi.manager = this;
					BotAccess access = null;
					bi.type = botType;
					if(botType!=null && botType.length()>0) {
						try {
						access = injector.getInstance(Key.get(BotAccess.class, Names.named(BotAccess.KEY_BOT_TYPE+botType)));
						}catch(Exception e) {
							log.warn("Wrong chatbot type:" + bi.type + "), can't load its chatbot access interface!",e);
						}
					}
					if(access==null)access = injector.getInstance(Key.get(BotAccess.class, Names.named(BotAccess.KEY_BOT_TYPE_DEFAULT)));
					
					String auth = BotUtil.getElementAsString(bi.infos, "authorize");
					IAuthorize authorize = null;
					if(auth!=null && auth.length()>0) try {
						authorize = injector.getInstance(Key.get(IAuthorize.class, Names.named(IAuthorize.KEY_AUTH + auth)));
					}catch(Exception e) {
						log.warn("Wrong authorize type:" + auth + "), can't load its chatbot IAuthorize!",e);
					}

					ILogin loginServer = null;
					String loginServerBeanName = BotUtil.getElementAsString(bi.infos, "loginServer");
					if(!Util.isNull(loginServerBeanName)) {
						try {
							loginServer = injector.getInstance(Key.get(ILogin.class, Names.named(ILogin.BEAN_INSTANCE_KEY_PREFIX + loginServerBeanName)));
						}catch(Exception e){
							log.warn("Wrong loginserver type:" + loginServerBeanName + "), can't load its chatbot ILogin!",e);
						}
					}

					IRedirectHandler redirectHandler = null;
					String redirectHandlerName = BotUtil.getElementAsString(bi.infos, "redirectHandler");
					if(!Util.isNull(redirectHandlerName)) {
						try {
							redirectHandler = injector.getInstance(Key.get(IRedirectHandler.class, Names.named(IRedirectHandler.BEAN_INSTANCE_KEY_PREFIX + redirectHandlerName)));
						}catch(Exception e){
							log.warn("Wrong redirectHandler type:" + redirectHandler + "), can't load its chatbot ILogin!",e);
						}
					}

					DbOperator dbOper = null;
					dbOper = injector.getInstance(DbOperator.class);
					bi.register(this, access, authorize, dbOper, loginServer ,redirectHandler);
					botInfoMap.put(bi.getChatbotId(), bi);
					String identify = BotUtil.getElementAsString(bi.getInfos(), "chatbotIdenty");
					if(identify!=null && !identify.isEmpty())botInfoMap.put(identify, bi);
					modified++;
				}
			}
			log.debug(modified + "'s catbot loaded!");
		}
		return modified>0;
	}

	/** ý���ϴ�״̬Future���� 
	 * key: MEDIAID
	 * CompletableFuture<UploadFileEntity>:supply UploadFileEntity
	 */
	private Map<String, CompletableFuture<UploadFileEntity>> mediaUploadFuture = new ConcurrentHashMap<>();
	public Map<String, CompletableFuture<UploadFileEntity>> getMediaUploadFuture(){
		return mediaUploadFuture;
	}
}
