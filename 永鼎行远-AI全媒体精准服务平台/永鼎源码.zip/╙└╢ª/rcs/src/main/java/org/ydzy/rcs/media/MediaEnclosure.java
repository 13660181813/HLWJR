package org.ydzy.rcs.media;

import java.awt.AlphaComposite;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.ByteBuffer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import javax.imageio.ImageIO;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MediaEnclosure{

	static final Logger log = LoggerFactory.getLogger(MediaEnclosure.class);
	
	public ByteBuffer convertBody(UploadFileEntity params,String boundary ){
		return this.convertBody(params, boundary, "media", "thumbnail");
	}

	public ByteBuffer convertBody(UploadFileEntity params,String boundary, String mediaName, String thumbnailName){
		ByteBuffer buffer=ByteBuffer.allocateDirect(214000000);
		try (
				InputStream in = convertBodyInputStream(params, boundary, mediaName, thumbnailName)
				){
			if(in!=null) {
				byte[] bs = new byte[8192];
				int len;
				while((len=in.read(bs))>=0) {
					buffer.put(bs, 0, len);;
				}
			}
		} catch (IOException e) {
			log.error("Open & read media file error",e);
		}
		return buffer;
	}
	public InputStream convertBodyInputStream(UploadFileEntity params,String boundary, String mediaName, String thumbnailName) throws IOException{
		if(params!=null){
			List<Map.Entry<String, IMediaFileInfo>> entrys = new ArrayList<>();
			if(mediaName!=null && !mediaName.isEmpty()){
				IMediaFileInfo media = getMediaFileInfo(params, false);
				if(media!=null)entrys.add(Map.entry(mediaName, media));
			}
			if(thumbnailName!=null && !thumbnailName.isEmpty()){
				IMediaFileInfo media = getMediaFileInfo(params, false);
				if(media!=null)entrys.add(Map.entry(thumbnailName, media));
			}
			if(entrys.size()>0)return convertBodyInputStream(entrys, boundary);
		}
		return null;
	}
	
	public InputStream convertBodyInputStream(List<Map.Entry<String, IMediaFileInfo>> entrys,String boundary) throws IOException{
		if(entrys!=null && entrys.size()>0){
			List<InputStream> ins = new ArrayList<>();
			for(Map.Entry<String, IMediaFileInfo> e:entrys) {
				String name = e.getKey();
				IMediaFileInfo media = e.getValue();
				List<InputStream> list = UploadFileEntity2Byte(media,boundary,name);
				if(list!=null)ins.addAll(list);
			}

			if(ins.size()>0) {
				InputStream lastIn = new ByteArrayInputStream(("\r\n--"+boundary+"--\r\n").getBytes());
				MergeInputStream minput = new MergeInputStream(ins, lastIn);
				return minput;
			}
		}
		return null;
	}

	private List<InputStream> UploadFileEntity2Byte(IMediaFileInfo fileinfo ,String boundary ,String name) throws IOException{
		InputStream in = fileinfo.open();
		if(in!=null){
			StringBuffer strtBuf=new StringBuffer();
			strtBuf.append("\r\n");
			strtBuf.append("--").append(boundary).append("\r\n");
			strtBuf.append("Content-Disposition: form-data; name=\"" + name + "\"; filename=\""+fileinfo.getFilename()+"\"\r\n");
			//strtBuf.append("Content-Length=\""+fileinfo.getFileSize()+"\"");
			strtBuf.append("Content-Type: "+fileinfo.getContentType()+"\r\n\r\n");//\r\nContent-Transfer-Encoding: base64
			return Arrays.asList(new ByteArrayInputStream(strtBuf.toString().getBytes()),in);
		}
		return null;
	}

	public IMediaFileInfo getMediaFileInfo(UploadFileEntity entity, boolean isThumbnail) {
		try {
			IMediaFileInfo media = new MediaFileInfo(entity, isThumbnail);
			if(media.getFileSize()>0)return media;
		}catch(Exception e) {
			log.debug("Skip mediaFileInfo since " + e.getMessage());
		}
		return null;
	}
	
	public static interface IMediaFileInfo{
		String getFilename();
		long getFileSize();
		String getContentType();
		InputStream open() throws IOException;
		String getMd5();
		boolean resizeTo(long toFileSize);
	}
	
	private static class MediaFileInfo implements IMediaFileInfo{
		Path file;
		URL url;
		/** ���õ�Hash�㷨 */
		String hashAlgorithm = "MD5";
		/** 0:need Read from url  1:readed 10:is Local file */
		int copyFile;
		MediaFileInfo(UploadFileEntity entity, boolean isThumbnail) throws IOException{
			this(entity, isThumbnail, null);
		}
		/***
		 * 
		 * @param entity
		 * @param isThumbnail
		 * @param hashAlgorithm  ���õ�hash�㷨 MD5 sha256 null
		 * @throws IOException
		 */
		MediaFileInfo(UploadFileEntity entity, boolean isThumbnail, String hashAlgorithm) throws IOException{
			this.hashAlgorithm = hashAlgorithm;
			String filepath;
			String url;
			if(isThumbnail) {
				filepath=entity.getThumbnailLocalPath();
				url = entity.getThumbnailUrl();
				contentType=entity.getThumbnailContentType();
			}else {
				filepath=entity.getContentLocalPath();
				url = entity.getMediaUrl();
				contentType=entity.getMediacontentType();
			}
			file = Paths.get(filepath);
			if(filepath!=null && (file = Paths.get(filepath))!=null && Files.isReadable(file)) {
				copyFile = 10;
				filename = file.getFileName().toString();
			}else if(url!=null && !url.isEmpty()){
				try {
					URL u = new URL(url);
					this.url = u;
					String tmp = u.getFile();
					filename = new File(tmp).getName();
				} catch (MalformedURLException e) {
					throw new IOException("Create media file info error, wrong url",e);
				}
				copyFile = 0;
			}else {
				throw new IOException("Create media file info error, no file and url found");
			}
		}
		
		synchronized boolean doCopyFile() throws IOException {
			if(copyFile>0)return true;
			if(copyFile==0) {
				Path tmpFile = Paths.get(tempDir, this.getFilename());
				try (
						SizedInputStream sizedin = new SizedInputStream(url.openStream());
						){
					
					MessageDigest digest = null;
					try {
						if(hashAlgorithm!=null)digest = MessageDigest.getInstance(hashAlgorithm);
					} catch (NoSuchAlgorithmException ignore) {}
					sizedin.setDigest(digest);
					Files.copy(sizedin, tmpFile, StandardCopyOption.REPLACE_EXISTING);
					file = tmpFile;
					filesize = sizedin.getOffset();
					if(digest!=null){
						byte[] bytes = digest.digest();
						if(bytes!=null){
							StringBuilder sb = new StringBuilder();
							for(int i=0;i<bytes.length;i++){
								int b = 0xFF & bytes[i];
								if(b<0x10)sb.append('0');
								sb.append(Integer.toHexString(b));
							}
							md5=sb.toString();
						}
					}
				}
				copyFile = 1;
			}else {
				filesize = Files.size(file);
			}
			return true;
		}
		
		public boolean resizeTo(long toFileSize) {
			if(getContentType().toLowerCase().startsWith("image")) {
				try(InputStream in = open()){
					File file = resizeImage(in, toFileSize);
					if(file!=null && file.length()<toFileSize) {
						this.file = file.toPath();
						this.filesize = file.length();
						this.filename = file.getName();
						return true;
					}
				}catch(Exception e) {
					log.warn("resize image file error!");
				}
			}
			return false;
		}
		
		String filename;
		String md5;
		String contentType;
		long filesize = -1;
		
		public String getFilename() {
			return filename;
		}
		public long getFileSize() {
			if(filesize>=0)return filesize;
			try {
				doCopyFile();
				filesize = Files.size(file);
				return filesize;
			}catch(Exception e) {
				log.debug("No file create");
			}
			return -1;
		}
		public String getMd5() {
			if(hashAlgorithm==null) {
				return null;
			}
			if(md5==null && file!=null) {
				MessageDigest digest = null;
				try (InputStream in = open()){
					digest = MessageDigest.getInstance(hashAlgorithm);
					byte[] bytes = new byte[1024];
					int len;
					while((len=in.read(bytes))>=0) {
						digest.update(bytes, 0, len);
					}
					bytes = digest.digest();
					if(bytes!=null){
						StringBuilder sb = new StringBuilder();
						for(int i=0;i<bytes.length;i++){
							int b = 0xFF & bytes[i];
							if(b<0x10)sb.append('0');
							sb.append(Integer.toHexString(b));
						}
						md5=sb.toString();
					}
				} catch (IOException ignore) {	
				} catch (NoSuchAlgorithmException ignore) {}
			}
			return md5;
		}
		public String getContentType() {
			return contentType;
		}
		public InputStream open() throws IOException{
			doCopyFile();
			return Files.newInputStream(file, StandardOpenOption.READ);
		}
		
		
	}
		
	
	
	private static String tempDir = System.getProperty("java.io.tmpdir");
//	/** ������ʱ�ļ� */
//	private static  Path makeTempFile(URL u) throws IOException {
//		String fileName = new File(u.getFile()).getName();
//		Path tmpFile = Paths.get(tempDir, fileName);
//		try (
//				InputStream in = (u.openStream());
//				){
//			Files.copy(in, tmpFile, StandardCopyOption.REPLACE_EXISTING);
//			return tmpFile;
//		}
//	}

	

	private static final int tiny_width = 100;
	private static final int tiny_height = 100;
	private static final int small_width = 196;
	private static final int small_height = 196;
	

	/** ��С�ļ���С,  �����ߴ�Ϊ 100X100, ���������� **/
	public static File resizeImage(String imgFile, long tartSize) throws IOException {
		return resizeImage(new FileInputStream(imgFile), tartSize);
	}
	
	/** ��С�ļ���С,  �����ߴ�Ϊ 100X100, ���������� **/
	public static File resizeImage(InputStream in, long tartSize) throws IOException {
		BufferedImage originalImage = ImageIO.read(in);
		int type = originalImage.getType() == 0? BufferedImage.TYPE_INT_ARGB : originalImage.getType();
		File tmpFile = File.createTempFile("thumbFile", ".jpg");
		
		int target_width, target_height;
		if(tartSize <= 10*1024) {
			target_width = tiny_width;
			target_height = tiny_height;
		}else {
			target_width = small_width;
			target_height = small_height;
		}
		BufferedImage image =  resizeImageWithHint(originalImage, type, target_width, target_height);
		ImageIO.write(image, "jpg", tmpFile);
		return tmpFile;
	}

	
	private static BufferedImage resizeImageWithHint(BufferedImage originalImage, int type, int img_width, int img_height){
		BufferedImage resizedImage = new BufferedImage(img_width, img_height, type);
		Graphics2D g = resizedImage.createGraphics();
		g.drawImage(originalImage, 0, 0, img_width, img_height, null);
		
		// ����������
		g.dispose();	
		g.setComposite(AlphaComposite.Src);
		g.setRenderingHint(RenderingHints.KEY_INTERPOLATION,
				RenderingHints.VALUE_INTERPOLATION_BILINEAR);
		g.setRenderingHint(RenderingHints.KEY_RENDERING,
				RenderingHints.VALUE_RENDER_QUALITY);
		g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
				RenderingHints.VALUE_ANTIALIAS_ON);
		return resizedImage;
	}	

}
