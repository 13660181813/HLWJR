package org.ydzy.rcs.impl;

import java.util.List;
import java.util.Map;

import org.ydzy.handler.BaseRcsContext;
import org.ydzy.rcs.CardModel;
import org.ydzy.rcs.annotation.Description;
import org.ydzy.rcs.entity.ReceiveEntity;

import com.google.gson.JsonObject;
import com.google.inject.Singleton;
@Singleton
@Description(TemplateCardContent.TYPE)
public class TemplateCardContent extends MulitiCardContent implements CardModel{
	public static final String TYPE = "templatecard";
	public static final String FOREIGN_TEMPLATE_MODEL_PARAM = "foreignTemplateModelParam";
	
	@Override
	protected List<Map<String,Object>> modelParams(ReceiveEntity requestObject,JsonObject contentObject,BaseRcsContext context){
		Object o =  context.getAttributes().get(FOREIGN_TEMPLATE_MODEL_PARAM);
		if(o!=null && o instanceof List) {
			return (List<Map<String,Object>>)o;
		}
		return super.modelParams(requestObject,contentObject, context);
	}

}
