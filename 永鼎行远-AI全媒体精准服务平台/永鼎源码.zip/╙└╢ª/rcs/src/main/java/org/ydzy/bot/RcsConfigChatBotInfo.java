package org.ydzy.bot;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.ydzy.rcs.RcsConfig;

import com.google.gson.JsonObject;
import com.google.inject.Inject;
import com.google.inject.Provider;

class RcsConfigChatBotInfo implements Provider<List<BotInfo>>{

	@Inject
	private RcsConfig config;
	
	@Override
	public List<BotInfo> get() {
		Map<String, JsonObject> map = config.getChatbotInfo();
		if(map!=null && map.size()>0) {
			List<BotInfo> list = new ArrayList<>();
			for(JsonObject jo:map.values()) {
				String chatbotid=BotUtil.getElementAsString(jo, "chatbotid");
				String appid=BotUtil.getElementAsString(jo, "appid");
				String appkey=BotUtil.getElementAsString(jo, "secretkey");
				String token=BotUtil.getElementAsString(jo, "token");
				BotInfo bi = new BotInfo(chatbotid, appid, appkey, token, jo);
				list.add(bi);
			}
			return list;
		}
		return null;
	}
	

}