package org.ydzy.csp.service;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.*;

import javax.sql.DataSource;

import org.ydzy.handler.BaseHandler;
import org.ydzy.rcs.Provider;
import org.ydzy.rcs.annotation.Description;
import org.ydzy.rcs.db.XmlSqlGenerator;
import org.ydzy.rcs.impl.OperationLogService;
import org.ydzy.rcs.module.LoadProperties;
import org.ydzy.util.NetUtils;
import org.ydzy.util.SqlUtil;
import org.ydzy.util.Util;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.inject.Singleton;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@Singleton
@Description(value="cmccCsp")
public class CmccCsp extends BaseCspInter {
	private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(CmccCsp.class);

	volatile String accesskey = LoadProperties.systemProperties.getProperty("csp.cmcc.accessKey");
	volatile String cspid = LoadProperties.systemProperties.getProperty("csp.cmcc.cspId");
	volatile long accessTokenTime = 0;
	public void checkAccessToken(DataSource ds, HttpServletRequest request) {
		if (accessTokenTime == 0 || Util.isNull(accessToken))
			accessToken(ds,request);
		else {
			boolean flag=isTimeOutToken(accessTokenTime,"csp.cmcc.accessTimeOut");
			if (flag) {
				accessToken(ds,request);
			}
		}
	}
	
	public CmccCsp()
	{
		super();
	}

	@Override
	protected boolean updatePhoneNumber(TaskInner task) {
		// TODO: 2022/1/11
		return true;
	}

	@Override
	protected boolean quitTestStatus(TaskInner task) {
		// TODO: 2022/1/11
		return true;
	}

	public boolean validateHeader(HttpServletRequest request,DataSource ds)
	{
		Map<String,String> headMap=new HashMap<String,String>();
		Enumeration<String> headers =request.getHeaderNames();
		while(headers.hasMoreElements())
		{
			String key = headers.nextElement();
			String value=request.getHeader(key);
			headMap.put(key, value);
		}
		
		String nonce=headMap.get("nonce");
		String signature=headMap.get("signature");
		String timestamp=headMap.get("timestamp");
		String authorization=headMap.get("authorization");
		String signaturecompute= Util.encrypt(accesskey + nonce + timestamp);
		Date date=Util.isNull(timestamp)?new Date():parse(timestamp);
		boolean flag=isTimeOutToken(date.getTime(),"csp.cmcc.accessTimeOut");
		if(flag)
		{
			try {
				logger(ds, "error", "500","validateHeaderError" , "accessToken "+authorization+" timeout timestamp "+timestamp, BaseHandler.getIpAddress(request), request,  "TeleComCspimp");
			} catch (IOException e) {
				e.printStackTrace();
			}
		}else
		{
			if(signaturecompute.equals(signature))
			{
				try {
					logger(ds, "info", "200","validateHeaderSucess" , "accessToken "+authorization+" timeout timestamp "+timestamp, BaseHandler.getIpAddress(request), request,  "TeleComCspimp");
				} catch (IOException e) {
				}
				return true;
			}
			else {
				try {
					logger(ds, "error", "500","validateHeaderError" ,"md5 check failed signature error "+signature+" md5str "+accesskey + nonce + timestamp +" signaturecompute "+signaturecompute, BaseHandler.getIpAddress(request), request,  "TeleComCspimp");
				} catch (IOException e) {
					e.printStackTrace();
				}
				return false;
			}
		}
		return false;
	}
	Gson gson = new Gson();

	/**
	 * 
	 */
	public synchronized void accessToken(DataSource ds, HttpServletRequest request) {
		LocalDateTime time = LocalDateTime.now(ZoneOffset.of("+8"));
if(gson==null)gson=new Gson();
if(accesskey==null) accesskey = LoadProperties.systemProperties.getProperty("csp.cmcc.accessKey");
if(cspid==null)cspid = LoadProperties.systemProperties.getProperty("csp.cmcc.cspId");
		Map<String, Object> header = headers(accesskey, time);

		JsonObject body = new JsonObject();
		body.addProperty("cspId", cspid);
		body.addProperty("accessKey", accesskey);
		String uri = LoadProperties.systemProperties.getProperty("csp.cmcc.accessTokenUri");
		String gsonhead=gson.toJson(header);
		try {
			log.info("request AccessToken  \r\nuri{}   \r\nheader {}   \r\nbody {} ", uri, gsonhead, body);
			String response = NetUtils.doHttps(uri,  gson.toJson(body), header, "application/json");
			JsonObject resObj = requestBody2Json(response);
			if(resObj==null)
				return ;
			JsonObject data = resObj.getAsJsonObject("data");
			if (data != null && !data.isJsonNull()) {
				accessToken = Util.getElementAsString(data, "accessToken");
				accessTokenTime = LocalDateTime.now().toInstant(ZoneOffset.of("+8")).toEpochMilli();
			}
			
			if(Util.isNull(accessToken))
			{
				try {
					logger(ds, "warn", "500", "get accessToken from uri "+uri+" failed ", "head is: "+gsonhead +" body is "+gson.toJson(body), request!=null?BaseHandler.getIpAddress(request):"", request,  "BaseCspInter");
				} catch (IOException e) {
					e.printStackTrace();
				}
			}else
			{
				logger(ds, "info", "200", "get accessToken from uri "+uri+" sucess  token: "+accessToken +" tokenTime : "+accessTokenTime, "head is: "+gsonhead +" body is: "+gson.toJson(body), request!=null?BaseHandler.getIpAddress(request):"", request,  "BaseCspInter");
			}

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * �ϴ��ͻ����� 6.1 �ӿ���Ϣ �ӿڷ���CSP��5G ��Ϣҵ�����ƽ̨ �ӿ�˵�������ڴ����ͻ�ǰ�ϴ��ͻ�������Ϣ����Ӫҵִ�ա�����֤���������Ϣ��
	 * 6.2 ���󷽷� ���󷽷���HTTPS POST ����
	 * URL��https://{serverRoot}/cspApi/{apiVersion}/uploadFile
	 */
	public boolean doUploadFile(TaskInner task) {
		DataSource ds=task.ds;
		JsonObject body=task.body;
		HttpServletRequest request=task.request; HttpServletResponse rsp=task.response;
		LocalDateTime time = LocalDateTime.now(ZoneOffset.of("+8"));
		Map<String, Object> header = headers(accesskey, time,"multipart/form-data");
		header.put("authorization", accessToken);
		String uploadType = request.getParameter("uploadType");// Util.getElementAsString(body, "uploadType");
		String fileType=request.getParameter("fileType");// 1:ecinfo  2 chatbot
		
		header.put("uploadType", uploadType);
		boolean flag=false;
		try {
			Map<String, Object> uploadObj = uploadFile(request);
			String localFile = Util.toString(uploadObj.get("localPath"));
			String filename =	 Util.toString(uploadObj.get("filename"));
			String uri = LoadProperties.systemProperties.getProperty("csp.cmcc.uploadFileUri");
			if("2".equals(fileType))
				 uri = LoadProperties.systemProperties.getProperty("csp.cmcc.uploadChatbotFileUri");
			try {
				logger(ds, "info", "ready", "request uploadFile "+uri, "upload "+filename, BaseHandler.getIpAddress(request), request,  "TeleComCspimp.uploadFiles");
			} catch (IOException e) {
				e.printStackTrace();
			}
			String response = null;
			try{
				String boundary="--------------------------"+UUID.randomUUID().toString().replace("-", "");
				if(task.doretryRMI) {
					ByteBuffer buffer =NetUtils.getMultiPartBody(localFile, Util.fileType(filename), boundary);
					response = NetUtils.doHttps(uri, buffer  , header, "multipart/form-data;boundary="+boundary);
				}
				
			}catch (IOException ioe){

			}
			JsonObject resObj=new JsonObject();
			Object [] paramsUpdate=null;
			String resbody1="";
			if(!Util.isNull(response))
			{
//				resbody1=response;
				JsonObject resObjnew = requestBody2Json(response);
				String code=Util.getElementAsString(resObjnew, "code");
				if("42001".equals(code)) {
					accessToken( ds,  request);
					doUploadFile(task);
				}
				JsonObject data = resObjnew.getAsJsonObject("data");
				if (data != null && !data.isJsonNull()) {
					// TODO ADD 2db
					String uploadFileUrl = Util.getElementAsString(data, "url");
					if(Util.isNull(uploadFileUrl))uploadFileUrl=Util.getElementAsString(data,"filePath");
					resObj.addProperty("url", uploadFileUrl);
					flag=true;
					task.doretryRMI=false;
					resbody1=resBodyJson("200","upload 2 5GServer sucess ",resObj);
					//INSERT INTO `rcs_csp_files`(`uploadServerUrl`, `headers`, `fileParams`, `url`, `uploadType`, `fileName`, `from`) VALUES (?,?, ?,?, ?,?,?);
					 paramsUpdate=new Object [] {
							uri,gson.toJson(header),gson.toJson(uploadObj),uploadFileUrl,uploadType,filename,fileType
					};
					 try {
							logger(ds, "info", "200", "uploadFile sucess "+uri +"responseuri "+uploadFileUrl+"body "+gson.toJson(body), resbody1, BaseHandler.getIpAddress(request), request,  "TeleComCspimp.uploadFiles");
						} catch (IOException e) {
							e.printStackTrace();
						}	
				}
			}

			else
			{
				
				String upurl=LoadProperties.systemProperties.getProperty("webUrl")+"/media/"+filename;
				resObj.addProperty("url",upurl );
				paramsUpdate=new Object [] {
						uri,gson.toJson(header),gson.toJson(uploadObj),upurl,uploadType,filename,fileType
				};
				resbody1=resBodyJson("500","upload 2 5GServer failed ",resObj);
				try {
					logger(ds, "info", "500", "uploadFile failed "+uri +"responseuri "+upurl+"body "+gson.toJson(body), resbody1, BaseHandler.getIpAddress(request), request,  "TeleComCspimp.uploadFiles");
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			if(task.add2db)
			task.add2db=!InsertUploadFiles(ds,paramsUpdate);
			try {
				sendResponse(BaseHandler.getIpAddress(request), resbody1, 200, request, rsp);
				return flag;
			} catch (IOException e) {
				e.printStackTrace();
			}
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ServletException e) {
			e.printStackTrace();
		}
		return flag;
	}

	/**
	 *URL 
		1��uploadType���ϴ��������͡�0���ͻ�ͼƬ 1������֤������  2����ͬ
		2��fileType�� 1:ecinfo �ͻ�����   2 chatbot chatbot����
		3��body ���� �ļ�����������
		4��operatorType ��������
		5��isp��	1:�й��ƶ� telcsp:�й����� 3:�й���ͨ	
		��� �ֶ� �� �� ���� ���� ���� �� ѡ ���� ����
1 rcsRegisterInfo object M �ͻ�������Ϣ,��ϸ�뿴rcsRegisterInfo ����˵��
2 rcsInfo object M �ͻ���ҵ��Ϣ,��ϸ�뿴 rcsInfo ����˵��
3 rcsContractInformation object M ��ͬ��Ϣ,��ϸ�뿴rcsContractInformation ����˵��
4 rcsLegalP object M �ͻ�������Ϣ,��ϸ�뿴 rcsLegalP����˵��
		{
 "rcsRegisterInfo": {
 "ecName": "�й�����",
 "ecGrade": 1,
 "businessType": 1
 },
 "rcsInfo": {
 "introduce": "XXXXXX ��˾���� 2010-08-16 ����,��ҵ��Ҫ����������������Ӧ;�ȵ���
����������졢����;����Դ��������;���¹ܡ����¼������°����졢����",
 " serviceIcon ": "http://172.17.25.10:9081/7,026c1babd98a",
 "workPhone": "020-58587765",
 "businessLicense": "http://172.17.25.10:9081/7,026d2c25342d",
 "businessAddress": "������ 13 ��", "province": "�����",
 "city": "�����",
 "area": "�Ͽ���",
 "operatorName": "������",
 "operatorCard": "210102199003077037",
 "operatorPhone": "133XXXXXXXX",
 " emailAddress ": "133XXXXXXXX@189.cn",
 " operatorIdentityPic ": 
["http://172.17.25.10:9081/7,026d2c25342d","http://172.17.25.10:9081/7,026d2c25342d"]
 },
 "rcsContractInformation": {
 "contractNo": "100001",
 "name": "��ͬ����",
 "effectiveDate": "20201208013659",
 "expiryDate": "20221208013659",
 "status": 1,
 "renewalDate": "20211208013659",
 "accessory": "http://172.18.91.4:8080/2,03bdf0e3a1"
 },
 "rcsLegalP": {
 "legalName": "��ΰ",
 "legalIdentification": "110302203002030203",
 "identificationStraight": "http://172.17.25.10:9081/7,026d2c25342d",
 "identificationCounter": "http://172.17.25.10:9081/7,026d2c25342d"
 }
}
rcsRegisterInfo ����˵��: 
��� �ֶ� �������� ���ݳ��� ��ѡ���� ����
1 ecName string 34 M �ͻ�����
2 businessType int 4 M �ͻ���ҵ���ͣ��μ�����ҵ�����ֵ� id �ֶ�  rcs_tags  isp
3 ecGrade int 4 M 0 ���Ƽ���1 ���Ƽ���2 ͭ�Ƽ���3 ��׼����Ĭ�ϣ�3��׼��
rcsInfo ����˵��:
��� �ֶ� �������� �� �� ���� �� ѡ ���� ����
1 introduce string 999 M ��ҵ����
2 serviceIcon string 128 M ��ҵ logo����ʹ�ÿͻ������ϴ��ӿڷ��صĵ�ַ
3 workPhone string 32 M �칫�绰
4 businessLicense string 255 M ��ҵӪҵִ�գ���ʹ�ÿͻ������ϴ��ӿڷ��صĵ�ַ
5 businessAddress string 64 M ��ҵ���ڵ�
6 province string 64 M ʡ��
7 city string 64 M ��
8 area string 64 M ��
9 operatorName string 16 M �ͻ���ϵ��
10 operatorCard string 16 M �ͻ���ϵ������֤��
11 operatorPhone string 32 M �ͻ���ϵ���ֻ���
12 emailAddress string 64 M �ͻ���ϵ������
13 operatorIdentityPic array 255 M �ͻ���ϵ������֤�������ļ���ַ

 rcsContractInformation ����˵��:
��� �ֶ� �������� ���� ���� �� ѡ ���� ����
1 contractNo string 255 M ��ͬ����
2 name string 32 M ��ͬ����
3 effectiveDate string 14 M �� ͬ �� Ч �� �� ��yyyyMMddHHmmss��:20201208013659
4 expiryDate string 14 M �� ͬ ʧ Ч �� �� ��yyyyMMddHHmmss��:20201208013659
5 status int 4 M ��ͬ�Ƿ���ǩ(1.�� 2.��)
6 renewalDate string 14 C �� ͬ �� ǩ �� �� ��yyyyMMddHHmmss��:20201208013659
7 accessory string 255 M ��ͬ��������ʹ�ÿͻ������ϴ��ӿڷ��ص� url

rcsLegalP ����˵��:
��� �ֶ� �������� �� �� ���� �� ѡ ���� ����
1 legalName string 20 M ��������
2 legalIdentification string 64 M ��������֤��
3 identificationStraight string 512 M ��������֤�����ļ���ַ
4 identificationCounter string 512 M ��������֤�����ļ���ַ
	 */
	public boolean addCspCustomer(TaskInner task) {
		DataSource ds=task.ds;
		JsonObject body=task.body;
		JsonObject bodyCopy=task.body.deepCopy();
		HttpServletRequest request=task.request; HttpServletResponse response=task.response;
		boolean flag=false;
		String uri = LoadProperties.systemProperties.getProperty("csp.cmcc.addCspCustomerUri");
		

		JsonObject rcsRegisterInfo = body.getAsJsonObject("rcsRegisterInfo");
		JsonObject rcsInfo = body.getAsJsonObject("rcsInfo");
		JsonObject rcsContractInformation = body.getAsJsonObject("rcsContractInformation");
		JsonObject rcsLegalP = body.getAsJsonObject("rcsLegalP");
//		if(task.add2db)
//		task.add2db=!insertCspCustomer(gson,body,ds);
//		rcsInfo.remove("operatorarea");
//		rcsInfo.remove("operatorsex");
//		rcsInfo.remove("operatoripfrom");
		JsonArray array = new JsonArray();
		array.add(Util.getElementAsString(rcsInfo, "operatorIdentityPic1"));
		array.add(Util.getElementAsString(rcsInfo, "operatorIdentityPic2"));

		rcsInfo.add("operatorIdentityPic", array);

		rcsInfo.remove("operatorIdentityPic1");
		rcsInfo.remove("operatorIdentityPic2");
		rcsLegalP.remove("operatorIdentityPic1");
		rcsLegalP.remove("operatorIdentityPic2");
		rcsRegisterInfo.remove("cspEcNo");
		JsonObject resbody = new JsonObject();
		resbody.add("rcsRegisterInfo", rcsRegisterInfo);
		resbody.add("rcsInfo", rcsInfo);
		resbody.add("rcsContractInformation", rcsContractInformation);
		rcsLegalP.remove("operatorPhone");
		resbody.add("rcsLegalP", rcsLegalP);
//		resbody.remove("isp");
		try {
			logger(ds, "info", "ready", "addCustomer2Db sucess ready request  "+uri , gson.toJson(resbody), BaseHandler.getIpAddress(request), request,  "TeleComCspimp.addCustomers");
		} catch (IOException e) {
			e.printStackTrace();
		}
		try {
			
			String r = "";
			if(task.doretryRMI)
			{
				r=post25gMsgAddCspCustomer(uri,resbody);
			}
			String resbody1="";
			if(!Util.isNull(r))
			{
				JsonObject ro = requestBody2Json(r);
				String code=Util.getElementAsString(ro, "code");
				if("0".equals(code))
				{
					JsonObject data = ro.getAsJsonObject("data");
					String cspEcNo = Util.getElementAsString(data, "cspEcNo");
					if(Util.isNull(cspEcNo)) {
						resbody1=resBodyJson("500","addCustomer failed  ���������� ",data);
						task.add2db=false;
						flag=true;
					}
					else {
						if(task.add2db)
							task.add2db=!insertCspCustomer(gson,bodyCopy,ds);
						resbody1=resBodyJson("200","addCustomer sucess ",data);
						task.doretryRMI=false;
//						waitNotifyQueue.add(task);
						Object[] updateParam = new Object[] { cspEcNo , Util.getElementAsString(rcsRegisterInfo, "ecName")};
						updateCspNo(ds,updateParam);
						flag=true;
						try {
							logger(ds, "info", "sucess", "addCustomer Request sucess ready request  "+uri+"body "+gson.toJson(body) , resbody1, 					BaseHandler.getIpAddress(request), request,  "TeleComCspimp.addCustomers");
						} catch (IOException e) {
							e.printStackTrace();
						}
					}
				}else if("42001".equals(code)){
					accessToken( ds,  request);
				}else
				{
					task.add2db=false;
					flag=true;
					resbody1=resBodyJson("500","addCustomer failed  ���������� ",ro);
				}
				
			}else
			{
				if(task.add2db)
					task.add2db=!insertCspCustomer(gson,bodyCopy,ds);
				String cspEcNo = "YD"+new java.util.Random().nextInt();
				Object[] updateParam = new Object[] { cspEcNo , Util.getElementAsString(rcsRegisterInfo, "ecName")};
				updateCspNo(ds,updateParam);
				 resbody1=resBodyJson("200","addCustomer request will be retried later ",null);
				 try {
						logger(ds, "warn", "failed", "addCustomer Request failed ready request  "+uri+"body "+gson.toJson(body) , resbody1, 					BaseHandler.getIpAddress(request), request,  "TeleComCspimp.addCustomers");
					} catch (IOException e) {
						e.printStackTrace();
					}
			}
			
			try {
				sendResponse(BaseHandler.getIpAddress(request), resbody1, 200, request, response);
				return flag;
			} catch (IOException e) {
				e.printStackTrace();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	public  String post25gMsgAddCspCustomer(String uri,JsonObject resbody) {
		LocalDateTime time = LocalDateTime.now(ZoneOffset.of("+8"));
		Map<String, Object> header = headers(accesskey, time);
		header.put("authorization", accessToken);		
		try {
			String	r = NetUtils.doHttps(uri, resbody, header, "application/json");
			return r;
		}catch (IOException ioee){
		}
		return null;
	}
	public boolean getFile(TaskInner task) {
		DataSource ds=task.ds;
		JsonObject body=task.body;
		HttpServletRequest request=task.request; HttpServletResponse response=task.response;
		boolean flag=false;
		LocalDateTime time = LocalDateTime.now(ZoneOffset.of("+8"));
		String uri = LoadProperties.systemProperties.getProperty("csp.cmcc.getFileUri");
		Map<String, Object> header = headers(accesskey, time);
		header.put("authorization", accessToken);
		String fileUrl = Util.getElementAsString(body, "fileUrl");
		JsonObject sendbody = new JsonObject();
		sendbody.addProperty("fileUrl", fileUrl);
		//TODO GETFILES ?
		try {
			String responsebody = "";
			if(task.doretryRMI)
				 responsebody = NetUtils.doHttps(uri, sendbody, header, " application/json");
			if(!Util.isNull(responsebody))
			{
				String res = new String(Base64.getEncoder().encode(responsebody.getBytes("UTF-8")));
				task.doretryRMI=false;
				JsonObject obj=new JsonObject();
				obj.addProperty("content", res);
				obj.addProperty("code","base64");
				String resbody1=resBodyJson("200","getFile sucess",obj);
				flag=true;
				try {
					 try {
							logger(ds, "info", "sucess", "getFile sucess ready request  "+uri+"body "+gson.toJson(body) , resbody1, 								BaseHandler.getIpAddress(request), request,  "TeleComCspimp.getFiles");
						} catch (IOException e) {
							e.printStackTrace();
						}
					sendResponse(BaseHandler.getIpAddress(request), resbody1, 200, request, response);
					return flag;
				} catch (IOException e) {
					e.printStackTrace();
				}
			}else
			{
				String resbody1=resBodyJson("500","getFile failed",null);
					 try {
							logger(ds, "warn", "failed", "getFile sucess ready request  "+uri+"body "+gson.toJson(body) , resbody1, 								BaseHandler.getIpAddress(request), request,  "TeleComCspimp.getFiles");
						} catch (IOException e) {
							e.printStackTrace();
						}
					sendResponse(BaseHandler.getIpAddress(request), resbody1, 200, request, response);
					return flag;
				
		   }
		}catch (IOException e) {
			e.printStackTrace();
		}
		return flag;
	}

	Map<String, String> rcsRegisterInfoMap = new HashMap<String, String>() {
		{
			put("ecName", "ecName");
			put("ecGrade", "ecGrade");
			put("businessType", "businessType");
			put("cspEcNo","cspEcNo");
		}
	};

	Map<String, String> rcsInfoMap = new HashMap<String, String>() {
		{
			put("introduce", "introduce");
			put("serviceIcon", "serviceIcon");
			put("workPhone", "workPhone");
			
			put("businessLicense", "businessLicense");
			put("businessAddress", "businessAddress");
			put("province", "province");
			put("city", "city");
			put("area", "area");
			put("operatorRcsUserId", "operatorRcsUserId");
			put("operatorUserId", "operatorUserId");
			put("contractNo", "contractNo");
			put("legalUserId", "legalUserId");
			put("operatorName", "operatorName");
			put("operatorCard", "operatorCard");
			put("operatorPhone", "operatorPhone");
			put("emailAddress", "emailAddress");
			put("operatorIdentityPic1","operatorIdentityPic1");
			put("operatorIdentityPic2","operatorIdentityPic2");
			put("operatorarea","operatorarea");
			put("operatoripfrom","operatoripfrom");
			put("operatorsex","operatorsex");
//			put("serverIcon","serverIcon");
		}
	};
	Map<String, String> rcsContractInformationMap = new HashMap<String, String>() {
		{
			put("contractNo", "contractNo");
			put("name", "name");
			put("effectiveDate", "effectiveDate");
			
			
			put("expiryDate", "expiryDate");
			put("status", "status");
			put("renewalDate", "renewalDate");
			put("accessory", "accessory");
		}
	};
	Map<String, String> rcsLegalIpMap = new HashMap<String, String>() {
		{
			put("legalRcsUserId", "legalRcsUserId");
			put("legalName", "legalName");
			put("legalIdentification", "legalIdentification");
			put("identificationStraight", "identificationStraight");
			put("identificationCounter", "identificationCounter");
			put("operatorIdentityPic1","operatorIdentityPic1");
			put("operatorIdentityPic2","operatorIdentityPic2");
			put("operatorPhone","operatorPhone2");
		}
	};
	protected JsonArray  getNotifyResult(){
//		String sqlid = "updateChatbotDeveloper";
//		try {
//			String sql = XmlSqlGenerator.getSql(sqlid).exeSql;
//			JsonArray array = SqlUtil.queryForJson(ds, sql);
//			if(array==null)
//			{
//				System.out.println("why");
//			}
//			return array;
//		}
//		catch (Exception e) {
//		e.printStackTrace();
//		}
		return null;
	}
	protected JsonArray getUnCommitCustomers()
	{
//		String sqlid = "queryUnCommitCustomers";
//		try {
//			String sql = XmlSqlGenerator.getSql(sqlid).exeSql;
//			JsonArray array = SqlUtil.queryForJson(ds, sql);
//			JsonArray resArray=dbRecord2CspStructs(array);
//			return resArray;
//		}
//		catch (Exception e) {
//		}
		return null;
	}
	public void showEcInfos(TaskInner task) {
		DataSource ds=task.ds;
		JsonObject body=task.body;
		HttpServletRequest request=task.request; HttpServletResponse response=task.response;
		/*
		 * SELECT A.*, b.username AS operatorName, b.phone AS operatorPhone, b.area AS
		 * operatorarea, b.sex AS operatorsex, b.ipfrom AS operatoripfrom,
		 * b.operatorCard AS operatorCard, b.emailAddress AS emailAddress,
		 * b.operatorIdentityPic1 AS operatorIdentityPic1, b.operatorIdentityPic2 AS
		 * operatorIdentityPic2, c.username AS legalName, c.operatorCard AS
		 * legalIdentification, c.operatorIdentityPic1 AS identificationStraight,
		 * c.operatorIdentityPic2 AS identificationCounter, `name`, DATE_FORMAT( (
		 * effectiveDate ), '%Y%m%d%H%i%S' ) effectiveDate, DATE_FORMAT( ( expiryDate ),
		 * '%Y%m%d%H%i%S' ) expiryDate, `status`, DATE_FORMAT( ( renewalDate ),
		 * '%Y%m%d%H%i%S' ) renewalDate, accessory FROM rcs_csp_ecinfo A LEFT JOIN
		 * rcs_user b ON a.operatorUserId = b.userid LEFT JOIN rcs_user c ON
		 * a.legalUserId = b.userid LEFT JOIN rcs_csp_contractinfomation d ON
		 * a.contractNo = d.contractNo
		 */
	
		String sqlid = "showecinfos";
		Map dbParam=gson.fromJson(body, Map.class);
		String sql = XmlSqlGenerator.getSqlstrByMap(sqlid,dbParam);
		try {
			JsonArray array = SqlUtil.queryForJson(ds, sql);
			JsonArray resArray=dbRecord2CspStructs(array);
			String send=resBodyJson("200","sucess",resArray);
			sendResponse(BaseHandler.getIpAddress(request),send,200,request,response);
			task.add2db=false;
			task.doretryRMI=false;
		} catch (SQLException | IOException e) {
			e.printStackTrace();
		}
	}
	private JsonArray dbRecord2CspStructs(JsonArray array)
	{
		JsonArray resArray=new JsonArray();
		for (JsonElement c : array) {
			JsonObject record = c.getAsJsonObject();
			JsonObject rcsRegisterInfo = new JsonObject();// "rcsRegisterInfo"
			JsonObject rcsInfo = new JsonObject();// ("rcsInfo");
			JsonObject rcsContractInformation = new JsonObject();// ("rcsContractInformation");
			JsonObject rcsLegalP = new JsonObject();// ("rcsLegalP");
			rcsRegisterInfoMap.forEach((k,v)->{
				rcsRegisterInfo.addProperty(k, Util.getElementAsString(record, v));
			});
			rcsInfoMap.forEach((k,v)->{
				rcsInfo.addProperty(k, Util.getElementAsString(record, v));
			});
			rcsContractInformationMap.forEach((k,v)->{
				rcsContractInformation.addProperty(k, Util.getElementAsString(record, v));
			});
			rcsLegalIpMap.forEach((k,v)->{
				rcsLegalP.addProperty(k, Util.getElementAsString(record, v));
			});
			JsonObject newRecord=new JsonObject();
			newRecord.add("rcsRegisterInfo", rcsRegisterInfo);
			newRecord.add("rcsInfo", rcsInfo);
			newRecord.add("rcsContractInformation", rcsContractInformation);
			newRecord.add("rcsLegalP", rcsLegalP);
			
			resArray.add(newRecord);
		}
		return resArray;
	}
	public boolean editCspCustomer(TaskInner task) {
		DataSource ds=task.ds;
		JsonObject body=task.body;
		HttpServletRequest request=task.request; HttpServletResponse response=task.response;
		boolean flag=false;
		LocalDateTime time = LocalDateTime.now(ZoneOffset.of("+8"));
		String uri = LoadProperties.systemProperties.getProperty("csp.cmcc.editcspCustomerUri");
		Map<String, Object> header = headers(accesskey, time);
		header.put("authorization", accessToken);		

		if(task.add2db)
			task.add2db=!updateCspInfos(gson,body,ds);
		JsonObject resbody = reBuildCustomers(body);
		JsonObject rcsRegisterInfo=resbody.getAsJsonObject("rcsRegisterInfo");
		try {
			String r = "";
			if(task.doretryRMI)
				r = NetUtils.doHttps(uri, resbody, header, "application/json");
			if(!Util.isNull(r))
			{
				JsonObject ro = requestBody2Json(r);
				JsonObject data = ro.getAsJsonObject("data");
				String cspEcNo = Util.getElementAsString(data, "cspEcNo");
				Object[] updateParam = new Object[] { Util.getElementAsString(rcsRegisterInfo, "ecName"), cspEcNo };
				flag=true;
				task.doretryRMI=false;
				try {
					String sqlId = "updatecspecinfo";
					String sql = XmlSqlGenerator.getSql(sqlId).exeSql;
					SqlUtil.updateRecords(ds, sql, updateParam);
					
					sendResponse(BaseHandler.getIpAddress(request), r, 200, request, response);
					try {
						logger(ds, "info", "sucess", "updateCustomerinfo sucess ready request  "+uri+"body "+gson.toJson(body) , r, BaseHandler.getIpAddress(request), request,  "TeleComCspimp.editCspCustomer");
					} catch (IOException e) {
						e.printStackTrace();
					}
					return flag;
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		String resbody1=resBodyJson("200","request will be retried later "+uri,null);
		try {
			sendResponse(BaseHandler.getIpAddress(request), resbody1, 200, request, response);
			
			try {
				logger(ds, "warn", "failed", "updateCustomerinfo failed ready request  "+uri+"body "+gson.toJson(body) , resbody1, BaseHandler.getIpAddress(request), request,  "TeleComCspimp.editCspCustomer");
			} catch (IOException e) {
				e.printStackTrace();
			}
			return flag;
		} catch (IOException e) {
			e.printStackTrace();
		}
		return flag;
	}
	public boolean deleteCustomer(TaskInner task) {
		DataSource ds=task.ds;
		JsonObject body=task.body;
		HttpServletRequest request=task.request; HttpServletResponse response=task.response;
		boolean flag=false;
		LocalDateTime time = LocalDateTime.now(ZoneOffset.of("+8"));
		String uri = LoadProperties.systemProperties.getProperty("csp.cmcc.deleteCustomerUri");
		Map<String, Object> header = headers(accesskey, time);
		header.put("authorization", accessToken);		

		if(task.add2db)
		task.add2db=!deleteCustomer2Db(gson,body,ds);
		try {
			String back="";
			if(task.doretryRMI)
				 back=NetUtils.doHttps(uri, gson.toJson(body), header, "");
			if(!Util.isNull(back))
			{
				
				JsonObject obj=requestBody2Json(back);
				String code=Util.getElementAsString(obj, "code");
				String message=Util.getElementAsString(obj, "message");
				String desc="";
				if("0".equals(code))
				{
					flag=true;
					desc="ɾ���ɹ�";
					task.doretryRMI=false;
				}else if("42001".equals(code)){
					accessToken( ds,  request);
				}
				else
				{
					desc= Util.toString(LoadProperties.systemProperties
							.getOrDefault(code, Util.toString(LoadProperties.systemProperties.get("other"))));
					flag=true;
					task.doretryRMI=false;
				}
				String resbody1=resBodyJson(desc,message,null);
				try {
					sendResponse(BaseHandler.getIpAddress(request), resbody1, 200, request, response);
					try {
						logger(ds, "info", "sucess", "deleteCustomerinfo sucess ready request  "+uri+"body "+gson.toJson(body) , resbody1, BaseHandler.getIpAddress(request), request,  "TeleComCspimp.deleteCspCustomer");
					} catch (IOException e) {
						e.printStackTrace();
					}
					return flag;
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		} catch (IOException e) {
			
			String resbody1=resBodyJson("200","request will be retried later",null);
			try {
				sendResponse(BaseHandler.getIpAddress(request), resbody1, 200, request, response);
				try {
					logger(ds, "warn", "failed", "deleteCustomerinfo failed ready request  "+uri+"body "+gson.toJson(body) , resbody1, BaseHandler.getIpAddress(request), request,  "TeleComCspimp.deleteCspCustomer");
				} catch (IOException e2) {
					e2.printStackTrace();
				}
				return flag;
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}
		return flag;
	}
	
	/**
	 * 1���ϴ�����
	 * operatorType uploadFile
	 * 	1��uploadType���ϴ��������͡��ϴ��������͡�0��Logo ͼƬ 1��Chatbot ����ͼƬ
		2��fileType��   2 chatbot chatbot����
	  2�� ���� Chatbot ��Ϣ  
	  operatorType ChatbotManager
	  ���ݸ�ʽ��
	��� �ֶ� �������� ���� ��ѡ���� ����
1 cspId string 32 M CSP ����
2 cspEcNo string 32 M �ͻ�ʶ����
3 chatbotId string 64 M ChatbotId���������+�Զ�����루ChatbotId һ�����������޸ģ� ��̨���㲻��ǰ�˴�ֵ 
4 serviceName string 128 M Chatbot ��������
5 serviceIcon string 128 M Chatbot logo ·��
6 serviceDescription string 300 M Chatbot ������Ϣ
7 SMSNumber string 64 M Chatbot ���Ŷ˿ں�=chatbotId ��(�������+�Զ������) ��̨���㲻��ǰ�˴�ֵ 
8 autograph string 128 M Chatbot ǩ��
9 category array 64 M Chatbot ���༴��ҵ�����࣬�����ҵ�����ֵ������ǰֻ֧�ֵ�һ��ҵ����
10 provider string 32 M Chatbot �ṩ������ ѡ��ͻ�����
11 showProvider int 4 M �Ƿ���ʾChatbot�ṩ�����ƣ�1����ʾ��0������ʾ
12 TCPage string 255 M Chatbot ��������
13 emailAddress string 50 M Chatbot ����
14 serviceWebsite string 150 M Chatbot ����(��ҳ��ַ)
15 callBackNumber string 21 M Chatbot ����绰
16 address string 200 M Chatbot �칫��ַ
17 longitude double 10 M Chatbot ��������
18 latitude double 10 M Chatbot ����γ��
19 ipWhiteList array 1024 M IP ��ַ������ (��� 15 �� ,�ָ�������
20 useAi �Ƿ�����AI������ 0:������ 1:����
{
 "cspCode":"A100000001",
 "cspEcNo":"A10000000100001",
"chatbotId":"1065988898989", 
"serviceName":"1209API",
"serviceIcon":"http://124.126.120.19:8080/maap_message/bot/chanageUrl/perm/20201205145323/95465/6,0566ad9c2462.jpg",
 "serviceDescription":"dgsdgdsfgdfg",
 "SMSNumber":"1065988898989",
 "autograph":"fddgdgfdg",
 "category":[1,2],
"provider":"XXX ��˾",
"showProvider ":1,
 "TCPage":"https://www.baidu.com/",
 "emailAddress":"XXXX@189.cn",
 "serviceWebsite":"https://www.baidu.com/",
 "callBackNumber":"16619898798",
 "address":"XX �� XX �� XX �ֵ�",
 "longitude":116.20,
 "latitude":39.56,
 "ipWhiteList":["124.126.120.102"]
}
3��chatbot״̬���
 operatorType isOnlineUpdate
 ��� �ֶ� �� �� ���� �� �� ���� �� ѡ ���� ����
1 accessTagNo string 64 M Chatbot �����ɹ��󷵻��ֶ�accessTagNo
2 type int 4 M �����߱�־��1:���ߣ�2:����
{
" accessTagNo": "9bb127ae3a5e43d8baece177564788ca",
" type": 1,
}
4����� Chatbot ��Ϣ 
operatorType ChatbotManager
����������һ�� ��һ��ID Ψһ��ʶ accessTagNo
5������ɾ�� Chatbot
 ��� �ֶ� �� �� ���� �� �� ���� �� ѡ ���� ����
1 accessTagNo string 64 M Chatbot �����ɹ��󷵻��ֶ�accessTagNo
operatorType ChatbotManager
{
" accessTagNo": "9bb127ae3a5e43d8baece177564788ca"
}


	 *
	 */
	public boolean  ChatbotManager(TaskInner task) {
		DataSource ds=task.ds;
		JsonObject body=task.body;
		HttpServletRequest request=task.request; HttpServletResponse response=task.response;
		boolean flag=false;
		LocalDateTime time = LocalDateTime.now(ZoneOffset.of("+8"));
		String uri = LoadProperties.systemProperties.getProperty("csp.cmcc.addChatbotUri");
		Map<String, Object> header = headers(accesskey, time);
		header.put("authorization", accessToken);		
		
		String accessNum=LoadProperties.systemProperties.getProperty("csp.cmcc.accessNumber");
		//TODO HOW TO CREATE CHATBOTID

//		body.remove("showH5menu");
		String latitude=Util.realToString(Util.getElementAsString(body, "latitude"), 7);
		body.addProperty("latitude",latitude);
		String longitude=Util.realToString(Util.getElementAsString(body, "longitude"), 7);
		body.addProperty("longitude",longitude);
		String type=Util.getElementAsString(body, "type");;
		JsonArray array1=new JsonArray();
		String category=Util.getElementAsString(body, "categoryold");;
		
		
		if(Util.isNull(category)) {
		       category=Util.getElementAsString(body, "category");
		       array1.add(category);
		       body.addProperty("categoryold", category);;  
		}else
		{
			array1.add(category);
		}
		   body.add("category", array1);
		
//		body.remove("hasChatbotAccount");
//		body.remove("isp");
		body.addProperty("cspCode", accessNum);
		String ipWhiteList =Util.getElementAsString(body, "ipWhiteListold");
		if(Util.isNull(ipWhiteList))
		{
			ipWhiteList =Util.getElementAsString(body, "ipWhiteList");
			body.addProperty("ipWhiteListold", ipWhiteList);
		}
		 if(!Util.isNull(ipWhiteList))
		 {
			 JsonArray array=new JsonArray();
			array.add(ipWhiteList);
			if(array!=null&&array.isJsonArray())
			{
				body.add("ipWhiteList", array);
			}
		 }
		/*
		 * 
		
		 * */
		
		//֪ͨ���ͣ�1��������2�������3��		ɾ��
		if("1".equals(type))
		{
			String comefrom = body.get("comefrom").getAsString();
			if(comefrom.equals("owner")){
				// TODO reids������������
				int diyNum=new java.util.Random().nextInt(99999);
				String chatbotNum=accessNum+""+diyNum;
				body.addProperty("cspId", cspid);
				body.addProperty("chatbotId", chatbotNum);
				body.addProperty("SMSNumber", chatbotNum);
				body.addProperty("chatbotIdenty", "sip:"+chatbotNum+"@botplatform.rcs.vnet.cn");
			}else {
				String chatbotIdenty = body.get("chatbotIdenty").getAsString();
				String chatbotId = Util.spiltNumbers(chatbotIdenty);
				body.addProperty("cspId", cspid);
				body.addProperty("chatbotId", chatbotId);
				body.addProperty("SMSNumber", chatbotId);
			}
			JsonObject rspbody=body.deepCopy();
			rspbody.addProperty("chatbotName", Util.getElementAsString(body, "serviceName"));
			 uri = LoadProperties.systemProperties.getProperty("csp.cmcc.addChatbotUri");
			 try {
				 String rsp="";
				 if(!comefrom.equals("owner")){
					 try {
						 if(task.doretryRMI)
							 rsp=NetUtils.doHttps(uri, body, header, "application/json");
					 } catch (IOException ioeee) {
						 ioeee.printStackTrace();
					 }
					 
					if(!Util.isNull(rsp))
					{
						
						JsonObject obj=requestBody2Json(rsp);
						String code=Util.getElementAsString(obj, "code");
						if(obj!=null&&!obj.isJsonNull()&&"0".equals(code))
						{
							flag=true;
							task.doretryRMI=false;
							String accessTagNo=Util.getElementDeepAsString(obj, "data","accessTagNo");
							body.addProperty("accessTagNo", accessTagNo);
						}else if("42001".equals(code)){
							accessToken( ds,  request);
						}else
						{
							rsp=resBodyJson("500","addchatbot  request will be retried later", obj);
							flag=true;
							task.add2db=false;
							task.doretryRMI=false;
							//body.addProperty("accessTagNo",new java.util.Random().nextInt());
						}
					}else
					{
						rsp=resBodyJson("200","addchatbot  request will be retried later",body);
						body.addProperty("accessTagNo","YD"+Util.getRandomString(10));
					}
				 }
				
				if(task.add2db) {
				task.add2db=!insertChatBot(gson,body,ds);
				if(comefrom.equals("owner")){
					updateDeveloper(task);
				}else
				{
					body.addProperty("auditStatus", 1);
					body.addProperty("description", "�Զ���� ��������������� ");
					updateChatbotAuditStatus(gson,body,ds);
				}
				}
				try {
					if (!task.add2db)
						rsp=resBodyJson("200","addchatbot success", rspbody);
					sendResponse(BaseHandler.getIpAddress(request), rsp, 200, request, response);
					try {
						logger(ds, "info", "chatbot", "addChatbot request ready request  "+uri+"body "+gson.toJson(body) , rsp, BaseHandler.getIpAddress(request), request,  "TeleComCspimp.addChatbot");
					} catch (IOException e2) {
						e2.printStackTrace();
					}
					 
					return true;
				} catch (IOException e) {
					e.printStackTrace();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}else if("2".equals(type))
		{ 
			uri = LoadProperties.systemProperties.getProperty("csp.cmcc.updateChatbotUri");
			try {
				String requestUpdate="";
				try {
					if(task.doretryRMI)
						requestUpdate=NetUtils.doHttps(uri, body, header, "application/json");
				} catch (IOException ioeee) {
					ioeee.printStackTrace();
				}
				if(Util.isNull(requestUpdate))
				{
					requestUpdate=resBodyJson("200","updatechatbot request will be retried later",null);
				}else
				{
					JsonObject obj=requestBody2Json(requestUpdate);
					if(obj!=null&&!obj.isJsonNull())
					{
						String code=Util.getElementAsString(obj, "code");
						if("0".equals(code)) {
						flag=true;
						task.doretryRMI=false;
						}else
						{
							flag=true;
							task.doretryRMI=false;
							task.add2db=false;
						}
						
					}
				}
				
				if(task.add2db)
				task.add2db=!updateChatBot(gson,body,ds);
				try {
					sendResponse(BaseHandler.getIpAddress(request), requestUpdate, 200, request, response);
					try {
						logger(ds, "info", "chatbot", "UpdateChatbot request ready request  "+uri+"body "+gson.toJson(body) , requestUpdate, BaseHandler.getIpAddress(request), request,  "TeleComCspimp.UpdateChatbot");
					} catch (IOException e2) {
						e2.printStackTrace();
					}
					return flag;
				} catch (IOException e) {
					e.printStackTrace();
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}else if("3".equals(type))
		{
			 uri = LoadProperties.systemProperties.getProperty("csp.cmcc.deleteChatbotUri");
			
			String	requestUpdate="";
			try {
				
				if(task.doretryRMI)
				{
					try {
						requestUpdate = NetUtils.doHttps(uri, body, header, "application/json");
					}catch (IOException ioe){
						ioe.printStackTrace();
					}
				}
				if(Util.isNull(requestUpdate))
				{
					requestUpdate=resBodyJson("200","deletechatbot request will be retried later",null);
				}else
				{
					JsonObject obj=requestBody2Json(requestUpdate);
					if(obj!=null&&!obj.isJsonNull())
					{
						String code=Util.getElementAsString(obj, "code");
						if("0".equals(code)) {
							flag=true;
							task.doretryRMI=false;
						}else if("42001".equals(code)){
							accessToken( ds,  request);
						}else
						{
							flag=true;
							task.doretryRMI=false;
						}
						
					}
				}
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			if(task.add2db)
			task.add2db=!deleteChatbot(gson,body,ds);
			try {
				sendResponse(BaseHandler.getIpAddress(request), requestUpdate, 200, request, response);
				try {
					logger(ds, "info", "chatbot", "deleteChatbot request ready request  "+uri+"body "+gson.toJson(body) , requestUpdate, BaseHandler.getIpAddress(request), request,  "TeleComCspimp.deleteChatbot");
				} catch (IOException e2) {
					e2.printStackTrace();
				}
				return flag;
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return flag;
//		String resbody1=resBodyJson(desc,message,null);
//		try {
//			sendResponse(BaseHandler.getIpAddress(request), resbody1, 200, request, response);
//			return ;
//		} catch (IOException e) {
//			e.printStackTrace();
//		}
	}
	public boolean  isOnlineUpdate(TaskInner task) {
		DataSource ds=task.ds;
		JsonObject oldbody=task.body;
		JsonObject body=new JsonObject();
		body.addProperty("accessTagNo", Util.getElementAsString(oldbody, "accessTagNo"));
		body.addProperty("type", Util.getElementAsString(oldbody, "enable","1"));
		HttpServletRequest request=task.request; HttpServletResponse response=task.response;
		boolean flag=false;
		LocalDateTime time = LocalDateTime.now(ZoneOffset.of("+8"));
		String uri = LoadProperties.systemProperties.getProperty("csp.cmcc.isOnlineUpdateUri");
		Map<String, Object> header = headers(accesskey, time);
		header.put("authorization", accessToken);	
		try {
			String	rsp = "";
			if(task.doretryRMI)
				rsp = NetUtils.doHttps(uri, body, header, " application/json");
			if(task.add2db)
			task.add2db=!deleteChatbot(gson,body,ds);
			String resbody1=rsp;
			if(!Util.isNull(rsp))
			{
//				resbody1=rsp;
					JsonObject obj=requestBody2Json(rsp);
					if(obj!=null&&!obj.isJsonNull())
					{
						String code=Util.getElementAsString(obj, "code");
						if("0".equals(code)) {
							flag=true;
							task.doretryRMI=false;
							resbody1=resBodyJson("200",rsp,null);
						}else if("42001".equals(code)){
							accessToken( ds,  request);
						}else
						{
							flag=true;
							task.doretryRMI=false;
						}
						
					}
				 
			}else
			{
				 resbody1=resBodyJson("500","server request failed",null);
			}
			try {
				sendResponse(BaseHandler.getIpAddress(request), resbody1, 200, request, response);
				try {
					logger(ds, "info", "chatbot", "offlineChatbot request ready request  "+uri+"body "+gson.toJson(body) , resbody1, BaseHandler.getIpAddress(request), request,  "TeleComCspimp.offlineChatbot");
				} catch (IOException e2) {
					e2.printStackTrace();
				}
				return flag;
			} catch (IOException e) {
				e.printStackTrace();
			}
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return flag;
		
	}
	/**
	 *���������� 
	 *operatorType updateDeveloper
	 *	��� �ֶ� �������� ���� ��ѡ���� ����
1 agreement string 25 C Э�� 1:http��2:https
2 token string 128 C ������ token����� 16 λ ��Ϊ��
3 url string 150 C �ص� URL ��ַ��Ŀ¼ �� http://��ͷ��IP+�˿ڵ���ʽ����������������Ϣ״̬�����Լ���Ϣ֪ͨ  ��Ϊ��
4 accessTagNo string 64 M ���� Chatbot ʱ,���ص� Chatbot ��Ψһʶ���ʶ  ѡ��chatbot
5 enable int 4 M Chatbot �ӿ��Ƿ����ã�1:���ã�0:������
{
 "accessTagNo":"9bb127ae3a5e43d8baece177564788ca",
 "agreement":"1",
 "token":"wfXbHLeIqKCkJJSI",
 "url":"http://127.0.0.1",
 "enable":1
}
	 */
	public boolean updateDeveloper(TaskInner task) {
		DataSource ds=task.ds;
		JsonObject body=task.body;
		JsonObject updateDeveloperBody=new JsonObject();
		String token=LoadProperties.systemProperties.getProperty("csp.cmcc.token");
		String agreement=Util.getElementAsString(body, "agreement");
		if("1".equals(agreement))
			agreement="http";
		else
			agreement="https";
		String accessTagNo=Util.getElementAsString(body, "accessTagNo");
		updateDeveloperBody.addProperty("agreement", agreement);
		updateDeveloperBody.addProperty("token", token);
		updateDeveloperBody.addProperty("url", agreement+"://"+Util.getElementAsString(body, "msgNotifyUrl"));
		updateDeveloperBody.addProperty("accessTagNo", accessTagNo);
		updateDeveloperBody.addProperty("enable", Util.getElementAsString(body, "enable"));
		
		HttpServletRequest request=task.request; HttpServletResponse response=task.response;
		LocalDateTime time = LocalDateTime.now(ZoneOffset.of("+8"));
		String uri = LoadProperties.systemProperties.getProperty("csp.cmcc.updateDeveloperUri");
		Map<String, Object> header = headers(accesskey, time);
		header.put("authorization", accessToken);	
		boolean flag=false;
		updateDeveloperBody.addProperty("token", token);
		try {
			String resbody1="";
			if(task.doretryRMI)
				resbody1= NetUtils.doHttps(uri, updateDeveloperBody, header, " application/json");
			if(!Util.isNull(resbody1))
			{
				JsonObject resObject=requestBody2Json(resbody1);
				String code=Util.getElementAsString(resObject, "code");
				if("0".equals(code)) {
				flag=true;
				task.doretryRMI=false;
				resObject.getAsJsonObject("data").addProperty("accessTagNo", accessTagNo);
				updateDeveloper(gson,resObject,ds);
				isOnlineUpdate(task);
				}else if("42001".equals(code)){
					accessToken( ds,  request);
				}else
				{
					flag=true;
					task.doretryRMI=false;
				}
			}else
			{
				 resbody1=resBodyJson("500","deleloper server request failed",null);
			}
			try {
				//TODO 
//				sendResponse(BaseHandler.getIpAddress(request), resbody1, 200, request, response);
				try {
					logger(ds, "info", "developer", "chatbot developer request ready request  "+uri +"body "+gson.toJson(body) , resbody1, BaseHandler.getIpAddress(request), request,  "TeleComCspimp.developer");
				} catch (IOException e2) {
					e2.printStackTrace();
				}
				return flag;
			} catch (Exception e) {
				e.printStackTrace();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return flag;
	}


	@Override
	public String selectCspCustomer(TaskInner task) {
		DataSource ds=task.ds;
		JsonObject body=task.body;
		HttpServletRequest request=task.request; HttpServletResponse response=task.response;
		LocalDateTime time = LocalDateTime.now(ZoneOffset.of("+8"));
		String uri = LoadProperties.systemProperties.getProperty("csp.cmcc.selectCspCustomerUri");
		Map<String, Object> header = headers(accesskey, time);
		header.put("authorization", accessToken);
		body.addProperty("token", LoadProperties.systemProperties.getProperty("csp.cmcc.token"));
		try {
			String resbody1="";
			if(task.doretryRMI)
				resbody1= NetUtils.doHttps(uri, body, header, " application/json");
			if(!Util.isNull(resbody1))
			{
				JsonObject resObject=requestBody2Json(resbody1);
				String code=Util.getElementAsString(resObject, "code");
				if("0".equals(code)) {
				task.doretryRMI=false;
				return resbody1;
				}else if("42001".equals(code)){
					accessToken( ds,  request);
				}else
				{
					task.doretryRMI=false;
				}
			}else
			{
				 resbody1=resBodyJson("500","QueryCustomer   request failed",null);
			}
			try {
				sendResponse(BaseHandler.getIpAddress(request), resbody1, 200, request, response);
				try {
					logger(ds, "info", "selectCspCustomer", "chatbot developer request ready request  "+uri +"body "+gson.toJson(body) , resbody1, BaseHandler.getIpAddress(request), request,  "TeleComCspimp.selectCspCustomer");
				} catch (IOException e2) {
					e2.printStackTrace();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
			return "";
		} catch (IOException e) {
			e.printStackTrace();
		}
		return "";
	}


	@Override
	public JsonObject reBuildCustomers(JsonObject body) {
		JsonObject rcsRegisterInfo = body.getAsJsonObject("rcsRegisterInfo");
		JsonObject rcsInfo = body.getAsJsonObject("rcsInfo");
		JsonObject rcsContractInformation = body.getAsJsonObject("rcsContractInformation");
		JsonObject rcsLegalP = body.getAsJsonObject("rcsLegalP");
	
		rcsInfo.remove("operatorarea");
		rcsInfo.remove("operatorsex");
		rcsInfo.remove("contractNo");
		rcsInfo.remove("operatoripfrom");
		rcsInfo.remove("legalUserId");
		rcsInfo.remove("operatorUserId");
		JsonArray array = new JsonArray();
		array.add(Util.getElementAsString(rcsInfo, "operatorIdentityPic1"));
		array.add(Util.getElementAsString(rcsInfo, "operatorIdentityPic2"));

		rcsInfo.add("operatorIdentityPic", array);

		rcsInfo.remove("operatorIdentityPic1");
		rcsInfo.remove("operatorIdentityPic2");


		JsonObject resbody = new JsonObject();
		resbody.add("rcsRegisterInfo", rcsRegisterInfo);
		resbody.add("rcsInfo", rcsInfo);
		resbody.add("rcsContractInformation", rcsContractInformation);
		rcsLegalP.remove("operatorPhone");
		rcsLegalP.remove("operatorIdentityPic1");
		rcsLegalP.remove("operatorIdentityPic2");
		resbody.add("rcsLegalP", rcsLegalP);
		return resbody;
	}

	public boolean selOperationLog(TaskInner task) {
		try {
			task.doretryRMI = Boolean.FALSE;
			OperationLogService operation = Provider.injector.getInstance(OperationLogService.class);
			String authorization = task.request.getHeader("Authorization").replaceAll("\"", "");
			String cspEcNo = task.body.get("cspEcNo").getAsString();
			JsonArray array = operation.selOperationLog(authorization, cspEcNo);
			String send=resBodyJson("200","sucess",array);
			sendResponse(BaseHandler.getIpAddress(task.request), send, 200, task.request, task.response);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return Boolean.FALSE;
	}
}
