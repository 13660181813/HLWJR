package org.ydzy.bot.model;

public class MenuItem extends MenuBase{
	public MenuItem(int menuid, int parentid) {
		super(menuid, parentid);
	}

	public MenuItem(int menuid) {
		super(menuid);
	}

	/** ���� */
	public String suggestiontype;
	
	/** id */
	public int suggestionid;

	/** ���� */
	public transient String suggestions;

}
