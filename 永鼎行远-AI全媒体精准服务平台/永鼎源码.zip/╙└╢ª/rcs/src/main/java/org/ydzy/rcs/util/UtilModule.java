package org.ydzy.rcs.util;

import java.util.HashSet;
import java.util.Set;

import org.ydzy.rcs.annotation.Description;

import com.google.inject.Binder;
import com.google.inject.Key;
import com.google.inject.Module;
import com.google.inject.Scopes;
import com.google.inject.name.Names;

/** ��ע�� */
@Description("UtilModule")
public class UtilModule implements Module {
	private static Set<Binder> binded = new HashSet<>();
	
	@Override
	public void configure(Binder binder) {
		synchronized(binded) {
			if(!binded.contains(binder)) {
				binded.add(binder);
				binder.bind(IShortUrl.class).to(ShortUrlBjydzy.class).in(Scopes.SINGLETON);
				binder.bind(TravelRecordManager.class).in(Scopes.SINGLETON);
				binder.bind(Key.get(ISms.class, Names.named(YdxySms.KEY_NAME))).to(YdxySms.class).in(Scopes.SINGLETON);
				binder.bind(Key.get(ISms.class, Names.named(GzgatSms.KEY_NAME))).to(GzgatSms.class).in(Scopes.SINGLETON);
			}
		}
	}
}
