package org.ydzy.bot.handler;
import java.io.IOException;
import java.io.Reader;
import java.nio.charset.Charset;
import java.time.Instant;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalQuery;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;

import javax.sql.DataSource;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;
import org.eclipse.jetty.server.Request;
import org.ydzy.bot.BotInfo;
import org.ydzy.bot.BotManager;
import org.ydzy.handler.BaseHandler;
import org.ydzy.rcs.action.RcsLogAction;
import org.ydzy.rcs.media.UploadFileEntity;
import org.ydzy.util.StreamsUtil;
import org.ydzy.util.Util;

import com.google.gson.JsonObject;
import com.google.inject.Inject;
import com.google.inject.name.Named;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
  * �й��ƶ�MAAP�ӿ�
  *  4.2	ý�����֪ͨ
HTTPS��POST
URL��https://{notifyURL}/InboundMessageNotification/{ChatbotURI}
  */
public  class MediaNotificationHandler extends BaseBotHandler {
	private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(MediaNotificationHandler.class);

	@Inject
	@Named("rcsDb")
	protected DataSource ds;
	
	@Inject(optional=true)
	protected RcsLogAction rcsLogAction = null;
	

	@Override
	public void handle(String target, Request baseRequest, HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException{
		baseRequest.setHandled(true);
		BotInfo bi = null;
		try {
			bi = verifyChatbot(request, response);
		}catch(VerifyError e) { 
			response.setStatus(HttpServletResponse.SC_FORBIDDEN);
			response.setContentType("application/json");
			JsonObject jo = new JsonObject();
			jo.addProperty("errorMsg", e.getMessage());
			// Write back response
			response.getWriter().println(jo.toString());
			log.debug("Sinagure error(" + e.getMessage() + "!");
			return;
		}
		long start = System.currentTimeMillis();
		String address=BaseHandler.getIpAddress(request);
		// Content-Type: text/xml; charset=utf-8
		String contentType = request.getContentType();
		String body = StreamsUtil.copyToString(request.getInputStream(), Charset.forName("UTF-8"));
		if(log.isDebugEnabled())log.debug(",receive {} from remoteAddr {}  ", body, address);
		if(contentType==null)contentType="text/xml";
		
		String code = null,msg = null;
		String tid = request.getHeader("tid");
		String status = request.getHeader("Authstatus");
		if(tid==null || tid.isEmpty()) {
			code = "2003";
			msg = "No tid header found";
		}else {
			try {
				UploadFileEntity media = new UploadFileEntity(null, null);
				media.setTid(tid);
				bi.getDbOper().loadMedia(media);
				if(media.getMediaID()==null || media.getMediaID().isEmpty()) {
					code = "2000";
					msg = "Can not found media by tid(" + tid + ")";
				}else {
					if("1".equals(status)) {
						//0ý�����ͨ�� 1ý����˾ܾ�
						media.setAuthStatus("1");
						media.setStatus("3");
						String errCode = media.getErrorCode();
						if(!Util.isNull(errCode))errCode += "|" + "1";
						String errDesc = media.getErrorDesc();
						if(!Util.isNull(errDesc))errDesc += "|" + "ý����˾ܾ�";
						media.setErrorCode(errCode);
						media.setErrorDesc(errDesc);
						bi.getDbOper().saveMedia(bi, media);
					}else if(contentType.startsWith("text/xml")) {
						MediaResponseFile mediafiles = dealMedia(request, response, body, tid);
						if(mediafiles!=null && mediafiles.files!=null && mediafiles.files.size()>0) {
							if(this.convert2Media(mediafiles, media)){
								//0ý�����ͨ�� 1ý����˾ܾ�
								media.setAuthStatus("0");
								media.setStatus("3");
								String errCode = media.getErrorCode();
								if(!Util.isNull(errCode))errCode += "|" + "0";
								String errDesc = media.getErrorDesc();
								if(!Util.isNull(errDesc))errDesc += "|" + "success";
								media.setErrorCode(errCode);
								media.setErrorDesc(errDesc);
								bi.getDbOper().saveMedia(bi, media);
							}
						}else {
							code = "2001";
							msg = "No file info  found";
						}
					}else {
						code = "2002";
						msg = "Unknow contentType:" + contentType;
					}
					CompletableFuture<UploadFileEntity> future = manager.getMediaUploadFuture().remove(media.getMediaID());
					if(future!=null)future.complete(media);
				}
			}catch(Exception e) {
				log.warn("run media notify error", e);
			}
		}
		boolean succ = code==null;
		if(succ) {
			code = "0";
			msg = "success";
		}
		String resBody = resBodyJson(code, msg, null);
		JsonObject object = new JsonObject();
		JsonObject je = new JsonObject();
		object.add("receive5GMsg",je);
		je.addProperty("mdn", tid);
		je.addProperty("chatBotId", bi.getChatbotIdenty());
		sendResponse(address, resBody, HttpServletResponse.SC_OK, request, response);
		if(rcsLogAction!=null && object!=null) {
			rcsLogAction.log(request, response, body, object, resBody, (int)(System.currentTimeMillis() - start), succ, "media");
		}
	}

	private boolean convert2Media(MediaResponseFile mediafiles, UploadFileEntity media) {
		if(mediafiles==null || mediafiles.files==null)return false;
		boolean flag = false;
		for(FileInfo fi:mediafiles.files) {
			long expire = Long.MAX_VALUE;
			if("file".equalsIgnoreCase(fi.type)) {
				if(fi.data!=null && fi.data.url!=null) {
					media.setChatbotMediaUrl(fi.data.url);
					media.setFileSize(fi.fileSize);
					media.setMediacontentType(fi.contentType);
					if(fi.data.until>0 && fi.data.until<expire) expire = fi.data.until;
					flag = true;
				}
			}else if("thumbnail".equalsIgnoreCase(fi.type)) {
				if(fi.data!=null && fi.data.url!=null) {
					media.setChatbotThumbnailUrl(fi.data.url);
					media.setThumbFileSize(fi.fileSize);
					media.setThumbnailContentType(fi.contentType);
					if(fi.data.until>0 && fi.data.until<expire) expire = fi.data.until;
					flag = true;
				}
			}
			if(expire<Long.MAX_VALUE)media.setExpiredTime(expire);
		}
		return flag;
	}
	
	private MediaResponseFile dealMedia(HttpServletRequest request, HttpServletResponse response, String body, String tid) {
		MediaResponseFile mediafiles;
		//mediafiles = XmlUtils.unmarshal(body, MediaResponseFile.class);
		mediafiles = new MediaResponseFile();
				
        SAXReader reader = new SAXReader();
        Document doc = null;
        //InputStream is = null;
        Reader in = null;
        try {
            //is = request.getInputStream();
            in = new java.io.StringReader(body);
            doc = reader.read(in);
            Element root = doc.getRootElement();
            
           
            List<?> files = root.elements("file-info");
            List<FileInfo> tFiles = new ArrayList<>();
            if(files!=null)for(Object ofile:files) {
            	if(ofile instanceof Element) {
            		Element eFile = (Element)ofile;
            		FileInfo tFile = new FileInfo();
            		tFile.type = eFile.attributeValue("type");
            		tFile.contentType = eFile.elementText("content-type");
            		String tmp = eFile.elementText("file-size");
            		tFile.fileSize = Integer.parseInt(tmp);
            		
            		Element eData = eFile.element("data");
            		if(eData!=null) {
            			Data tData = new Data();
            			tData.url = eData.attributeValue("url");
            			String until = eData.attributeValue("until");
						if(until!=null&&!until.isEmpty()) {
							//LocalDateTime untilDate = null;//DateTimeFormatter.ISO_INSTANT.parse(until, In::from);
							TemporalQuery<Instant> tQuery = Instant::from;
							Instant ins = DateTimeFormatter.ISO_INSTANT.parse(until, tQuery);
							tData.until = ins.toEpochMilli();// ins.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli();
						}else {
							tData.until = Integer.MAX_VALUE;
						}
						tFile.data = tData;
            		}
            		tFiles.add(tFile);
            	}
            }
            mediafiles.files = tFiles;
           
        } catch (Exception e) {
            log.warn("parse xml error", e);
        }
		return mediafiles;
	}
	
	@XmlRootElement(name="file")
	static class MediaResponseFile{
		public List<FileInfo> files;
	}

	@XmlRootElement(name="file-info" )
	static class FileInfo{
		@XmlAttribute
		public String type;
		
		@XmlElement(name = "file-size")
		public int fileSize;
		@XmlElement(name = "content-type")
		public String contentType;
		
		public Data data;
	}
	
	
	//url = "[HTTP URL for the file]" until = "[validity of the file]"/>
	static class Data{
		@XmlAttribute
		public String url;
		@XmlAttribute
		public long until;
	}
}