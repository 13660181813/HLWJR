package org.ydzy.rcs.util;

import java.util.Map;

import org.ydzy.rcs.Provider;
import org.ydzy.rcs.notify.NotifyThridParyBaseAbstract;
import org.ydzy.thirdparty.util.MsgUtils;
import org.ydzy.util.Util;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonSyntaxException;
import com.google.inject.Inject;
import com.google.inject.Singleton;

@Singleton
public class NotifyThirdPartyPostData {
	private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(NotifyThirdPartyPostData.class);
  @Inject
  MsgUtils msgUtils;
  
  
  
  public void postData2ThirdParty(String eventType,String userName, JsonObject body, Map<String, Object> headers, String contentType)
  {
	 try {
		 JsonObject plat= msgUtils.platConfig(userName);
		 /*
		  {
"envokeClass:"OrderInfoUpdate",
"url":"",
"errorRetry":4,
"msgContent":"error msg"
"operation":"17090085992"
}
		  * 
		  * */
		 String subscribeDataUrl=Util.getElementAsString(plat, "subscribeDataUrl");
		 if(Util.isNull(subscribeDataUrl)) {
			 log.error("post data failed  username {} postDataUrl is null",userName);
			 return ;
		 }
		 JsonObject subscribeObject =JsonParser.parseString(subscribeDataUrl).getAsJsonObject();
		 JsonArray subClient=subscribeObject.getAsJsonArray(eventType);
		 if(subClient!=null && !subClient.isJsonNull())
		 {
			 for(int i =0;i<subClient.size();i++)
			 {
				 JsonObject party = subClient.get(i).getAsJsonObject();
				 String envokeClass = Util.getElementAsString(party, "envokeClass");
				 NotifyThridParyBaseAbstract third = null;
				 if (!Util.isNull(envokeClass))
					 third = Provider.getInstance(NotifyThridParyBaseAbstract.class, envokeClass);
				 if (third == null) {
					 envokeClass = "basePostNotify";
					 third = Provider.getInstance(NotifyThridParyBaseAbstract.class, envokeClass);
				 }
				 JsonObject postData = third.beforePostAction(body.deepCopy());

				 for (String key : plat.keySet()) {
					 if (!body.has(key) && !"subscribeDataUrl".equals(key))
						 body.add(key, plat.get(key));
				 }
				 for (String key : party.keySet()) {
					 if (!body.has(key))
						 body.add(key, party.get(key));
				 }
				 third.doPostAction(postData,body, plat, userName,contentType);
			 }
		 }
	} catch (JsonSyntaxException e) {
		e.printStackTrace();
	}
  }
 
  
}
