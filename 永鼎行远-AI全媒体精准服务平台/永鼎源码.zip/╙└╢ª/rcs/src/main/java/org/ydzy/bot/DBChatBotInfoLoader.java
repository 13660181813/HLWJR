package org.ydzy.bot;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.sql.DataSource;

import org.ydzy.rcs.db.DbType;
import org.ydzy.rcs.db.XmlSqlGenerator;
import org.ydzy.util.Util;

import com.google.gson.JsonObject;
import com.google.inject.Inject;
import com.google.inject.Provider;
import com.google.inject.Singleton;
import com.google.inject.name.Named;


@Singleton
class DBChatBotInfoLoader implements Provider<List<BotInfo>>{
	static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(DBChatBotInfoLoader.class);
	
	private DataSource dataSource = null;
	private String dbTypestr;
	@Inject
	public DBChatBotInfoLoader(@Named("rcsDb")DataSource dataSource, @Named("rcsDb.DbType") String dbTypestr) {
		super();
		this.dataSource = dataSource;
		this.dbTypestr = dbTypestr;
	}

	public List<BotInfo> load() {
		if(dataSource==null)
			return null;
		String sql;
		DbType dbType=DbType.valueof(dbTypestr);
		XmlSqlGenerator.init(dbType.desc, "sqls/current");
		sql=XmlSqlGenerator.getSql("selectBotInfo").exeSql;
		log.info("load config from {} sql \r\n {} ",this.dbTypestr,sql);
		if(Util.isNull(sql))
		{
			log.error("botinfo load failed ! sql is null");
			return null;
		}
		try(Connection con = dataSource.getConnection();
				Statement stat = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY)){
				ResultSet rs=stat.executeQuery(sql);
				ResultSetMetaData rsmd = rs.getMetaData();
				int numberOfColumns = rsmd.getColumnCount();
				Set<String> columnnames=new HashSet<String>();
				
				for(int i=1;i<=numberOfColumns;i++)
				{
					columnnames.add(rsmd.getColumnLabel(i));
				}
				
				List<String> fields = null;
				List<BotInfo> list = new ArrayList<>();
				while(rs.next()){
					String chatbotid=rs.getString("chatbotid");
					String appid=rs.getString("appid");
					String appkey=rs.getString("appkey");
					JsonObject jo = new JsonObject();
					if(fields==null) {
						fields = new ArrayList<>();
						if(rs.getMetaData()!=null) {
							for(int i=0;i<rs.getMetaData().getColumnCount();i++) {
								fields.add(rs.getMetaData().getColumnName(i));
							}
						}
					}
					for(String fName:fields) {
						jo.addProperty(fName, rs.getString(fName));
					}
					String token = null;
					if(fields.contains("token")) {
						token = rs.getString("token");
					}

					BotInfo bi = new BotInfo(chatbotid, appid, appkey, token, jo);
					list.add(bi);
				}
				return list;
			}catch(SQLException e) {
				log.error("query,%s", sql,e );
			}
	
		return null;
	}



	@Override
	public List<BotInfo> get() {
		return load();
	}
	
	
}
