package org.ydzy.util.crypto;

import org.apache.commons.codec.binary.Base64;

import javax.crypto.Cipher;
import java.nio.charset.Charset;

/**
 * ʹ��Cipher���м���
 */
public abstract class CipherEencryptImp<E extends Enum<?>> implements ICipherEncrypt<E> {
    /**
     * ������ʧ��, �׳����쳣��Ϣ
     */
    protected static final String encryptException = "Encrypt Error!";
    /**
     * ������ʧ��, �׳����쳣��Ϣ
     */
    protected static final String decryptException = "Decrypt Error!";
    /**
     * �����ļ����õ���Կ
     */
    protected String configSlat = null;
    /**
     * �����ļ����õ�����
     */
    protected String configVectorKey = null;
    /**
     * Ĭ�ϼ���ģʽ
     */
    protected E defaultAlgorithm = null;

    /**
     * ����, ��ֱ�ӽ����ؽ��תΪString����, Ϊ����, ����תΪBase64��תΪ16����
     *
     * @param content     ��������
     * @param slatKey     ������Կ
     * @param vectorKey   ��������
     * @param encryptType ����ģʽ
     * @return ����(byte[])
     * @throws Exception
     */
    protected abstract byte[] encrypt(String content, String slatKey, String vectorKey, E encryptType) throws Exception;

    /**
     * ����
     *
     * @param content     ��������
     * @param slatKey     ������Կ
     * @param vectorKey   ��������
     * @param encryptType ����ģʽ
     * @return ��������(String)
     * @throws Exception
     */
    protected abstract String decrypt(byte[] content, String slatKey, String vectorKey, E encryptType) throws Exception;

    protected static byte[] handleNoPaddingEncryptFormat(Cipher cipher, String content) throws Exception {
        return handleNoPaddingEncryptFormat(cipher, content, Charset.defaultCharset());
    }

    /**
     * <p>NoPadding����ģʽ, �������ݱ����� 8byte�ı���, ����8λ��ĩλ����0</p>
     * <p>�����㷨���ṩ�ò��뷽ʽ, ��Ҫ������ɸò��뷽ʽ</p>
     *
     * @param cipher
     * @param content ��������
     * @return ���ϼ��ܵ�����(byte[])
     * @Param charset ָ�����ַ���
     */
    protected static byte[] handleNoPaddingEncryptFormat(Cipher cipher, String content, Charset charset) throws Exception {
        int blockSize = cipher.getBlockSize();
        byte[] srawt = content.getBytes(charset);
        int plaintextLength = srawt.length;
        if (plaintextLength % blockSize != 0) {
            plaintextLength = plaintextLength + (blockSize - plaintextLength % blockSize);
        }
        byte[] plaintext = new byte[plaintextLength];
        System.arraycopy(srawt, 0, plaintext, 0, srawt.length);
        return plaintext;
    }

    @Override
    public String encryptBase64(String content) throws Exception {
        return encryptBase64(content, configSlat, configVectorKey, defaultAlgorithm);
    }

    @Override
    public String decryptBase64(String content) throws Exception {
        return decryptBase64(content, configSlat, configVectorKey, defaultAlgorithm);
    }

    @Override
    public String encryptBase64(String content, String slatKey, String vectorKey) throws Exception {
        return encryptBase64(content, slatKey, vectorKey, defaultAlgorithm);
    }

    @Override
    public String decryptBase64(String content, String slatKey, String vectorKey) throws Exception {
        return decryptBase64(content, slatKey, vectorKey, defaultAlgorithm);
    }

    @Override
    public String encryptBase64(String content, E encryptType) throws Exception {
        return encryptBase64(content, configSlat, configVectorKey, encryptType);
    }

    @Override
    public String decryptBase64(String content, E encryptType) throws Exception {
        return decryptBase64(content, configSlat, configVectorKey, encryptType);
    }

    @Override
    public String encryptBase64(String content, String slatKey, String vectorKey, E encryptType) throws Exception {
        byte[] result = encrypt(content, slatKey, vectorKey, encryptType);
        return Base64.encodeBase64String(result);
    }

    @Override
    public String decryptBase64(String content, String slatKey, String vectorKey, E encryptType) throws Exception {
        byte[] byteContent = Base64.decodeBase64(content);
        return decrypt(byteContent, slatKey, vectorKey, encryptType);
    }

    @Override
    public String encryptHex(String content) throws Exception {
        return encryptHex(content, configSlat, configVectorKey, defaultAlgorithm);
    }

    @Override
    public String decryptHex(String content) throws Exception {
        return decryptHex(content, configSlat, configVectorKey, defaultAlgorithm);
    }

    @Override
    public String encryptHex(String content, String slatKey, String vectorKey) throws Exception {
        return encryptHex(content, slatKey, vectorKey, defaultAlgorithm);
    }

    @Override
    public String decryptHex(String content, String slatKey, String vectorKey) throws Exception {
        return decryptHex(content, slatKey, vectorKey, defaultAlgorithm);
    }

    @Override
    public String encryptHex(String content, E encryptType) throws Exception {
        return encryptHex(content, configSlat, configVectorKey, encryptType);
    }

    @Override
    public String decryptHex(String content, E encryptType) throws Exception {
        return decryptHex(content, configSlat, configVectorKey, encryptType);
    }

    @Override
    public String encryptHex(String content, String slatKey, String vectorKey, E encryptType) throws Exception {
        byte[] result = encrypt(content, slatKey, vectorKey, encryptType);
        return HexUtil.byteArrayToHexStr(result);
    }

    @Override
    public String decryptHex(String content, String slatKey, String vectorKey, E encryptType) throws Exception {
        byte[] byteContent = HexUtil.hexStrToByteArray(content);
        return decrypt(byteContent, slatKey, vectorKey, encryptType);
    }
}
