package org.ydzy.bot;

import jakarta.servlet.http.HttpServletRequest;
import org.bouncycastle.crypto.parsers.ECIESPublicKeyParser;
import org.ydzy.handler.RcsSession;
import org.ydzy.rcs.BodyTransform;
import org.ydzy.rcs.entity.ReceiveEntity;
import org.ydzy.util.Util;
import org.ydzy.util.crypto.AesUtil;
import org.ydzy.util.crypto.ICipherEncrypt;

import java.util.HashMap;
import java.util.Map;

/**
 * ���麽���û���¼��Ϣ��װ��
 *
 * @author zxw
 * @create 2021/11/29
 */
public class LoginJXHK implements ILogin {
    /**
     * bean������bean��bean��
     */
    public static String KEY_LOGIN_BEAN_NAME = ILogin.BEAN_INSTANCE_KEY_PREFIX + "hk_jixiang";
    public static String encrypt_key = "nj66E9lxMI8nnk+9";

    @Override
    public Map<String, Object> login(BodyTransform bodyTransform, HttpServletRequest request) {
        //��װ���麽�յ�¼��Ϣ
        if (bodyTransform == null) {
            return null;
        }
        ReceiveEntity receiveEntity = bodyTransform.receiveEntity;
        String mdn = receiveEntity.getMdn();
        Map<String, Object> userInfo = new HashMap<>();
        if (!Util.isNull(mdn)) {
            ICipherEncrypt cipher = new AesUtil(AesUtil.AESEnum.CBC_PKCS5PADDING);
            try {
                String encryptMdn = cipher.encryptBase64(mdn, encrypt_key, encrypt_key);
                userInfo.put("mobile", encryptMdn);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return userInfo;
    }

    @Override
    public Map<String, Object> login(RcsSession session, HttpServletRequest request) {
        Map<String, Object> userInfo = new HashMap<>();
        if (session == null) {
            return userInfo;
        }

        String mdn = (String) session.get("mdn");
        if (!Util.isNull(mdn)) {
            ICipherEncrypt cipher = new AesUtil(AesUtil.AESEnum.CBC_PKCS5PADDING);
            try {
                String encryptMdn = cipher.encryptBase64(mdn, encrypt_key, encrypt_key);
                userInfo.put("mobile", encryptMdn);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return userInfo;
    }
}
