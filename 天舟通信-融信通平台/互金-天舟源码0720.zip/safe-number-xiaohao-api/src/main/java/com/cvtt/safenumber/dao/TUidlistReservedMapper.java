package com.cvtt.safenumber.dao;

import com.cvtt.safenumber.pojo.*;

import java.util.Date;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface TUidlistReservedMapper {
    /**
     * 批量写入
     * @param records
     * @param state
     * @return
     */
    int insertBatch(@Param("list") List<TReginfo> records, @Param("state") int state, @Param("reusetime") Date reusetime);
    int insertDBatch(@Param("list") List<TReginfo1> records, @Param("state") int state, @Param("reusetime") Date reusetime);

    /**
     * 从T_REGINFO表批量导入到T_UIDLIST_RESERVED表
     * @param batchWorkId
     * @param state
     * @return
     */
    int insertFromReginfo(@Param("batchworkid") String batchWorkId, @Param("state") int state, @Param("reusetime") Date reusetime);

    long countByExample(TUidlistReservedExample example);

    int deleteByExample(TUidlistReservedExample example);

    int insert(TUidlistReserved record);

    int insertSelective(TUidlistReserved record);

    List<TUidlistReserved> selectByExample(TUidlistReservedExample example);

    int updateByExampleSelective(@Param("record") TUidlistReserved record, @Param("example") TUidlistReservedExample example);

    int updateByExample(@Param("record") TUidlistReserved record, @Param("example") TUidlistReservedExample example);

    List<TReginfoSimple> selectByExampleSimple(TUidlistReservedExample example);
}