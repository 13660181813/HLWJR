/**
 * 关系数据相关接口(绑定，解绑，延期)
 */
package com.cvtt.safenumber.controller.dianhui;

import com.alibaba.fastjson.JSONObject;
import com.cvtt.safenumber.constents.Regex;
import com.cvtt.safenumber.dao.TReginfoMapper;
import com.cvtt.safenumber.dao.TRegnumSourceMapper;
import com.cvtt.safenumber.dao.TUnitMapper;
import com.cvtt.safenumber.pojo.TReginfo;
import com.cvtt.safenumber.pojo.TReginfo1;
import com.cvtt.safenumber.pojo.TReginfoExample;
import com.cvtt.safenumber.pojo.TRegnumSource;
import com.cvtt.safenumber.pojo.TUnit;
import com.cvtt.safenumber.service.IReginfoService;
import com.cvtt.safenumber.service.IUnitService;
import com.cvtt.safenumber.service.dianhui.IDianhuiBindService;
import com.cvtt.safenumber.utils.OKHttpClientUtil;
import com.cvtt.safenumber.utils.ResponseUtils;
import com.cvtt.safenumber.utils.SignUtils;
import com.cvtt.safenumber.vo.xz.DmDataBindVo;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.UUID;

import static com.cvtt.safenumber.utils.OKHttpClientUtil.httpJsonPostDianHui;

@Controller
@RequestMapping("/dh/manage")
public class DHDataManage {
    @Autowired
    private HttpServletRequest request;
    @Resource
    private IUnitService unitService;
    @Resource
    private IDianhuiBindService dianhuiBindService;
    @Resource
    private Regex regex;
    @Resource
    private TRegnumSourceMapper tRegnumSourceMapper;
    @Resource
    private IReginfoService reginfoService;
    @Resource
    private TReginfoMapper reginfoDao;
    @Resource
    private TUnitMapper unitDao;
    @Value("${xx.interface.dh}")
    private String DH_INTERFACE;
    @Value("${dianhui.url}")
    private String DH_URL;
    @Value("${dianhui.key}")
    private String DH_KEY;
    @Value("${dianhui.merchantNo}")
    private String DH_MERCHANTNO;

    private static Logger loggerSingleWork = Logger.getLogger("DataManage.SingleWork");
    private static Logger loggerException = Logger.getLogger("Sys.Exception");

    /**
     * axB复用绑定接口
     *
     * @param bindVo
     * @return
     */
    @ResponseBody
    @RequestMapping("/bindingAXB")
    public Object bindingAXBReview(DmDataBindVo bindVo) {
        //测试使用的当前时间
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmssSSS");
        loggerSingleWork.info("now:" + sdf.format(new Date()));
        // 生成一个SequenceId,用于记录日志
        String seqId = UUID.randomUUID().toString();
        // 通过getParameterMap获取"相对"原始的请求参数,分别存放在requestContent（用于记录日志）和parameterMap（用于计算签名）。
        // 通过spring注入bean获取的参数会忽略掉bean里不需要的参数
        String requestContent = "";
        Map<String, String> parameterMap = new HashMap<String, String>();
        for (Iterator<Entry<String, String[]>> iter = request.getParameterMap().entrySet().iterator(); iter
                .hasNext(); ) {
            Entry<String, String[]> entry = iter.next();
            String key = entry.getKey();
            String vals = "";
            for (String val : entry.getValue()) {
                vals += val;
            }
            if (requestContent != "")
                requestContent += "&";
            requestContent += key + "=" + vals;
            if (!key.equals("sign"))
                parameterMap.put(key, vals);
        }
        loggerSingleWork.info(String.format("seqid=%s,request=%s?%s", seqId, request.getRequestURI(), requestContent));

        // 公众参数合法性检查
        loggerSingleWork.info("receive ts:" + bindVo.getTs());
        String errMsg = bindVo.checkCommon();
        if (StringUtils.isNotBlank(errMsg)) {
            Object response = ResponseUtils.makeXzResponse("101", errMsg, null);
            loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
            return response;
        }

        // 绑定参数合法性检查
        errMsg = bindVo.checkAxBReview(regex);
        if (StringUtils.isNotBlank(errMsg)) {
            Object response = ResponseUtils.makeXzResponse("101", errMsg, null);
            loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
            return response;
        }

        if (!StringUtils.equals("0", bindVo.getUnitId())) {
            // 根据unitid获取secret(用于计算签名)，后续考虑将secret放在缓存中
            String secret = unitService.getSecret(bindVo.getUnitId(), bindVo.getAppkey());
            if (StringUtils.isBlank(secret)) {
                Object response = ResponseUtils.makeXzResponse("101", "使用了错误的unitID或appkey", null);
                loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
                return response;
            }

            // 签名检查
            try {
                if (!bindVo.getSign().equalsIgnoreCase(SignUtils.signTopRequest(parameterMap, secret, "MD5"))) {
                    loggerSingleWork.info(String.format("seqid=%s,calculate_sign=%s", seqId,
                            SignUtils.signTopRequest(parameterMap, secret, "MD5")));
                    Object response = ResponseUtils.makeXzResponse("101", "签名错误", null);
                    loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
                    return response;
                }
            } catch (IOException e) {
                loggerException
                        .error(String.format("seqid=%s,Exception=%s", seqId, e.toString().replaceAll("\n", "|")));
                return ResponseUtils.makeXzResponse("-1", "服务器异常", null);
            }
        }
        //服务器返回的结果
        JSONObject response;
        try {
            //判断之前是否绑定
            // 查询95号的绑定信息
            TReginfoExample example = new TReginfoExample();
            TReginfoExample.Criteria criteria1 = example.createCriteria();
            criteria1.andUidnumberEqualTo(bindVo.getTelX());
            criteria1.andUnitidEqualTo(bindVo.getUnitId());
            criteria1.andRegphoneEqualTo(bindVo.getTelA());
            criteria1.andExpiretimeGreaterThan(new Date());
            TReginfoExample.Criteria criteria2 = example.createCriteria();
            criteria2.andUidnumberEqualTo(bindVo.getTelX());
            criteria2.andUnitidEqualTo(bindVo.getUnitId());
            criteria2.andRegphoneEqualTo(bindVo.getTelA());
            criteria2.andExpiretimeIsNull();
            example.or(criteria2);
            example.setLimitClause("1");
            List<TReginfo> reginfos = reginfoService.selectLTReginfoByExample(example);
            if (null != reginfos && reginfos.size() >= 1) {    //已有绑定记录
                response = ResponseUtils.makeErrResponse("201", "Service error", "rebind",
                        "重复绑定");
                loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
                return response;
            }

            //判断接口是否有权限,根据unitId判断权限。
            TUnit unit = unitDao.selectByPrimaryKey(bindVo.getUnitId());
            String role = unit.getUnitadd();
            //mode101，指定号码绑定，根据指定号码在数据库中存的值判断调用哪个接口
            TRegnumSource source = tRegnumSourceMapper.selectByPrimaryKey(bindVo.getTelX());
            if (source == null) {
                loggerException.error(String.format("seqid=%s,Exception=%s", seqId, "号码池中没有该号码!"));
                return ResponseUtils.makeXzResponse("-1", "号码池中没有该号码", null);
            }
            //接口名称
            String sourceName = source.getSource();
            bindVo.setName(sourceName);
            //判断tunit表中的权限，根据TRegnumSource调用不同接口
            if (StringUtils.contains(role, DH_INTERFACE) && StringUtils.equals(sourceName, DH_INTERFACE)) {
                response = (JSONObject) dianhuiBindService.bindDianHuiAXBReview(loggerSingleWork, bindVo, seqId);
                loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
            }else {
                //数据库source名称维护错误的接口
                loggerException.error(String.format("seqid=%s,Exception=%s", seqId, "未找到与" + sourceName + "匹配的接口"));
                response = ResponseUtils.makeXzResponse("10003", "没有权限访问接口", null);
            }
            //返回结果
            return response;
        } catch (Exception e) {
            loggerException.error(String.format("seqid=%s,Exception=%s", seqId, e.toString().replaceAll("\n", "|")));
            //loggerException.error("出错详细信息",e); //第二个参数是e
            return ResponseUtils.makeXzResponse("-1", "服务器异常", null);
        }

    }

    /**
     * axB复用解绑接口
     *
     * @param bindVo
     * @return
     */
    @ResponseBody
    @RequestMapping("/unbindAXB")
    public Object unbindAXBReview(DmDataBindVo bindVo) {
        // 生成一个SequenceId,用于记录日志
        String seqId = UUID.randomUUID().toString();
        // 通过getParameterMap获取"相对"原始的请求参数,分别存放在requestContent（用于记录日志）和parameterMap（用于计算签名）。通过spring注入bean获取的参数会忽略掉bean里不需要的参数
        String requestContent = "";
        Map<String, String> parameterMap = new HashMap<String, String>();
        for (Iterator<Entry<String, String[]>> iter = request.getParameterMap().entrySet().iterator(); iter
                .hasNext(); ) {
            Entry<String, String[]> entry = iter.next();
            String key = entry.getKey();
            String vals = "";
            for (String val : entry.getValue()) {
                vals += val;
            }
            if (requestContent != "")
                requestContent += "&";
            requestContent += key + "=" + vals;
            if (!key.equals("sign"))
                parameterMap.put(key, vals);
        }
        loggerSingleWork.info(String.format("seqid=%s,request=%s?%s", seqId, request.getRequestURI(), requestContent));

        // 公众参数合法性检查
        String errMsg = bindVo.checkCommon();
        if (StringUtils.isNotBlank(errMsg)) {
            Object response = ResponseUtils.makeXzResponse("101", errMsg, null);
            loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
            return response;
        }

        // 绑定参数合法性检查
        errMsg = bindVo.checkUnBind(regex);
        if (StringUtils.isNotBlank(errMsg)) {
            Object response = ResponseUtils.makeXzResponse("101", errMsg, null);
            loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
            return response;
        }

        if (!StringUtils.equals("0", bindVo.getUnitId())) {
            // 根据unitid获取secret(用于计算签名)，后续考虑将secret放在缓存中
            String secret = unitService.getSecret(bindVo.getUnitId(), bindVo.getAppkey());
            if (StringUtils.isBlank(secret)) {
                Object response = ResponseUtils.makeXzResponse("101", "使用了错误的unitID或appkey", null);
                loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
                return response;
            }

            // 签名检查
            try {
                if (!bindVo.getSign().equalsIgnoreCase(SignUtils.signTopRequest(parameterMap, secret, "MD5"))) {
                    loggerSingleWork.info(String.format("seqid=%s,calculate_sign=%s", seqId,
                            SignUtils.signTopRequest(parameterMap, secret, "MD5")));
                    Object response = ResponseUtils.makeXzResponse("101", "签名错误", null);
                    loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
                    return response;
                }
            } catch (IOException e) {
                loggerException
                        .error(String.format("seqid=%s,Exception=%s", seqId, e.toString().replaceAll("\n", "|")));
                return ResponseUtils.makeXzResponse("-1", "服务器异常", null);
            }
        }
        //服务器返回的结果
        JSONObject response;
        try {
            //查询reginfo记录
            TReginfoExample example = new TReginfoExample();
            TReginfoExample.Criteria criteria = example.createCriteria();
            criteria.andCardnoEqualTo(bindVo.getSubId());
            List<TReginfo1> reginfos = reginfoDao.selectDByExample(example);
            try {
                if (null == reginfos || reginfos.size() < 1) {
                    loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, "没有该subid的绑定数据，直接返回成功"));
                    return ResponseUtils.makeXzResponse("0", "success", null);
                }
                bindVo.setTelX(reginfos.get(0).getUidnumber());
            } catch (Exception e) {
                e.printStackTrace();
                loggerSingleWork.error(String.format("seqid=%s,response=%s", seqId, "解绑时获取telx出错"));
            }
            //判断接口是否有权限,根据unitId判断权限。
            TUnit unit = unitDao.selectByPrimaryKey(bindVo.getUnitId());
            String role = unit.getUnitadd();
            //判断调用哪个接口
            TRegnumSource source = tRegnumSourceMapper.selectByPrimaryKey(bindVo.getTelX());
            if (source == null) {
                loggerException.error(String.format("seqid=%s,Exception=%s", seqId, "号码池中没有该号码!"));
                return ResponseUtils.makeXzResponse("-1", "号码池中没有该号码", null);
            }
            //接口名称
            String sourceName = source.getSource();
            bindVo.setName(sourceName);
            //判断tunit表中的权限，根据TRegnumSource调用不同接口
            if (StringUtils.contains(role, DH_INTERFACE) && StringUtils.equals(sourceName, DH_INTERFACE)) {
                response = (JSONObject) dianhuiBindService.unDianHuiAXBReview(loggerSingleWork, bindVo, seqId);
                loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
            } else {
                //数据库source名称维护错误的接口
                loggerException.error(String.format("seqid=%s,Exception=%s", seqId, "未找到与" + sourceName + "匹配的接口"));
                response = ResponseUtils.makeXzResponse("10003", "没有权限访问接口", null);
            }
            //返回结果
            return response;
        } catch (Exception e) {
            loggerException.error(String.format("seqid=%s,Exception=%s", seqId, e.toString().replaceAll("\n", "|")));
            loggerException.error("e",e);
            return ResponseUtils.makeXzResponse("-1", "服务器异常", null);
        }
    }
    //临时的xb接口
    @ResponseBody
    @RequestMapping("/bindingXB")
    public Object bindingXB(DmDataBindVo bindVo) {
        try{
        loggerSingleWork.info("receive:" + bindVo.toString());
        //测试使用的当前时间
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmssSSS");
        String ts=sdf.format(new Date());
        loggerSingleWork.info("now:" + ts);
        // 生成一个SequenceId,用于记录日志
        String seqId = UUID.randomUUID().toString();
        // 通过getParameterMap获取"相对"原始的请求参数,分别存放在requestContent（用于记录日志）和parameterMap（用于计算签名）。
        // 通过spring注入bean获取的参数会忽略掉bean里不需要的参数
        String url = DH_URL + "/privacyNumber/privacyXB.do";
        loggerSingleWork.info("url:" + url);
        //点慧有效期不允许为0
        if(StringUtils.equals("0",bindVo.getExpiration()) ){
            loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, "expiration不允许为0" ));
            return ResponseUtils.makeXzResponse("201", "expiration不允许为0", null);
        }


        //点慧header参数
        Map<String, String> header = new LinkedHashMap<>();
        header.put("merchantNo", DH_MERCHANTNO);
        header.put("ts", ts);
        //json参数
        Map<String, String> requestMap = new LinkedHashMap<>();
        requestMap.put("telB", bindVo.getTelB());
        requestMap.put("telX",  bindVo.getTelX());
        requestMap.put("expiration", bindVo.getExpiration());

        //计算签名所需要的参数
        Map<String, String> md5Param = new LinkedHashMap<>();
        md5Param.putAll(header);
        md5Param.putAll(requestMap);
        //接口调用时间
        String dataJson = JSONObject.toJSONString(requestMap);
        String result = OKHttpClientUtil.httpJsonPostDianHui(url,  dataJson, DH_MERCHANTNO, ts,
                getMsgdgt(loggerSingleWork, seqId, md5Param, DH_KEY), seqId, loggerSingleWork);
        loggerSingleWork.info("http result:" + result);
        Map resultMap = null;
        try {
             ObjectMapper objectMapper = new ObjectMapper();
            resultMap = objectMapper.readValue(result, Map.class);
        } catch (Exception e) {
            loggerSingleWork.error(String.format("seqid=%s,response=%s", seqId, "xb接口返回值转换错误:" + result));
            return ResponseUtils.makeXzResponse("201", "x to b 接口出错", null);
        }

        if (!StringUtils.equals("0000", resultMap.get("responseCode").toString())) {
            loggerSingleWork.error(String.format("seqid=%s,response=%s", seqId, "xb接口返回值错误:" + result));
            return ResponseUtils.makeXzResponse("201", (String) resultMap.get("responseMsg"), null);
        }
        return ResponseUtils.makeXzResponse("0", "success", result);
        }catch (Exception e){
            loggerSingleWork.info("e:",e);
            return null;
        }
    }
    public String getMsgdgt(Logger logger, String seqId, Map<String, String> param, String key) {
        StringBuffer msgdgtBuffer = new StringBuffer(key);
        for (Map.Entry<String, String> entry : param.entrySet()) {
            msgdgtBuffer.append(entry.getKey() + entry.getValue());
        }
        String msgdgt = DigestUtils.md5Hex(msgdgtBuffer.toString()).toUpperCase();
        if (null != logger) {
            logger.info(String.format("seqid=%s,response=%s", seqId, "小号接口密钥明文:" + msgdgtBuffer.toString()));
            logger.info(String.format("seqid=%s,response=%s", seqId,
                    "小号接口密钥密文:" + msgdgt));
        }
        return msgdgt;
    }

}
