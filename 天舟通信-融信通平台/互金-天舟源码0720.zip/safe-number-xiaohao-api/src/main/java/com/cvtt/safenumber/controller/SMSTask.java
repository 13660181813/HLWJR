package com.cvtt.safenumber.controller;

import java.io.File;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import javax.annotation.Resource;

import com.cvtt.safenumber.constents.Regex;
import org.apache.commons.lang.StringUtils;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Controller;

import com.cvtt.safenumber.service.ISMSService;
import com.cvtt.safenumber.utils.CSVUtils;

@Controller
public class SMSTask {
	@Resource
	private ISMSService smsService;
	@Resource
	private Regex regex;
	
	public void sendSms(String fileName){
		// 读取上传的数据文件
		String[] header = { "\t电话号", "\t自定义编号", "\t有效期", "\t95号", "\t操作结果" };
		List<List<String>> requestRecords = CSVUtils.readCsvFile(fileName, header);
		// 判断读取结果
		if ( null != requestRecords ) {
			// 如果有表头则去掉表头
			if (1 <= requestRecords.size()) {
				List<String> first = requestRecords.get(0);
				if( StringUtils.isNotBlank(first.get(0)) && StringUtils.equals("电话号", first.get(0).trim()) ){
					requestRecords.remove(0);
				}
			}
			for (List<String> request : requestRecords) {
				while (request.size() < 5) // 补齐字段，方便写结果csv
					request.add("");
				// 处理电话号码
				if (StringUtils.isBlank(request.get(0))) {
					request.set(4, "失败：电话号码为空");
					for (int i = 0; i < request.size(); i++) // 加上制表符
						request.set(i, "\t" + request.get(i));
					continue;
				}
				if ( !request.get(0).matches(regex.PHONE_FIXED) && !request.get(0).matches(regex.PHONE_MOBILE) ) {
					request.set(4, "失败：电话号码错误");
					for (int i = 0; i < request.size(); i++) // 加上制表符
						request.set(i, "\t" + request.get(i));
					continue;
				}
				// 处理uidnumber
				if (StringUtils.isBlank(request.get(3))) {
					request.set(4, "失败：95号码为空");
					for (int i = 0; i < request.size(); i++) // 加上制表符
						request.set(i, "\t" + request.get(i));
					continue;
				}
				if (!request.get(3).matches("^95013\\d{0,12}$")) {
					request.set(4, "失败：95号码错误");
					for (int i = 0; i < request.size(); i++) // 加上制表符
						request.set(i, "\t" + request.get(i));
					continue;
				}
				// 处理uuidinpartner
				/*if (StringUtils.isBlank(request.get(2))) {
					request.set(4, "失败：自定义编号为空");
					for (int i = 0; i < request.size(); i++) // 加上制表符
						request.set(i, "\t" + request.get(i));
					continue;
				}*/
				// 发送短信
				try {
					String retMsg = smsService.sendMsg(request.get(0).trim(), request.get(3).trim(), request.get(1).trim());
					request.set(4, retMsg );
					for (int i = 0; i < request.size(); i++) // 加上制表符
						request.set(i, "\t" + request.get(i));
				} catch (Exception e) {
					request.set(4, e.getMessage() );
					for (int i = 0; i < request.size(); i++) // 加上制表符
						request.set(i, "\t" + request.get(i));
				}
			}
			String retFileName = fileName+".ret.csv";
			CSVUtils.writeCsvFile(retFileName, header, requestRecords);
		}
	}
	
	@Scheduled(cron="*/60 * * * * *")  
    public void runTask(){
		// 遍历${catalina.base}/smsqueue/文件夹，查找需要发送短信的文件
		File dir = new File(System.getProperty("catalina.base") + "/smsqueue/");
		if (dir.exists()) {
			File[] files = dir.listFiles();
            for (File file : files) {
            	if (!file.isDirectory()) {
            		// 获取创建时间
            		String createTime = file.getName().substring(0,14);
            		DateFormat fmt = new SimpleDateFormat("yyyyMMddHHmmss");
        			try {
        				Date createDate = fmt.parse(createTime);
        				Calendar calendar = new GregorianCalendar();
        				calendar.setTime(new Date());
        				calendar.add(Calendar.MINUTE, -smsService.getDelayTime());
        				if (createDate.before(calendar.getTime())){ //可执行发送
        					// 移动文件到sent文件夹
        					File folder = new File(System.getProperty("catalina.base") + "/smsqueue/sent/");
        					if (!(folder.exists() && folder.isDirectory())){
        						folder.mkdirs();
        					}
        					String newFileName = System.getProperty("catalina.base") + "/smsqueue/sent/" + file.getName();
        					if(file.renameTo(new File(newFileName))){
        						// 调用发送
            					sendSms(newFileName);
        					}
        					// TODO 移动失败时需处理
        				}
        			} catch (ParseException e) {
        				//e.printStackTrace();
        			}
                }
            }
		}
    }
}
