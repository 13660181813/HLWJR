/**
 * 鉴权相关接口(鉴权绑定，鉴权解绑)，不包括鉴权查询，鉴权查询在CallManage里实现
 */
package com.cvtt.safenumber.controller;

import com.cvtt.safenumber.constents.Regex;
import com.cvtt.safenumber.service.*;
import com.cvtt.safenumber.utils.ResponseUtils;
import com.cvtt.safenumber.utils.SignUtils;
import com.cvtt.safenumber.vo.AuthBindVo;
import com.cvtt.safenumber.vo.AuthQueryVo;
import com.cvtt.safenumber.vo.AuthUnbindVo;
import com.cvtt.safenumber.vo.CommonVo1;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.UUID;

@Controller
@RequestMapping("/api/auth")
public class AuthManage {
	@Autowired
	private HttpServletRequest request;
	@Resource
	private IUnitService unitService;
	@Resource
	private IAuthService authService;
	@Resource
	private Regex regex;

	private static Logger loggerAuthMainten = Logger.getLogger("AuthManage.AuthMainten");
	private static Logger loggerException = Logger.getLogger("Sys.Exception");

	@ResponseBody
	@RequestMapping("/authManage")
	// 示例url
	public Object authManage(CommonVo1 commonVo, AuthBindVo bindVo, AuthUnbindVo unbindVo, AuthQueryVo queryVo) {
		// 生成一个SequenceId,用于记录日志
		String seqId = UUID.randomUUID().toString();
		// 通过getParameterMap获取"相对"原始的请求参数,分别存放在requestContent（用于记录日志）和parameterMap（用于计算签名）。通过spring注入bean获取的参数会忽略掉bean里不需要的参数
		String requestContent = "";
		Map<String, String> parameterMap = new HashMap<String, String>();
		for (Iterator<Entry<String, String[]>> iter = request.getParameterMap().entrySet().iterator(); iter
				.hasNext();) {
			Entry<String, String[]> entry = iter.next();
			String key = entry.getKey();
			String vals = "";
			for (String val : entry.getValue()) {
				vals += val;
			}
			if (requestContent != "")
				requestContent += "&";
			requestContent += key + "=" + vals;
			if (!key.equals("sid"))
				parameterMap.put(key, vals);
		}
		loggerAuthMainten.info(String.format("seqid=%s,request=%s?%s", seqId, request.getRequestURI(), requestContent));

		// 公众参数合法性检查
		String errMsg = commonVo.checkMembers();
		if (StringUtils.isNotBlank(errMsg)) {
			Object response = ResponseUtils.makeErrResponse("101", "Parameter error", "invalid-parameter", errMsg);
			loggerAuthMainten.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
			return response;
		}

		// 根据unitid获取secret(用于计算签名)，后续考虑将secret放在缓存中
		String secret = unitService.getSecret(commonVo.getUnitID(), commonVo.getAppkey());
		if (StringUtils.isBlank(secret)) {
			Object response = ResponseUtils.makeErrResponse("101", "Parameter error", "key-error",
					"使用了错误的unitID或appkey");
			loggerAuthMainten.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
			return response;
		}

		// 签名检查
		try {
			if (!commonVo.getSid().equalsIgnoreCase(SignUtils.signTopRequest(parameterMap, secret, "MD5"))) {
				loggerAuthMainten.error(String.format("seqid=%s,calculate_sign=%s", seqId,
						SignUtils.signTopRequest(parameterMap, secret, "MD5")));
				Object response = ResponseUtils.makeErrResponse("101", "Parameter error", "sign-error", "签名错误");
				loggerAuthMainten.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
				return response;
			}
		}  catch (IOException e) {
			loggerException.error(String.format("seqid=%s,Exception=%s", seqId, e.toString().replaceAll("\n", "|")));
			return ResponseUtils.makeExceptResponse("");
		}

		// 消息体参数检查
		String msgType = commonVo.getMsgtype();
		switch (msgType) {
		case "binding_Relation":
			try {
				bindVo.setProductid(null);
				return authService.authProcess(loggerAuthMainten, commonVo, bindVo, seqId);
			} catch (Exception e) {
				loggerException.error(String.format("seqid=%s,Exception=%s", seqId, e.toString().replaceAll("\n", "|")));
				return ResponseUtils.makeExceptResponse("");
			}
		case "remove_Relation":
			try {
				return authService.authProcess(loggerAuthMainten, commonVo, unbindVo, seqId);
			} catch (Exception e) {
				loggerException.error(String.format("seqid=%s,Exception=%s", seqId, e.toString().replaceAll("\n", "|")));
				return ResponseUtils.makeExceptResponse("");
			}
		case "check_Relation":
			errMsg = queryVo.checkMembers(regex);
			if (StringUtils.isNotBlank(errMsg)) {
				Object response = ResponseUtils.makeErrResponse("101", "Parameter error", "invalid-parameter", errMsg);
				loggerAuthMainten.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
				return response;
			}
			try {
				return authService.AuthQuery(loggerAuthMainten, queryVo, seqId);
			} catch (Exception e) {
				loggerException.error(String.format("seqid=%s,Exception=%s", seqId, e.toString().replaceAll("\n", "|")));
				return ResponseUtils.makeExceptResponse("");
			}
		default:
			Object response = ResponseUtils.makeErrResponse("101", "Parameter error", "invalid-parameter",
					"使用了本接口不支持的方法");
			loggerAuthMainten.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
			return response;
		}
	}
}
