/**
 * 讯众小号推送话单类
 */
package com.cvtt.safenumber.controller.xz;

import com.alibaba.fastjson.JSONObject;
import com.cvtt.safenumber.dao.TUnitInfoMapper;
import com.cvtt.safenumber.dao.TUnitMapper;
import com.cvtt.safenumber.pojo.Arc95013;
import com.cvtt.safenumber.pojo.Arc95013Example;
import com.cvtt.safenumber.pojo.TReginfo;
import com.cvtt.safenumber.pojo.TReginfoExample;
import com.cvtt.safenumber.pojo.TUnit;
import com.cvtt.safenumber.pojo.TUnitInfo;
import com.cvtt.safenumber.pojo.TUnitInfoExample;
import com.cvtt.safenumber.service.ICallService;
import com.cvtt.safenumber.service.IDownloadService;
import com.cvtt.safenumber.service.IReginfoService;
import com.cvtt.safenumber.service.IUnitService;
import com.cvtt.safenumber.service.xz.IxzBindService;
import com.cvtt.safenumber.utils.DateUtils;
import com.cvtt.safenumber.utils.JsonUtils;
import com.cvtt.safenumber.utils.ResponseUtils;
import com.cvtt.safenumber.utils.SignUtils;
import com.cvtt.safenumber.vo.CallReleaseVo;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.io.BufferedReader;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.UUID;


@SuppressWarnings("all")
@Controller
@RequestMapping("/v2/ax")
public class XzCallManage {
    @Autowired
    private HttpServletRequest request;
    @Resource
    private IUnitService unitService;
    @Resource
    private IxzBindService xzBindService;

    @Resource
    private ICallService callService;

    @Resource
    private IReginfoService reginfoService;

    @Resource
    private TUnitInfoMapper infoDao;
    @Resource
    private TUnitMapper unitDao;
    @Resource
    private IDownloadService iDownloadService;


    @Value("${recordUrl}")
    private String RECORDURL;
    @Value("${dowmloadTime}")
    private String WAITSECOND;


    private static Logger loggerSingleWork = Logger.getLogger("DataManage.SingleWork");
    private static Logger loggerBatchWork = Logger.getLogger("DataManage.BatchWork");
    private static Logger loggerException = Logger.getLogger("Sys.Exception");
    private static String sdf = "yyyy-MM-dd HH:mm:ss";

    /**
     * 开始通话接口
     *
     * @param bindVo
     * @return
     */
    @ResponseBody
    @RequestMapping("/callin")
    public Object callin() {
        String seqId = UUID.randomUUID().toString();
        JSONObject response = ResponseUtils.makeXzResponse("200", "成功", null);
        try {
            Map<String, String> map = getParaMap();
            // 通过getParameterMap获取"相对"原始的请求参数,分别存放在requestContent（用于记录日志）和parameterMap（用于计算签名）。通过spring注入bean获取的参数会忽略掉bean里不需要的参数
            String requestContent = "";
            for (Entry<String, String> entry : map.entrySet()) {
                String key = entry.getKey();
                String value = entry.getValue();
                if (requestContent != "") {
                    requestContent += "&";
                }
                requestContent += key + "=" + value;
            }
            loggerSingleWork
                    .info(String.format("seqid=%s,request=%s?%s", seqId, request.getRequestURI(), requestContent));

            // 签名验证最后加
            // 绑定参数合法性检查
            String subId = map.get("subid");
            String callid = map.get("callid");
            String telA = map.get("telA");
            String telX = map.get("telX");
            String telB = map.get("telB");
            String requestId = map.get("requestId");
            String calltype = map.get("calltype");

            if(StringUtils.isEmpty(subId)){
                loggerSingleWork.info(String.format("seqid=%s,info=%s", seqId, "该请求没有subid，直接返回响应信息"));
                return response;
            }

            TReginfoExample example = new TReginfoExample();
            TReginfoExample.Criteria criteria = example.createCriteria();
            criteria.andCardnoEqualTo(subId);
            List<TReginfo> tReginfos = reginfoService.selectByExample(example);
            if (tReginfos.size() == 0) {
                loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
                return response;
            }
            String unitId = tReginfos.get(0).getUnitid();
            Date startTime = DateUtils.parseSync8(map.get("calltime"), sdf);

            CallReleaseVo releaseVo = new CallReleaseVo();
            releaseVo.setCall_id(callid);
            releaseVo.setNo_a(telA);
            releaseVo.setNo_x(telX);
            releaseVo.setNo_b(telB);
            releaseVo.setTime_start(startTime);
            releaseVo.setRequest_id(requestId);
            releaseVo.setPartner_id(unitId);
            releaseVo.setCalltype(calltype);
            releaseVo.setSubid(subId);
            releaseVo.setAreacode(map.get("areacode"));
            String companyName= tReginfos.get(0).getName();
            releaseVo.setVoicemail_file(companyName);

            TUnitInfoExample infoExample = new TUnitInfoExample();
            TUnitInfoExample.Criteria infoCriteria = infoExample.createCriteria();
            infoCriteria.andUnitidEqualTo(unitId);
            List<TUnitInfo> infos = infoDao.selectByExample(infoExample);

            if (infos.size() > 0) {
                TUnitInfo info = infos.get(0);
                if (StringUtils.isNotBlank(info.getShanUrl())) {
                    Map<String, String> param = new HashMap<>();
                    param.put("start_time", URLEncoder.encode(map.get("calltime"), "utf-8"));
                    param.put("call_id", callid);
                    param.put("ring_time", URLEncoder.encode(map.get("calltime"), "utf-8"));
                    param.put("partner_id", info.getShanPartnerId());
                    param.put("no_x", telX);
                    param.put("leg", info.getShanTempletAb());
                    if (StringUtils.equals(calltype, "128")) {
                        param.put("no_b", telB);
                    } else if (StringUtils.equals(calltype, "1")) {
                        param.put("no_b", telA);
                    }
                    xzBindService.pushShan(loggerSingleWork, param, seqId, info.getShanUrl());
                }
            }
            //判断话单是否重复，通过releaseTime=空+callId判断,重复则不再写话单。
            Arc95013Example exampleARC = new Arc95013Example();
            Arc95013Example.Criteria criteria2 = exampleARC.createCriteria();
            criteria2.andStartTimeEqualTo(startTime);
            criteria2.andNoXEqualTo(telX);
            criteria2.andCallIdEqualTo(callid);
            criteria2.andReleaseTimeIsNull();
            List<Arc95013> arc95013ExampleList = callService.selectByExample(exampleARC);
            //如果查不到值，则写话单
            if (arc95013ExampleList.size() == 0) {
                callService.callRelease(loggerSingleWork, releaseVo, seqId);
            }


        } catch (Exception e) {
            e.printStackTrace();
            loggerException.error(String.format("seqid=%s,Exception=%s", seqId, e.toString().replaceAll("\n", "|")));
        }
        loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
        return response;
    }

    /**
     * 结束通话接口
     *
     * @param bindVo
     * @return
     */
    @ResponseBody
    @RequestMapping("/finish")
    public Object finish() {
        String seqId = UUID.randomUUID().toString();
        JSONObject response = ResponseUtils.makeXzResponse("200", "成功", null);
        try {
            Map<String, String> map = getParaMap();
            // 生成一个SequenceId,用于记录日志

            // 通过getParameterMap获取"相对"原始的请求参数,分别存放在requestContent（用于记录日志）和parameterMap（用于计算签名）。通过spring注入bean获取的参数会忽略掉bean里不需要的参数
            String requestContent = "";
            for (Entry<String, String> entry : map.entrySet()) {
                String key = entry.getKey();
                String value = entry.getValue();

                if (requestContent != "") {
                    requestContent += "&";
                }
                requestContent += key + "=" + value;
            }
            loggerSingleWork
                    .info(String.format("seqid=%s,request=%s?%s", seqId, request.getRequestURI(), requestContent));

            // 签名验证最后加
            // 绑定参数合法性检查
            String subId = map.get("subid");
            String callid = map.get("callid");
            String telA = map.get("telA");
            String telX = map.get("telX");
            String telB = map.get("telB");
            String requestId = map.get("requestId");
            String calltype = map.get("calltype");
            String recordUrl = map.get("recordUrl");
            if(StringUtils.isEmpty(subId)){
                loggerSingleWork.info(String.format("seqid=%s,info=%s", seqId, "该请求没有subid，直接返回响应信息"));
                return response;
            }

            TReginfoExample example = new TReginfoExample();
            TReginfoExample.Criteria criteria = example.createCriteria();
            criteria.andCardnoEqualTo(subId);
            List<TReginfo> tReginfos = reginfoService.selectByExample(example);
            if (tReginfos.size() == 0) {
                loggerSingleWork.info(String.format("seqid=%s,info=%s", seqId, "subId在TReginfo没找到对应的数据:" + subId));
                loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
                return response;
            }
            String unitId = tReginfos.get(0).getUnitid();
            Date startTime = DateUtils.parseSync8(map.get("calltime"), sdf);

            CallReleaseVo releaseVo = new CallReleaseVo();
            releaseVo.setCall_id(callid);
            releaseVo.setNo_a(telA);
            releaseVo.setNo_x(telX);
            releaseVo.setNo_b(telB);
            releaseVo.setTime_start(startTime);
            releaseVo.setRequest_id(requestId);
            releaseVo.setPartner_id(unitId);
            releaseVo.setCalltype(calltype);
            releaseVo.setSubid(subId);
            releaseVo.setRecording_file(recordUrl);
            if(map.containsKey("starttime")){
                releaseVo.setTime_answer(DateUtils.parseSync8(map.get("starttime"), sdf));
            }
            if(map.containsKey("ringingtime")){
                releaseVo.setTime_ring(DateUtils.parseSync8(map.get("ringingtime"), sdf));
            }
            if(map.containsKey("releasetime")){
                releaseVo.setTime_release(DateUtils.parseSync8(map.get("releasetime"), sdf));
            }
            releaseVo.setRelease_dir(map.get("releasedir"));
            releaseVo.setRelease_cause(map.get("releasecause"));

            releaseVo.setAreacode(map.get("areacode"));
            String companyName= tReginfos.get(0).getName();
            releaseVo.setVoicemail_file(companyName);

            if (!StringUtils.isEmpty(recordUrl)) {
                //保存录音文件到本地
                String urlPath = recordUrl;
                //获取录音文件名
                String recordName = StringUtils.substringAfterLast(urlPath, "/");
                Date now = new Date();
                SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd");
                String DateNow = sdf2.format(now);
                String saveDir = RECORDURL + "/recordings/" + unitId + "/" + DateNow + "/" + recordName;
                //下载录音
                iDownloadService.downloadFile(urlPath, saveDir, seqId, WAITSECOND);
                String newRecordUrl = unitId + "/" + DateNow + "/" + recordName;
                map.put("recordUrl", newRecordUrl);
            }

            TUnitInfoExample infoExample = new TUnitInfoExample();
            TUnitInfoExample.Criteria infoCriteria = infoExample.createCriteria();
            infoCriteria.andUnitidEqualTo(unitId);
            List<TUnitInfo> infos = infoDao.selectByExample(infoExample);

            if (infos.size() > 0) {
                //TUnitInfo表中该企业有话单地址，添加话单传递时必要信息
                TUnitInfo info = infos.get(0);
                if (StringUtils.isNotBlank(info.getCdrUrl())) {
                    TUnit unit = unitDao.selectSecretByUnitid(unitId);
                    String secret = unitService.getSecret(unitId, unit.getUnitkey());
                    map.put("unitId", unitId);
                    map.put("appkey", unit.getUnitkey());
                    String url = info.getCdrUrl() + "/v2/ax/finish";
                    String sign = SignUtils.signTopRequest(map, secret, "MD5");
                    if(StringUtils.equals(calltype,"11")){
                        map.put("calltype", "1");
                    }else if(StringUtils.equals(calltype,"10")){
                        map.put("calltype", "128");
                    }
                    map.put("sign", sign);
                    xzBindService.pushCdr(loggerSingleWork, map, seqId, url);
                }
            } else {
                loggerSingleWork.info(String.format("seqid=%s,info=%s", seqId, "subId在TUnitInfo没找到对应的数据:" + subId));
            }
            if(StringUtils.equals(calltype,"12")||StringUtils.equals(calltype,"13")){
                //短信话单
                //判断话单是否重复，通过releaseTime=空+callId判断,重复则不再写话单。
                Arc95013Example exampleARC = new Arc95013Example();
                Arc95013Example.Criteria criteria2 = exampleARC.createCriteria();
                criteria2.andStartTimeEqualTo(startTime);
                criteria2.andNoXEqualTo(telX);
                criteria2.andCallIdEqualTo(callid);
                criteria2.andReleaseTimeIsNull();
                List<Arc95013> arc95013ExampleList = callService.selectByExample(exampleARC);
                //如果查不到值，则写话单
                if (arc95013ExampleList.size() == 0) {
                    callService.callRelease(loggerSingleWork, releaseVo, seqId);
                }else{
                    loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, "短信话单重复，直接返回成功，不写入数据库"));
                }
            }else {
                //判断话单是否重复，通过releaseTime+callId判断,重复则不再写话单。
                Arc95013Example exampleARC = new Arc95013Example();
                Arc95013Example.Criteria criteria2 = exampleARC.createCriteria();
                criteria2.andStartTimeEqualTo(startTime);
                criteria2.andNoXEqualTo(telX);
                criteria2.andReleaseTimeEqualTo(DateUtils.parseSync8(map.get("releasetime"), sdf));
                criteria2.andCallIdEqualTo(callid);
                callService.callReleaseAndJudgeRepeated(loggerSingleWork, releaseVo, seqId, exampleARC);
            }
        } catch (Exception e) {
            loggerException.error(String.format("seqid=%s,Exception=%s", seqId, e.toString().replaceAll("\n", "|")));
            loggerSingleWork.info("exception:", e);
        }
        loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
        return response;
    }


    private Map<String, String> getParaMap() {
        BufferedReader reader = null;
        StringBuffer sb = new StringBuffer();
        try {
            reader = request.getReader();
            String str;
            while ((str = reader.readLine()) != null) {
                sb.append(str);
            }
            reader.close();
        } catch (Exception e) {
            // TODO: handle exception
        } finally {
            if (null != reader) {
                try {
                    reader.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
        return JsonUtils.jsonToPojo(sb.toString(), Map.class);
    }

}
