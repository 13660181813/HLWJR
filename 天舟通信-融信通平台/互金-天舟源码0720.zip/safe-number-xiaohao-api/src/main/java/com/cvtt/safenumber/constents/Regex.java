package com.cvtt.safenumber.constents;


import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * Created by sujin on 2017/6/20.
 */
@Component
public class Regex {
    @Value("${regex.phone_fixed}")
    public String PHONE_FIXED;
    @Value("${regex.phone_mobile}")
    public String PHONE_MOBILE;
    @Value("${regex.mobile_yd}")
    public String MOBILE_YD;
    @Value("${regex.mobile_lt}")
    public String MOBILE_LT;
    @Value("${regex.mobile_dx}")
    public String MOBILE_DX;
    @Value("${regex.prefix_authcall}")
    public String PREFIX_AUTHCALL;
    @Value("${regex.prefix_95013}")
    public String PREFIX_95013;
    /*
    public Regex(){
        PHONE_FIXED     = "^0\\d{2,3}\\d{7,8}$";
        PHONE_MOBILE    = "^1[34578]\\d{9}$";
        MOBILE_YD       = "^1(3[4-9]|5[012789]|8[78])$";
        MOBILE_LT       = "^1(3[0-2]|5[56]|8[56])$";
        MOBILE_DX       = "^1(8[09]|[35]3)$";
    }

    public Regex(String phoneFixed, String phoneMobile, String mobileYD, String mobileLT, String mobileDX){
        PHONE_FIXED     = phoneFixed;
        PHONE_MOBILE    = phoneMobile;
        MOBILE_YD       = mobileYD;
        MOBILE_LT       = mobileLT;
        MOBILE_DX       = mobileDX;
    }
    */
    // 京东
    @Value("${AES.SALT.JD:8445C55CB635FB10B667872001BFD9AE}")
    public String AES_SALT_JD;
    @Value("${JD.UNITID:0}")
    public String JD_UNITID;
    // 美团
    @Value("${ykt.unitid}")
    public String YKT_UNITID;
    @Value("${ykt.url}")
    public String YKT_URL;
    @Value("${ykt.url.unbind}")
    public String YKT_URL_UNBIND;
    @Value("${ykt.api.timestamp}")
    public int YKT_API_TIMESTAMP;
    @Value("${ykt.bind.max_expiration}")
    public long YKT_BIND_MAX_EXPIRATION;

}
