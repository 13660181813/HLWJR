/**
 * 关系数据相关接口(绑定，解绑，延期)
 */
package com.cvtt.safenumber.controller.xz;

import com.alibaba.fastjson.JSONObject;
import com.cvtt.safenumber.constents.Regex;
import com.cvtt.safenumber.dao.TReginfoMapper;
import com.cvtt.safenumber.dao.TRegnumSourceMapper;
import com.cvtt.safenumber.dao.TUnitMapper;
import com.cvtt.safenumber.pojo.TReginfo;
import com.cvtt.safenumber.pojo.TReginfoExample;
import com.cvtt.safenumber.pojo.TRegnumSource;
import com.cvtt.safenumber.pojo.TUnit;
import com.cvtt.safenumber.service.IUnitService;
import com.cvtt.safenumber.service.dm.IdmBindService;
import com.cvtt.safenumber.service.xz.IxzBindService;
import com.cvtt.safenumber.service.xz2.IxzBindService2;
import com.cvtt.safenumber.utils.ResponseUtils;
import com.cvtt.safenumber.utils.SignUtils;
import com.cvtt.safenumber.vo.xz.DmDataBindVo;
import com.cvtt.safenumber.vo.xz.XzDataBindVo;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.UUID;

@Controller
@RequestMapping("/xz/manage")
public class XzDataManage {
	@Autowired
	private HttpServletRequest request;
	@Resource
	private IUnitService unitService;
	@Resource
	private IxzBindService xzBindService;
	@Resource
	private IxzBindService2 xzBindService2;
	@Resource
	private TRegnumSourceMapper tRegnumSourceMapper;
	@Resource
	private TReginfoMapper tReginfoMapper;
	@Resource
	private Regex regex;
    @Resource
    private TUnitMapper unitDao;

	@Resource
	private IdmBindService dmBindService;

	private static Logger loggerSingleWork = Logger.getLogger("DataManage.SingleWork");
	private static Logger loggerException = Logger.getLogger("Sys.Exception");

	/**
	 * ax绑定接口
	 * 
	 * @param bindVo
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/binding")
	public Object binding(XzDataBindVo bindVo) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmssSSS");
		loggerSingleWork.info("now:"+sdf.format(new Date()));
		// 生成一个SequenceId,用于记录日志
		String seqId = UUID.randomUUID().toString();
		// 通过getParameterMap获取"相对"原始的请求参数,分别存放在requestContent（用于记录日志）和parameterMap（用于计算签名）。通过spring注入bean获取的参数会忽略掉bean里不需要的参数
		String requestContent = "";
		Map<String, String> parameterMap = new HashMap<String, String>();
		for (Iterator<Entry<String, String[]>> iter = request.getParameterMap().entrySet().iterator(); iter
				.hasNext();) {
			Entry<String, String[]> entry = iter.next();
			String key = entry.getKey();
			String vals = "";
			for (String val : entry.getValue()) {
				vals += val;
			}
			if (requestContent != "")
				requestContent += "&";
			requestContent += key + "=" + vals;
			if (!key.equals("sign"))
				parameterMap.put(key, vals);
		}
		loggerSingleWork.info(String.format("seqid=%s,request=%s?%s", seqId, request.getRequestURI(), requestContent));

		// 公众参数合法性检查
		String errMsg = bindVo.checkCommon();
		if (StringUtils.isNotBlank(errMsg)) {
			Object response = ResponseUtils.makeXzResponse("101",errMsg ,null);
			loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
			return response;
		}

		// 绑定参数合法性检查
		errMsg = bindVo.checkAxBind(regex);
		if (StringUtils.isNotBlank(errMsg)) {
			Object response = ResponseUtils.makeXzResponse("101",errMsg ,null);
			loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
			return response;
		}

		if (!StringUtils.equals("0", bindVo.getUnitId())) {
			// 根据unitid获取secret(用于计算签名)，后续考虑将secret放在缓存中
			String secret = unitService.getSecret(bindVo.getUnitId(), bindVo.getAppkey());
			if (StringUtils.isBlank(secret)) {
				Object response = ResponseUtils.makeXzResponse("101",  "使用了错误的unitID或appkey",null);
				loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
				return response;
			}

			// 签名检查
			try {
				if (!bindVo.getSign().equalsIgnoreCase(SignUtils.signTopRequest(parameterMap, secret, "MD5"))) {
					loggerSingleWork.info(String.format("seqid=%s,calculate_sign=%s", seqId,
							SignUtils.signTopRequest(parameterMap, secret, "MD5")));
					Object response = ResponseUtils.makeXzResponse("101",  "签名错误",null);
					loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
					return response;
				}
			} catch (IOException e) {
				loggerException
						.error(String.format("seqid=%s,Exception=%s", seqId, e.toString().replaceAll("\n", "|")));
				return ResponseUtils.makeXzResponse("-1","服务器异常",null);
			}
		}
			//根据telx的source判断调用哪个接口。
			TRegnumSource source=tRegnumSourceMapper.selectByPrimaryKey(bindVo.getTelX());
			if(source==null){
				loggerException.error(String.format("seqid=%s,Exception=%s", seqId, "号码池中没有该号码!"));
				return ResponseUtils.makeXzResponse("-1","号码池中没有该号码或没有权限访问接口",null);
			}
            JSONObject response ;
		    try {
                //根据unitId获取企业应该调用的接口。switch形式方便后续添加运营商。
                TUnit unit = unitDao.selectByPrimaryKey(bindVo.getUnitId());
                String sourceName=unit.getUnitadd()+source.getSource();
				bindVo.setName(sourceName);
                //服务器返回结果
                switch(sourceName){
                    case "xzxz1":
                        //讯众旧接口;
                         bindVo.setName(sourceName);
                         response = (JSONObject) xzBindService.bindSingle(loggerSingleWork, bindVo, seqId);
                        loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
                        break;
                    case "xzxz2":
                         //讯众新接口;
                         bindVo.setName(sourceName);
                         response = (JSONObject) xzBindService2.bindSingle(loggerSingleWork, bindVo, seqId);
                        loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
                        break;
                    default:
                        //数据库source名称维护错误的接口
                        loggerException.error(String.format("seqid=%s,Exception=%s", seqId,"未找到与"+sourceName+"匹配的接口"));
                        response=ResponseUtils.makeXzResponse("-1","号码池中没有该号码或没有权限访问接口",null);
                        break;
			}
			return response;

		} catch (Exception e) {
			loggerException.error(String.format("seqid=%s,Exception=%s", seqId, e.toString().replaceAll("\n", "|")));
			return ResponseUtils.makeXzResponse("-1","服务器异常",null);
		}
	}

	/**
	 * ax解绑接口
	 * 
	 * @param bindVo
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/unbind")
	public Object unbind(XzDataBindVo bindVo) {
		// 生成一个SequenceId,用于记录日志
		String seqId = UUID.randomUUID().toString();
		// 通过getParameterMap获取"相对"原始的请求参数,分别存放在requestContent（用于记录日志）和parameterMap（用于计算签名）。通过spring注入bean获取的参数会忽略掉bean里不需要的参数
		String requestContent = "";
		Map<String, String> parameterMap = new HashMap<String, String>();
		for (Iterator<Entry<String, String[]>> iter = request.getParameterMap().entrySet().iterator(); iter
				.hasNext();) {
			Entry<String, String[]> entry = iter.next();
			String key = entry.getKey();
			String vals = "";
			for (String val : entry.getValue()) {
				vals += val;
			}
			if (requestContent != "")
				requestContent += "&";
			requestContent += key + "=" + vals;
			if (!key.equals("sign"))
				parameterMap.put(key, vals);
		}
		loggerSingleWork.info(String.format("seqid=%s,request=%s?%s", seqId, request.getRequestURI(), requestContent));

		// 公众参数合法性检查
		String errMsg = bindVo.checkCommon();
		if (StringUtils.isNotBlank(errMsg)) {
			Object response = ResponseUtils.makeXzResponse("101", errMsg,null);
			loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
			return response;
		}

		// 绑定参数合法性检查
		errMsg = bindVo.checkUnBind(regex);
		if (StringUtils.isNotBlank(errMsg)) {
			Object response = ResponseUtils.makeXzResponse("101",  errMsg,null);
			loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
			return response;
		}

		if (!StringUtils.equals("0", bindVo.getUnitId())) {
			// 根据unitid获取secret(用于计算签名)，后续考虑将secret放在缓存中
			String secret = unitService.getSecret(bindVo.getUnitId(), bindVo.getAppkey());
			if (StringUtils.isBlank(secret)) {
				Object response = ResponseUtils.makeXzResponse("101", "使用了错误的unitID或appkey",null);
				loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
				return response;
			}

			// 签名检查
			try {
				if (!bindVo.getSign().equalsIgnoreCase(SignUtils.signTopRequest(parameterMap, secret, "MD5"))) {
					loggerSingleWork.info(String.format("seqid=%s,calculate_sign=%s", seqId,
							SignUtils.signTopRequest(parameterMap, secret, "MD5")));
					Object response = ResponseUtils.makeXzResponse("101",  "签名错误",null);
					loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
					return response;
				}
			} catch (IOException e) {
				loggerException
						.error(String.format("seqid=%s,Exception=%s", seqId, e.toString().replaceAll("\n", "|")));
				return ResponseUtils.makeXzResponse("-1","服务器异常",null);
			}
		}
		//根据subid判断调用哪个接口。TReginfo selectByPrimaryKey(Long subid)
		//TReginfo source= tReginfoMapper.selectByPrimaryKey(Long.parseLong(bindVo.getSubId()));
		TReginfoExample example = new TReginfoExample();
		TReginfoExample.Criteria criteria = example.createCriteria();
		criteria.andCardnoEqualTo(bindVo.getSubId());
		List<TReginfo> reginfos = tReginfoMapper.selectByExample(example);
		if(reginfos==null||reginfos.size()<1) {
			return ResponseUtils.makeXzResponse("0","success",null);
		}
		//服务器返回结果
		JSONObject response ;
		try {
            //根据unitId获取企业应该调用的接口。switch形式方便后续添加运营商。
            //TUnit unit = unitDao.selectByPrimaryKey(bindVo.getUnitId());
			String sourceName=reginfos.get(0).getName();
			bindVo.setName(sourceName);
			switch(sourceName){
				case "xzxz1":
					//讯众旧接口;
					response = (JSONObject) xzBindService.unbind(loggerSingleWork, bindVo, seqId);
					loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
					break;
				case "xzxz2":
					//讯众新接口;
					response = (JSONObject) xzBindService2.unbind(loggerSingleWork, bindVo, seqId);
					loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
					break;
				default:
					//数据库source名称维护错误的接口
					loggerException.error(String.format("seqid=%s,Exception=%s", seqId,"未找到与"+sourceName+"匹配的接口"));
					response=ResponseUtils.makeXzResponse("-1","号码池中没有该号码或没有权限访问接口",null);
					break;
			}
			return response;
		} catch (Exception e) {
			loggerException.error(String.format("seqid=%s,Exception=%s", seqId, e.toString().replaceAll("\n", "|")));
			return ResponseUtils.makeXzResponse("-1","服务器异常",null);
		}
	}

	
	/**
	 * ax关系绑定b
	 * 
	 * @param bindVo
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/bindingB")
	public Object bindingB(XzDataBindVo bindVo) {
		// 生成一个SequenceId,用于记录日志
		String seqId = UUID.randomUUID().toString();
		// 通过getParameterMap获取"相对"原始的请求参数,分别存放在requestContent（用于记录日志）和parameterMap（用于计算签名）。通过spring注入bean获取的参数会忽略掉bean里不需要的参数
		String requestContent = "";
		Map<String, String> parameterMap = new HashMap<String, String>();
		for (Iterator<Entry<String, String[]>> iter = request.getParameterMap().entrySet().iterator(); iter
				.hasNext();) {
			Entry<String, String[]> entry = iter.next();
			String key = entry.getKey();
			String vals = "";
			for (String val : entry.getValue()) {
				vals += val;
			}
			if (requestContent != "")
				requestContent += "&";
			requestContent += key + "=" + vals;
			if (!key.equals("sign"))
				parameterMap.put(key, vals);
		}
		loggerSingleWork.info(String.format("seqid=%s,request=%s?%s", seqId, request.getRequestURI(), requestContent));

		// 公众参数合法性检查
		String errMsg = bindVo.checkCommon();
		if (StringUtils.isNotBlank(errMsg)) {
			Object response = ResponseUtils.makeXzResponse("101",  errMsg,null);
			loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
			return response;
		}

		// 绑定参数合法性检查
		errMsg = bindVo.checkAxTobBind(regex);
		if (StringUtils.isNotBlank(errMsg)) {
			Object response = ResponseUtils.makeXzResponse("101", errMsg,null);
			loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
			return response;
		}

		if (!StringUtils.equals("0", bindVo.getUnitId())) {
			// 根据unitid获取secret(用于计算签名)，后续考虑将secret放在缓存中
			String secret = unitService.getSecret(bindVo.getUnitId(), bindVo.getAppkey());
			if (StringUtils.isBlank(secret)) {
				Object response = ResponseUtils.makeXzResponse("101",  "使用了错误的unitID或appkey",null);
				loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
				return response;
			}

			// 签名检查
			try {
				if (!bindVo.getSign().equalsIgnoreCase(SignUtils.signTopRequest(parameterMap, secret, "MD5"))) {
					loggerSingleWork.info(String.format("seqid=%s,calculate_sign=%s", seqId,
							SignUtils.signTopRequest(parameterMap, secret, "MD5")));
					Object response = ResponseUtils.makeXzResponse("101",  "签名错误",null);
					loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
					return response;
				}
			} catch (IOException e) {
				loggerException
						.error(String.format("seqid=%s,Exception=%s", seqId, e.toString().replaceAll("\n", "|")));
				return ResponseUtils.makeXzResponse("-1","服务器异常",null);
			}
		}
		//根据subid判断调用哪个接口。TReginfo selectByPrimaryKey(Long subid)
		TReginfoExample example = new TReginfoExample();
		TReginfoExample.Criteria criteria = example.createCriteria();
		criteria.andCardnoEqualTo(bindVo.getSubId());
		List<TReginfo> reginfos = tReginfoMapper.selectByExample(example);
		if(reginfos==null||reginfos.size()<1) {
			loggerException.error(String.format("seqid=%s,Exception=%s", seqId, "号码池中没有该号码或没有权限访问接口!"));
			return ResponseUtils.makeXzResponse("-1", "号码池中没有该号码或没有权限访问接口", null);
		}
		//服务器返回结果
		JSONObject response ;
		try {
            //根据unitId获取企业应该调用的接口。switch形式方便后续添加运营商。
            //TUnit unit = unitDao.selectByPrimaryKey(bindVo.getUnitId());
            String sourceName=reginfos.get(0).getName();
			bindVo.setName(sourceName);
			switch(sourceName){
				case "xzxz1":
					//讯众旧接口;
					response =  (JSONObject) xzBindService.bindSingleTob(loggerSingleWork, bindVo, seqId);
					loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
					break;
				case "xzxz2":
					//讯众新接口;
					response =  (JSONObject) xzBindService2.bindSingleTob(loggerSingleWork, bindVo, seqId);
					loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
					break;
				default:
					//数据库source名称维护错误的接口
					loggerException.error(String.format("seqid=%s,Exception=%s", seqId,"未找到与"+sourceName+"匹配的接口"));
					response=ResponseUtils.makeXzResponse("-1","号码池中没有该号码或没有权限访问接口",null);
					break;
			}
			return response;
		} catch (Exception e) {
			loggerException.error(String.format("seqid=%s,Exception=%s", seqId, e.toString().replaceAll("\n", "|")));
			return ResponseUtils.makeXzResponse("-1","服务器异常",null);
		}
	}
	/**
	 * ax延期接口
	 * 
	 * @param bindVo
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/updateBind")
	public Object updateBind(XzDataBindVo bindVo) {
		// 生成一个SequenceId,用于记录日志
		String seqId = UUID.randomUUID().toString();
		// 通过getParameterMap获取"相对"原始的请求参数,分别存放在requestContent（用于记录日志）和parameterMap（用于计算签名）。通过spring注入bean获取的参数会忽略掉bean里不需要的参数
		String requestContent = "";
		Map<String, String> parameterMap = new HashMap<String, String>();
		for (Iterator<Entry<String, String[]>> iter = request.getParameterMap().entrySet().iterator(); iter
				.hasNext();) {
			Entry<String, String[]> entry = iter.next();
			String key = entry.getKey();
			String vals = "";
			for (String val : entry.getValue()) {
				vals += val;
			}
			if (requestContent != "")
				requestContent += "&";
			requestContent += key + "=" + vals;
			if (!key.equals("sign"))
				parameterMap.put(key, vals);
		}
		loggerSingleWork.info(String.format("seqid=%s,request=%s?%s", seqId, request.getRequestURI(), requestContent));

		// 公众参数合法性检查
		String errMsg = bindVo.checkCommon();
		if (StringUtils.isNotBlank(errMsg)) {
			Object response = ResponseUtils.makeXzResponse("101", errMsg,null);
			loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
			return response;
		}

		// 绑定参数合法性检查
		errMsg = bindVo.checkUpdateBind(regex);
		if (StringUtils.isNotBlank(errMsg)) {
			Object response = ResponseUtils.makeXzResponse("101", errMsg,null);
			loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
			return response;
		}

		if (!StringUtils.equals("0", bindVo.getUnitId())) {
			// 根据unitid获取secret(用于计算签名)，后续考虑将secret放在缓存中
			String secret = unitService.getSecret(bindVo.getUnitId(), bindVo.getAppkey());
			if (StringUtils.isBlank(secret)) {
				Object response = ResponseUtils.makeXzResponse("101", "使用了错误的unitID或appkey",null);
				loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
				return response;
			}

			// 签名检查
			try {
				if (!bindVo.getSign().equalsIgnoreCase(SignUtils.signTopRequest(parameterMap, secret, "MD5"))) {
					loggerSingleWork.info(String.format("seqid=%s,calculate_sign=%s", seqId,
							SignUtils.signTopRequest(parameterMap, secret, "MD5")));
					Object response = ResponseUtils.makeXzResponse("101", "签名错误", null);
					loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
					return response;
				}
			} catch (IOException e) {
				loggerException
						.error(String.format("seqid=%s,Exception=%s", seqId, e.toString().replaceAll("\n", "|")));
				return ResponseUtils.makeXzResponse("-1","服务器异常",null);
			}
		}
		//根据subid判断调用哪个接口。TReginfo selectByPrimaryKey(Long subid)
		TReginfoExample example = new TReginfoExample();
		TReginfoExample.Criteria criteria = example.createCriteria();
		criteria.andCardnoEqualTo(bindVo.getSubId());
		List<TReginfo> reginfos = tReginfoMapper.selectByExample(example);
		if(reginfos==null||reginfos.size()<1){
			loggerException.error(String.format("seqid=%s,Exception=%s", seqId, "号码池中没有该号码或没有权限访问接口!"));
			return ResponseUtils.makeXzResponse("-1", "号码池中没有该号码或没有权限访问接口", null);
		}
		//服务器返回结果
		JSONObject response ;
		try {
            //根据unitId获取企业应该调用的接口。switch形式方便后续添加运营商。
            //TUnit unit = unitDao.selectByPrimaryKey(bindVo.getUnitId());
            String sourceName=reginfos.get(0).getName();
			bindVo.setName(sourceName);
			switch(sourceName){
				case "xzxz1":
					//讯众旧接口;
					response =  (JSONObject) xzBindService.updateBind(loggerSingleWork, bindVo, seqId);
					loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
					break;
				case "xzxz2":
					//讯众新接口;
					response =  (JSONObject) xzBindService2.updateBind(loggerSingleWork, bindVo, seqId);
					loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
					break;
				default:
					//数据库source名称维护错误的接口
					loggerException.error(String.format("seqid=%s,Exception=%s", seqId,"未找到与"+sourceName+"匹配的接口"));
					response=ResponseUtils.makeXzResponse("-1","号码池中没有该号码或没有权限访问接口",null);
					break;
			}
			return response;
		} catch (Exception e) {
			loggerException.error(String.format("seqid=%s,Exception=%s", seqId, e.toString().replaceAll("\n", "|")));
			return ResponseUtils.makeXzResponse("-1","服务器异常",null);
		}
	}
    /**
     * 批量更新
     *
     * @return
     */
    @ResponseBody
    @RequestMapping("/updateNumber")
    public void updateNumber() {
        String seqId = UUID.randomUUID().toString();
        //设置所需参数
        //subts,变更时间，ts
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmssSSS");
        SimpleDateFormat sdf2 = new SimpleDateFormat("yyyyMMddHHmmss");
        String ts=sdf.format(new Date());
        String subts=sdf2.format(new Date());
		DmDataBindVo bindVo=new DmDataBindVo();
        bindVo.setTs(ts);
        bindVo.setSubts(subts);
//        bindVo.setSubId("C1129X028X0278563933-00-0-XZGF-GXI");
        bindVo.setSmsmtchannel("2");
        //读取数据
        //String filename = "/src/main/resources/data.txt";
		String path =this.getClass().getClassLoader().getResource("./data.txt").getPath();
		Map<Integer, String> fileMaps = readTxtFile(path);
		int num = fileMaps.size();// 行数
		for (int i = 0; i < num; i++) {
			String subId = fileMaps.get(i);
            bindVo.setSubId(subId);
            //调用修改接口
            try {
				dmBindService.updateBindOnly(loggerSingleWork, bindVo, seqId);
            } catch (Exception e) {
				System.out.println("catch a exception");
            }
		}
    }
    public static Map<Integer,String> readTxtFile(String filePath) {

        //存放内容的map对象
        Map<Integer,String> filemaps = new HashMap<Integer,String>();
        try {
            String encoding = "GBK";
            File file = new File(filePath);
            int count = 0;//定义顺序变量
            if (file.isFile() && file.exists()) { // 判断文件是否存在
                InputStreamReader read = new InputStreamReader(
                        new FileInputStream(file), encoding);// 考虑到编码格式
                BufferedReader bufferedReader = new BufferedReader(read);
                String lineTxt = null;
                while ((lineTxt = bufferedReader.readLine()) != null) {//按行读取
                    if(!"".equals(lineTxt)){
                        String reds = lineTxt.split("\\+")[0];//对行的内容进行分析处理后再放入map里。
                        filemaps.put(count, reds);//放入map
                        count ++;
                    }
                }
                read.close();//关闭InputStreamReader
                bufferedReader.close();//关闭BufferedReader
            } else {
                System.out.println("not find");
            }
        } catch (Exception e) {
            System.out.println("wrong");
            e.printStackTrace();
        }
        return filemaps;
    }

}
 

