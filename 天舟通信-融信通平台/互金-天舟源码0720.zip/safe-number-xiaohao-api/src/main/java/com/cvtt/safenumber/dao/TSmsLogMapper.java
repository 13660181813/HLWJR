package com.cvtt.safenumber.dao;

import java.util.List;

import com.cvtt.safenumber.pojo.TSmsLog;
import com.cvtt.safenumber.pojo.TSmsLogExample;
import org.apache.ibatis.annotations.Param;

public interface TSmsLogMapper {
    long countByExample(TSmsLogExample example);

    int deleteByExample(TSmsLogExample example);

    int insert(TSmsLog record);

    int insertSelective(TSmsLog record);

    List<TSmsLog> selectByExample(TSmsLogExample example);

    int updateByExampleSelective(@Param("record") TSmsLog record, @Param("example") TSmsLogExample example);

    int updateByExample(@Param("record") TSmsLog record, @Param("example") TSmsLogExample example);
}