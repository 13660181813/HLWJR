/**
 * 讯众小号推送话单类
 */
package com.cvtt.safenumber.controller.dianhui;

import com.alibaba.fastjson.JSONObject;
import com.cvtt.safenumber.dao.TUnitInfoMapper;
import com.cvtt.safenumber.dao.TUnitMapper;
import com.cvtt.safenumber.pojo.TReginfo;
import com.cvtt.safenumber.pojo.TReginfoExample;
import com.cvtt.safenumber.pojo.TUnit;
import com.cvtt.safenumber.pojo.TUnitInfo;
import com.cvtt.safenumber.pojo.TUnitInfoExample;
import com.cvtt.safenumber.service.ICallService;
import com.cvtt.safenumber.service.IDownloadService;
import com.cvtt.safenumber.service.IReginfoService;
import com.cvtt.safenumber.service.IUnitService;
import com.cvtt.safenumber.service.dianhui.IDianhuiBindService;
import com.cvtt.safenumber.utils.DateUtils;
import com.cvtt.safenumber.utils.JsonUtils;
import com.cvtt.safenumber.utils.ResponseUtils;
import com.cvtt.safenumber.utils.SignUtils;
import com.cvtt.safenumber.vo.CallReleaseVo;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.io.BufferedReader;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.UUID;


@SuppressWarnings("all")
@Controller
@RequestMapping("/v2/axb")
public class DHCallManage {
    @Autowired
    private HttpServletRequest request;
    @Resource
    private IUnitService unitService;
    @Resource
    private ICallService callService;
    @Resource
    private IReginfoService reginfoService;
    @Resource
    private TUnitInfoMapper infoDao;
    @Resource
    private TUnitMapper unitDao;
    @Resource
    private IDownloadService iDownloadService;
    @Resource
    private IDianhuiBindService dianhuiBindService;
    @Value("${recordUrl}")
    private String RECORDURL;
    @Value("${dowmloadTime}")
    private String WAITSECOND;


    private static Logger loggerSingleWork = Logger.getLogger("DataManage.SingleWork");
    private static Logger loggerBatchWork = Logger.getLogger("DataManage.BatchWork");
    private static Logger loggerException = Logger.getLogger("Sys.Exception");
    private static String sdf = "yyyyMMddHHmmss";

    /**
     * 结束通话接口
     *
     * @param bindVo
     * @return
     */
    @ResponseBody
    @RequestMapping("/finish")
    public Object finish() {
        String seqId = UUID.randomUUID().toString();
        JSONObject response = ResponseUtils.makeYdResponse("0000", "success");
        try {
            Map<String, String> map = getParaMap();
            // 生成一个SequenceId,用于记录日志
            // 通过getParameterMap获取"相对"原始的请求参数,分别存放在requestContent（用于记录日志）和parameterMap（用于计算签名）。通过spring注入bean获取的参数会忽略掉bean里不需要的参数
            String requestContent = "";
            for (Entry<String, String> entry : map.entrySet()) {
                String	key = entry.getKey();
                String	value = entry.getValue();
                if (requestContent != "") {
                    requestContent += "&";
                }
                requestContent += key + "=" + value;
            }
            loggerSingleWork
                    .info(String.format("seqid=%s,request=%s?%s", seqId, request.getRequestURI(), requestContent));

            // 签名验证最后加
            // 绑定参数合法性检查
            String telA ="";
            String telB ="";
            String telX ="";
            String calltype="";
            String requestId = seqId;
            String subId = map.get("subid");
            String callid = map.get("callid");
            String startTime= map.get("starttime");
            String recordUrl ="";
            String releaseTime="";
            int type=2;

            //根据subid查询绑定数据，没有查到绑定关系则直接返回200成功。
            TReginfoExample example = new TReginfoExample();
            TReginfoExample.Criteria criteria = example.createCriteria();
            criteria.andCardnoEqualTo(subId);
            List<TReginfo> tReginfos = reginfoService.selectByExample(example);
            if (tReginfos.size() == 0) {
                loggerSingleWork.info(String.format("seqid=%s,info=%s", seqId, "subId在TReginfo没找到对应的数据:"+subId));
                loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
                return response;
            }

            //话单参数
            String unitId = tReginfos.get(0).getUnitid();
            String callrecording=tReginfos.get(0).getCallrecording();
            CallReleaseVo releaseVo = new CallReleaseVo();


            if(map.containsKey("calltype")&&StringUtils.equals(map.get("calltype"),"12")){
                //此为短信话单
                Date now=new Date();
                map.put("starttime",DateUtils.formatSync8(now,sdf));
                calltype="12";
                telA = map.get("telA");
                telX = map.get("telX");
                telB = map.get("telB");
                releaseVo.setTime_start(now);
                type=4;
            }else{
                //非短信话单
                 releaseTime= map.get("releasetime");
                //传来的主被叫
                String callerNumber = map.get("callerNumber");
                String calledNumber = map.get("calledNumber");

                telX = map.get("xNumber");
                telA = map.get("callerNumber");
                telB = map.get("calledNumber");
                //根据绑定关系查询绑定的号码，号码为主叫号码的话则calltype=0，被叫号码的话则calltype=1
                if (StringUtils.equals(callerNumber, tReginfos.get(0).getRegphone())) {
                    //A号码为主叫
                    calltype = "0";
                } else if (StringUtils.equals(calledNumber, tReginfos.get(0).getRegphone())) {
                    //A号码为被叫,telA、telB需要颠倒一下
                    calltype = "1";
                    telB = map.get("callerNumber");
                    telA = map.get("calledNumber");
                } else {
                    loggerSingleWork.info(String.format("seqid=%s,info=%s", seqId, "该subId的calltype为空："+subId+",原因为,callerNumber:"
                            +callerNumber+",calledNumber:"+calledNumber+",regPhone:"+tReginfos.get(0).getRegphone()));
                }
                //非短信话单参数
                releaseVo.setTime_release(DateUtils.parseSync8(releaseTime,sdf));
                releaseVo.setTime_start(DateUtils.parseSync8(startTime,sdf));


                releaseVo.setRelease_cause(map.get("releasecause"));
                recordUrl = null==map.get("recordUrl")?"":map.get("recordUrl");
                releaseVo.setRecording_file(recordUrl);
                if (!StringUtils.isEmpty(recordUrl)) {
                    //保存录音文件到本地
                    String urlPath = recordUrl;
                    //获取录音文件名
                    String recordName = StringUtils.substringAfterLast(urlPath, "/");
                    if(recordUrl.contains("recordKey")){
                        recordName=callid+".wav";
                    }
                    Date now = new Date();
                    SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd");
                    String DateNow = sdf2.format(now);
                    String saveDir = RECORDURL + "/recordings/" + unitId + "/" + DateNow + "/" + recordName;
                    //下载录音
                    iDownloadService.downloadFile(urlPath, saveDir, seqId, WAITSECOND);
                    String newRecordUrl = unitId + "/" + DateNow + "/" + recordName;
                    recordUrl=newRecordUrl;
                }
            }

            //短信话单和电话结束话单共有参数
            releaseVo.setCall_id(callid);
            releaseVo.setNo_a(telA);
            releaseVo.setNo_x(telX);
            releaseVo.setNo_b(telB);
            releaseVo.setRequest_id(requestId);
            releaseVo.setPartner_id(unitId);
            releaseVo.setCalltype(calltype);
            releaseVo.setSubid(subId);
            String companyName= tReginfos.get(0).getName();
            releaseVo.setVoicemail_file(companyName);

            TUnitInfoExample infoExample = new TUnitInfoExample();
            TUnitInfoExample.Criteria infoCriteria = infoExample.createCriteria();
            infoCriteria.andUnitidEqualTo(unitId);
            List<TUnitInfo> infos = infoDao.selectByExample(infoExample);
            if (infos.size() > 0) {
                TUnitInfo info = infos.get(0);
                if (StringUtils.isNotBlank(info.getCdrUrl())) {
                    Map<String, String> sendMap=new HashMap<>();
                    //话单公共推送参数
                    sendMap.put("telA", telA);
                    sendMap.put("telX", telX);
                    sendMap.put("telB", telB);
                    sendMap.put("calltype", calltype);
                    sendMap.put("callid", callid);
                    sendMap.put("subid", subId);
                    if(!(map.containsKey("calltype")&&StringUtils.equals(map.get("calltype"),"12"))) {
                        //此为非短信话单
                        sendMap.put("starttime", startTime);
                        sendMap.put("releasetime",releaseTime);
                        //当收到点慧的话单starttime与releasetime不一致的时候，
                        //给客户推送的话单中增加ringingtime和calltime参数，取值为starttime的值；
                        String ringingtime="";
                        String calltime="";
                        if(!StringUtils.equals(startTime,releaseTime)){
                            sendMap.put("ringingtime", startTime);
                            sendMap.put("calltime",startTime);
                            //当收到点慧的话单starttime与releasetime一致的时候，此为未接通话单，写入数据库的answertime目前有值，不需要
                            releaseVo.setTime_answer(DateUtils.parseSync8(startTime,sdf));
                        }else{
                            //当收到点慧的话单starttime与releasetime一致的时候，
                            //给客户推送的话单推送calltime（取值为starttime的值）和releasetime，ringingtime和starttime也要推，值为空值
                            sendMap.put("calltime",startTime);
                            sendMap.put("releasetime", releaseTime);
                            sendMap.put("ringingtime", "");
                            sendMap.put("starttime", "");
                        }
                        sendMap.put("recordUrl",recordUrl);
                        sendMap.put("releasecause",map.get("releasecause"));
                        sendMap.put("releasedir","1");
                        sendMap.put("callrecording",callrecording);
                    }else{
                        sendMap.put("calltime", map.get("starttime"));
                    }

                    //其它通用参数
                    TUnit unit = unitDao.selectSecretByUnitid(unitId);
                    String secret = unitService.getSecret(unitId, unit.getUnitkey());
                    sendMap.put("unitId", unitId);
                    sendMap.put("appkey", unit.getUnitkey());
                    String url = info.getCdrUrl() + "/v2/ax/finish";
                    String sign = SignUtils.signTopRequest(sendMap, secret, "MD5");
                    sendMap.put("sign", sign);
                    //给客户传话单
                    dianhuiBindService.pushCdr(loggerSingleWork, sendMap, seqId, url);
                }

            }else {
                loggerSingleWork.info(String.format("seqid=%s,info=%s", seqId, "subId在TUnitInfo没找到对应的数据:"+subId));
            }
            //写话单、更新话单等操作。和移动小号一样
            callService.callRelease10086(loggerSingleWork, releaseVo, seqId,type);

        } catch (Exception e) {
            loggerException.error("error,",e);
            loggerException.error(String.format("seqid=%s,Exception=%s", seqId, e.toString().replaceAll("\n", "|")));
        }
        loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
        return response;
    }

    /**
     * 录音推送接口
     *
     * @param bindVo
     * @return
     */
    @ResponseBody
    @RequestMapping("/record")
    public Object record() {
        String seqId = UUID.randomUUID().toString();
        JSONObject response = ResponseUtils.makeYdResponse("0000", "success");
        try {
            Map<String, String> map = getParaMap();
            // 生成一个SequenceId,用于记录日志
            // 通过getParameterMap获取"相对"原始的请求参数,分别存放在requestContent（用于记录日志）和parameterMap（用于计算签名）。通过spring注入bean获取的参数会忽略掉bean里不需要的参数
            String requestContent = "";
            for (Entry<String, String> entry : map.entrySet()) {
                String key = entry.getKey();
                String value = entry.getValue();
                if (requestContent != "") {
                    requestContent += "&";
                }
                requestContent += key + "=" + value;
            }
            loggerSingleWork
                    .info(String.format("seqid=%s,request=%s?%s", seqId, request.getRequestURI(), requestContent));

            // 签名验证最后加
            // 绑定参数合法性检查
            String subId = map.get("subid");
            String callid = map.get("callid");
            String recordUrl=map.get("recordUrl");
            String requestId = seqId;

            TReginfoExample example = new TReginfoExample();
            TReginfoExample.Criteria criteria = example.createCriteria();
            criteria.andCardnoEqualTo(subId);
            List<TReginfo> tReginfos = reginfoService.selectByExample(example);
            if (tReginfos.size() == 0) {
                loggerSingleWork.info(String.format("seqid=%s,info=%s", seqId, "subId在TReginfo没找到对应的数据:"+subId));
                loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
                return response;
            }
            String unitId = tReginfos.get(0).getUnitid();

            CallReleaseVo releaseVo = new CallReleaseVo();
            releaseVo.setCall_id(callid);
            releaseVo.setRequest_id(requestId);
            releaseVo.setPartner_id(unitId);
            releaseVo.setSubid(subId);
            releaseVo.setRecording_file(recordUrl);
            releaseVo.setTime_start(new Date());
            //录音的calltype
            releaseVo.setCalltype("4");
            String companyName= tReginfos.get(0).getName();
            releaseVo.setVoicemail_file(companyName);

            TUnitInfoExample infoExample = new TUnitInfoExample();
            TUnitInfoExample.Criteria infoCriteria = infoExample.createCriteria();
            infoCriteria.andUnitidEqualTo(unitId);
            List<TUnitInfo> infos = infoDao.selectByExample(infoExample);

            if (infos.size() > 0) {
                TUnitInfo info = infos.get(0);
                if (StringUtils.isNotBlank(info.getCdrUrl())) {
                    Map<String, String> sendMap=new HashMap<>();
                    //参数
                    sendMap.put("subid", subId);
                    sendMap.put("callid", callid);
                    //通用参数
                    TUnit unit = unitDao.selectSecretByUnitid(unitId);
                    String secret = unitService.getSecret(unitId, unit.getUnitkey());
                    sendMap.put("unitId", unitId);
                    sendMap.put("appkey", unit.getUnitkey());
                    String url = info.getCdrUrl() + "/v2/ax/record";
                    //录音文件不为空时，并且将传递的录音文件地址进行修改。需要将签名放在recordUrl下方。否则会报签名错误。
                    if(!StringUtils.isEmpty(recordUrl)){
                        //保存录音文件到本地
                        String urlPath=recordUrl;
                        //获取录音文件名
                        String recordName=StringUtils.substringAfterLast(urlPath,"/");
                        Date now=new Date();
                        SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd");
                        String DateNow=sdf2.format(now);
                        String saveDir=RECORDURL+"/recordings/"+unitId+"/"+DateNow+"/"+recordName;
                        //下载
                        iDownloadService.downloadFile(urlPath, saveDir,seqId,WAITSECOND);
                        String newRecordUrl=unitId+"/"+DateNow+"/"+recordName;
                        sendMap.put("recordUrl", newRecordUrl);
                    }
                    String sign = SignUtils.signTopRequest(sendMap, secret, "MD5");
                    sendMap.put("sign", sign);
                    dianhuiBindService.pushCdr(loggerSingleWork, sendMap, seqId, url);
                }

            }else {
                loggerSingleWork.info(String.format("seqid=%s,info=%s", seqId, "subId在TUnitInfo没找到对应的数据:"+subId));
            }
            //写话单、更新话单等操作。和移动小号一样
            callService.callRelease10086(loggerSingleWork, releaseVo, seqId,3);
        } catch (Exception e) {
            loggerException.error(String.format("seqid=%s,Exception=%s", seqId, e.toString().replaceAll("\n", "|")));
        }
        loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
        return response;
    }

    private Map<String, String> getParaMapJson() {
        BufferedReader reader = null;
        StringBuffer sb = new StringBuffer();
        try {
            reader = request.getReader();
            String str;
            while ((str = reader.readLine()) != null) {
                sb.append(str);
            }
            reader.close();
        } catch (Exception e) {
            // TODO: handle exception
        } finally {
            if (null != reader) {
                try {
                    reader.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
        return JsonUtils.jsonToPojo(sb.toString(), Map.class);
    }
    private Map<String, String> getParaMap() {
        String requestContent = "";
        Map<String, String> parameterMap = new HashMap<String, String>();
        for (Iterator<Entry<String, String[]>> iter = request.getParameterMap().entrySet().iterator(); iter
                .hasNext(); ) {
            Entry<String, String[]> entry = iter.next();
            String key = entry.getKey();
            String vals = "";
            for (String val : entry.getValue()) {
                vals += val;
            }
            if (requestContent != "")
                requestContent += "&";
            requestContent += key + "=" + vals;
            if (!key.equals("sid"))
                parameterMap.put(key, vals);
        }
        return parameterMap;
    }
}
