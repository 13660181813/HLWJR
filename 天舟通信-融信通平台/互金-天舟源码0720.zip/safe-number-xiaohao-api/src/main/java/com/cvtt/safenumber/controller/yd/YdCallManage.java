/**
 * 讯众小号推送话单类
 */
package com.cvtt.safenumber.controller.yd;

import com.alibaba.fastjson.JSONObject;
import com.cvtt.safenumber.crypt.ADESUtils;
import com.cvtt.safenumber.dao.TUnitInfoMapper;
import com.cvtt.safenumber.dao.TUnitMapper;
import com.cvtt.safenumber.pojo.Arc95013;
import com.cvtt.safenumber.pojo.Arc95013Example;
import com.cvtt.safenumber.pojo.TReginfo;
import com.cvtt.safenumber.pojo.TReginfoExample;
import com.cvtt.safenumber.pojo.TUnit;
import com.cvtt.safenumber.pojo.TUnitInfo;
import com.cvtt.safenumber.pojo.TUnitInfoExample;
import com.cvtt.safenumber.service.ICallService;
import com.cvtt.safenumber.service.IDownloadService;
import com.cvtt.safenumber.service.IReginfoService;
import com.cvtt.safenumber.service.IUnitService;
import com.cvtt.safenumber.service.xz.IxzBindService;
import com.cvtt.safenumber.service.yd.YdBindService;
import com.cvtt.safenumber.utils.DateUtils;
import com.cvtt.safenumber.utils.JsonUtils;
import com.cvtt.safenumber.utils.ResponseUtils;
import com.cvtt.safenumber.utils.SignUtils;
import com.cvtt.safenumber.vo.CallReleaseVo;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.io.BufferedReader;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.UUID;

@SuppressWarnings("all")
@Controller
@RequestMapping("/v2/ax/yd/")
public class YdCallManage {
	@Autowired
	private HttpServletRequest request;
	@Resource
	private IUnitService unitService;
	@Resource
	private YdBindService ydBindService;

	@Resource
	private ICallService callService;

	@Resource
	private IReginfoService reginfoService;

	@Resource
	private TUnitInfoMapper infoDao;
	@Resource
	private TUnitMapper unitDao;
	@Resource
	private IDownloadService iDownloadService;


	@Value("${recordUrl}")
	private String RECORDURL;
	@Value("${dowmloadTime}")
	private String  WAITSECOND;

	private static Logger loggerSingleWork = Logger.getLogger("DataManage.SingleWork");
	private static Logger loggerBatchWork = Logger.getLogger("DataManage.BatchWork");
	private static Logger loggerException = Logger.getLogger("Sys.Exception");
	private static String sdf = "yyyyMMddHHmmss";

	/**
	 * 开始通话接口
	 *
	 * @param bindVo
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/callin")
	public Object callin() {
		String seqId = UUID.randomUUID().toString();
		JSONObject response = ResponseUtils.makeYdResponse("0000", "成功");
		try {
			Map<String, String> map = getParaMap();
			// 生成一个SequenceId,用于记录日志
			// 通过getParameterMap获取"相对"原始的请求参数,分别存放在requestContent（用于记录日志）和parameterMap（用于计算签名）。通过spring注入bean获取的参数会忽略掉bean里不需要的参数
			String requestContent = "";
			for (Entry<String, String> entry : map.entrySet()) {
				String key = entry.getKey();
				String value = entry.getValue();

				if (requestContent != "") {
					requestContent += "&";
				}
				requestContent += key + "=" + value;
			}
			loggerSingleWork
					.info(String.format("seqid=%s,request=%s?%s", seqId, request.getRequestURI(), requestContent));
			// 签名验证最后加
			// 绑定参数合法性检查
			String subId = map.get("bindId");
			String callid = map.get("callId");
			String telA = map.get("callNo");
			String telX = map.get("telX");
			String telB = map.get("peerNo");
			String requestId = map.get("seqId");
            //根据subid查询绑定数据，没有查到绑定关系则直接返回200成功。
			TReginfoExample example = new TReginfoExample();
			TReginfoExample.Criteria criteria = example.createCriteria();
			criteria.andCardnoEqualTo(subId);
			List<TReginfo> tReginfos = reginfoService.selectByExample(example);
			if (tReginfos.size() == 0) {
				loggerSingleWork.info(String.format("seqid=%s,info=%s", seqId, "subId在TReginfo没找到对应的数据:"+subId));
				loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
				return response;
			}
			//根据绑定关系查询绑定的号码，号码为主叫号码的话则calltype=0，被叫号码的话则calltype=1
			String calltype="";
			if(StringUtils.equals(telA,tReginfos.get(0).getRegphone())){ calltype="0";}
			else  if(StringUtils.equals(telB,tReginfos.get(0).getRegphone())){ calltype="1";}
			else {
				loggerSingleWork.info(String.format("seqid=%s,info=%s", seqId, "该subId的calltype为空："+subId+",原因为,telA:"
						+telA+",telB:"+telB+",regPhone:"+tReginfos.get(0).getRegphone()));
			}
			String unitId = tReginfos.get(0).getUnitid();
			CallReleaseVo releaseVo = new CallReleaseVo();
			releaseVo.setCall_id(callid);
			releaseVo.setNo_a(telA);
			releaseVo.setNo_x(telX);
			releaseVo.setNo_b(telB);
			releaseVo.setTime_start(DateUtils.parseSync8(map.get("callTime"),sdf));
			releaseVo.setRequest_id(requestId);
			releaseVo.setPartner_id(unitId);
			releaseVo.setCalltype(calltype);
			releaseVo.setSubid(subId);
			releaseVo.setAreacode(map.get("areaCode"));
			//判断话单是否重复，话单重复则写入一条日志，话单不重复则根据绑定关系判断是主叫还是被叫，写入话单。
			callService.callRelease10086(loggerSingleWork, releaseVo, seqId,1);

		} catch (Exception e) {
			e.printStackTrace();
			loggerException.error(String.format("seqid=%s,Exception=%s", seqId, e.toString().replaceAll("\n", "|")));
		}
		loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
		return response;
	}

	/**
	 * 结束通话接口
	 * 
	 * @param bindVo
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/finish")
	public Object finish() {
		String seqId = UUID.randomUUID().toString();
		JSONObject response = ResponseUtils.makeYdResponse("0000", "success");
		try {
			Map<String, String> map = getParaMap();
			if(map.containsKey("callDuration"))
			{
				map.put("callDuration",String.valueOf(map.get("callDuration")));
			}
				// 生成一个SequenceId,用于记录日志
			// 通过getParameterMap获取"相对"原始的请求参数,分别存放在requestContent（用于记录日志）和parameterMap（用于计算签名）。通过spring注入bean获取的参数会忽略掉bean里不需要的参数
			String requestContent = "";
			for (Entry<String, String> entry : map.entrySet()) {
				String	key = entry.getKey();
				String	value = entry.getValue();
				if (requestContent != "") {
					requestContent += "&";
				}
				requestContent += key + "=" + value;
			}
			loggerSingleWork
					.info(String.format("seqid=%s,request=%s?%s", seqId, request.getRequestURI(), requestContent));
			// 签名验证最后加

			// 绑定参数合法性检查
            String subId =map.get("bindId");
			String callid = map.get("callId");
			String telA = map.get("callNo");
			String telX = map.get("x");
			String telB = map.get("peerNo");
			String requestId = seqId;
			//如果有bindId，根据绑定id查询绑定数据，没有则根据x小号查找绑定关系的subid，按照时间倒叙排列
			TReginfoExample example = new TReginfoExample();
			TReginfoExample.Criteria criteria = example.createCriteria();
            criteria.andCardnoEqualTo(subId);
            List<TReginfo> tReginfos = reginfoService.selectByExample(example);

            if (tReginfos.size() == 0) {
                loggerSingleWork.info(String.format("seqid=%s,info=%s", seqId, "subId在TReginfo没找到对应的数据," +
                        "还需要进一步根据x号码进行查询是否为设置X号码转接的话单:"+subId));
                TReginfoExample example2 = new TReginfoExample();
                TReginfoExample.Criteria criteria2 = example2.createCriteria();
                criteria2.andUidnumberEqualTo(telX);
                example2.setOrderByClause("regtime desc");
                tReginfos = reginfoService.selectByExample(example2);
                if (tReginfos.size() == 0) {
                    loggerSingleWork.info(String.format("seqid=%s,info=%s", seqId, "subId在TReginfo没找到对应的数据:"+subId));
                    loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
                    return response;
                }
            }

			//确保subId为数据库中的subId，不为空值
			subId = tReginfos.get(0).getCardno();
			String record=tReginfos.get(0).getCallrecording();


			//根据绑定关系查询绑定的号码，号码为主叫号码的话则calltype=0，被叫号码的话则calltype=1
			String calltype="";
			if(StringUtils.equals(telA,tReginfos.get(0).getRegphone())){ calltype="0";}
			else  if(StringUtils.equals(telB,tReginfos.get(0).getRegphone())){ calltype="1";}
			else {
				loggerSingleWork.info(String.format("seqid=%s,info=%s", seqId, "该subId的calltype为空："+subId+",原因为,telA:"
						+telA+",telB:"+telB+",regPhone:"+tReginfos.get(0).getRegphone()));
			}

			//话单接收之后写入ARC_95013表voicemail字段的值需要填入yd，calltype需要有值，areacode需要有值，recording_file需要有值
			String unitId = tReginfos.get(0).getUnitid();
			String areaCode = tReginfos.get(0).getAreacode();

			CallReleaseVo releaseVo = new CallReleaseVo();
			releaseVo.setCall_id(callid);
			releaseVo.setNo_a(telA);
			releaseVo.setNo_x(telX);
			releaseVo.setNo_b(telB);
			releaseVo.setTime_start(DateUtils.parseSync8(map.get("callTime"),sdf));
			releaseVo.setRequest_id(requestId);
			releaseVo.setPartner_id(unitId);
			releaseVo.setCalltype(calltype);
			releaseVo.setSubid(subId);
			//移动没有振铃时间
			//releaseVo.setTime_ring(sdf.parse(map.get("ringingtime")));
			releaseVo.setTime_release(DateUtils.parseSync8(map.get("finishTime"),sdf));
			releaseVo.setRelease_dir(map.get("finishType"));
			releaseVo.setRelease_cause(map.get("finishState"));
			releaseVo.setAreacode(areaCode);
			releaseVo.setDuration(0);
			String companyName=tReginfos.get(0).getName();
            releaseVo.setVoicemail_file(companyName);

			if(map.containsKey("startTime")&&StringUtils.isNotEmpty(map.get("startTime"))){
				releaseVo.setTime_answer(DateUtils.parseSync8(map.get("startTime"),sdf));
				if(map.containsKey("callDuration")){
					releaseVo.setDuration(Integer.parseInt(map.get("callDuration")));
				}

			}


			TUnitInfoExample infoExample = new TUnitInfoExample();
			TUnitInfoExample.Criteria infoCriteria = infoExample.createCriteria();
			infoCriteria.andUnitidEqualTo(unitId);
			List<TUnitInfo> infos = infoDao.selectByExample(infoExample);
			if (infos.size() > 0) {
				TUnitInfo info = infos.get(0);
				if (StringUtils.isNotBlank(info.getCdrUrl())) {
					Map<String, String> sendMap=new HashMap<>();
					//参数
					sendMap.put("telA", telA);
					sendMap.put("telX", telX);
					sendMap.put("telB", telB);
					sendMap.put("subid", subId);
					sendMap.put("callid", callid);
					sendMap.put("calltype", calltype);
					sendMap.put("calltime", map.get("callTime"));
					sendMap.put("starttime", map.get("startTime"));
					sendMap.put("releasetime", map.get("finishTime"));
					sendMap.put("talktime", map.get("callDuration"));
					sendMap.put("releasedir",  map.get("finishType"));
					sendMap.put("releasecause",  map.get("finishState"));
					//通用参数
					TUnit unit = unitDao.selectSecretByUnitid(unitId);
					String secret = unitService.getSecret(unitId, unit.getUnitkey());
					sendMap.put("unitId", unitId);
					sendMap.put("appkey", unit.getUnitkey());

					Date now = new Date();
					SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd");
					String DateNow = sdf2.format(now);

					//传给客户的telA，B，X需要去掉86，固话加上0，录音文件格式应该去掉86，固话加上0
                    String telAToUser=dealProblem86(seqId,releaseVo.getNo_a());
                    String telBToUser=dealProblem86(seqId,releaseVo.getNo_b());
                    String telXToUser=dealProblem86(seqId,releaseVo.getNo_x());
                    String callNoRecordUrl=dealProblem86(seqId,map.get("callNo"));
                    String peerNoRecordUrl=dealProblem86(seqId,map.get("peerNo"));

					//录音文件名格式：callid_主叫号码_被叫号码_通话开始时间
					String recordName = "";
					String newRecordUrl="";
					if(map.containsKey("startTime")&&StringUtils.isNotEmpty(map.get("startTime"))&&(!StringUtils.equals(record,"0"))&&(StringUtils.isNotEmpty(record))) {
						//有开始时间并且通话时间不为0才有录音
                        if(map.containsKey("callDuration")&&StringUtils.isNotEmpty(map.get("callDuration"))&&!StringUtils.equals(map.get("callDuration"),"0")){
                            recordName = callid + "_" + callNoRecordUrl + "_" + peerNoRecordUrl + "_" + map.get("startTime");
                            newRecordUrl=unitId + "/" + DateNow + "/" + recordName+".wav";
                        }
					}

					sendMap.put("recordUrl", newRecordUrl);
                    sendMap.put("telA", telAToUser);
                    sendMap.put("telX", telXToUser);
                    sendMap.put("telB", telBToUser);
					String url = info.getCdrUrl() + "/v2/ax/finish";
					String sign = SignUtils.signTopRequest(sendMap, secret, "MD5");
					sendMap.put("sign", sign);
                    //给客户传话单
					ydBindService.pushCdr(loggerSingleWork, sendMap, seqId, url);
					//更新话单地址
					//有开始时间才有录音
					releaseVo.setRecording_file(newRecordUrl);

				}

			}else {
				loggerSingleWork.info(String.format("seqid=%s,info=%s", seqId, "subId在TUnitInfo没找到对应的数据:"+subId));
			}
			//写话单、更新话单等操作。
			callService.callRelease10086(loggerSingleWork, releaseVo, seqId,2);

		} catch (Exception e) {
			loggerException.error("error,",e);
			loggerException.error(String.format("seqid=%s,Exception=%s", seqId, e.toString().replaceAll("\n", "|")));
		}
		loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
		return response;
	}

	/**
	 * 录音推送接口
	 *
	 * @param bindVo
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/record")
	public Object record() {
		String seqId = UUID.randomUUID().toString();
		JSONObject response = ResponseUtils.makeYdResponse("0000", "success");
		try {
			Map<String, String> map = getParaMap();
			// 生成一个SequenceId,用于记录日志
			// 通过getParameterMap获取"相对"原始的请求参数,分别存放在requestContent（用于记录日志）和parameterMap（用于计算签名）。通过spring注入bean获取的参数会忽略掉bean里不需要的参数
			String requestContent = "";
			for (Entry<String, String> entry : map.entrySet()) {
				String key = entry.getKey();
				String value = entry.getValue();
				if (requestContent != "") {
					requestContent += "&";
				}
				requestContent += key + "=" + value;
			}
			loggerSingleWork
					.info(String.format("seqid=%s,request=%s?%s", seqId, request.getRequestURI(), requestContent));

			// 签名验证最后加
			// 绑定参数合法性检查
			String subId = map.get("bindId");
			String callid = map.get("callId");
			String recordUrl=map.get("recordUrl");
			String requestId = seqId;

			TReginfoExample example = new TReginfoExample();
			TReginfoExample.Criteria criteria = example.createCriteria();
			criteria.andCardnoEqualTo(subId);
			List<TReginfo> tReginfos = reginfoService.selectByExample(example);
			if (tReginfos.size() == 0) {
				loggerSingleWork.info(String.format("seqid=%s,info=%s", seqId, "subId在TReginfo没找到对应的数据:"+subId));
				loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
				return response;
			}
			String unitId = tReginfos.get(0).getUnitid();

			CallReleaseVo releaseVo = new CallReleaseVo();
			releaseVo.setCall_id(callid);
			releaseVo.setRequest_id(requestId);
			releaseVo.setPartner_id(unitId);
			releaseVo.setSubid(subId);
			releaseVo.setRecording_file(recordUrl);
			releaseVo.setTime_start(new Date());
			//录音的calltype
            releaseVo.setCalltype("4");

			TUnitInfoExample infoExample = new TUnitInfoExample();
			TUnitInfoExample.Criteria infoCriteria = infoExample.createCriteria();
			infoCriteria.andUnitidEqualTo(unitId);
			List<TUnitInfo> infos = infoDao.selectByExample(infoExample);

			if (infos.size() > 0) {
				TUnitInfo info = infos.get(0);
				if (StringUtils.isNotBlank(info.getCdrUrl())) {
					Map<String, String> sendMap=new HashMap<>();
					//参数
					sendMap.put("subid", subId);
					sendMap.put("callid", callid);
					//通用参数
					TUnit unit = unitDao.selectSecretByUnitid(unitId);
					String secret = unitService.getSecret(unitId, unit.getUnitkey());
					sendMap.put("unitId", unitId);
					sendMap.put("appkey", unit.getUnitkey());
					String url = info.getCdrUrl() + "/v2/ax/record";
					//录音文件不为空时，并且将传递的录音文件地址进行修改。需要将签名放在recordUrl下方。否则会报签名错误。
					if(!StringUtils.isEmpty(recordUrl)){
						//保存录音文件到本地
						String urlPath=recordUrl;
						//获取录音文件名
						String recordName=StringUtils.substringAfterLast(urlPath,"/");
						Date now=new Date();
						SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd");
						String DateNow=sdf2.format(now);
						String saveDir=RECORDURL+"/recordings/"+unitId+"/"+DateNow+"/"+recordName;
						//下载
						iDownloadService.downloadFile(urlPath, saveDir,seqId,WAITSECOND);
						String newRecordUrl=unitId+"/"+DateNow+"/"+recordName;
                        sendMap.put("recordUrl", newRecordUrl);
					}
					String sign = SignUtils.signTopRequest(sendMap, secret, "MD5");
					sendMap.put("sign", sign);
					ydBindService.pushCdr(loggerSingleWork, sendMap, seqId, url);
				}

			}else {
				loggerSingleWork.info(String.format("seqid=%s,info=%s", seqId, "subId在TUnitInfo没找到对应的数据:"+subId));
			}
			//写话单、更新话单等操作。
			callService.callRelease10086(loggerSingleWork, releaseVo, seqId,3);
		} catch (Exception e) {
			loggerException.error(String.format("seqid=%s,Exception=%s", seqId, e.toString().replaceAll("\n", "|")));
		}
		loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
		return response;
	}
	/**
	 * AXB短信接口
	 *
	 * @param bindVo
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/message")
	public Object message() {
		String seqId = UUID.randomUUID().toString();
		JSONObject response = ResponseUtils.makeYdResponse("0000", "success");
		try {
			Map<String, String> map = getParaMap();
			// 生成一个SequenceId,用于记录日志

			// 通过getParameterMap获取"相对"原始的请求参数,分别存放在requestContent（用于记录日志）和parameterMap（用于计算签名）。通过spring注入bean获取的参数会忽略掉bean里不需要的参数
			String requestContent = "";
			for (Entry<String, String> entry : map.entrySet()) {
				String key = entry.getKey();
				String value = entry.getValue();

				if (requestContent != "") {
					requestContent += "&";
				}
				requestContent += key + "=" + value;
			}
			loggerSingleWork
					.info(String.format("seqid=%s,request=%s?%s", seqId, request.getRequestURI(), requestContent));

			// 签名验证最后加
			// 绑定参数合法性检查

			String subId = map.get("bindId");
			String callid = map.get("callId");
			String telA = map.get("callNo");
			String telX = map.get("x");
			String telB = map.get("peerNo");
			String requestId = seqId;

			TReginfoExample example = new TReginfoExample();
			TReginfoExample.Criteria criteria = example.createCriteria();
			criteria.andCardnoEqualTo(subId);
			List<TReginfo> tReginfos = reginfoService.selectByExample(example);
			if (tReginfos.size() == 0) {
				loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
				return response;
			}
			//根据绑定关系查询绑定的号码，号码为主叫号码的话则calltype=2，被叫号码的话则calltype=3
			String calltype="";
			if(StringUtils.equals(telA,tReginfos.get(0).getRegphone())){ calltype="2";}
			else  if(StringUtils.equals(telB,tReginfos.get(0).getRegphone())){ calltype="3";}
			else {
				loggerSingleWork.info(String.format("seqid=%s,info=%s", seqId, "该subId的calltype为空："+subId+",原因为,telA:"
						+telA+",telB:"+telB+",regPhone:"+tReginfos.get(0).getRegphone()));
			}

			String unitId = tReginfos.get(0).getUnitid();
			Date timeStart=(StringUtils.isEmpty(map.get("smsTime")))?new Date():DateUtils.parseSync8(map.get("smsTime"),sdf);
			CallReleaseVo releaseVo = new CallReleaseVo();
			releaseVo.setCall_id(callid);
			releaseVo.setNo_a(telA);
			releaseVo.setNo_x(telX);
			releaseVo.setNo_b(telB);
			releaseVo.setTime_start(timeStart);
			releaseVo.setRequest_id(requestId);
			releaseVo.setPartner_id(unitId);
			releaseVo.setCalltype(calltype);
			releaseVo.setSubid(subId);
			releaseVo.setRelease_cause(map.get("smsResult"));

			TUnitInfoExample infoExample = new TUnitInfoExample();
			TUnitInfoExample.Criteria infoCriteria = infoExample.createCriteria();
			infoCriteria.andUnitidEqualTo(unitId);
			List<TUnitInfo> infos = infoDao.selectByExample(infoExample);

			if (infos.size() > 0) {
				TUnitInfo info = infos.get(0);
				if (StringUtils.isNotBlank(info.getCdrUrl())) {
					Map<String, String> sendMap=new HashMap<>();
					//参数
					sendMap.put("subid", subId);
					sendMap.put("callid", callid);
					sendMap.put("telA", telA);
					sendMap.put("telX", telX);
					sendMap.put("calltype", calltype);
					sendMap.put("telB", telB);
					sendMap.put("calltime", StringUtils.isEmpty(map.get("smsTime"))?DateUtils.formatSync8(new Date(),sdf):map.get("smsTime"));
					sendMap.put("releasecause", map.get("smsResult"));
					//通用参数
					TUnit unit = unitDao.selectSecretByUnitid(unitId);
					String secret = unitService.getSecret(unitId, unit.getUnitkey());
					sendMap.put("unitId", unitId);
					sendMap.put("appkey", unit.getUnitkey());
					String url = info.getCdrUrl() + "/v2/ax/message";
					String sign = SignUtils.signTopRequest(sendMap, secret, "MD5");
					sendMap.put("sign", sign);
					ydBindService.pushCdr(loggerSingleWork, sendMap, seqId, url);
				}

			}
			//写短信话单。
			callService.callRelease10086(loggerSingleWork, releaseVo, seqId,4);
		} catch (Exception e) {
			e.printStackTrace();
			loggerException.error(String.format("seqid=%s,Exception=%s", seqId, e.toString().replaceAll("\n", "|")));
		}
		loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
		return response;
	}
	private Map<String, String> getParaMap() {
		BufferedReader reader = null;
		StringBuffer sb = new StringBuffer();
		try {
			reader = request.getReader();
			String str;
			while ((str = reader.readLine()) != null) {
				sb.append(str);
			}
			reader.close();
		} catch (Exception e) {
			// TODO: handle exception
		} finally {
			if (null != reader) {
				try {
					reader.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
		return JsonUtils.jsonToPojo(sb.toString(), Map.class);
	}

	private  String dealProblem86(String seqId,String number){
        if(number.startsWith("862")||
                number.startsWith("863")||
                number.startsWith("864")||
                number.startsWith("865")||
                number.startsWith("866")||
                number.startsWith("867")||
                number.startsWith("868")||
                number.startsWith("869")||
                number.startsWith("8610")){
            number="0"+StringUtils.substringAfter(number,"86");
        }else if(number.startsWith("86")){
            number= StringUtils.substringAfter(number,"86");
        }else{
            loggerSingleWork.info(String.format("seqid=%s,result=%s", seqId, "dealProblem86 change86 number wrong,original number is "+number));
        }
         return number;
    }

}
