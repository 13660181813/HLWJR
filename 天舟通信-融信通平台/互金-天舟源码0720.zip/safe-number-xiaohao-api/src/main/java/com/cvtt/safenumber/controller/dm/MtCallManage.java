/**
 * 讯众小号推送话单类
 */
package com.cvtt.safenumber.controller.dm;

import com.alibaba.fastjson.JSONObject;
import com.cvtt.safenumber.dao.TUnitInfoMapper;
import com.cvtt.safenumber.dao.TUnitMapper;
import com.cvtt.safenumber.pojo.Arc95013Example;
import com.cvtt.safenumber.pojo.TReginfo;
import com.cvtt.safenumber.pojo.TReginfoExample;
import com.cvtt.safenumber.pojo.TUnit;
import com.cvtt.safenumber.pojo.TUnitInfo;
import com.cvtt.safenumber.pojo.TUnitInfoExample;
import com.cvtt.safenumber.service.ICallService;
import com.cvtt.safenumber.service.IDownloadService;
import com.cvtt.safenumber.service.IReginfoService;
import com.cvtt.safenumber.service.IUnitService;
import com.cvtt.safenumber.service.xz.IxzBindService;
import com.cvtt.safenumber.utils.DateUtils;
import com.cvtt.safenumber.utils.JsonUtils;
import com.cvtt.safenumber.utils.ResponseUtils;
import com.cvtt.safenumber.utils.SignUtils;
import com.cvtt.safenumber.vo.CallReleaseVo;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.UUID;


@SuppressWarnings("all")
@Controller
@RequestMapping("/v2/mtax")
public class MtCallManage {
    @Autowired
    private HttpServletRequest request;
    @Resource
    private IUnitService unitService;
    @Resource
    private IxzBindService xzBindService;

    @Resource
    private ICallService callService;

    @Resource
    private IReginfoService reginfoService;

    @Resource
    private TUnitInfoMapper infoDao;
    @Resource
    private TUnitMapper unitDao;
    @Resource
    private IDownloadService iDownloadService;


    @Value("${recordUrl}")
    private String RECORDURL;
    @Value("${dowmloadTime}")
    private String WAITSECOND;


    private static Logger loggerSingleWork = Logger.getLogger("DataManage.SingleWork");
    private static Logger loggerBatchWork = Logger.getLogger("DataManage.BatchWork");
    private static Logger loggerException = Logger.getLogger("Sys.Exception");
    private static String sdf = "yyyy-MM-dd HH:mm:ss";

    /**
     * 结束通话接口
     *
     * @param bindVo
     * @return
     */
    @ResponseBody
    @RequestMapping("/finish")
    public Object finish(@RequestParam(value = "postData") String postData) {
        String seqId = UUID.randomUUID().toString();
        JSONObject response = ResponseUtils.makeXzResponse("200", "成功", null);
        loggerSingleWork
                .info(String.format("seqid=%s,request=%s?%s", seqId, request.getRequestURI(), postData));
        try {
            Map<String, String> mapMT = getParaMap(postData);
            // 生成一个SequenceId,用于记录日志
            // 通过getParameterMap获取"相对"原始的请求参数,分别存放在requestContent（用于记录日志）和parameterMap（用于计算签名）。
            // 通过spring注入bean获取的参数会忽略掉bean里不需要的参数
            String requestContent = "";
            for (Entry<String, String> entry : mapMT.entrySet()) {
                String key = entry.getKey();
                String value = entry.getValue();
                if (requestContent != "") {
                    requestContent += "&";
                }
                requestContent += key + "=" + value;
            }
            loggerSingleWork
                    .info(String.format("seqid=%s,format request=%s?%s", seqId, request.getRequestURI(), requestContent));
            // 将麦田话单字段和东盟字段统一
            String telX = mapMT.get("virtualNumber");
            //根据x小号查找绑定关系的subid，按照时间倒叙排列
            TReginfoExample example = new TReginfoExample();
            TReginfoExample.Criteria criteria = example.createCriteria();
            criteria.andUidnumberEqualTo(telX);
            example.setOrderByClause("regtime desc");
            List<TReginfo> tReginfos = reginfoService.selectByExample(example);
            if (tReginfos.size() == 0) {
                loggerSingleWork.info(String.format("seqid=%s,info=%s", seqId, "telX在TReginfo没找到对应的数据"));
                loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
                return response;
            }
            String subId = tReginfos.get(0).getCardno();
            String callrecording = tReginfos.get(0).getCallrecording();
            String areaCode = tReginfos.get(0).getAreacode();

            String callid = mapMT.get("callid");
            String requestId = seqId;
            String recordUrl = mapMT.get("recordfile");
            String releasecause = mapMT.get("reason");
            String bridgeSec = mapMT.get("bridgeSec");
            //给平安传的参数
            Map<String, String> map = new HashMap<>();
            map.put("subId", subId);
            map.put("callid", callid);
            map.put("telX", telX);
            map.put("requestId", requestId);
            map.put("recordUrl", recordUrl);
            map.put("calltime", mapMT.get("created_time"));
            map.put("ringingtime", mapMT.get("created_time"));
            map.put("starttime", mapMT.get("answered_time"));
            map.put("releasetime", mapMT.get("hangup_time"));
            map.put("releasecause", releasecause);
            map.put("callrecording", callrecording);
            map.put("releasedir", mapMT.get("releasedir"));
            if (!StringUtils.isEmpty(recordUrl)) {
                map.put("recordMode", "1");
            }
            //monitorParty和T_REGINFO表中的regphone
            String calltype = "";
            String telA = "";
            String telB = "";
            //没有bindcode为AX绑定
            if (StringUtils.isEmpty(mapMT.get("bindCode"))
                    || StringUtils.equals(mapMT.get("bindCode"), "null")
                    || StringUtils.equals(mapMT.get("bindCode"), "0")) {
                calltype = "1";
                telA = mapMT.get("otherParty");
                telB = mapMT.get("monitorParty");
            } else {
                //此时是axb绑定或者是标准AX绑定
                telA = mapMT.get("monitorParty");
                telB = mapMT.get("otherParty");
                //根据calltype判断是主叫还是被叫
                if (StringUtils.equals(mapMT.get("calltype"), "10")
                        || StringUtils.equals(mapMT.get("calltype"), "110")
                        || StringUtils.equals(mapMT.get("calltype"), "111")
                        || StringUtils.equals(mapMT.get("calltype"), "113")
                        || StringUtils.equals(mapMT.get("calltype"), "112")) {
                    //主叫
                    calltype = "128";
                } else if (StringUtils.equals(mapMT.get("calltype"), "11")
                        || StringUtils.equals(mapMT.get("calltype"), "120")) {
                    //被叫
                    calltype = "1";
                } else {
                    //其它情况
                    calltype = mapMT.get("calltype");
                }
            }
            map.put("calltype", calltype);
            map.put("telB", telB);
            map.put("telA", telA);
            map.put("areacode", areaCode);

            String unitId = tReginfos.get(0).getUnitid();
            CallReleaseVo releaseVo = new CallReleaseVo();
            releaseVo.setCall_id(callid);
            releaseVo.setNo_a(telA);
            releaseVo.setNo_x(telX);
            releaseVo.setNo_b(telB);
            releaseVo.setTime_start(DateUtils.parseSync8(map.get("calltime"), sdf));
            releaseVo.setRequest_id(requestId);
            releaseVo.setPartner_id(unitId);
            releaseVo.setCalltype(calltype);
            releaseVo.setSubid(subId);
            releaseVo.setRecording_file(recordUrl);
            releaseVo.setTime_answer(DateUtils.parseSync8(map.get("starttime"), sdf));
            releaseVo.setTime_ring(DateUtils.parseSync8(map.get("ringingtime"), sdf));
            releaseVo.setTime_release(DateUtils.parseSync8(map.get("releasetime"), sdf));
            releaseVo.setRelease_dir(map.get("releasedir"));
            releaseVo.setRelease_cause(map.get("releasecause"));
            releaseVo.setDuration(Integer.parseInt(bridgeSec));
            releaseVo.setAreacode(areaCode);
            String companyName= tReginfos.get(0).getName();
            releaseVo.setVoicemail_file(companyName);

            //录音文件不为空时，并且将传递的录音文件地址进行修改。需要将签名放在recordUrl下方。否则会报签名错误。
            if (!StringUtils.isEmpty(recordUrl)) {
                //保存录音文件到本地
                String urlPath = recordUrl;
                //获取录音文件名
                String recordName = StringUtils.substringAfterLast(urlPath, "/");
                Date now = new Date();
                SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd");
                String DateNow = sdf2.format(now);
                String saveDir = RECORDURL + "/recordings/" + unitId + "/" + DateNow + "/" + recordName;
                //下载
                iDownloadService.downloadFile(urlPath, saveDir, seqId, WAITSECOND);
                String newRecordUrl = unitId + "/" + DateNow + "/" + recordName;
                map.put("recordUrl", newRecordUrl);
            }

            TUnitInfoExample infoExample = new TUnitInfoExample();
            TUnitInfoExample.Criteria infoCriteria = infoExample.createCriteria();
            infoCriteria.andUnitidEqualTo(unitId);
            List<TUnitInfo> infos = infoDao.selectByExample(infoExample);

            if (infos.size() > 0) {
                TUnitInfo info = infos.get(0);
                if (StringUtils.isNotBlank(info.getCdrUrl())) {
                    TUnit unit = unitDao.selectSecretByUnitid(unitId);
                    String secret = unitService.getSecret(unitId, unit.getUnitkey());
                    map.put("unitId", unitId);
                    map.put("appkey", unit.getUnitkey());
                    String url = info.getCdrUrl() + "/v2/ax/finish";
                    String sign = SignUtils.signTopRequest(map, secret, "MD5");
                    map.put("sign", sign);
                    xzBindService.pushCdr(loggerSingleWork, map, seqId, url);
                }
            } else {
                loggerSingleWork.info(String.format("seqid=%s,info=%s", seqId, "subId在TUnitInfo没找到对应的数据:" + subId));
            }
            //判断话单是否重复，通过releaseTime+callId判断,重复则不再写话单。
            Arc95013Example exampleARC = new Arc95013Example();
            Arc95013Example.Criteria criteria2 = exampleARC.createCriteria();
            criteria2.andNoXEqualTo(map.get("telX").toString());
            criteria2.andStartTimeEqualTo(DateUtils.parseSync8(map.get("calltime"), sdf));
            criteria2.andReleaseTimeEqualTo(DateUtils.parseSync8(map.get("releasetime"), sdf));
            criteria2.andCallIdEqualTo(callid);
            callService.callReleaseAndJudgeRepeated(loggerSingleWork, releaseVo, seqId, exampleARC);
        } catch (Exception e) {
            loggerException.error(String.format("seqid=%s,Exception=%s", seqId, e.toString().replaceAll("\n", "|")));
        }
        loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
        return response;
    }

    private Map<String, String> getParaMap(String postData) {
        Map<String, String> getParaMap = new HashMap<>();
        Map<String, Object> receiveMap = JsonUtils.jsonToPojo(postData, Map.class);
        for (String key : receiveMap.keySet()) {
            getParaMap.put(key, receiveMap.get(key) + "");
        }
        return getParaMap;
    }
}
