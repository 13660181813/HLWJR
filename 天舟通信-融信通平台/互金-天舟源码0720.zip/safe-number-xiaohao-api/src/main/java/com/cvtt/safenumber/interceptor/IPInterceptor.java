package com.cvtt.safenumber.interceptor;

import com.cvtt.safenumber.utils.IPUtils;
import com.cvtt.safenumber.utils.ResponseUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

/**
 * @decription IPInterceptor
 * <p>http请求过滤器</p>
 * @author Yampery
 * @date 2017/12/7 17:22
 */
@WebFilter(filterName = "IPInterceptor", urlPatterns = "/*")
public class IPInterceptor implements Filter {

    private static Logger logger = LoggerFactory.getLogger("Filter.IPInterceptor");

    /**
     * 禁止单位'0'的请求方法表
     */
    /* private final String[] NOT_ALLAW_METHOD = {
            "remove_Relation"                       // 解绑操作
            ,"binding_Relation"                     // 绑定
            ,"check_Relation"                       // 鉴权查询
            ,"twowaycall"                           // 双向呼
            ,"cancel_Relation"                      // 撤单
            ,"query_Relation"                       // 绑定关系查询
            ,"query_Remains"                        // 号码余量
            ,"extend_Relation"                      // 延期
            ,"recover_Relation"                     // 解冻
            ,"announcement"                         // 语音通知

            ,"sms_safenumber"                       // 安全号发送短信
            ,"sms_release"                          // 短信日志入库

            ,"secret.call.control"                  // 呼叫控制
            ,"secret.call.release"                  // 呼叫通知
            ,"secret.call.authentication"           // 呼叫鉴权
            ,"secret.call.authcontrol"              // 呼叫鉴权控制，京东使用
    };
    */

    private final String[] ALLAW_METHOD_LIST = {
            "query_Relation"
            ,"recover_Relation"
            ,"twowaycall"

            ,"sms_safenumber"
            ,"sms_release"

            ,"secret.call.control"
            ,"secret.call.release"
    };

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        HttpServletRequest httpRequest = (HttpServletRequest) request;
        HttpServletResponse httpResponse = (HttpServletResponse) response;

        // 先判断请求参数unitid是否为'0'
        String unitid = httpRequest.getParameter("unitID");
        String partnerId = httpRequest.getParameter("partner_id");
        if (StringUtils.equals("0", unitid) || StringUtils.equals("0", partnerId)) {
            // 判断ip是否可信
            String remoteAddr = IPUtils.getInstance().getIpAddr(httpRequest);
            if (IPUtils.getInstance().isSecurityIp(remoteAddr)) {
                // ip可信，判断请求接口
                String method1 = httpRequest.getParameter("msgtype");
                String method2 = httpRequest.getParameter("method");
                boolean isAllawed = false;
                for (int i = 0, len = ALLAW_METHOD_LIST.length; i < len; i++) {
                    if (StringUtils.equals(ALLAW_METHOD_LIST[i], method1) ||
                            StringUtils.equals(ALLAW_METHOD_LIST[i], method2)) {
                        isAllawed = true;
                        break;
                    }
                }
                // 如果请求方法允许，放行
                if (isAllawed) {
                    chain.doFilter(request, response);
                } else {
                    String seqId = UUID.randomUUID().toString();
                    String requestContent = "";
                    Map<String, String> parameterMap = new HashMap<String, String>();
                    for (Iterator<Map.Entry<String, String[]>> iter = request.getParameterMap().entrySet().iterator(); iter
                            .hasNext(); ) {
                        Map.Entry<String, String[]> entry = iter.next();
                        String key = entry.getKey();
                        String vals = "";
                        for (String val : entry.getValue()) {
                            vals += val;
                        }
                        if (requestContent != "")
                            requestContent += "&";
                        requestContent += key + "=" + vals;
                        if (!key.equals("sid"))
                            parameterMap.put(key, vals);
                    }
                    logger.info(String.format("seqid=%s, clientIP=%s, request=%s?%s", seqId, remoteAddr, httpRequest.getRequestURI(), requestContent));
                    // 不允许请求
                    Object result = ResponseUtils.makeErrResponse("403", "Forbidden", "Method-access-denied",
                            "禁止访问");
                    logger.info(String.format("seqid=%s,response=%s", seqId, result.toString()));
                    httpResponse.setContentType("text/html; charset=UTF-8");
                    httpResponse.getWriter().print(result.toString());
                }
            } else {
                String seqId = UUID.randomUUID().toString();
                String requestContent = "";
                Map<String, String> parameterMap = new HashMap<String, String>();
                for (Iterator<Map.Entry<String, String[]>> iter = request.getParameterMap().entrySet().iterator(); iter
                        .hasNext(); ) {
                    Map.Entry<String, String[]> entry = iter.next();
                    String key = entry.getKey();
                    String vals = "";
                    for (String val : entry.getValue()) {
                        vals += val;
                    }
                    if (requestContent != "")
                        requestContent += "&";
                    requestContent += key + "=" + vals;
                    if (!key.equals("sid"))
                        parameterMap.put(key, vals);
                }
                logger.info(String.format("seqid=%s,clientIP=%s,request=%s?%s", seqId, remoteAddr, httpRequest.getRequestURI(), requestContent));
                Object result = ResponseUtils.makeErrResponse("403", "Forbidden", "IP-denied",
                        "IP拒绝");
                logger.info(String.format("seqid=%s,response=%s", seqId, result.toString()));
                httpResponse.setContentType("text/html; charset=UTF-8");
                httpResponse.getWriter().print(result.toString());
            }
        } else { // unitID不为0，直接放行
            chain.doFilter(request, response);
        }
    }

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        //empty implement
    }

    @Override
    public void destroy() {
        //empty implement
    }
}
