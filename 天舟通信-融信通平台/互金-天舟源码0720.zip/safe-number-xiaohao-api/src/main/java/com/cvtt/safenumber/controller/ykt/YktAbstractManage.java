package com.cvtt.safenumber.controller.ykt;

import com.alibaba.fastjson.JSONObject;
import com.cvtt.safenumber.constents.Regex;
import com.cvtt.safenumber.service.IUnitService;
import com.cvtt.safenumber.utils.ResponseUtils;
import com.cvtt.safenumber.utils.SignUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.io.IOException;
import java.util.Map;

/**
 * @decription AbstractManage
 * <p>公共Controller</p>
 * @author Yampery
 * @date 2018/4/17 16:19
 */
@RestController
public class YktAbstractManage {

    @Resource private IUnitService unitService;
    @Resource private Regex regex;
    static Logger loggerSingleWork = Logger.getLogger("DataManage.SingleWork");
    static Logger loggerException = Logger.getLogger("Sys.Exception");

    /**
     * 接口统一验签
     * @param map
     * @param seqId
     * @return
     */
    public JSONObject yxtSignValid(Map<String, String> map, String seqId) {
        String secret = unitService.getSecret(regex.YKT_UNITID, map.get("appkey"));
        String requestSign = map.get("sign");
        map.remove("sign");
        if (StringUtils.isBlank(secret)) {
            JSONObject response = ResponseUtils.makeYxtResponse(11, "使用了错误的appkey", null);
            loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
            return response;
        }

        // 签名检查
        try {
            String sign = SignUtils.signTopRequest(map, secret, "MD5", "=", "&");
            if (!requestSign.equalsIgnoreCase(sign)) {
                loggerSingleWork.info(String.format("seqid=%s,calculate_sign=%s", seqId, sign));
                JSONObject response = ResponseUtils.makeYxtResponse(11, "验签失败", null);
                loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
                return response;
            }
        } catch (IOException e) {
            loggerException.error(String.format("seqid=%s,Exception=%s",
                    seqId, e.toString().replaceAll("\n", "|")));
            return ResponseUtils.makeYxtResponse(11, "计算签名异常", null);
        }

        return null;
    }
}
