/**
 * 关系数据相关接口(绑定，解绑，批绑，批解，批延期)
 */
package com.cvtt.safenumber.controller;

import com.alibaba.fastjson.JSONObject;
import com.cvtt.safenumber.constents.Regex;
import com.cvtt.safenumber.crypt.TransADESUtils;
import com.cvtt.safenumber.service.*;
import com.cvtt.safenumber.service.ykt.IYktNumberService;
import com.cvtt.safenumber.utils.CSVUtils;
import com.cvtt.safenumber.utils.ResponseUtils;
import com.cvtt.safenumber.utils.SignUtils;
import com.cvtt.safenumber.vo.*;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.*;
import java.util.Map.Entry;

@SuppressWarnings("all")
@Controller
@RequestMapping("/api/manage")
public class DataManage {
    @Autowired
    private HttpServletRequest request;
    @Resource
    private IUnitService unitService;
    @Resource
    private IUidlistService uidlistService;
    @Resource
    private IBindService bindService;
    @Resource
    private IUnbindService unbindService;
    @Resource
    private ICancelService cancelService;
    @Resource
    private IExtendService extendService;
    @Resource
    private IQueryService queryService;
    @Resource
    private IChangeBindService changeService;
    @Resource
    private IVoiceService voiceService;
    @Resource
    private IPOPBindService popBindService;
    @Resource
    private IPassportService passportService;
    @Resource
    private Regex regex;

    private static Logger loggerSingleWork = Logger.getLogger("DataManage.SingleWork");
    private static Logger loggerBatchWork = Logger.getLogger("DataManage.BatchWork");
    private static Logger loggerException = Logger.getLogger("Sys.Exception");
    @ResponseBody
    @RequestMapping("/dataManage")
    // 示例url
    // http://localhost:8080/safeNumberServiceSSM/api/manage/dataManage?msgtype=binding_Relation&unitID=10000000003&prtms=13811685444&uidType=0&appkey=T7LIYJJhMcLmjyqqFmpgz0ycLrvIueALpfGtmPRFfRb6NCCDiUP9vlHkYFwWWOBA&callrestrict=1&otherms=17340905244&msgid=1&service=1&ts=1&ver=1&sid=191554E8617CD80B6214D227630C9C70
    // public String register(HttpServletRequest request,Model model){
    public Object dataManage(CommonVo1 commonVo, DataBindVo bindVo, DataUnbindVo unbindVo, TwoWayCallVo twowaycallVo, AnnouncementVo announcement) {
        // 生成一个SequenceId,用于记录日志
        String seqId = UUID.randomUUID().toString();
        // 通过getParameterMap获取"相对"原始的请求参数,分别存放在requestContent（用于记录日志）和parameterMap（用于计算签名）。通过spring注入bean获取的参数会忽略掉bean里不需要的参数
        String requestContent = "";
        Map<String, String> parameterMap = new HashMap<String, String>();
        for (Iterator<Entry<String, String[]>> iter = request.getParameterMap().entrySet().iterator(); iter
                .hasNext(); ) {
            Entry<String, String[]> entry = iter.next();
            String key = entry.getKey();
            String vals = "";
            for (String val : entry.getValue()) {
                vals += val;
            }
            if (requestContent != "")
                requestContent += "&";
            requestContent += key + "=" + vals;
            if (!key.equals("sid"))
                parameterMap.put(key, vals);
        }
        loggerSingleWork.info(String.format("seqid=%s,request=%s?%s", seqId, request.getRequestURI(), requestContent));

        // 公众参数合法性检查
        String errMsg = commonVo.checkMembers();
        if (StringUtils.isNotBlank(errMsg)) {
            Object response = ResponseUtils.makeErrResponse("101", "Parameter error", "invalid-parameter", errMsg);
            loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
            return response;
        }

        // 消息体参数检查
        String msgType = commonVo.getMsgtype();
        switch (msgType) {
            case "binding_Relation":
                errMsg = bindVo.checkMembers(commonVo.getTimestamp(), regex);
                if (StringUtils.isNotBlank(errMsg)) {
                    Object response = ResponseUtils.makeErrResponse("101", "Parameter error", "invalid-parameter", errMsg);
                    loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
                    return response;
                }
                break;
            case "remove_Relation":
                errMsg = unbindVo.checkMembers(regex);
                if (StringUtils.isNotBlank(errMsg)) {
                    Object response = ResponseUtils.makeErrResponse("101", "Parameter error", "invalid-parameter", errMsg);
                    loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
                    return response;
                }
                break;
            case "twowaycall":
                errMsg = twowaycallVo.checkMembers();
                if (StringUtils.isNotBlank(errMsg)) {
                    Object response = ResponseUtils.makeErrResponse("101", "Parameter error", "invalid-parameter", errMsg);
                    loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
                    return response;
                }
                break;
            case "announcement":
                // 语音通知
                errMsg = announcement.checkMembers();
                if (StringUtils.isNotBlank(errMsg)) {
                    Object response = ResponseUtils.makeErrResponse("101", "Parameter error", "invalid-parameter", errMsg);
                    loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
                    return response;
                }
                break;
            default:
                Object response = ResponseUtils.makeErrResponse("101", "Parameter error", "invalid-parameter",
                        "使用了本接口不支持的方法:" + msgType );
                loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
                return response;
        }

        if (!StringUtils.equals("0", commonVo.getUnitID())) {
            // 根据unitid获取secret(用于计算签名)，后续考虑将secret放在缓存中
            String secret = unitService.getSecret(commonVo.getUnitID(), commonVo.getAppkey());
            if (StringUtils.isBlank(secret)) {
                Object response = ResponseUtils.makeErrResponse("101", "Parameter error", "key-error",
                        "使用了错误的unitID或appkey");
                loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
                return response;
            }

            // 签名检查
            try {
                if (!commonVo.getSid().equalsIgnoreCase(SignUtils.signTopRequest(parameterMap, secret, "MD5"))) {
                    loggerSingleWork.info(String.format("seqid=%s,calculate_sign=%s", seqId,
                            SignUtils.signTopRequest(parameterMap, secret, "MD5")));
                    Object response = ResponseUtils.makeErrResponse("101", "Parameter error", "sign-error", "签名错误");
                    loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
                    return response;
                }
            } catch (IOException e) {
                loggerException.error(String.format("seqid=%s,Exception=%s", seqId, e.toString().replaceAll("\n", "|")));
                return ResponseUtils.makeExceptResponse("");
            }
        }

        // 参数检查及签名校验通过，根据msgType执行对应操作
        switch (msgType) {
            case "binding_Relation":
                try {
                    JSONObject response = (JSONObject) bindService.bindSingle(loggerSingleWork, bindVo, seqId);
                    loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
                    return response;
                } catch (Exception e) {
                    loggerException.error(String.format("seqid=%s,Exception=%s", seqId, e.toString().replaceAll("\n", "|")));
                    return ResponseUtils.makeExceptResponse("");
                }

            case "remove_Relation":
                try {
                    JSONObject response = (JSONObject) unbindService.unbindSingle(loggerSingleWork, unbindVo, seqId);
                    return response;
                } catch (Exception e) {
                    loggerException.error(String.format("seqid=%s,Exception=%s", seqId, e.toString().replaceAll("\n", "|")));
                    return ResponseUtils.makeExceptResponse("");
                }
            case "twowaycall":
                try {
                    return voiceService.twowaycall(loggerSingleWork, twowaycallVo, seqId);
                } catch (Exception e) {
                    loggerException.error(String.format("seqid=%s,Exception=%s", seqId, e.toString().replaceAll("\n", "|")));
                    return ResponseUtils.makeExceptResponse("");
                }
            case "announcement":
                // 语音通知
                try {
                    return voiceService.announcement(loggerSingleWork, announcement, seqId);
                } catch (Exception e) {
                    loggerException.error(String.format("seqid=%s,Exception=%s", seqId, e.toString().replaceAll("\n", "|")));
                    return ResponseUtils.makeExceptResponse("");
                }
        }
        return "";
    }

    @ResponseBody
    @RequestMapping("/dataManageReuse")
    public Object dataManageReuse(CommonVo1 commonVo, DataBindReuseVo bindVo, DataUnbindReuseVo unbindVo) {
        // 生成一个SequenceId,用于记录日志
        String seqId = UUID.randomUUID().toString();
        // 通过getParameterMap获取"相对"原始的请求参数,分别存放在requestContent（用于记录日志）和parameterMap（用于计算签名）。通过spring注入bean获取的参数会忽略掉bean里不需要的参数
        String requestContent = "";
        Map<String, String> parameterMap = new HashMap<String, String>();
        for (Iterator<Entry<String, String[]>> iter = request.getParameterMap().entrySet().iterator(); iter
                .hasNext(); ) {
            Entry<String, String[]> entry = iter.next();
            String key = entry.getKey();
            String vals = "";
            for (String val : entry.getValue()) {
                vals += val;
            }
            if (requestContent != "")
                requestContent += "&";
            requestContent += key + "=" + vals;
            if (!key.equals("sid"))
                parameterMap.put(key, vals);
        }
        loggerSingleWork.info(String.format("seqid=%s,request=%s?%s", seqId, request.getRequestURI(), requestContent));

        // 公众参数合法性检查
        String errMsg = commonVo.checkMembers();
        if (StringUtils.isNotBlank(errMsg)) {
            Object response = ResponseUtils.makeErrResponse("101", "Parameter error", "invalid-parameter", errMsg);
            loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
            return response;
        }

        // 消息体参数检查
        String msgType = commonVo.getMsgtype();
        switch (msgType) {
            case "binding_Relation":
                errMsg = bindVo.checkMembers(commonVo.getTimestamp(), regex);
                if (StringUtils.isNotBlank(errMsg)) {
                    Object response = ResponseUtils.makeErrResponse("101", "Parameter error", "invalid-parameter", errMsg);
                    loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
                    return response;
                }
                break;
            case "remove_Relation":
                errMsg = unbindVo.checkMembers(regex);
                if (StringUtils.isNotBlank(errMsg)) {
                    Object response = ResponseUtils.makeErrResponse("101", "Parameter error", "invalid-parameter", errMsg);
                    loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
                    return response;
                }
                break;
            default:
                Object response = ResponseUtils.makeErrResponse("101", "Parameter error", "invalid-parameter",
                        "使用了本接口不支持的方法:" + msgType );
                loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
                return response;
        }

        // 根据unitid获取secret(用于计算签名)，后续考虑将secret放在缓存中
        String secret = unitService.getSecret(commonVo.getUnitID(), commonVo.getAppkey());
        if (StringUtils.isBlank(secret)) {
            Object response = ResponseUtils.makeErrResponse("101", "Parameter error", "key-error",
                    "使用了错误的unitID或appkey");
            loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
            return response;
        }

        // 签名检查
        try {
            if (!commonVo.getSid().equalsIgnoreCase(SignUtils.signTopRequest(parameterMap, secret, "MD5"))) {
                loggerSingleWork.error(String.format("seqid=%s,calculate_sign=%s", seqId,
                        SignUtils.signTopRequest(parameterMap, secret, "MD5")));
                Object response = ResponseUtils.makeErrResponse("101", "Parameter error", "sign-error", "签名错误");
                loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
                return response;
            }
        }  catch (IOException e) {
            loggerException.error(String.format("seqid=%s,Exception=%s", seqId, e.toString().replaceAll("\n", "|")));
            return ResponseUtils.makeExceptResponse("");
        }

        // 参数检查及签名校验通过，根据msgType执行对应操作
        switch (msgType) {
            case "binding_Relation":
                JSONObject response = (JSONObject) bindService.bindSingleReuse(loggerSingleWork, bindVo, seqId);
                if (null != response.get("binding_Relation_response")) { // 复用绑定成功时返回参数与普通绑定成功时不一样，进行下简化
                    ((JSONObject) response.get("binding_Relation_response")).remove("callrestrict");
                }
                loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
                return response;
            case "remove_Relation":
                return unbindService.unbindSingleReuse(loggerSingleWork, unbindVo, seqId);
        }
        return "";
    }

    @ResponseBody
    @RequestMapping("/batchWork")
    public Object dataManageBatch(BatchWorkVo batchWorkVo) {
        // 生成一个SequenceId,用于记录日志,同时也作为批量任务的编号
        String seqId = UUID.randomUUID().toString();
        // 通过getParameterMap获取"相对"原始的请求参数,分别存放在requestContent（用于记录日志）和parameterMap（用于计算签名）。通过spring注入bean获取的参数会忽略掉bean里不需要的参数
        String requestContent = "";
        Map<String, String> parameterMap = new HashMap<String, String>();
        for (Iterator<Entry<String, String[]>> iter = request.getParameterMap().entrySet().iterator(); iter
                .hasNext(); ) {
            Entry<String, String[]> entry = iter.next();
            String key = entry.getKey();
            String vals = "";
            for (String val : entry.getValue()) {
                vals += val;
            }
            if (requestContent != "")
                requestContent += "&";
            requestContent += key + "=" + vals;
            if (!key.equals("sid"))
                parameterMap.put(key, vals);
        }
        loggerBatchWork.info(String.format("seqid=%s,request=%s?%s", seqId, request.getRequestURI(), requestContent));

        // 参数合法性检查
        String errMsg = batchWorkVo.checkMembers();
        if (StringUtils.isNotBlank(errMsg)) {
            Object response = ResponseUtils.makeErrResponse("101", "Parameter error", "invalid-parameter", errMsg);
            loggerBatchWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
            return response;
        }

        // 参数检查及签名校验通过，根据msgType执行对应操作
        switch (batchWorkVo.getMsgtype()) {
            case "batch_bind": {
                // 读取上传的数据文件
                String[] header = {"\t电话号", "\t自定义编号", "\t有效期"};
                List<List<String>> requestRecords = CSVUtils.readCsvFile(batchWorkVo.getSrcFile(), header);
                // 判断读取结果
                if (null == requestRecords) {
                    Object response = ResponseUtils.makeErrResponse("102", "Data error", "data-not-available", "读取上传文件错误");
                    loggerBatchWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
                    return response;
                }
                // 如果有表头则去掉表头
                if (1 <= requestRecords.size()) {
                    List<String> first = requestRecords.get(0);
                    if (StringUtils.isNotBlank(first.get(0)) && StringUtils.equals("电话号", first.get(0).trim())) {
                        requestRecords.remove(0);
                    }
                }
                // 判断请求数量是否可接受
                if (0 >= requestRecords.size()) {
                    Object response = ResponseUtils.makeErrResponse("102", "Data error", "data-range-error", "绑定数据不能为空");
                    loggerBatchWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
                    return response;
                }
                if (200000 < requestRecords.size()) {
                    Object response = ResponseUtils.makeErrResponse("102", "Data error", "data-range-error",
                            "单次绑定数量不能超过200000");
                    loggerBatchWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
                    return response;
                }
                // 检查号码资源是否足够
                if (uidlistService.getUIDCount(batchWorkVo.getUnitID(), batchWorkVo.getUidType()) < requestRecords.size()) {
                    Object response = ResponseUtils.makeErrResponse("201", "Service error", "resource-insufficient",
                            "号码资源不足");
                    loggerBatchWork.info(String.format("session=%s,response=%s", seqId, response.toString()));
                    return response;
                }
                // 启动后台任务
                try {
                    bindService.bindBatch(loggerBatchWork, requestRecords, batchWorkVo.getUnitID(), batchWorkVo.getUidType(), seqId, batchWorkVo.getSrcFile(), batchWorkVo.getOpmodule(), batchWorkVo.getOpuser());
                    JSONObject response = new JSONObject();
                    JSONObject msgBody = new JSONObject();
                    msgBody.put("result", 0);
                    msgBody.put("batchworkid", seqId);
                    response.put("batch_bind", msgBody);
                    loggerBatchWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
                    return response;
                }  catch (Exception e) {
                    loggerException.error(String.format("seqid=%s,Exception=%s", seqId, e.toString().replaceAll("\n", "|")));
                    return ResponseUtils.makeExceptResponse("");
                }
            }
            case "batch_unbind": {
                // 读取上传的数据文件
                String[] header = {"\t95号", "\t自定义编号"};
                List<List<String>> requestRecords = CSVUtils.readCsvFile(batchWorkVo.getSrcFile(), header);
                // 判断读取结果
                if (null == requestRecords) {
                    Object response = ResponseUtils.makeErrResponse("102", "Data error", "data-not-available", "读取上传文件错误");
                    loggerBatchWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
                    return response;
                }
                // 如果有表头则去掉表头
                if (1 <= requestRecords.size()) {
                    List<String> first = requestRecords.get(0);
                    if (StringUtils.isNotBlank(first.get(0)) && StringUtils.equals("95号", first.get(0).trim())) {
                        requestRecords.remove(0);
                    }
                }
                // 判断请求数量是否可接受
                if (0 >= requestRecords.size()) {
                    Object response = ResponseUtils.makeErrResponse("102", "Data error", "data-range-error", "解绑数据不能为空");
                    loggerBatchWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
                    return response;
                }
                if (200000 < requestRecords.size()) {
                    Object response = ResponseUtils.makeErrResponse("102", "Data error", "data-range-error",
                            "单次解绑数量不能超过200000");
                    loggerBatchWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
                    return response;
                }
                // 启动后台任务
                try {
                    unbindService.unbindBatch(loggerBatchWork, requestRecords, batchWorkVo.getUnitID(), batchWorkVo.getUidType(), seqId, batchWorkVo.getSrcFile(), batchWorkVo.getOpmodule(), batchWorkVo.getOpuser());
                    JSONObject response = new JSONObject();
                    JSONObject msgBody = new JSONObject();
                    msgBody.put("result", 0);
                    msgBody.put("batchworkid", seqId);
                    response.put("batch_unbind", msgBody);
                    loggerBatchWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
                    return response;
                }  catch (Exception e) {
                    loggerException.error(String.format("seqid=%s,Exception=%s", seqId, e.toString().replaceAll("\n", "|")));
                    return ResponseUtils.makeExceptResponse("");
                }
            }
            case "batch_extend": {
                // 读取上传的数据文件
                String[] header = {"\t95号", "\t自定义编号", "\t有效期"};
                List<List<String>> requestRecords = CSVUtils.readCsvFile(batchWorkVo.getSrcFile(), header);
                // 判断读取结果
                if (null == requestRecords) {
                    Object response = ResponseUtils.makeErrResponse("102", "Data error", "data-not-available", "读取上传文件错误");
                    loggerBatchWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
                    return response;
                }
                // 如果有表头则去掉表头
                if (1 <= requestRecords.size()) {
                    List<String> first = requestRecords.get(0);
                    if (StringUtils.isNotBlank(first.get(0)) && StringUtils.equals("95号", first.get(0).trim())) {
                        requestRecords.remove(0);
                    }
                }
                // 判断请求数量是否可接受
                if (0 >= requestRecords.size()) {
                    Object response = ResponseUtils.makeErrResponse("102", "Data error", "data-range-error", "延期数据不能为空");
                    loggerBatchWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
                    return response;
                }
                if (200000 < requestRecords.size()) {
                    Object response = ResponseUtils.makeErrResponse("102", "Data error", "data-range-error",
                            "单次延期数量不能超过200000");
                    loggerBatchWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
                    return response;
                }
                // 启动后台任务
                try {
                    extendService.extendBatch(loggerBatchWork, requestRecords, batchWorkVo.getUnitID(), batchWorkVo.getUidType(), seqId, batchWorkVo.getSrcFile(), batchWorkVo.getOpmodule(), batchWorkVo.getOpuser());
                    JSONObject response = new JSONObject();
                    JSONObject msgBody = new JSONObject();
                    msgBody.put("result", 0);
                    msgBody.put("batchworkid", seqId);
                    response.put("batch_extend", msgBody);
                    loggerBatchWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
                    return response;
                }  catch (Exception e) {
                    loggerException.error(String.format("seqid=%s,Exception=%s", seqId, e.toString().replaceAll("\n", "|")));
                    return ResponseUtils.makeExceptResponse("");
                }
            }
            // 批量撤单操作
            case "batch_cancel": {
                // 读取上传的数据文件
                String[] header = {"\t95号", "\t自定义编号"};
                List<List<String>> requestRecords = CSVUtils.readCsvFile(batchWorkVo.getSrcFile(), header);
                // 判断读取结果
                if (null == requestRecords) {
                    Object response = ResponseUtils.makeErrResponse("102", "Data error", "data-not-available", "读取上传文件错误");
                    loggerBatchWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
                    return response;
                }
                // 如果有表头则去掉表头
                if (1 <= requestRecords.size()) {
                    List<String> first = requestRecords.get(0);
                    if (StringUtils.isNotBlank(first.get(0)) && StringUtils.equals("95号", first.get(0).trim())) {
                        requestRecords.remove(0);
                    }
                }
                // 判断请求数量是否可接受
                if (0 >= requestRecords.size()) {
                    Object response = ResponseUtils.makeErrResponse("102", "Data error", "data-range-error", "解绑数据不能为空");
                    loggerBatchWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
                    return response;
                }
                if (200000 < requestRecords.size()) {
                    Object response = ResponseUtils.makeErrResponse("102", "Data error", "data-range-error",
                            "单次撤单数量不能超过200000");
                    loggerBatchWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
                    return response;
                }
                // 启动后台任务
                try {
                    cancelService.cancelBatch(loggerBatchWork, requestRecords, batchWorkVo.getUnitID(), batchWorkVo.getUidType(), seqId, batchWorkVo.getSrcFile(), batchWorkVo.getOpmodule(), batchWorkVo.getOpuser());
                    JSONObject response = new JSONObject();
                    JSONObject msgBody = new JSONObject();
                    msgBody.put("result", 0);
                    msgBody.put("batchworkid", seqId);
                    response.put("batch_cancel", msgBody);
                    loggerBatchWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
                    return response;
                }  catch (Exception e) {
                    loggerException.error(String.format("seqid=%s,Exception=%s", seqId, e.toString().replaceAll("\n", "|")));
                    return ResponseUtils.makeExceptResponse("");
                }
            }
        }
        return "";
    }

    // 撤销绑定请求
    @ResponseBody
    @RequestMapping("/cancelRelation")
    public Object cancelRelation(CommonVo1 commonVo, DataUnbindVo unbindVo) {
        // 生成一个SequenceId,用于记录日志
        String seqId = UUID.randomUUID().toString();
        // 通过getParameterMap获取"相对"原始的请求参数,分别存放在requestContent（用于记录日志）和parameterMap（用于计算签名）。通过spring注入bean获取的参数会忽略掉bean里不需要的参数
        String requestContent = "";
        Map<String, String> parameterMap = new HashMap<String, String>();
        for (Iterator<Entry<String, String[]>> iter = request.getParameterMap().entrySet().iterator(); iter
                .hasNext(); ) {
            Entry<String, String[]> entry = iter.next();
            String key = entry.getKey();
            String vals = "";
            for (String val : entry.getValue()) {
                vals += val;
            }
            if (requestContent != "")
                requestContent += "&";
            requestContent += key + "=" + vals;
            if (!key.equals("sid"))
                parameterMap.put(key, vals);
        }
        loggerSingleWork.info(String.format("seqid=%s,request=%s?%s", seqId, request.getRequestURI(), requestContent));

        // 公众参数合法性检查
        String errMsg = commonVo.checkMembers();
        if (StringUtils.isNotBlank(errMsg)) {
            Object response = ResponseUtils.makeErrResponse("101", "Parameter error", "invalid-parameter", errMsg);
            loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
            return response;
        }

        // 消息体参数检查
        String msgType = commonVo.getMsgtype();
        switch (msgType) {
            case "cancel_Relation":
                errMsg = unbindVo.checkMembers(regex);
                if (StringUtils.isNotBlank(errMsg)) {
                    Object response = ResponseUtils.makeErrResponse("101", "Parameter error", "invalid-parameter", errMsg);
                    loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
                    return response;
                }
                break;
            default:
                Object response = ResponseUtils.makeErrResponse("101", "Parameter error", "invalid-parameter",
                        "使用了本接口不支持的方法:" + msgType );
                loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
                return response;
        }

        // 根据unitid获取secret(用于计算签名)，后续考虑将secret放在缓存中
        String secret = unitService.getSecret(commonVo.getUnitID(), commonVo.getAppkey());
        if (StringUtils.isBlank(secret)) {
            Object response = ResponseUtils.makeErrResponse("101", "Parameter error", "key-error",
                    "使用了错误的unitID或appkey");
            loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
            return response;
        }

        // 签名检查
        try {
            if (!commonVo.getSid().equalsIgnoreCase(SignUtils.signTopRequest(parameterMap, secret, "MD5"))) {
                loggerSingleWork.error(String.format("seqid=%s,calculate_sign=%s", seqId,
                        SignUtils.signTopRequest(parameterMap, secret, "MD5")));
                Object response = ResponseUtils.makeErrResponse("101", "Parameter error", "sign-error", "签名错误");
                loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
                return response;
            }
        }  catch (IOException e) {
            loggerException.error(String.format("seqid=%s,Exception=%s", seqId, e.toString().replaceAll("\n", "|")));
            return ResponseUtils.makeExceptResponse("");
        }

        // 参数检查及签名校验通过，根据msgType执行对应操作
        switch (msgType) {
            case "cancel_Relation":
                try {
                    JSONObject response = (JSONObject) cancelService.cancelSingle(loggerSingleWork, unbindVo, seqId);
                    //取消时返回参数与普通解绑时不一样，进行下修改
                    response.put("cancel_Relation_response", response.get("binding_Relation_response"));
                    response.remove("binding_Relation_response");
                    return response;
                }  catch (Exception e) {
                    loggerException.error(String.format("seqid=%s,Exception=%s", seqId, e.toString().replaceAll("\n", "|")));
                    return ResponseUtils.makeExceptResponse("");
                }
        }

        return "";

    }

    // 查询绑定关系请求
    @ResponseBody
    @RequestMapping("/queryRelation")
    public Object queryRelation(CommonVo1 commonVo, DataQueryVo dataQueryVo, String uidType) {
        // 生成一个SequenceId,用于记录日志
        String seqId = UUID.randomUUID().toString();
        // 通过getParameterMap获取"相对"原始的请求参数,分别存放在requestContent（用于记录日志）和parameterMap（用于计算签名）。通过spring注入bean获取的参数会忽略掉bean里不需要的参数
        String requestContent = "";
        Map<String, String> parameterMap = new HashMap<String, String>();
        for (Iterator<Entry<String, String[]>> iter = request.getParameterMap().entrySet().iterator(); iter
                .hasNext(); ) {
            Entry<String, String[]> entry = iter.next();
            String key = entry.getKey();
            String vals = "";
            for (String val : entry.getValue()) {
                vals += val;
            }
            if (requestContent != "")
                requestContent += "&";
            requestContent += key + "=" + vals;
            if (!key.equals("sid"))
                parameterMap.put(key, vals);
        }
        loggerSingleWork.info(String.format("seqid=%s,request=%s?%s", seqId, request.getRequestURI(), requestContent));

        // 公众参数合法性检查
        String errMsg = commonVo.checkMembers();
        if (StringUtils.isNotBlank(errMsg)) {
            Object response = ResponseUtils.makeErrResponse("101", "Parameter error", "invalid-parameter", errMsg);
            loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
            return response;
        }

        // 消息体参数检查
        String msgType = commonVo.getMsgtype();
        switch (msgType) {
            case "query_Relation":
                errMsg = dataQueryVo.checkMembers(regex);
                if (StringUtils.isNotBlank(errMsg)) {
                    Object response = ResponseUtils.makeErrResponse("101", "Parameter error", "invalid-parameter", errMsg);
                    loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
                    return response;
                }
                break;
            case "query_Remains":
                if (StringUtils.isBlank(uidType)) {
                    errMsg = "uidType不能为空";
                    Object response = ResponseUtils.makeErrResponse("101", "Parameter error", "invalid-parameter", errMsg);
                    loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
                    return response;
                }
                if (!StringUtils.equals("0", uidType) && !StringUtils.equals("1", uidType)) {
                    errMsg = "uidType只能为0或1";
                    Object response = ResponseUtils.makeErrResponse("101", "Parameter error", "invalid-parameter", errMsg);
                    loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
                    return response;
                }
                break;
            default:
                Object response = ResponseUtils.makeErrResponse("101", "Parameter error", "invalid-parameter",
                        "使用了本接口不支持的方法:" + msgType );
                loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
                return response;
        }

        // 请求参数unitId不是0时进行签名检查
        if (!StringUtils.equals("0", commonVo.getUnitID())) {
            // 根据unitid获取secret(用于计算签名)，后续考虑将secret放在缓存中
            String secret = unitService.getSecret(commonVo.getUnitID(), commonVo.getAppkey());
            if (StringUtils.isBlank(secret)) {
                Object response = ResponseUtils.makeErrResponse("101", "Parameter error", "key-error",
                        "使用了错误的unitID或appkey");
                loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
                return response;
            }

            // 签名检查
            try {
                if (!commonVo.getSid().equalsIgnoreCase(SignUtils.signTopRequest(parameterMap, secret, "MD5"))) {
                    loggerSingleWork.error(String.format("seqid=%s,calculate_sign=%s", seqId,
                            SignUtils.signTopRequest(parameterMap, secret, "MD5")));
                    Object response = ResponseUtils.makeErrResponse("101", "Parameter error", "sign-error", "签名错误");
                    loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
                    return response;
                }
            }  catch (IOException e) {
                loggerException.error(String.format("seqid=%s,Exception=%s", seqId, e.toString().replaceAll("\n", "|")));
                return ResponseUtils.makeExceptResponse("");
            }
        }

        // 参数检查及签名校验通过，根据msgType执行对应操作
        switch (msgType) {
            case "query_Relation":
                try {
                    JSONObject msgBody = new JSONObject();
                    msgBody.put("result", 0);
                    msgBody.put("items", queryService.queryBind(loggerSingleWork, dataQueryVo, seqId));
                    JSONObject response = new JSONObject();
                    response.put("query_Relation_response", msgBody);
                    loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
                    return response;
                }  catch (Exception e) {
                    loggerException.error(String.format("seqid=%s,Exception=%s", seqId, e.toString().replaceAll("\n", "|")));
                    return ResponseUtils.makeExceptResponse("");
                }

            case "query_Remains":   // 查询号码余量
                try {
                    JSONObject remains = new JSONObject();
                    remains.put("result", 0);
                    remains.put("remain_number", queryService.queryRemainNumbers(loggerSingleWork, commonVo.getUnitID(), uidType, seqId));
                    // 查询优先号池
                    long priorCount = queryService.queryPriorRemainNumbers(loggerSingleWork, commonVo.getUnitID(), uidType, seqId);
                    if (0 < priorCount) {
                        remains.put("prior_number", priorCount);
                    }
                    JSONObject remainsResponse = new JSONObject();
                    remainsResponse.put("query_Remains_response", remains);
                    loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, remainsResponse.toString()));
                    return remainsResponse;
                }  catch (Exception e) {
                    loggerException.error(String.format("seqid=%s,Exception=%s", seqId, e.toString().replaceAll("\n", "|")));
                    return ResponseUtils.makeExceptResponse("");
                }
        }

        return "";

    }

    // 延期绑定关系请求
    @ResponseBody
    @RequestMapping("/extendRelation")
    public Object extendRelation(CommonVo1 commonVo, DataExtendVo dataExtendVo) {
        // System.out.println(request.getScheme()+"://"+request.getServerName()+":"+request.getServerPort());
        // 生成一个SequenceId,用于记录日志
        String seqId = UUID.randomUUID().toString();
        // 通过getParameterMap获取"相对"原始的请求参数,分别存放在requestContent（用于记录日志）和parameterMap（用于计算签名）。通过spring注入bean获取的参数会忽略掉bean里不需要的参数
        String requestContent = "";
        Map<String, String> parameterMap = new HashMap<String, String>();
        for (Iterator<Entry<String, String[]>> iter = request.getParameterMap().entrySet().iterator(); iter
                .hasNext(); ) {
            Entry<String, String[]> entry = iter.next();
            String key = entry.getKey();
            String vals = "";
            for (String val : entry.getValue()) {
                vals += val;
            }
            if (requestContent != "")
                requestContent += "&";
            requestContent += key + "=" + vals;
            if (!key.equals("sid"))
                parameterMap.put(key, vals);
        }
        loggerSingleWork.info(String.format("seqid=%s,request=%s?%s", seqId, request.getRequestURI(), requestContent));

        // 公众参数合法性检查
        String errMsg = commonVo.checkMembers();
        if (StringUtils.isNotBlank(errMsg)) {
            Object response = ResponseUtils.makeErrResponse("101", "Parameter error", "invalid-parameter", errMsg);
            loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
            return response;
        }

        // 消息体参数检查
        String msgType = commonVo.getMsgtype();
        switch (msgType) {
            case "extend_Relation":
                errMsg = dataExtendVo.checkMembers(commonVo.getTimestamp(), regex);
                if (StringUtils.isNotBlank(errMsg)) {
                    Object response = ResponseUtils.makeErrResponse("101", "Parameter error", "invalid-parameter", errMsg);
                    loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
                    return response;
                }
                break;
            default:
                Object response = ResponseUtils.makeErrResponse("101", "Parameter error", "invalid-parameter",
                        "使用了本接口不支持的方法:" + msgType );
                loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
                return response;
        }

        // 根据unitid获取secret(用于计算签名)，后续考虑将secret放在缓存中
        String secret = unitService.getSecret(commonVo.getUnitID(), commonVo.getAppkey());
        if (StringUtils.isBlank(secret)) {
            Object response = ResponseUtils.makeErrResponse("101", "Parameter error", "key-error",
                    "使用了错误的unitID或appkey");
            loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
            return response;
        }

        // 签名检查
        try {
            if (!commonVo.getSid().equalsIgnoreCase(SignUtils.signTopRequest(parameterMap, secret, "MD5"))) {
                loggerSingleWork.error(String.format("seqid=%s,calculate_sign=%s", seqId,
                        SignUtils.signTopRequest(parameterMap, secret, "MD5")));
                Object response = ResponseUtils.makeErrResponse("101", "Parameter error", "sign-error", "签名错误");
                loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
                return response;
            }
        }  catch (IOException e) {
            loggerException.error(String.format("seqid=%s,Exception=%s", seqId, e.toString().replaceAll("\n", "|")));
            return ResponseUtils.makeExceptResponse("");
        }

        // 参数检查及签名校验通过，根据msgType执行对应操作
        switch (msgType) {
            case "extend_Relation":
                try {
                    return extendService.extendSingle(loggerSingleWork, dataExtendVo, seqId);
                }  catch (Exception e) {
                    loggerException.error(String.format("seqid=%s,Exception=%s", seqId, e.toString().replaceAll("\n", "|")));
                    return ResponseUtils.makeExceptResponse("");
                }
        }
        return "";
    }

    // 恢复绑定关系请求
    @ResponseBody
    @RequestMapping("/recoverRelation")
    public Object recoverRelation(CommonVo1 commonVo, DataRecoverVo dataRecoverVo) {
        // 生成一个SequenceId,用于记录日志
        String seqId = UUID.randomUUID().toString();
        // 通过getParameterMap获取"相对"原始的请求参数,分别存放在requestContent（用于记录日志）和parameterMap（用于计算签名）。通过spring注入bean获取的参数会忽略掉bean里不需要的参数
        String requestContent = "";
        Map<String, String> parameterMap = new HashMap<String, String>();
        for (Iterator<Entry<String, String[]>> iter = request.getParameterMap().entrySet().iterator(); iter
                .hasNext(); ) {
            Entry<String, String[]> entry = iter.next();
            String key = entry.getKey();
            String vals = "";
            for (String val : entry.getValue()) {
                vals += val;
            }
            if (requestContent != "")
                requestContent += "&";
            requestContent += key + "=" + vals;
            if (!key.equals("sid"))
                parameterMap.put(key, vals);
        }
        loggerSingleWork.info(String.format("seqid=%s,request=%s?%s", seqId, request.getRequestURI(), requestContent));

        // 公众参数合法性检查
        String errMsg = commonVo.checkMembers();
        if (StringUtils.isNotBlank(errMsg)) {
            Object response = ResponseUtils.makeErrResponse("101", "Parameter error", "invalid-parameter", errMsg);
            loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
            return response;
        }

        // 消息体参数检查
        String msgType = commonVo.getMsgtype();
        switch (msgType) {
            case "recover_Relation":
                errMsg = dataRecoverVo.checkMembers(commonVo.getTimestamp(), regex);
                if (StringUtils.isNotBlank(errMsg)) {
                    Object response = ResponseUtils.makeErrResponse("101", "Parameter error", "invalid-parameter", errMsg);
                    loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
                    return response;
                }
                break;
            default:
                Object response = ResponseUtils.makeErrResponse("101", "Parameter error", "invalid-parameter",
                        "使用了本接口不支持的方法:" + msgType );
                loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
                return response;
        }

        if (!StringUtils.equals("0", commonVo.getUnitID())) {
            // 根据unitid获取secret(用于计算签名)，后续考虑将secret放在缓存中
            String secret = unitService.getSecret(commonVo.getUnitID(), commonVo.getAppkey());
            if (StringUtils.isBlank(secret)) {
                Object response = ResponseUtils.makeErrResponse("101", "Parameter error", "key-error",
                        "使用了错误的unitID或appkey");
                loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
                return response;
            }

            // 签名检查
            try {
                if (!commonVo.getSid().equalsIgnoreCase(SignUtils.signTopRequest(parameterMap, secret, "MD5"))) {
                    loggerSingleWork.error(String.format("seqid=%s,calculate_sign=%s", seqId,
                            SignUtils.signTopRequest(parameterMap, secret, "MD5")));
                    Object response = ResponseUtils.makeErrResponse("101", "Parameter error", "sign-error", "签名错误");
                    loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
                    return response;
                }
            }  catch (IOException e) {
                loggerException.error(String.format("seqid=%s,Exception=%s", seqId, e.toString().replaceAll("\n", "|")));
                return ResponseUtils.makeExceptResponse("");
            }
        }

        // 参数检查及签名校验通过，根据msgType执行对应操作
        switch (msgType) {
            case "recover_Relation":
                try {
                    return bindService.recoverSingle(loggerSingleWork, dataRecoverVo, seqId);
                } catch (Exception e) {
                    loggerException.error(String.format("seqid=%s,Exception=%s", seqId, e.toString().replaceAll("\n", "|")));
                    return ResponseUtils.makeExceptResponse("");
                }
        }

        return "";
    }

    /**
     * pop推送绑定接口
     * @param popBind
     * @return
     */
    @ResponseBody
    @RequestMapping("/popBinding")
    public Object popBinding(CrypticBindVo popBind) {

        // Map<String, String[]> map =  request.getParameterMap();
        // 生成一个SequenceId,用于记录日志
        String seqId = UUID.randomUUID().toString();
        // 校验数据
        String checkResult = popBind.checkMembers();
        if (StringUtils.isNotBlank(checkResult)) {
            Object response = ResponseUtils.makeHeaderResponse("101", checkResult);
            loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
            return TransADESUtils.getInstance().encrypt(response.toString());
        }
        // 校验签名
        String data = TransADESUtils.getInstance().decrypt(popBind.getData());
        // 请求日志
        loggerSingleWork.info(String.format("seqid=%s,request=%s?%s", seqId, request.getRequestURI(), "data=" + data));
        String sign = DigestUtils.md5Hex(data + regex.AES_SALT_JD);
        if (!StringUtils.equalsIgnoreCase(sign, popBind.getSign())) {
            loggerSingleWork.error(String.format("seqid=%s,calculate_sign=%s", seqId, sign));
            Object response = ResponseUtils.makeHeaderResponse("101", "签名错误");
            loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
            return TransADESUtils.getInstance().encrypt(response.toString());
        }
        // 校验通过
        POPBindVo bindVo = new POPBindVo();
        bindVo.setParam(data);
        bindVo.setUnitid(regex.JD_UNITID);
        // 校验实体
        String errMsg = bindVo.checkMembers(regex);
        if (StringUtils.isNotBlank(errMsg)) {
            Object response = ResponseUtils.makeHeaderResponse("101", errMsg);
            loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
            return TransADESUtils.getInstance().encrypt(response.toString());
        }
        // 通过，调用绑定
        try {
            Object response = popBindService.bindSingle(loggerSingleWork, bindVo, seqId);
            loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
            return TransADESUtils.getInstance().encrypt(response.toString());
        } catch (Exception e) {
            loggerException.error(String.format("seqid=%s,Exception=%s", seqId, e.toString().replaceAll("\n", "|")));
            return ResponseUtils.makeExceptResponse("");
        }
    }

    // 更改绑定关系参数接口
    @ResponseBody
    @RequestMapping("/changeRelation")
    public Object changeRelation(CommonVo1 commonVo, DataChangeVo changeVo) {
        // 生成一个SequenceId,用于记录日志
        String seqId = UUID.randomUUID().toString();
        String requestContent = "";
        Map<String, String> parameterMap = new HashMap<>();
        for (Iterator<Entry<String, String[]>> iter = request.getParameterMap().entrySet().iterator(); iter
                .hasNext(); ) {
            Entry<String, String[]> entry = iter.next();
            String key = entry.getKey();
            String vals = "";
            for (String val : entry.getValue()) {
                vals += val;
            }
            if (requestContent != "")
                requestContent += "&";
            requestContent += key + "=" + vals;
            if (!key.equals("sid"))
                parameterMap.put(key, vals);
        }
        loggerSingleWork.info(String.format("seqid=%s,request=%s?%s", seqId, request.getRequestURI(), requestContent));

        // 公众参数合法性检查
        String errMsg = commonVo.checkMembers();
        if (StringUtils.isNotBlank(errMsg)) {
            Object response = ResponseUtils.makeErrResponse("101", "Parameter error", "invalid-parameter", errMsg);
            loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
            return response;
        }

        // 消息体参数检查
        String msgType = commonVo.getMsgtype();
        switch (msgType) {
            case "change_Relation":
                errMsg = changeVo.checkMembers(regex);
                if (StringUtils.isNotBlank(errMsg)) {
                    Object response = ResponseUtils.makeErrResponse("101", "Parameter error", "invalid-parameter", errMsg);
                    loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
                    return response;
                }
                break;
            default:
                Object response = ResponseUtils.makeErrResponse("101", "Parameter error", "invalid-parameter",
                        "使用了本接口不支持的方法:" + msgType );
                loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
                return response;
        }

        // 根据unitid获取secret(用于计算签名)，后续考虑将secret放在缓存中
        String secret = unitService.getSecret(commonVo.getUnitID(), commonVo.getAppkey());
        if (StringUtils.isBlank(secret)) {
            Object response = ResponseUtils.makeErrResponse("101", "Parameter error", "key-error",
                    "使用了错误的unitID或appkey");
            loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
            return response;
        }

        // 签名检查
        try {
            if (!commonVo.getSid().equalsIgnoreCase(SignUtils.signTopRequest(parameterMap, secret, "MD5"))) {
                loggerSingleWork.error(String.format("seqid=%s,calculate_sign=%s", seqId,
                        SignUtils.signTopRequest(parameterMap, secret, "MD5")));
                Object response = ResponseUtils.makeErrResponse("101", "Parameter error", "sign-error", "签名错误");
                loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
                return response;
            }
        }  catch (IOException e) {
            loggerException.error(String.format("seqid=%s,Exception=%s", seqId, e.toString().replaceAll("\n", "|")));
            return ResponseUtils.makeExceptResponse("");
        }

        // 参数检查及签名校验通过，根据msgType执行对应操作
        switch (msgType) {
            case "change_Relation":
                try {
                    // 调用更改service
                    return changeService.change(loggerSingleWork, changeVo, seqId);
                }  catch (Exception e) {
                    loggerException.error(String.format("seqid=%s,Exception=%s", seqId, e.toString().replaceAll("\n", "|")));
                    return ResponseUtils.makeExceptResponse("");
                }
        }
        return "";
    }
}
