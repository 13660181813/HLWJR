package com.cvtt.safenumber.dao;

import com.cvtt.safenumber.pojo.TRegnumSource;


public interface TRegnumSourceMapper {
    TRegnumSource selectByPrimaryKey(String uidnumber);
}