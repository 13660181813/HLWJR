package com.cvtt.safenumber.crypt;

/**
 * @decription ADESInterface
 * <p></p>
 * @author Yampery
 * @date 2017/10/24 13:15
 */
public interface ADESInterface {
    public <T> T encryptSelf();
    public <T> T decryptSelf();
}
