package com.cvtt.safenumber.dao;

import com.cvtt.safenumber.pojo.TPlayTemplate;
import com.cvtt.safenumber.pojo.TPlayTemplateExample;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

public interface TPlayTemplateMapper {
    long countByExample(TPlayTemplateExample example);

    int deleteByExample(TPlayTemplateExample example);

    int insert(TPlayTemplate record);

    int insertSelective(TPlayTemplate record);

    List<TPlayTemplate> selectByExample(TPlayTemplateExample example);

    int updateByExampleSelective(@Param("record") TPlayTemplate record, @Param("example") TPlayTemplateExample example);

    int updateByExample(@Param("record") TPlayTemplate record, @Param("example") TPlayTemplateExample example);

    TPlayTemplate selectByTemplateId(Map map);
}