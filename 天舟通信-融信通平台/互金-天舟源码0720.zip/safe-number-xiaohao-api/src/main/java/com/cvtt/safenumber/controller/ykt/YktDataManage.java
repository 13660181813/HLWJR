package com.cvtt.safenumber.controller.ykt;

import com.alibaba.fastjson.JSONObject;
import com.cvtt.safenumber.constents.Regex;
import com.cvtt.safenumber.service.ykt.IYktNumberService;
import com.cvtt.safenumber.utils.JsonUtils;
import com.cvtt.safenumber.utils.ResponseUtils;
import com.cvtt.safenumber.vo.ykt.BindVo;
import com.cvtt.safenumber.vo.ykt.CommonVo;
import com.cvtt.safenumber.vo.ykt.ExtendVo;
import com.cvtt.safenumber.vo.ykt.UnbindVo;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.Map;
import java.util.UUID;

/**
 * @decription YktDataManage
 * <p>美团数据维护接口</p>
 * @author Yampery
 * @date 2018/4/16 10:09
 */
@RestController
@RequestMapping("/ykt-pool/number")
public class YktDataManage extends YktAbstractManage {

    @Resource private Regex regex;
    @Resource private IYktNumberService numberService;
    @Resource private HttpServletRequest request;

    /**
     * 绑定接口
     * @param bindVo
     * @return
     */
    @RequestMapping("/binding")
    public Object binding(@RequestBody BindVo bindVo) {
        // 1. 生成seqId，记录请求日志
        String seqId = UUID.randomUUID().toString();
        String paramJson = JsonUtils.objectToJson(bindVo);
        loggerSingleWork.info(String.format("seqid=%s,request=%s,param=%s",
                seqId, request.getRequestURI(), paramJson));
        // 2. 请求体校验
        JSONObject check = bindVo.checkMembers(regex);
        if (null != check) {
            loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, check.toJSONString()));
            return check;
        }
        // 3. 请求体检查通过，进行签名校验
        Map<String, String> parameterMap;
        try {
            parameterMap = JsonUtils.jsonToPojo(paramJson, Map.class);
            parameterMap.remove("callDisplay");
            JSONObject signValid = yxtSignValid(parameterMap, seqId);
            if (null != signValid) {
                return signValid;
            }
            // 4. 验签通过，调用绑定
            bindVo.setUnitid(regex.YKT_UNITID);
            Object response = numberService.bindSingle(bindVo, seqId, loggerSingleWork);
            loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
            return response;
        } catch (Exception e) {
            JSONObject response = ResponseUtils.makeYxtResponse(12, "服务器暂时不可用", null);
            loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toJSONString()));
            loggerException.error(String.format("seqid=%s,Exception=%s", seqId, e.toString().replaceAll("\n", "|")));
            return response;
        }
    }

    /**
     * 解绑接口
     * @param unbindVo
     * @return
     */
    @RequestMapping("/unbind")
    public Object unbind(@RequestBody UnbindVo unbindVo) {
        // 1. 生成seqId记录日志
        String seqId = UUID.randomUUID().toString();
        String paramJson = JsonUtils.objectToJson(unbindVo);
        loggerSingleWork.info(String.format("seqid=%s,request=%s,param=%s",
                seqId, request.getRequestURI(), paramJson));
        // 2. 请求体校验
        JSONObject check = unbindVo.checkMembers(regex);
        if (null != check) {
            loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, check.toJSONString()));
            return check;
        }
        // 3. 请求体检查通过，进行签名校验
        Map<String, String> parameterMap;
        JSONObject response;
        try {
            parameterMap = JsonUtils.jsonToPojo(paramJson, Map.class);

            JSONObject signValid = yxtSignValid(parameterMap, seqId);
            if (null != signValid) {
                return signValid;
            }
            // 4. 验签通过，调用解绑
            unbindVo.setUnitid(regex.YKT_UNITID);
            response = (JSONObject) numberService.unbind(unbindVo, seqId, loggerSingleWork);
            loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
        } catch (Exception e) {
            response = ResponseUtils.makeYxtResponse(12, "服务器暂时不可用", null);
            loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toJSONString()));
            loggerException.error(String.format("seqid=%s,Exception=%s", seqId, e.toString().replaceAll("\n", "|")));
        }
        // 5. 异步调用解绑事件推送
        if (0 == response.getInteger("code"))
            numberService.pushUnbindEvent(unbindVo, seqId, regex.YKT_URL + regex.YKT_URL_UNBIND, loggerSingleWork);
        return response;
    }

    /**
     * 更改有效期
     * @param extendVo
     * @return
     */
    @RequestMapping("/update-expiration-binded")
    public Object extend(@RequestBody ExtendVo extendVo) {
        // 1. 生成seqId记录日志
        String seqId = UUID.randomUUID().toString();
        String paramJson = JsonUtils.objectToJson(extendVo);
        loggerSingleWork.info(String.format("seqid=%s,request=%s,param=%s",
                seqId, request.getRequestURI(), paramJson));
        // 2. 请求体校验
        JSONObject check = extendVo.checkMembers(regex);
        if (null != check) {
            loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, check.toJSONString()));
            return check;
        }
        // 3. 请求体检查通过，进行签名校验
        Map<String, String> parameterMap;
        try {
            parameterMap = JsonUtils.jsonToPojo(paramJson, Map.class);
            JSONObject signValid = yxtSignValid(parameterMap, seqId);
            if (null != signValid) {
                return signValid;
            }
            // 4. 验签通过，调用更改有效期
            extendVo.setUnitid(regex.YKT_UNITID);
            Object response = numberService.extend(extendVo, seqId, loggerSingleWork);
            loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
            return response;
        } catch (Exception e) {
            JSONObject response = ResponseUtils.makeYxtResponse(12, "服务器暂时不可用", null);
            loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toJSONString()));
            loggerException.error(String.format("seqid=%s,Exception=%s", seqId, e.toString().replaceAll("\n", "|")));
            return response;
        }
    }

    /**
     * 号池使用率
     * @param vo
     * @return
     */
    @RequestMapping("/utilization")
    public Object utilization(@RequestBody CommonVo vo) {
        // 1. 生成seqId记录日志
        String seqId = UUID.randomUUID().toString();
        String paramJson = JsonUtils.objectToJson(vo);
        loggerSingleWork.info(String.format("seqid=%s,request=%s,param=%s",
                seqId, request.getRequestURI(), paramJson));
        // 2. 请求体校验
        JSONObject check = vo.checkMembers(regex);
        if (null != check) {
            loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, check.toJSONString()));
            return check;
        }
        // 3. 请求体检查通过，进行签名校验
        Map<String, String> parameterMap;
        try {
            parameterMap = JsonUtils.jsonToPojo(paramJson, Map.class);
            JSONObject signValid = yxtSignValid(parameterMap, seqId);
            if (null != signValid) {
                return signValid;
            }
            Object response = numberService.utilization(regex.YKT_UNITID, "0");
            loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
            return response;
        } catch (Exception e) {
            JSONObject response = ResponseUtils.makeYxtResponse(12, "服务器暂时不可用", null);
            loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toJSONString()));
            loggerException.error(String.format("seqid=%s,Exception=%s", seqId, e.toString().replaceAll("\n", "|")));
            return response;
        }
    }
}
