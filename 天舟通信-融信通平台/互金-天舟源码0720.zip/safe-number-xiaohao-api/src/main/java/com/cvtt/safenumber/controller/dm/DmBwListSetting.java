/**
 * 关系数据相关接口(绑定，解绑，延期)
 */
package com.cvtt.safenumber.controller.dm;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.cvtt.safenumber.service.yd.YdBindService;
import com.cvtt.safenumber.utils.ResponseUtils;
import com.cvtt.safenumber.utils.SignUtils;
import com.cvtt.safenumber.vo.xz.DmDataBindVo;
import com.cvtt.safenumber.vo.xz.YdDataBindVo;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

@Controller
@RequestMapping("/xx")
public class DmBwListSetting {
	private static Logger loggerSingleWork = Logger.getLogger("DataManage.SingleWork");
	@Resource
	private  YdBindService ydBindService;
	@Value("${mt.appSecret}")
	private String MT_SECRETKEY;
	@Autowired
	private HttpServletRequest request;
	/**
	 * bwListSetting接口
	 *
	 * @param
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/bwListSetting")
	public String bwListSetting(@RequestBody Map<String,Object> models) {
		String seqId = UUID.randomUUID().toString();
		String requestId = UUID.randomUUID().toString().replace("-", "");
		// 签名请求体部分
		Map<String, String> param = new HashMap<>();
		param.put("requestid", requestId);
		param.put("action", models.get("action").toString());//add,move
		param.put("level", "appkey");//appkey 级别
		// 签名请求头部分
		param.put("appkey", "TZPT_0001");
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmssSSS");
		String ts=sdf.format(new Date());
		param.put("ts", ts);

		//待发送的请求体
		Map<String, Object> paramSend = new HashMap<>();
		paramSend.put("requestid", requestId);
		paramSend.put("action", models.get("action").toString());//add,move
		paramSend.put("level", "appkey");//appkey 级别 apkbw
		if(models.containsKey("apkbw")){
		  paramSend.put("apkbw", models.get("apkbw"));
		}

		//发送地址
		String url="http://spn.caihcom.com:9101/spn/secure/bwListSetting";

		//发送
		String result=httpPost(url,ts,getMsgdgt(loggerSingleWork,seqId,param),paramSend,loggerSingleWork,seqId,"POST");

		return result;
	}

	public String getMsgdgt(Logger logger, String seqId, Map<String, String> param) {
		List<String> list = new ArrayList<>(param.keySet());
		list = list.stream().filter(k -> StringUtils.isNotBlank(param.get(k))).sorted((k1, k2) -> k1.compareTo(k2))
				.collect(Collectors.toList());
		StringBuffer sb = new StringBuffer("dfjr_tzpt_1053");
		for (String key : list) {
			sb.append(key).append(param.get(key));
		}
        System.out.println("明文："+sb.toString());
		System.out.println("密文："+DigestUtils.md5Hex(sb.toString()).toUpperCase());
		return DigestUtils.md5Hex(sb.toString()).toUpperCase();
	}

	private String httpPost(String url, String ts, String msgdgt, Map<String, Object> param, Logger logger,
							String seqId, String method) {
		ObjectMapper objectMapper = new ObjectMapper();
		PrintWriter out = null;
		BufferedReader in = null;
		BufferedWriter bw = null;
		String result = "";
		try {
			URL realUrl = new URL(url);
			// 打开和URL之间的连接
			HttpURLConnection conn = (HttpURLConnection) realUrl.openConnection();
			// 设置通用的请求属性
			conn.setUseCaches(false);// 设置不使用缓存
			conn.setConnectTimeout(10 * 1000);// 设置连接超时
			conn.setRequestMethod(method);
			conn.setRequestProperty("connection", "Keep-Alive");
			conn.setRequestProperty("Accept", "application/json");
			conn.setRequestProperty("Content-Type", "application/json");
			conn.setRequestProperty("Charset", "UTF-8");
			conn.setRequestProperty("appkey", "TZPT_0001");
			conn.setRequestProperty("ts", ts);
			conn.setRequestProperty("msgdgt", msgdgt);

			// 发送POST请求必须设置如下两行
			conn.setDoOutput(true);
			conn.setDoInput(true);
			// 获取URLConnection对象对应的输出流
			bw = new BufferedWriter(new OutputStreamWriter(conn.getOutputStream(), "utf-8"));
			out = new PrintWriter(bw);
			// 发送请求参数
			out.print(objectMapper.writeValueAsString(param));
			// flush输出流的缓冲
			out.flush();
			// 定义BufferedReader输入流来读取URL的响应
			in = new BufferedReader(new InputStreamReader(conn.getInputStream(), "utf-8"));
			String line;
			while ((line = in.readLine()) != null) {
				result += line;
			}

			logger.info(String.format("seqid=%s,url=%s,request=%s", seqId, url,
					"小号接口请求参数:" + objectMapper.writeValueAsString(param)));
			logger.info(String.format("seqid=%s,url=%s,response=%s", seqId, url, "小号接口返回值:" + result));
			System.out.println("返回值："+result);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (out != null) {
					out.close();
				}
				if (in != null) {
					in.close();
				}
			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}

		return result;
	}





	/**
	 * 测试授权接口
	 *
	 * @param
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/test")
	public Object test(YdDataBindVo bindVo) {
		String seqId = UUID.randomUUID().toString();
//        System.out.println("bindVo:"+bindVo.getSubId().toString());
		return ydBindService.bindSingle(loggerSingleWork,bindVo,seqId);
        //return ydBindService.unbind(loggerSingleWork,bindVo,seqId);
        //return ydBindService.updateBind(loggerSingleWork,bindVo,seqId);
	}
    /**
     * 测试授权接口
     *
     * @param
     * @return
     */
    @ResponseBody
    @RequestMapping("/testAXB")
    public Object testAX(YdDataBindVo bindVo) {
        String seqId = UUID.randomUUID().toString();
//        System.out.println("bindVo:"+bindVo.getSubId().toString());
        return ydBindService.axbBindSingle(loggerSingleWork,bindVo,seqId);
        //return ydBindService.unbind(loggerSingleWork,bindVo,seqId);
        //return ydBindService.updateBind(loggerSingleWork,bindVo,seqId);
    }
	//签名算法
	public String getSignature(Logger logger, String seqId, Map<String, Object> param) {
		//算法：MD5($timestamp$secret[$httpbody])
		JSONObject itemJSONObj = JSONObject.parseObject(JSON.toJSONString(param));
		long timeStampSec = System.currentTimeMillis()/1000;
		String timestamp = String.format("%010d", timeStampSec);
		String ts=timestamp;
		StringBuffer sb = new StringBuffer();
		sb.append(ts);
		sb.append("du95lphf1rrs0cs2");
		sb.append(itemJSONObj);
		System.out.println("ts:"+ts);
		System.out.println("明文："+sb.toString());
		System.out.println("密文："+DigestUtils.md5Hex(sb.toString()).toUpperCase());
		return DigestUtils.md5Hex(sb.toString()).toUpperCase();
	}
	
 
}
