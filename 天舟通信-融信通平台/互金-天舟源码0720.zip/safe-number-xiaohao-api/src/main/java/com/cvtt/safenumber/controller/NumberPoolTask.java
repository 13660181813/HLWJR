package com.cvtt.safenumber.controller;

import com.cvtt.safenumber.utils.CommonUtils;
import com.cvtt.safenumber.utils.DateUtils;
import com.cvtt.safenumber.utils.RedisUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;
import java.util.Set;

/**
 * @decription NumberTask
 * <p>号码相关任务</p>
 * @author Yampery
 * @date 2018/1/24 11:36
 */
@Component
public class NumberPoolTask {

    @Resource private RedisUtils redisUtils;
    private static Logger loggerException = Logger.getLogger("Sys.Exception");
    private static Logger logger = Logger.getLogger(NumberPoolTask.class);

    /**
     * 优先号池自动清理
     * 每月1号0点执行清理，回放大号池
     */
    @Scheduled(cron = "0 0 0 1 * ?")
    public void priorPoolAutoClean() {

        // String str = "10000000003:0:prior";
        try {
            Set<String> priorSet = redisUtils.getSet("prior:pool");
            priorSet.forEach(s -> {
                // 1. 获取优先号码池
                String priorKey = redisUtils.get(s, "");
                if (StringUtils.isNotBlank(priorKey)) {
                    String key = priorKey.substring(0, priorKey.lastIndexOf(":"));
                    // 2. 获取优先号池号码
                    List<String> list = redisUtils.rangeList(priorKey, 0, -1);
                    if (!CommonUtils.isNull(list)) {
                        while (true) {
                            if (redisUtils.addSet(key, list.toArray(new String[list.size()]))) {
                                // 4. 清除
                                redisUtils.del(priorKey);
                                break;
                            }
                        }
                        logger.info("msg=本月清理完成&datetime="
                                + DateUtils.format(new Date(), DateUtils.DATE_TIME_PATTERN));
                    }

                }
            });
        } catch (Exception e) {
            // 如果出现异常，记录日志，结束执行
            loggerException.error("msg=优先号池清理定时器异常&exception="
                    + e.toString().replaceAll("\n", "|"));
        }
    }
}
