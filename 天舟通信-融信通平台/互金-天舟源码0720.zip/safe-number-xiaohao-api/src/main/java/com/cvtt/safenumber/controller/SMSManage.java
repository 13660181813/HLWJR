package com.cvtt.safenumber.controller;

import com.cvtt.safenumber.constents.Regex;
import com.cvtt.safenumber.pojo.TUnit;
import com.cvtt.safenumber.service.ISMSService;
import com.cvtt.safenumber.service.IUnitService;
import com.cvtt.safenumber.utils.ResponseUtils;
import com.cvtt.safenumber.utils.SignUtils;
import com.cvtt.safenumber.vo.CommonVo1;
import com.cvtt.safenumber.vo.SMSControllerVo;
import com.cvtt.safenumber.vo.SMSReleaseVo;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

/**
 * @decription SMSManage
 * <p>短信接口</p>
 * @author Yampery
 * @date 2017/9/12 15:32
 */
@RestController
@RequestMapping("/api/sms")
public class SMSManage {

    @Autowired
    private HttpServletRequest request;
    @Resource
    private Regex regex;
    @Resource
    private IUnitService unitService;
    @Resource private ISMSService smsService;

    private static Logger loggerSMSControl = LoggerFactory.getLogger("SMSManage.SMSControl");
    private static Logger loggerException = LoggerFactory.getLogger("Sys.Exception");

    /**
     * 安全号发送短信接口
     * @param commonVo
     * @param smsControlVo
     * @return
     */
    @RequestMapping("/smsManage")
    public Object smsManage(CommonVo1 commonVo, SMSControllerVo smsControlVo, SMSReleaseVo smsReleaseVo) {
        String seqId = UUID.randomUUID().toString();
        String requestContent = "";
        Map<String, String> parameterMap = new HashMap<String, String>();
        for (Iterator<Map.Entry<String, String[]>> iter = request.getParameterMap().entrySet().iterator(); iter
                .hasNext();) {
            Map.Entry<String, String[]> entry = iter.next();
            String key = entry.getKey();
            String vals = "";
            for (String val : entry.getValue()) {
                vals += val;
            }
            if (requestContent != "")
                requestContent += "&";
            requestContent += key + "=" + vals;
            if (!key.equals("sid"))
                parameterMap.put(key, vals);
        }
        loggerSMSControl.info(String.format("seqid=%s,request=%s?%s", seqId, request.getRequestURI(), requestContent));

        // 公众参数合法性检查
        String errMsg = commonVo.checkMembers();
        if (StringUtils.isNotBlank(errMsg)) {
            Object response = ResponseUtils.makeErrResponse("101", "Parameter error", "invalid-parameter", errMsg);
            loggerSMSControl.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
            return response;
        }

        // 消息体参数检查
        String msgType = commonVo.getMsgtype();
        switch (msgType) {
            case "sms_safenumber":
                errMsg = smsControlVo.checkMembers();
                if (StringUtils.isNotBlank(errMsg)) {
                    Object response = ResponseUtils.makeErrResponse("101", "Parameter error", "invalid-parameter", errMsg);
                    loggerSMSControl.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
                    return response;
                }
                break;
            case "sms_release":
                errMsg = smsReleaseVo.checkMembers(regex);
                if (StringUtils.isNotBlank(errMsg)) {
                    Object response = ResponseUtils.makeErrResponse("101", "Parameter error", "invalid-parameter", errMsg);
                    loggerSMSControl.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
                    return response;
                }
                break;

            default:
                Object response = ResponseUtils.makeErrResponse("101", "Parameter error", "invalid-parameter",
                        "使用了本接口不支持的方法");
                loggerSMSControl.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
                return response;
        }
        TUnit unit = null;
        // 单位id不是'0'时，需要校验签名
        if (!StringUtils.equals("0", commonVo.getUnitID())) {
            // 计算签名
            String secret = "";
            unit = unitService.getSecret(commonVo.getUnitID());
            if (null != unit) {
                if (StringUtils.equalsIgnoreCase(unit.getUnitkey(), commonVo.getAppkey())) {
                    if( null != unit.getSysApplication() )
                        secret = unit.getSysApplication().getAppSecret();
                }
            }

            if (StringUtils.isBlank(secret)) {
                Object response = ResponseUtils.makeErrResponse("101", "Parameter error", "key-error",
                        "使用了错误的unitID或appkey");
                loggerSMSControl.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
                return response;
            }

            // 签名检查
            try {
                if (!commonVo.getSid().equalsIgnoreCase(SignUtils.signTopRequest(parameterMap, secret, "MD5"))) {
                    loggerSMSControl.error(String.format("seqid=%s,calculate_sign=%s", seqId,
                            SignUtils.signTopRequest(parameterMap, secret, "MD5")));
                    Object response = ResponseUtils.makeErrResponse("101", "Parameter error", "sign-error", "签名错误");
                    loggerSMSControl.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
                    return response;
                }
            } catch (IOException e) {
                // e.printStackTrace();
                loggerException.error(String.format("seqid=%s,Exception=%s", seqId, e.toString().replaceAll("\n", "|")));
                return ResponseUtils.makeExceptResponse("");
            }
        }
        // 参数检查及签名校验通过，根据msgType执行对应操作
        switch (msgType) {
            case "sms_safenumber":
                String unittype = "0";
                if (!StringUtils.equals("0", commonVo.getUnitID())) {
                    unittype = StringUtils.isNotBlank(unit.getUnittype()) ? unit.getUnittype() : "1";
                }
                // invoke sms service
                try {
                    Object response = smsService.sendMsg(smsControlVo, unittype, seqId, loggerSMSControl);
                    loggerSMSControl.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
                    return response;
                } catch (Exception e) {
                    loggerException.error(String.format("seqid=%s,Exception=%s", seqId, e.toString().replaceAll("\n", "|")));
                    return ResponseUtils.makeExceptResponse("");
                }
            case "sms_release":
                try {
                    Object response = smsService.smsRelease(loggerSMSControl, smsReleaseVo, seqId);
                    loggerSMSControl.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
                    return response;
                } catch (Exception e) {
                    loggerException.error(String.format("seqid=%s,Exception=%s", seqId, e.toString().replaceAll("\n", "|")));
                    return ResponseUtils.makeExceptResponse("");
                }
        }
        return "未知错误";
    }
}
