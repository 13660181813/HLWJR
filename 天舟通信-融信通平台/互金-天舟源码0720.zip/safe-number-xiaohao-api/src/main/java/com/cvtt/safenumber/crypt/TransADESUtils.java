package com.cvtt.safenumber.crypt;

import org.apache.commons.codec.binary.Hex;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.crypto.Cipher;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.SecretKeySpec;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

/**
 * @decription TransADESUtils
 * <p>用于传输加解密</p>
 * @author Yampery
 * @date 2017/10/24 12:57
 */
@Component
public class TransADESUtils {
    private static final String ENCRYPT_TYPE = "AES";
    private static final String ENCODING = "UTF-8";

    // 密盐
    private static String AES_SALT;
    private static TransADESUtils adesUtils;
    private static Cipher encryptCipher;//加密cipher
    private static Cipher decryptChipher;//解密chipher

    @Value("${AES.SALT.JD:8445C55CB635FB10B667872001BFD9AE}")
    public void setAESSalt(String key){
        TransADESUtils.AES_SALT = key;
    }

    /**
     * encryptCipher、decryptChipher初始化
     */
    public static void init(){
        try {
            encryptCipher = Cipher.getInstance(ENCRYPT_TYPE);
            decryptChipher = Cipher.getInstance(ENCRYPT_TYPE);
            encryptCipher.init(Cipher.ENCRYPT_MODE, generateMySQLAESKey(AES_SALT, ENCODING));
            decryptChipher.init(Cipher.DECRYPT_MODE, generateMySQLAESKey(AES_SALT, ENCODING));
        } catch (InvalidKeyException e) {
            throw new RuntimeException(e);
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        } catch (NoSuchPaddingException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * 防止外部创建新的实例
     */
    private TransADESUtils() {  }

    /**
     * 获取单例
     * @return
     */
    public static TransADESUtils getInstance(){
        if(adesUtils == null){
            // 当需要创建的时候在加锁
            synchronized(TransADESUtils.class) {
                if (adesUtils == null) {
                    adesUtils = new TransADESUtils();
                    init();
                }
            }
        }
        return adesUtils;
    }

    /**
     * 对明文加密
     * @param pString
     * @return
     */
    public String encrypt(String pString) {

        if (StringUtils.isBlank(pString))
            return "";
        try{
            return new String(Hex.encodeHex(encryptCipher.doFinal(pString.getBytes(ENCODING)))).toUpperCase();
        } catch (Exception e) {
            e.printStackTrace();
            return pString;
        }
    }

    /**
     * 对密文解密
     * @param eString
     * @return
     */
    public String decrypt(String eString) {
        if (StringUtils.isBlank(eString))
            return "";
        try {
            return new String(decryptChipher.doFinal(Hex.decodeHex(eString.toCharArray())));
        } catch (Exception e) {
            e.printStackTrace();
            return eString;
        }
    }
    /**
     * 产生mysql-aes_encrypt
     * @param key 加密的密盐
     * @param encoding 编码
     * @return
     */
    public static SecretKeySpec generateMySQLAESKey(final String key, final String encoding) {
        try {
            final byte[] finalKey = new byte[16];
            int i = 0;
            for(byte b : Hex.decodeHex(key.toCharArray()))
                finalKey[i++%16] ^= b;
            return new SecretKeySpec(finalKey, "AES");
        } catch(Exception e) {
            throw new RuntimeException(e);
        }
    }
}
