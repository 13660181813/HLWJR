/**
 * 呼叫控制接口(查询呼叫控制，查询鉴权关系，挂机通知)
 */
package com.cvtt.safenumber.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.UUID;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import com.cvtt.safenumber.constents.Regex;
import com.cvtt.safenumber.service.IAuthControlService;
import com.cvtt.safenumber.vo.*;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cvtt.safenumber.utils.ResponseUtils;
import com.cvtt.safenumber.utils.SignUtils;
import com.cvtt.safenumber.service.IUnitService;
import com.alibaba.fastjson.JSONObject;
import com.cvtt.safenumber.service.IAuthService;
import com.cvtt.safenumber.service.ICallService;

@Controller
@RequestMapping("/api/Call")
public class CallManage {
	@Autowired
	private HttpServletRequest request;
	@Resource
	private IUnitService unitService;
	@Resource
	private IAuthService authService;
	@Resource
	private ICallService callService;
	@Resource
	private IAuthControlService authControlService;
	@Resource
	private Regex regex;
	
	private static Logger loggerCallControl = Logger.getLogger("CallManage.CallControl");
	private static Logger loggerException = Logger.getLogger("Sys.Exception");

	@ResponseBody
	@RequestMapping("/callControl")
	// 示例url
	public Object callManage(CommonVo2 commonVo, CallControlVo callControlVo, CallReleaseVo callReleaseVo, AuthCheckVo checkVo, AuthControlVo acVo) {
		// 生成一个SequenceId,用于记录日志
		String seqId = UUID.randomUUID().toString();
		// 通过getParameterMap获取"相对"原始的请求参数,分别存放在requestContent（用于记录日志）和parameterMap（用于计算签名）。通过spring注入bean获取的参数会忽略掉bean里不需要的参数
		String requestContent = "";
		Map<String, String> parameterMap = new HashMap<String, String>();
		for (Iterator<Entry<String, String[]>> iter = request.getParameterMap().entrySet().iterator(); iter
				.hasNext();) {
			Entry<String, String[]> entry = iter.next();
			String key = entry.getKey();
			String vals = "";
			for (String val : entry.getValue()) {
				vals += val;
			}
			if (requestContent != "")
				requestContent += "&";
			requestContent += key + "=" + vals;
			if (!key.equals("sign"))
				parameterMap.put(key, vals);
		}
		loggerCallControl.info(String.format("seqid=%s,request=%s?%s", seqId, request.getRequestURI(), requestContent));

		// 公众参数合法性检查
		String errMsg = commonVo.checkMembers();
		if (StringUtils.isNotBlank(errMsg)) {
			Object response = ResponseUtils.makeErrResponse("101", "Parameter error", "invalid-parameter", errMsg);
			loggerCallControl.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
			return response;
		}

		// 消息体参数检查
		String method = commonVo.getMethod();
		switch (method) {
		case "secret.call.control":
			errMsg = callControlVo.checkMembers(regex);
			if (StringUtils.isNotBlank(errMsg)) {
				Object response = ResponseUtils.makeErrResponse("101", "Parameter error", "invalid-parameter", errMsg);
				loggerCallControl.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
				return response;
			}
			break;
		case "secret.call.release":
			errMsg = callReleaseVo.checkMembers(regex);
			if (StringUtils.isNotBlank(errMsg)) {
				Object response = ResponseUtils.makeErrResponse("101", "Parameter error", "invalid-parameter", errMsg);
				loggerCallControl.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
				return response;
			}
			break;
		case "secret.call.authentication":
			errMsg = checkVo.checkMembers(regex);
			if (StringUtils.isNotBlank(errMsg)) {
				Object response = ResponseUtils.makeErrResponse("101", "Parameter error", "invalid-parameter", errMsg);
				loggerCallControl.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
				return response;
			}
			break;
		case "secret.call.authcontrol":
			errMsg = acVo.checkMembers(regex);
			if (StringUtils.isNotBlank(errMsg)) {
				Object response = ResponseUtils.makeErrResponse("101", "Parameter error", "invalid-parameter", errMsg);
				loggerCallControl.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
				return response;
			}
			break;
		default:
			Object response = ResponseUtils.makeErrResponse("101", "Parameter error", "invalid-parameter",
					"使用了本接口不支持的方法");
			loggerCallControl.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
			return response;
		}

		if (!StringUtils.equals("0", commonVo.getPartner_id())) {
			// 根据unitid获取secret(用于计算签名)，后续考虑将secret放在缓存中
			String secret;

			secret = unitService.getSecret(commonVo.getPartner_id(), commonVo.getApp_key());
			if (StringUtils.isBlank(secret)) {
				Object response = ResponseUtils.makeErrResponse("101", "Parameter error", "key-error",
						"使用了错误的unitID或appkey");
				loggerCallControl.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
				return response;
			}

			// 签名检查
			try {
				if (!commonVo.getSign().equalsIgnoreCase(SignUtils.signTopRequest(parameterMap, secret, "MD5"))) {
					loggerCallControl.error(String.format("seqid=%s,calculate_sign=%s", seqId,
							SignUtils.signTopRequest(parameterMap, secret, "MD5")));
					Object response = ResponseUtils.makeErrResponse("101", "Parameter error", "sign-error", "签名错误");
					loggerCallControl.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
					return response;
				}
			} catch (IOException e) {
				loggerException.error(String.format("seqid=%s,Exception=%s", seqId, e.toString().replaceAll("\n", "|")));
				return ResponseUtils.makeExceptResponse("");
			}
		}

		// 参数检查及签名校验通过，根据method执行对应操作
		switch (method) {
			case "secret.call.control":
				try {
					JSONObject response = (JSONObject) callService.callQuery(loggerCallControl, callControlVo, seqId);
					loggerCallControl.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
					return response;
				} catch (Exception e) {
					loggerException.error(String.format("seqid=%s,Exception=%s", seqId, e.toString().replaceAll("\n", "|")));
					return ResponseUtils.makeExceptResponse("");
				}

			case "secret.call.release":
				try {
					JSONObject response = (JSONObject) callService.callRelease(loggerCallControl, callReleaseVo, seqId);
					loggerCallControl.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
					return response;
				} catch (Exception e) {
					loggerException.error(String.format("seqid=%s,Exception=%s", seqId, e.toString().replaceAll("\n", "|")));
					return ResponseUtils.makeExceptResponse("");
				}

			case "secret.call.authentication":
				try {
					return authService.AuthCheck(loggerCallControl, checkVo, seqId);
				} catch (Exception e) {
					loggerException.error(String.format("seqid=%s,Exception=%s", seqId, e.toString().replaceAll("\n", "|")));
					return ResponseUtils.makeExceptResponse("");
				}
			case "secret.call.authcontrol":
				try {
					JSONObject response = (JSONObject) authControlService.callQuery(loggerCallControl, acVo, seqId);
					loggerCallControl.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
					return response;
				}  catch (Exception e) {
					loggerException.error(String.format("seqid=%s,Exception=%s", seqId, e.toString().replaceAll("\n", "|")));
					return ResponseUtils.makeExceptResponse("");
				}
		}
		return "";
	}
	/*
	@ResponseBody
	@RequestMapping("/getUnitInfo")
	// 示例url
	public Object getUnitInfo(CommonVo2 commonVo, CallControlVo callControlVo, CallReleaseVo callReleaseVo, AuthCheckVo checkVo) {
		TUnitUidsection unitUidsection = unitUidsectionDao.selectByUidnumber("95013777776000000");
		if( null != unitUidsection && null != unitUidsection.getUnitid()){
			TUnit unit = unitService.getSecret(unitUidsection.getUnitid());
			if( null != unit && null != unit.getSysApplication()){
				System.out.println(unit.getUnitkey());
				System.out.println(unit.getSysApplication().getAppSecret());
			}
		}else{
			
		}
		return null;
	}*/
}
