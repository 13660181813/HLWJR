package com.cvtt.safenumber.dao;

import com.cvtt.safenumber.pojo.TSMSTemplate;

import java.util.Map;

public interface TSMSTemplateMapper {
    
    int insert(TSMSTemplate record);

    int insertSelective(TSMSTemplate record);
    
    TSMSTemplate selectByTemplateId(Map map);
}