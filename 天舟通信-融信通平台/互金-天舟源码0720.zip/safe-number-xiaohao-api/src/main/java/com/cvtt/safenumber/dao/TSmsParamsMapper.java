package com.cvtt.safenumber.dao;

import com.cvtt.safenumber.pojo.TSmsParams;
import com.cvtt.safenumber.pojo.TSmsParamsExample;
import java.util.List;

public interface TSmsParamsMapper {
    int insert(TSmsParams record);

    int insertSelective(TSmsParams record);

    List<TSmsParams> selectByExample(TSmsParamsExample example);

    TSmsParams selectByUnitid(String unitid);
}