package com.cvtt.safenumber.dao;

import com.cvtt.safenumber.pojo.TExceptionCall;
import com.cvtt.safenumber.pojo.TExceptionCallExample;
import java.util.List;

public interface TExceptionCallMapper {
    int insert(TExceptionCall record);

    int insertSelective(TExceptionCall record);

    List<TExceptionCall> selectByExample(TExceptionCallExample example);
}