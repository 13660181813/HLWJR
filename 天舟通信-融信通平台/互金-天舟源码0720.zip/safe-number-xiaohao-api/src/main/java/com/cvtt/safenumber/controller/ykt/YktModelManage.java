package com.cvtt.safenumber.controller.ykt;

import com.alibaba.fastjson.JSONObject;
import com.cvtt.safenumber.constents.Regex;
import com.cvtt.safenumber.service.ykt.IYktModelService;
import com.cvtt.safenumber.utils.JsonUtils;
import com.cvtt.safenumber.utils.ResponseUtils;
import com.cvtt.safenumber.vo.ykt.ModelVo;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.Map;
import java.util.UUID;

/**
 * @decription YktModelManage
 * <p>美团厂商号码池</p>
 * @author Yampery
 * @date 2018/9/16 11:36
 */
@RestController
@RequestMapping("/model")
public class YktModelManage extends YktAbstractManage {

    @Resource private IYktModelService modelService;

    @Resource private Regex regex;
    @Resource private HttpServletRequest request;

    /** 通过appkey获取相应号码连接池中使用率 **/
    @RequestMapping("/tel/utilization")
    public Object telUtilization(@RequestBody ModelVo vo) {
        // 1. 生成seqId记录日志
        String seqId = UUID.randomUUID().toString();
        String paramJson = JsonUtils.objectToJson(vo);
        loggerSingleWork.info(String.format("seqid=%s,request=%s,param=%s",
                seqId, request.getRequestURI(), paramJson));
        // 2. 请求体校验
        JSONObject check = vo.checkMembers(regex);
        if (null != check) {
            loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, check.toJSONString()));
            return check;
        }
        // 3. 请求体检查通过，进行签名校验
        Map<String, String> parameterMap;
        try {
            parameterMap = JsonUtils.jsonToPojo(paramJson, Map.class);
            JSONObject signValid = yxtSignValid(parameterMap, seqId);
            if (null != signValid) {
                return signValid;
            }
            Object response = modelService.telUtilization(regex.YKT_UNITID, "0");
            loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
            return response;
        } catch (Exception e) {
            JSONObject response = ResponseUtils.makeYxtResponse(12, "服务器暂时不可用", null);
            loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toJSONString()));
            loggerException.error(String.format("seqid=%s,Exception=%s", seqId, e.toString().replaceAll("\n", "|")));
            return response;
        }
    }

    /** 通过appkey和城市获取相应号码池的号码数量以及使用率 **/
    @RequestMapping("/city/utilization")
    public Object cityUtilization(@RequestBody ModelVo vo) {
        // 1. 生成seqId记录日志
        String seqId = UUID.randomUUID().toString();
        String paramJson = JsonUtils.objectToJson(vo);
        loggerSingleWork.info(String.format("seqid=%s,request=%s,param=%s",
                seqId, request.getRequestURI(), paramJson));
        // 2. 请求体校验
        JSONObject check = vo.checkMembers(regex);
        if (null != check) {
            loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, check.toJSONString()));
            return check;
        }
        // 3. 请求体检查通过，进行签名校验
        Map<String, String> parameterMap;
        try {
            parameterMap = JsonUtils.jsonToPojo(paramJson, Map.class);
            JSONObject signValid = yxtSignValid(parameterMap, seqId);
            if (null != signValid) {
                return signValid;
            }
            Object response = modelService.cityUtilization(regex.YKT_UNITID, "0");
            loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
            return response;
        } catch (Exception e) {
            JSONObject response = ResponseUtils.makeYxtResponse(12, "服务器暂时不可用", null);
            loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toJSONString()));
            loggerException.error(String.format("seqid=%s,Exception=%s", seqId, e.toString().replaceAll("\n", "|")));
            return response;
        }
    }

    /** 通过appkey和城市获取相应号码池中使用率在前五十的号码及已绑定数量、使用率 **/
    @RequestMapping("/city/tel/utilization")
    public Object cityTelUtilization(@RequestBody ModelVo vo) {
        // 1. 生成seqId记录日志
        String seqId = UUID.randomUUID().toString();
        String paramJson = JsonUtils.objectToJson(vo);
        loggerSingleWork.info(String.format("seqid=%s,request=%s,param=%s",
                seqId, request.getRequestURI(), paramJson));
        // 2. 请求体校验
        JSONObject check = vo.checkMembers(regex);
        if (null != check) {
            loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, check.toJSONString()));
            return check;
        }
        // 3. 请求体检查通过，进行签名校验
        Map<String, String> parameterMap;
        try {
            parameterMap = JsonUtils.jsonToPojo(paramJson, Map.class);
            JSONObject signValid = yxtSignValid(parameterMap, seqId);
            if (null != signValid) {
                return signValid;
            }
            Object response = modelService.cityTelUtilization(regex.YKT_UNITID, "0");
            loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
            return response;
        } catch (Exception e) {
            JSONObject response = ResponseUtils.makeYxtResponse(12, "服务器暂时不可用", null);
            loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toJSONString()));
            loggerException.error(String.format("seqid=%s,Exception=%s", seqId, e.toString().replaceAll("\n", "|")));
            return response;
        }
    }
}
