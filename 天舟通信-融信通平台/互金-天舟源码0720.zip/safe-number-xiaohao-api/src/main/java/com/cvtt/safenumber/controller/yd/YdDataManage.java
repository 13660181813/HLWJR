/**
 * 关系数据相关接口(绑定，解绑，延期)
 */
package com.cvtt.safenumber.controller.yd;

import com.alibaba.fastjson.JSONObject;
import com.cvtt.safenumber.constents.Regex;
import com.cvtt.safenumber.dao.TUnitMapper;
import com.cvtt.safenumber.pojo.TUnit;
import com.cvtt.safenumber.service.IUnitService;
import com.cvtt.safenumber.service.dm.IdmBindService;
import com.cvtt.safenumber.service.yd.YdBindService;
import com.cvtt.safenumber.utils.ResponseUtils;
import com.cvtt.safenumber.utils.SignUtils;
import com.cvtt.safenumber.vo.xz.YdDataBindVo;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.UUID;

@Controller
@RequestMapping("/yd/manage")
public class YdDataManage {
	@Autowired
	private HttpServletRequest request;
	@Resource
	private IUnitService unitService;
	@Resource
	private YdBindService ydBindService;
	@Resource
	private Regex regex;
	@Resource
	private TUnitMapper unitDao;

	private static Logger loggerSingleWork = Logger.getLogger("DataManage.SingleWork");
	private static Logger loggerException = Logger.getLogger("Sys.Exception");

	/**
	 * ax绑定接口
	 * 
	 * @param bindVo
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/binding")
	public Object binding(YdDataBindVo bindVo) {
		//测试使用的当前时间
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmssSSS");
		loggerSingleWork.info("now:"+sdf.format(new Date()));

		// 生成一个SequenceId,用于记录日志
		String seqId = UUID.randomUUID().toString();
		// 通过getParameterMap获取"相对"原始的请求参数,分别存放在requestContent（用于记录日志）和parameterMap（用于计算签名）。
		// 通过spring注入bean获取的参数会忽略掉bean里不需要的参数
		String requestContent = "";
		Map<String, String> parameterMap = new HashMap<String, String>();
		for (Iterator<Entry<String, String[]>> iter = request.getParameterMap().entrySet().iterator(); iter
				.hasNext();) {
			Entry<String, String[]> entry = iter.next();
			String key = entry.getKey();
			String vals = "";
			for (String val : entry.getValue()) {
				vals += val;
			}
			if (requestContent != "")
				requestContent += "&";
			requestContent += key + "=" + vals;
			if (!key.equals("sign"))
				parameterMap.put(key, vals);
		}
		loggerSingleWork.info(String.format("seqid=%s,request=%s?%s", seqId, request.getRequestURI(), requestContent));

		// 公众参数合法性检查
        loggerSingleWork.info("receive ts:"+bindVo.getTs());
		String errMsg = bindVo.checkCommon();
		if (StringUtils.isNotBlank(errMsg)) {
			Object response = ResponseUtils.makeXzResponse("101",errMsg ,null);
			loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
			return response;
		}

		// 绑定参数合法性检查
		errMsg = bindVo.checkAxBind(regex);
		if (StringUtils.isNotBlank(errMsg)) {
			Object response = ResponseUtils.makeXzResponse("101",errMsg ,null);
			loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
			return response;
		}

		if (!StringUtils.equals("0", bindVo.getUnitId())) {
			// 根据unitid获取secret(用于计算签名)，后续考虑将secret放在缓存中
			String secret = unitService.getSecret(bindVo.getUnitId(), bindVo.getAppkey());
			if (StringUtils.isBlank(secret)) {
				Object response = ResponseUtils.makeXzResponse("101",  "使用了错误的unitID或appkey",null);
				loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
				return response;
			}

			// 签名检查
			try {
				if (!bindVo.getSign().equalsIgnoreCase(SignUtils.signTopRequest(parameterMap, secret, "MD5"))) {
					loggerSingleWork.info(String.format("seqid=%s,calculate_sign=%s", seqId,
							SignUtils.signTopRequest(parameterMap, secret, "MD5")));
					Object response = ResponseUtils.makeXzResponse("101",  "签名错误",null);
					loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
					return response;
				}
			} catch (IOException e) {
				loggerException
						.error(String.format("seqid=%s,Exception=%s", seqId, e.toString().replaceAll("\n", "|")));
				return ResponseUtils.makeXzResponse("-1","服务器异常",null);
			}
		}
		//服务器返回的结果
		JSONObject response;
		try {
			//根据unitId获取企业应该调用的接口。switch形式方便后续添加运营商。
			TUnit unit = unitDao.selectByPrimaryKey(bindVo.getUnitId());
			String sourceName=unit.getUnitadd();
			bindVo.setName(sourceName);
			switch(sourceName){
				//移动ax绑定接口;
				case "yd":
					response= (JSONObject) ydBindService.bindSingle(loggerSingleWork, bindVo, seqId);
					loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
					break;
				default:
					//数据库source名称维护错误的接口
					loggerException.error(String.format("seqid=%s,Exception=%s", seqId,"未找到与"+sourceName+"匹配的接口"));
					response=ResponseUtils.makeXzResponse("10003","没有权限访问接口",null);
					break;
			}
			//返回结果
			return response;
		} catch (Exception e) {
			loggerException.error(String.format("seqid=%s,Exception=%s", seqId, e.toString().replaceAll("\n", "|")));
            //loggerException.error("出错详细信息",e); //第二个参数是e
			return ResponseUtils.makeXzResponse("-1","服务器异常",null);
		}
	}

	/**
	 * ax解绑接口
	 *
	 * @param bindVo
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/unbind")
	public Object unbind(YdDataBindVo bindVo) {
		// 生成一个SequenceId,用于记录日志
		String seqId = UUID.randomUUID().toString();
		// 通过getParameterMap获取"相对"原始的请求参数,分别存放在requestContent（用于记录日志）和parameterMap（用于计算签名）。通过spring注入bean获取的参数会忽略掉bean里不需要的参数
		String requestContent = "";
		Map<String, String> parameterMap = new HashMap<String, String>();
		for (Iterator<Entry<String, String[]>> iter = request.getParameterMap().entrySet().iterator(); iter
				.hasNext();) {
			Entry<String, String[]> entry = iter.next();
			String key = entry.getKey();
			String vals = "";
			for (String val : entry.getValue()) {
				vals += val;
			}
			if (requestContent != "")
				requestContent += "&";
			requestContent += key + "=" + vals;
			if (!key.equals("sign"))
				parameterMap.put(key, vals);
		}
		loggerSingleWork.info(String.format("seqid=%s,request=%s?%s", seqId, request.getRequestURI(), requestContent));

		// 公众参数合法性检查
		String errMsg = bindVo.checkCommon();
		if (StringUtils.isNotBlank(errMsg)) {
			Object response = ResponseUtils.makeXzResponse("101", errMsg,null);
			loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
			return response;
		}

		// 绑定参数合法性检查
		errMsg = bindVo.checkUnBind(regex);
		if (StringUtils.isNotBlank(errMsg)) {
			Object response = ResponseUtils.makeXzResponse("101",  errMsg,null);
			loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
			return response;
		}

		if (!StringUtils.equals("0", bindVo.getUnitId())) {
			// 根据unitid获取secret(用于计算签名)，后续考虑将secret放在缓存中
			String secret = unitService.getSecret(bindVo.getUnitId(), bindVo.getAppkey());
			if (StringUtils.isBlank(secret)) {
				Object response = ResponseUtils.makeXzResponse("101", "使用了错误的unitID或appkey",null);
				loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
				return response;
			}

			// 签名检查
			try {
				if (!bindVo.getSign().equalsIgnoreCase(SignUtils.signTopRequest(parameterMap, secret, "MD5"))) {
					loggerSingleWork.info(String.format("seqid=%s,calculate_sign=%s", seqId,
							SignUtils.signTopRequest(parameterMap, secret, "MD5")));
					Object response = ResponseUtils.makeXzResponse("101",  "签名错误",null);
					loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
					return response;
				}
			} catch (IOException e) {
				loggerException
						.error(String.format("seqid=%s,Exception=%s", seqId, e.toString().replaceAll("\n", "|")));
				return ResponseUtils.makeXzResponse("-1","服务器异常",null);
			}
		}
		//服务器返回的结果
		JSONObject response;
		try {
			//根据unitId获取企业应该调用的接口。switch形式方便后续添加运营商。
			TUnit unit = unitDao.selectByPrimaryKey(bindVo.getUnitId());
			String sourceName=unit.getUnitadd();
			bindVo.setName(sourceName);
			switch(sourceName){
				//移动ax绑定接口;
				case "yd":
					response = (JSONObject) ydBindService.unbind(loggerSingleWork, bindVo, seqId);
					loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
					break;
				default:
					//数据库source名称维护错误的接口
					loggerException.error(String.format("seqid=%s,Exception=%s", seqId,"未找到与"+sourceName+"匹配的接口"));
					response=ResponseUtils.makeXzResponse("10003","没有权限访问接口",null);
					break;
			}
			return response;
		} catch (Exception e) {
			loggerException.error(String.format("seqid=%s,Exception=%s", seqId, e.toString().replaceAll("\n", "|")));
			return ResponseUtils.makeXzResponse("-1","服务器异常",null);
		}
	}
	/**
	 * ax延期接口
	 *
	 * @param bindVo
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/updateBind")
	public Object updateBind(YdDataBindVo bindVo) {
		// 生成一个SequenceId,用于记录日志
		String seqId = UUID.randomUUID().toString();
		// 通过getParameterMap获取"相对"原始的请求参数,分别存放在requestContent（用于记录日志）和parameterMap（用于计算签名）。通过spring注入bean获取的参数会忽略掉bean里不需要的参数
		String requestContent = "";
		Map<String, String> parameterMap = new HashMap<String, String>();
		for (Iterator<Entry<String, String[]>> iter = request.getParameterMap().entrySet().iterator(); iter
				.hasNext();) {
			Entry<String, String[]> entry = iter.next();
			String key = entry.getKey();
			String vals = "";
			for (String val : entry.getValue()) {
				vals += val;
			}
			if (requestContent != "")
				requestContent += "&";
			requestContent += key + "=" + vals;
			if (!key.equals("sign"))
				parameterMap.put(key, vals);
		}
		loggerSingleWork.info(String.format("seqid=%s,request=%s?%s", seqId, request.getRequestURI(), requestContent));

		// 公众参数合法性检查
		String errMsg = bindVo.checkCommon();
		if (StringUtils.isNotBlank(errMsg)) {
			Object response = ResponseUtils.makeXzResponse("101", errMsg,null);
			loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
			return response;
		}

		// 绑定参数合法性检查
		errMsg = bindVo.checkUpdateBind(regex);
		if (StringUtils.isNotBlank(errMsg)) {
			Object response = ResponseUtils.makeXzResponse("101", errMsg,null);
			loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
			return response;
		}

		if (!StringUtils.equals("0", bindVo.getUnitId())) {
			// 根据unitid获取secret(用于计算签名)，后续考虑将secret放在缓存中
			String secret = unitService.getSecret(bindVo.getUnitId(), bindVo.getAppkey());
			if (StringUtils.isBlank(secret)) {
				Object response = ResponseUtils.makeXzResponse("101", "使用了错误的unitID或appkey",null);
				loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
				return response;
			}

			// 签名检查
			try {
				if (!bindVo.getSign().equalsIgnoreCase(SignUtils.signTopRequest(parameterMap, secret, "MD5"))) {
					loggerSingleWork.info(String.format("seqid=%s,calculate_sign=%s", seqId,
							SignUtils.signTopRequest(parameterMap, secret, "MD5")));
					Object response = ResponseUtils.makeXzResponse("101", "签名错误", null);
					loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
					return response;
				}
			} catch (IOException e) {
				loggerException
						.error(String.format("seqid=%s,Exception=%s", seqId, e.toString().replaceAll("\n", "|")));
				return ResponseUtils.makeXzResponse("-1","服务器异常",null);
			}
		}
		//服务器返回的结果
		JSONObject response;
		try {
			//根据unitId获取企业应该调用的接口。switch形式方便后续添加运营商。
			TUnit unit = unitDao.selectByPrimaryKey(bindVo.getUnitId());
			String sourceName=unit.getUnitadd();
			bindVo.setName(sourceName);
			switch(sourceName){
				//移动ax延期接口;
				case "yd":
					response = (JSONObject) ydBindService.updateBind(loggerSingleWork, bindVo, seqId);
					loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
					break;
				default:
					//数据库source名称维护错误的接口
					loggerException.error(String.format("seqid=%s,Exception=%s", seqId,"未找到与"+sourceName+"匹配的接口"));
					response=ResponseUtils.makeXzResponse("10003","没有权限访问接口",null);
					break;
			}
			return response;
		} catch (Exception e) {
			loggerException.error(String.format("seqid=%s,Exception=%s", seqId, e.toString().replaceAll("\n", "|")));
			return ResponseUtils.makeXzResponse("-1","服务器异常",null);
		}
	}
    /**
     * axb绑定接口
     *
     * @param bindVo
     * @return
     */
    @ResponseBody
    @RequestMapping("/bindingAXB")
    public Object bindingAXB(YdDataBindVo bindVo) {
        //测试使用的当前时间
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmssSSS");
        loggerSingleWork.info("now:"+sdf.format(new Date()));

        // 生成一个SequenceId,用于记录日志
        String seqId = UUID.randomUUID().toString();
        // 通过getParameterMap获取"相对"原始的请求参数,分别存放在requestContent（用于记录日志）和parameterMap（用于计算签名）。
        // 通过spring注入bean获取的参数会忽略掉bean里不需要的参数
        String requestContent = "";
        Map<String, String> parameterMap = new HashMap<String, String>();
        for (Iterator<Entry<String, String[]>> iter = request.getParameterMap().entrySet().iterator(); iter
                .hasNext();) {
            Entry<String, String[]> entry = iter.next();
            String key = entry.getKey();
            String vals = "";
            for (String val : entry.getValue()) {
                vals += val;
            }
            if (requestContent != "")
                requestContent += "&";
            requestContent += key + "=" + vals;
            if (!key.equals("sign"))
                parameterMap.put(key, vals);
        }
        loggerSingleWork.info(String.format("seqid=%s,request=%s?%s", seqId, request.getRequestURI(), requestContent));

        // 公众参数合法性检查
        loggerSingleWork.info("receive ts:"+bindVo.getTs());
        String errMsg = bindVo.checkCommon();
        if (StringUtils.isNotBlank(errMsg)) {
            Object response = ResponseUtils.makeXzResponse("101",errMsg ,null);
            loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
            return response;
        }

        // 绑定参数合法性检查
        errMsg = bindVo.checkAxbBind(regex);
        if (StringUtils.isNotBlank(errMsg)) {
            Object response = ResponseUtils.makeXzResponse("101",errMsg ,null);
            loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
            return response;
        }

        if (!StringUtils.equals("0", bindVo.getUnitId())) {
            // 根据unitid获取secret(用于计算签名)，后续考虑将secret放在缓存中
            String secret = unitService.getSecret(bindVo.getUnitId(), bindVo.getAppkey());
            if (StringUtils.isBlank(secret)) {
                Object response = ResponseUtils.makeXzResponse("101",  "使用了错误的unitID或appkey",null);
                loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
                return response;
            }

            // 签名检查
            try {
                if (!bindVo.getSign().equalsIgnoreCase(SignUtils.signTopRequest(parameterMap, secret, "MD5"))) {
                    loggerSingleWork.info(String.format("seqid=%s,calculate_sign=%s", seqId,
                            SignUtils.signTopRequest(parameterMap, secret, "MD5")));
                    Object response = ResponseUtils.makeXzResponse("101",  "签名错误",null);
                    loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
                    return response;
                }
            } catch (IOException e) {
                loggerException
                        .error(String.format("seqid=%s,Exception=%s", seqId, e.toString().replaceAll("\n", "|")));
                return ResponseUtils.makeXzResponse("-1","服务器异常",null);
            }
        }
        //服务器返回的结果
        JSONObject response;
        try {
            //根据unitId获取企业应该调用的接口。switch形式方便后续添加运营商。
            TUnit unit = unitDao.selectByPrimaryKey(bindVo.getUnitId());
            String sourceName=unit.getUnitadd();
			bindVo.setName(sourceName);
            switch(sourceName){
                //移动ax绑定接口;
                case "yd":
                    response= (JSONObject) ydBindService.axbBindSingle(loggerSingleWork, bindVo, seqId);
                    loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
                    break;
                default:
                    //数据库source名称维护错误的接口
                    loggerException.error(String.format("seqid=%s,Exception=%s", seqId,"未找到与"+sourceName+"匹配的接口"));
                    response=ResponseUtils.makeXzResponse("10003","没有权限访问接口",null);
                    break;
            }
            //返回结果
            return response;
        } catch (Exception e) {
            loggerException.error(String.format("seqid=%s,Exception=%s", seqId, e.toString().replaceAll("\n", "|")));
            loggerException.error("出错详细信息",e); //第二个参数是e
            return ResponseUtils.makeXzResponse("-1","服务器异常",null);
        }
    }

    /**
     * ax解绑接口
     *
     * @param bindVo
     * @return
     */
    @ResponseBody
    @RequestMapping("/unbindAXB")
    public Object unbindAXB(YdDataBindVo bindVo) {
        // 生成一个SequenceId,用于记录日志
        String seqId = UUID.randomUUID().toString();
        // 通过getParameterMap获取"相对"原始的请求参数,分别存放在requestContent（用于记录日志）和parameterMap（用于计算签名）。通过spring注入bean获取的参数会忽略掉bean里不需要的参数
        String requestContent = "";
        Map<String, String> parameterMap = new HashMap<String, String>();
        for (Iterator<Entry<String, String[]>> iter = request.getParameterMap().entrySet().iterator(); iter
                .hasNext();) {
            Entry<String, String[]> entry = iter.next();
            String key = entry.getKey();
            String vals = "";
            for (String val : entry.getValue()) {
                vals += val;
            }
            if (requestContent != "")
                requestContent += "&";
            requestContent += key + "=" + vals;
            if (!key.equals("sign"))
                parameterMap.put(key, vals);
        }
        loggerSingleWork.info(String.format("seqid=%s,request=%s?%s", seqId, request.getRequestURI(), requestContent));

        // 公众参数合法性检查
        String errMsg = bindVo.checkCommon();
        if (StringUtils.isNotBlank(errMsg)) {
            Object response = ResponseUtils.makeXzResponse("101", errMsg,null);
            loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
            return response;
        }

        // 绑定参数合法性检查
        errMsg = bindVo.checkAxbUnBind(regex);
        if (StringUtils.isNotBlank(errMsg)) {
            Object response = ResponseUtils.makeXzResponse("101",  errMsg,null);
            loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
            return response;
        }

        if (!StringUtils.equals("0", bindVo.getUnitId())) {
            // 根据unitid获取secret(用于计算签名)，后续考虑将secret放在缓存中
            String secret = unitService.getSecret(bindVo.getUnitId(), bindVo.getAppkey());
            if (StringUtils.isBlank(secret)) {
                Object response = ResponseUtils.makeXzResponse("101", "使用了错误的unitID或appkey",null);
                loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
                return response;
            }

            // 签名检查
            try {
                if (!bindVo.getSign().equalsIgnoreCase(SignUtils.signTopRequest(parameterMap, secret, "MD5"))) {
                    loggerSingleWork.info(String.format("seqid=%s,calculate_sign=%s", seqId,
                            SignUtils.signTopRequest(parameterMap, secret, "MD5")));
                    Object response = ResponseUtils.makeXzResponse("101",  "签名错误",null);
                    loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
                    return response;
                }
            } catch (IOException e) {
                loggerException
                        .error(String.format("seqid=%s,Exception=%s", seqId, e.toString().replaceAll("\n", "|")));
                return ResponseUtils.makeXzResponse("-1","服务器异常",null);
            }
        }
        //服务器返回的结果
        JSONObject response;
        try {
            //根据unitId获取企业应该调用的接口。switch形式方便后续添加运营商。
            TUnit unit = unitDao.selectByPrimaryKey(bindVo.getUnitId());
            String sourceName=unit.getUnitadd();
			bindVo.setName(sourceName);
            switch(sourceName){
                //移动ax绑定接口;
                case "yd":
                    response = (JSONObject) ydBindService.axbUnbind(loggerSingleWork, bindVo, seqId);
                    loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
                    break;
                default:
                    //数据库source名称维护错误的接口
                    loggerException.error(String.format("seqid=%s,Exception=%s", seqId,"未找到与"+sourceName+"匹配的接口"));
                    response=ResponseUtils.makeXzResponse("10003","没有权限访问接口",null);
                    break;
            }
            return response;
        } catch (Exception e) {
            loggerException.error(String.format("seqid=%s,Exception=%s", seqId, e.toString().replaceAll("\n", "|")));
            return ResponseUtils.makeXzResponse("-1","服务器异常",null);
        }
    }
    /**
     * axB延期接口
     *
     * @param bindVo
     * @return
     */
    @ResponseBody
    @RequestMapping("/delayBindAXB")
    public Object updateBindAXB(YdDataBindVo bindVo) {
        // 生成一个SequenceId,用于记录日志
        String seqId = UUID.randomUUID().toString();
        // 通过getParameterMap获取"相对"原始的请求参数,分别存放在requestContent（用于记录日志）和parameterMap（用于计算签名）。通过spring注入bean获取的参数会忽略掉bean里不需要的参数
        String requestContent = "";
        Map<String, String> parameterMap = new HashMap<String, String>();
        for (Iterator<Entry<String, String[]>> iter = request.getParameterMap().entrySet().iterator(); iter
                .hasNext();) {
            Entry<String, String[]> entry = iter.next();
            String key = entry.getKey();
            String vals = "";
            for (String val : entry.getValue()) {
                vals += val;
            }
            if (requestContent != "")
                requestContent += "&";
            requestContent += key + "=" + vals;
            if (!key.equals("sign"))
                parameterMap.put(key, vals);
        }
        loggerSingleWork.info(String.format("seqid=%s,request=%s?%s", seqId, request.getRequestURI(), requestContent));

        // 公众参数合法性检查
        String errMsg = bindVo.checkCommon();
        if (StringUtils.isNotBlank(errMsg)) {
            Object response = ResponseUtils.makeXzResponse("101", errMsg,null);
            loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
            return response;
        }

        // 绑定参数合法性检查
        errMsg = bindVo.checkDelayBind(regex);
        if (StringUtils.isNotBlank(errMsg)) {
            Object response = ResponseUtils.makeXzResponse("101", errMsg,null);
            loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
            return response;
        }

        if (!StringUtils.equals("0", bindVo.getUnitId())) {
            // 根据unitid获取secret(用于计算签名)，后续考虑将secret放在缓存中
            String secret = unitService.getSecret(bindVo.getUnitId(), bindVo.getAppkey());
            if (StringUtils.isBlank(secret)) {
                Object response = ResponseUtils.makeXzResponse("101", "使用了错误的unitID或appkey",null);
                loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
                return response;
            }

            // 签名检查
            try {
                if (!bindVo.getSign().equalsIgnoreCase(SignUtils.signTopRequest(parameterMap, secret, "MD5"))) {
                    loggerSingleWork.info(String.format("seqid=%s,calculate_sign=%s", seqId,
                            SignUtils.signTopRequest(parameterMap, secret, "MD5")));
                    Object response = ResponseUtils.makeXzResponse("101", "签名错误", null);
                    loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
                    return response;
                }
            } catch (IOException e) {
                loggerException
                        .error(String.format("seqid=%s,Exception=%s", seqId, e.toString().replaceAll("\n", "|")));
                return ResponseUtils.makeXzResponse("-1","服务器异常",null);
            }
        }
        //服务器返回的结果
        JSONObject response;
        try {
            //根据unitId获取企业应该调用的接口。switch形式方便后续添加运营商。
            TUnit unit = unitDao.selectByPrimaryKey(bindVo.getUnitId());
            String sourceName=unit.getUnitadd();
			bindVo.setName(sourceName);
            switch(sourceName){
                //移动ax延期接口;
                case "yd":
                    response = (JSONObject) ydBindService.axbUpdateBind(loggerSingleWork, bindVo, seqId);
                    loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
                    break;
                default:
                    //数据库source名称维护错误的接口
                    loggerException.error(String.format("seqid=%s,Exception=%s", seqId,"未找到与"+sourceName+"匹配的接口"));
                    response=ResponseUtils.makeXzResponse("10003","没有权限访问接口",null);
                    break;
            }
            return response;
        } catch (Exception e) {
            loggerException.error(String.format("seqid=%s,Exception=%s", seqId, e.toString().replaceAll("\n", "|")));
            return ResponseUtils.makeXzResponse("-1","服务器异常",null);
        }
    }

	/**
	 * axB改变B号码接口
	 *
	 * @param bindVo
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/changeAXB")
	public Object changeAXB(YdDataBindVo bindVo) {
		// 生成一个SequenceId,用于记录日志
		String seqId = UUID.randomUUID().toString();
		// 通过getParameterMap获取"相对"原始的请求参数,分别存放在requestContent（用于记录日志）和parameterMap（用于计算签名）。通过spring注入bean获取的参数会忽略掉bean里不需要的参数
		String requestContent = "";
		Map<String, String> parameterMap = new HashMap<String, String>();
		for (Iterator<Entry<String, String[]>> iter = request.getParameterMap().entrySet().iterator(); iter
				.hasNext();) {
			Entry<String, String[]> entry = iter.next();
			String key = entry.getKey();
			String vals = "";
			for (String val : entry.getValue()) {
				vals += val;
			}
			if (requestContent != "")
				requestContent += "&";
			requestContent += key + "=" + vals;
			if (!key.equals("sign"))
				parameterMap.put(key, vals);
		}
		loggerSingleWork.info(String.format("seqid=%s,request=%s?%s", seqId, request.getRequestURI(), requestContent));

		// 公众参数合法性检查
		String errMsg = bindVo.checkCommon();
		if (StringUtils.isNotBlank(errMsg)) {
			Object response = ResponseUtils.makeXzResponse("101", errMsg,null);
			loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
			return response;
		}

		// 绑定参数合法性检查
		errMsg = bindVo.checkChangeAxb(regex);
		if (StringUtils.isNotBlank(errMsg)) {
			Object response = ResponseUtils.makeXzResponse("101", errMsg,null);
			loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
			return response;
		}

		if (!StringUtils.equals("0", bindVo.getUnitId())) {
			// 根据unitid获取secret(用于计算签名)，后续考虑将secret放在缓存中
			String secret = unitService.getSecret(bindVo.getUnitId(), bindVo.getAppkey());
			if (StringUtils.isBlank(secret)) {
				Object response = ResponseUtils.makeXzResponse("101", "使用了错误的unitID或appkey",null);
				loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
				return response;
			}

			// 签名检查
			try {
				if (!bindVo.getSign().equalsIgnoreCase(SignUtils.signTopRequest(parameterMap, secret, "MD5"))) {
					loggerSingleWork.info(String.format("seqid=%s,calculate_sign=%s", seqId,
							SignUtils.signTopRequest(parameterMap, secret, "MD5")));
					Object response = ResponseUtils.makeXzResponse("101", "签名错误", null);
					loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
					return response;
				}
			} catch (IOException e) {
				loggerException
						.error(String.format("seqid=%s,Exception=%s", seqId, e.toString().replaceAll("\n", "|")));
				return ResponseUtils.makeXzResponse("-1","服务器异常",null);
			}
		}
		//服务器返回的结果
		JSONObject response;
		try {
			//根据unitId获取企业应该调用的接口。switch形式方便后续添加运营商。
			TUnit unit = unitDao.selectByPrimaryKey(bindVo.getUnitId());
			String sourceName=unit.getUnitadd();
			bindVo.setName(sourceName);
			switch(sourceName){
				//移动ax延期接口;
				case "yd":
					response = (JSONObject) ydBindService.axbChangebBind(loggerSingleWork, bindVo, seqId);
					loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
					break;
				default:
					//数据库source名称维护错误的接口
					loggerException.error(String.format("seqid=%s,Exception=%s", seqId,"未找到与"+sourceName+"匹配的接口"));
					response=ResponseUtils.makeXzResponse("10003","没有权限访问接口",null);
					break;
			}
			return response;
		} catch (Exception e) {
			loggerException.error(String.format("seqid=%s,Exception=%s", seqId, e.toString().replaceAll("\n", "|")));
			return ResponseUtils.makeXzResponse("-1","服务器异常",null);
		}
	}

	/**
	 * 黑名单接口
	 *
	 * @param bindVo
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/blacklist")
	public Object blacklist(YdDataBindVo bindVo) {
		// 生成一个SequenceId,用于记录日志
		String seqId = UUID.randomUUID().toString();
		// 通过getParameterMap获取"相对"原始的请求参数,分别存放在requestContent（用于记录日志）和parameterMap（用于计算签名）。通过spring注入bean获取的参数会忽略掉bean里不需要的参数
		String requestContent = "";
		Map<String, String> parameterMap = new HashMap<String, String>();
		for (Iterator<Entry<String, String[]>> iter = request.getParameterMap().entrySet().iterator(); iter
				.hasNext();) {
			Entry<String, String[]> entry = iter.next();
			String key = entry.getKey();
			String vals = "";
			for (String val : entry.getValue()) {
				vals += val;
			}
			if (requestContent != "")
				requestContent += "&";
			requestContent += key + "=" + vals;
			if (!key.equals("sign"))
				parameterMap.put(key, vals);
		}
		loggerSingleWork.info(String.format("seqid=%s,request=%s?%s", seqId, request.getRequestURI(), requestContent));

		// 公众参数合法性检查
		String errMsg = bindVo.checkCommon();
		if (StringUtils.isNotBlank(errMsg)) {
			Object response = ResponseUtils.makeXzResponse("101", errMsg,null);
			loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
			return response;
		}

		// 绑定参数合法性检查
		errMsg = bindVo.checkBlackList(regex);
		if (StringUtils.isNotBlank(errMsg)) {
			Object response = ResponseUtils.makeXzResponse("101", errMsg,null);
			loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
			return response;
		}

		if (!StringUtils.equals("0", bindVo.getUnitId())) {
			// 根据unitid获取secret(用于计算签名)，后续考虑将secret放在缓存中
			String secret = unitService.getSecret(bindVo.getUnitId(), bindVo.getAppkey());
			if (StringUtils.isBlank(secret)) {
				Object response = ResponseUtils.makeXzResponse("101", "使用了错误的unitID或appkey",null);
				loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
				return response;
			}

			// 签名检查
			try {
				if (!bindVo.getSign().equalsIgnoreCase(SignUtils.signTopRequest(parameterMap, secret, "MD5"))) {
					loggerSingleWork.info(String.format("seqid=%s,calculate_sign=%s", seqId,
							SignUtils.signTopRequest(parameterMap, secret, "MD5")));
					Object response = ResponseUtils.makeXzResponse("101", "签名错误", null);
					loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
					return response;
				}
			} catch (IOException e) {
				loggerException
						.error(String.format("seqid=%s,Exception=%s", seqId, e.toString().replaceAll("\n", "|")));
				return ResponseUtils.makeXzResponse("-1","服务器异常",null);
			}
		}
		//服务器返回的结果
		JSONObject response;
		try {
			//根据unitId获取企业应该调用的接口。switch形式方便后续添加运营商。
			TUnit unit = unitDao.selectByPrimaryKey(bindVo.getUnitId());
			String sourceName=unit.getUnitadd();
			bindVo.setName(sourceName);
			switch(sourceName){
				//移动ax延期接口;
				case "yd":
					response = (JSONObject) ydBindService.blacklist(loggerSingleWork, bindVo, seqId);
					loggerSingleWork.info(String.format("seqid=%s,response=%s", seqId, response.toString()));
					break;
				default:
					//数据库source名称维护错误的接口
					loggerException.error(String.format("seqid=%s,Exception=%s", seqId,"未找到与"+sourceName+"匹配的接口"));
					response=ResponseUtils.makeXzResponse("10003","没有权限访问接口",null);
					break;
			}
			return response;
		} catch (Exception e) {
			loggerException.error(String.format("seqid=%s,Exception=%s", seqId, e.toString().replaceAll("\n", "|")));
			return ResponseUtils.makeXzResponse("-1","服务器异常",null);
		}
	}
 
}
