package com.tianzhou.querynumbergateway.service;

import com.tianzhou.querynumbergateway.pojo.QueryRelationAll;

import java.util.List;
import java.util.Map;

public interface QueryRelationService {
    /**
     * 传入95号码查看
     * */
     List<Map<String,Object>> selectByParams(Map<String,Object> paramsMap);

}
