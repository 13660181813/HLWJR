package com.tianzhou.querynumbergateway.pojo;

import java.util.Date;

public class QueryRelationAll {
    private Long id;


    private String unitid;

    private Long beginuid;


    public Long getEnduid() {
        return enduid;
    }

    public void setEnduid(Long enduid) {
        this.enduid = enduid;
    }

    private Long enduid;

    private Integer countuid;

    private Date createtime;


    private Integer numtype;

    private String ipaddress;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }



    public String getUnitid() {
        return unitid;
    }

    public void setUnitid(String unitid) {
        this.unitid = unitid == null ? null : unitid.trim();
    }
    public Long getBeginuid() {
        return beginuid;
    }

    public void setBeginuid(Long beginuid) {
        this.beginuid = beginuid;
    }




    public Integer getCountuid() {
        return countuid;
    }

    public void setCountuid(Integer countuid) {
        this.countuid = countuid;
    }

    public Date getStarttime() {
        return createtime;
    }

    public void setStarttime(Date starttime) {
        this.createtime = starttime;
    }

    public Integer getNumtype() {
        return numtype;
    }

    public void setNumtype(Integer numtype) {
        this.numtype = numtype;
    }

    public String getIpaddress() {
        return ipaddress;
    }

    public void setIpaddress(String ipaddress) {
        this.ipaddress = ipaddress == null ? null : ipaddress.trim();
    }
}