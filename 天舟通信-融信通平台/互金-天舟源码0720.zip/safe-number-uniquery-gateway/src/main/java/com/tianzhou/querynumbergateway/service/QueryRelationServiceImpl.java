package com.tianzhou.querynumbergateway.service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.tianzhou.querynumbergateway.dao.QueryRelationAllMapper;
import com.tianzhou.querynumbergateway.pojo.QueryRelationAll;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
@Service
public class QueryRelationServiceImpl implements QueryRelationService{
    @Autowired
    private QueryRelationAllMapper queryRelationAllMapper;

    private static final Logger logger = LoggerFactory.getLogger(QueryRelationServiceImpl.class);

    @Override
    public List<Map<String,Object>> selectByParams(Map<String, Object> paramsMap) {
        List<Map<String,Object>> queryRelationList = queryRelationAllMapper.selectByParams(paramsMap);
        logger.info("{}", "查询表得到数据为"+JSON.toJSONString(queryRelationList));
        return queryRelationList;
    }




}
