package com.tianzhou.querynumbergateway.filter;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cloud.gateway.filter.GatewayFilter;
import org.springframework.cloud.gateway.filter.factory.rewrite.ModifyResponseBodyGatewayFilterFactory;
import org.springframework.cloud.gateway.filter.factory.rewrite.RewriteFunction;
import org.springframework.http.codec.ServerCodecConfigurer;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

@Component
public class RewriteResponseGatewayFilterFactory
        extends ModifyResponseBodyGatewayFilterFactory {

    public RewriteResponseGatewayFilterFactory(ServerCodecConfigurer codecConfigurer) {
        super(codecConfigurer);
    }
    private static final Logger logger = LoggerFactory.getLogger(RewriteResponseGatewayFilterFactory.class);

    @Override
    public GatewayFilter apply(Config config) {
        return new ModifyResponseGatewayFilter(this.getConfig());
    }

    private Config getConfig() {
        Config config = new Config();
        // Config.setRewriteFunction(Class<T> inClass, Class<R> outClass, RewriteFunction<T, R> rewriteFunction)
        // inClass 原数据类型，可以指定为具体数据类型，原作者说:"这里可以指定为Object,是为了处理多种数据类型。当然支持多接口返回多数据类型的统一修改，yaml中的配置，path,uri需要做相关调整"
        // 但测试发现，如果inClass指定为Object，若与我编写的RewriteRequestGatewayFilterFactory配合，当authenticate失败直接返回时(StatusCode设为200OK)，
        // 会报Content type 'application/octet-stream' not supported for bodyType=java.lang.Object错误，即使在RewriteRequestGatewayFilterFactory中指定Content type为application/json也不行
        // 同时当RewriteRequestGatewayFilterFactory转发到了后端，后端返回Content type为text/plain时，也会报类似错误，所以将inClass设置为String
        // outClass 目标数据类型
        // rewriteFunction 内容重写方法
        config.setRewriteFunction(String.class, String.class, getRewriteFunction());
        return config;
    }

    private RewriteFunction<String, String> getRewriteFunction() {
        //return (exchange, resp) -> Mono.just(UnionResult.builder().requestId(exchange.getRequest().getHeaders().getFirst("cn-buddie.demo.requestId")).result(resp).build());
        return (exchange, response) -> {
            // 如果是前序RewriteRequestGatewayFilterFactory鉴权失败的返回，则不修改返回结果
            if (exchange.getResponse().getHeaders().getFirst("X-Auth-Result") != null)
                return Mono.just(response);
            else {
                String responseType = exchange.getResponse().getHeaders().getFirst("X-Response-Type");
                if (StringUtils.isNotBlank(responseType)) {
                    //返回html的情况
                    if(response.toString().contains("html")){
                        JSONObject errorResponseBody = new JSONObject();
                        errorResponseBody.put("code", "404");
                        errorResponseBody.put("msg", "失败");
                        errorResponseBody.put("sub_msg", "服务异常");
                        JSONObject errorResponse = new JSONObject();
                        errorResponse.put("error_response", errorResponseBody);
                        logger.info("{\"error_response\":{\"msg\":\"失败\",\"code\":\"404\",\"sub_msg\":\"服务异常\"}}");
                        return Mono.just(errorResponse.toString());
                    }
//                    if(response.toString().contains("html")){
//                        JSONObject errorResponseBody = new JSONObject();
//                        errorResponseBody.put("code", "404");
//                        errorResponseBody.put("msg", "失败");
//                        errorResponseBody.put("sub_msg", "服务异常");
//                        JSONObject errorResponse = new JSONObject();
//                        errorResponse.put("error_response", errorResponseBody);
//                        logger.info("{\"error_response\":{\"msg\":\"失败\",\"code\":\"404\",\"sub_msg\":\"服务异常\"}}");
//                        return Mono.just(errorResponse.toString());
//                    }
                    JSONObject responseObject = JSON.parseObject(response);
                    if (responseObject != null) {
                        //判断是否接口返回错误信息
                        if(responseObject.get("error_response")!=null) {
                            logger.info(responseObject.toString());
                            return Mono.just(responseObject.toString());
                        }
                        if (responseType.equals("call_query")) {
                            // responseType == call_query的时候不用区分code
                            JSONObject secret_call_control_response = responseObject.getJSONObject("secret_call_control_response");
                            if(secret_call_control_response==null){
                                JSONObject rewriteRespone = new JSONObject();
                                rewriteRespone.put("error_response", responseObject);
                                return Mono.just(rewriteRespone.toJSONString());
                            }else {
                                return Mono.just(convertResponse(responseType, responseObject, ""));
                            }
                            //return Mono.just(convertResponse(responseType, responseObject, ""));
                        } else {
                            Integer code = responseObject.getJSONObject("query_Relation_response").getInteger("result");
                            //Integer code = responseObject.getInteger("result");
                            if (code != null) {
                                if (code.equals(0)) {
                                    // 重组并返回正常响应包
                                    String unitID = exchange.getRequest().getQueryParams().getFirst("unitID");
                                    return Mono.just(convertResponse(responseType, responseObject, unitID));
                                } else {
                                    // 重组并返回错误响应包
                                    JSONObject rewriteRespone = new JSONObject();
                                    rewriteRespone.put("error_response", responseObject);
                                    return Mono.just(rewriteRespone.toJSONString());
                                }
                            }
                        }
                    }
                }
                return Mono.just(response);
            }
        };
    }

    private String convertResponse(String responseType, JSONObject responseObject, String unitID) {
        switch (responseType) {
            case "query_relationinfo":
                return convertToQueryRelationInfoResponse(responseObject,unitID);
            case "call_query":
                logger.info("安全号接口返回:"+responseObject.toString());
                logger.info("网关接口返回:"+responseObject.toString());
                return responseObject.toJSONString();
            default:
                break;
        }
        return responseObject.toJSONString();
    }
    private String convertToQueryRelationInfoResponse(JSONObject responseObject,String unitID) {
        logger.info("安全号接口返回:"+responseObject.toString());
        JSONArray dataArray = responseObject.getJSONObject("query_Relation_response").getJSONArray("items");
        JSONObject response = new JSONObject();
        JSONObject response1 = new JSONObject();
        JSONObject responseBody = new JSONObject();
        JSONArray responseArray = new JSONArray();

        if (dataArray != null) {

            for(int i=0;i<dataArray.size();i++){
                try {
                JSONObject data = dataArray.getJSONObject(i);
                //state=1并且validitytime大于当前时间
                String state = data.getString("state");
                String validitytime = data.getString("validitytime");
                if ("1".equals(state)&&"".equals(validitytime)){
                    responseBody.put("prtms", data.getString("prtms"));
                    responseBody.put("smbms", data.getString("smbms"));
                    responseBody.put("validitytime", data.getString("validitytime"));
                    responseArray.add(responseBody);
                }
                if(!StringUtils.isEmpty(validitytime)) {
                    SimpleDateFormat ss = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                    Date validitytimeDate = ss.parse(validitytime);
                    if("1".equals(state)&&validitytimeDate.getTime()>new Date().getTime()){
                        responseBody.put("prtms", data.getString("prtms"));
                        responseBody.put("smbms", data.getString("smbms"));
                        responseBody.put("validitytime", data.getString("validitytime"));
                        responseArray.add(responseBody);
                    }
                }

                } catch (ParseException e) {
                    logger.info("日期格式错误："+e.getMessage());
                    e.printStackTrace();
                }
            }
            response1.put("result", 0);
            response1.put("items",responseArray);
            response.put("query_Relation_response",response1);
            logger.info("网关接口返回:"+response.toJSONString());
            return response.toJSONString();
        }
        return responseObject.toJSONString();
    }







}