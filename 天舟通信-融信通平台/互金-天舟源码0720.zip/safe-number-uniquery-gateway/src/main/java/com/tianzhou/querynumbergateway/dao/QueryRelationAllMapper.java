package com.tianzhou.querynumbergateway.dao;


import com.tianzhou.querynumbergateway.pojo.QueryRelationAll;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;
public interface QueryRelationAllMapper {
    int deleteByPrimaryKey(Long id);

    int insert(QueryRelationAll record);

    QueryRelationAll selectByPrimaryKey(Long id);

    int updateByPrimaryKey(QueryRelationAll record);

    List<Map<String,Object>> selectByParams(Map<String,Object> paramsMap);
}