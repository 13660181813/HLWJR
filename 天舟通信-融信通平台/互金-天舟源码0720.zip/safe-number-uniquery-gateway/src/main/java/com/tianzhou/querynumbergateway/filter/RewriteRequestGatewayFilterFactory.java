package com.tianzhou.querynumbergateway.filter;

import com.alibaba.fastjson.JSONObject;
import com.tianzhou.querynumbergateway.pojo.AuthenticateErrorEnum;
import com.tianzhou.querynumbergateway.service.QueryRelationService;
import com.tianzhou.querynumbergateway.utils.SignUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.gateway.filter.GatewayFilter;
import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.cloud.gateway.filter.factory.AbstractGatewayFilterFactory;
import org.springframework.cloud.gateway.route.Route;
import org.springframework.http.HttpStatus;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;
import org.springframework.web.server.ServerWebExchange;
import org.springframework.web.util.UriComponentsBuilder;
import reactor.core.publisher.Mono;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.nio.charset.StandardCharsets;
import java.util.*;

import static org.springframework.cloud.gateway.support.ServerWebExchangeUtils.GATEWAY_ROUTE_ATTR;
import static org.springframework.cloud.gateway.support.ServerWebExchangeUtils.addOriginalRequestUrl;

/**
 * 实现签名检查和转换请求格式和方法的功能
 */
@Component
public class RewriteRequestGatewayFilterFactory
        extends AbstractGatewayFilterFactory<RewriteRequestGatewayFilterFactory.Config> {
    @Autowired
    private QueryRelationService queryRelationService;
    private static final Logger logger = LoggerFactory.getLogger(RewriteRequestGatewayFilterFactory.class);

    @Value("${defaultqueryurl}")
    private String urlbegin;
    @Value("${defaultunitid}")
    private String defaultunitid;
    @Value("${defaultappkey}")
    private String defaultappkey;
    @Value("${defaultsecret}")
    private String defaultsid;
    @Value("${projectname:safenumberservicessm}")
    private String projectname;


    public RewriteRequestGatewayFilterFactory() {
        super(Config.class);
    }




    @Override
    public List<String> shortcutFieldOrder() {
        return Arrays.asList("requestType", "checkAuth", "idField", "keyField", "signField");
    }

    @Override
    public GatewayFilter apply(Config config) {

        if (config.requestType == null)
            throw new RuntimeException("'requestType' must be assigned for RewriteRequest filter.");
        return (exchange, chain) -> {

            //默认地址
             //url = "http://192.168.106.74:8060/";
            ServerHttpRequest req = exchange.getRequest();
            logger.info("网关请求："+req.getURI());
            addOriginalRequestUrl(exchange,req.getURI());

//            AuthenticateErrorEnum error = authenticate(req.getQueryParams(), config);
//            if (error != null) {
//                ServerHttpResponse response = exchange.getResponse();
//                response.getHeaders().add("Content-Type", "application/json;charset=UTF-8");
//                response.getHeaders().add("X-Auth-Result", "fail");   // 后续filter可以根据此header判断是否需要修改response
//
//                JSONObject errorResponseBody = new JSONObject();
//                errorResponseBody.put("code", error.getCode());
//                errorResponseBody.put("msg", error.getMessage());
//                errorResponseBody.put("sub_code", error.getSubCode());
//                errorResponseBody.put("sub_msg", error.getSubMessage());
//                JSONObject errorResponse = new JSONObject();
//                errorResponse.put("error_response", errorResponseBody);
//                logger.info(errorResponseBody.toString());
//                response.setStatusCode(HttpStatus.OK);
//                //response.setStatusCode(HttpStatus.UNAUTHORIZED);
//                //return response.setComplete();    // setComplete后，后续filter将不被调用
//                return response.writeWith( Mono.just(
//                        response.bufferFactory().wrap(errorResponse.toJSONString().getBytes(StandardCharsets.UTF_8)) ) );
//            }
            try {

            switch (config.getRequestType()) {
                case "query_relationinfo": {
                    return query_RelationMethod(config, exchange, chain, req);
                }
                case "call_query":{
                    return call_QueryMethod(config, exchange, chain, req);
                }
                default:
                    break;
            }
            } catch (Exception e) {
                logger.info("此次异常:"+e.getMessage());
                e.printStackTrace();
            }
            return chain.filter(exchange);

            };

        }

    private Mono<Void> call_QueryMethod(Config config, ServerWebExchange exchange, GatewayFilterChain chain, ServerHttpRequest req) throws IOException, URISyntaxException{
        //--------校验开始-------//

        //获得request里面的API接口名称
        List<String> methodList = req.getQueryParams().get("method");
        //获得appkey，进行校验
        List<String> app_keyList = req.getQueryParams().get("app_key");
        //获得时间戳，进行校验
        List<String> timestampList = req.getQueryParams().get("timestamp");
        //响应格式。默认为xml格式，可选值：xml，json
        //List<String> formatList = req.getQueryParams().get("format");
        //获取API协议版本
        List<String> VList = req.getQueryParams().get("v");
        //获取合作伙伴身份标识。（UnitID）
        List<String> partner_idList = req.getQueryParams().get("partner_id");
        //获取签名的摘要算法，可选值为：md5
        List<String> sign_methodList = req.getQueryParams().get("sign_method");
        //获取API输入参数签名结果
        List<String> signList = req.getQueryParams().get("sign");


        //----公共参数（2个以上抽出来）----//

        //接入平台的AppKey （UnitKey）
        List<String> platform_keyList = req.getQueryParams().get("platform_key");
        //发起呼叫号码（源号码）
        List<String> call_out_noList = req.getQueryParams().get("call_out_no");
        //隐私号码（安全号码或岗位号码）
        List<String> no_xList = req.getQueryParams().get("no_x");
        //呼叫唯一标示ID
        List<String> call_idList = req.getQueryParams().get("call_id");

        ServerHttpResponse response = exchange.getResponse();
        JSONObject errorResponseBody = new JSONObject();
        errorResponseBody.put("code", 500);
        errorResponseBody.put("msg", "失败");
        JSONObject errorResponse = new JSONObject();
        errorResponse.put("error_response", errorResponseBody);
        //判断
        if(methodList==null){
            return chechParams(response, errorResponseBody, errorResponse, "method传入错误");
        }
        String method = methodList.get(0);
        if(app_keyList==null){
            return chechParams(response, errorResponseBody, errorResponse, "app_key传入错误");
        }
        String app_key = app_keyList.get(0);
        if(timestampList==null){
            return chechParams(response, errorResponseBody, errorResponse, "timestamp传入错误");
        }
        if(VList==null){
            return chechParams(response, errorResponseBody, errorResponse, "V传入错误");
        }
        String V = VList.get(0);
        if(partner_idList==null){
            return chechParams(response, errorResponseBody, errorResponse, "partner_id传入错误");
        }
        String partner_id = partner_idList.get(0);

        if(sign_methodList==null){
            return chechParams(response, errorResponseBody, errorResponse, "sign_method传入错误");
        }
        if(signList==null){
            return chechParams(response, errorResponseBody, errorResponse, "sign需要传入");
        }
        String sign = signList.get(0);



        if(platform_keyList==null){
            return chechParams(response, errorResponseBody, errorResponse, "platform_key需要传入");
        }

        if(call_out_noList==null) {
            //需要传95号 打印日志
            return chechParams(response, errorResponseBody, errorResponse, "call_out_no传入错误");
        }
        if(no_xList==null) {
            //需要传95号 打印日志
            return chechParams(response, errorResponseBody, errorResponse, "no_x传入错误");
        }
        String no_x = no_xList.get(0);
        if(call_idList==null) {
            //需要传95号 打印日志
            return chechParams(response, errorResponseBody, errorResponse, "call_id传入错误");
        }

        if(!defaultunitid.equals(partner_id)) {
            return chechParams(response, errorResponseBody, errorResponse, "partner_id传入错误，请检查");

        }
        if(!defaultappkey.equals(app_key)) {
            return chechParams(response, errorResponseBody, errorResponse, "app_key传入错误，请检查");
        }
        if(!"secret.call.control".equals(method)) {
            return chechParams(response, errorResponseBody, errorResponse, "method传入错误，请检查");
        }
        if(!"2.0".equals(V)) {
            return chechParams(response, errorResponseBody, errorResponse, "V传入错误，请检查");

        }
        // 生成一个SequenceId,用于记录日志
        String seqId = UUID.randomUUID().toString();
        // 通过getParameterMap获取"相对"原始的请求参数,分别存放在requestContent（用于记录日志）和parameterMap（用于计算签名）。通过spring注入bean获取的参数会忽略掉bean里不需要的参数
        String requestContent = "";
        //Map<String, String> parameterMap = new HashMap<String, String>();
        Map<String, String> parameterMap = new HashMap<>();
        for (Map.Entry<String, List<String>> entry : req.getQueryParams().entrySet()) {
            if ("sign".equals(entry.getKey())) {
                requestContent = String.join(",", entry.getValue());
            } else {
                parameterMap.put(entry.getKey(), String.join(",", entry.getValue()));
            }
        }

        if (!sign.equalsIgnoreCase(SignUtils.signTopRequest(parameterMap, defaultsid, "MD5"))) {
            logger.info(String.format("seqid=%s,calculate_sign=%s", seqId,
                    SignUtils.signTopRequest(parameterMap, defaultsid, "MD5")));
            errorResponseBody.put("sub_msg", "签名出错，请检查");
            logger.info("网关接口返回："+errorResponseBody.toString());
            return response.writeWith( Mono.just(
                    response.bufferFactory().wrap(errorResponse.toJSONString().getBytes(StandardCharsets.UTF_8)) ) );
        }

        //--------校验结束-------//
        Map<String,Object> queryMap = new HashMap<String,Object>();
        queryMap.put("number",no_x);
        List<Map<String,Object>> queryRelationAllsList = queryRelationService.selectByParams(queryMap);
        ServerHttpRequest request = null;
        if(queryRelationAllsList!=null&&queryRelationAllsList.size()>0) {
            String url = queryRelationAllsList.get(0).get("ipaddress").toString();
            request = paramUrl(exchange, req,url,config);
        }else{
            request = paramUrl(exchange, req,urlbegin,config);
        }
        return chain.filter(exchange.mutate().request(request).build());
    }

    private Mono<Void> query_RelationMethod(Config config, ServerWebExchange exchange, GatewayFilterChain chain, ServerHttpRequest req) throws IOException, URISyntaxException {
        //--------校验开始-------//

        //获得request里面的number
        List<String> numberlist = req.getQueryParams().get("number");
        //获得unitid，进行校验
        List<String> unitIDList = req.getQueryParams().get("unitID");
        //获得appkey，进行校验
        List<String> appkeyList = req.getQueryParams().get("appkey");
        //获得sid，进行校验
        List<String> sidList = req.getQueryParams().get("sid");
        //获取msgtype
        List<String> msgtypeList = req.getQueryParams().get("msgtype");
        //获取ver
        List<String> verList = req.getQueryParams().get("ver");
        //获取ts
        List<String> tsList = req.getQueryParams().get("ts");
        //获取msgid
        List<String> msgidList = req.getQueryParams().get("msgid");
        //获取service
        List<String> serviceList = req.getQueryParams().get("service");

        ServerHttpResponse response = exchange.getResponse();
        JSONObject errorResponseBody = new JSONObject();
        errorResponseBody.put("code", 500);
        errorResponseBody.put("msg", "失败");
        JSONObject errorResponse = new JSONObject();
        errorResponse.put("error_response", errorResponseBody);
        //判断
        if(numberlist==null){
            return chechParams(response, errorResponseBody, errorResponse, "number传入错误，需要传入95号");
        }
        String number = numberlist.get(0);
        if(unitIDList==null){
            return chechParams(response, errorResponseBody, errorResponse, "unitID传入错误");
        }
        String unitid = unitIDList.get(0);
        if(appkeyList==null){
            return chechParams(response, errorResponseBody, errorResponse, "appkey传入错误");
        }
        String appkey = appkeyList.get(0);
        if(sidList==null){
            return chechParams(response, errorResponseBody, errorResponse, "sid传入错误");
        }
        String sid = sidList.get(0);
        if(msgtypeList==null){
            return chechParams(response, errorResponseBody, errorResponse, "msgtype传入错误");
        }
        String type = msgtypeList.get(0);

        if(verList==null){
            return chechParams(response, errorResponseBody, errorResponse, "ver传入错误");
        }
        String ver = verList.get(0);

        if(tsList==null){
            return chechParams(response, errorResponseBody, errorResponse, "ts需要传入");
        }

        if(serviceList==null){
            return chechParams(response, errorResponseBody, errorResponse, "service需要传入");
        }

        if(msgidList==null){
            return chechParams(response, errorResponseBody, errorResponse, "msgid需要传入");
        }

        if(!number.matches("^95013\\d{0,12}$")) {
            //需要传95号 打印日志
            return chechParams(response, errorResponseBody, errorResponse, "number传入错误，需要传入95号");
        }

        if(!defaultunitid.equals(unitid)) {
            return chechParams(response, errorResponseBody, errorResponse, "\"unitID传入错误，请检查");

        }
        if(!defaultappkey.equals(appkey)) {
            return chechParams(response, errorResponseBody, errorResponse, "\"appkey传入错误，请检查");
        }
        if(!"query_Relation".equals(type)) {
            return chechParams(response, errorResponseBody, errorResponse, "\"msgtype传入错误，请检查");
        }
        if(!"2.0".equals(ver)) {
            return chechParams(response, errorResponseBody, errorResponse, "\"ver传入错误，请检查");

        }
        // 生成一个SequenceId,用于记录日志
        String seqId = UUID.randomUUID().toString();
        // 通过getParameterMap获取"相对"原始的请求参数,分别存放在requestContent（用于记录日志）和parameterMap（用于计算签名）。通过spring注入bean获取的参数会忽略掉bean里不需要的参数
        String requestContent = "";
        //Map<String, String> parameterMap = new HashMap<String, String>();
        Map<String, String> parameterMap = new HashMap<>();
        for (Map.Entry<String, List<String>> entry : req.getQueryParams().entrySet()) {
            if (config.getSignField().equals(entry.getKey())) {
                requestContent = String.join(",", entry.getValue() );
            } else {
                parameterMap.put(entry.getKey(), String.join(",", entry.getValue()));
            }
        }

        if (!sid.equalsIgnoreCase(SignUtils.signTopRequest(parameterMap, defaultsid, "MD5"))) {
            logger.info(String.format("seqid=%s,calculate_sign=%s", seqId,
                    SignUtils.signTopRequest(parameterMap, defaultsid, "MD5")));
            errorResponseBody.put("sub_msg", "签名出错，请检查");
            logger.info("网关接口返回："+errorResponseBody.toString());
            return response.writeWith( Mono.just(
                    response.bufferFactory().wrap(errorResponse.toJSONString().getBytes(StandardCharsets.UTF_8)) ) );
        }

        //--------校验结束-------//
        Map<String,Object> queryMap = new HashMap<String,Object>();
        queryMap.put("number",number);
        List<Map<String,Object>> queryRelationAllsList = queryRelationService.selectByParams(queryMap);
        ServerHttpRequest request = null;
        if(queryRelationAllsList!=null&&queryRelationAllsList.size()>0) {
            String url = queryRelationAllsList.get(0).get("ipaddress").toString();
             request = paramUrl(exchange, req,url,config);
        }else{
             request = paramUrl(exchange, req,urlbegin,config);
        }
        return chain.filter(exchange.mutate().request(request).build());
    }

    private Mono<Void> chechParams(ServerHttpResponse response, JSONObject errorResponseBody, JSONObject errorResponse, String s) {
        logger.info(s);
        errorResponseBody.put("sub_msg", s);
        logger.info("网关接口返回：" + errorResponseBody.toString());
        return response.writeWith(Mono.just(
                response.bufferFactory().wrap(errorResponse.toJSONString().getBytes(StandardCharsets.UTF_8))));
    }

    private ServerHttpRequest paramUrl(ServerWebExchange exchange, ServerHttpRequest req,String url,Config config) throws URISyntaxException {
        //判断number值映射url
        String uriString = req.getURI().toString();
        //req.getURI().getQuery().
        String uriStringNew = uriString.replace("safenumbergateway",projectname);
        String ip = uriStringNew.substring(0,uriStringNew.indexOf(projectname));
        String replaceAll = uriStringNew.replaceAll(ip, url);

        URI uri = null;

        //uri = UriComponentsBuilder.fromHttpUrl("http://localhost:8080/safenumberservicessm/api/manage/queryRelation?msgtype=query_Relation&unitID=0&appkey=123456&sid=123456&ver=2.0&ts=2017-04-26%2015:04:04&msgid=6cac2d02-9b39-4b98-9d28-c12cf0dbb4cb&service=SafeNumber&number=950131001").build().toUri();
        if("query_relationinfo".equals(config.getRequestType())) {
            uri = UriComponentsBuilder.fromUri(new URI(replaceAll)).replaceQuery(convertToqueryRelationinfo(req.getQueryParams())).build().toUri();
        }else {
            uri = UriComponentsBuilder.fromUri(new URI(replaceAll)).replaceQuery(convertTocallQuery(req.getQueryParams())).build().toUri();
        }
        //logger.info("跳转url:"+url);
        ServerHttpRequest request = req.mutate().uri(uri).build();
        Route route = exchange.getAttribute(GATEWAY_ROUTE_ATTR);
        Route newRoute = Route.async()
                .asyncPredicate(route.getPredicate())
                .filters(route.getFilters())
                .id(route.getId())
                .order(route.getOrder())
                .uri(uri).build();
        exchange.getAttributes().put(GATEWAY_ROUTE_ATTR, newRoute);
        logger.info("接口请求:"+request.getURI());
        return request;
    }


    public static class Config {

        private String requestType;

        private boolean checkAuth;

        private String idField;

        private String keyField;

        private String signField;

        public Config() {
            this.checkAuth = true;
            this.idField = "unitID";
            this.keyField = "appkey";
            this.signField = "sid";
        }

        public String getRequestType() {
            return requestType;
        }

        public void setRequestType(String requestType) {
            this.requestType = requestType;
        }

        public boolean isCheckAuth() {
            return checkAuth;
        }

        public void setCheckAuth(boolean checkAuth) {
            this.checkAuth = checkAuth;
        }

        public String getIdField() {
            return idField;
        }

        public void setIdField(String idField) {
            this.idField = idField;
        }

        public String getKeyField() {
            return keyField;
        }

        public void setKeyField(String keyField) {
            this.keyField = keyField;
        }

        public String getSignField() {
            return signField;
        }

        public void setSignField(String signField) {
            this.signField = signField;
        }
    }

    private AuthenticateErrorEnum authenticate(MultiValueMap<String, String> queryParams, Config config) {

        // 将queryParams转换为Map<String, String>（不包括签名字段），一个字段有多个值时用","拼接
        String sign = "";
        Map<String, String> parameterMap = new HashMap<>();
        for (Map.Entry<String, List<String>> entry : queryParams.entrySet()) {
            if (config.getSignField().equals(entry.getKey())) {
                sign = String.join(",", entry.getValue());
            } else {
                parameterMap.put(entry.getKey(), String.join(",", entry.getValue()));
            }
        }

        // 从请求中取出并检查鉴权所需的字段
        String id = parameterMap.get(config.getIdField());
        if (StringUtils.isBlank(id)) return AuthenticateErrorEnum.ERR_ID;
        String key = parameterMap.get(config.getKeyField());
        if (StringUtils.isBlank(key)) return AuthenticateErrorEnum.ERR_KEY;
        if (StringUtils.isBlank(sign)) return AuthenticateErrorEnum.ERR_SIGN;


        // 比较key和sign
//        try {
//            if (!StringUtils.equals(snAuth.getString("platform_key"), key)) return AuthenticateErrorEnum.ERR_KEY;
//            String signCalculated = SignUtil.signTopRequest(parameterMap, snAuth.getString("secret"), "MD5");
//            if (StringUtils.equals(sign, signCalculated))
//                return null;
//            else
//                return AuthenticateErrorEnum.ERR_SIGN;
//        } catch (IOException e) {
//            return AuthenticateErrorEnum.ERR_SIGN;
//        }
        return null;
    }


    private String convertToRegisterQuery(MultiValueMap<String, String> originQuery) {
        StringBuilder queryBuilder = new StringBuilder();

        JSONObject settings = new JSONObject();
        for (String key : originQuery.keySet()) {

            if (key.equals("msgtype")) continue;
            if (key.equals("producttype")) continue;
            if (key.equals("productcat")) continue;
            if (key.equals("sid")) continue;
            if (key.equals("appkey")) continue;
            if (key.equals("ver")) continue;

            for (String value : originQuery.get(key)) {
                String newKey;
                switch (key) {
                    //case "ver":
                    //    newKey = key;
                    //    value = "3.0";
                    //    break;
                    case "msgid":
                        newKey = "msg_id";
                        break;
                    //case "sid":
                    //    newKey = "sign";
                    //    break;
                    //case "appkey":
                    //    newKey = "platform_key";
                    //    break;
                    case "opmodule":
                        newKey = "op_module";
                        break;
                    case "opuser":
                        newKey = "op_user";
                        break;

                    case "unitID":
                        newKey = "sub_service";
                        break;
                    case "prtms":
                        newKey = "reg_phone";
                        break;
                    case "smbms":
                        newKey = "uid";
                        break;
                    case "otherms":
                        newKey = "contacts";
                        break;
                    case "subts":
                        newKey = "reg_time";
                        break;
                    case "productid":
                        newKey = "product_type";
                        break;
                    case "uidType":
                        newKey = "uid_type";
                        break;
                    case "callrestrict":
                        newKey = "call_restrict";
                        break;
                    case "validitytime":
                        newKey = "expire_time";
                        break;
                    case "uuidinpartner":
                        newKey = "uuid_in_partner";
                        break;

                    case "calldisplay":
                        newKey = "settings";
                        settings.put("call_display", value);
                        break;
                    case "callrecording":
                        newKey = "settings";
                        settings.put("call_recording", value);
                        break;
                    case "anucode":
                        newKey = "settings";
                        settings.put("anucode_aleg", value);
                        break;
                    case "bnucode":
                        newKey = "settings";
                        settings.put("anucode_bleg", value);
                        break;

                    //case "ts":
                    //case "service":
                    //case "rsvd":
                    default:
                        newKey = key;
                        break;
                }
                if (!StringUtils.equals(newKey, "settings"))
                    queryBuilder.append(newKey).append("=").append(value).append("&");
            }
        }
        queryBuilder.append("settings=").append(settings.toJSONString());

        String query = queryBuilder.toString();
        if (query.endsWith("&"))
            query = query.substring(0, query.length() - 1);
        return query;
    }

    private String convertToqueryRelationinfo(MultiValueMap<String, String> originQuery) {
        StringBuilder queryBuilder = new StringBuilder();
        for (String key : originQuery.keySet()) {



            for (String value : originQuery.get(key)) {
                String newKey;
                switch (key) {

                    case "unitID":
                        newKey = "unitID";
                        value ="0";
                        break;

                    default:
                        newKey = key;
                        break;
                }

                queryBuilder.append(newKey).append("=").append(value).append("&");
            }
        }


        String query = queryBuilder.toString();
        if (query.endsWith("&")) {
            query = query.substring(0, query.length() - 1);
        }
        return query;
    }
    private String convertTocallQuery(MultiValueMap<String, String> originQuery) {
        StringBuilder queryBuilder = new StringBuilder();
        for (String key : originQuery.keySet()) {



            for (String value : originQuery.get(key)) {
                String newKey;
                switch (key) {

                    case "partner_id":
                        newKey = "partner_id";
                        value ="0";
                        break;

                    default:
                        newKey = key;
                        break;
                }

                queryBuilder.append(newKey).append("=").append(value).append("&");
            }
        }


        String query = queryBuilder.toString();
        if (query.endsWith("&")) {
            query = query.substring(0, query.length() - 1);
        }
        return query;
    }

}
