package com.tianzhou.querynumbergateway.utils;


import org.apache.commons.codec.binary.Hex;
import org.apache.commons.lang3.StringUtils;

import javax.crypto.KeyGenerator;
import javax.crypto.Mac;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import java.io.IOException;
import java.security.GeneralSecurityException;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Map;

public class SignUtils {
	public static String signTopRequest(Map<String, String> params, String secret, String signMethod)
			throws IOException {
		// 第一步：检查参数是否已经排序
		String[] keys = params.keySet().toArray(new String[0]);
		Arrays.sort(keys);

		// 第二步：把所有参数名和参数值串在一起
		StringBuilder query = new StringBuilder();
		if (signMethod.equals("MD5")) {
			query.append(secret);
		}
		for (String key : keys) {
			String value = params.get(key);
			if (StringUtils
					.isNotBlank(key) /* && StringUtils.isNotBlank(value) */ ) { //改为允许value为空
				query.append(key).append(value);
			}
		}

		// 第三步：使用MD5/HMAC加密
		byte[] bytes;
		if (signMethod.equals("HMAC")) {
			bytes = encryptHMAC(query.toString(), secret);
		} else {
			query.append(secret);
			// System.out.println(query.toString());
			bytes = encryptMD5(query.toString());
		}

		// 第四步：把二进制转化为大写的十六进制

		return byte2hex(bytes).toUpperCase();
	}

	/**
	 * 拼接字符串，包含连接符号和分隔符号
	 * @param params 原始参数map
	 * @param secret 秘钥
	 * @param signMethod 签名方法
	 * @param join map的key和value连接符号，如"="
	 * @param split 每组kv之间的分隔符号，如"&"
	 * @return
	 * @throws IOException
	 */
	public static String signTopRequest(Map<String, String> params,
						String secret, String signMethod, String join, String split) throws IOException {
		// 第一步：检查参数是否已经排序
		String[] keys = params.keySet().toArray(new String[0]);
		Arrays.sort(keys);

		// 第二步：把所有参数名和参数值串在一起
		StringBuilder query = new StringBuilder();

		for (int i = 0, len = keys.length; i < len; i++) {
			// String value = params.get(keys[i]);
			if (StringUtils.isNotBlank(keys[i])
					// 防止经过json转化过来的map包含字符串为null
					&& !StringUtils.equalsIgnoreCase("null", String.valueOf(params.get(keys[i])))
					&& StringUtils.isNotBlank(String.valueOf(params.get(keys[i])))) {
				query.append(keys[i]).append(join)					// key=
					 .append(String.valueOf(params.get(keys[i])))	// key=value
					 .append(split);								// key=value&
			}
		}

		// 第三步：拼接secret使用MD5加密 key=value&secret=secret
		query.append("secret=" + secret);
		byte[] bytes = encryptMD5(query.toString());

		// 第四步：把二进制转化为大写的十六进制
		return byte2hex(bytes);
	}
	public static byte[] encryptHMAC(String data, String secret) throws IOException {
		byte[] bytes = null;
		try {
			SecretKey secretKey = new SecretKeySpec(secret.getBytes("UTF-8"), "HmacMD5");
			Mac mac = Mac.getInstance(secretKey.getAlgorithm());
			mac.init(secretKey);
			bytes = mac.doFinal(data.getBytes("UTF-8"));
		} catch (GeneralSecurityException gse) {
			throw new IOException(gse.toString());
		}
		return bytes;
	}

	public static byte[] encryptMD5(String data) throws IOException {
		byte[] bytes = null;
		try {
			MessageDigest md = MessageDigest.getInstance("MD5");
			bytes = md.digest(data.getBytes("UTF-8"));
		} catch (GeneralSecurityException gse) {
			throw new IOException(gse.toString());
		}
		return bytes;
	}

	public static String byte2hex(byte[] bytes) {
		StringBuilder sign = new StringBuilder();
		for (int i = 0; i < bytes.length; i++) {
			String hex = Integer.toHexString(bytes[i] & 0xFF);
			if (hex.length() == 1) {
				sign.append("0");
			}
			sign.append(hex);
		}
		return sign.toString();
	}

	/**
	 * 生成秘钥(128位)
	 * @return
	 * @throws Exception
	 */
	public static String generateAESKey() throws Exception{
		//实例化
		KeyGenerator kgen = KeyGenerator.getInstance("AES");
		//设置密钥长度
		kgen.init(128);
		//生成密钥
		SecretKey skey = kgen.generateKey();
		// 转为16进制字串
		String key = new String(Hex.encodeHex(skey.getEncoded()));
		//返回密钥的16进制字串
		return key;
	}
}
