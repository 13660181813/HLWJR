package com.tianzhou.querynumbergateway;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QueryNumberGatewayApplicationTests {



}
