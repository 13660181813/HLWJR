package cn.cvtt.safenumber.task;

import cn.cvtt.safenumber.common.api.SafeNumberService;
import cn.cvtt.safenumber.common.api.SnResponse;
import cn.cvtt.safenumber.common.model.SnUidSect;
import cn.cvtt.safenumber.common.model.SnUnit;
import cn.cvtt.safenumber.common.model.SnUnitKey;
import cn.cvtt.safenumber.common.model.pojo.CallSettings;
import cn.cvtt.safenumber.common.model.pojo.UnitParams;
import com.alibaba.fastjson.JSONObject;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.test.context.junit4.SpringRunner;

import javax.annotation.Resource;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

@EnableFeignClients(basePackages = "cn.cvtt.safenumber.common.api")
@RunWith(SpringRunner.class)
@SpringBootTest
public class SafeNumberTaskApplicationTests {

    @Resource
    private SafeNumberService safeNumberService;

    @Test
    public void contextLoads() {

    }

    // 测试获取unit列表接口
    @Test
    public void unitGetAll() {
        Map<SnUnitKey, SnUnit> units =  safeNumberService.unitGetAll();
        System.out.println("");
    }

    // 测试创建unit接口
    @Test
    public void unitCreateSingle() {
        UnitParams unitParams = new UnitParams();
        unitParams.setExpire_time(5);
        unitParams.setReserve_time(10);

        CallSettings callSettings_s = new CallSettings();
        callSettings_s.setCall_restrict((byte)0);
        callSettings_s.setAnucode_aleg("0");
        callSettings_s.setAnucode_bleg("0");
        callSettings_s.setCall_display("0,0");
        callSettings_s.setCall_recording((byte)0);
        CallSettings callSettings_p = new CallSettings();
        callSettings_p.setCall_restrict((byte)0);
        callSettings_p.setAnucode_aleg("0");
        callSettings_p.setAnucode_bleg("0");
        callSettings_p.setCall_display("0,0");
        callSettings_p.setCall_recording((byte)0);

        JSONObject callSettings = new JSONObject();
        callSettings.put("SCALLSETTINGS", callSettings_s);
        callSettings.put("PCALLSETTINGS", callSettings_p);
        SnResponse snResponse = safeNumberService.unitCreateSingle("1",
                new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()),
                "SafeNumber",
                "1000",
                "web",
                "sujin",
                "xxxx",
                "xxxx",
                JSONObject.toJSONString(unitParams),
                callSettings.toJSONString(),
                (byte)1,
                (byte)1,
                "");
        System.out.println("");
    }

    // 测试创建unit接口
    @Test
    public void unitUpdateSingle() {
        UnitParams unitParams = new UnitParams();
        unitParams.setExpire_time(15);
        unitParams.setReserve_time(100);

        CallSettings callSettings_s = new CallSettings();
        callSettings_s.setCall_restrict((byte)0);
        callSettings_s.setAnucode_aleg("0");
        callSettings_s.setAnucode_bleg("0");
        callSettings_s.setCall_display("0,0");
        callSettings_s.setCall_recording((byte)0);
        CallSettings callSettings_p = new CallSettings();
        callSettings_p.setCall_restrict((byte)0);
        callSettings_p.setAnucode_aleg("0");
        callSettings_p.setAnucode_bleg("0");
        callSettings_p.setCall_display("0,0");
        callSettings_p.setCall_recording((byte)0);

        JSONObject callSettings = new JSONObject();
        callSettings.put("SCALLSETTINGS", callSettings_s);
        callSettings.put("PCALLSETTINGS", callSettings_p);
        SnResponse snResponse = safeNumberService.unitUpdateSingle("1",
                new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()),
                "SafeNumber",
                "1000",
                "web",
                "sujin",
                "xxxx",
                "xxxx",
                JSONObject.toJSONString(unitParams),
                callSettings.toJSONString(),
                (byte)1,
                (byte)1,
                "");
        System.out.println("");
    }

    // 测试删除unit接口
    @Test
    public void unitDeleteSingle() {
        SnResponse snResponse = safeNumberService.unitDeleteSingle("1",
                new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()),
                "SafeNumber",
                "1000",
                "web",
                "sujin");

        System.out.println("");
    }

    // 测试添加uid接口
    @Test
    public void uidCreate() {
        SnResponse snResponse = safeNumberService.uidCreate("1",
                new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()),
                "SafeNumber",
                "1000",
                "web",
                "sujin",
                (byte)1,
                "950135000",
                "950135999");
        System.out.println(snResponse);
    }

    // 测试uidsect获取接口
    @Test
    public void uidSectGet() {
        List<SnUidSect> snUidSects1 = safeNumberService.uidSectGetByUnitId("1000");
        List<SnUidSect> snUidSects2 = safeNumberService.uidSectGetByUnitIdAndType("1000", (byte)0);
        System.out.println("");
    }

    @Test
    public void userRegister() {
        SnResponse snResponse = safeNumberService.userRegister("1",
                new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()),
                "SafeNumber",
                "10000000003",
                "web",
                "sujin",
                "13911334545",
                null,
                null,
                null,
                (byte)0,
                null,
                null,
                null,
                null);
        System.out.println("");
    }

    @Test
    public void userUnregister() {

        SnResponse snResponse = safeNumberService.userUnregister("1",
                new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()),
                "SafeNumber",
                "10000000003",
                "web",
                "sujin",
                null,
                null,
                null,
                "39vr9024-i55see3-1dj6k6uq3",
                (byte)0,
                "d");
        System.out.println("");
    }

    @Test
    public void userUpdate() {
        SnResponse snResponse = safeNumberService.userUpdate("1",
                new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()),
                "SafeNumber",
                "10000000003",
                "web",
                "sujin",
                null,
                null,
                null,
                "3a2qa1kh-5hbk09et1i-1dipbnm49",
                "1",
                null,
                null,
                null);
        System.out.println("");
    }

    @Test
    public void twoWayCall() {
        SnResponse<String> snResponse = safeNumberService.twoWayCall("1",
                new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()),
                "SafeNumber",
                "1000",
                "web",
                "sujin",
                "");
        System.out.println("");
    }

}
