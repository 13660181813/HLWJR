package cn.cvtt.safenumber.task;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SafeNumberTaskApplication {

    public static void main(String[] args) {
        SpringApplication.run(SafeNumberTaskApplication.class, args);
    }

}
