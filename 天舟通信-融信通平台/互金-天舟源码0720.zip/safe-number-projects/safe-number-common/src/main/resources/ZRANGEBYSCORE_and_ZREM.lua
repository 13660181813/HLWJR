-- 通过组合调用ZRANGEBYSCORE和ZREM实现返回zset中所需数据并删除
local result = redis.call('ZRANGEBYSCORE', KEYS[1], ARGV[1], ARGV[2], 'LIMIT', 0, ARGV[3]);
if #result > 0 then
  redis.call('ZREM', KEYS[1], unpack(result));
  return result;
else
  return {};
end