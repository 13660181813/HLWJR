package cn.cvtt.safenumber.common.model;

import org.apache.ignite.cache.query.annotations.QuerySqlField;

@SuppressWarnings("CanBeFinal")
public class SnUidSect {

    @QuerySqlField(index = true)
    private String  unit_id;

    @QuerySqlField(index = true)
    private Byte    uid_type;

    @QuerySqlField
    private String uid_begin;

    @QuerySqlField
    private String uid_end;

    @QuerySqlField
    private Long uid_count;

    @QuerySqlField
    private String reserved;

    public SnUidSect(String unit_id, Byte uid_type, String uid_begin, String uid_end, Long uid_count, String reserved) {
        this.unit_id = unit_id;
        this.uid_type = uid_type;
        this.uid_begin = uid_begin;
        this.uid_end = uid_end;
        this.uid_count = uid_count;
        this.reserved = reserved;
    }

    public String getUnit_id() {
        return unit_id;
    }

    public Byte getUid_type() {
        return uid_type;
    }

    public String getUid_begin() {
        return uid_begin;
    }

    public String getUid_end() {
        return uid_end;
    }

    public Long getUid_count() {
        return uid_count;
    }

    public String getReserved() {
        return reserved;
    }
}
