package cn.cvtt.safenumber.common.service;

import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

@Service
public class BlackListService {
    @Resource
    private StringRedisTemplate stringRedisTemplate;

    public Boolean isBlackList(String unit_id, String phone) {
        return stringRedisTemplate.opsForSet().isMember("blacklist:" + unit_id, phone);
    }
}
