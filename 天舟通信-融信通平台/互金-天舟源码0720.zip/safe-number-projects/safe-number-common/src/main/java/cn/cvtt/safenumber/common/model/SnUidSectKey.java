package cn.cvtt.safenumber.common.model;

import org.apache.ignite.cache.query.annotations.QuerySqlField;

@SuppressWarnings("CanBeFinal")
public class SnUidSectKey {

    @QuerySqlField(index = true)
    private Long uid_begin_key; // "1"+uid_begin转换为的Long值，以便查询时利用索引

    @QuerySqlField(index = true)
    private Long uid_end_key;   // "1"+uid_end转换为的Long值，以便查询时利用索引

    public SnUidSectKey(Long uid_begin_key, Long uid_end_key) {
        this.uid_begin_key = uid_begin_key;
        this.uid_end_key = uid_end_key;
    }

    public Long getUid_begin_key() {
        return uid_begin_key;
    }

    public Long getUid_end_key() {
        return uid_end_key;
    }
}
