package cn.cvtt.safenumber.common.util;

import java.util.Date;

@SuppressWarnings("CanBeFinal")
public class DateEx extends Date {

    private Integer days;

    public DateEx(long date, Integer days) {
        super(date);
        this.days = days;
    }

    public Integer getDays() {
        return days;
    }
}
