package cn.cvtt.safenumber.common.format.datetime;

import cn.cvtt.safenumber.common.util.DateEx;
import org.jetbrains.annotations.NotNull;
import org.springframework.format.datetime.DateFormatter;

import java.text.ParseException;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;

/**
 * 支持字符串到DateEx的转换
 * 支持两种字符串格式:
 *  1. 表示具体时间的字符串（如yyyy-MM-dd HH:mm:ss）
 *  2. 表示相对天数的整数串（如1或-1等），转换后DateEx的Date为当前时间加上整数天
 */
@SuppressWarnings("WeakerAccess")
public class DateExFormatter extends DateFormatter {

    @NotNull
    @Override
    public DateEx parse(@NotNull String text, @NotNull Locale locale) throws NumberFormatException {

        Integer days = null;
        Date date;

        Date now = new Date();
        try {
            // 按pattern解析（具体日期）
            date = super.parse(text, locale);
            // 如果按pattern转换成功则不设置days，以便可以根据days是否为null判断传入的字符是具体日期还是相对天数
            //days = (int)((date.getTime() - now.getTime())/(24*3600*1000));
        } catch (ParseException e) {
            days = Integer.parseInt(text);
            Calendar calendar = new GregorianCalendar();
            calendar.setTime(now);
            calendar.add(Calendar.DATE, days);
            date = calendar.getTime();
        }

        return new DateEx(date.getTime(), days);
    }
}
