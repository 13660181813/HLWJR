package cn.cvtt.safenumber.common.exception;

@SuppressWarnings("CanBeFinal")
public class SecureValidException extends RuntimeException {

    private SecureValidExceptionEnum exceptionEnum;

    public SecureValidException(SecureValidExceptionEnum secureValidExceptionEnum) {
        super(secureValidExceptionEnum.getSubMessage());
        this.exceptionEnum = secureValidExceptionEnum;
    }

    public SecureValidExceptionEnum getExceptionEnum() {
        return exceptionEnum;
    }
}
