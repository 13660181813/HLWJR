package cn.cvtt.safenumber.common.config;

import cn.cvtt.safenumber.common.model.SnUidSect;
import cn.cvtt.safenumber.common.model.SnUidSectKey;
import cn.cvtt.safenumber.common.model.SnUnit;
import cn.cvtt.safenumber.common.model.SnUnitKey;
import org.apache.ignite.Ignite;
import org.apache.ignite.IgniteCache;
import org.apache.ignite.cache.CacheMode;
import org.apache.ignite.configuration.CacheConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.annotation.Resource;

@Configuration
public class IgniteCacheConfig {

    @SuppressWarnings("FieldCanBeLocal")
    private final String CACHE_NAME_SNUNIT = "SnUnit";
    @SuppressWarnings("FieldCanBeLocal")
    private final String CACHE_NAME_SNUIDSECT = "SnUidSect";

    @Resource
    private Ignite ignite;

    @Bean
    public IgniteCache<SnUnitKey, SnUnit> snUnitCache() {
        CacheConfiguration<SnUnitKey, SnUnit> cacheCfg = new CacheConfiguration<>(CACHE_NAME_SNUNIT);
        cacheCfg.setCacheMode(CacheMode.REPLICATED);
        cacheCfg.setIndexedTypes(SnUnitKey.class, SnUnit.class);   // 不执行本行，按sql查询时会提示找不到表; 且model类(如SnUser)中需用QuerySqlField注解标明sql查询所需字段；同时，此操作只会对刚创建的cache有作用，不会改变已存在cache的属性
        return ignite.getOrCreateCache(cacheCfg);
    }

    @Bean
    public IgniteCache<SnUidSectKey, SnUidSect> snUidSectCache() {
        CacheConfiguration<SnUidSectKey, SnUidSect> cacheCfg = new CacheConfiguration<>(CACHE_NAME_SNUIDSECT);
        cacheCfg.setCacheMode(CacheMode.REPLICATED);
        cacheCfg.setIndexedTypes(SnUidSectKey.class, SnUidSect.class);   // 不执行本行，按sql查询时会提示找不到表; 且model类(如SnUser)中需用QuerySqlField注解标明sql查询所需字段；同时，此操作只会对刚创建的cache有作用，不会改变已存在cache的属性
        return ignite.getOrCreateCache(cacheCfg);
    }

    @Bean
    public IgniteCacheGetter igniteCacheGetter() {
        return new IgniteCacheGetter();
    }
}
