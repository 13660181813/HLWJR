package cn.cvtt.safenumber.common.format.annotation;

import java.lang.annotation.*;

@Documented
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.METHOD, ElementType.FIELD, ElementType.PARAMETER, ElementType.ANNOTATION_TYPE})
public @interface DateTimeExFormat {
    String style() default "SS";

    org.springframework.format.annotation.DateTimeFormat.ISO iso() default org.springframework.format.annotation.DateTimeFormat.ISO.NONE;

    String pattern() default "";

    enum ISO {
        DATE,
        TIME,
        DATE_TIME,
        NONE;

        ISO() {
        }
    }
}
