package cn.cvtt.safenumber.common.service;

import cn.cvtt.safenumber.common.model.SnUnit;
import cn.cvtt.safenumber.common.model.SnUser;
import cn.cvtt.safenumber.common.model.SnUserKey;
import cn.cvtt.safenumber.common.model.pojo.UnitParams;
import cn.cvtt.safenumber.common.util.DateEx;
import cn.cvtt.safenumber.common.config.IgniteCacheGetter;
import cn.cvtt.safenumber.common.exception.BusinessException;
import cn.cvtt.safenumber.common.exception.BusinessExceptionEnum;
import cn.cvtt.safenumber.common.vo.SnUserRecoverVo;
import cn.cvtt.safenumber.common.vo.SnUserRegisterVo;
import cn.cvtt.safenumber.common.vo.SnUserUnregisterVo;
import cn.cvtt.safenumber.common.pojo.SnUserServiceLog;
import cn.cvtt.safenumber.common.util.SnSubIdUtils;
import cn.cvtt.safenumber.common.vo.SnUserUpdateVo;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.serializer.SerializerFeature;
import org.apache.commons.lang.StringUtils;
import org.apache.ignite.IgniteCache;
import org.apache.ignite.cache.query.QueryCursor;
import org.apache.ignite.cache.query.ScanQuery;
import org.apache.ignite.cache.query.SqlFieldsQuery;
import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.elasticsearch.search.sort.FieldSortBuilder;
import org.elasticsearch.search.sort.SortOrder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import javax.cache.Cache;
import java.sql.Timestamp;
import java.util.*;

@SuppressWarnings("Duplicates")
@Service
public class SnUserService {

    private static final String queryFileds = "REG_PHONE,UID,SUB_ID,PRODUCT_TYPE,UID_TYPE,REG_TIME,EXPIRE_TIME,CALL_RESTRICT,SETTINGS,CONTACTS,UUID_IN_PARTNER";

    private static final String queryStringForValidAndNoRestrictByUid = "SELECT " + queryFileds +
            " FROM SNUSER WHERE UID = ? AND (EXPIRE_TIME IS NULL OR EXPIRE_TIME >= GETDATE()) AND CALL_RESTRICT <> 1 LIMIT 1";
    private static final String queryStringForValidByPhone = "SELECT " + queryFileds +
            " FROM SNUSER WHERE REG_PHONE = ? AND (EXPIRE_TIME IS NULL OR EXPIRE_TIME >= GETDATE()) LIMIT 1";
    private static final String queryStringForValidByPhoneAndUidType = "SELECT " + queryFileds +
            " FROM SNUSER WHERE REG_PHONE = ? AND (EXPIRE_TIME IS NULL OR EXPIRE_TIME >= GETDATE()) AND UID_TYPE = ? LIMIT 1";
    private static final String queryStringForByUuidInPartner = "SELECT " + queryFileds +
            " FROM SNUSER WHERE UUID_IN_PARTNER = ? LIMIT 1";
    private static final String queryStringForByUid = "SELECT " + queryFileds +
            " FROM SNUSER WHERE UID = ? LIMIT 1";
    private static final String queryStringForByRegPhone = "SELECT " + queryFileds +
            " FROM SNUSER WHERE REG_PHONE = ? LIMIT 1";
    private static final String queryStringForValidCount = "SELECT " + "COUNT(1)" +
            " FROM SNUSER WHERE UID_TYPE = ? AND (EXPIRE_TIME IS NULL OR EXPIRE_TIME >= GETDATE())";

    private static final Logger logger = LoggerFactory.getLogger(SnUserService.class);

    @Resource
    private IgniteCacheGetter igniteCacheGetter;

    @Resource
    private BlackListService blackListService;

    @Resource
    private DeadZoneService deadZoneService;

    @Resource
    private SnUidService snUidService;

    @Resource
    private SnUidSectService snUidSectService;

    @Resource
    private SnUserContactService snUserContactService;

    @Resource
    private SnUserUnregisterQueueService snUserUnregisterQueueService;

    @Resource
    private SnUidReserveQueueService snUidReserveQueueService;

    @Resource
    private SnStatService snStatService;

    @Resource
    private RestHighLevelClient elasticClient;

    // kv方式写入(key重复则覆盖)
    // kv方式和sql方式经测试感觉性能几乎无差异，只是好像kv方式波动较小。
    private void addSingle(String unit_id, SnUserKey snUserKey, SnUser snUser) {

        //写入SnUser
        igniteCacheGetter.getSnUserCache(unit_id, null).put(snUserKey, snUser);

        //如果有联系人
        if (StringUtils.isNotBlank(snUser.getContacts())) {
            snUserContactService.addMultiple(unit_id, snUserKey, snUser);
        }

        // 如果expire_time不为null，则加入延迟注销队列
        if (snUser.getExpire_time() != null) {
            snUserUnregisterQueueService.add(unit_id, snUser.getUid_type(), snUser.getSub_id(), snUser.getExpire_time().getTime());
        }

        //修改redis中记录的注册用户总数（注意，这个数据包括已过期但未注销的数量）
        //采用这种方式是因为通过sql根据uid type条件查询效率低，而根据igniteCache.size获取的数据包含所有uid type
        snStatService.incrTotalUser(unit_id, snUser.getUid_type(), 1);
    }

    // sql方式写入(key重复则失败)
    // kv方式和sql方式经测试感觉性能几乎无差异，只是好像kv方式波动较小。
    /*private Boolean addSingle(String unit_id, SnUserKey snUserKey, SnUser snUser) {
        long start = System.currentTimeMillis();
        logger.info("start at {}.", start);
        IgniteCache<SnUserKey, SnUser> snUserCache = getSnUserCache(unit_id);

        SqlFieldsQuery query = new SqlFieldsQuery(
                "INSERT INTO SnUser (reg_phone,uid,sub_id,product_type,uid_type,reg_time,expire_time,settings,contacts,uuid_in_partner) VALUES (?,?,?,?,?,?,?,?,?,?)");
        snUserCache.query(query.setArgs(snUserKey.getReg_phone(),
                snUserKey.getUid(),
                snUser.getSub_id(),
                snUser.getProductType(),
                snUser.getUidType(),
                snUser.getReg_time(),
                snUser.getExpire_time(),
                snUser.getSettings(),
                snUser.getContacts(),
                snUser.getUuid_in_partner())).getAll();

        long duration = System.currentTimeMillis() - start;
        if( duration >= 500 ) {
            logger.warn("finished, duration is {}.", duration);
        } else {
            logger.info("finished, duration is {}.", duration);
        }
        return Boolean.TRUE;
    }*/


    @SuppressWarnings("UnusedReturnValue")
    private Boolean delSingle(String unit_id, SnUserKey snUserKey, SnUser snUser) {

        //如果有联系人
        if (StringUtils.isNotBlank(snUser.getContacts())) {
            //遍历删除
            for (String contact:
                    (snUser.getContacts() + ",").split(",")) {
                if (!snUserContactService.delSingle(unit_id, contact, snUserKey.getUid())) {
                    return false;
                }
            }
        }

        //删除SnUser中数据
        Boolean result = igniteCacheGetter.getSnUserCache(unit_id, null).remove(snUserKey);

        // todo 此处可以优化，因为如果本身此次注销是从延迟注销队列中发起的，则没必要执行此步骤
        // 如果expire_time不为null，则从延迟注销队列中删除
        if (snUser.getExpire_time() != null) {
            snUserUnregisterQueueService.del(unit_id, snUser.getUid_type(), snUser.getSub_id());
        }

        if (result) {
            //修改redis中记录的注册用户总数（注意，这个数据包括已过期但未注销的数量）
            //采用这种方式是因为通过sql根据uid type条件查询效率低，而根据igniteCache.size获取的数据包含所有uid type
            snStatService.decrTotalUser(unit_id, snUser.getUid_type(), 1);
        }

        return result;
    }

    private void updateSingle(String unit_id, SnUserKey snUserKey, SnUser snUser, SnUser newSnUser) {
        //更新SnUser
        igniteCacheGetter.getSnUserCache(unit_id, null).put(snUserKey, newSnUser);

        //如果联系人发生了变化
        Set<String> contacts = new TreeSet<>(Arrays.asList(snUser.getContacts().split(",")));
        Set<String> newContacts = new TreeSet<>(Arrays.asList(newSnUser.getContacts().split(",")));
        if (!contacts.equals(newContacts)) {
            snUserContactService.delMultiple(unit_id, snUserKey, snUser);
            snUserContactService.addMultiple(unit_id, snUserKey, newSnUser);
        }

        // 如果expire_time发生了变化
        if (newSnUser.getExpire_time() != null && !newSnUser.getExpire_time().equals(snUser.getExpire_time())) {
            snUserUnregisterQueueService.add(unit_id, snUser.getUid_type(), snUser.getSub_id(), newSnUser.getExpire_time().getTime());
        }
    }

    private SnUser getSingle(String unit_id, SnUserKey snUserKey) {
        IgniteCache<SnUserKey, SnUser> snUserCache = igniteCacheGetter.getSnUserCache(unit_id, null);
        return snUserCache.get(snUserKey);
    }

    public SnUser getSingle(String unit_id, String reg_phone, String uid) {
        return getSingle(unit_id, new SnUserKey(reg_phone, uid));
    }

    public SnUser getSingle(String unit_id, String sub_id) {
        SnUserKey snUserKey = SnSubIdUtils.parseSubId(sub_id);
        if (StringUtils.isBlank(snUserKey.getReg_phone()) && StringUtils.isBlank(snUserKey.getUid()))
            return null;
        SnUser snUser = getSingle(unit_id, snUserKey);
        if (snUser != null && StringUtils.equals(snUser.getSub_id(), sub_id))
            return snUser;
        else
            return null;
    }

    public SnUser addSingle(SnUnit snUnit, SnUserRegisterVo snUserRegisterVo) {

        // 黑名单判断(reg_phone)
        if (blackListService.isBlackList(snUserRegisterVo.getSub_service(),snUserRegisterVo.getReg_phone())) {
            throw new BusinessException(BusinessExceptionEnum.ERR_BLOCKED_PHONE);
        }
        // 盲区判断(reg_phone)
        if (deadZoneService.isDeadZone(snUserRegisterVo.getReg_phone())) {
            throw new BusinessException(BusinessExceptionEnum.ERR_DEAD_ZONE);
        }
        // 黑名单和盲区判断(other_phone/contact)
        if (StringUtils.isNotBlank(snUserRegisterVo.getContacts())) {
            for (String contact:
                    (snUserRegisterVo.getContacts() + ",").split(",")) {
                if (blackListService.isBlackList(snUserRegisterVo.getSub_service(), contact)) {
                    throw new BusinessException(BusinessExceptionEnum.ERR_BLOCKED_PHONE);
                }
                if (deadZoneService.isDeadZone(contact)) {
                    throw new BusinessException(BusinessExceptionEnum.ERR_DEAD_ZONE);
                }
            }
        }

        // 从号池获取uid
        String uid = snUidService.pop(snUserRegisterVo.getSub_service(), snUserRegisterVo.getUid_type(), snUserRegisterVo.getUid());

        // 获取不成功则判断具体原因
        if (StringUtils.isBlank(uid)) {
            if (StringUtils.isBlank(snUserRegisterVo.getUid())) {
                throw new BusinessException(BusinessExceptionEnum.ERR_UID_INSUFFICIENT);
            } else {
                // 查询95号码是否分配给该unit(未区分uid_type)
                if (snUidSectService.getUidSectByUid(snUserRegisterVo.getUid()) == null) {
                    throw new BusinessException(BusinessExceptionEnum.ERR_UID_NOT_OWNER);
                }
                // 判断是否已使用
                throw new BusinessException(BusinessExceptionEnum.ERR_UID_OCCUPIED);
            }
        }

        // 获取成功则设置uid
        snUserRegisterVo.setUid(uid);

        // 根据unit的param设置expire_time
        if (snUserRegisterVo.getExpire_time() == null) {
            Integer expire_time = snUnit.getParamsObject().getExpire_time();
            if (expire_time != null) {
                Calendar calendar = new GregorianCalendar();
                calendar.setTime(new Date());
                calendar.add(Calendar.DATE, expire_time);
                DateEx date = new DateEx(new Date().getTime(), null);
                date.setTime(calendar.getTimeInMillis());
                snUserRegisterVo.setExpire_time(date);
            }
        }

        //构造SnUserKey和SnUser对象
        SnUserKey snUserKey = new SnUserKey(snUserRegisterVo.getReg_phone(), snUserRegisterVo.getUid());
        SnUser snUser = new SnUser(SnSubIdUtils.genSubId(snUserKey),
                snUserRegisterVo.getProduct_type(),
                snUserRegisterVo.getUid_type(),
                new Timestamp(snUserRegisterVo.getReg_time().getTime()),
                snUserRegisterVo.getExpire_time() == null ? null : new Timestamp(snUserRegisterVo.getExpire_time().getTime()),
                snUserRegisterVo.getCall_restrict() != null ? snUserRegisterVo.getCall_restrict()
                        : (snUserRegisterVo.getUid_type() == 0 ? snUnit.getCallSettings("SCALLSETTINGS").getCall_restrict() : snUnit.getCallSettings("PCALLSETTINGS").getCall_restrict()),
                snUserRegisterVo.getSettings(),
                StringUtils.isBlank(snUserRegisterVo.getContacts()) ? "" : String.join(",",snUserRegisterVo.getContacts().split(",")), //去除末尾可能的","
                snUserRegisterVo.getUuid_in_partner(),
                "");
        //执行写入操作
        addSingle(snUserRegisterVo.getSub_service(), snUserKey, snUser);

        logger.info("{}", JSON.toJSONString(
                new SnUserServiceLog(snUserRegisterVo.getMsg_id(),
                        snUserRegisterVo.getSub_service(),
                        snUserRegisterVo.getOp_module(),
                        snUserRegisterVo.getOp_user(),
                        snUserRegisterVo.getOp_type(),
                        snUserRegisterVo.getOp_time(),
                        snUserRegisterVo.getOp_ip(),
                        snUser), SerializerFeature.UseISO8601DateFormat));
        return snUser;
    }

    @SuppressWarnings("UnusedReturnValue")
    public SnUser delSingle(SnUnit snUnit, SnUserUnregisterVo snUserUnregisterVo) {

        //查询注册数据
        SnUser snUser = null;

        if (StringUtils.isNotBlank(snUserUnregisterVo.getReg_phone())
            && StringUtils.isNotBlank(snUserUnregisterVo.getUid())) {
            //如果reg_phone和uid均传入了，则根据reg_phone和uid同时查
            snUser = getSingle(snUserUnregisterVo.getSub_service(), snUserUnregisterVo.getReg_phone(), snUserUnregisterVo.getUid());
            if (snUser != null
                    && StringUtils.isNotBlank(snUserUnregisterVo.getUuid_in_partner())
                    && !StringUtils.equals(snUserUnregisterVo.getUuid_in_partner(), snUser.getUuid_in_partner())) {
                //如果还同时传入了uuid_in_partner，但与记录中的uuid_in_partner不一致时，当做未查询到记录
                snUser = null;
            }
        } else if (StringUtils.isNotBlank(snUserUnregisterVo.getSub_id())) {
            // 如果传入了sub_id
            snUser = getSingle(snUserUnregisterVo.getSub_service(), snUserUnregisterVo.getSub_id());
        } else if (StringUtils.isNotBlank(snUserUnregisterVo.getUuid_in_partner())) {
            //如果传入了uuid_in_partner，则根据uuid_in_partner查找
            snUser = getSingleByUuidInPartner(snUserUnregisterVo.getSub_service(),snUserUnregisterVo.getUuid_in_partner());
        } else if (StringUtils.isNotBlank(snUserUnregisterVo.getUid())) {
            //如果传入了uid
            snUser = getSingleByUid(snUserUnregisterVo.getSub_service(),snUserUnregisterVo.getUid());
        } else if (StringUtils.isNotBlank(snUserUnregisterVo.getReg_phone())) {
            //如果传入了reg_phone
            snUser = getSingleByRegPhone(snUserUnregisterVo.getSub_service(),snUserUnregisterVo.getReg_phone());
        }

        if (snUser == null) {
            throw new BusinessException(BusinessExceptionEnum.ERR_DATA_NOT_EXIST);
        }

        if (delSingle(snUserUnregisterVo.getSub_service(), SnSubIdUtils.parseSubId(snUser.getSub_id()), snUser)) {

            // 回收号码
            UnitParams unitParams = snUnit.getParamsObject();
            if (unitParams.getReserve_time() == null || unitParams.getReserve_time() == 0) {
                // 立即回收
                snUidService.add(snUserUnregisterVo.getSub_service(), snUser.getUid_type(), snUser.getUid());
            } else {
                // 计算回收时间
                Calendar calendar = new GregorianCalendar();
                calendar.setTime(new Date());
                calendar.add(Calendar.DATE, unitParams.getReserve_time());
                // 写入待回收队列
                snUidReserveQueueService.add(snUserUnregisterVo.getSub_service(), snUser.getUid_type(), snUser.getUid(), calendar.getTimeInMillis());
            }

            logger.info("{}", JSON.toJSONString(
                    new SnUserServiceLog(snUserUnregisterVo.getMsg_id(),
                            snUserUnregisterVo.getSub_service(),
                            snUserUnregisterVo.getOp_module(),
                            snUserUnregisterVo.getOp_user(),
                            snUserUnregisterVo.getOp_type(),
                            snUserUnregisterVo.getOp_time(),
                            snUserUnregisterVo.getOp_ip(),
                            snUser), SerializerFeature.UseISO8601DateFormat));

            return snUser;
        } else {
            throw new BusinessException(BusinessExceptionEnum.ERR_UNREGISTER);    //这种错误很可能是并发（删除同一个值）导致
        }
    }

    public SnUser updateSingle(SnUnit snUnit, SnUserUpdateVo snUserUpdateVo) {
        //查询注册数据
        SnUser snUser = null;

        if (StringUtils.isNotBlank(snUserUpdateVo.getReg_phone())
                && StringUtils.isNotBlank(snUserUpdateVo.getUid())) {
            // 如果reg_phone和uid均传入了，则根据reg_phone和uid同时查
            snUser = getSingle(snUserUpdateVo.getSub_service(), snUserUpdateVo.getReg_phone(), snUserUpdateVo.getUid());
        } else if (StringUtils.isNotBlank(snUserUpdateVo.getSub_id())) {
            // 如果传入了sub_id
            snUser = getSingle(snUserUpdateVo.getSub_service(), snUserUpdateVo.getSub_id());
        } else if (StringUtils.isNotBlank(snUserUpdateVo.getUuid_in_partner())) {
            // 如果传入了uuid_in_partner，则根据uuid_in_partner查找
            snUser = getSingleByUuidInPartner(snUserUpdateVo.getSub_service(),snUserUpdateVo.getUuid_in_partner());
        } else {
            // 抛出异常提示参数不全
            throw new BusinessException(BusinessExceptionEnum.ERR_INSUFFICIENT_PARAM_UPDATE_USER);
        }

        // 未查询到数据
        if (snUser == null) {
            throw new BusinessException(BusinessExceptionEnum.ERR_DATA_NOT_EXIST);
        }

        // 复制旧数据到newSnUser
        SnUser newSnUser = new SnUser(snUser.getSub_id(),
                snUser.getProduct_type(),
                snUser.getUid_type(),
                snUser.getReg_time(),
                snUser.getExpire_time(),
                snUser.getCall_restrict(),
                snUser.getSettings(),
                snUser.getContacts(),
                snUser.getUuid_in_partner(),
                snUser.getReserved());
        // 先处理下请求中的过期时间，处理后有可能是null
        if (snUserUpdateVo.getExpire_time() != null){
            if(snUserUpdateVo.getExpire_time().getDays() != null){
                // 传入的是相对时间，此时不能直接利用snUserUpdateVo.expire_time，因为那个时间是在当前时间基础上加上天数生成。
                // 注册时可以直接用userUpdateVo.expire_time，在更新时需要在已有过期时间基础上加上天数
                if (snUser.getExpire_time() != null) {
                    Calendar calendar = new GregorianCalendar();
                    calendar.setTime(snUser.getExpire_time());
                    calendar.add(Calendar.DATE, snUserUpdateVo.getExpire_time().getDays());
                    DateEx date = new DateEx(new Date().getTime(), null);
                    date.setTime(calendar.getTimeInMillis());
                    snUserUpdateVo.setExpire_time(date);
                } else {
                    snUserUpdateVo.setExpire_time(null);
                }
            }

            if (snUserUpdateVo.getExpire_time() != null && snUserUpdateVo.getExpire_time().before(new Date())){
                throw new BusinessException(BusinessExceptionEnum.ERR_EXPIRE_TIME);
            }
        }
        // 更新newSnUser
        if (snUserUpdateVo.getExpire_time() != null) newSnUser.setExpire_time(new Timestamp(snUserUpdateVo.getExpire_time().getTime()));
        if (snUserUpdateVo.getCall_restrict() != null) newSnUser.setCall_restrict(snUserUpdateVo.getCall_restrict());
        if (snUserUpdateVo.getSettings() != null) newSnUser.setSettings(snUserUpdateVo.getSettings());
        if (snUserUpdateVo.getContacts() != null) newSnUser.setContacts(snUserUpdateVo.getContacts());

        // 更新数据
        updateSingle(snUserUpdateVo.getSub_service(), SnSubIdUtils.parseSubId(snUser.getSub_id()), snUser, newSnUser);

        logger.info("{}", JSON.toJSONString(
                new SnUserServiceLog(snUserUpdateVo.getMsg_id(),
                        snUserUpdateVo.getSub_service(),
                        snUserUpdateVo.getOp_module(),
                        snUserUpdateVo.getOp_user(),
                        snUserUpdateVo.getOp_type(),
                        snUserUpdateVo.getOp_time(),
                        snUserUpdateVo.getOp_ip(),
                        newSnUser), SerializerFeature.UseISO8601DateFormat));

        return newSnUser;
    }

    /**
     * 根据uuid_in_partner查找一个SnUser(忽略过期时间)
     * @param unit_id           unit_id
     * @param uuidInPartner     uuidInPartner
     * @return SnUser
     */
    public SnUser getSingleByUuidInPartner(String unit_id, String uuidInPartner) {

        IgniteCache<SnUserKey, SnUser> snUserCache = igniteCacheGetter.getSnUserCache(unit_id, null);

        List<List<?>> records = snUserCache.query(new SqlFieldsQuery(queryStringForByUuidInPartner).setArgs(uuidInPartner)).getAll();

        if (records != null && records.size() > 0) {
            List<?> row = records.get(0);
            return new SnUser((String)row.get(2), (Byte)row.get(3), (Byte)row.get(4), (Timestamp) row.get(5), (Timestamp) row.get(6), (Byte)row.get(7), (String)row.get(8), (String)row.get(9), (String)row.get(10), "");
        }

        return null;
    }

    /**
     * 根据uid查找一个SnUser(忽略过期时间)
     * @param unit_id   unit_id
     * @param uid       uid
     * @return          SnUser
     */
    public SnUser getSingleByUid(String unit_id, String uid) {

        IgniteCache<SnUserKey, SnUser> snUserCache = igniteCacheGetter.getSnUserCache(unit_id, null);

        List<List<?>> records = snUserCache.query(new SqlFieldsQuery(queryStringForByUid).setArgs(uid)).getAll();

        if (records != null && records.size() > 0) {
            List<?> row = records.get(0);
            return new SnUser((String)row.get(2), (Byte)row.get(3), (Byte)row.get(4), (Timestamp) row.get(5), (Timestamp) row.get(6), (Byte)row.get(7), (String)row.get(8), (String)row.get(9), (String)row.get(10), "");
        }

        return null;
    }

    /**
     * 根据reg_phone查找一个SnUser(忽略过期时间)
     * @param unit_id   unit_id
     * @param reg_phone reg_phone
     * @return          SnUser
     */
    public SnUser getSingleByRegPhone(String unit_id, String reg_phone) {

        IgniteCache<SnUserKey, SnUser> snUserCache = igniteCacheGetter.getSnUserCache(unit_id, null);

        List<List<?>> records = snUserCache.query(new SqlFieldsQuery(queryStringForByRegPhone).setArgs(reg_phone)).getAll();

        if (records != null && records.size() > 0) {
            List<?> row = records.get(0);
            return new SnUser((String)row.get(2), (Byte)row.get(3), (Byte)row.get(4), (Timestamp) row.get(5), (Timestamp) row.get(6), (Byte)row.get(7), (String)row.get(8), (String)row.get(9), (String)row.get(10), "");
        }

        return null;
    }

    /**
     * 根据uid查找一个有效的且没有呼叫限制（call_restrict<>1）的SnUser
     * @param unit_id   unit_id
     * @param uid       uid
     * @return
     */
    public SnUser getSingleValidAndNoRestrictByUid(String unit_id, String uid) {

        IgniteCache<SnUserKey, SnUser> snUserCache = igniteCacheGetter.getSnUserCache(unit_id, null);

        List<List<?>> records = snUserCache.query(new SqlFieldsQuery(queryStringForValidAndNoRestrictByUid).setArgs(uid)).getAll();

        if (records != null && records.size() > 0) {
            List<?> row = records.get(0);
            return new SnUser((String)row.get(2), (Byte)row.get(3), (Byte)row.get(4), (Timestamp) row.get(5), (Timestamp) row.get(6), (Byte)row.get(7), (String)row.get(8), (String)row.get(9), (String)row.get(10), "");
        }

        return null;
    }

    /**
     * 根据电话查找一个有效的SnUser（不限uid_type）
     * @param unit_id   unit_id
     * @param phone     phone
     * @return
     */
    public SnUser getSingleValidByPhone(String unit_id, String phone) {

        IgniteCache<SnUserKey, SnUser> snUserCache = igniteCacheGetter.getSnUserCache(unit_id, null);

        List<List<?>> records = snUserCache.query(new SqlFieldsQuery(queryStringForValidByPhone).setArgs(phone)).getAll();

        if (records != null && records.size() > 0) {
            List<?> row = records.get(0);
            return new SnUser((String)row.get(2), (Byte)row.get(3), (Byte)row.get(4), (Timestamp) row.get(5), (Timestamp) row.get(6), (Byte)row.get(7), (String)row.get(8), (String)row.get(9), (String)row.get(10), "");
        }

        return null;
    }

    /**
     * 根据电话和uid_type查找一个有效的SnUser
     * @param unit_id   unit_id
     * @param phone     phone
     * @param uid_type  uid_type
     * @return
     */
    public SnUser getSingleValidByPhoneAndUidType(String unit_id, String phone, Byte uid_type) {

        IgniteCache<SnUserKey, SnUser> snUserCache = igniteCacheGetter.getSnUserCache(unit_id, null);

        List<List<?>> records = snUserCache.query(new SqlFieldsQuery(queryStringForValidByPhoneAndUidType).setArgs(phone, uid_type)).getAll();

        if (records != null && records.size() > 0) {
            List<?> row = records.get(0);
            return new SnUser((String)row.get(2), (Byte)row.get(3), (Byte)row.get(4), (Timestamp) row.get(5), (Timestamp) row.get(6), (Byte)row.get(7), (String)row.get(8), (String)row.get(9), (String)row.get(10), "");
        }

        return null;
    }

    /**
     * 根据uid_type计算未过期的用户数(采用Sql查询方式实现，性能差，请谨慎使用)
     * @param unit_id   unit_id
     * @param uid_type  uid_type
     * @return count
     */
    public int getValidCount(String unit_id, Byte uid_type) {

        IgniteCache<SnUserKey, SnUser> snUserCache = igniteCacheGetter.getSnUserCache(unit_id, null);

        List<List<?>> records = snUserCache.query(new SqlFieldsQuery(queryStringForValidCount).setArgs(uid_type)).getAll();

        if (records != null && records.size() > 0) {
            List<?> row = records.get(0);
            return (Integer) row.get(0);
        } else {
            return 0;
        }
    }

    //出于性能考虑，暂未实现按uid_type分别查询
    public List<Cache.Entry<SnUserKey, SnUser>> getAll(String unit_id, Byte uid_type) {

        List<Cache.Entry<SnUserKey, SnUser>> result = new ArrayList<>();

        IgniteCache<SnUserKey, SnUser> snUserCache = igniteCacheGetter.getSnUserCache(unit_id, null);

        //注意：当数据量很大时，用SqlQuery如果不加入LIMIT限制（即使PageSize设置很小）会导致查询超时甚至引起Ignite异常退出
        //QueryCursor<Cache.Entry<SnUserKey, SnUser>> cursor = snUserCache.query(new SqlQuery<SnUserKey, SnUser>(SnUser.class, "1=1").setPageSize(20));
        //用ScanQuery暂时无法实现检索
        QueryCursor<Cache.Entry<SnUserKey, SnUser>> cursor = snUserCache.query(new ScanQuery<SnUserKey, SnUser>().setPageSize(20));

        //todo 目前仅随机返回了20条，如何返回多个分页还需考虑
        for (Cache.Entry<SnUserKey, SnUser> entry : cursor) {
            result.add(entry);
            if (result.size() >= 20)
                break;
        }
        return result;
    }

    private Map<String, Object> getLastOpLogByUid(String uid) throws Exception {

        SearchSourceBuilder searchSourceBuilder = new SearchSourceBuilder();
        searchSourceBuilder.query(QueryBuilders.termQuery("snUser.uid", uid));
        searchSourceBuilder.sort(new FieldSortBuilder("op_time").order(SortOrder.DESC));
        searchSourceBuilder.size(1);

        SearchRequest searchRequest = new SearchRequest("sn_user_log");
        searchRequest.source(searchSourceBuilder);

        SearchResponse response = elasticClient.search(searchRequest, RequestOptions.DEFAULT);

        if (response.getHits().getHits().length >= 1) {
            Map<String, Object> record = new HashMap<>();
            record.put("op_type", response.getHits().getHits()[0].getSourceAsMap().get("op_type"));
            record.put("snUser", response.getHits().getHits()[0].getSourceAsMap().get("snUser"));
            return record;
        } else {
            return null;
        }
    }

    public SnUser recoverSingle(SnUnit snUnit, SnUserRecoverVo snUserRecoverVo) throws Exception {
        // 先获取注销记录（根据uid查最后一次操作记录，如果是注销且phone一致，才可恢复）
        Map<String, Object> record = getLastOpLogByUid(snUserRecoverVo.getUid());
        if (record == null) {
            throw new BusinessException(BusinessExceptionEnum.ERR_DATA_NOT_EXIST);
        }
        if (!StringUtils.equals((String) record.get("op_type"), "d")) {
            throw new BusinessException(BusinessExceptionEnum.ERR_DATA_NOT_EXIST);
        }
        SnUser snUser;
        try {
            snUser = JSON.parseObject(JSON.toJSONBytes(record.get("snUser")), SnUser.class);
        } catch (Exception e) {
            snUser = null;
        }
        if (snUser == null) {
            throw new BusinessException(BusinessExceptionEnum.ERR_DATA_NOT_EXIST);
        }
        if (!StringUtils.equals(snUser.getReg_phone(), snUserRecoverVo.getReg_phone())) {
            throw new BusinessException(BusinessExceptionEnum.ERR_DATA_NOT_EXIST);
        }

        // 注销记录有效，执行注册操作
        // 黑名单判断(reg_phone)，因期间黑名单库可能有更新
        if (blackListService.isBlackList(snUserRecoverVo.getSub_service(),snUser.getReg_phone())) {
            throw new BusinessException(BusinessExceptionEnum.ERR_BLOCKED_PHONE);
        }
        // 盲区判断(reg_phone)，因期间盲区库可能有更新
        if (deadZoneService.isDeadZone(snUser.getReg_phone())) {
            throw new BusinessException(BusinessExceptionEnum.ERR_DEAD_ZONE);
        }
        // 黑名单和盲区判断(other_phone/contact)，因期间黑名单和盲区库可能有更新
        if (StringUtils.isNotBlank(snUser.getContacts())) {
            for (String contact:
                    (snUser.getContacts() + ",").split(",")) {
                if (blackListService.isBlackList(snUserRecoverVo.getSub_service(), contact)) {
                    throw new BusinessException(BusinessExceptionEnum.ERR_BLOCKED_PHONE);
                }
                if (deadZoneService.isDeadZone(contact)) {
                    throw new BusinessException(BusinessExceptionEnum.ERR_DEAD_ZONE);
                }
            }
        }

        // 判断uid是否可用，先从等待回收的uid队列中判断，再从号池中判断，这样可以避免刚查完号池没有，查回收队列时恰好被回收了的特殊情况
        if (snUidReserveQueueService.del(snUserRecoverVo.getSub_service(), snUser.getUid_type(), snUser.getUid()) <= 0) {
            if (StringUtils.isBlank(snUidService.pop(snUserRecoverVo.getSub_service(), snUser.getUid_type(), snUser.getUid()))) {
                // 返回uid不可用的具体原因
                // 查询95号码是否分配给该unit(未区分uid_type)
                if (snUidSectService.getUidSectByUid(snUser.getUid()) == null) {
                    throw new BusinessException(BusinessExceptionEnum.ERR_UID_NOT_OWNER);
                }
                // 判断是否已使用
                throw new BusinessException(BusinessExceptionEnum.ERR_UID_OCCUPIED);
            }
        }

        // 修改snUser的expire_time
        if (snUserRecoverVo.getExpire_time() == null) {
            // 根据unit的param设置expire_time
            Integer expire_time = snUnit.getParamsObject().getExpire_time();
            if (expire_time != null) {
                Calendar calendar = new GregorianCalendar();
                calendar.setTime(new Date());
                calendar.add(Calendar.DATE, expire_time);
                DateEx date = new DateEx(new Date().getTime(), null);
                date.setTime(calendar.getTimeInMillis());
                snUserRecoverVo.setExpire_time(date);
            }
        }
        snUser.setExpire_time(snUserRecoverVo.getExpire_time() == null ? null : new Timestamp(snUserRecoverVo.getExpire_time().getTime()));

        // 构造SnUserKey
        SnUserKey snUserKey = new SnUserKey(snUser.getReg_phone(), snUser.getUid());

        // 修改snUser的sub_id
        snUser.setSub_id(SnSubIdUtils.genSubId(snUserKey));

        // 执行写入操作
        addSingle(snUserRecoverVo.getSub_service(), snUserKey, snUser);

        logger.info("{}", JSON.toJSONString(
                new SnUserServiceLog(snUserRecoverVo.getMsg_id(),
                        snUserRecoverVo.getSub_service(),
                        snUserRecoverVo.getOp_module(),
                        snUserRecoverVo.getOp_user(),
                        snUserRecoverVo.getOp_type(),
                        snUserRecoverVo.getOp_time(),
                        snUserRecoverVo.getOp_ip(),
                        snUser), SerializerFeature.UseISO8601DateFormat));
        return snUser;
    }
}
