package cn.cvtt.safenumber.common.service;

import cn.cvtt.safenumber.common.model.SnUnit;
import cn.cvtt.safenumber.common.model.SnUnitKey;
import cn.cvtt.safenumber.common.exception.SecureValidException;
import cn.cvtt.safenumber.common.exception.SecureValidExceptionEnum;
import org.apache.ignite.IgniteCache;
import org.apache.ignite.cache.query.ScanQuery;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import javax.cache.Cache;
import java.util.List;

@Service
public class SnUnitService {

    @Resource
    IgniteCache<SnUnitKey, SnUnit> snUnitCache;

    //@Resource
    //private StringRedisTemplate stringRedisTemplate;

    public void addSingle(SnUnitKey snUnitKey, SnUnit snUnit) {
        // 写入表
        snUnitCache.put(snUnitKey, snUnit);
        /*// platform_key和secret写入redis
        JSONObject snAuth = new JSONObject();
        snAuth.put("platform_key", snUnit.getPlatform_key());
        snAuth.put("secret", snUnit.getSecret());
        stringRedisTemplate.opsForValue().set(snUnitKey.getUnit_id() +":SnAuth:", snAuth.toJSONString());*/
    }

    public Boolean delSingle(SnUnitKey snUnitKey) {
        return snUnitCache.remove(snUnitKey);
        /*if (snUnitCache.remove(snUnitKey)) {
            return stringRedisTemplate.delete(snUnitKey.getUnit_id() +":SnAuth:");
        } else {
            return false;
        }*/
    }

    public SnUnit getByUnitId(String unit_id) {
        return snUnitCache.get(new SnUnitKey(unit_id));
    }

    public SnUnit checkUnitId(String unit_id) {
        SnUnit snUnit = snUnitCache.get(new SnUnitKey(unit_id));

        if (snUnit == null) {
            // 使用了错误的unit_id
            throw new SecureValidException(SecureValidExceptionEnum.ERR_ID);
        } else {
            if (snUnit.getState() != null && snUnit.getState() != 1) {
                // unit被disable
                throw new SecureValidException(SecureValidExceptionEnum.ERR_ID_DISABLE);
            }
        }

        return snUnit;
    }

    public List<Cache.Entry<SnUnitKey, SnUnit>> getAll() {
        //return snUnitCache.query(new SqlQuery<SnUnitKey, SnUnit>(SnUnit.class,"1 = 1")).getAll();
        return snUnitCache.query(new ScanQuery<SnUnitKey, SnUnit>()).getAll();
    }
}
