package cn.cvtt.safenumber.common.exception;

@SuppressWarnings({"CanBeFinal", "SameParameterValue"})
public enum BusinessExceptionEnum {

    ERR_BLOCKED_PHONE(201,"Service error","phone-in-blacklist","电话号码属于敏感号码"),
    ERR_DEAD_ZONE(201,"Service error","service-not-available","电话号码属于95013盲区"),
    ERR_UID_INSUFFICIENT(201, "Service error", "resource-insufficient", "号码资源不足"),
    ERR_UID_OCCUPIED(201, "Service error", "resource-insufficient", "指定号码已被占用"),
    ERR_UID_NOT_OWNER(201, "Service error", "safenumber-wrong", "指定号码不存在"),
    ERR_UID_CREATE(201, "Service error", "server-error", "添加UID失败"),
    ERR_DATA_NOT_EXIST(102, "Data error", "data-not-exist", "没有数据"),
    ERR_UNIT_OCCUPIED(201, "Service error", "unit-occupied", "指定unit_id已被占用"),
    ERR_UNREGISTER(201, "Service error", "server-error", "解绑失败"),
    ERR_INSUFFICIENT_PARAM_UPDATE_USER (101,"Parameter error","insufficient-parameter","必须有sub_id或uuid_in_partner或'reg_phone和uid'"),
    ERR_EXPIRE_TIME (101,"Parameter error","invalid-parameter","expire_time需要是一个将来的时间"),
    ERR_TWO_WAY_CALL_MSG (101,"Parameter error","invalid-parameter","msg_data不是有效的JSON数据"),
    ERR_TWO_WAY_CALL_CALLER (101,"Parameter error","invalid-parameter","caller非法"),
    ERR_TWO_WAY_CALL_CALLEE (101,"Parameter error","invalid-parameter","callee不是有效的电话号码");

    private Integer code;
    private String message;
    private String subCode;
    private String subMessage;

    BusinessExceptionEnum(Integer code, String message, String subCode, String subMessage) {
        this.code = code;
        this.message = message;
        this.subCode = subCode;
        this.subMessage = subMessage;
    }

    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getSubCode() {
        return subCode;
    }

    public void setSubCode(String subCode) {
        this.subCode = subCode;
    }

    public String getSubMessage() {
        return subMessage;
    }

    public void setSubMessage(String subMessage) {
        this.subMessage = subMessage;
    }
}
