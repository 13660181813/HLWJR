package cn.cvtt.safenumber.common.vo;

import cn.cvtt.safenumber.common.format.annotation.DateTimeExFormat;
import cn.cvtt.safenumber.common.util.DateEx;
import cn.cvtt.safenumber.common.validation.constraints.PhoneConstraint;
import org.springframework.format.annotation.DateTimeFormat;

import javax.validation.constraints.*;
import java.util.Date;

public class SnUserRecoverVo extends CommonVo {

    @NotEmpty
    @PhoneConstraint
    private String reg_phone;

    @NotEmpty
    @Pattern(regexp = "^95013\\d{0,12}$", message = "不是有效的安全号码")
    private String uid;

    @Future
    @DateTimeExFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private DateEx expire_time;

    // reg_time不从http request中获取，需要在controller中手工赋值
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date reg_time;

    public String getReg_phone() {
        return reg_phone;
    }

    public void setReg_phone(String reg_phone) {
        this.reg_phone = reg_phone;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public DateEx getExpire_time() {
        return expire_time;
    }

    public void setExpire_time(DateEx expire_time) {
        this.expire_time = expire_time;
    }

    public Date getReg_time() {
        return reg_time;
    }

    public void setReg_time(Date reg_time) {
        this.reg_time = reg_time;
    }
}
