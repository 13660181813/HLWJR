package cn.cvtt.safenumber.common.vo;

import cn.cvtt.safenumber.common.validation.constraints.PhoneConstraint;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

public class CallQueryVo extends CommonVo{

    @NotBlank
    @PhoneConstraint
    private String caller;

    @NotBlank
    @Pattern(regexp = "^95013\\d{0,12}$", message = "不是有效的安全号码")
    private String called;

    @NotBlank
    @Size(max = 64)
    private String call_id;

    public String getCaller() {
        return caller;
    }

    public void setCaller(String caller) {
        this.caller = caller;
    }

    public String getCalled() {
        return called;
    }

    public void setCalled(String called) {
        this.called = called;
    }

    public String getCall_id() {
        return call_id;
    }

    public void setCall_id(String call_id) {
        this.call_id = call_id;
    }
}
