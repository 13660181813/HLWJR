package cn.cvtt.safenumber.common.pojo;

import java.util.Date;

public class CallQueryResponse {
    private Byte op_type;
    private Byte call_type;
    private String callee;
    private String play_code;
    private String display_code;
    private Boolean record;
    private String unit_id_real;
    private Date last_call_time;
    private String sub_id;
    private Long reg_time;
    private String uuid_in_partner;

    public CallQueryResponse() {
    }

    public CallQueryResponse(Byte op_type, Byte call_type, String callee, String play_code, String display_code, Boolean record, String unit_id_real, Date last_call_time, String sub_id, Long reg_time, String uuid_in_partner) {
        this.op_type = op_type;
        this.call_type = call_type;
        this.callee = callee;
        this.play_code = play_code;
        this.display_code = display_code;
        this.record = record;
        this.unit_id_real = unit_id_real;
        this.last_call_time = last_call_time;
        this.sub_id = sub_id;
        this.reg_time = reg_time;
        this.uuid_in_partner = uuid_in_partner;
    }

    public Byte getOp_type() {
        return op_type;
    }

    public void setOp_type(Byte op_type) {
        this.op_type = op_type;
    }

    public Byte getCall_type() {
        return call_type;
    }

    public void setCall_type(Byte call_type) {
        this.call_type = call_type;
    }

    public String getCallee() {
        return callee;
    }

    public void setCallee(String callee) {
        this.callee = callee;
    }

    public String getPlay_code() {
        return play_code;
    }

    public void setPlay_code(String play_code) {
        this.play_code = play_code;
    }

    public String getDisplay_code() {
        return display_code;
    }

    public void setDisplay_code(String display_code) {
        this.display_code = display_code;
    }

    public Boolean getRecord() {
        return record;
    }

    public void setRecord(Boolean record) {
        this.record = record;
    }

    public String getUnit_id_real() {
        return unit_id_real;
    }

    public void setUnit_id_real(String unit_id_real) {
        this.unit_id_real = unit_id_real;
    }

    public Date getLast_call_time() {
        return last_call_time;
    }

    public void setLast_call_time(Date last_call_time) {
        this.last_call_time = last_call_time;
    }

    public String getSub_id() {
        return sub_id;
    }

    public void setSub_id(String sub_id) {
        this.sub_id = sub_id;
    }

    public Long getReg_time() {
        return reg_time;
    }

    public void setReg_time(Long reg_time) {
        this.reg_time = reg_time;
    }

    public String getUuid_in_partner() {
        return uuid_in_partner;
    }

    public void setUuid_in_partner(String uuid_in_partner) {
        this.uuid_in_partner = uuid_in_partner;
    }
}
