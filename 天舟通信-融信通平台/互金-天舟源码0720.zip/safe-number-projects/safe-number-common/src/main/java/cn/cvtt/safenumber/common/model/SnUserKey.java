package cn.cvtt.safenumber.common.model;

import com.alibaba.fastjson.JSON;
import org.apache.ignite.cache.query.annotations.QuerySqlField;

import javax.validation.constraints.NotNull;

/**
 *  todo: 可以考虑和SnUserContactKey共用此类
 */
@SuppressWarnings("CanBeFinal")
public class SnUserKey {
    @QuerySqlField(index = true)
    private String reg_phone;

    @QuerySqlField(index = true)
    private String uid;

    public SnUserKey(@NotNull String reg_phone, @NotNull String uid) {
        this.reg_phone = reg_phone;
        this.uid = uid;
    }

    public String getReg_phone() {
        return reg_phone;
    }

    public String getUid() {
        return uid;
    }

    /*@Override
    public String toString() {
        return reg_phone + "," + uid;
    }*/

    @Override
    public String toString() {
        return JSON.toJSONString(this);
    }
}
