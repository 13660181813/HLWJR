package cn.cvtt.safenumber.common.service;

import cn.cvtt.safenumber.common.model.SnUidSect;
import cn.cvtt.safenumber.common.model.SnUidSectKey;
import org.apache.ignite.IgniteCache;
import org.apache.ignite.cache.query.SqlFieldsQuery;
import org.springframework.stereotype.Service;

import javax.annotation.Nullable;
import javax.annotation.Resource;
import java.util.*;

@SuppressWarnings("Duplicates")
@Service
public class SnUidSectService {

    private static final String queryStringByUid = "SELECT UNIT_ID, UID_TYPE, UID_BEGIN, UID_END, UID_COUNT FROM SNUIDSECT WHERE UID_BEGIN_KEY <= ? AND UID_END_KEY >= ? LIMIT 1";
    private static final String queryStringByUnitId = "SELECT UNIT_ID, UID_TYPE, UID_BEGIN, UID_END, UID_COUNT FROM SNUIDSECT WHERE UNIT_ID = ?";
    private static final String queryStringByUnitIdAndType = "SELECT UNIT_ID, UID_TYPE, UID_BEGIN, UID_END, UID_COUNT FROM SNUIDSECT WHERE UNIT_ID = ? AND UID_TYPE = ?";
    private static final String queryStringForCountByType = "SELECT SUM(UID_COUNT) FROM SNUIDSECT WHERE UNIT_ID = ? AND UID_TYPE = ?";

    @Resource
    private IgniteCache<SnUidSectKey, SnUidSect> snUidSectCache;

    @Nullable
    public SnUidSect getUidSectByUid(String uid) {

        // "1"+uid转换为Long值，以便查询时利用索引
        Long uidLongValue = Long.parseLong("1" + uid);

        //QueryCursor<List<?>> resultCur = snUidSectCache.query(new SqlFieldsQuery(queryStringByUid).setArgs(uidLongValue, uidLongValue));
        List<List<?>> records = snUidSectCache.query(new SqlFieldsQuery(queryStringByUid).setArgs(uidLongValue, uidLongValue)).getAll();

        if (records != null && records.size() > 0) {
            List<?> row = records.get(0);
            return new SnUidSect((String) row.get(0), (Byte) row.get(1), (String) row.get(2), (String) row.get(3), (Long) row.get(4), "");
        }

        return null;
    }

    /**
     * 根据unid_id获取号段列表
     * @param unit_id   unit_id
     * @return  号段列表
     */
    @Nullable
    public List<SnUidSect> getUidSectByUnitId(String unit_id) {

        List<List<?>> records = snUidSectCache.query(new SqlFieldsQuery(queryStringByUnitId).setArgs(unit_id)).getAll();

        List<SnUidSect> snUidSects = new ArrayList<>();

        records.forEach(row -> snUidSects.add(new SnUidSect((String) row.get(0), (Byte) row.get(1), (String) row.get(2), (String) row.get(3), (Long) row.get(4), "")));

        return snUidSects;
    }

    /**
     * 根据unid_id和uid_type获取号段列表
     * @param unit_id   unit_id
     * @param uid_type  uid_type
     * @return  号段列表
     */
    @Nullable
    public List<SnUidSect> getUidSectByUnitIdAndType(String unit_id, Byte uid_type) {

        List<List<?>> records = snUidSectCache.query(new SqlFieldsQuery(queryStringByUnitIdAndType).setArgs(unit_id, uid_type)).getAll();

        List<SnUidSect> snUidSects = new ArrayList<>();

        records.forEach(row -> snUidSects.add(new SnUidSect((String) row.get(0), (Byte) row.get(1), (String) row.get(2), (String) row.get(3), (Long) row.get(4), "")));

        return snUidSects;
    }

    /**
     * 添加一个号段（注：未校验数据，前端需要校验）
     * @param unit_id   unit_id
     * @param uid_type  uid_type
     * @param uid_begin 开始号码
     * @param uid_end   结束号码
     */
    public void addUidSection(String unit_id, Byte uid_type, String uid_begin, String uid_end) {

        Long uid_begin_key = Long.parseLong("1" + uid_begin);
        Long uid_end_key = Long.parseLong("1" + uid_end);

        snUidSectCache.put(new SnUidSectKey(uid_begin_key, uid_end_key),
                new SnUidSect(unit_id, uid_type, uid_begin, uid_end, uid_end_key - uid_begin_key + 1, ""));
    }

    /**
     * 根据开始号码和结束号码删除一个号段（注：未校验数据，前端需要校验）
     * @param uid_begin 开始号码
     * @param uid_end   结束号码
     */
    public boolean delUidSection(String uid_begin, String uid_end) {

        Long uid_begin_key = Long.parseLong("1" + uid_begin);
        Long uid_end_key = Long.parseLong("1" + uid_end);

        return snUidSectCache.remove(new SnUidSectKey(uid_begin_key, uid_end_key));
    }

    /**
     * 根据unid_id和uid_type获取号段总数
     * @param unit_id   unit_id
     * @param uid_type  uid_type
     * @return  号段总数
     */
    public Long getUidCountByType(String unit_id, Byte uid_type) {

        List<List<?>> records = snUidSectCache.query(new SqlFieldsQuery(queryStringForCountByType).setArgs(unit_id, uid_type)).getAll();

        return Long.parseLong(records.get(0).get(0).toString());
    }
}
