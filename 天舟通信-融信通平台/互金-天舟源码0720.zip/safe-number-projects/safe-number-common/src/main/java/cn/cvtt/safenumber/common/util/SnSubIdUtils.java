package cn.cvtt.safenumber.common.util;

import cn.cvtt.safenumber.common.model.SnUserKey;

import javax.validation.constraints.NotNull;

import static org.springframework.util.Assert.notNull;

public class SnSubIdUtils {
    public static String genSubId(@NotNull SnUserKey snUserKey) {
        notNull(snUserKey, "snUserKey must not be 'null'.");
        notNull(snUserKey.getReg_phone(),"phone must not be 'null'");
        notNull(snUserKey.getUid(),"uid must not be 'null'");

        return Long.toString(Long.parseLong("1" + snUserKey.getReg_phone()),32) + "-"
                + Long.toString(Long.parseLong("1" + snUserKey.getUid()),32) + "-"
                + Long.toString(System.currentTimeMillis(),32);
    }

    public static SnUserKey parseSubId(@NotNull String subId) {
        notNull(subId, "subId must not be 'null'.");

        String [] arrOfSubId = subId.split("-");
        if (3 == arrOfSubId.length) {
            return new SnUserKey(Long.toString(Long.parseLong(arrOfSubId[0],32)).substring(1), Long.toString(Long.parseLong(arrOfSubId[1],32)).substring(1));
        }
        return new SnUserKey("", "");
    }
}
