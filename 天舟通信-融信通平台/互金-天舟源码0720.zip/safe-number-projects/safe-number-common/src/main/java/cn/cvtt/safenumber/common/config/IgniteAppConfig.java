package cn.cvtt.safenumber.common.config;

import org.apache.ignite.Ignite;
import org.apache.ignite.Ignition;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@ConditionalOnProperty(prefix = "ignite", name = "cfg-path")
@Configuration
public class IgniteAppConfig {

    @Value("${ignite.cfg-path}")
    private String cfgPath;

    /**
     * Creating Apache Ignite instance bean.
     */
    @Bean
    public Ignite igniteInstance() {
        Ignite ignite = Ignition.start(cfgPath);
        //如果开启了持久化，则集群在第一启动时需要active，且应在所有节点加入之后执行，在active之后加入的节点不会自动参与集群的存储和计算，需要调整基线拓扑
        //参见https://liyuj.gitee.io/doc/java/Persistence.html#_16-5-3-%E9%85%8D%E7%BD%AE%E5%9F%BA%E7%BA%BF%E6%8B%93%E6%89%91
        //todo 何时active集群，尚需进一步考虑优化，包括分别测试在server模式和client模式下是否都可以像目前这样在Configuration时直接active？
        // 多个这样的server启动时间有无考究？是否需要事先用其他方式启动一个server节点？是否不要在Configuration阶段就初始化IgniteCache（指snUnitCache和snUidSectCache）
        if (!Ignition.isClientMode() && !ignite.cluster().active())
            ignite.cluster().active(true);
        return ignite;
    }
}
