package cn.cvtt.safenumber.common.model;

import org.apache.ignite.cache.query.annotations.QuerySqlField;

import java.sql.Timestamp;

/**
 * 最后一次通话记录的value
 * 只有呼叫类型是XA（NXA/BXA）时才记录，双呼时也是只有当能当做XA时才记录
 * caller: 直呼时a路主叫或双呼时a路被叫，对应N或B
 * called: 直呼时a路被叫或双呼时a路主叫，一般是对应X（但双呼时也可能是统一来显）
 */
@SuppressWarnings("CanBeFinal")
public class SnLastCall {

    @QuerySqlField(index = true)
    private String caller;

    @QuerySqlField(index = true)
    private String called;

    @QuerySqlField
    private Timestamp start_time;

    @QuerySqlField
    private String reserved;

    public SnLastCall(String caller, String called, Timestamp start_time, String reserved) {
        this.caller = caller;
        this.called = called;
        this.start_time = start_time;
        this.reserved = reserved;
    }

    public String getCaller() {
        return caller;
    }

    public String getCalled() {
        return called;
    }

    public Timestamp getStart_time() {
        return start_time;
    }

    public String getReserved() {
        return reserved;
    }
}
