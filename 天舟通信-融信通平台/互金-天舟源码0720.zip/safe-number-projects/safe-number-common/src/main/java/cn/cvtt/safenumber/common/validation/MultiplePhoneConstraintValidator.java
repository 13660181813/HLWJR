package cn.cvtt.safenumber.common.validation;

import cn.cvtt.safenumber.common.validation.constraints.MultiplePhoneConstraint;
import cn.cvtt.safenumber.common.constents.Regex;
import org.apache.commons.lang.StringUtils;

import javax.annotation.Resource;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

/**
 * 对形如"13911112222,13811112222"的电话号码组进行校验（也支持单号码）
 */
public class MultiplePhoneConstraintValidator implements ConstraintValidator<MultiplePhoneConstraint, Object> {

    @Resource
    private Regex regex;

    @Override
    public void initialize(MultiplePhoneConstraint constraintAnnotation) {

    }

    @Override
    public boolean isValid(Object value, ConstraintValidatorContext context) {

        //为空视为有效，这样可配合NotEmpty等注解来限制是否必填
        if (StringUtils.isEmpty((String) value)) {
            return true;
        }

        //遍历进行正则匹配
        for (String phone : (value + ",").split(",")) {
            if (!(phone.matches(regex.PHONE_FIXED) || phone.matches(regex.PHONE_MOBILE))) {
                //任一不匹配则返回false
                return false;
            }
        }

        //全部匹配返回true
        return true;
    }

}
