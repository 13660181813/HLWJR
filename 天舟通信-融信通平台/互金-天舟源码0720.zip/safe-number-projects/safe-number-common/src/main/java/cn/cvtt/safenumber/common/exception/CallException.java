package cn.cvtt.safenumber.common.exception;

@SuppressWarnings("CanBeFinal")
public class CallException extends RuntimeException {

    private CallExceptionEnum exceptionEnum;
    private String unit_id_real;
    private Byte call_type;

    public CallException(CallExceptionEnum exceptionEnum, String unit_id_real, Byte call_type) {
        this.exceptionEnum = exceptionEnum;
        this.unit_id_real = unit_id_real;
        this.call_type = call_type;
    }

    public CallExceptionEnum getExceptionEnum() {
        return exceptionEnum;
    }

    public String getUnit_id_real() {
        return unit_id_real;
    }

    public Byte getCall_type() {
        return call_type;
    }
}
