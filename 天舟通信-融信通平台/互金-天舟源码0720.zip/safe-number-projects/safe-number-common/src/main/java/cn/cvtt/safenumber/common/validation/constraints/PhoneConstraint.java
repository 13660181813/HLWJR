package cn.cvtt.safenumber.common.validation.constraints;

import cn.cvtt.safenumber.common.validation.PhoneConstraintValidator;

import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.*;

@Documented
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.FIELD})
@Constraint(validatedBy = PhoneConstraintValidator.class)
public @interface PhoneConstraint {

    String message() default "不是有效的电话号码";

    Class<?>[] groups() default { };

    Class<? extends Payload>[] payload() default { };
}
