package cn.cvtt.safenumber.common.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.data.redis.core.script.DefaultRedisScript;
import org.springframework.scripting.support.ResourceScriptSource;

import java.util.List;

/**
 * 加载redis的lua脚本
 */
@Configuration
public class RedisScriptConfigure {

    /*private static final String script =
            "-- 通过组合调用ZRANGEBYSCORE和ZREM实现返回zset中所需数据并删除\n" +
            "local result = redis.call('ZRANGEBYSCORE', KEYS[1], ARGV[1], ARGV[2], 'LIMIT', 0, ARGV[3]);\n" +
            "if #result > 0 then\n" +
            "  redis.call('ZREM', KEYS[1], unpack(result));\n" +
            "  return result;\n" +
            "else\n" +
            "  return {};\n" +
            "end";*/

    @Bean
    public DefaultRedisScript<List> ZRANGEBYSCORE_and_ZREM() {
        DefaultRedisScript<List> defaultRedisScript = new DefaultRedisScript<>();
        defaultRedisScript.setResultType(List.class);
        //defaultRedisScript.setScriptText(script);
        defaultRedisScript.setScriptSource(new ResourceScriptSource(new ClassPathResource("ZRANGEBYSCORE_and_ZREM.lua")));
        return defaultRedisScript;
    }
}
