package cn.cvtt.safenumber.common.exception;

@SuppressWarnings("CanBeFinal")
public class BusinessException extends RuntimeException {

    private BusinessExceptionEnum exceptionEnum;

    public BusinessException(BusinessExceptionEnum businessExceptionEnum) {
        super(businessExceptionEnum.getSubMessage());
        this.exceptionEnum = businessExceptionEnum;
    }

    public BusinessExceptionEnum getExceptionEnum() {
        return exceptionEnum;
    }
}
