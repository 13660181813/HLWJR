package cn.cvtt.safenumber.common.validation.constraints;

import cn.cvtt.safenumber.common.validation.MultiplePhoneConstraintValidator;

import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.*;

@Documented
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.FIELD})
@Constraint(validatedBy = MultiplePhoneConstraintValidator.class)
public @interface MultiplePhoneConstraint {

    String message() default "存在无效的电话号码";

    Class<?>[] groups() default { };

    Class<? extends Payload>[] payload() default { };
}
