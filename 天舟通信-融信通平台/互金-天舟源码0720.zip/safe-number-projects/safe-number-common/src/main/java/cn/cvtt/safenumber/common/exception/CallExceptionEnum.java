package cn.cvtt.safenumber.common.exception;

@SuppressWarnings("CanBeFinal")
public enum CallExceptionEnum {

    ERR_NO_PRIVILEGE("991","查询的被叫(no_x)不属于接口指定的unit_id"),
    ERR_BAD_NOX("992","查询不到被叫(no_x)的号段归属"),
    ERR_NOREG_NOA_CALL_NOY("994","被叫为统一来显，但主叫无绑定关系或绑定关系已过期"),
    ERR_NO_LAST_CALL("995","被叫为统一来显，但无通话记录"),
    ERR_CALL_RESTRICT("996","被叫(no_x)设置了来话控制"),
    ERR_NO_NOB_NO_LAST_CALL("997","AX时既无B号码也无通话记录"),
    ERR_NOREG_NOX_OR_CALL_RESTRICT("999","被叫(no_x)无绑定记录或设置了来话控制");


    private String code;
    private String message;

    CallExceptionEnum(String code, String message) {
        this.code = code;
        this.message = message;
    }

    public String getCode() {
        return code;
    }

    public String getMessage() {
        return message;
    }
}
