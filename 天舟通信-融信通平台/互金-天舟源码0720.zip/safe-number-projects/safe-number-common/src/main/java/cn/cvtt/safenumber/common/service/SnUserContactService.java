package cn.cvtt.safenumber.common.service;

import cn.cvtt.safenumber.common.config.IgniteCacheGetter;
import cn.cvtt.safenumber.common.model.SnUser;
import cn.cvtt.safenumber.common.model.SnUserContact;
import cn.cvtt.safenumber.common.model.SnUserContactKey;
import cn.cvtt.safenumber.common.model.SnUserKey;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.*;

@Service
public class SnUserContactService {

    @Resource
    private IgniteCacheGetter igniteCacheGetter;

    private void addSingle(String unit_id, SnUserContactKey snUserContactKey, SnUserContact snUserContact) {
        igniteCacheGetter.getSnUserContactCache(unit_id, null).put(snUserContactKey, snUserContact);
    }

    private void addMultiple(String unit_id, Map<SnUserContactKey,SnUserContact> snUserContactKeySnUserContactmap) {
        igniteCacheGetter.getSnUserContactCache(unit_id, null).putAll(snUserContactKeySnUserContactmap);
    }
    private SnUserContact getSingle(String unit_id, SnUserContactKey snUserContactKey) {
        return igniteCacheGetter.getSnUserContactCache(unit_id, null).get(snUserContactKey);
    }

    private Boolean delSingle(String unit_id, SnUserContactKey snUserContactKey) {
        return igniteCacheGetter.getSnUserContactCache(unit_id, null).remove(snUserContactKey);
    }

    private void delMultiple(String unit_id, Set<SnUserContactKey> snUserContactKeys) {
        igniteCacheGetter.getSnUserContactCache(unit_id, null).removeAll(snUserContactKeys);
    }

    public void addSingle(String unit_id, String contact_phone, String uid, String reg_phone) {
        addSingle(unit_id, new SnUserContactKey(contact_phone, uid), new SnUserContact(reg_phone, ""));
    }

    public void addMultiple(String unit_id, SnUserKey snUserKey, SnUser snUser) {

        Map<SnUserContactKey,SnUserContact> snUserContactKeySnUserContactmap = new HashMap<>();

        //遍历写入Map
        for (String contact:
                (snUser.getContacts()+",").split(",")) {
            snUserContactKeySnUserContactmap.put(new SnUserContactKey(contact, snUserKey.getUid()) , new SnUserContact(snUserKey.getReg_phone(), ""));
        }

        addMultiple(unit_id, snUserContactKeySnUserContactmap);
    }

    public SnUserContact getSingle(String unit_id, String contact_phone, String uid) {
        return getSingle(unit_id, new SnUserContactKey(contact_phone,uid));
    }

    public Boolean delSingle(String unit_id, String contact_phone, String uid) {
        return delSingle(unit_id, new SnUserContactKey(contact_phone, uid));
    }

    public void delMultiple(String unit_id, SnUserKey snUserKey, SnUser snUser) {
        Set<SnUserContactKey> snUserContactKeys = new HashSet<>();
        //遍历写入Set
        for (String contact:
                (snUser.getContacts()+",").split(",")) {
            snUserContactKeys.add(new SnUserContactKey(contact, snUserKey.getUid()));
        }
        delMultiple(unit_id, snUserContactKeys);
    }
}
