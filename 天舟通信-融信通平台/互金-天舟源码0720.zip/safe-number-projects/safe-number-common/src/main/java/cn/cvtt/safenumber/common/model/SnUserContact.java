package cn.cvtt.safenumber.common.model;

import org.apache.ignite.cache.query.annotations.QuerySqlField;

/**
 *
 */
@SuppressWarnings("CanBeFinal")
public class SnUserContact {
    @QuerySqlField/*(index = true)*/
    private String reg_phone;

    @QuerySqlField
    private String reserved;

    public SnUserContact(String reg_phone, String reserved) {
        this.reg_phone = reg_phone;
        this.reserved = reserved;
    }

    public String getReg_phone() {
        return reg_phone;
    }

    public String getReserved() {
        return reserved;
    }
}
