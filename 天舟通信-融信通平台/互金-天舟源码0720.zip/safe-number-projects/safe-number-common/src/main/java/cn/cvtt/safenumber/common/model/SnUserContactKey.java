package cn.cvtt.safenumber.common.model;

import org.apache.ignite.cache.query.annotations.QuerySqlField;

/**
 *  todo: 可以考虑就用SnUserKey作为key
 */
@SuppressWarnings("CanBeFinal")
public class SnUserContactKey {
    @QuerySqlField(index = true)
    private String contact_phone;

    @QuerySqlField/*(index = true)*/
    private String uid;

    public SnUserContactKey(String contact_phone, String uid) {
        this.contact_phone = contact_phone;
        this.uid = uid;
    }

    public String getContact_phone() {
        return contact_phone;
    }

    public String getUid() {
        return uid;
    }
}
