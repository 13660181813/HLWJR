package cn.cvtt.safenumber.common.vo;

import org.springframework.format.annotation.DateTimeFormat;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import java.util.Date;

public class CommonVo {

    //@NotBlank
    //private String sign;

    //@NotEmpty
    //@Pattern(regexp = "^3.0$", message = "参数必须为3.0")
    //private String ver;

    @NotBlank
    private String msg_id;

    @NotNull(message = "为必填参数")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date ts;

    @NotEmpty
    @Pattern(regexp = "^SafeNumber$", message = "参数必须为SafeNumber")
    private String service;

    @NotBlank
    private String sub_service;

    //@NotBlank
    //private String platform_key;

    private String op_module = "";

    private String op_user = "";

    // 以下字段不从http request中获取，需要在controller中手工赋值
    private String op_type; //用户注销时，本字段从http request中获取

    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date op_time;

    private String op_ip;

    // Getter and Setter

//    public void setSign(String sign) {
//        this.sign = sign;
//    }

//    public void setVer(String ver) {
//        this.ver = ver;
//    }

    public void setMsg_id(String msg_id) {
        this.msg_id = msg_id;
    }

    public void setTs(Date ts) {
        this.ts = ts;
    }

    public void setService(String service) {
        this.service = service;
    }

    public void setSub_service(String sub_service) {
        this.sub_service = sub_service;
    }

//    public void setPlatform_key(String platform_key) {
//        this.platform_key = platform_key;
//    }

    public void setOp_module(String op_module) {
        this.op_module = op_module;
    }

    public void setOp_user(String op_user) {
        this.op_user = op_user;
    }

    public void setOp_type(String op_type) {
        this.op_type = op_type;
    }

    public void setOp_time(Date op_time) {
        this.op_time = op_time;
    }

    public void setOp_ip(String op_ip) {
        this.op_ip = op_ip;
    }

//    public String getSign() {
//        return sign;
//    }

//    public String getVer() {
//        return ver;
//    }

    public String getMsg_id() {
        return msg_id;
    }

    public Date getTs() {
        return ts;
    }

    public String getService() {
        return service;
    }

    public String getSub_service() {
        return sub_service;
    }

//    public String getPlatform_key() {
//        return platform_key;
//    }

    public String getOp_module() {
        return op_module;
    }

    public String getOp_user() {
        return op_user;
    }

    public String getOp_type() {
        return op_type;
    }

    public Date getOp_time() {
        return op_time;
    }

    public String getOp_ip() {
        return op_ip;
    }
}
