package cn.cvtt.safenumber.common.model.pojo;

public class CallSettings {

    private Byte call_restrict;

    private String call_display;

    private Byte call_recording;

    private String anucode_aleg;

    private String anucode_bleg;

    public Byte getCall_restrict() {
        return call_restrict;
    }

    public void setCall_restrict(Byte call_restrict) {
        this.call_restrict = call_restrict;
    }

    public String getCall_display() {
        return call_display;
    }

    public void setCall_display(String call_display) {
        this.call_display = call_display;
    }

    public Byte getCall_recording() {
        return call_recording;
    }

    public void setCall_recording(Byte call_recording) {
        this.call_recording = call_recording;
    }

    public String getAnucode_aleg() {
        return anucode_aleg;
    }

    public void setAnucode_aleg(String anucode_aleg) {
        this.anucode_aleg = anucode_aleg;
    }

    public String getAnucode_bleg() {
        return anucode_bleg;
    }

    public void setAnucode_bleg(String anucode_bleg) {
        this.anucode_bleg = anucode_bleg;
    }
}
