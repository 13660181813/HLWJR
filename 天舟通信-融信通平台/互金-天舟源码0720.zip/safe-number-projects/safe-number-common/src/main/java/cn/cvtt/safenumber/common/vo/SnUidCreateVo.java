package cn.cvtt.safenumber.common.vo;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

public class SnUidCreateVo extends CommonVo {

    @Min(0)
    @Max(2)
    @NotNull(message = "为必填参数")
    private Byte uid_type;

    @Pattern(regexp = "^95013\\d{0,12}$", message = "不是有效的安全号码")
    private String uid_begin;

    @Pattern(regexp = "^95013\\d{0,12}$", message = "不是有效的安全号码")
    private String uid_end;

    public Byte getUid_type() {
        return uid_type;
    }

    public void setUid_type(Byte uid_type) {
        this.uid_type = uid_type;
    }

    public String getUid_begin() {
        return uid_begin;
    }

    public void setUid_begin(String uid_begin) {
        this.uid_begin = uid_begin;
    }

    public String getUid_end() {
        return uid_end;
    }

    public void setUid_end(String uid_end) {
        this.uid_end = uid_end;
    }
}
