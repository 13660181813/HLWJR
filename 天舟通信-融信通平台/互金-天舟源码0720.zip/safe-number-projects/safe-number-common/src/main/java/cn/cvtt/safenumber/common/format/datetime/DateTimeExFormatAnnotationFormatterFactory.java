package cn.cvtt.safenumber.common.format.datetime;

import cn.cvtt.safenumber.common.format.annotation.DateTimeExFormat;
import org.jetbrains.annotations.NotNull;
import org.springframework.context.support.EmbeddedValueResolutionSupport;
import org.springframework.format.AnnotationFormatterFactory;
import org.springframework.format.Formatter;
import org.springframework.format.Parser;
import org.springframework.format.Printer;
import org.springframework.util.StringUtils;

import java.util.*;

@SuppressWarnings("WeakerAccess")
public class DateTimeExFormatAnnotationFormatterFactory extends EmbeddedValueResolutionSupport implements AnnotationFormatterFactory<DateTimeExFormat> {
    private static final Set<Class<?>> FIELD_TYPES;

    public DateTimeExFormatAnnotationFormatterFactory() {
    }

    @NotNull
    public Set<Class<?>> getFieldTypes() {
        return FIELD_TYPES;
    }

    @NotNull
    public Printer<?> getPrinter(@NotNull DateTimeExFormat annotation, @NotNull Class<?> fieldType) {
        return this.getFormatter(annotation, fieldType);
    }

    @NotNull
    public Parser<?> getParser(@NotNull DateTimeExFormat annotation, @NotNull Class<?> fieldType) {
        return this.getFormatter(annotation, fieldType);
    }

    protected Formatter<Date> getFormatter(DateTimeExFormat annotation, Class<?> fieldType) {
        DateExFormatter formatter = new DateExFormatter();
        String style = this.resolveEmbeddedValue(annotation.style());
        if (StringUtils.hasLength(style)) {
            formatter.setStylePattern(style);
        }

        formatter.setIso(annotation.iso());
        String pattern = this.resolveEmbeddedValue(annotation.pattern());
        if (StringUtils.hasLength(pattern)) {
            formatter.setPattern(pattern);
        }

        return formatter;
    }

    static {
        @SuppressWarnings("unchecked")
        Set<Class<?>> fieldTypes = new HashSet(4);
        fieldTypes.add(Date.class);
        fieldTypes.add(Calendar.class);
        fieldTypes.add(Long.class);
        FIELD_TYPES = Collections.unmodifiableSet(fieldTypes);
    }
}
