package cn.cvtt.safenumber.common.exception;

@SuppressWarnings({"CanBeFinal", "SameParameterValue"})
public enum SecureValidExceptionEnum {

    ERR_ID_DISABLE (102,"Secure valid error","unit-disable","账户不可用"),
    ERR_ID (101,"Parameter error","id-error","id错误"),
    ERR_KEY (101,"Parameter error","key-error","key错误"),
    ERR_SIGN (101,"Parameter error","sign-error","签名错误");

    private Integer code;
    private String message;
    private String subCode;
    private String subMessage;

    SecureValidExceptionEnum(Integer code, String message, String subCode, String subMessage) {
        this.code = code;
        this.message = message;
        this.subCode = subCode;
        this.subMessage = subMessage;
    }

    public Integer getCode() {
        return code;
    }

    public String getMessage() {
        return message;
    }

    public String getSubCode() {
        return subCode;
    }

    public String getSubMessage() {
        return subMessage;
    }
}
