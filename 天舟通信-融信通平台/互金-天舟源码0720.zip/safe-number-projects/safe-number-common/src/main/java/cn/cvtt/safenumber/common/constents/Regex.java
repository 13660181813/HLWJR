package cn.cvtt.safenumber.common.constents;


import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * Created by sujin on 2017/6/20.
 */
@Component
public class Regex {

    @Value("${regex.phone.fixed}")
    public String PHONE_FIXED;
    @Value("${regex.phone.mobile}")
    public String PHONE_MOBILE;
    @Value("${regex.phone.mobile.yd}")
    public String MOBILE_YD;
    @Value("${regex.phone.mobile.lt}")
    public String MOBILE_LT;
    @Value("${regex.phone.mobile.dx}")
    public String MOBILE_DX;
}
