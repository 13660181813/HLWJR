package cn.cvtt.safenumber.common.model.pojo;

import java.util.Date;

/**
 * @author hushuai
 * @Description TODO
 * @date 2019/8/29
 */
public class UnitReserved {
    /**
     * 单位名称
     */
    private String unit_name;
    /**
     * 单位手机
     */
    private String unit_mobile;
    /**
     * 单位电话
     */
    private String unit_telephone;
    /**
     * 单位联系人
     */
    private String unit_contact;
    /**
     * 单位地址
     */
    private String unit_address;
    /**
     * 创建时间
     */
    private Date add_time;

    public String getUnit_name() {
        return unit_name;
    }

    public void setUnit_name(String unit_name) {
        this.unit_name = unit_name;
    }

    public String getUnit_mobile() {
        return unit_mobile;
    }

    public void setUnit_mobile(String unit_mobile) {
        this.unit_mobile = unit_mobile;
    }

    public String getUnit_telephone() {
        return unit_telephone;
    }

    public void setUnit_telephone(String unit_telephone) {
        this.unit_telephone = unit_telephone;
    }

    public String getUnit_contact() {
        return unit_contact;
    }

    public void setUnit_contact(String unit_contact) {
        this.unit_contact = unit_contact;
    }

    public String getUnit_address() {
        return unit_address;
    }

    public void setUnit_address(String unit_address) {
        this.unit_address = unit_address;
    }

    public Date getAdd_time() {
        return add_time;
    }

    public void setAdd_time(Date add_time) {
        this.add_time = add_time;
    }
}
