package cn.cvtt.safenumber.common.service;

import org.apache.commons.lang.StringUtils;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

/**
 *  todo:加入异常处理
 */
@Service
public class SnUidService {

    private static final String CACHE_NAME_UID = ":SnUid:";

    /** */
    @Resource
    private StringRedisTemplate stringRedisTemplate;

    /**
     * 加入一个uid
     * @param unit_id   unit_id
     * @param type      type
     * @param uid       uid
     * @return          成功数量
     */
    public Long add(String unit_id, Byte type, String uid) {
        String key = unit_id + CACHE_NAME_UID + type.toString();

        return stringRedisTemplate.opsForSet().add(key, uid);
    }

    /**
     * 批量加入uid(单次最大10万)
     * @param unit_id   unit_id
     * @param type      type
     * @param uid_begin uid_begin
     * @param uid_end   uid_end
     * @return          成功数量
     */
    public Long add(String unit_id, Byte type, String uid_begin, String uid_end) {

        String key = unit_id + CACHE_NAME_UID + type.toString();

        Long uid_begin_key = Long.parseLong("1" + uid_begin);
        Long uid_end_key = Long.parseLong("1" + uid_end);

        if (uid_end_key - uid_begin_key > 99999 || uid_end_key - uid_begin_key < 0)
            return -1L;

        List<String> uids = new ArrayList<>();
        for (Long uid = uid_begin_key; uid <= uid_end_key; uid++ ) {
            uids.add(uid.toString().replaceFirst("1",""));
        }

        return stringRedisTemplate.opsForSet().add(key, uids.toArray(new String[0]));
    }

    public Long add(String unit_id, Byte type, String... uids) {
        String key = unit_id + CACHE_NAME_UID + type;
        return stringRedisTemplate.opsForSet().add(key, uids);
    }
    
    /** */
    @Nullable
    public String pop(String unit_id, Byte type, String uid) {
        String key = unit_id + CACHE_NAME_UID + type.toString();

        if (StringUtils.isBlank(uid)) {
            return stringRedisTemplate.opsForSet().pop(key);
        } else {
            if(Long.valueOf(1L).equals(stringRedisTemplate.opsForSet().remove(key, uid))) {
                return uid;
            }
            return null;
        }
    }

    public Long count(String unit_id, Byte type) {
        String key = unit_id + CACHE_NAME_UID + type.toString();

        return stringRedisTemplate.opsForSet().size(key);
    }
}
