package cn.cvtt.safenumber.common.service;

import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.data.redis.core.script.DefaultRedisScript;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Collections;
import java.util.Date;
import java.util.List;

/**
 * 利用redis实现的延迟队列，存储需要在一定时间回收的uid
 */
@Service
public class SnUidReserveQueueService {

    private static final String CACHE_SN_UID_RESERVE_QUEUE = "SnUidReserveQueue:";

    @Resource
    private StringRedisTemplate stringRedisTemplate;

    @Resource
    private DefaultRedisScript<List> zrangebyscore_and_zrem;

    /**
     * 加入等待回收队列
     * @param unit_id       unit_id
     * @param type          uid type
     * @param uid           uid
     * @param expire_time   expire_time
     * @return  是否成功
     */
    public Boolean add(String unit_id, Byte type, String uid, long expire_time) {
        String key = CACHE_SN_UID_RESERVE_QUEUE + unit_id + ":" + type;
        return stringRedisTemplate.opsForZSet().add(key, uid, expire_time);
    }

    /**
     * 从队列中删除
     * @param unit_id   unit_id
     * @param type      uid type
     * @param uid       uid
     * @return  删除数量
     */
    public Long del(String unit_id, Byte type, String uid) {
        String key = CACHE_SN_UID_RESERVE_QUEUE + unit_id + ":" + type;
        return stringRedisTemplate.opsForZSet().remove(key, uid);
    }

    /**
     * 取出已到时间的uid
     * @param unit_id   unit_id
     * @param type      uid type
     * @param limit     单次取出的数量
     * @return  uid列表
     */
    public List getAndRemove(String unit_id, Byte type, long limit) {
        String key = CACHE_SN_UID_RESERVE_QUEUE + unit_id + ":" + type;
        return stringRedisTemplate.execute(zrangebyscore_and_zrem, Collections.singletonList(key), "-inf", String.valueOf(new Date().getTime()), String.valueOf(limit));
    }

    public List getAndRemove(String unit_id, Byte type, String max, long limit) {
        String key = CACHE_SN_UID_RESERVE_QUEUE + unit_id + ":" + type;
        return stringRedisTemplate.execute(zrangebyscore_and_zrem, Collections.singletonList(key), "-inf", max, String.valueOf(limit));
    }

    public Long count(String unit_id, Byte type) {
        String key = CACHE_SN_UID_RESERVE_QUEUE + unit_id + ":" + type;

        return stringRedisTemplate.opsForZSet().size(key);
    }
}
