package cn.cvtt.safenumber.common.pojo;

import cn.cvtt.safenumber.common.model.SnUser;
import com.alibaba.fastjson.annotation.JSONField;

import java.util.Date;

public class SnUserServiceLog {
    @JSONField(ordinal = 0)
    private String msg_id;

    @JSONField(ordinal = 1)
    private String unit_id;

    @JSONField(ordinal = 2)
    private String op_module;

    @JSONField(ordinal = 3)
    private String op_user;

    @JSONField(ordinal = 4)
    private String op_type;

    @JSONField(ordinal = 5)
    private Date op_time;

    @JSONField(ordinal = 6)
    private String op_ip;

    @JSONField(ordinal = 7)
    private SnUser snUser;

    public SnUserServiceLog(String msg_id, String unit_id, String op_module, String op_user, String op_type, Date op_time, String op_ip, SnUser snUser) {
        this.msg_id = msg_id;
        this.unit_id = unit_id;
        this.op_module = op_module;
        this.op_user = op_user;
        this.op_type = op_type;
        this.op_time = op_time;
        this.op_ip = op_ip;
        this.snUser = snUser;
    }

    public String getMsg_id() {
        return msg_id;
    }

    public String getUnit_id() {
        return unit_id;
    }

    public String getOp_module() {
        return op_module;
    }

    public String getOp_user() {
        return op_user;
    }

    public String getOp_type() {
        return op_type;
    }

    public Date getOp_time() {
        return op_time;
    }

    public String getOp_ip() {
        return op_ip;
    }

    public SnUser getSnUser() {
        return snUser;
    }
}
