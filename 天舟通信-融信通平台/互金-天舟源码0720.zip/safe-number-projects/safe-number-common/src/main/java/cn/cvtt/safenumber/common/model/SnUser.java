package cn.cvtt.safenumber.common.model;

import cn.cvtt.safenumber.common.model.pojo.CallSettings;
import cn.cvtt.safenumber.common.util.SnSubIdUtils;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.annotation.JSONField;
import org.apache.ignite.cache.query.annotations.QuerySqlField;

import java.sql.Timestamp;

/**
 *
 */
@SuppressWarnings("CanBeFinal")
public class SnUser {
    @JSONField(ordinal = 2)
    @QuerySqlField
    private String sub_id;  // 必须使用SnSubIdUtils来生成或解析此字段。这样做的原因是让sub_id和SnUserKey有了对应关系，不必再为sub_id设置索引，同时让SnUser中间接包含了SnUserKey,方便使用

    @JSONField(ordinal = 3)
    @QuerySqlField
    private Byte product_type;

    @JSONField(ordinal = 4)
    @QuerySqlField
    private Byte uid_type;

    @JSONField(ordinal = 5)
    @QuerySqlField
    private Timestamp reg_time;

    @JSONField(ordinal = 6)
    @QuerySqlField(index = true)
    private Timestamp expire_time;

    @JSONField(ordinal = 7)
    @QuerySqlField
    private Byte call_restrict;

    @JSONField(ordinal = 8)
    @QuerySqlField
    private String settings;

    @JSONField(ordinal = 9)
    @QuerySqlField
    private String contacts;

    @JSONField(ordinal = 10)
    @QuerySqlField(index = true)
    private String uuid_in_partner;

    @QuerySqlField
    @JSONField(ordinal = 11)
    private String reserved;

    @JSONField(serialize = false)
    public CallSettings getCallSettingsObject() {
        CallSettings callSettings = JSON.parseObject(settings, CallSettings.class);
        callSettings.setCall_restrict(call_restrict);
        return callSettings;
    }

    // Constructor

    /*public SnUser(String reg_phone, String uid, Byte product_type, Byte uid_type, Timestamp reg_time, Timestamp expire_time, Byte call_restrict, String settings, String contacts, String uuid_in_partner, String reserved) {
        this.sub_id = SnSubIdUtils.genSubId(new SnUserKey(reg_phone, uid));
        this.product_type = product_type;
        this.uid_type = uid_type;
        this.reg_time = reg_time;
        this.expire_time = expire_time;
        this.call_restrict = call_restrict;
        this.settings = settings;
        this.contacts = contacts;
        this.uuid_in_partner = uuid_in_partner;
        this.reserved = reserved;
    }*/

    public SnUser(String sub_id, Byte product_type, Byte uid_type, Timestamp reg_time, Timestamp expire_time, Byte call_restrict, String settings, String contacts, String uuid_in_partner, String reserved) {
        this.sub_id = sub_id;
        this.product_type = product_type;
        this.uid_type = uid_type;
        this.reg_time = reg_time;
        this.expire_time = expire_time;
        this.call_restrict = call_restrict;
        this.settings = settings;
        this.contacts = contacts;
        this.uuid_in_partner = uuid_in_partner;
        this.reserved = reserved;
    }

    // Getter

    @JSONField(ordinal = 0)
    public String getReg_phone() {
        return SnSubIdUtils.parseSubId(sub_id).getReg_phone();
    }

    @JSONField(ordinal = 1)
    public String getUid () {
        return SnSubIdUtils.parseSubId(sub_id).getUid();
    }

    public String getSub_id() {
        return sub_id;
    }

    public Byte getProduct_type() {
        return product_type;
    }

    public Byte getUid_type() {
        return uid_type;
    }

    public Timestamp getReg_time() {
        return reg_time;
    }

    public Timestamp getExpire_time() {
        return expire_time;
    }

    public Byte getCall_restrict() {
        return call_restrict;
    }

    public String getSettings() {
        return settings;
    }

    public String getContacts() {
        return contacts;
    }

    public String getUuid_in_partner() {
        return uuid_in_partner;
    }

    public String getReserved() {
        return reserved;
    }

    public void setSub_id(String sub_id) {
        this.sub_id = sub_id;
    }

    public void setProduct_type(Byte product_type) {
        this.product_type = product_type;
    }

    public void setUid_type(Byte uid_type) {
        this.uid_type = uid_type;
    }

    public void setReg_time(Timestamp reg_time) {
        this.reg_time = reg_time;
    }

    public void setExpire_time(Timestamp expire_time) {
        this.expire_time = expire_time;
    }

    public void setCall_restrict(Byte call_restrict) {
        this.call_restrict = call_restrict;
    }

    public void setSettings(String settings) {
        this.settings = settings;
    }

    public void setContacts(String contacts) {
        this.contacts = contacts;
    }

    public void setUuid_in_partner(String uuid_in_partner) {
        this.uuid_in_partner = uuid_in_partner;
    }

    public void setReserved(String reserved) {
        this.reserved = reserved;
    }
}
