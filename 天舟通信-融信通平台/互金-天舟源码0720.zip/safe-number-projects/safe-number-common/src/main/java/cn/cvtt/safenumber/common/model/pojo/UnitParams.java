package cn.cvtt.safenumber.common.model.pojo;

public class UnitParams {

    // 号码有效期（天）
    private Integer expire_time;

    // 号码注销后保留期（天）
    private Integer reserve_time;

    public Integer getExpire_time() {
        return expire_time;
    }

    public void setExpire_time(Integer expire_time) {
        this.expire_time = expire_time;
    }

    public Integer getReserve_time() {
        return reserve_time;
    }

    public void setReserve_time(Integer reserve_time) {
        this.reserve_time = reserve_time;
    }
}
