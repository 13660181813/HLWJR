package cn.cvtt.safenumber.common.service;

import cn.cvtt.safenumber.common.constents.Regex;
import com.alibaba.fastjson.JSONObject;
import org.apache.commons.lang.StringUtils;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import javax.validation.constraints.NotNull;

@Service
public class DeadZoneService {

    @Resource
    private Regex regex;

    @Resource
    private StringRedisTemplate stringRedisTemplate;

    public boolean isDeadZone(@NotNull String phone) {

        if (phone.length() < 8) return true;    // 错误号码直接当做盲区号码

        String zoneInfo = "";
        if (phone.startsWith("0")) { // 固话
            for (int areaCodeLen = 3; areaCodeLen <= 4; areaCodeLen++) {
                String areaCode = phone.substring(0, areaCodeLen);
                String areaInfo = stringRedisTemplate.opsForValue().get("AreaCode:" + areaCode);
                if (StringUtils.isNotBlank(areaInfo)) {
                    zoneInfo = areaCode + "GH";
                    break;
                }
            }
        } else { // 手机
            String areaInfo = stringRedisTemplate.opsForValue().get("HLRCode:" + phone.substring(0, 7));
            if (StringUtils.isNotBlank(areaInfo)) {
                JSONObject areaInfoJson = JSONObject.parseObject(areaInfo);
                String areaCode = areaInfoJson.getString("areacode");
                if (StringUtils.isNotBlank(areaCode)) {
                    if (phone.matches(regex.MOBILE_YD))
                        zoneInfo = areaCode + "YD";
                    else if (phone.matches(regex.MOBILE_LT))
                        zoneInfo = areaCode + "LT";
                    else if (phone.matches(regex.MOBILE_DX))
                        zoneInfo = areaCode + "DX";
                }
            }
        }
        //noinspection ConstantConditions
        return stringRedisTemplate.opsForSet().isMember("deadzone", zoneInfo);
    }
}
