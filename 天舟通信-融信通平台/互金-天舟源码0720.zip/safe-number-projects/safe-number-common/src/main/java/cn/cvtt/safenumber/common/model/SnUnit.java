package cn.cvtt.safenumber.common.model;

import cn.cvtt.safenumber.common.model.pojo.CallSettings;
import cn.cvtt.safenumber.common.model.pojo.UnitParams;
import cn.cvtt.safenumber.common.model.pojo.UnitReserved;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.annotation.JSONField;
import org.apache.ignite.cache.query.annotations.QuerySqlField;

@SuppressWarnings("CanBeFinal")
public class SnUnit {

    @QuerySqlField
    private String platform_key;

    @QuerySqlField
    private String secret;

    @QuerySqlField
    private String params;          //pojo UnitParams对应的json串

    @QuerySqlField
    private String callSettings;    //pojo CallSettings对应的json串

    @QuerySqlField(index = true)
    private Byte type;

    @QuerySqlField
    private Byte state;

    @QuerySqlField
    private String reserved;

    @JSONField(serialize = false)
    public UnitParams getParamsObject() {
        try {
            return JSON.parseObject(this.params).toJavaObject(UnitParams.class);
        } catch (Exception e) {
            return new UnitParams();
        }
    }

    @JSONField(serialize = false)
    public UnitReserved getReservedObject() {
        try {
            return JSON.parseObject(this.reserved).toJavaObject(UnitReserved.class);
        } catch (Exception e) {
            return new UnitReserved();
        }
    }

    public CallSettings getCallSettings(String key) {

        CallSettings callSettings;

        try {
            callSettings = JSON.parseObject(this.callSettings).getJSONObject(key).toJavaObject(CallSettings.class);
        } catch (Exception e) {
            callSettings = new CallSettings();
        }
        if (callSettings.getCall_restrict() == null)
            callSettings.setCall_restrict((byte)0);
        if (callSettings.getCall_display() == null)
            callSettings.setCall_display("0,0");
        if (callSettings.getCall_recording() == null)
            callSettings.setCall_recording((byte)0);
        if (callSettings.getAnucode_aleg() == null)
            callSettings.setAnucode_aleg("0,0,0");
        if (callSettings.getAnucode_bleg() == null)
            callSettings.setAnucode_bleg("0,0,0");

        return callSettings;
    }

    // Constructor

    public SnUnit(String platform_key, String secret, String params, String callSettings, Byte type, Byte state, String reserved) {
        this.platform_key = platform_key;
        this.secret = secret;
        this.params = params;
        this.callSettings = callSettings;
        this.type = type;
        this.state = state;
        this.reserved = reserved;
    }

    // Getter and Setter

    public String getPlatform_key() {
        return platform_key;
    }

    public String getSecret() {
        return secret;
    }

    public String getParams() {
        return params;
    }

    public String getCallSettings() {
        return callSettings;
    }

    public Byte getType() {
        return type;
    }

    public Byte getState() {
        return state;
    }

    public String getReserved() {
        return reserved;
    }
}
