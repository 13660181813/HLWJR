package cn.cvtt.safenumber.common.vo;

import cn.cvtt.safenumber.common.validation.constraints.PhoneConstraint;

import javax.validation.constraints.Max;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

public class SnUserUnregisterVo extends CommonVo {

    @PhoneConstraint
    private String reg_phone;

    @Pattern(regexp = "^95013\\d{0,12}$")
    private String uid;

    @Size(max = 64)
    private String uuid_in_partner = "";

    @Size(max = 64)
    private String sub_id;

    @Max(1)
    private Byte cancel_passport;

    public String getReg_phone() {
        return reg_phone;
    }

    public void setReg_phone(String reg_phone) {
        this.reg_phone = reg_phone;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getUuid_in_partner() {
        return uuid_in_partner;
    }

    public void setUuid_in_partner(String uuid_in_partner) {
        this.uuid_in_partner = uuid_in_partner;
    }

    public String getSub_id() {
        return sub_id;
    }

    public void setSub_id(String sub_id) {
        this.sub_id = sub_id;
    }

    public Byte getCancel_passport() {
        return cancel_passport;
    }

    public void setCancel_passport(Byte cancel_passport) {
        this.cancel_passport = cancel_passport;
    }
}
