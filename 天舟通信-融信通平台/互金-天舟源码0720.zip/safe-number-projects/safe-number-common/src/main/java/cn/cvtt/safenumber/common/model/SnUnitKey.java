package cn.cvtt.safenumber.common.model;

import com.alibaba.fastjson.JSON;
import org.apache.ignite.cache.query.annotations.QuerySqlField;

@SuppressWarnings("CanBeFinal")
public class SnUnitKey {

    @QuerySqlField
    private String unit_id;

    public SnUnitKey(String unit_id) {
        this.unit_id = unit_id;
    }

    public String getUnit_id() {
        return unit_id;
    }

    @Override
    public String toString() {
        return JSON.toJSONString(this);
    }
}
