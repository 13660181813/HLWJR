package cn.cvtt.safenumber.common.validation;

import cn.cvtt.safenumber.common.validation.constraints.PhoneConstraint;
import cn.cvtt.safenumber.common.constents.Regex;
import org.apache.commons.lang.StringUtils;

import javax.annotation.Resource;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

/**
 * 检验电话号码的validator
 * 注:通过Pattern注解可以实现本功能，但正则要求是常量，考虑到号段变化的可能，所以新增本validator和对应的注解PhoneConstraint
 */
public class PhoneConstraintValidator implements ConstraintValidator<PhoneConstraint, Object> {

    @Resource
    private Regex regex;

    @Override
    public void initialize(PhoneConstraint constraintAnnotation) {

    }

    @Override
    public boolean isValid(Object value, ConstraintValidatorContext context) {

        // 为空或匹配正则均视为有效，这样可配合NotEmpty等注解来限制是否必填
        return StringUtils.isEmpty((String) value)
                || (((String) value).matches(regex.PHONE_FIXED) || ((String) value).matches(regex.PHONE_MOBILE));
    }

}