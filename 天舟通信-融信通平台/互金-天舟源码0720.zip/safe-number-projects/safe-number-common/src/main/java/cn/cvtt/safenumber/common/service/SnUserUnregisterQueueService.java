package cn.cvtt.safenumber.common.service;

import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.data.redis.core.script.DefaultRedisScript;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Collections;
import java.util.Date;
import java.util.List;

/**
 * 利用redis实现的延迟队列，存储需要在一定时间注销的sub_id
 */
@Service
public class SnUserUnregisterQueueService {

    private static final String CACHE_SN_USER_UNREGISTER_QUEUE = "SnUserUnregisterQueue:";

    @Resource
    private StringRedisTemplate stringRedisTemplate;

    @Resource
    private DefaultRedisScript<List> zrangebyscore_and_zrem;

    /**
     * 加入注销队列
     * @param unit_id   unit_id
     * @param type      uid type
     * @param sub_id        待注销的sub_id
     * @param expire_time   long型的过期时间(作为zset的score)
     * @return  是否加入成功
     */
    public Boolean add(String unit_id, Byte type, String sub_id, long expire_time) {
        String key = CACHE_SN_USER_UNREGISTER_QUEUE + unit_id + ":" + type;
        return stringRedisTemplate.opsForZSet().add(key, sub_id, expire_time);
    }

    /**
     * 从队列中删除
     * @param unit_id   unit_id
     * @param type      uid type
     * @param sub_id        sub_id
     * @return  删除的记录数
     */
    public Long del(String unit_id, Byte type, String sub_id) {
        String key = CACHE_SN_USER_UNREGISTER_QUEUE + unit_id + ":" + type;
        return stringRedisTemplate.opsForZSet().remove(key, sub_id);
    }

    /**
     * 取出已到过期时间的sub_id
     * @param unit_id   unit_id
     * @param type      uid type
     * @param limit 单次取出的数量
     * @return  sub_id列表
     */
    public List getAndRemove(String unit_id, Byte type, long limit) {
        String key = CACHE_SN_USER_UNREGISTER_QUEUE + unit_id + ":" + type;
        return stringRedisTemplate.execute(zrangebyscore_and_zrem, Collections.singletonList(key), "-inf", String.valueOf(new Date().getTime()), String.valueOf(limit));
    }

    public List getAndRemove(String unit_id, Byte type, String max, long limit) {
        String key = CACHE_SN_USER_UNREGISTER_QUEUE + unit_id + ":" + type;
        return stringRedisTemplate.execute(zrangebyscore_and_zrem, Collections.singletonList(key), "-inf", max, String.valueOf(limit));
    }

    public Long count(String unit_id, Byte type) {
        String key = CACHE_SN_USER_UNREGISTER_QUEUE + unit_id + ":" + type;

        return stringRedisTemplate.opsForZSet().size(key);
    }
}
