package cn.cvtt.safenumber.common.model;

import org.apache.ignite.cache.query.annotations.QuerySqlField;

/**
 * 最后一次通话记录的key
 * 只有呼叫类型是XA（NXA/BXA）时才记录，双呼时也是只有当能当做XA时才记录
 * callee:      b路被叫（对应A）
 * displaycode: b路主叫（可能是X，（动态）统一来显）
 */
@SuppressWarnings("CanBeFinal")
public class SnLastCallKey {

    @QuerySqlField(index = true)
    private String callee;

    @QuerySqlField
    private String display_code;

    public SnLastCallKey(String callee, String display_code) {
        this.callee = callee;
        this.display_code = display_code;
    }

    public String getCallee() {
        return callee;
    }

    public String getDisplay_code() {
        return display_code;
    }
}
