package cn.cvtt.safenumber.common.vo;

import cn.cvtt.safenumber.common.format.annotation.DateTimeExFormat;
import cn.cvtt.safenumber.common.util.DateEx;
import cn.cvtt.safenumber.common.validation.constraints.PhoneConstraint;
import org.springframework.format.annotation.DateTimeFormat;

import javax.validation.constraints.*;
import java.util.Date;

public class SnUserRegisterVo extends CommonVo {

    @NotEmpty
    @PhoneConstraint
    private String reg_phone;

    @Pattern(regexp = "^95013\\d{0,12}$", message = "不是有效的安全号码")
    private String uid;

    @Future
    @DateTimeExFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private DateEx expire_time;

    @Min(0)
    @Max(1)
    private Byte product_type = 0;

    @Min(0)
    @Max(1)
    @NotNull(message = "为必填参数")
    private Byte uid_type;

    @Min(0)
    @Max(6)
    private Byte call_restrict = 0;

    @Size(max = 256)
    private String settings = "{}";

    @Size(max = 256)
    private String contacts = "";

    @Size(max = 64)
    private String uuid_in_partner = "";

    // reg_time不从http request中获取，需要在controller中手工赋值
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date reg_time;

    // Getter and Setter

    public String getReg_phone() {
        return reg_phone;
    }

    public void setReg_phone(String reg_phone) {
        this.reg_phone = reg_phone;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public DateEx getExpire_time() {
        return expire_time;
    }

    public void setExpire_time(DateEx expire_time) {
        this.expire_time = expire_time;
    }

    public Byte getProduct_type() {
        return product_type;
    }

    public void setProduct_type(Byte product_type) {
        this.product_type = product_type;
    }

    public Byte getUid_type() {
        return uid_type;
    }

    public void setUid_type(Byte uid_type) {
        this.uid_type = uid_type;
    }

    public Byte getCall_restrict() {
        return call_restrict;
    }

    public void setCall_restrict(Byte call_restrict) {
        this.call_restrict = call_restrict;
    }

    public String getSettings() {
        return settings;
    }

    public void setSettings(String settings) {
        this.settings = settings;
    }

    public String getContacts() {
        return contacts;
    }

    public void setContacts(String contacts) {
        this.contacts = contacts;
    }

    public String getUuid_in_partner() {
        return uuid_in_partner;
    }

    public void setUuid_in_partner(String uuid_in_partner) {
        this.uuid_in_partner = uuid_in_partner;
    }

    public Date getReg_time() {
        return reg_time;
    }

    public void setReg_time(Date reg_time) {
        this.reg_time = reg_time;
    }
}
