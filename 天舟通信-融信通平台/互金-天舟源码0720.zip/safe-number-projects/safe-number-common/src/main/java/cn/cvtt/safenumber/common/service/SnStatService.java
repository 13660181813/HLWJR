package cn.cvtt.safenumber.common.service;

import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

/**
 * 维护实时统计数据的服务
 */
@Service
public class SnStatService {

    private static final String CACHE_SNSTAT_TOTALUSER = ":SnStat:TotalUser:";

    @Resource
    private StringRedisTemplate stringRedisTemplate;

    /**
     * 增加注册用户数（注意，这个数据包括已过期但未注销的数量）
     * @param unit_id   unit_id
     * @param type      uid type
     * @param delta     增加数量
     * @return          增加后的值
     */
    public Long incrTotalUser(String unit_id, Byte type, long delta) {

        String key = unit_id + CACHE_SNSTAT_TOTALUSER + type.toString();

        return stringRedisTemplate.opsForValue().increment(key, delta);
    }

    /**
     * 减少注册用户数（注意，这个数据包括已过期但未注销的数量）
     * @param unit_id   unit_id
     * @param type      uid type
     * @param delta     减少的数量
     * @return          减少后的值
     */
    public Long decrTotalUser(String unit_id, Byte type, long delta) {

        String key = unit_id + CACHE_SNSTAT_TOTALUSER + type.toString();

        return stringRedisTemplate.opsForValue().decrement(key, delta);
    }

}
