package cn.cvtt.safenumber.common.config;

import io.lettuce.core.ClientOptions;
import io.lettuce.core.cluster.ClusterClientOptions;
import io.lettuce.core.cluster.ClusterTopologyRefreshOptions;
import org.apache.commons.lang.StringUtils;
import org.springframework.boot.autoconfigure.data.redis.RedisProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.connection.ReactiveRedisConnectionFactory;
import org.springframework.data.redis.connection.RedisClusterConfiguration;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.connection.RedisStandaloneConfiguration;
import org.springframework.data.redis.connection.lettuce.LettuceClientConfiguration;
import org.springframework.data.redis.connection.lettuce.LettuceConnectionFactory;
import org.springframework.util.Assert;

import javax.annotation.Resource;
import java.time.Duration;

@Configuration
public class RedisLettuceConfig {
    /** */
    @Resource
    private RedisProperties redisProperties;

    /** */
    @Bean
    public RedisConnectionFactory redisConnectionFactory() {

        // 如果设置了cluster则配置为cluster
        if (redisProperties.getCluster() != null) {
            // 设置server参数
            Assert.isTrue(null != redisProperties.getCluster().getNodes(), "spring.redis.cluster.nodes must be set");
            RedisClusterConfiguration serverConfig = new RedisClusterConfiguration(redisProperties.getCluster().getNodes());
            if (null != redisProperties.getCluster().getMaxRedirects() && redisProperties.getCluster().getMaxRedirects() > 0)
                serverConfig.setMaxRedirects(redisProperties.getCluster().getMaxRedirects());
            if (!StringUtils.isEmpty(redisProperties.getPassword()))
                serverConfig.setPassword(redisProperties.getPassword());

            // 设置client参数
            //设置周期性拓扑图更新
            //ClusterTopologyRefreshOptions topologyRefreshOptions = ClusterTopologyRefreshOptions.builder()
            //        .enablePeriodicRefresh(Duration.ofSeconds(30))
            //        .enableAllAdaptiveRefreshTriggers()
            //        .build();
            //设置自适应拓扑图更新操作
            ClusterTopologyRefreshOptions topologyRefreshOptions = ClusterTopologyRefreshOptions.builder()
                    .enableAdaptiveRefreshTrigger(ClusterTopologyRefreshOptions.RefreshTrigger.MOVED_REDIRECT, ClusterTopologyRefreshOptions.RefreshTrigger.PERSISTENT_RECONNECTS)
                    .adaptiveRefreshTriggersTimeout(Duration.ofSeconds(30))
                    .build();
            ClientOptions clientOptions = ClusterClientOptions.builder()
                    .topologyRefreshOptions(topologyRefreshOptions)
                    .build();
            //设置ClientResources
            /*ClientResources clientResources = DefaultClientResources.create();
            //设置事件处理
            clientResources.eventBus().get().subscribe( e -> {
                if ( null != e ) {
                    System.out.println(e.toString());
                    // …
                }
            } );*/

            LettuceClientConfiguration clientConfig = LettuceClientConfiguration.builder()
                    //.clientResources(clientResources)
                    .commandTimeout(Duration.ofSeconds(5))
                    .clientOptions(clientOptions).build();

            return new LettuceConnectionFactory(serverConfig,clientConfig);
        }
        // 否则配置为standalone
        else {
            // 设置server参数
            RedisStandaloneConfiguration serverConfig = new RedisStandaloneConfiguration();
            serverConfig.setHostName(redisProperties.getHost());
            serverConfig.setPort(redisProperties.getPort());
            serverConfig.setDatabase(redisProperties.getDatabase());
            serverConfig.setPassword(redisProperties.getPassword());
            // 设置client参数
            LettuceClientConfiguration clientConfig = LettuceClientConfiguration.builder()
                    //.useSsl()
                    .commandTimeout(Duration.ofSeconds(5))
                    .build();

            return new LettuceConnectionFactory(serverConfig, clientConfig);
        }
    }

    /** */
    @Bean
    public ReactiveRedisConnectionFactory reactiveRedisConnectionFactory() {

        // 如果设置了cluster则配置为cluster
        if (redisProperties.getCluster() != null) {
            // 设置server参数
            Assert.isTrue(null != redisProperties.getCluster().getNodes(), "spring.redis.cluster.nodes must be set");
            RedisClusterConfiguration serverConfig = new RedisClusterConfiguration(redisProperties.getCluster().getNodes());
            if (null != redisProperties.getCluster().getMaxRedirects() && redisProperties.getCluster().getMaxRedirects() > 0)
                serverConfig.setMaxRedirects(redisProperties.getCluster().getMaxRedirects());
            if (!StringUtils.isEmpty(redisProperties.getPassword()))
                serverConfig.setPassword(redisProperties.getPassword());

            // 设置client参数
            //设置周期性拓扑图更新
            //ClusterTopologyRefreshOptions topologyRefreshOptions = ClusterTopologyRefreshOptions.builder()
            //        .enablePeriodicRefresh(Duration.ofSeconds(30))
            //        .enableAllAdaptiveRefreshTriggers()
            //        .build();
            //设置自适应拓扑图更新操作
            ClusterTopologyRefreshOptions topologyRefreshOptions = ClusterTopologyRefreshOptions.builder()
                    .enableAdaptiveRefreshTrigger(ClusterTopologyRefreshOptions.RefreshTrigger.MOVED_REDIRECT, ClusterTopologyRefreshOptions.RefreshTrigger.PERSISTENT_RECONNECTS)
                    .adaptiveRefreshTriggersTimeout(Duration.ofSeconds(30))
                    .build();
            ClientOptions clientOptions = ClusterClientOptions.builder()
                    .topologyRefreshOptions(topologyRefreshOptions)
                    .build();
            //设置ClientResources
            /*ClientResources clientResources = DefaultClientResources.create();
            //设置事件处理
            clientResources.eventBus().get().subscribe( e -> {
                if ( null != e ) {
                    System.out.println(e.toString());
                    // …
                }
            } );*/

            LettuceClientConfiguration clientConfig = LettuceClientConfiguration.builder()
                    //.clientResources(clientResources)
                    .commandTimeout(Duration.ofSeconds(5))
                    .clientOptions(clientOptions).build();

            return new LettuceConnectionFactory(serverConfig,clientConfig);
        }
        // 否则配置为standalone
        else {
            // 设置server参数
            RedisStandaloneConfiguration serverConfig = new RedisStandaloneConfiguration();
            serverConfig.setHostName(redisProperties.getHost());
            serverConfig.setPort(redisProperties.getPort());
            serverConfig.setDatabase(redisProperties.getDatabase());
            serverConfig.setPassword(redisProperties.getPassword());
            // 设置client参数
            LettuceClientConfiguration clientConfig = LettuceClientConfiguration.builder()
                    //.useSsl()
                    .commandTimeout(Duration.ofSeconds(5))
                    .build();

            return new LettuceConnectionFactory(serverConfig, clientConfig);
        }
    }
}
