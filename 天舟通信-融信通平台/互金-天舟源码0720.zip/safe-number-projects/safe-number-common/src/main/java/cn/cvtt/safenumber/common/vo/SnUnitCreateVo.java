package cn.cvtt.safenumber.common.vo;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

public class SnUnitCreateVo extends CommonVo{

    @NotBlank
    private String platform_key;

    @NotBlank
    private String secret;

    @NotBlank
    private String params;          //pojo UnitParams对应的json串

    @NotBlank
    private String call_settings;    //pojo CallSettings对应的json串

    @Min(0)
    @Max(2)
    @NotNull
    private Byte type;

    @Min(0)
    @Max(2)
    @NotNull
    private Byte state;

    private String reserved;

    public String getPlatform_key() {
        return platform_key;
    }

    public void setPlatform_key(String platform_key) {
        this.platform_key = platform_key;
    }

    public String getSecret() {
        return secret;
    }

    public void setSecret(String secret) {
        this.secret = secret;
    }

    public String getParams() {
        return params;
    }

    public void setParams(String params) {
        this.params = params;
    }

    public String getCall_settings() {
        return call_settings;
    }

    public void setCall_settings(String call_settings) {
        this.call_settings = call_settings;
    }

    public Byte getType() {
        return type;
    }

    public void setType(Byte type) {
        this.type = type;
    }

    public Byte getState() {
        return state;
    }

    public void setState(Byte state) {
        this.state = state;
    }

    public String getReserved() {
        return reserved;
    }

    public void setReserved(String reserved) {
        this.reserved = reserved;
    }
}
