package cn.cvtt.safenumber.common.config;

import cn.cvtt.safenumber.common.model.*;
import org.apache.ignite.Ignite;
import org.apache.ignite.IgniteCache;
import org.apache.ignite.cache.CacheWriteSynchronizationMode;
import org.apache.ignite.configuration.CacheConfiguration;

import javax.annotation.Resource;
import javax.cache.expiry.Duration;
import javax.cache.expiry.ExpiryPolicy;

import static java.util.concurrent.TimeUnit.DAYS;

@SuppressWarnings("Duplicates")
public class IgniteCacheGetter {

    private static final String CACHE_NAME_SNUSER = ":SnUser";
    private static final String CACHE_NAME_SNUSERCONTACT = ":SnUserContact";
    private static final String CACHE_NAME_SNLASTCALL = ":SnLastCall";

    @Resource
    private Ignite ignite;

    /*
    public <K, V> IgniteCache<K, V> getOrCreateCache(String cacheName, Class<?>... indexedTypes) {
        CacheConfiguration<K, V> cacheCfg = new CacheConfiguration<>(cacheName);
        cacheCfg.setBackups(1);
        cacheCfg.setWriteSynchronizationMode(CacheWriteSynchronizationMode.FULL_SYNC);
        cacheCfg.setIndexedTypes(indexedTypes);   // 不执行本行，按sql查询时会提示找不到表; 且model类(如SnUser)中需用QuerySqlField注解标明sql查询所需字段；同时，此操作只会对刚创建的cache有作用，不会改变已存在cache的属性
        //cacheCfg.setSqlIndexMaxInlineSize(128); //设置了此参数，性能有很大提升，但内存占用也增加很多，还要多调试看看
        return ignite.getOrCreateCache(cacheCfg);//.withExpiryPolicy(new CreatedExpiryPolicy((new Duration(SECONDS,3600))));

    }
    */

    public IgniteCache<SnUserKey, SnUser> getSnUserCache(String unit_id, Long expire) {
        CacheConfiguration<SnUserKey, SnUser> cacheCfg = new CacheConfiguration<>(unit_id + CACHE_NAME_SNUSER);
        cacheCfg.setBackups(1);
        cacheCfg.setWriteSynchronizationMode(CacheWriteSynchronizationMode.FULL_SYNC);
        cacheCfg.setIndexedTypes(SnUserKey.class, SnUser.class);   // 不执行本行，按sql查询时会提示找不到表; 且model类(如SnUser)中需用QuerySqlField注解标明sql查询所需字段；同时，此操作只会对刚创建的cache有作用，不会改变已存在cache的属性
        //cacheCfg.setSqlIndexMaxInlineSize(128); //设置了此参数，性能有很大提升，但内存占用也增加很多，还要多调试看看
        if (expire == null) {
            return ignite.getOrCreateCache(cacheCfg);
        } else {
            return ignite.getOrCreateCache(cacheCfg).withExpiryPolicy(new ExpiryPolicy() {
                @Override
                public Duration getExpiryForCreation() {
                    return new Duration(DAYS, expire);
                }
                @Override
                public Duration getExpiryForAccess() {
                    return null;
                }
                @Override
                public Duration getExpiryForUpdate() {
                    return new Duration(DAYS, expire);
                }
            });
        }
    }

    public IgniteCache<SnUserContactKey, SnUserContact> getSnUserContactCache(String unit_id, Long expire) {
        CacheConfiguration<SnUserContactKey, SnUserContact> cacheCfg = new CacheConfiguration<>(unit_id + CACHE_NAME_SNUSERCONTACT);
        cacheCfg.setBackups(1);
        cacheCfg.setWriteSynchronizationMode(CacheWriteSynchronizationMode.FULL_SYNC);
        cacheCfg.setIndexedTypes(SnUserContactKey.class, SnUserContact.class);   // 不执行本行，按sql查询时会提示找不到表; 且model类(如SnUser)中需用QuerySqlField注解标明sql查询所需字段；同时，此操作只会对刚创建的cache有作用，不会改变已存在cache的属性
        if (expire == null) {
            return ignite.getOrCreateCache(cacheCfg);
        } else {
            return ignite.getOrCreateCache(cacheCfg).withExpiryPolicy(new ExpiryPolicy() {
                @Override
                public Duration getExpiryForCreation() {
                    return new Duration(DAYS, expire);
                }
                @Override
                public Duration getExpiryForAccess() {
                    return null;
                }
                @Override
                public Duration getExpiryForUpdate() {
                    return new Duration(DAYS, expire);
                }
            });
        }
    }

    public IgniteCache<SnLastCallKey, SnLastCall> getSnLastCallCache(String unit_id, Long expire) {
        CacheConfiguration<SnLastCallKey, SnLastCall> cacheCfg = new CacheConfiguration<>(unit_id + CACHE_NAME_SNLASTCALL);
        cacheCfg.setBackups(1);
        cacheCfg.setWriteSynchronizationMode(CacheWriteSynchronizationMode.FULL_SYNC);
        cacheCfg.setIndexedTypes(SnLastCallKey.class, SnLastCall.class);   // 不执行本行，按sql查询时会提示找不到表; 且model类(如SnUser)中需用QuerySqlField注解标明sql查询所需字段；同时，此操作只会对刚创建的cache有作用，不会改变已存在cache的属性
        if (expire == null) {
            return ignite.getOrCreateCache(cacheCfg);
        } else {
            return ignite.getOrCreateCache(cacheCfg).withExpiryPolicy(new ExpiryPolicy() {
                @Override
                public Duration getExpiryForCreation() {
                    return new Duration(DAYS, expire);
                }
                @Override
                public Duration getExpiryForAccess() {
                    return null;
                }
                @Override
                public Duration getExpiryForUpdate() {
                    return new Duration(DAYS, expire);
                }
            });
        }
    }
}
