package cn.cvtt.safenumber.common.vo;

import javax.validation.constraints.NotBlank;

public class TwoWayCallVo extends CommonVo {

    @NotBlank
    private String msg_data;

    public String getMsg_data() {
        return msg_data;
    }

    public void setMsg_data(String msg_data) {
        this.msg_data = msg_data;
    }
}
