package cn.cvtt.safenumber.common.service;

import cn.cvtt.safenumber.common.config.IgniteCacheGetter;
import cn.cvtt.safenumber.common.model.SnLastCall;
import cn.cvtt.safenumber.common.model.SnLastCallKey;
import org.apache.ignite.IgniteCache;
import org.apache.ignite.cache.query.SqlFieldsQuery;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

/**
 * 查询说明：
 *  A回拨获取最后一次通话的caller时，根据SnLastCallKey查询（callee为当前呼入的caller，display_code为当前呼入的called）
 *  动态来显需查询上次呼叫的display_code时，根据当前呼入的caller=记录的caller和当前呼入的called=记录的called来查询，没有则新生成
 *  注销时，根据uid=called且reg_phone=callee来查询（当双呼called被置为统一来显时，可能会遗留垃圾数据）
 */
@Service
public class SnLastCallService {

    private static final Long EXPIRE_DAYS = 1L;

    private static final String queryStringByCallerAndCalled = "SELECT CALLEE, DISPLAY_CODE, START_TIME FROM SNLASTCALL WHERE CALLER = ? AND CALLED = ? LIMIT 1";

    @Resource
    private IgniteCacheGetter igniteCacheGetter;

    private SnLastCall getSingle(String unit_id, SnLastCallKey snLastCallKey) {
        IgniteCache<SnLastCallKey, SnLastCall> snLastCallCache = igniteCacheGetter.getSnLastCallCache(unit_id, EXPIRE_DAYS);
        return snLastCallCache.get(snLastCallKey);
    }

    private void addSingle(String unit_id, SnLastCallKey snLastCallKey, SnLastCall snLastCall) {
        IgniteCache<SnLastCallKey, SnLastCall> snLastCallCache = igniteCacheGetter.getSnLastCallCache(unit_id, EXPIRE_DAYS);
        snLastCallCache.put(snLastCallKey, snLastCall);
    }

    public SnLastCall getSingle(String unit_id, String callee, String display_code) {
        return getSingle(unit_id, new SnLastCallKey(callee, display_code));
    }

    public void addSingle(String unit_id, String callee, String display_code, String caller, String called, Date start_time) {
        addSingle(unit_id, new SnLastCallKey(callee, display_code), new SnLastCall(caller, called, new Timestamp(start_time.getTime()), ""));
    }

    public SnLastCallKey getSingleByCallerAndCalled(String unit_id, String caller, String called) {

        IgniteCache<SnLastCallKey, SnLastCall> snLastCallCache = igniteCacheGetter.getSnLastCallCache(unit_id, EXPIRE_DAYS);

        List<List<?>> records = snLastCallCache.query(new SqlFieldsQuery(queryStringByCallerAndCalled).setArgs(caller, called)).getAll();
        if (records != null && records.size() > 0) {
            List<?> row = records.get(0);
            return new SnLastCallKey((String) row.get(0), (String) row.get(1));
        }

        return null;
    }
}
