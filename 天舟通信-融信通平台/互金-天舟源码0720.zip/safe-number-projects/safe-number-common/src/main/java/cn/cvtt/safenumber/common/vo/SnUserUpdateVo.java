package cn.cvtt.safenumber.common.vo;

import cn.cvtt.safenumber.common.format.annotation.DateTimeExFormat;
import cn.cvtt.safenumber.common.util.DateEx;
import cn.cvtt.safenumber.common.validation.constraints.MultiplePhoneConstraint;
import cn.cvtt.safenumber.common.validation.constraints.PhoneConstraint;

import javax.validation.constraints.*;

public class SnUserUpdateVo extends CommonVo {

    @PhoneConstraint
    private String reg_phone;

    @Pattern(regexp = "^95013\\d{0,12}$")
    private String uid;

    @Size(max = 64)
    private String uuid_in_partner;

    @Size(max = 64)
    private String sub_id;

    //@Future //在业务代码中判断是否未来时间，因为在binder中处理相对时间是按当前时间为基准的，而在变更时应该以已有的expire_time为基准，在binder转换时无法获取已有expire_time
    @DateTimeExFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private DateEx expire_time;

    @Min(0)
    @Max(6)
    private Byte call_restrict;

    @Size(max = 256)
    private String settings;

    @Size(max = 256)
    @MultiplePhoneConstraint
    private String contacts;

    public String getReg_phone() {
        return reg_phone;
    }

    public void setReg_phone(String reg_phone) {
        this.reg_phone = reg_phone;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getUuid_in_partner() {
        return uuid_in_partner;
    }

    public void setUuid_in_partner(String uuid_in_partner) {
        this.uuid_in_partner = uuid_in_partner;
    }

    public String getSub_id() {
        return sub_id;
    }

    public void setSub_id(String sub_id) {
        this.sub_id = sub_id;
    }

    public DateEx getExpire_time() {
        return expire_time;
    }

    public void setExpire_time(DateEx expire_time) {
        this.expire_time = expire_time;
    }

    public Byte getCall_restrict() {
        return call_restrict;
    }

    public void setCall_restrict(Byte call_restrict) {
        this.call_restrict = call_restrict;
    }

    public String getSettings() {
        return settings;
    }

    public void setSettings(String settings) {
        this.settings = settings;
    }

    public String getContacts() {
        return contacts;
    }

    public void setContacts(String contacts) {
        this.contacts = contacts;
    }
}
