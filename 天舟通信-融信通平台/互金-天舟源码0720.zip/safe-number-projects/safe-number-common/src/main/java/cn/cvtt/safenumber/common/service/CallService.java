package cn.cvtt.safenumber.common.service;

import cn.cvtt.safenumber.common.constents.Regex;
import cn.cvtt.safenumber.common.model.*;
import cn.cvtt.safenumber.common.exception.BusinessException;
import cn.cvtt.safenumber.common.exception.BusinessExceptionEnum;
import cn.cvtt.safenumber.common.pojo.CallQueryResponse;
import cn.cvtt.safenumber.common.exception.CallException;
import cn.cvtt.safenumber.common.exception.CallExceptionEnum;
import cn.cvtt.safenumber.common.vo.CallQueryVo;
import cn.cvtt.safenumber.common.model.pojo.CallSettings;
import cn.cvtt.safenumber.common.vo.TwoWayCallVo;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import org.apache.commons.lang.StringUtils;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import javax.annotation.Resource;

import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

@SuppressWarnings("Duplicates")
@Service
public class CallService {

    @Resource
    private StringRedisTemplate stringRedisTemplate;

    @Resource
    private SnUidSectService snUidSectService;

    @Resource
    private SnUnitService snUnitService;

    @Resource
    private SnUserService snUserService;

    @Resource
    private SnUserContactService snUserContactService;

    @Resource
    private SnLastCallService snLastCallService;

    /**
     * 根据Unit的CallSettings和User的Settings组合返回CallSettings
     * @param snUnit unit
     * @param snUser user
     * @return 根据Unit的CallSettings和User的Settings组合返回CallSettings
     */
    private CallSettings getCallSettings(SnUnit snUnit, SnUser snUser) {
        CallSettings unitCallSettings = snUser.getUid_type() == 0 ? snUnit.getCallSettings("SCALLSETTINGS") : snUnit.getCallSettings("PCALLSETTINGS");
        CallSettings userCallSettings = snUser.getCallSettingsObject();
        if (userCallSettings.getCall_restrict() != null)
            unitCallSettings.setCall_restrict(userCallSettings.getCall_restrict());
        if (userCallSettings.getCall_display() != null)
            unitCallSettings.setCall_display(userCallSettings.getCall_display());
        if (userCallSettings.getCall_recording() != null)
            unitCallSettings.setCall_recording(userCallSettings.getCall_recording());
        if (userCallSettings.getAnucode_aleg() != null)
            unitCallSettings.setAnucode_aleg(userCallSettings.getAnucode_aleg());
        if (userCallSettings.getAnucode_bleg() != null)
            unitCallSettings.setAnucode_bleg(userCallSettings.getAnucode_bleg());
        return unitCallSettings;
    }

    /**
     * 获取放音编号
     * @param anuCodeSetting   CallSetting中放音编号设置(Anucode_a/bleg)字符串
     * @param mode      0:BX, 1:AX, 2:NX
     * @return  放音编号
     */
    private String getAnuCode(String anuCodeSetting, int mode) {
        if (StringUtils.isNotBlank(anuCodeSetting)) {
            String[] anuCodes = anuCodeSetting.split(",");
            if (anuCodes.length <= mode)
                return "";
            else
                return anuCodes[mode];
        }
        return "";
    }

    /**
     * 获取动态统一来显
     * @param callDisplaySetting    callDisplaySetting
     * @param snUidSect             called(no_x或(动态)统一来显)对应的snUidSect
     * @param caller                caller
     * @param called                called(no_x或(动态)统一来显)
     * @param callee                本次呼叫将要接续的号码
     * @return  动态统一来显
     */
    private String getDynamicDisplayCode(String callDisplaySetting, SnUidSect snUidSect, String caller, String called, String callee) {

        // 如果需要复用上次的display_code
        if ("1".equals(callDisplaySetting)) {
            // 根据caller和called查找上次通话记录
            SnLastCallKey snLastCallKey = snLastCallService.getSingleByCallerAndCalled(snUidSect.getUnit_id(), caller, called);
            if (snLastCallKey != null) {
                return snLastCallKey.getDisplay_code();
            }
        }

        // 如果不需复用或没有历史记录，则通过获取动态来显的偏移量（偏移量记录在redis中）来生成来显
        // 如果callDisplaySetting=5，则偏移量按unit统一设置；否则偏移量细化到手机号
        String suffixOffsetKey = snUidSect.getUnit_id() + ":SnDisplayCode" + ("1".equals(callDisplaySetting) ? ":" + callee : "");

        // 下面的get/set/increment没有进行事务处理，在并发时，会得到脏数据（比如两个线程同时取到Long.MAX_VALUE时，则会有两次赋值为0的set操作，导致后面increment获取的不是预期值）
        // 评估上述问题，应该关系不大，上述并发完成，数据会回归正常
        /*try {
            long suffixOffset = Long.parseLong(stringRedisTemplate.opsForValue().get(suffixOffsetKey));
            if (suffixOffset >= Long.MAX_VALUE || suffixOffset < 0) {
                stringRedisTemplate.opsForValue().set(suffixOffsetKey, "0");
            }
        } catch (Exception e) {
            stringRedisTemplate.opsForValue().set(suffixOffsetKey, "0");
        }*/ //此段代码感觉意义不大，暂时注释掉

        Long suffixOffset = (stringRedisTemplate.opsForValue().increment(suffixOffsetKey) - 1)
                % ( (snUidSect.getUid_count() == 0 || snUidSect.getUid_count() == null ) ? 1 : snUidSect.getUid_count() );

        // 设置过期时间
        stringRedisTemplate.expire(suffixOffsetKey, 1L, TimeUnit.DAYS);

        return String.valueOf(Long.parseLong(snUidSect.getUid_begin()) + Math.abs(suffixOffset));
    }

    /**
     * 获取display_code
     * @param callDisplaySetting called(no_x或(动态)统一来显)对应的callDisplaySetting
     * @param snUidSect          called(no_x或(动态)统一来显)对应的snUidSect
     * @param caller_phone       caller的phone
     * @param caller_uid         caller的uid
     * @param called             called(no_x或(动态)统一来显)
     * @param called_uid         called(no_x或(动态)统一来显)对应的uid，如果called是no_x，则called_uid=called，如果called是(动态)统一来显，则called_uid=caller_uid
     * @param callee             本次呼叫将要接续的号码
     * @return                   display_code
     */
    private String getDisplayCode(String callDisplaySetting, SnUidSect snUidSect, String caller_phone, String caller_uid, String called, String called_uid, String callee) {

        String [] callDisplaySettingArray = callDisplaySetting.split(",");

        if (StringUtils.isNotBlank(caller_uid)) {
            callDisplaySetting = callDisplaySettingArray.length >= 1 ? callDisplaySettingArray[0] : "3";
            if ("4".equals(callDisplaySetting)) {
                callDisplaySetting = "3";
            }
        } else {
            callDisplaySetting = callDisplaySettingArray.length >= 2 ? callDisplaySettingArray[1] : "0";
            if ("3".equals(callDisplaySetting)) {
                callDisplaySetting = "0";
            }
        }

        String displayCode = "";

        switch (callDisplaySetting) {
            case "0":
                displayCode = called_uid;
                break;
            case "2":
                displayCode = caller_phone;
                break;
            case "3":
                displayCode = caller_uid;
                break;
            case "4":
                displayCode = "95013" + caller_phone;
                break;
            case "1":
            case "5":
                if (snUidSect.getUid_type() != 2) {
                    List<SnUidSect> snUidSects = snUidSectService.getUidSectByUnitIdAndType(snUidSect.getUnit_id(), (byte)2);
                    snUidSect = snUidSects.size() <= 0 ? null : snUidSects.get(0);
                }
                if (snUidSect != null) {
                    if (snUidSect.getUid_count() > 1) {
                        displayCode = getDynamicDisplayCode(callDisplaySetting, snUidSect, caller_phone, called, callee);
                    } else {
                        displayCode = snUidSect.getUid_begin();
                    }
                }
                break;
        }

        if (StringUtils.isBlank(displayCode)) {
            if (StringUtils.isNotBlank(called_uid)) {
                displayCode = called_uid;
            } else {
                displayCode = caller_uid;
            }
        }

        return displayCode;
    }

    /**
     * A呼X，转接B
     * @param snUidSect     called（no_x）对应的snUidSect
     * @param snUnit        called（no_x）对应的snUnit
     * @param snUser        called（no_x）对应的snUser
     * @param callQueryVo CallQueryVo
     * @return  CallQueryResponse
     */
    private CallQueryResponse callQueryAXB(SnUidSect snUidSect, SnUnit snUnit, SnUser snUser, CallQueryVo callQueryVo) {
        CallQueryResponse callQueryResponse = new CallQueryResponse();

        CallSettings callSettings = getCallSettings(snUnit, snUser);

        callQueryResponse.setOp_type((byte)1);
        callQueryResponse.setCall_type((byte)0);
        //noinspection LoopStatementThatDoesntLoop
        for (String contact:
                (snUser.getContacts() + ",").split(",")) {
            callQueryResponse.setCallee(contact);
            break;  // 目前只取第一个，直接用snUser.getContacts().split(",")[0]担心出现NullPointerException（比如数据库中contacts写入一个","）
        }
        callQueryResponse.setPlay_code(getAnuCode(callSettings.getAnucode_aleg(),1));
        callQueryResponse.setDisplay_code(
                getDisplayCode(callSettings.getCall_display(), snUidSect, callQueryVo.getCaller(), snUser.getUid(), callQueryVo.getCalled(), callQueryVo.getCalled(), callQueryResponse.getCallee())
                );
        callQueryResponse.setRecord(callSettings.getCall_recording() == 1);
        callQueryResponse.setUnit_id_real(snUidSect.getUnit_id());
        callQueryResponse.setLast_call_time(null);
        callQueryResponse.setSub_id(snUser.getSub_id());
        callQueryResponse.setReg_time(snUser.getReg_time().getTime()/1000);
        callQueryResponse.setUuid_in_partner(snUser.getUuid_in_partner());

        return callQueryResponse;
    }

    /**
     * A呼X,转接上次被叫记录的主叫
     * @param snUidSect     called（no_x）对应的snUidSect
     * @param snUnit        called（no_x）对应的snUnit
     * @param snUser        called（no_x）对应的snUser
     * @param callQueryVo CallQueryVo
     * @param snLastCall    caller(no_a)的上一次被叫记录
     * @return  CallQueryResponse
     */
    private CallQueryResponse callQueryAXLast(SnUidSect snUidSect, SnUnit snUnit, SnUser snUser, CallQueryVo callQueryVo, SnLastCall snLastCall) {

        CallQueryResponse callQueryResponse = new CallQueryResponse();

        CallSettings callSettings = getCallSettings(snUnit, snUser);

        callQueryResponse.setOp_type((byte)1);
        callQueryResponse.setCall_type((byte)0);
        callQueryResponse.setCallee(snLastCall.getCaller());
        callQueryResponse.setPlay_code(getAnuCode(callSettings.getAnucode_aleg(),1));
        callQueryResponse.setDisplay_code(
                getDisplayCode(callSettings.getCall_display(), snUidSect, callQueryVo.getCaller(), snUser.getUid(), callQueryVo.getCalled(), callQueryVo.getCalled(), callQueryResponse.getCallee())
        );
        callQueryResponse.setRecord(callSettings.getCall_recording() == 1);
        callQueryResponse.setUnit_id_real(snUidSect.getUnit_id());
        callQueryResponse.setLast_call_time(null);
        callQueryResponse.setSub_id(snUser.getSub_id());
        callQueryResponse.setReg_time(snUser.getReg_time().getTime()/1000);
        callQueryResponse.setUuid_in_partner(snUser.getUuid_in_partner());

        return callQueryResponse;
    }

    /**
     * A呼（动态）统一来显，转接上次被叫记录的主叫
     * @param snUidSect     called（no_y）对应的snUidSect
     * @param snUnit        called（no_y）对应的snUnit
     * @param snUser        caller（no_a）和snLastCall的called(no_x)对应的snUser
     * @param callQueryVo CallQueryVo
     * @param snLastCall    caller(no_a)的上一次被叫记录
     * @return CallQueryResponse
     */
    private CallQueryResponse callQueryAYLast(SnUidSect snUidSect, SnUnit snUnit, SnUser snUser, CallQueryVo callQueryVo, SnLastCall snLastCall) {

        CallQueryResponse callQueryResponse = new CallQueryResponse();

        // A呼（动态）统一来显时使用unit而不是自己的呼叫设置
        CallSettings callSettings = snUser.getUid_type() == 0 ? snUnit.getCallSettings("SCALLSETTINGS") : snUnit.getCallSettings("PCALLSETTINGS");

        callQueryResponse.setOp_type((byte)1);
        callQueryResponse.setCall_type((byte)0);
        callQueryResponse.setCallee(snLastCall.getCaller());
        callQueryResponse.setPlay_code(getAnuCode(callSettings.getAnucode_aleg(),1));
        callQueryResponse.setDisplay_code(
                getDisplayCode(callSettings.getCall_display(), snUidSect, callQueryVo.getCaller(), snUser.getUid(), callQueryVo.getCalled(), snUser.getUid(), callQueryResponse.getCallee())
        );
        callQueryResponse.setRecord(callSettings.getCall_recording() == 1);
        callQueryResponse.setUnit_id_real(snUidSect.getUnit_id());
        callQueryResponse.setLast_call_time(null);
        callQueryResponse.setSub_id(snUser.getSub_id());
        callQueryResponse.setReg_time(snUser.getReg_time().getTime()/1000);
        callQueryResponse.setUuid_in_partner(snUser.getUuid_in_partner());

        return callQueryResponse;
    }

    /**
     * B呼X，转接A
     * @param snUidSect     called（no_x）对应的snUidSect
     * @param snUnit        called（no_x）对应的snUnit
     * @param snUser        called（no_x）对应的snUser
     * @param callQueryVo CallQueryVo
     * @return CallQueryResponse
     */
    private CallQueryResponse callQueryBXA(SnUidSect snUidSect, SnUnit snUnit, SnUser snUser, CallQueryVo callQueryVo) {

        CallQueryResponse callQueryResponse = new CallQueryResponse();

        CallSettings callSettings = getCallSettings(snUnit, snUser);

        SnUser snUserOfCaller = snUserService.getSingleValidByPhone(snUidSect.getUnit_id(), callQueryVo.getCaller());

        callQueryResponse.setOp_type((byte)1);
        callQueryResponse.setCall_type((byte)1);
        callQueryResponse.setCallee(snUser.getReg_phone());
        callQueryResponse.setPlay_code(getAnuCode(callSettings.getAnucode_aleg(),0));
        callQueryResponse.setDisplay_code(
                getDisplayCode(callSettings.getCall_display(), snUidSect, callQueryVo.getCaller(), snUserOfCaller == null ? "" : snUserOfCaller.getUid(), callQueryVo.getCalled(), callQueryVo.getCalled(), callQueryResponse.getCallee())
        );
        callQueryResponse.setRecord(callSettings.getCall_recording() == 1);
        callQueryResponse.setUnit_id_real(snUidSect.getUnit_id());
        callQueryResponse.setLast_call_time(null);
        callQueryResponse.setSub_id(snUser.getSub_id());
        callQueryResponse.setReg_time(snUser.getReg_time().getTime()/1000);
        callQueryResponse.setUuid_in_partner(snUser.getUuid_in_partner());

        // 不管是否有多个B(contact_phone)，均记录lastcaller
        snLastCallService.addSingle(snUidSect.getUnit_id(),
                callQueryResponse.getCallee(),
                callQueryResponse.getDisplay_code(),
                callQueryVo.getCaller(),
                callQueryVo.getCalled(),
                new Date());

        return callQueryResponse;
    }

    /**
     * N呼X，转接A
     * @param snUidSect     called（no_x）对应的snUidSect
     * @param snUnit        called（no_x）对应的snUnit
     * @param snUser        called（no_x）对应的snUser
     * @param callQueryVo CallQueryVo
     * @return CallQueryResponse
     */
    private CallQueryResponse callQueryNXA(SnUidSect snUidSect, SnUnit snUnit, SnUser snUser, CallQueryVo callQueryVo) {

        CallQueryResponse callQueryResponse = new CallQueryResponse();

        CallSettings callSettings = getCallSettings(snUnit, snUser);

        SnUser snUserOfCaller = null;

        switch (callSettings.getCall_restrict()) {

            case 2: // 主叫为岗位号时允许接续
                if (null == (snUserOfCaller = snUserService.getSingleValidByPhoneAndUidType(snUidSect.getUnit_id(), callQueryVo.getCaller(), (byte)1))) {
                    throw new CallException(CallExceptionEnum.ERR_CALL_RESTRICT, snUidSect.getUnit_id(), (byte)1);
                }
                callQueryResponse.setOp_type((byte)1);
                break;
            case 3: // 主叫为安全号时允许接续
                if (null == (snUserOfCaller = snUserService.getSingleValidByPhoneAndUidType(snUidSect.getUnit_id(), callQueryVo.getCaller(), (byte)0))) {
                    throw new CallException(CallExceptionEnum.ERR_CALL_RESTRICT, snUidSect.getUnit_id(), (byte)1);
                }
                callQueryResponse.setOp_type((byte)1);
                break;
            case 4: // 主叫为安全号或岗位号是均允许接续
                if (null == (snUserOfCaller = snUserService.getSingleValidByPhone(snUidSect.getUnit_id(), callQueryVo.getCaller()))) {
                    throw new CallException(CallExceptionEnum.ERR_CALL_RESTRICT, snUidSect.getUnit_id(), (byte)1);
                }
                callQueryResponse.setOp_type((byte)1);
                break;
            case 0: // 允许接续，不留言
                snUserOfCaller = snUserService.getSingleValidByPhone(snUidSect.getUnit_id(), callQueryVo.getCaller());
                callQueryResponse.setOp_type((byte)1);
                break;
            case 5: // 允许接续，失败转留言
                snUserOfCaller = snUserService.getSingleValidByPhone(snUidSect.getUnit_id(), callQueryVo.getCaller());
                callQueryResponse.setOp_type((byte)2);
                break;
            case 6: // 直接转留言
                snUserOfCaller = snUserService.getSingleValidByPhone(snUidSect.getUnit_id(), callQueryVo.getCaller());
                callQueryResponse.setOp_type((byte)3);
                break;
        }

        callQueryResponse.setCall_type((byte)1);
        callQueryResponse.setCallee(snUser.getReg_phone());
        callQueryResponse.setPlay_code(getAnuCode(callSettings.getAnucode_aleg(),2));
        callQueryResponse.setDisplay_code(
                getDisplayCode(callSettings.getCall_display(), snUidSect, callQueryVo.getCaller(), snUserOfCaller == null ? "" : snUserOfCaller.getUid(), callQueryVo.getCalled(), callQueryVo.getCalled(), callQueryResponse.getCallee())
        );
        callQueryResponse.setRecord(callSettings.getCall_recording() == 1);
        callQueryResponse.setUnit_id_real(snUidSect.getUnit_id());
        callQueryResponse.setLast_call_time(null);
        callQueryResponse.setSub_id(snUser.getSub_id());
        callQueryResponse.setReg_time(snUser.getReg_time().getTime()/1000);
        callQueryResponse.setUuid_in_partner(snUser.getUuid_in_partner());

        // 记录LastCall
        snLastCallService.addSingle(snUidSect.getUnit_id(),
                callQueryResponse.getCallee(),
                callQueryResponse.getDisplay_code(),
                callQueryVo.getCaller(),
                callQueryVo.getCalled(),
                new Date());

        return callQueryResponse;
    }

    /**
     * 呼叫查询
     * @param snUnit unit
     * @param callQueryVo CallQueryVo
     * @return CallQueryResponse
     */
    public CallQueryResponse callQuery(SnUnit snUnit, CallQueryVo callQueryVo) {

        // 查询被叫的号段归属
        SnUidSect snUidSect = snUidSectService.getUidSectByUid(callQueryVo.getCalled());

        // 查询不到被叫的号段归属
        if (snUidSect == null) {
            throw new CallException(CallExceptionEnum.ERR_BAD_NOX, callQueryVo.getSub_service(), (byte)1);
        }

        // 如果接口使用的sub_service和snUidSect的unit_id不一致
        if (!StringUtils.equals(callQueryVo.getSub_service(), snUidSect.getUnit_id())) {
            if (!StringUtils.equals("0", callQueryVo.getSub_service())    // 不是通用unit_id
                    && !snUidSect.getUnit_id().startsWith(callQueryVo.getSub_service())) { // 不是父unit_id
                // 查询的被叫不属于接口指定的unit_id
                throw new CallException(CallExceptionEnum.ERR_NO_PRIVILEGE, callQueryVo.getSub_service(), (byte)1);
            }
            // 根据snUidSect的unit_id更新snUnit
            snUnit = snUnitService.checkUnitId(snUidSect.getUnit_id());
        }

        // 此时，snUidSect.getUnit_id()是真正的unit_id，snUnit存放的是真正的unit的属性

        Assert.isTrue(snUnit != null, "snUnit is null");

        SnUser snUser;
        SnUserContact snUserContact;
        SnLastCall snLastCall;

        // 如果被叫是（动态）统一来显
        if (snUidSect.getUid_type() == 2) {
            // 查询最后通话
            if (null != (snLastCall = snLastCallService.getSingle(snUidSect.getUnit_id(), callQueryVo.getCaller(), callQueryVo.getCalled()))) {
                // 检查主叫是否有绑定关系（根据reg_phone和uid查询，一般情况下LastCall中的called是uid）
                if (null != (snUser = snUserService.getSingle(snUidSect.getUnit_id(), callQueryVo.getCaller(), snLastCall.getCalled()))) {
                    if (snUser.getExpire_time() == null ||
                            snUser.getExpire_time().after(new Date()) ) {
                        // AY最后一通电话
                        return callQueryAYLast(snUidSect, snUnit, snUser, callQueryVo, snLastCall);
                    }
                }
                // 无绑定关系或绑定关系已过期则不允许回拨 todo 是否还要根据CallQueryVo的caller顺便查一个uid？（因为韵达双呼时写入的lastcall的called是统一来显）
                throw new CallException(CallExceptionEnum.ERR_NOREG_NOA_CALL_NOY, snUidSect.getUnit_id(), (byte)0);
            } else {
                throw new CallException(CallExceptionEnum.ERR_NO_LAST_CALL, snUidSect.getUnit_id(), (byte)0);
            }
        }

        // 如果有AX绑定记录
        if (null != (snUser = snUserService.getSingle(snUidSect.getUnit_id(), callQueryVo.getCaller(), callQueryVo.getCalled()))) {
            // AX有绑定记录且在有效期内
            if (snUser.getExpire_time() == null ||
                snUser.getExpire_time().after(new Date()) ) {
                if (null != (snLastCall = snLastCallService.getSingle(snUidSect.getUnit_id(), callQueryVo.getCaller(), callQueryVo.getCalled()))) {
                    // AX最后一通电话
                    return callQueryAXLast(snUidSect, snUnit, snUser, callQueryVo, snLastCall);
                } else if (StringUtils.isNotBlank(snUser.getContacts())) {
                    // AXB
                    return callQueryAXB(snUidSect, snUnit, snUser, callQueryVo);
                } else {
                    // AX时无通话记录也无B
                    throw new CallException(CallExceptionEnum.ERR_NO_NOB_NO_LAST_CALL, snUidSect.getUnit_id(), (byte)0);
                }
            }
            // 即使AX关系已失效也暂不返回，因为caller和called有是BX关系的可能
        }

        // 如果有BX绑定记录
        if (null != (snUserContact = snUserContactService.getSingle(snUidSect.getUnit_id(), callQueryVo.getCaller(), callQueryVo.getCalled()))) {
            snUser = snUserService.getSingle(snUidSect.getUnit_id(), snUserContact.getReg_phone(), callQueryVo.getCalled());
            Assert.isTrue(snUser != null, "snUser is null");
            // BX有绑定记录且对应的AX在有效期内
            if (snUser.getExpire_time() == null ||
                    snUser.getExpire_time().after(new Date()) ) {
                // BXA
                return callQueryBXA(snUidSect, snUnit, snUser, callQueryVo);
            }
            // 即使BX对应的AX已失效也暂不返回，因为called有可能是一个允许NXA且有效的X
        }

        // 如果有有效的X且call_restrict!=1，则作为NXA处理
        if (null != (snUser = snUserService.getSingleValidAndNoRestrictByUid(snUidSect.getUnit_id(), callQueryVo.getCalled()))) {
            return callQueryNXA(snUidSect, snUnit, snUser, callQueryVo);
        }

        // 运行到此处，说明要么X没有有效记录，要么X的call_restrict=1而caller又不是X的contact_phone
        throw new CallException(CallExceptionEnum.ERR_NOREG_NOX_OR_CALL_RESTRICT, snUidSect.getUnit_id(), (byte)1);
    }

    public String twoWayCall(SnUnit snUnit, TwoWayCallVo twoWayCallVo) {
        // 检查msg_data字段数据
        JSONObject msgData;
        try {
            msgData = JSON.parseObject(twoWayCallVo.getMsg_data());
        } catch (Exception e) {
            throw new BusinessException(BusinessExceptionEnum.ERR_TWO_WAY_CALL_MSG);
        }
        if (msgData == null) {
            throw new BusinessException(BusinessExceptionEnum.ERR_TWO_WAY_CALL_MSG);
        }
        checkMsgData(twoWayCallVo.getSub_service(), msgData, "aleg");
        checkMsgData(twoWayCallVo.getSub_service(), msgData, "bleg");

        // 可根据情况处理msgData并返回给调用方

        return msgData.toJSONString();
    }

    @Resource
    private Regex regex;

    @Resource
    private DeadZoneService deadZoneService;

    @Resource
    private BlackListService blackListService;

    public void checkMsgData(String unit_id, JSONObject msgData, String leg) {
        JSONArray numbers;
        try {
            numbers = msgData.getJSONObject(leg).getJSONArray("numbers");
        } catch (Exception e) {
            throw new BusinessException(BusinessExceptionEnum.ERR_TWO_WAY_CALL_MSG);
        }

        if (numbers == null || numbers.isEmpty()) {
            throw new BusinessException(BusinessExceptionEnum.ERR_TWO_WAY_CALL_MSG);
        }

        for (Object number : numbers) {
            String caller = ((JSONObject) number).getString("caller");
            if (null != caller) {
                SnUidSect snUidSect = snUidSectService.getUidSectByUid(caller);
                if (snUidSect == null || !StringUtils.equals(snUidSect.getUnit_id(), unit_id)) {
                    throw new BusinessException(BusinessExceptionEnum.ERR_TWO_WAY_CALL_CALLER);
                }
            } else {
                throw new BusinessException(BusinessExceptionEnum.ERR_TWO_WAY_CALL_MSG);
            }
            String callee = ((JSONObject) number).getString("callee");
            if (null != callee) {
                if (!callee.matches(regex.PHONE_FIXED) && !callee.matches(regex.PHONE_MOBILE)) {
                    throw new BusinessException(BusinessExceptionEnum.ERR_TWO_WAY_CALL_CALLEE);
                }
                // 黑名单判断(reg_phone)
                if (blackListService.isBlackList(unit_id,callee)) {
                    throw new BusinessException(BusinessExceptionEnum.ERR_BLOCKED_PHONE);
                }
                // 盲区判断(reg_phone)
                if (deadZoneService.isDeadZone(callee)) {
                    throw new BusinessException(BusinessExceptionEnum.ERR_DEAD_ZONE);
                }
            } else {
                throw new BusinessException(BusinessExceptionEnum.ERR_TWO_WAY_CALL_MSG);
            }
        }
    }
}

