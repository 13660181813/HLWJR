package cn.cvtt.safenumber.common.api;

import cn.cvtt.safenumber.common.model.SnUidSect;
import cn.cvtt.safenumber.common.model.SnUnit;
import cn.cvtt.safenumber.common.model.SnUnitKey;
import cn.cvtt.safenumber.common.model.SnUser;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@FeignClient("safe-number-service")
public interface SafeNumberService {

    @GetMapping("/v3/unit")
    Map<SnUnitKey, SnUnit> unitGetAll();

    @GetMapping("/v3/unit/{unit_id}")
    SnUnit unitGetByUnitId(@PathVariable("unit_id") String unit_id);

    @PostMapping("/v3/unit")
    SnResponse unitCreateSingle(@RequestParam("msg_id")             String msg_id,
                                @RequestParam("ts")                 String ts,
                                @RequestParam("service")            String service,
                                @RequestParam("sub_service")        String sub_service,
                                @RequestParam("op_module")          String op_module,
                                @RequestParam("op_user")            String op_user,
                                @RequestParam("platform_key")       String platform_key,
                                @RequestParam("secret")             String secret,
                                @RequestParam("params")             String params,
                                @RequestParam("call_settings")      String call_settings,
                                @RequestParam("type")               Byte type,
                                @RequestParam("state")              Byte state,
                                @RequestParam("reserved")           String reserved);

    @PutMapping("/v3/unit")
    SnResponse unitUpdateSingle(@RequestParam("msg_id")             String msg_id,
                                @RequestParam("ts")                 String ts,
                                @RequestParam("service")            String service,
                                @RequestParam("sub_service")        String sub_service,
                                @RequestParam("op_module")          String op_module,
                                @RequestParam("op_user")            String op_user,
                                @RequestParam("platform_key")       String platform_key,
                                @RequestParam("secret")             String secret,
                                @RequestParam("params")             String params,
                                @RequestParam("call_settings")      String call_settings,
                                @RequestParam("type")               Byte type,
                                @RequestParam("state")              Byte state,
                                @RequestParam("reserved")           String reserved);

    @DeleteMapping("/v3/unit")
    SnResponse unitDeleteSingle(@RequestParam("msg_id")             String msg_id,
                                @RequestParam("ts")                 String ts,
                                @RequestParam("service")            String service,
                                @RequestParam("sub_service")        String sub_service,
                                @RequestParam("op_module")          String op_module,
                                @RequestParam("op_user")            String op_user);

    @PostMapping("/v3/uid")
    SnResponse uidCreate(@RequestParam("msg_id")             String msg_id,
                         @RequestParam("ts")                 String ts,
                         @RequestParam("service")            String service,
                         @RequestParam("sub_service")        String sub_service,
                         @RequestParam("op_module")          String op_module,
                         @RequestParam("op_user")            String op_user,
                         @RequestParam("uid_type")           Byte uid_type,
                         @RequestParam("uid_begin")          String uid_begin,
                         @RequestParam("uid_end")            String uid_end);

    @GetMapping("/v3/uid/sect/{unit_id}")
    List<SnUidSect> uidSectGetByUnitId(@PathVariable("unit_id") String unit_id);

    @GetMapping("/v3/uid/sect/{unit_id}/{uid_type}")
    List<SnUidSect> uidSectGetByUnitIdAndType(@PathVariable("unit_id") String unit_id, @PathVariable("uid_type") Byte uid_type);

    @PostMapping("/v3/user")
    SnResponse<SnUser> userRegister(@RequestParam("msg_id")             String msg_id,
                                    @RequestParam("ts")                 String ts,
                                    @RequestParam("service")            String service,
                                    @RequestParam("sub_service")        String sub_service,
                                    @RequestParam("op_module")          String op_module,
                                    @RequestParam("op_user")            String op_user,
                                    @RequestParam("reg_phone")          String reg_phone,
                                    @RequestParam("uid")                String uid,
                                    @RequestParam("expire_time")        String expire_time,
                                    @RequestParam("product_type")       Byte product_type,
                                    @RequestParam("uid_type")           Byte uid_type,
                                    @RequestParam("call_restrict")      Byte call_restrict,
                                    @RequestParam("settings")           String settings,
                                    @RequestParam("contacts")           String contacts,
                                    @RequestParam("uuid_in_partner")    String uuid_in_partner);

    @DeleteMapping("/v3/user")
    SnResponse<SnUser> userUnregister(@RequestParam("msg_id")             String msg_id,
                                      @RequestParam("ts")                 String ts,
                                      @RequestParam("service")            String service,
                                      @RequestParam("sub_service")        String sub_service,
                                      @RequestParam("op_module")          String op_module,
                                      @RequestParam("op_user")            String op_user,
                                      @RequestParam("reg_phone")          String reg_phone,
                                      @RequestParam("uid")                String uid,
                                      @RequestParam("uuid_in_partner")    String uuid_in_partner,
                                      @RequestParam("sub_id")             String sub_id,
                                      @RequestParam("cancel_passport")    Byte cancel_passport,
                                      @RequestParam("op_type")            String op_type);

    @PutMapping("/v3/user")
    SnResponse<SnUser> userUpdate(@RequestParam("msg_id")             String msg_id,
                                  @RequestParam("ts")                 String ts,
                                  @RequestParam("service")            String service,
                                  @RequestParam("sub_service")        String sub_service,
                                  @RequestParam("op_module")          String op_module,
                                  @RequestParam("op_user")            String op_user,
                                  @RequestParam("reg_phone")          String reg_phone,
                                  @RequestParam("uid")                String uid,
                                  @RequestParam("uuid_in_partner")    String uuid_in_partner,
                                  @RequestParam("sub_id")             String sub_id,
                                  @RequestParam("expire_time")        String expire_time,
                                  @RequestParam("call_restrict")      Byte call_restrict,
                                  @RequestParam("settings")           String settings,
                                  @RequestParam("contacts")           String contacts);

    @GetMapping("/v3/call/two_way_call")
    SnResponse<String> twoWayCall(@RequestParam("msg_id")             String msg_id,
                                  @RequestParam("ts")                 String ts,
                                  @RequestParam("service")            String service,
                                  @RequestParam("sub_service")        String sub_service,
                                  @RequestParam("op_module")          String op_module,
                                  @RequestParam("op_user")            String op_user,
                                  @RequestParam("msg_data")           String msg_data);

    @PostMapping("/v3/call/last_call")
    SnResponse<Object> addLastCall(@RequestParam("msg_id")             String msg_id,
                                   @RequestParam("ts")                 String ts,
                                   @RequestParam("service")            String service,
                                   @RequestParam("sub_service")        String sub_service,
                                   @RequestParam("op_module")          String op_module,
                                   @RequestParam("op_user")            String op_user,
                                   @RequestParam("callee")             String callee,
                                   @RequestParam("display_code")       String display_code,
                                   @RequestParam("caller")             String caller,
                                   @RequestParam("called")             String called,
                                   @RequestParam("start_time")         String start_time);

}
