package cn.cvtt.safenumber.web;

import org.apache.commons.lang3.RandomStringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author hushuai
 * @Description TODO
 * @date 2019/8/26
 */
public class Test {
    Logger logger = LoggerFactory.getLogger(Test.class);
    public static void main(String[] args) {
        String unitkey = RandomStringUtils.randomAlphanumeric(15);// 认证码
        String appSecret = RandomStringUtils.randomAlphanumeric(12);// 密钥
        System.out.println(unitkey);
        System.out.println(appSecret);
    }
}
