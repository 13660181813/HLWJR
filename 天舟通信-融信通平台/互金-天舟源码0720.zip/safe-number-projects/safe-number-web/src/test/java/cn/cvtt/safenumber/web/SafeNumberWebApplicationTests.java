package cn.cvtt.safenumber.web;

import cn.cvtt.safenumber.common.api.SafeNumberService;
import cn.cvtt.safenumber.common.api.SnResponse;
import cn.cvtt.safenumber.common.model.SnUser;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import javax.annotation.Resource;
import java.text.SimpleDateFormat;
import java.util.Date;

@RunWith(SpringRunner.class)
@SpringBootTest
public class SafeNumberWebApplicationTests {

    @Resource
    private SafeNumberService safeNumberService;

    @Test
    public void contextLoads() {
        SnResponse<SnUser> result = safeNumberService.userRegister("1",
                new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()),
                "SafeNumber", "10000000003",
                "web",
                "sujin",
                "13911334545",
                null,
                null,
                null,
                (byte)0,
                null,
                null,
                null,
                null);
        System.out.println("test");
    }

}
