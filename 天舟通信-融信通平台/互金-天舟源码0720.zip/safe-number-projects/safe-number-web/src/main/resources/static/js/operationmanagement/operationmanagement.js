$(function () {
    $("#jqGrid").jqGrid({
        url: '../operationmanagement/list',
        datatype: "json",
        colModel: [
			{ label: '单位ID', name: 'unit_id', index: "unit_id", width: 45,key: true, align: 'center' },
			{ label: '单位名称', name: 'unitname', width: 45, align: 'center' },
            { label: 'platform_key', name: 'platform_key', width: 50, align: 'center' },
			{ label: 'secret', name: 'secret', width: 50, align: 'center' },
			{
				label: '类型', name: 'type', width: 30, align: 'center', formatter: function (value, options, row) {
					if (value === 0) {
						return '<span class="label label-primary">系统</span>';
					}
					if (value === 1) {
						return '<span class="label label-success">合作伙伴</span>';
					}
					if (value === 2) {
						return '<span class="label label-warning">渠道商</span>';
					}
				}
			},
			{ label: '状态', name: 'state', width: 30, align: 'center', formatter: function(value, options, row){
				return value === 0 ? 
					'<span class="label label-danger">禁用</span>' : 
					'<span class="label label-success">正常</span>';
			}},
			{ label: '创建时间', name: 'addtime', width: 45, align: 'center' },
			{ label: '默认有效期', name: 'expire_time', width: 45, align: 'center' ,formatter: function (value, options, row) {
                    if (isNull(value)) {
                        return '永久';
                    } else {
                        return  value;
                    }
			}},
			{ label: '保号期', name: 'reserve_time', width: 45, align: 'center' }
        ],
		viewrecords: true,
        height: '100%',
        autowidth:true,
        multiselect: true,
        altRows: true,
        altclass: 'differ',
		rowNum: "data.totalCount",
        // pager: "#jqGridPager",
        jsonReader : {
            root: "data.list",
            page: "data.currPage",
            total: "data.totalPage",
            records: "data.totalCount"
        },
        prmNames : {
            page:"page", 
            rows:"limit", 
            order: "order"
        },
        gridComplete:function(){
        	//隐藏grid底部滚动条
        	$("#jqGrid").closest(".ui-jqgrid-bdiv").css({ "overflow-x" : "hidden" }); 
        },

    });
});

var vm = new Vue({
	el:'#safenumberapp',
	data:{
		q:{
			username: null
		},
		showList: true,
		showListadd:false,
		showListupdate:false,
		title:null,
		roleList:{},
		user:{
			unitstate:1,
			unittype:1,
			roleIdList:[]
		},

	},
	methods: {
		query: function () {
			vm.reload();
		},
		add: function(){
			vm.showList = false;
			vm.showListadd = true;
			vm.showListupdate = false;
			vm.title = "新增";
			vm.roleList = {};
			vm.user = {unittype:1,unitstate:1,roleIdList:[]};

			//获取角色信息
			this.getRoleList();
		},
		update: function () {
			var unitid = getSelectedRow();
			if(unitid == null){
				return ;
			}

			vm.showList = false;
			vm.showListadd = false;
			vm.showListupdate = true;
            vm.title = "修改";

			vm.getUnit(unitid);
			//获取角色信息
		},
		del: function () {
			var userIds = getSelectedRows();
			if(userIds == null){
				return ;
			}

			confirm('确定要删除选中的记录？', function(){
				$.ajax({
					type: "POST",
				    url: "../operationmanagement/unit/delete",
				    data: JSON.stringify(userIds),
				    success: function(r){
						if(r.status == 200){
							alert('操作成功', function(index){
                                vm.reload();
							});
						}else{
							alert(r.msg);
						}
					}
				});
			});
		},
		saveOrUpdate: function (event) {
			var url = vm.user.unit_id == null ? "../operationmanagement/unit/save" : "../operationmanagement/unit/update";
			if (isNull(vm.user.unitid)) {
				alert('单位id不能为空');
				return;
			}
			var numReg = /^[0-9]+$/
			var numRe = new RegExp(numReg);
			if (!numRe.test(vm.user.unitid)) {
				alert("单位id必须是数字")
				return;
			}
			if (isNull(vm.user.unitname)) {
				alert('单位名称不能为空');
				return;
			}
			if (vm.user.unittelephone==undefined) {

			}else {
				var unittelephone = vm.user.unittelephone.replace(/(^\s*)|(\s*$)/g, '');//去除空格;
				if (!isNull(unittelephone) && !isPhone(unittelephone)) {
					alert("电话号码有误，请检查");
					return;
				}
			}
			if (vm.user.unitmobile==undefined){

            }else {
                var mobile = vm.user.unitmobile.replace(/(^\s*)|(\s*$)/g, '');//去除空格;
                if (!isNull(mobile) && !isPhone(mobile)) {
                    alert("手机号格式有误，请检查");
                    return;
                }
            }
			if (isNull(vm.user.expiretime)) {

			}else {
				if (!numRe.test(vm.user.expiretime)) {
					alert("号码默认有效期必须是数字")
					return;
				}
			}
			if (isNull(vm.user.reservetime)) {
				alert('保号期不能为空');
				return;
			}
			if (!numRe.test(vm.user.reservetime)) {
				alert("保号期必须是数字")
				return;
			}
			if (isNull(vm.user.name)) {
				alert('登录昵称不能为空');
				return;
			}
			if (isNull(vm.user.password)) {
				alert('密码不能为空');
				return;
			}
			vm.user.password=$.base64.encode(hex_md5(vm.user.password));

			$.ajax({
				type: "POST",
			    url: url,
			    data: JSON.stringify(vm.user),
			    success: function(r){
			    	if(r.status === 200){
						alert('操作成功', function(index){
							vm.reload();
						});
					}else{
						alert(r.msg);
					}
				}
			});
		},

		saveUpdate: function (event) {
			var numReg = /^[0-9]+$/
			var numRe = new RegExp(numReg);
			var url = "../operationmanagement/unit/update";
			var noPer = false;
			if (isNull(vm.user.unitname)) {
				alert('单位名称不能为空');
				return;
			}
			if (vm.user.unittelephone==undefined) {

			}else {
				var unittelephone = vm.user.unittelephone.replace(/(^\s*)|(\s*$)/g, '');//去除空格;
				if (!isNull(unittelephone) && !isPhone(unittelephone)) {
					alert("电话号码有误，请检查");
					return;
				}
			}
			if (vm.user.unitmobile==undefined){

			}else {
				var mobile = vm.user.unitmobile.replace(/(^\s*)|(\s*$)/g, '');//去除空格;
				if (!isNull(mobile) && !isPhone(mobile)) {
					alert("手机号格式有误，请检查");
					return;
				}
			}

			if (vm.user.expiretime===0) {

			}
			if (isNull(vm.user.expiretime)) {

			}else {
				if (!numRe.test(vm.user.expiretime)) {
					alert("号码默认有效期必须是数字")
					return;
				}
			}

			if (vm.user.reservetime===0) {

			}else {
				if (isNull(vm.user.reservetime)) {
					alert('保号期不能为空');
					return;
				}
			}

			if (!numRe.test(vm.user.reservetime)) {
				alert("保号期必须是数字")
				return;
			}

			$.ajax({
				type: "POST",
				url: url,
				data: JSON.stringify(vm.user),
				success: function(r){
					if(r.status === 200){
						alert('操作成功', function(index){
							vm.reload();
						});
					}else{
						alert(r.msg);
					}
				}
			});
		},
		getUnit: function(unitid){
			$.get("../operationmanagement/unit/info/"+unitid, function(r){
				vm.user = r.data;
			});
		},
		getRoleList: function(){
			$.get("../sys/role/select", function(r){
				vm.roleList = r.data;
			});
		},
		getUser: function(unitid){
			$.get("../sys/user/info/"+userId, function(r){
				vm.user = r.data;
			});
		},
		reload: function (event) {
			vm.showList = true;
			vm.showListadd = false;
			vm.showListupdate = false;
			// var page = $("#jqGrid").jqGrid('getGridParam','page');
			$("#jqGrid").jqGrid('setGridParam',{
                postData:{'username': getString(vm.q.username)},
                // page:1
            }).trigger("reloadGrid");
		}
	}
});