/**
 * 账单统计
 * Created by Yampery on 2018/5/28.
 */
$(function () {
    $("#jqGrid").jqGrid({
        url: '../app/tcs/billStats',
        datatype: "json",
        viewrecords: true,
        height: '100%',
        rowNum: 15,
        rowList : [15,30,50,100],
        autowidth:true,
        altRows: true,
        altclass: 'differ',
        pager: "#jqGridPager",
        colModel: [
            { label: '账户名称', name: 'customerName', width: 20, align:'center' },
            { label: '所属项目', name: 'apid', width: 35, align:'center' },
            { label: '通话次数', name: 'callCount', width: 30, align:'center' },
            { label: '费率', name: 'tariff', width: 20, align:'center' },
            { label: '号码费', name: 'numberSpend', width: 20, align:'center' },
            { label: '并发费', name: 'concurrencySpend', width: 20, align:'center' },
            { label: '通话费', name: 'callSpend', width: 30, align:'center' },
            { label: '总费用', name: 'totalSpend', width: 20, align:'center' },
            { label: '月最低消费', name: 'minCharge', width: 20, align:'center' },
            { label: '呼叫时间', name: 'callTime', width: 20, align:'center' }
        ],
        jsonReader : {
            root: "data.list",
            page: "data.currPage",
            total: "data.totalPage",
            records: "data.totalCount",
        },
        prmNames : {
            page:"page",
            rows:"limit",
            order: "order"
        },
        gridComplete:function(){
            //隐藏grid底部滚动条
            $("#jqGrid").closest(".ui-jqgrid-bdiv").css({ "overflow-x" : "hidden" });
        },
        loadComplete: function(){
            var re_records = $("#jqGrid").getGridParam("records");
            if(isNull(re_records) || re_records<=0){
                vm.showjqGridPager=false;
            }else{
                vm.showjqGridPager=true;
            }
        }
    });
});

var vm = new Vue({
    el:'#safenumberapp',
    data:{
        q:{
            startTime: null,
            endTime: null
        },

        showList: true,
        title:null,
        showjqGridPager:true,
    },
    methods: {
        query: function () {
            vm.q.startTime = $("#start_time").val();
            vm.q.endTime = $("#end_time").val();
            vm.reload();
        },
        reload: function (event) {
            vm.showList = true;
            vm.showResult = true;
            var page = $("#jqGrid").jqGrid('getGridParam','page');
            $("#jqGrid").jqGrid('setGridParam',{
                postData:{
                    'startTime': vm.q.startTime ,
                    'endTime': vm.q.endTime
                },
                page:1
            }).trigger("reloadGrid");
        }
    }
});
