/**
 * 充值页面
 * Created by Yampery on 2018/5/25.
 */
$(function () {
    $("#jqGrid").jqGrid({
        url: '../app/tcs/rechargeLog',
        datatype: "json",
        viewrecords: true,
        height: '100%',
        rowNum: 15,
        rowList : [15,30,50,100],
        autowidth:true,
        altRows: true,
        altclass: 'differ',
        pager: "#jqGridPager",
        colModel: [
            { label: '添加日期', name: 'addtime', width: 40, align:'center' },
            { label: '账户', name: 'customerName', width: 20, align:'center' },
            { label: '账户名称', name: 'customerId', width: 20, align:'center' },
            { label: '所属项目', name: 'apid', width: 35, align:'center' },
            { label: '充值凭证', name: 'certificate', width: 30, align:'center',
                formatter: function(value, options, row){
                    /*if (isNull(value))
                        return "";*/
                    var index = value.lastIndexOf("\/");
                    var flag = value.trim().substring(0, 4);
                    if ("http" != flag)
                        return '';
                    return "<a  href='#' onclick='vm.view(\"" + value + "\")'>" + "查看</a>";
                }
            }
        ],
        jsonReader : {
            root: "data.list",
            page: "data.currPage",
            total: "data.totalPage",
            records: "data.totalCount",
        },
        prmNames : {
            page:"page",
            rows:"limit",
            order: "order"
        },
        gridComplete:function(){
            //隐藏grid底部滚动条
            $("#jqGrid").closest(".ui-jqgrid-bdiv").css({ "overflow-x" : "hidden" });
        },
        loadComplete: function(){
            var re_records = $("#jqGrid").getGridParam("records");
            if(isNull(re_records) || re_records<=0){
                vm.showjqGridPager=false;
            }else{
                vm.showjqGridPager=true;
            }
        }
    });
});

var vm = new Vue({
    el:'#safenumberapp',
    data:{
        q:{
            startTime: null,
            endTime: null
        },

        showList: true,
        title:null,
        showjqGridPager:true,
    },
    methods: {
        query: function () {
            vm.q.startTime = $("#start_time").val();
            vm.q.endTime = $("#end_time").val();
            vm.reload();
        },

        // 上传充值凭证
        recharge: function() {
            vm.title = "上传凭证";
            vm.showList = false;
            // vm.commit();
        }, /// queryOrder end

        commit: function () {
            document.forms[0].target="blank_frame";
            var formData = new FormData($("#uploadForm")[0]);
            var value = $("#upload_file").val();
            if ("" == value) {
                alert("请选择文件！");
                return;
            }
            //return;

            $.ajax({
                url : '../app/tcs/recharge',
                type : 'POST',
                data : formData,
                processData : false,
                contentType : false,
                async: true,
                cache: false,
                beforeSend : function() {
                    $("#upload_file").val("");
                    parent.layerIndex = parent.layer.msg('正在处理，请稍后...', {
                        icon: 16
                        ,shade: 0.5
                        ,time: 1000*60*60
                    });
                },
                complete: function() {
                    parent.layer.close(parent.layerIndex);
                },
                success : function(r) {
                    if(r.status == 200){
                        alert(r.msg, function(index){
                            vm.reload();
                        });
                    }else{
                        alert(r.msg);
                    }
                },
                error : function(r) {
                    parent.layer.alert("请求出错！", {
                        icon: 2
                        ,shade: 0.5
                    });
                    parent.layer.close(parent.layerIndex);
                    console.log("error");
                }
            });
        }, ///commit end

        reload: function (event) {
            vm.showList = true;
            vm.showResult = true;
            var page = $("#jqGrid").jqGrid('getGridParam','page');
            $("#jqGrid").jqGrid('setGridParam',{
                postData:{
                    'startTime': vm.q.startTime ,
                    'endTime': vm.q.endTime
                },
                page:1
            }).trigger("reloadGrid");
        },
        // 查看图片
        view: function (url) {
            var json = {
                "title": "", // 相册标题
                "id": 123, // 相册id
                "start": 0, // 初始显示的图片序号，默认0
                "data": [   //相册包含的图片，数组格式
                    {
                        "alt": "凭证",
                        "pid": 666, //图片id
                        "src": url, //原图地址
                        "thumb": "" //缩略图地址
                    }
                ]
            };

            layer.photos({
                photos: json
                ,anim: 5 //0-6的选择，指定弹出图片动画类型，默认随机
                ,shade: 0.5
            });
        }
    }
});
