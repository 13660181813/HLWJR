$(function () {
	showCompany();
	showNumberType();
    $("#jqGrid").jqGrid({
        url: '../operationmanagement/number/list',
        datatype: "json",
		type : 'POST',
        colModel: [
			/*{ label: 'uid开始key', name: 'uid_begin_key', index: "uid_begin_key", width: 45, key: true, hidden: true, align: 'center' },
			{ label: 'uid结束key', name: 'uid_end_key', index: "uid_end_key", width: 45, key: true, hidden: true, align: 'center' },*/
			{ label: '客户编码', name: 'unit_id', width: 75, align: 'center' },
			{ label: '开始UID', name: 'uid_begin', width: 75, align: 'center' },
			{ label: '结束UID', name: 'uid_end', width: 90, align: 'center' },
			{ label: 'uid个数', name: 'uid_count', width: 100, align: 'center' },
			{ label: '号码类型', name: 'uid_type', width: 80, align: 'center', formatter: function(value, options, row){
					if(value==0) {
						return "安全号";
					}else if(value==1) {
						return "岗位号";
					}else{
						return "企业统一号";
					}
			}}
        ],
		viewrecords: true,
        height: '100%',
        autowidth:true,
        multiselect: true,
        altRows: true,
        altclass: 'differ',
		rowNum: "data.totalCount",
        // pager: "#jqGridPager",
        jsonReader : {
            root: "data.list",
            page: "data.currPage",
            total: "data.totalPage",
            records: "data.totalCount"
        },
		postData:{
			'unitId':$("#unitId").val()
		},
        prmNames : {
            page:"page", 
            rows:"limit", 
            order: "order"
        },
        gridComplete:function(){
        	//隐藏grid底部滚动条
        	$("#jqGrid").closest(".ui-jqgrid-bdiv").css({ "overflow-x" : "hidden" }); 
        }

    });
});
function showNumberType(){
	var html = '<option value="">请选择类型</option>'+'<option value="'+0+'">'+"安全号"+'</option>'+'<option value="'+1+'">'+"岗位号"+'</option>'+'<option value="'+2+'">'+"企业统一号"+'</option>';
	$('#numbertype').html(html);
}
function showCompany(){
	$.ajax({
		url : '/app/number/company',
		dataType: 'json',
		success : function(r) {
			var html='';
			html+='<option value="">请选择企业</option>';
			$.each(r.data,function(i, value) {
				console.log(value);
				var splitArray = value.split(",");
				html+='<option value="'+splitArray[0]+'">'+splitArray[1]+'</option>';
			});
			console.log(html);
			console.log($('#unitId').html());
			$('#unitId').html(html);
			$('#qiyeid').html(html);

		}
	}); /// ajax
}
var vm = new Vue({
	el:'#safenumberapp',
	data:{
		q:{
			username: null
		},
		showList: true,
		title:null,
		roleList:{},
		user:{
			isActive:1,
			roleIdList:[]
		},

	},
	methods: {
		query: function () {
			vm.reload();
		},
		add: function(){
			vm.showList = false;
			vm.title = "新增";
			vm.roleList = {};
			//vm.user = {isActive:1,roleIdList:[]};
			
			//获取角色信息
			//this.getRoleList();
		},
		saveOrUpdate: function (event) {
			/*params:{
				'qiyeId':$("#qiyeid").val(),
					'beginNumber':$("#beginNumber").val(),
					'endNumber':$("#endNumber").val(),
					'numberType':$("#numbertype").val()
			}*/

			var url = "/operationmanagement/app.number/save" ;
			if (isNull($('#qiyeid').val() && $('#qiyeid').val()!="")) {
                alert('请选择企业');
                return;
			}
			else if (isNull($('#beginNumber').val())) {
				alert('开始号段不能为空');
				return;
			}
			else if (isNull($('#endNumber').val())) {
				alert('开始号段不能为空');
				return;
			}
			if (isNull($('#numbertype').val() && $('#numbertype').val()!="")) {
				alert('请选择类型');
				return;
			}
			if ($('#beginNumber').val()>$('#endNumber').val()){
				alert('开始UID需要小于结束UID');
				return;
			}

			/*if (!isNull(vm.user.email) && !isEmail(vm.user.email)) {
				alert("邮箱格式有误，请检查");
				return
			}
			 */

            /*else if (!vm.user.roleIdList || null == vm.user.roleIdList || 1 > vm.user.roleIdList.length) {
               confirm('该用户未分配角色，是否确认？', function() {
					noPer = true;
               });
            }

            if (noPer)	return;*/
            //vm.user.password=$.base64.encode(hex_md5(vm.user.password));
			$.ajax({
				type: "GET",
			    url: url,
				// datatype: "json",
				dataType:'json',
				data:{
					"qiyeId":$("#qiyeid").val(),
					"beginNumber":$("#beginNumber").val(),
					"endNumber":$("#endNumber").val(),
					"numberType":$("#numbertype").val()
				},
			    success: function(r){
			    	if(r.code === 0){
						alert('操作成功', function(index){
							vm.reload();
						});
					}else{
						alert(r.sub_msg);
					}
				}
			});
		},

		reload: function (event) {
			vm.showList = true;
			// var page = $("#jqGrid").jqGrid('getGridParam','page');
			$("#jqGrid").jqGrid('setGridParam',{
                postData:{'unitId': $("#unitId").val(),
				'qiyeId': $("#qiyeid").val()},
                // page:1
            }).trigger("reloadGrid");
		}
	}
});