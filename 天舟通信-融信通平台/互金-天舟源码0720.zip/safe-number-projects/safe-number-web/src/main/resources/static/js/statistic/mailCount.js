/**
 * 安全号js文件
 * 处理安全号批量绑定、单绑以及查询等业务操作
 * Created by Yampery on 2017/6/16.
 */
var monthCount=0;
var weekCount=0;
$(function () {
    $(window).resize(function(){
    });
    $("#start_time").val(vm.q.startTime);
    $("#end_time").val(vm.q.endTime);
    count();
    window.vm.query();
    //createGrid();

});
function tab(date1,date2){
    var oDate1 = new Date(date1);
    var oDate2 = new Date(date2);
    if(oDate1.getTime() > oDate2.getTime()){
        alert("开始日期不得大于结束日期");
        return false;
    }else{
    	return true;
    }
}
function checkDays(endDate,startDate){
    var endDate2 = new Date(endDate);
    var startDate2 = new Date(startDate);
    console.log("value："+(endDate2.getTime() - startDate2.getTime())/1000/60/60);
    return (endDate2.getTime() - startDate2.getTime())>2678400000
}

function isToday(str) {
	   return new Date().getTime() - new Date(str).getTime() < 86400000;
	}
function isAfterToday(str) {
    //当天凌晨
    var timeStamp = new Date(new Date().setHours(0, 0, 0, 0));
    //一天是86400秒   故n天前的时间戳为
    var tomorrow = timeStamp.getTime()+ 86400000;
    console.log("tomorrow:"+tomorrow);
    return new Date(str).getTime()-tomorrow>= 0;
}
function isThisMonth(str) {
    var year=new Date(str).getFullYear()-new Date().getFullYear()=== 0;
    var month=new Date(str).getMonth()-new Date().getMonth()=== 0;
    return year&&month;
}
function isThisWeek(str) {
    var now=new Date();
    var week = now.getDay(); //获取时间的星期数
    var minus = week ? week - 1 : 6;
    now.setDate(now.getDate() - minus); //获取minus天前的日期
    var monday=now;
    var year=monday.getFullYear();
    var month=change(monday.getMonth()+1);
    var day=change(monday.getDate());
    var today=year + "-" + month + "-" + day;
    var compareStr=GetMonday(str);
    console.log("today:"+today);
    console.log("compareStr:"+compareStr);
    return today===compareStr;
}
function change(t){
    if(t<10){
        return "0"+t;
    }else{
        return t;
    }
}
function MonthsBetw(starttime,endtime){
	starttime = starttime.split("-");
	endtime = endtime.split("-");
	//获取年,月数
	var year1 = parseInt(starttime[0]),
	month1 = parseInt(starttime[1]),
	year2 = parseInt(endtime[0]),
	month2 = parseInt(endtime[1]),
	//通过年,月差计算月份差
	months = (year2 - year1) * 12 + (month2 - month1);
	console.log(months);
	return months;
}

/**
 * 统计各状态
 */
function count() {
    $.ajax({
        url : '../number/count/0',
        dataType: 'json',
        type : 'POST',
        processData : false,
        // contentType : false,
        cache: false,
        async: false,
        success : function(r) {
            if ("200" == r.status) {
                // alert("请求成功");
                var data = r.data;
                vm.count_using=data.count_using;
                vm.count_reserve=data.count_reserve;
                vm.count_available=data.count_available;
                vm.count_total=data.count_total;
                return;
            }
            else {
                parent.layer.alert("请求出错", {
                    icon: 2
                    , shade: 0.5
                });
                return;
            }
        }
    });
}

/**
 * 创建表格
 */
function createGrid() {
	var months = MonthsBetw(vm.q.startTime,vm.q.endTime);
	console.log(months);
    var gridWidth=Math.floor(document.body.clientWidth*0.85);
    //列数
    var colsCount=colModel.length;
    console.log("当前有"+colsCount+"列");
    //是否设置滚动条
    var autowidthOrNot=false;
    if(colsCount>7){
        autowidthOrNot=true;
    }
	if(tab(vm.q.startTime,vm.q.endTime)){
        $("#jqGrid").jqGrid({
        url: '../mailCount/countListDetail',
        datatype: "json",
        colModel: colModel,
        altRows: true,
        altclass: 'differ',
        //显示水平滚动条
        // shrinkToFit:false,
        // autoScroll: true,
            autowidth:autowidthOrNot,
        viewrecords: true,

        width:gridWidth,

        height: '100%',
        rowNum: 50,
        rowList : [50],
        rownumbers: false,

        pager: "#jqGridPager",
        pginput:true,
        jsonReader : {
            root: "data.list",
            page: "data.currPage",
            total: "data.totalPage",
            records: "data.totalCount"
        },
        postData:{
            'number': getString(vm.q.number),
            'status': vm.q.status,
            'startTime': vm.q.startTime,
            'endTime': vm.q.endTime,
            'unitId':$('#unitId').val(),
            'uidtype': 0
        },
        prmNames : {  page:"page", rows:"limit", order: "order" },

        gridComplete:function(){
            console.log("jqgfirstrow width:"+$(".jqgfirstrow").width());
            $(".ui-jqgrid-hdiv").width(gridWidth+1);
            $(".ui-jqgrid-bdiv").width(gridWidth+1);
            $(".ui-jqgrid-view").width(gridWidth+1);
            console.log("ui-jqgrid-bdiv width:"+$(".ui-jqgrid-bdiv").width());
        },
        //footerrow:true,
        loadComplete: function(){
            $("#jqGrid").jqGrid('addRowData', 'last_id',lastTotalRow(), 'last');
            var re_records = $("#jqGrid").getGridParam("records");
            if(isNull(re_records) || re_records<=0){
                vm.showjqGridPager=false;
            }else{
                vm.showjqGridPager=true;
            }
        }
    });
}
}
/*合计功能 */
function lastTotalRow(){
    var sum_xiaoji=$("#jqGrid").getCol('total',false,'sum');
    var finallyData={ "start_time": '合计',"total":sum_xiaoji};
    $.each(titleParm,function(i, valueName) {
        var sum=$("#jqGrid").getCol(i+2,false,'sum');
        finallyData[valueName]=sum;
    });
    return finallyData;

}

var vm = new Vue({
    el:'#safenumberapp',
    data:{
        q:{
            number: null,
            startTime: pStrDateTime("","","",new Date(new Date().getFullYear(), new Date().getMonth(), 1), false).substr(0,10),
            endTime: pStrDateTime("","","",new Date(new Date(new Date().toLocaleDateString()).getTime()+24*60*60*1000-1),false).substr(0,10),
            downloadUrl: "安全号批量绑定导入模板.csv",
            msgtype: "batch_bind",
            uidtype: 0
        },
        r:{
            success: null,
            failure: null,
            total: null
        },
        numberArray: [],
        showList: true,
        showUpload: true,
        showResult: true,
        showInput: true,
        showInputResult:true,
        showUnbindInput:true,
        showUnbindInputResult:true,
        showExtendInput:true,
        showExtendInputResult:true,
        title:null,
        showjqGridPager:true
    },
    methods: {
        query: function () {
            monthCount=0;
            weekCount=0;
            vm.q.startTime = $("#start_time").val();
            vm.q.endTime = $("#end_time").val();
            if(isAfterToday(vm.q.startTime)){
                alert("只支持查询当日之前的数据");
                return false;
            }
            if(isAfterToday(vm.q.endTime)){
                alert("只支持查询当日之前的数据");
                return false;
            }
            showCompany();
            vm.recreate();
        },
        queryBeforeMonth: function () {
            //点击前一个月
            if(monthCount===0){
                var lastMonth=getMonthFirstOrLaseDay(new Date(),"before");
                console.log("f:"+lastMonth.firstDay+",last:"+lastMonth.lastDay);
                vm.q.startTime = lastMonth.firstDay.substr(0,10);
                vm.q.endTime = lastMonth.lastDay.substr(0,10);
            }else{
                var lastMonth=getMonthFirstOrLaseDay(new Date(vm.q.startTime),"before");
                console.log("f:"+lastMonth.firstDay+",last:"+lastMonth.lastDay);
                vm.q.startTime = lastMonth.firstDay.substr(0,10);
                vm.q.endTime = lastMonth.lastDay.substr(0,10);
            }
            //判断是否是当月，当月的话，结束时间设置成当天。
            if(isThisMonth(vm.q.startTime)){
                vm.q.startTime= pStrDateTime("","","",new Date(new Date().getFullYear(), new Date().getMonth(), 1), false).substr(0,10);
                vm.q.endTime= pStrDateTime("","","",new Date(new Date(new Date().toLocaleDateString()).getTime()+24*60*60*1000-1),false).substr(0,10);
            }
            if(isAfterToday(vm.q.endTime)){
                vm.q.startTime= pStrDateTime("","","",new Date(new Date().getFullYear(), new Date().getMonth(), 1), false).substr(0,10);
                vm.q.endTime= pStrDateTime("","","",new Date(new Date(new Date().toLocaleDateString()).getTime()+24*60*60*1000-1),false).substr(0,10);
                alert("已经是最新一个月的数据");
                return false;
            }
            monthCount=monthCount+1;
            weekCount=0;
            showCompany();
            vm.recreate();
        },
        queryAfterMonth: function () {
            //点击后一个月
            if(monthCount===0){
                var afterMonth=getMonthFirstOrLaseDay(new Date(),"after");
                console.log("f:"+afterMonth.firstDay+",last:"+afterMonth.lastDay);
                vm.q.startTime = afterMonth.firstDay.substr(0,10);
                vm.q.endTime = afterMonth.lastDay.substr(0,10);
                monthCount=monthCount+1;
                weekCount=0;
            }else{
                //非首次点前一个月，开始时间应该是vm.q.startTime。
                // var startTimeAfterMonth = new Date(vm.q.startTime).getMonth()+2;
                var afterMonth=getMonthFirstOrLaseDay(new Date(vm.q.startTime),"after");
                console.log("f:"+afterMonth.firstDay+",last:"+afterMonth.lastDay);
                vm.q.startTime = afterMonth.firstDay.substr(0,10);
                vm.q.endTime = afterMonth.lastDay.substr(0,10);
                monthCount=monthCount+1;
                weekCount=0;
            }
            //判断是否是当月，当月的话，结束时间设置成当天。
            if(isThisMonth(vm.q.startTime)){
                vm.q.startTime= pStrDateTime("","","",new Date(new Date().getFullYear(), new Date().getMonth(), 1), false).substr(0,10);
                vm.q.endTime= pStrDateTime("","","",new Date(new Date(new Date().toLocaleDateString()).getTime()+24*60*60*1000-1),false).substr(0,10);
            }
            if(isAfterToday(vm.q.endTime)){
                vm.q.startTime= pStrDateTime("","","",new Date(new Date().getFullYear(), new Date().getMonth(), 1), false).substr(0,10);
                vm.q.endTime= pStrDateTime("","","",new Date(new Date(new Date().toLocaleDateString()).getTime()+24*60*60*1000-1),false).substr(0,10);
                alert("已经是最新一个月的数据");
                return false;
            }
            showCompany();
            vm.recreate();
        },
        queryBeforeWeek: function () {
            //点击上一周
            if(weekCount===0){
                //首次点上一周，开始时间应该是当前时间的上周一。
                var date=new Date();
                var lastMonday=GetMonday(pStrDateTime("","dd","7",date, false));
                // var lastMonday0000=lastMonday+" "+"00:00:00";
                // var lastMonday5959=lastMonday+" "+"23:59:59";
                var lastMonday0000=lastMonday;
                var lastMonday5959=lastMonday;
                var lastSunday5959=pStrDateTime("","dd","-6",lastMonday5959, false);
                console.log("lastMonday:"+lastMonday0000+",lastSunday:"+lastSunday5959);
                vm.q.startTime = lastMonday0000.substr(0,10);
                vm.q.endTime = lastSunday5959.substr(0,10);
            }else{
                //非首次点上一周，开始时间应该是当前startTime的上周一。
                var lastMondayF=GetMonday(pStrDateTime("","dd","7",vm.q.startTime, false));
                // var lastMonday0000F=lastMondayF+" "+"00:00:00";
                // var lastMonday5959F=lastMondayF+" "+"23:59:59";
                var lastMonday0000F=lastMondayF.substr(0,10);
                var lastMonday5959F=lastMondayF.substr(0,10);
                var lastSunday5959F=pStrDateTime("","dd","-6",lastMonday5959F, false);
                console.log("lastMondayF:"+lastMonday0000F+",lastSundayF:"+lastSunday5959F);
                vm.q.startTime = lastMonday0000F;
                vm.q.endTime = lastSunday5959F;
            }
            //判断是否是当周。
            if(isThisWeek(vm.q.startTime)){
                var thisMonday=GetMonday(pStrDateTime("","","",new Date(new Date(new Date().toLocaleDateString()).getTime()+24*60*60*1000-1),false)).substr(0,10);
                // vm.q.startTime= thisMonday+" "+"00:00:00";
                vm.q.startTime= thisMonday;
                vm.q.endTime= pStrDateTime("","","",new Date(new Date(new Date().toLocaleDateString()).getTime()+24*60*60*1000-1),false).substr(0,10);
            }
            if(isAfterToday(vm.q.endTime)){
                var thisMonday=GetMonday(pStrDateTime("","","",new Date(new Date(new Date().toLocaleDateString()).getTime()+24*60*60*1000-1),false)).substr(0,10);
                // vm.q.startTime= thisMonday+" "+"00:00:00";
                vm.q.startTime= thisMonday;
                vm.q.endTime= pStrDateTime("","","",new Date(new Date(new Date().toLocaleDateString()).getTime()+24*60*60*1000-1),false).substr(0,10);
                alert("已经是最新一周的数据");
                return false;
            }
            weekCount=weekCount+1;
            monthCount=0;
            showCompany();
            vm.recreate();
        },
        queryAfterWeek: function () {
            //点击下一周
            if(weekCount===0){
                //首次点下一周，开始时间应该是当前时间的下一周周一。
                var date=new Date();
                var afterMonday=GetMonday(pStrDateTime("","dd","-7",date, false));
                var afterMonday0000=afterMonday;
                var afterMonday5959=afterMonday;
                var afterSunday5959=pStrDateTime("","dd","-6",afterMonday5959, false);
                console.log("lastMonday:"+afterMonday0000+",lastSunday:"+afterSunday5959);
                vm.q.startTime = afterMonday0000.substr(0,10);
                vm.q.endTime = afterSunday5959.substr(0,10);
            }else{
                //非首次点上一周，开始时间应该是当前startTime的上周一。
                var afterMondayF=GetMonday(pStrDateTime("","dd","-7",vm.q.startTime, false));
                var afterMonday0000F=afterMondayF;
                var afterMonday5959F=afterMondayF;
                var afterSunday5959F=pStrDateTime("","dd","-6",afterMonday5959F, false);
                console.log("afterMondayF:"+afterMonday0000F+",afterSundayF:"+afterSunday5959F);
                vm.q.startTime = afterMonday0000F.substr(0,10);
                vm.q.endTime = afterSunday5959F.substr(0,10);
            }
            //判断是否是当周。
            if(isThisWeek(vm.q.startTime)){
                var thisMonday=GetMonday(pStrDateTime("","","",new Date(new Date(new Date().toLocaleDateString()).getTime()+24*60*60*1000-1),false)).substr(0,10);
                vm.q.startTime= thisMonday;
                vm.q.endTime= pStrDateTime("","","",new Date(new Date(new Date().toLocaleDateString()).getTime()+24*60*60*1000-1),false).substr(0,10);
            }
            if(isAfterToday(vm.q.endTime)){
                var thisMonday=GetMonday(pStrDateTime("","","",new Date(new Date(new Date().toLocaleDateString()).getTime()+24*60*60*1000-1),false)).substr(0,10);
                vm.q.startTime= thisMonday;
                vm.q.endTime= pStrDateTime("","","",new Date(new Date(new Date().toLocaleDateString()).getTime()+24*60*60*1000-1),false).substr(0,10);
                alert("已经是最新一周的数据");
                return false;
            }
            weekCount=weekCount+1;
            monthCount=0;
            showCompany();
            vm.recreate();
        },

        // 导出文件
        exportGrid: function () {
            var params = {
                'startTime': vm.q.startTime ,
                'endTime': vm.q.endTime
            };
            params = JSON.stringify(params);
            $.ajax({
                url : '../mailCount/export',
                dataType: 'json',
                type : 'POST',
                processData : false,
                cache: false,
                async: false,
                data: params,
                beforeSend : function() {
                    parent.layerIndex = parent.layer.msg('正在导出，请稍后...', {
                        icon: 16
                        ,shade: 0.5
                        ,time: 1000*60*60
                    });
                },
                complete: function() {
                    parent.layer.close(parent.layerIndex);
                },
                success : function(r) {
                    // console.log(data);

                    if ("200" == r.status) {
                        // alert("请求成功");
                        window.location.href = r.data;
                        return;
                    }
                    else {
                        parent.layer.alert(r.msg, {
                            icon: 2
                            , shade: 0.5
                        });
                        return;
                    } /// else
                }, /// success
                error: function (e) {
                    alert("请求出错");
                }
            }); /// ajax
        }, /// exportGrid

        recreate: function (event) {
            // 卸载数据
            $.jgrid.gridUnload("#jqGrid");
            createGrid();
        },

        // 重新加载表格，因div切换后使用卸载表格会导致宽度不能自适应，因此使用重载
        reload: function (event) {
            vm.showList = true;
            vm.showUpload = true;
            vm.showResult = true;
            vm.showInput = true;
            vm.showInputResult = true;
            vm.showUnbindInput=true;
            vm.showUnbindInputResult = true;
            vm.showExtendInput=true;
            vm.showExtendInputResult = true;
            
            $("#check_radio").attr("checked", false);
            var page = $("#jqGrid").jqGrid('getGridParam','page');

            $("#jqGrid").jqGrid('setGridParam',{
                postData:{
                    'number': getString(vm.q.number),
                    'status': vm.q.status,
                    'startTime': vm.q.startTime ,
                    'endTime': vm.q.endTime,
                    'uidtype': vm.q.uidtype
                },
                page:1,
                colModel: colModel
            }).trigger("reloadGrid");
            
        }
    }
});

function showCompany(){
    titleParm=[];
    var cols = [
        { label: '日期', name: 'start_time', width:20, align:'center', formatter: function(valule, options, row){
            if(valule.length>9){return valule.substr(0,10)}
            else return valule;
        // return valule.substr(0,10);
            }
        },
        { label: '小计', name: 'total', width: 10, align:'center',
            formatter: function(valule, options, row){
                if(valule =='' || isNull(valule)){
                    return "0";
                }else {
                    return valule;
                }}
        }
    ];
    //查询表格所需要的列
    $.ajax({
        url : '../number/company',
        dataType: 'json',
        type : 'POST',
        async: false,
        success : function(r) {
            $.each(r.data,function(i, value) {
                titleParm.push("col"+value.unitid);
                cols.push({ label: value.unitname, name: "col"+value.unitid,width: 20, align: 'center',
                    formatter: function(valule, options, row) {
                        if(valule =='' || isNull(valule)){
                            return "0";
                        }else {
                            return valule;
                        }}
                });//如果需要添加额外的列可以这样加
                // html+='<option value="'+value.unitid+'">'+value.unitname+'</option>';
            });
        }
    }); /// ajax
    {
        colModel = cols
    }
}

//获取到每月的第一天和最后一天
function getMonthFirstOrLaseDay(date,afterOrBefore){
    var month=date.getMonth()+1;  //当前月份,1-12
    var year = date.getFullYear();
    if(afterOrBefore==="before"){
        month=month-1;//前一个月份,12月时为-1,1月时为0
        if(month===0) {
            month=12;
            year=year-1;
        }
    }
    if(afterOrBefore==="after"){
        month=month+1;//后一个月份,12月时为1,1月时为0
        if(month===13){
            month=1;
            year=year+1;
        }

    }
    if (month < 10) {
        month = "0" + month;
    }
    var firstDay = year+'-' + month+'-' + "01"+" "+"00:00:00";
    var myDate = new Date(year, month, 0);
    var lastDay = year+'-' + month+'-' +  myDate.getDate()+" "+"23:59:59";
    console.log("firstDay:"+firstDay+",lastDay:"+lastDay);
    return {firstDay:firstDay,lastDay:lastDay}
}

//获取到每个月有几周，并且每周一和周日是哪天
    function GetMonday(ddReceive) {
        var dd=new Date(ddReceive);
        var week = dd.getDay(); //获取时间的星期数
        var minus = week ? week - 1 : 6;
        dd.setDate(dd.getDate() - minus); //获取minus天前的日期
        var y = dd.getFullYear();
        var m = dd.getMonth() + 1; //获取月份
        if (m < 10) {
            m = "0" + m;
        }
        var d = dd.getDate();
        if (d < 10) {
            d = "0" + d;
        }
        console.log("monday:"+y + "-" + m + "-" + d);
        return y + "-" + m + "-" + d;
    }

//全局变量，用于统计合计
var titleParm = [];

