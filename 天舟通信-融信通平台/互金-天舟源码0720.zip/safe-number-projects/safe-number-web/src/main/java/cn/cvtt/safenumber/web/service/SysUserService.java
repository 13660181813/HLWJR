package cn.cvtt.safenumber.web.service;

import cn.cvtt.safenumber.web.pojo.SysUser;

import java.util.List;
import java.util.Map;

/**
 * 用户service
 * @author Yampery
 * @date 2017/6/8 21:19
 */
public interface SysUserService {


    /**
     * 查询应用用户的所有权限
     * @param userId  用户ID
     */
    List<String> queryAllUserPerms(Long userId);

    /**
     * 查询管理用户的所有权限
     * @param userId  用户ID
     */
    List<String> queryAllAdminPerms(Long userId);

    /**
     * 查询用户的所有菜单ID
     */
    List<Long> queryAllMenuId(Long userId);

    /**
     * 根据用户名，查询系统用户
     */
    SysUser queryByUserName(String username);

    /**
     * 根据用户ID，查询用户
     * @param userId
     * @return
     */
    SysUser queryObject(Long userId);

    /**
     * 查询用户列表
     */
    List<SysUser> queryList(Map<String, Object> map);

    /**
     * 查询总数
     */
    int queryTotal(Map<String, Object> map);

    /**
     * 保存用户
     */
    void save(SysUser user);

    /**
     * 修改用户
     */
    void update(SysUser user);

    /**
     * 删除用户
     */
    void deleteBatch(Long[] userIds);

    /**
     * 修改密码
     * @param userId       用户ID
     * @param password     原密码
     * @param newPassword  新密码
     */
    int updatePassword(Long userId, String password, String newPassword);

    /**
     * 获取用户名
     * @param userId
     * @return
     */
    String getUsername(Long userId);

    /**
     * 是否超级管理员
     * @param userId
     * @return
     */
    boolean isAdmin(Long userId);

    /**
     * 获取超级管理员
     * @return
     */
    SysUser getSuper();

    /**
     *
     * @param createId 父Id
     * @return 所有子用户名字
     */
    List getChildrenUserIds(Long createId);

    List queryChildren(Map<String, Object> map);
}
