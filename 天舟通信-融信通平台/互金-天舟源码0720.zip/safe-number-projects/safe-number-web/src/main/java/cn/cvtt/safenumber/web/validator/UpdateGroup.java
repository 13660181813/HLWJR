package cn.cvtt.safenumber.web.validator;

/**
 * 更新数据组
 * @author Yampery
 * @date 2017/6/8 15:39
 */
public interface UpdateGroup {
}
