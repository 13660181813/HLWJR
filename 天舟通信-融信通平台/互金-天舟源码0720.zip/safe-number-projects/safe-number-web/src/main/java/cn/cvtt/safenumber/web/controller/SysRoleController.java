package cn.cvtt.safenumber.web.controller;

import cn.cvtt.safenumber.web.annotation.SysLog;
import cn.cvtt.safenumber.web.pojo.PageResult;
import cn.cvtt.safenumber.web.pojo.ResponsePojo;
import cn.cvtt.safenumber.web.pojo.SNException;
import cn.cvtt.safenumber.web.pojo.SysRole;
import cn.cvtt.safenumber.web.service.SysRoleMenuService;
import cn.cvtt.safenumber.web.service.SysRoleService;
import cn.cvtt.safenumber.web.service.SysUserService;
import cn.cvtt.safenumber.web.utils.CommonUtils;
import cn.cvtt.safenumber.web.validator.ValidatorUtils;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.Collections;
import java.util.List;
import java.util.Map;

/**
 * @author Yampery
 * @date 2017/6/9 15:24
 */
@RestController("roleController")
@RequestMapping("/sys/role")
public class SysRoleController extends AbstractController {

    @Resource
    private SysRoleService sysRoleService;
    @Resource
    private SysRoleMenuService sysRoleMenuService;
    @Resource
    private SysUserService sysUserService;

    /**
     * 角色列表
     */
    @RequestMapping("/list")
    @RequiresPermissions("sys:role:list")
    public ResponsePojo list(@RequestParam Map<String, Object> params){
        int total = 0;
        List<SysRole> list;
        if (isAdmin()) {
            list = sysRoleService.queryList(null);
        }
        else
            list = sysRoleService.getRoleList(getUserId());

        if (!CommonUtils.isNull(list)) {
            Collections.sort(list);
            total = list.size();
        }

        PageResult result = new PageResult(list, total, total, 1);

        return ResponsePojo.ok(result);
    }

    /**
     * 保留---
     *  @RequestMapping("/list")
        @RequiresPermissions("sys:role:list")
        public ResponsePojo list(@RequestParam Map<String, Object> params){
            //如果不是超级管理员，则只查询自己创建的角色列表
            if(!isAdmin()){
                params.put("createUserId", getUserId());
            }

            //查询列表数据
            QueryParams queryParams = new QueryParams(params);
            List<SysRole> list = sysRoleService.queryList(queryParams);
            int total = sysRoleService.queryTotal(queryParams);

            PageResult result = new PageResult(list, total, queryParams.getLimit(), queryParams.getPage());

            return ResponsePojo.ok(result);
        }
     */

    /**
     * 角色列表
     */
    @RequestMapping("/select")
    @RequiresPermissions("sys:role:select")
    public ResponsePojo select(){
        // Map<String, Object> map = new HashMap<>();

        //如果不是超级管理员，则只查询自己所拥有的角色列表
        /*if(!isAdmin()){
            map.put("createUserId", getUserId());
        }*/
        List<SysRole> list = sysRoleService.getRoleList(getUserId());

        return ResponsePojo.ok(list);
    }

    /**
     * 角色信息
     */
    @RequestMapping("/info/{roleId}")
    @RequiresPermissions("sys:role:info")
    public ResponsePojo info(@PathVariable("roleId") Long roleId){
        SysRole role = sysRoleService.queryObject(roleId);

        //查询角色对应的菜单
        List<Long> menuIdList = sysRoleMenuService.queryMenuIdList(roleId);
        role.setMenuIdList(menuIdList);

        return ResponsePojo.ok(role);
    }

    /**
     * 保存角色
     */
    @SysLog("保存角色")
    @RequestMapping("/save")
    @RequiresPermissions("sys:role:save")
    public ResponsePojo save(@RequestBody SysRole role){
        try {
            ValidatorUtils.validateEntity(role);
        } catch (SNException e) {
            logger.error(e.getMsg());
            return ResponsePojo.error(e.getMsg());
        }

        // exist or not
        if (isExist(role.getRoleName(), null)) {
            return ResponsePojo.error("该角色已存在");
        }

        role.setCreateUserId(getUserId());
        sysRoleService.save(role);

        return ResponsePojo.ok();
    }

    /**
     * 保存应用角色，不需要授权
     * @param role
     * @return
     */
    @SysLog("保存应用角色")
    @RequestMapping("/app/save")
    public ResponsePojo saveAppRole(@RequestBody SysRole role) {

        ValidatorUtils.validateEntity(role);

        role.setCreateUserId(getUserId());
        sysRoleService.save(role);

        return ResponsePojo.ok();
    }

    /**
     * 修改角色
     */
    @SysLog("修改角色")
    @RequestMapping("/update")
    @RequiresPermissions("sys:role:update")
    public ResponsePojo update(@RequestBody SysRole role){
        try {
            ValidatorUtils.validateEntity(role);
        } catch (SNException e) {
            logger.error(e.getMsg());
            return ResponsePojo.error(e.getMsg());
        }

        // exist or not
        if (isExist(role.getRoleName(), role.getRoleId())) {
            return ResponsePojo.error("该角色已存在");
        }

        role.setCreateUserId(getUserId());
        sysRoleService.update(role);

        return ResponsePojo.ok();
    }

    /**
     * 修改应用角色，不需要授权
     * @param role
     * @return
     */
    @SysLog("修改應用用戶角色")
    @RequestMapping("/app/update")
    public ResponsePojo updateAppRole(@RequestBody SysRole role){
        ValidatorUtils.validateEntity(role);

        role.setCreateUserId(getUserId());
        sysRoleService.update(role);

        return ResponsePojo.ok();
    }

    /**
     * 删除角色
     */
    @SysLog("删除角色")
    @RequestMapping("/delete")
    @RequiresPermissions("sys:role:delete")
    public ResponsePojo delete(@RequestBody Long[] roleIds){
        sysRoleService.deleteBatch(roleIds);

        return ResponsePojo.ok();
    }

    /**
     * 判断角色是否已经存在
     * @param roleName 角色名
     * @param roleId 角色id（当修改判断时使用，如果是添加，则置参数为null）
     * @return boolean
     */
    private boolean isExist(String roleName, Long roleId) {

        SysRole roleCheck = null;
        long id = 0;
        roleCheck = sysRoleService.queryByRoleName(roleName);

        if (null != roleCheck)
            id = roleCheck.getRoleId();
        // 添加角色
        if (null == roleId) {
            if (null != roleCheck)
                return true;
        } /// if end

        // 修改角色
        else {
            if (null != roleCheck && id != roleId)
                return true;
        } /// else

        return false;
    }
}
