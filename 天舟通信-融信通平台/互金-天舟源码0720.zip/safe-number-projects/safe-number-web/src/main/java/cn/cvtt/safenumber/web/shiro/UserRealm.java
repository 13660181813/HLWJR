package cn.cvtt.safenumber.web.shiro;

import cn.cvtt.safenumber.web.dao.SysMenuDao;
import cn.cvtt.safenumber.web.dao.SysUserDao;
import cn.cvtt.safenumber.web.pojo.Constant;
import cn.cvtt.safenumber.web.pojo.SysMenu;
import cn.cvtt.safenumber.web.pojo.SysUser;
import org.apache.commons.lang3.StringUtils;
import org.apache.shiro.authc.*;
import org.apache.shiro.authz.AuthorizationInfo;
import org.apache.shiro.authz.SimpleAuthorizationInfo;
import org.apache.shiro.realm.AuthorizingRealm;
import org.apache.shiro.subject.PrincipalCollection;

import javax.annotation.Resource;
import java.util.*;

public class UserRealm extends AuthorizingRealm {

    @Resource private SysUserDao sysUserDao;
    @Resource private SysMenuDao sysMenuDao;

    @Override
    protected AuthorizationInfo doGetAuthorizationInfo(PrincipalCollection principals) {

        try {
            SimpleAuthorizationInfo info = new SimpleAuthorizationInfo();
            //info.setRoles();
            info.setStringPermissions(((SysUser)getAvailablePrincipal(principals)).getPermissions());
            return info;
        } catch (Exception e) {
            return null;
        }

    }

    @Override
    protected AuthenticationInfo doGetAuthenticationInfo(AuthenticationToken token) throws AuthenticationException {
        UsernamePasswordToken upToken = (UsernamePasswordToken)token;
        String username = upToken.getUsername();

        // Null username is invalid
        if (StringUtils.isBlank(username)) {
            throw new AccountException("请输入正确的用户名");
        }

        //查询用户信息
        SysUser user = sysUserDao.queryByUserName(username);

        //账号不存在
        if(user == null) {
            throw new UnknownAccountException("账号或密码不正确");
        }
        //账号锁定
        if(0 == user.getIsActive()){
            throw new LockedAccountException("账号已被锁定,请联系管理员");
        }

        //获取用户权限并存到SimpleAuthenticationInfo中，
        //这样每次doGetAuthorizationInfo时不用再查数据库(缺点是修改数据库后需要重新登录才能反映权限变化)
        List<String> permsList;
        // 系统管理员，拥有最高权限
        if(username.equals(Constant.SUPER_ADMIN)){
            List<SysMenu> menuList = sysMenuDao.queryList(new HashMap<>());
            permsList = new ArrayList<>(menuList.size());
            for(SysMenu menu : menuList){
                permsList.add(menu.getPerms());
            }
        } else {
            //获取普通用户的权限
            permsList = sysUserDao.queryAllAdminPerms(user.getUserId());
        }
        //生成用户权限列表
        Set<String> permsSet = new HashSet<>();
        for(String perms : permsList){
            if(StringUtils.isBlank(perms)){
                continue;
            }
            permsSet.addAll(Arrays.asList(perms.trim().split(",")));
        }
        user.setPermissions(permsSet);

        return new SimpleAuthenticationInfo(user, user.getPassword(), getName());
    }
}
