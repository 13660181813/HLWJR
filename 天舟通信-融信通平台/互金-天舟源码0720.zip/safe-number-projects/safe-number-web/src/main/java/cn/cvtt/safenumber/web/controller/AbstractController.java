package cn.cvtt.safenumber.web.controller;

import cn.cvtt.safenumber.web.pojo.Constant;
import cn.cvtt.safenumber.web.pojo.SysUser;
import org.apache.shiro.SecurityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @decription AbstractController
 * <p>公共Controller组件</p>
 * 用于获取当前用户相关信息
 * @author Yampery
 * @date 2017/6/9 14:32
 */
public class AbstractController {

    protected Logger logger = LoggerFactory.getLogger(getClass());

    /**
     * 获取系统用户
     * @return
     */
    protected SysUser getUser() {
        return (SysUser) SecurityUtils.getSubject().getPrincipal();
    }

    /**
     * 获取用户Id
     * @return
     */
    protected Long getUserId() {
        return getUser().getUserId();
    }

    /**
     * 获取用户名
     * @return
     */
    protected String getUsername() { return getUser().getUsername(); }

    /**
     * 获取用户单位id
     * @return
     */
    protected Long getUnitid() {
        return getUser().getUnitid();
    }

    protected String getApid() {
        return getUser().getApid();
    }

    /**
     * 判断当前登录用户是否为管理员
     * @return true/false
     */
    protected boolean isAdmin() {
        return Constant.SUPER_ADMIN.equals(getUsername());
    }
}
