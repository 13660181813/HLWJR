package cn.cvtt.safenumber.web.utils;

import org.apache.commons.lang3.StringUtils;

import java.util.*;
import java.util.stream.Collectors;

/**
 * @decription CommonUtils
 * <p>公共工具方法</p>
 * @date 2017/8/22 15:13
 * @author Yampery
 */
public class CommonUtils {

    /**
     * 对List中的元素去除重复（如果为自定义对象，需要重写equals和hashCode方法）
     * @param objects
     * @return
     */
    public static List removeDuplicate(List objects) {

        List<Object> newList = new ArrayList<>();
        if (isNull(objects))
            return null;
        // 针对ArrayList等随机访问列表
        if (objects instanceof RandomAccess) {
            Object obj;
            for (int i = 0, size = objects.size(); i < size; i++) {
                if (!newList.contains(obj = objects.get(i)))
                    newList.add(obj);
            } /// for end~
        }
        // 针对LinkedList等非随机访问的列表
        else {
            for (Object obj : objects) {
                if (!newList.contains(obj))
                    newList.add(obj);
            } /// for end~
        }

        return newList;
    }

    /**
     * 判断list是否为空
     * @param list
     * @return
     */
    public static boolean isNull(List list) {
        return null == list || list.size() < 1;
    }

    /**
     * 判断数组是否为空
     * @param arr
     * @return
     */
    public static boolean isNullArray(Object[] arr) {
        return null == arr || 1 > arr.length;
    }

    /**
     * 判断Map是否为null
     * @param map
     * @return
     */
    public static boolean isNullMap(Map map) {
        return null == map || 1 > map.size();
    }

    /**
     * 判断一个对象是否为空
     * @param obj
     * @return
     * @TODO 可以将判断空值整合
     */
    public static boolean isNullObj(Object obj) {
        if (null == obj)    return true;
        if (obj instanceof String)
            return StringUtils.isBlank((String) obj);

        return false;
    }

    /**
     * 去除list中的空字符串
     * Java8直接使用<code>list.removeIf(s -> StringUtils.isBlank(s))</code>
     * @param list
     * @return
     */
    @Deprecated
    public static List<String> getTrimList(List<String> list) {
        if (CommonUtils.isNull(list))   return null;
        String str;
        List<String> result = new ArrayList<>();
        for (int i = 0, length = list.size(); i < length; i++) {
            if (StringUtils.isBlank(str = list.get(i)))
                continue;
            result.add(str);
        }

        return result;
    }

    /**
     * 判断list是否有重复（如果为自定义对象，需要重写equals和hashCode方法）
     * @param objects
     * @return
     */
    public static boolean isDuplicate(List objects) {
        if (isNull(objects))
            return false;
        HashMap<Object, Integer> map = new HashMap<>();
        // 针对ArrayList等随机访问列表
        if (objects instanceof RandomAccess) {
            Object obj;
            for (int i = 0, size = objects.size(); i < size; i++) {
                if (null != map.get(obj = objects.get(i)))
                    return true;
                else
                    map.put(obj, 1);
            } /// for end~
        }
        // 针对LinkedList等非随机访问的列表
        else {
            for (Object obj : objects) {
                if (null != map.get(obj))
                    return true;
                else
                    map.put(obj, 1);
            } /// for end~
        }

        return false;
    }

    /**
     * 获取List中的重复元素
     * @param list
     * @param <E>
     * @return
     */
    public static <E> List<E> getDuplicateElements(List<E> list) {
        return list.stream()                           // list 对应的 Stream
                .collect(Collectors.toMap(e -> e, e -> 1, (a, b) -> a + b)) // 获得元素出现频率的 Map，键为元素，值为元素出现的次数
                .entrySet().stream()                   // 所有 entry 对应的 Stream
                .filter(entry -> entry.getValue() > 1) // 过滤出元素出现次数大于 1 的 entry
                .map(entry -> entry.getKey())          // 获得 entry 的键（重复元素）对应的 Stream
                .collect(Collectors.toList());         // 转化为 List
    }

    /**
     * 获取List中相同的元素和位置（仅支持String类型）
     * @param objects
     * @param incr 根据条件，如果需要位置增加（如从CSV中导出的有效数据）
     * @return
     */
    public static Map<String, List<Integer>> getDuplicateWithPos(List<String> objects, int incr) {
        if (isNull(objects))
            return null;
        HashMap<String, List<Integer>> map0 = new HashMap<>();
        HashMap<String, Integer> map1 = new HashMap<>();
        // 保存字符串出现的序号（行号）列表引用
        List<Integer> list;
        String str;
        // 序号
        Integer seqid;
        for (int i = 0, size = objects.size(); i < size; i++) {
            str = objects.get(i);
            if (StringUtils.isBlank(str)) continue;
            if (null != (seqid = map1.get(str))) {
                if (null != (map0.get(str))) {
                    map0.get(str).add(i);
                } else {
                    list = new ArrayList<>();
                    list.add(seqid);
                    list.add(i + incr);
                    map0.put(str, list);
                }
            }
            else
                map1.put(str, i + incr);
        } /// for end~

        return map0;
    }

    /**
     * 获取重复元素和位置（支持泛型）
     * @param objects
     * @param incr 根据此条件，在集合中得到的元素位置增加
     * @param <K>
     * @return
     */
    public static <K> Map<K, List<Integer>> _getDuplicateWithPos(List<K> objects, int incr) {
        if (isNull(objects))
            return null;

        HashMap<K, List<Integer>> map0 = new HashMap<>();
        HashMap<K, Integer> map1 = new HashMap<>();
        // 保存对象出现的序号（行号）列表引用
        List<Integer> list;
        K k;
        Integer seqid;
        for (int i = 0, size = objects.size(); i < size; i++) {
            k = objects.get(i);
            if(isNullObj(k)) continue;
            if (null != (seqid = map1.get(k))) {
                if (null != (map0.get(k))) {
                    map0.get(k).add(i);
                } else {
                    list = new ArrayList<>();
                    list.add(seqid);
                    list.add(i + incr);
                    map0.put(k, list);
                }
            }
            else
                map1.put(k, i + incr);
        } /// for end~

        return map0;
    }
}
