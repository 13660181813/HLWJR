package cn.cvtt.safenumber.web.controller;

import cn.cvtt.safenumber.web.annotation.SysLog;
import cn.cvtt.safenumber.web.dao.SysUserDao;
import cn.cvtt.safenumber.web.pojo.*;
import cn.cvtt.safenumber.web.service.SysLogService;
import cn.cvtt.safenumber.web.service.SysUserRoleService;
import cn.cvtt.safenumber.web.service.SysUserService;
import cn.cvtt.safenumber.web.utils.CommonUtils;
import cn.cvtt.safenumber.web.utils.HttpContextUtils;
import cn.cvtt.safenumber.web.utils.IPUtils;
import cn.cvtt.safenumber.web.utils.JsonUtils;
import cn.cvtt.safenumber.web.validator.AddGroup;
import cn.cvtt.safenumber.web.validator.Assert;
import cn.cvtt.safenumber.web.validator.ValidatorUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.web.bind.annotation.*;
import sun.misc.BASE64Decoder;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.*;


/**
 * @author Yampery
 * @date 2017/6/9 15:10
 */
@RestController("UserController")
@RequestMapping("/sys/user")
public class SysUserController extends AbstractController {

    @Resource
    private SysUserService sysUserService;
    @Resource
    private SysUserRoleService sysUserRoleService;
    @Resource
    private SysUserDao sysUserDao;
    @Resource
    private SysLogService sysLogService;

    /**
     * 所有用户列表
     */
    @RequestMapping("/list")
    @RequiresPermissions("sys:user:list")
    public ResponsePojo list(@RequestParam Map<String, Object> params){

        List<SysUser> userList;
        int total = 0;

        /**
         * 更改为递归查询后不需要排除超级管理员，
         * 但是不再适合分页查询，由于用户一般不是很多，因此这里不再处理分页
         */

        //只有超级管理员，才能查看所有管理员列表
        if(isAdmin()){
            userList = sysUserService.queryList(null);
        }
        else {
            params.put("createUserId", getUserId());
            userList = sysUserService.queryChildren(params);
        }

        if (!CommonUtils.isNull(userList)) {
            Collections.sort(userList);
            total = userList.size();
        }
        PageResult result = new PageResult(userList, total, total, 1);
        //查询列表数据
        /*QueryParams queryParams = new QueryParams(params);
        List<SysUser> userList = sysUserService.queryList(queryParams);
        int total = sysUserService.queryTotal(queryParams);

        PageResult result = new PageResult(userList, total, queryParams.getLimit(), queryParams.getPage());*/

        return ResponsePojo.ok(result);
    }

    /**
     * 获取登录的用户信息
     */
    @RequestMapping("/info")
    public ResponsePojo info(){
        return ResponsePojo.ok(getUser());
    }

    /**
     * 修改登录用户密码
     */
    @RequestMapping("/password")
    public ResponsePojo password(String password, String newPassword){
        Assert.isBlank(newPassword, "新密码不为能空");

        // 记录操作日志
        SysLogPojo sysLogPojo = new SysLogPojo();
        //获取request
        HttpServletRequest request = HttpContextUtils.getHttpServletRequest();
        //设置IP地址
        sysLogPojo.setIp(IPUtils.getIpAddr(request));

        //用户名
        String username = getUser().getUsername();
        sysLogPojo.setUsername(username);

        sysLogPojo.setCreateDate(new Date());
        sysLogPojo.setUnitid(getUnitid().toString());
        String className = this.getClass().getName();
        String methodName = "password";
        sysLogPojo.setMethod(className + "." + methodName + "()");
        sysLogPojo.setOperation("修改密码");

        //sha256加密
        // password = new Sha256Hash(password).toHex();
        //sha256加密
        // newPassword = new Sha256Hash(newPassword).toHex();
        //原md5加密，现更改为前台md5后加盐的方式。
        // password = DigestUtils.md5Hex(password);
        //newPassword = DigestUtils.md5Hex(newPassword);

        //前台采用的是jquery.base64.js进行加盐，改名为addSalt.js,后台可用相应的saltBase64解密
        //前台密码解密
        try {
            password = new String(new BASE64Decoder().decodeBuffer(password));
            newPassword = new String(new BASE64Decoder().decodeBuffer(newPassword));
        } catch (IOException e) {
            sysLogPojo.setMsg("密码解码错误");
            sysLogPojo.setResultCode(201);
            sysLogService.save(sysLogPojo);
            return ResponsePojo.error("密码解码错误");
        }

        //更新密码
        int count = sysUserService.updatePassword(getUserId(), password, newPassword);
        if(count == 0){
            sysLogPojo.setMsg("原密码不正确");
            sysLogPojo.setResultCode(201);
            sysLogService.save(sysLogPojo);
            return ResponsePojo.error("原密码不正确");
        }

        sysLogPojo.setMsg("成功");
        sysLogPojo.setResultCode(200);
        //保存系统日志
        sysLogService.save(sysLogPojo);
        //退出
        SecurityUtils.getSubject().logout();

        return ResponsePojo.ok();
    }

    /**
     * 用户信息
     */
    @RequestMapping("/info/{userId}")
    @RequiresPermissions("sys:user:info")
    public ResponsePojo info(@PathVariable("userId") Long userId){
        SysUser user = sysUserService.queryObject(userId);

        //获取用户所属的角色列表
        List<Long> roleIdList = sysUserRoleService.queryRoleIdList(userId);
        user.setRoleIdList(roleIdList);

        return ResponsePojo.ok(user);
    }

    /**
     * 保存用户
     */
    @SysLog("保存用户")
    @RequestMapping("/save")
    @RequiresPermissions("sys:user:save")
    public ResponsePojo save(@RequestBody SysUser user){

        try {
            ValidatorUtils.validateEntity(user, AddGroup.class);
        } catch (SNException e) {
            logger.error(e.getMsg());
            // e.printStackTrace();
            return ResponsePojo.error(e.getMsg());
        }

        // 如果不是超级管理员，则将单位id设置为该管理员单位id
        if (!isAdmin()) {
            user.setUnitid(getUnitid());
            user.setApid(getApid());
        }

        if (isUserExist(user.getUsername(), null))
            return ResponsePojo.error("该用户名已存在");
        Long unitid  = user.getUnitid();
        if (0L==unitid){
           user.setUnitid(-1L);
        }
        user.setCreateUserId(getUserId());
        sysUserService.save(user);

        return ResponsePojo.ok();
    }

    /**
     * 用于后台调用接口添加企业用户
     * @param user 表单数据
     * @return
     */
    @RequestMapping("/add_unit")
    public ResponsePojo addUnitUser(SysUser user) {

        System.out.println(JsonUtils.objectToJson(user));
        // SysUser user = new SysUser();
        String username = user.getUsername();
        String password = user.getPassword();
        Long unitid = user.getUnitid();
        String name = user.getName();

        if (StringUtils.isBlank(username)) {
            return ResponsePojo.error("用户名为空");
        }
        if (StringUtils.isBlank(password)) {
            return ResponsePojo.error("密码为空");
        }
        if (StringUtils.isBlank(String.valueOf(unitid))){
            unitid = -1L;
        }
            //return ResponsePojo.error("单位id为空");

        SysUser superU = sysUserService.getSuper();
        // 设置创建用户id为超级管理员
        user.setCreateUserId(superU.getUserId());
        user.setUsername(username);
        if (isUserExist(username, null))
            return  ResponsePojo.error("用户已存在");

        user.setPassword(password);
        logger.info(password);
        user.setUnitid(unitid);
        user.setName(name);
        user.setIsActive(1);
        user.setCreateTime(new Date());
        List<Long> roleIds = new ArrayList<>();
        long roleId = 1;
        roleIds.add(roleId);
        user.setRoleIdList(roleIds);

        // 保存企业用户
        sysUserDao.save(user);
        // 保存用户角色
        sysUserRoleService.saveOrUpdate(user.getUserId(), user.getRoleIdList());
        // 保存日志
        SysLogPojo sysLogPojo = new SysLogPojo();

        //获取request
        HttpServletRequest request = HttpContextUtils.getHttpServletRequest();
        //设置IP地址
        sysLogPojo.setIp(IPUtils.getIpAddr(request));

        sysLogPojo.setUsername(Constant.SUPER_ADMIN);

        sysLogPojo.setCreateDate(new Date());
        sysLogPojo.setOperation("添加企业管理员");
        //保存系统日志
        sysLogService.save(sysLogPojo);
        return ResponsePojo.ok();
    }

    /**
     * 检查用户是否已经存在
     * @param username
     * @return
     */
    private boolean isUserExist(String username, Long userId) {
        SysUser userCheck;
        userCheck = sysUserService.queryByUserName(username);
        long id = 0;
        if (null != userCheck)
            id = userCheck.getUserId();
        // 添加用户
        if (null == userId) {
            if (null != userCheck)
                return true;
        }

        // 修改用户
        else {
            if (null != userCheck && id != userId)
                return true;
        }

        return false;
    }

    /**
     * 修改用户
     */
    @SysLog("修改用户")
    @RequestMapping("/update")
    @RequiresPermissions("sys:user:update")
    public ResponsePojo update(@RequestBody SysUser user){

        // 如果管理员没有修改该用户密码，则按照原密码
        /*if (StringUtils.isBlank(user.getPassword())) {
            SysUser sysUser = sysUserService.queryObject(user.getUserId());
            user.setPassword(sysUser.getPassword());
        }*/
        /*try {
            ValidatorUtils.validateEntity(user, AddGroup.class);
        } catch (SNException e) {
            logger.error(e.getMsg());
            // e.printStackTrace();
            return ResponsePojo.error(e.getMsg());
        }*/

        // 如果不是超级管理员，则将单位id设置为该管理员单位id
        if (!isAdmin())
            user.setUnitid(getUnitid());

        if (isUserExist(user.getUsername(), user.getUserId()))
            return ResponsePojo.error("该用户已存在");

        user.setCreateUserId(getUserId());
        sysUserService.update(user);

        return ResponsePojo.ok();
    }

    /**
     * 删除用户
     */
    @SysLog("删除用户")
    @RequestMapping("/delete")
    @RequiresPermissions("sys:user:delete")
    public ResponsePojo delete(@RequestBody Long[] userIds){
        if(ArrayUtils.contains(userIds, 1L)){
            return ResponsePojo.error("系统管理员不能删除");
        }

        if(ArrayUtils.contains(userIds, getUserId())){
            return ResponsePojo.error("当前用户不能删除");
        }

        sysUserService.deleteBatch(userIds);

        return ResponsePojo.ok();
    }
}
