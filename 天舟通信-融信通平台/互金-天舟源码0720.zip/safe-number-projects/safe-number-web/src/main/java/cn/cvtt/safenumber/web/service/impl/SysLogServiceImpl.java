package cn.cvtt.safenumber.web.service.impl;

import cn.cvtt.safenumber.web.dao.SysLogDao;
import cn.cvtt.safenumber.web.pojo.SysLogPojo;
import cn.cvtt.safenumber.web.service.SysLogService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

/**
 * @author Yampery
 * @date 2017/6/15 16:18
 */
@Service("SysLogService")
public class SysLogServiceImpl implements SysLogService {

    @Resource
    private SysLogDao sysLogDao;

    @Override
    public SysLogPojo queryObject(Long id){
        return sysLogDao.queryObject(id);
    }

    @Override
    public List<SysLogPojo> queryList(Map<String, Object> map){
        return sysLogDao.queryList(map);
    }

    @Override
    public int queryTotal(Map<String, Object> map){
        return sysLogDao.queryTotal(map);
    }

    @Override
    public void save(SysLogPojo sysLog){
        sysLogDao.save(sysLog);
    }

    @Override
    public void update(SysLogPojo sysLog){
        sysLogDao.update(sysLog);
    }

    @Override
    public void delete(Long id){
        sysLogDao.delete(id);
    }

    @Override
    public void deleteBatch(Long[] ids){
        sysLogDao.deleteBatch(ids);
    }
}
