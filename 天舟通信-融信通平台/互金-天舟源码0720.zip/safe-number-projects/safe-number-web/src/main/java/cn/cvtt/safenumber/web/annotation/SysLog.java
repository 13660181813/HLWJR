package cn.cvtt.safenumber.web.annotation;

import java.lang.annotation.*;

/**
 * 系统日志注解
 * @author Yampery
 * @date 2017/6/9 14:59
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface SysLog {

    String value() default "";
}
