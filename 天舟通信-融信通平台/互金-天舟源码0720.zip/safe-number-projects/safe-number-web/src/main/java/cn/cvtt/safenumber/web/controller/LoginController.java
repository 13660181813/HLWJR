package cn.cvtt.safenumber.web.controller;

import cn.cvtt.safenumber.web.pojo.ResponsePojo;
import com.google.code.kaptcha.Constants;
import org.apache.commons.lang3.StringUtils;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.*;
import org.apache.shiro.subject.Subject;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import sun.misc.BASE64Decoder;

@Controller
public class LoginController {

    @RequestMapping("/login.html")
    public String login() {
        return "login.html";
    }

    @GetMapping("/logout.html")
    public String logout() {
        SecurityUtils.getSubject().logout();
        return "redirect:login.html";
    }

    @ResponseBody
    @PostMapping("/sys/login")
    public ResponsePojo sys_login(String username, String password, String captcha) {

        try {

            Subject currentUser = SecurityUtils.getSubject();

            //校验验证码
            if (StringUtils.isBlank(captcha)
                    || !StringUtils.equalsIgnoreCase(captcha, currentUser.getSession().getAttribute(Constants.KAPTCHA_SESSION_KEY).toString())) {
                //return ResponsePojo.error("请输入正确的验证码");
            }

            //执行login
            currentUser.login(new UsernamePasswordToken(username, new String(new BASE64Decoder().decodeBuffer(password))));
            
        } catch (UnknownAccountException e) {
            return ResponsePojo.error(e.getMessage());
        }catch (IncorrectCredentialsException e) {
            return ResponsePojo.error("账号或密码不正确");
        }catch (LockedAccountException e) {
            return ResponsePojo.error(e.getMessage());
        }catch (AuthenticationException e) {
            return ResponsePojo.error(e.getMessage());
        }catch (Exception e) {
            return ResponsePojo.error("登录异常，请联系管理员");
        }

        return ResponsePojo.ok();
    }
}
