package cn.cvtt.safenumber.web.dao;

import cn.cvtt.safenumber.web.pojo.SysRole;

import java.util.List;

/**
 * 角色表访问
 * @author Yampery
 * @date 2017/6/8 15:49
 */
public interface SysRoleDao extends BaseDao<SysRole> {

    /**
     * 查询用户创建的角色ID列表
     */
    List<Long> queryRoleIdList(Long createUserId);

    int queryRoleType(Long roleId);

    SysRole queryByRoleName(String roleName);

    List<SysRole> getRoleList(Long CreateId);
}
