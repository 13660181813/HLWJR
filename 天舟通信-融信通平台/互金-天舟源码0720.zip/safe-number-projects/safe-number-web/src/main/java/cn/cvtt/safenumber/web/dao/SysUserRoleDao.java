package cn.cvtt.safenumber.web.dao;

import cn.cvtt.safenumber.web.pojo.SysUserRole;

import java.util.List;

/**
 * @author Yampery
 * @date 2017/6/8 15:50
 */
public interface SysUserRoleDao extends BaseDao<SysUserRole> {

    /**
     * 根据用户ID，获取角色ID列表
     */
    List<Long> queryRoleIdList(Long userId);

    /**
     * 获取某一角色下的所有用户
     * @param roleId
     * @return
     */
    List<Long> quetUserIdsByRole(Long roleId);
}
