package cn.cvtt.safenumber.web.service;

import java.util.List;

/**
 * 角色-资源
 * @author Yampery
 * @date 2017/6/9 10:00
 */
public interface SysRoleMenuService {

    void saveOrUpdate(Long roleId, List<Long> menuIdList);

    /**
     * 根据角色ID，获取菜单ID列表
     */
    List<Long> queryMenuIdList(Long roleId);
}
