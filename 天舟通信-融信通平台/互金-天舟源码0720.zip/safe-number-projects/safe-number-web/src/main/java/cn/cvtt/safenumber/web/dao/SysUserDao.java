package cn.cvtt.safenumber.web.dao;

import cn.cvtt.safenumber.web.pojo.SysUser;

import java.util.List;
import java.util.Map;

/**
 * 用户
 * @author Yampery
 * @date 2017/6/8 15:49
 */
public interface SysUserDao extends BaseDao<SysUser> {

    /**
     * 查询应用用户的所有权限
     * @param userId  用户ID
     */
    List<String> queryAllUserPerms(Long userId);

    /**
     * 查询管理用户的所有权限
     * @param userId 管理员ID
     */
    List<String> queryAllAdminPerms(Long userId);

    /**
     * 查询用户的所有菜单ID
     */
    List<Long> queryAllMenuId(Long userId);

    /**
     * 根据用户名，查询系统用户
     */
    SysUser queryByUserName(String username);

    /**
     * 修改密码
     */
    int updatePassword(Map<String, Object> map);

    /**
     *
     * @param createId 父Id
     * @return 所有子用户名字
     */
    List<SysUser> getChildren(Long createId);

    List<SysUser> queryChildren(Map<String, Object> map);
}
