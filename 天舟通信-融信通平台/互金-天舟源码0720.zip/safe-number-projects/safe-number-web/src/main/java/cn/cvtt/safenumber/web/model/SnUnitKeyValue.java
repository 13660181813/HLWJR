package cn.cvtt.safenumber.web.model;

import java.util.Date;

/**
 * @Description: TODO
 * @Author hushuai
 * @Date 2019/8/25
 **/
public class SnUnitKeyValue {
    private String unit_id;

    private String platform_key;

    private String secret;

    /**
     * pojo UnitParams对应的json串
     */
    private String params;

    /**
     * pojo CallSettings对应的json串
     */
    private String callSettings;

    private Byte type;

    private Byte state;

    private String reserved;

    public SnUnitKeyValue() {
    }

    // 号码有效期（天）
    private Integer expire_time;

    // 号码注销后保留期（天）
    private Integer reserve_time;

    /**
     * 单位名称
     */
    private String unitname;
    /**
     * 单位手机
     */
    private String unitmobile;
    /**
     * 单位电话
     */
    private String unittelephone;
    /**
     * 单位联系人
     */
    private String unitcontact;
    /**
     * 单位地址
     */
    private String unitaddress;
    /**
     * 创建时间
     */
    private Date addtime;

    public SnUnitKeyValue(String unit_id, String platform_key, String secret, String params, String callSettings, Byte type, Byte state, String reserved) {
        this.unit_id = unit_id;
        this.platform_key = platform_key;
        this.secret = secret;
        this.params = params;
        this.callSettings = callSettings;
        this.type = type;
        this.state = state;
        this.reserved = reserved;
    }

    public SnUnitKeyValue(String unit_id, String platform_key, String secret, String params, String callSettings, Byte type, Byte state, String reserved, Integer expire_time, Integer reserve_time, String unitname, String unitmobile, String unittelephone, String unitcontact, String unitaddress, Date addtime) {
        this.unit_id = unit_id;
        this.platform_key = platform_key;
        this.secret = secret;
        this.params = params;
        this.callSettings = callSettings;
        this.type = type;
        this.state = state;
        this.reserved = reserved;
        this.expire_time = expire_time;
        this.reserve_time = reserve_time;
        this.unitname = unitname;
        this.unitmobile = unitmobile;
        this.unittelephone = unittelephone;
        this.unitcontact = unitcontact;
        this.unitaddress = unitaddress;
        this.addtime = addtime;
    }

    public String getUnit_id() {
        return unit_id;
    }

    public void setUnit_id(String unit_id) {
        this.unit_id = unit_id;
    }

    public String getPlatform_key() {
        return platform_key;
    }

    public void setPlatform_key(String platform_key) {
        this.platform_key = platform_key;
    }

    public String getSecret() {
        return secret;
    }

    public void setSecret(String secret) {
        this.secret = secret;
    }

    public String getParams() {
        return params;
    }

    public void setParams(String params) {
        this.params = params;
    }

    public String getCallSettings() {
        return callSettings;
    }

    public void setCallSettings(String callSettings) {
        this.callSettings = callSettings;
    }

    public Byte getType() {
        return type;
    }

    public void setType(Byte type) {
        this.type = type;
    }

    public Byte getState() {
        return state;
    }

    public void setState(Byte state) {
        this.state = state;
    }

    public String getReserved() {
        return reserved;
    }

    public void setReserved(String reserved) {
        this.reserved = reserved;
    }

    public Integer getExpire_time() {
        return expire_time;
    }

    public void setExpire_time(Integer expire_time) {
        this.expire_time = expire_time;
    }

    public Integer getReserve_time() {
        return reserve_time;
    }

    public void setReserve_time(Integer reserve_time) {
        this.reserve_time = reserve_time;
    }

    public String getUnitname() {
        return unitname;
    }

    public void setUnitname(String unitname) {
        this.unitname = unitname;
    }

    public String getUnitmobile() {
        return unitmobile;
    }

    public void setUnitmobile(String unitmobile) {
        this.unitmobile = unitmobile;
    }

    public String getUnittelephone() {
        return unittelephone;
    }

    public void setUnittelephone(String unittelephone) {
        this.unittelephone = unittelephone;
    }

    public String getUnitcontact() {
        return unitcontact;
    }

    public void setUnitcontact(String unitcontact) {
        this.unitcontact = unitcontact;
    }

    public String getUnitaddress() {
        return unitaddress;
    }

    public void setUnitaddress(String unitaddress) {
        this.unitaddress = unitaddress;
    }

    public Date getAddtime() {
        return addtime;
    }

    public void setAddtime(Date addtime) {
        this.addtime = addtime;
    }
}
