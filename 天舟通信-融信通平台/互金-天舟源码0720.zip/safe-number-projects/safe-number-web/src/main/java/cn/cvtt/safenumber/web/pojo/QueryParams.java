package cn.cvtt.safenumber.web.pojo;

import cn.cvtt.safenumber.web.crypt.ADESUtils;
import cn.cvtt.safenumber.web.filter.SQLFilter;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * 查询参数
 * @author Yampery
 * @date 2017/6/9 14:44
 */
public class QueryParams extends LinkedHashMap<String, Object>{

    private static final long serialVersionUID = 1L;
    //当前页码
    private int page;
    //每页条数
    private int limit;

    public QueryParams(Map<String, Object> params){
        // 如果参数是手机号，则加密后查询
        if (params.containsKey("app.number")) {
            String number = params.get("app.number").toString();
            if (number.matches(Constant.REGIX_PHONE)) {
                params.put("number", ADESUtils.getInstance().encrypt(number));
            }
        }
        this.putAll(params);

        //分页参数
        if (null != params.get("page")) {
            this.page = Integer.parseInt(params.get("page").toString());
            this.put("page", page);
        }
        if (null != params.get("limit")) {
            this.limit = Integer.parseInt(params.get("limit").toString());
            this.put("limit", limit);
            this.put("offset", (page - 1) * limit);
        }
        //防止SQL注入（因为sidx、order是通过拼接SQL实现排序的，会有SQL注入风险）
        String sidx = "", order = "";
        if (null != params.get("sidx"))
            sidx = params.get("sidx").toString();
        if (null != params.get("order"))
            order = params.get("order").toString();
        this.put("sidx", SQLFilter.sqlInject(sidx));
        this.put("order", SQLFilter.sqlInject(order));
    }


    public int getPage() {
        return page;
    }

    public void setPage(int page) {
        this.page = page;
    }

    public int getLimit() {
        return limit;
    }

    public void setLimit(int limit) {
        this.limit = limit;
    }
}
