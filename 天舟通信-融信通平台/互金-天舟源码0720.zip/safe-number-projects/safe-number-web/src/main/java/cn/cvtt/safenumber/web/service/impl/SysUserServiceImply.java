package cn.cvtt.safenumber.web.service.impl;

import cn.cvtt.safenumber.web.dao.SysUserDao;
import cn.cvtt.safenumber.web.pojo.Constant;
import cn.cvtt.safenumber.web.pojo.SNException;
import cn.cvtt.safenumber.web.pojo.SysRole;
import cn.cvtt.safenumber.web.pojo.SysUser;
import cn.cvtt.safenumber.web.service.SysRoleService;
import cn.cvtt.safenumber.web.service.SysUserRoleService;
import cn.cvtt.safenumber.web.service.SysUserService;
import cn.cvtt.safenumber.web.utils.CommonUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import sun.misc.BASE64Decoder;

import javax.annotation.Resource;
import java.io.IOException;
import java.util.*;

/**
 * @author Yampery
 * @date 2017/6/9 10:14
 */
@Service("SysUserService")
public class SysUserServiceImply implements SysUserService {

    @Resource
    private SysUserDao sysUserDao;
    @Resource
    private SysUserRoleService sysUserRoleService;
    @Resource
    private SysRoleService sysRoleService;

    @Override
    public List<String> queryAllUserPerms(Long userId) {
        return sysUserDao.queryAllUserPerms(userId);
    }
    
    @Override
    public List<String> queryAllAdminPerms(Long userId) {
        return sysUserDao.queryAllAdminPerms(userId);
    }

    @Override
    public List<Long> queryAllMenuId(Long userId) {
        return sysUserDao.queryAllMenuId(userId);
    }

    @Override
    public SysUser queryByUserName(String username) {
        return sysUserDao.queryByUserName(username);
    }

    @Override
    public SysUser queryObject(Long userId) {
        return sysUserDao.queryObject(userId);
    }

    @Override
    public List<SysUser> queryList(Map<String, Object> map){
        return sysUserDao.queryList(map);
    }

    @Override
    public int queryTotal(Map<String, Object> map) {
        return sysUserDao.queryTotal(map);
    }

    @Override
    @Transactional
    public void save(SysUser user) {
        user.setCreateTime(new Date());
        try {
            user.setPassword(new String(new BASE64Decoder().decodeBuffer(user.getPassword())));
        } catch (IOException e) {
            //todo handle this exception
        }

        sysUserDao.save(user);

        //检查角色是否越权
        // checkRole(user);

        //保存用户与角色关系
        sysUserRoleService.saveOrUpdate(user.getUserId(), user.getRoleIdList());
    }

    @Override
    @Transactional
    public void update(SysUser user) {
        if(StringUtils.isBlank(user.getPassword())){
            user.setPassword(null);
        }else{
            try {
                user.setPassword(new String(new BASE64Decoder().decodeBuffer(user.getPassword())));
            } catch (IOException e) {
                //todo handle this exception
            }
        }
        sysUserDao.update(user);

        //检查角色是否越权
        // checkRole(user);

        //保存用户与角色关系
        sysUserRoleService.saveOrUpdate(user.getUserId(), user.getRoleIdList());
    }

    @Override
    @Transactional
    public void deleteBatch(Long[] userId) {
        sysUserDao.deleteBatch(userId);
    }

    @Override
    public int updatePassword(Long userId, String password, String newPassword) {
        Map<String, Object> map = new HashMap<>();
        map.put("userId", userId);
        map.put("password", password);
        map.put("newPassword", newPassword);
        return sysUserDao.updatePassword(map);
    }

    @Override
    public String getUsername(Long userId) {
        return queryObject(userId).getUsername();
    }

    @Override
    public boolean isAdmin(Long userId) {
        String username = getUsername(userId);
        return Constant.SUPER_ADMIN.equals(username);
    }

    @Override
    public SysUser getSuper() {
        return queryByUserName(Constant.SUPER_ADMIN);
    }

    @Override
    @Transactional
    public List<String> getChildrenUserIds(Long createId) {
        List<String> list = new ArrayList<>();
        // 首先添加当前操作用户
        list.add(getUsername(createId));
        List<SysUser> users = sysUserDao.getChildren(createId);
        // 如果子用户不为null，则递归查询
        if (null != users && 0 < users.size()) {
            for (SysUser user : users) {
                list.addAll(getChildrenUserIds(user.getUserId()));
            } /// for end~
        }
        return list;
    }

    @Override
    @Transactional
    public List<SysUser> queryChildren(Map<String, Object> map) {
        List<SysUser> users = sysUserDao.queryChildren(map);
        List<SysUser> list = new ArrayList<>();
        list.addAll(users);
        if (null != users && 0 < users.size()) {
            for (SysUser user : users) {
                map.put("createUserId", user.getUserId());
                list.addAll(queryChildren(map));
            } /// for end~
        }
        return list;
    }

    /**
     * 检查角色是否越权
     */
    private void checkRole(SysUser user){
        SysUser createUser = sysUserDao.queryObject(user.getUserId());
        //如果不是超级管理员，则需要判断用户的角色是否自己创建
        if(isAdmin(createUser.getUserId())){
            return ;
        }

        //查询用户创建的角色列表
        // List<Long> roleIdList = sysRoleService.queryRoleIdList(user.getCreateUserId());
        List<Long> roleIdList = new ArrayList<>();
        List<SysRole> roleList = sysRoleService.getRoleList(user.getCreateUserId());
        if (!CommonUtils.isNull(roleList)) {
            for (SysRole role : roleList) {
                roleIdList.add(role.getRoleId());
            } /// for end~
        }

        //判断是否越权
        if(!roleIdList.containsAll(user.getRoleIdList())){
            throw new SNException("新增用户所选角色，不是本人创建");
        }
    }
}
