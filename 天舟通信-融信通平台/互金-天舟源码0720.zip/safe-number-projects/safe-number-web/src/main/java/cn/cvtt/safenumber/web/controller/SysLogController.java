package cn.cvtt.safenumber.web.controller;

import cn.cvtt.safenumber.web.pojo.PageResult;
import cn.cvtt.safenumber.web.pojo.QueryParams;
import cn.cvtt.safenumber.web.pojo.ResponsePojo;
import cn.cvtt.safenumber.web.pojo.SysLogPojo;
import cn.cvtt.safenumber.web.service.SysLogService;
import cn.cvtt.safenumber.web.service.SysUserService;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

/**
 * 系统日志控制器
 * @author Yampery
 * @date 2017/6/15 16:33
 */
@RestController("SysLogController")
@RequestMapping("/sys/log")
public class SysLogController extends AbstractController {

    @Resource
    private SysLogService sysLogService;
    @Resource
    private SysUserService userService;

    /**
     * 日志列表
     */
    @RequestMapping("/list")
    @RequiresPermissions("sys:log:list")
    public ResponsePojo list(@RequestParam Map<String, Object> params){
        // 获取当前登录用户的unitid
        long unitid = getUnitid();
        long userId = getUserId();
        // List<String> usernames = userService.getChildrenUserIds(userId);

        if (!isAdmin()) {
            params.put("unitid", unitid);
            // 去除用户过滤
            // params.put("usernames", usernames);
        }
        //查询列表数据
        QueryParams queryParams = new QueryParams(params);
        List<SysLogPojo> sysLogList = sysLogService.queryList(queryParams);
        int total = sysLogService.queryTotal(queryParams);

        PageResult result = new PageResult(sysLogList, total, queryParams.getLimit(), queryParams.getPage());

        return ResponsePojo.ok(result);
    }
}
