package cn.cvtt.safenumber.web.model;

import java.util.List;

/**
 * @author hushuai
 * @Description 用户接收添加单位信息的实体类
 * @date 2019/8/28
 */
public class UnitVo {

    /**
     * 单位id
     */
    private String unitid;
    /**
     * 单位名称
     */
    private String unitname;
    /**
     * 单位手机
     */
    private String unitmobile;
    /**
     * 单位电话
     */
    private String unittelephone;
    /**
     * 单位联系人
     */
    private String unitcontact;
    /**
     * 单位地址
     */
    private String unitaddress;
    /**
     * 单位类型，0：系统；1：合作伙伴；2：渠道商
     */
    private String unittype;

    /**
     * 单位状态
     */
    private String unitstate;
    /**
     * 过期时间
     */
    private Integer expiretime;
    /**
     * 保号期
     */
    private Integer reservetime;

    /**
     * 用户名
     */
    private String username;
    /**
     * 密码
     */
    private  String password;

    /**
     * 角色ID列表
     */
    private List<Long> roleIdList;

    /**
     * 用户昵称
     */
    private String name;

    private String sAnucodeAleg;

    private String sAnucodeBleg;

    private String sCallDisplay;

    private Byte sCallRecording;

    private Byte sCallRestrict;

    private String pAnucodeAleg;

    private String pAnucodeBleg;

    private String pCallDisplay;

    private Byte pCallRecording;

    private Byte pCallRestrict;

    private String platformKey;

    private String secret;

    public String getUnitid() {
        return unitid;
    }

    public void setUnitid(String unitid) {
        this.unitid = unitid;
    }

    public String getUnitname() {
        return unitname;
    }

    public void setUnitname(String unitname) {
        this.unitname = unitname;
    }

    public String getUnitmobile() {
        return unitmobile;
    }

    public void setUnitmobile(String unitmobile) {
        this.unitmobile = unitmobile;
    }

    public String getUnittelephone() {
        return unittelephone;
    }

    public void setUnittelephone(String unittelephone) {
        this.unittelephone = unittelephone;
    }

    public String getUnitcontact() {
        return unitcontact;
    }

    public void setUnitcontact(String unitcontact) {
        this.unitcontact = unitcontact;
    }

    public String getUnitaddress() {
        return unitaddress;
    }

    public void setUnitaddress(String unitaddress) {
        this.unitaddress = unitaddress;
    }

    public String getUnittype() {
        return unittype;
    }

    public void setUnittype(String unittype) {
        this.unittype = unittype;
    }

    public String getUnitstate() {
        return unitstate;
    }

    public void setUnitstate(String unitstate) {
        this.unitstate = unitstate;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public List<Long> getRoleIdList() {
        return roleIdList;
    }

    public void setRoleIdList(List<Long> roleIdList) {
        this.roleIdList = roleIdList;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getExpiretime() {
        return expiretime;
    }

    public void setExpiretime(Integer expiretime) {
        this.expiretime = expiretime;
    }

    public Integer getReservetime() {
        return reservetime;
    }

    public void setReservetime(Integer reservetime) {
        this.reservetime = reservetime;
    }

    public String getsAnucodeAleg() {
        return sAnucodeAleg;
    }

    public void setsAnucodeAleg(String sAnucodeAleg) {
        this.sAnucodeAleg = sAnucodeAleg;
    }

    public String getsAnucodeBleg() {
        return sAnucodeBleg;
    }

    public void setsAnucodeBleg(String sAnucodeBleg) {
        this.sAnucodeBleg = sAnucodeBleg;
    }

    public String getsCallDisplay() {
        return sCallDisplay;
    }

    public void setsCallDisplay(String sCallDisplay) {
        this.sCallDisplay = sCallDisplay;
    }

    public Byte getsCallRecording() {
        return sCallRecording;
    }

    public void setsCallRecording(Byte sCallRecording) {
        this.sCallRecording = sCallRecording;
    }

    public Byte getsCallRestrict() {
        return sCallRestrict;
    }

    public void setsCallRestrict(Byte sCallRestrict) {
        this.sCallRestrict = sCallRestrict;
    }

    public String getpAnucodeAleg() {
        return pAnucodeAleg;
    }

    public void setpAnucodeAleg(String pAnucodeAleg) {
        this.pAnucodeAleg = pAnucodeAleg;
    }

    public String getpAnucodeBleg() {
        return pAnucodeBleg;
    }

    public void setpAnucodeBleg(String pAnucodeBleg) {
        this.pAnucodeBleg = pAnucodeBleg;
    }

    public String getpCallDisplay() {
        return pCallDisplay;
    }

    public void setpCallDisplay(String pCallDisplay) {
        this.pCallDisplay = pCallDisplay;
    }

    public Byte getpCallRecording() {
        return pCallRecording;
    }

    public void setpCallRecording(Byte pCallRecording) {
        this.pCallRecording = pCallRecording;
    }

    public Byte getpCallRestrict() {
        return pCallRestrict;
    }

    public void setpCallRestrict(Byte pCallRestrict) {
        this.pCallRestrict = pCallRestrict;
    }

    public String getPlatformKey() {
        return platformKey;
    }

    public void setPlatformKey(String platformKey) {
        this.platformKey = platformKey;
    }

    public String getSecret() {
        return secret;
    }

    public void setSecret(String secret) {
        this.secret = secret;
    }
}
