package cn.cvtt.safenumber.web.validator;

import cn.cvtt.safenumber.web.pojo.SNException;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import java.util.Set;

/**
 *
 * 对象校验工具
 * @author Yampery
 * @date 2017/6/9 15:21
 */
public class ValidatorUtils {

    private static Validator validator;

    // 初始加载创建一个validator
    static {
        validator = Validation.buildDefaultValidatorFactory().getValidator();
    }

    /**
     * 校验对象
     * @param object        待校验对象
     * @param groups        待校验的组
     * @throws SNException  校验不通过，则报SNException异常
     */
    public static void validateEntity(Object object, Class<?>... groups)
            throws SNException {
        Set<ConstraintViolation<Object>> constraintViolations = validator.validate(object, groups);
        if (!constraintViolations.isEmpty()) {
            ConstraintViolation<Object> constraint = (ConstraintViolation<Object>)constraintViolations.iterator().next();
            throw new SNException(constraint.getMessage());
        }
    }
}
