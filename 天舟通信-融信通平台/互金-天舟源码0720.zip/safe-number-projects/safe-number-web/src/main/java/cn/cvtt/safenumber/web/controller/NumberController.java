package cn.cvtt.safenumber.web.controller;

import cn.cvtt.safenumber.common.api.SafeNumberService;
import cn.cvtt.safenumber.common.model.SnUnit;
import cn.cvtt.safenumber.common.model.SnUnitKey;
import cn.cvtt.safenumber.web.pojo.PageResult;
import cn.cvtt.safenumber.web.pojo.QueryParams;
import cn.cvtt.safenumber.web.pojo.ResponsePojo;
import com.alibaba.fastjson.JSONObject;
import org.apache.commons.lang3.StringUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.thymeleaf.spring5.context.SpringContextUtils;
import org.thymeleaf.util.DateUtils;

import javax.annotation.Resource;
import java.io.IOException;
import java.util.*;import java.util.HashMap;
@RestController
@RequestMapping("/app/number")
public class NumberController extends AbstractController {

    @Resource
    private SafeNumberService safeNumberService;
//    @Resource
//    private INumberService numberService;

    /*@RequestMapping("/count/{uidtype}")
    public ResponsePojo count(@PathVariable Byte uidtype) {
        //Map<String, Long> result = safeNumberService.uidStat(getUnitid().toString(), uidtype);
        Map<String, Long> result = new HashMap<>();        return ResponsePojo.ok(result);

    }
    }*/
    @RequestMapping("/list")
    public ResponsePojo list(@RequestParam Map<String, Object> params){
        return null;
    }

    @RequestMapping("/ifcompany")
    public ResponsePojo ifcompany() {
        long unitid = getUnitid();
        System.out.println(unitid);
        return ResponsePojo.ok(unitid);
    }
    @RequestMapping("/company")
    public ResponsePojo company() {
        Map<SnUnitKey, SnUnit> returnmap = safeNumberService.unitGetAll();
        Set set = returnmap.entrySet();
        List<String> returnList = new ArrayList<>();
        for(Iterator iter = set.iterator(); iter.hasNext();)
        {
            Map.Entry entry = (Map.Entry)iter.next();
            SnUnitKey key = (SnUnitKey)entry.getKey();
            SnUnit value = (SnUnit)entry.getValue();
            String unitid = key.getUnit_id();
            String params = value.getReserved();
            JSONObject jsonObject = JSONObject.parseObject(params);
            String unitname = (String)jsonObject.get("unitname");
            String returnUnit = unitid+","+unitname;
            returnList.add(returnUnit);
            //System.out.println(value);
        }
        return ResponsePojo.ok(returnList);
    }
    /**
     * @param file
     * @param uidtype
     * @param msgtype
     * @return
     * @throws Exception
     */
    @RequestMapping("/batchwork/operate")
    public ResponsePojo batchwork(@RequestParam("file") MultipartFile file, @RequestParam("uidtype") String uidtype,
                                  @RequestParam("msgtype") String msgtype, @RequestParam("checkUUID") int checkUUID) throws Exception {
        if (file.isEmpty()) {
            ResponsePojo.error("");
        }
        return null;
    }
    /**
     *
     * @param
     * @return
     */
    @RequestMapping("/bind")
    public ResponsePojo bindSingleNumber(@RequestBody Map<String,Object> params) throws IOException {

        //return numberService.bind(params, REQUEST_BASE_PATH);
        return null;
    }
    /**
     *
     * @param
     * @return
     */
    @RequestMapping("/unbind")
    public ResponsePojo unbindSingleNumber(@RequestBody Map<String,Object> params) throws IOException {

       // return numberService.unbind(params, REQUEST_BASE_PATH);
        return null;
    }
    /**
     *
     * @param
     * @return
     */
    @RequestMapping("/extend")
    public ResponsePojo extendSingleNumber(@RequestBody Map<String,Object> params) throws IOException {

       // return numberService.extend(params, REQUEST_BASE_PATH);
        return null;
    }



}
