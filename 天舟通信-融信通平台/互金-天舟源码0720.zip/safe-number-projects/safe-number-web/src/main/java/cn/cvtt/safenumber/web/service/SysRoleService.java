package cn.cvtt.safenumber.web.service;

import cn.cvtt.safenumber.web.pojo.SysRole;

import java.util.List;
import java.util.Map;

/**
 * 角色service
 * @author Yampery
 * @date 2017/6/8 21:22
 */
public interface SysRoleService {

    SysRole queryObject(Long roleId);

    List<SysRole> queryList(Map<String, Object> map);

    int queryTotal(Map<String, Object> map);

    void save(SysRole role);

    void update(SysRole role);

    void deleteBatch(Long[] roleIds);

    /**
     * 查询用户创建的角色ID列表
     */
    List<Long> queryRoleIdList(Long createUserId);

    /**
     * 根据角色名称查询角色
     * @param roleName
     * @return
     */
    SysRole queryByRoleName(String roleName);

    List<SysRole> getRoleList(Long createUserId);
}
