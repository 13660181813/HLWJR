package cn.cvtt.safenumber.web.validator;

import cn.cvtt.safenumber.web.pojo.SNException;
import org.apache.commons.lang3.StringUtils;

/**
 * 数据校验
 * @author Yampery
 * @date 2017/6/9 15:19
 */
public class Assert {


    public static void isBlank(String str, String message) {
        if (StringUtils.isBlank(str)) {
            throw new SNException(message);
        }
    }

    public static void isNull(Object object, String message) {
        if (object == null) {
            throw new SNException(message);
        }
    }
}
