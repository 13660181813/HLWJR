package cn.cvtt.safenumber.web.service;

import cn.cvtt.safenumber.web.pojo.SysLogPojo;

import java.util.List;
import java.util.Map;

/**
 * 系统日志service
 * @author Yampery
 * @date 2017/6/15 16:17
 */
public interface SysLogService {

    SysLogPojo queryObject(Long id);

    List<SysLogPojo> queryList(Map<String, Object> map);

    int queryTotal(Map<String, Object> map);

    void save(SysLogPojo sysLog);

    void update(SysLogPojo sysLog);

    void delete(Long id);

    void deleteBatch(Long[] ids);
}
