package cn.cvtt.safenumber.web.controller;

import cn.cvtt.safenumber.common.api.SafeNumberService;
import cn.cvtt.safenumber.common.api.SnResponse;
import cn.cvtt.safenumber.common.model.SnUidSect;
import cn.cvtt.safenumber.common.model.SnUnit;
import cn.cvtt.safenumber.common.model.SnUnitKey;
import cn.cvtt.safenumber.common.model.pojo.CallSettings;
import cn.cvtt.safenumber.common.model.pojo.UnitParams;
import cn.cvtt.safenumber.common.model.pojo.UnitReserved;
import cn.cvtt.safenumber.web.model.SnUnitKeyValue;
import cn.cvtt.safenumber.web.model.UnitVo;
import cn.cvtt.safenumber.web.pojo.PageResult;
import cn.cvtt.safenumber.web.pojo.ResponsePojo;
import cn.cvtt.safenumber.web.pojo.SysUser;
import cn.cvtt.safenumber.web.service.SysUserService;
import cn.cvtt.safenumber.web.utils.CommonUtils;
import com.alibaba.fastjson.JSONObject;
import org.apache.commons.lang3.RandomStringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

/**
 * @author hushuai
 * @Description TODO
 * @date 2019/8/21
 */
@Controller
@RequestMapping("operationmanagement")
public class OperationPageController extends AbstractController {

    private static Logger logger = LoggerFactory.getLogger(OperationPageController.class);

    @Resource
    private SafeNumberService safeNumberService;
    @Resource
    private SysUserService sysUserService;
    @Value("${app.number.numberCount}")
    private int numberCount;//单次放号数量的最大值



    /**
     * 运营管理页面
     *
     * @param url 地址
     * @return
     */
    @RequestMapping("/{url}.html")
    public String numberPage(@PathVariable("url") String url) {
        String page = "operationmanagement/" + url + ".html";
        return page;
    }

    @RequestMapping("/list")
    @ResponseBody
    public ResponsePojo list(@RequestParam Map<String, Object> params) {

        List<SnUnitKeyValue> snUnitKeyValueList = null;
        int total = 0;

        /**
         * 更改为递归查询后不需要排除超级管理员，
         * 但是不再适合分页查询，由于用户一般不是很多，因此这里不再处理分页
         */

        //只有超级管理员，才能查看所有企业注册信息
        if (isAdmin()) {
            Map<SnUnitKey, SnUnit> units = safeNumberService.unitGetAll();
            snUnitKeyValueList = units.entrySet().stream().map(e -> new SnUnitKeyValue(e.getKey().getUnit_id(),
                    e.getValue().getPlatform_key(),
                    e.getValue().getSecret(),
                    e.getValue().getParams(),
                    e.getValue().getCallSettings(),
                    e.getValue().getType(),
                    e.getValue().getState(),
                    e.getValue().getReserved(),
                    e.getValue().getParamsObject().getExpire_time(),
                    e.getValue().getParamsObject().getReserve_time(),
                    e.getValue().getReservedObject().getUnit_name(),
                    e.getValue().getReservedObject().getUnit_mobile(),
                    e.getValue().getReservedObject().getUnit_telephone(),
                    e.getValue().getReservedObject().getUnit_contact(),
                    e.getValue().getReservedObject().getUnit_address(),
                    e.getValue().getReservedObject().getAdd_time()))
                    .sorted((s1, s2) -> {
                        if (Long.parseLong(s1.getUnit_id()) - Long.parseLong(s2.getUnit_id()) > 0) {
                            return 1;
                        }else {
                            return -1;
                        }
                    }).collect(Collectors.toList());
        } else {
            //其他用户不能查看，或者自定义查询
        }

        if (!CommonUtils.isNull(snUnitKeyValueList)) {
            total = snUnitKeyValueList.size();
        }
        PageResult result = new PageResult(snUnitKeyValueList, total, total, 1);
        return ResponsePojo.ok(result);

    }

    /**
     * 添加企业账户
     *
     * @param user 企业信息
     * @return
     */
    @RequestMapping("/unit/save")
    @ResponseBody
    public ResponsePojo save(@RequestBody UnitVo user) {
        //判断用户是否存在
        if (isUserExist(user.getUnitid(), null)){
            return ResponsePojo.error("该单位ID已存在");
        }
        /**--------------保存单位信息到ignite------------------*/
        logger.info("保存unit开始：unitid为："+user.getUnitid());
        UnitParams unitParams = new UnitParams();
        unitParams.setExpire_time(user.getExpiretime());
        unitParams.setReserve_time(user.getReservetime());
        UnitReserved unitReserved = new UnitReserved();
        unitReserved.setUnit_name(user.getUnitname());
        unitReserved.setUnit_telephone(user.getUnittelephone());
        unitReserved.setUnit_mobile(user.getUnitmobile());
        unitReserved.setUnit_contact(user.getUnitcontact());
        unitReserved.setUnit_address(user.getUnitaddress());
        unitReserved.setAdd_time(new Date());
        CallSettings callSettings_s = new CallSettings();
        callSettings_s.setCall_restrict((byte) 0);
        callSettings_s.setAnucode_aleg("1,1,1");
        callSettings_s.setAnucode_bleg("1,1,1");
        callSettings_s.setCall_display("0,0");
        callSettings_s.setCall_recording((byte) 0);
        CallSettings callSettings_p = new CallSettings();
        callSettings_p.setCall_restrict((byte) 0);
        callSettings_p.setAnucode_aleg("1,1,1");
        callSettings_p.setAnucode_bleg("1,1,1");
        callSettings_p.setCall_display("0,0");
        callSettings_p.setCall_recording((byte) 0);

        JSONObject callSettings = new JSONObject();
        callSettings.put("SCALLSETTINGS", callSettings_s);
        callSettings.put("PCALLSETTINGS", callSettings_p);
        String unitkey = RandomStringUtils.randomAlphanumeric(8);
        String appSecret = RandomStringUtils.randomAlphanumeric(16);
        SnResponse snResponse = safeNumberService.unitCreateSingle("1",
                new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()),
                "SafeNumber",
                user.getUnitid(),
                "web",
                getUser().getUsername(),
                unitkey,
                appSecret,
                JSONObject.toJSONString(unitParams),
                callSettings.toJSONString(),
                (byte) Integer.parseInt(user.getUnittype()),
                (byte) Integer.parseInt(user.getUnitstate()),
                JSONObject.toJSONString(unitReserved));
        if (snResponse.getCode() != 0) {
            logger.info("新增unit成功，unitid为："+user.getUnitid());
            return ResponsePojo.error(snResponse.getSub_msg());
        }
        logger.info("保存unit成功，unitid为："+user.getUnitid());
        /**--------------保存单位信息到ignite结束------------------*/
        //保存用户信息到mysql用户表
        // 如果不是超级管理员，则将单位id设置为该管理员单位id
        SysUser sysUser = new SysUser();
        //设置用户名为unitid
        sysUser.setUsername(user.getUnitid());
        sysUser.setPassword(user.getPassword());
        sysUser.setUnitid(Long.parseLong(user.getUnitid()));
        sysUser.setRoleIdList(user.getRoleIdList());
        sysUser.setName(user.getName());
        sysUser.setIsActive(1);
        if (!isAdmin()) {
            sysUser.setUnitid(getUnitid());
            sysUser.setApid(getApid());
        }
        sysUser.setCreateUserId(getUserId());
        sysUserService.save(sysUser);
        return ResponsePojo.ok();
    }

    /**
     * 修改用户
     *
     * @param user
     * @return
     */
    @RequestMapping("/unit/update")
    @ResponseBody
    public ResponsePojo update(@RequestBody UnitVo user) {
        SnUnit snUnit = safeNumberService.unitGetByUnitId(user.getUnitid());
        logger.info("修改unit开始：unitid为："+user.getUnitid());
        /**--------------保存单位信息到ignite------------------*/
        UnitParams unitParams = new UnitParams();
        unitParams.setExpire_time(user.getExpiretime());
        unitParams.setReserve_time(user.getReservetime());
        UnitReserved unitReserved = new UnitReserved();
        unitReserved.setUnit_name(user.getUnitname());
        unitReserved.setUnit_telephone(user.getUnittelephone());
        unitReserved.setUnit_mobile(user.getUnitmobile());
        unitReserved.setUnit_contact(user.getUnitcontact());
        unitReserved.setUnit_address(user.getUnitaddress());
        unitReserved.setAdd_time(snUnit.getReservedObject().getAdd_time());
        CallSettings callSettings_s = new CallSettings();
        callSettings_s.setCall_restrict(user.getsCallRestrict());
        callSettings_s.setAnucode_aleg(user.getsAnucodeAleg());
        callSettings_s.setAnucode_bleg(user.getsAnucodeBleg());
        callSettings_s.setCall_display(user.getsCallDisplay());
        callSettings_s.setCall_recording(user.getsCallRecording());
        CallSettings callSettings_p = new CallSettings();
        callSettings_p.setCall_restrict(user.getpCallRestrict());
        callSettings_p.setAnucode_aleg(user.getpAnucodeAleg());
        callSettings_p.setAnucode_bleg(user.getpAnucodeBleg());
        callSettings_p.setCall_display(user.getpCallDisplay());
        callSettings_p.setCall_recording(user.getpCallRecording());

        JSONObject callSettings = new JSONObject();
        callSettings.put("SCALLSETTINGS", callSettings_s);
        callSettings.put("PCALLSETTINGS", callSettings_p);

        SnResponse updateSingle = safeNumberService.unitUpdateSingle("1",
                new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()),
                "SafeNumber",
                user.getUnitid(),
                "web",
                getUser().getUsername(),
                user.getPlatformKey(),
                user.getSecret(),
                JSONObject.toJSONString(unitParams),
                callSettings.toJSONString(),
                (byte) Integer.parseInt(user.getUnittype()),
                (byte) Integer.parseInt(user.getUnitstate()),
                JSONObject.toJSONString(unitReserved));
        if (updateSingle.getCode() != 0) {
            logger.info("修改unit失败，unitid为："+user.getUnitid());
            return ResponsePojo.error(updateSingle.getSub_msg());
        }
        /**--------------保存单位信息到ignite结束------------------*/
        logger.info("修改unit成功，unitid为："+user.getUnitid());
        return ResponsePojo.ok();
    }

    /**
     * 根据unitid删除unit信息（包括企业下的用户信息）
     *
     * @param unitIds
     * @return
     */
    @RequestMapping("/unit/delete")
    @ResponseBody
    public ResponsePojo delete(@RequestBody String[] unitIds) {
        for (String unitId : unitIds) {
            logger.info("删除unit开始，unitid为："+unitId);
            //删除unit信息
            SnResponse snResponse = safeNumberService.unitDeleteSingle("1",
                    new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()),
                    "SafeNumber",
                    unitId,
                    "web",
                    getUser().getUsername());
            if (snResponse.getCode() != 0) {
                logger.error("删除unit失败，unitid为：" + unitId);
                return ResponsePojo.error(snResponse.getSub_msg());
            }
            logger.info("删除unit成功，unitid为："+unitId);
            //删除unit下的用户信息,删除用户角色关系表
            HashMap<String, Object> hashMap = new HashMap<>();
            hashMap.put("unitid", unitId);
            List<SysUser> sysUsers = sysUserService.queryList(hashMap);
            if (sysUsers != null && !sysUsers.isEmpty()) {
                List<Long> longs = new ArrayList<>();
                sysUsers.stream().forEach(sysUser -> {
                            longs.add(sysUser.getUserId());
                        }
                );
                Long[] array = longs.stream().toArray(Long[]::new);
                sysUserService.deleteBatch(array);
            }
        }
        return ResponsePojo.ok();
    }

    /**
     * 获取企业信息
     */
    @RequestMapping("/unit/info/{unitid}")
    @ResponseBody
    public ResponsePojo info(@PathVariable("unitid") String unitid) {
        UnitVo user = new UnitVo();
        SnUnit snUnit = safeNumberService.unitGetByUnitId(unitid);
        user.setUnitname(snUnit.getReservedObject().getUnit_name());
        user.setUnittelephone(snUnit.getReservedObject().getUnit_telephone());
        user.setUnitmobile(snUnit.getReservedObject().getUnit_mobile());
        user.setUnitcontact(snUnit.getReservedObject().getUnit_contact());
        user.setUnitaddress(snUnit.getReservedObject().getUnit_address());
        user.setExpiretime(snUnit.getParamsObject().getExpire_time());
        user.setReservetime(snUnit.getParamsObject().getReserve_time());
        user.setUnitid(unitid);
        Byte type = snUnit.getType();
        user.setUnittype(type.toString());
        user.setUnitstate(snUnit.getState().toString());
//回显详细参数
        CallSettings scallsettings = snUnit.getCallSettings("SCALLSETTINGS");
        user.setsAnucodeAleg(scallsettings.getAnucode_aleg());
        user.setsAnucodeBleg(scallsettings.getAnucode_bleg());
        user.setsCallDisplay(scallsettings.getCall_display());
        user.setsCallRecording(scallsettings.getCall_recording());
        user.setsCallRestrict(scallsettings.getCall_restrict());
        CallSettings pcallsettings = snUnit.getCallSettings("PCALLSETTINGS");
        user.setpAnucodeAleg(pcallsettings.getAnucode_aleg());
        user.setpAnucodeBleg(pcallsettings.getAnucode_bleg());
        user.setpCallDisplay(pcallsettings.getCall_display());
        user.setpCallRecording(pcallsettings.getCall_recording());
        user.setpCallRestrict(pcallsettings.getCall_restrict());
        user.setPlatformKey(snUnit.getPlatform_key());
        user.setSecret(snUnit.getSecret());
        return ResponsePojo.ok(user);
    }

    /**
     * 检查用户是否已经存在
     *
     * @param username
     * @return
     */
    private boolean isUserExist(String username, Long userId) {
        SysUser userCheck;
        userCheck = sysUserService.queryByUserName(username);
        long id = 0;
        if (null != userCheck)
            id = userCheck.getUserId();
        // 添加用户
        if (null == userId) {
            if (null != userCheck)
                return true;
        }

        // 修改用户
        else {
            if (null != userCheck && id != userId)
                return true;
        }

        return false;
    }

    /**
     * 放号界面展示
     * @param unitId
     * @return
     */
    @ResponseBody
    @RequestMapping("/number/list")
    public ResponsePojo queryNumber(String unitId) {
        if ("".equals(unitId)) {
            return null;
        }
        List<SnUidSect> returnmap = safeNumberService.uidSectGetByUnitId(unitId);
		
        if (returnmap != null) {
            returnmap.sort(Comparator.comparingInt(SnUidSect::getUid_type).thenComparing(SnUidSect::getUid_count));
            PageResult pageResult = new PageResult(returnmap, returnmap.size(), 15, 1);
            ResponsePojo result = ResponsePojo.ok(pageResult);
            return result;
        }else {
            return null;
        }
    }

    /**
     * 放号新增
     * @param qiyeId
     * @param beginNumber
     * @param endNumber
     * @param numberType
     * @return
     */
    @ResponseBody
    @RequestMapping("/number/save")
    public SnResponse safeNumber(String qiyeId,  String beginNumber,
                                  String endNumber,  int numberType){
        //限制单次输入
        SnResponse response = null;
        long i = Long.valueOf(endNumber) - Long.valueOf(beginNumber);
        System.out.println("ok"+numberCount);
        if (i+1>numberCount){
            response = new SnResponse(500,"","","单次放号数量不能超过"+numberCount,null);
            return response;
        }
        if (!(endNumber.length()==beginNumber.length())){
            response = new SnResponse(500,"","","开始UID位数需要与结束UID位数相同",null);
            return response;
        }
        beginNumber = "95013"+beginNumber;
        endNumber = "95013"+endNumber;
        logger.info("添加放号开始，企业id为"+qiyeId);
         response = safeNumberService.uidCreate("1",
                new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()),
                "SafeNumber",qiyeId,"web",
                "zhoulb",(byte)(0XFF & numberType),beginNumber,endNumber);
        if (response.getCode() != 0) {
            logger.info("添加放号失败");
            return response;
        }
        logger.info("添加放号成功");
        return response ;
    }

}
