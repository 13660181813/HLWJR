package cn.cvtt.safenumber.web.dao;

import cn.cvtt.safenumber.web.pojo.SysLogPojo;

/**
 * 系统日志dao
 * @author Yampery
 * @date 2017/6/15 16:15
 */
public interface SysLogDao extends BaseDao<SysLogPojo> {
}
