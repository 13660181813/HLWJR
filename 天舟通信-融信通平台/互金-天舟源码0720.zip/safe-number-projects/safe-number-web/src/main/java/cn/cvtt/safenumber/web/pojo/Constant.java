package cn.cvtt.safenumber.web.pojo;

/**
 * 常量
 * @author Yampery
 * @date 2017/6/9 10:08
 */
public class Constant {

    /** 超级管理员ID */
    public static final String SUPER_ADMIN = "super";

    /**
     * 95013号码正则表达式
     */
    public static final String REGIX_95013 = "^95013\\d{0,12}$";

    /**
     * 手机号或固话正则表达式
     */
    public static final String REGIX_PHONE = "^((0\\d{2,3}\\d{7,8})|(1[35784]\\d{9}))$";

    /**
     * 科学计数法正则表达式
     */
    public static final String REGIX_SCIENTIFIC_NOTATION = "^((-?\\d+.?\\d*)[Ee]{1}[+]?(-?\\d+))$";

    /**
     * 菜单类型
     *
     * @author Yampery
     * @date 2017/6/9 10:10
     */
    public enum MenuType {
        /**
         * 目录
         */
        CATALOG(0),
        /**
         * 菜单
         */
        MENU(1),
        /**
         * 按钮
         */
        BUTTON(2);

        private int value;

        private MenuType(int value) {
            this.value = value;
        }

        public int getValue() {
            return value;
        }
    }

    /**
     * 定时任务常量
     */
    public enum ScheduleStatus {
        /**
         * 正常
         */
        NORMAL(0),
        /**
         * 暂停
         */
        PAUSE(1);

        private int value;

        private ScheduleStatus(int value) {
            this.value = value;
        }

        public int getValue() {
            return value;
        }
    }
}
