package cn.cvtt.safenumber.web.pojo;

import java.io.Serializable;

/**
 * 用户角色对应
 * @author Yampery
 * @date 2017/6/8 15:10
 */
public class SysUserRole implements Serializable {

    private static final long serialVersionUID = 1L;

    private Long id;

    /**
     * 用户ID
     */
    private Long userId;

    /**
     * 角色ID
     */
    private Long roleId;

    /**
     * 角色类型
     */
    private int roleType;

    /**
     * 设置：
     * @param id
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * 获取：
     * @return Long
     */
    public Long getId() {
        return id;
    }

    /**
     * 设置：用户ID
     * @param userId 用户ID
     */
    public void setUserId(Long userId) {
        this.userId = userId;
    }

    /**
     * 获取：用户ID
     * @return Long
     */
    public Long getUserId() {
        return userId;
    }

    /**
     * 设置：角色ID
     * @param roleId 角色ID
     */
    public void setRoleId(Long roleId) {
        this.roleId = roleId;
    }

    /**
     * 获取：角色ID
     * @return Long
     */
    public Long getRoleId() {
        return roleId;
    }

    /**
     * 设置：角色类型
     * @param roleType 角色类型
     */
    public void setRoleType(int roleType) {
        this.roleType = roleType;
    }

    /**
     * 获取：角色类型
     * @return int
     */
    public int getRoleType() {
        return roleType;
    }
}
