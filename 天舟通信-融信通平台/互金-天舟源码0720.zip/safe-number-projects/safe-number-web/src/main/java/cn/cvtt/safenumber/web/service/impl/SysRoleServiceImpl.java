package cn.cvtt.safenumber.web.service.impl;

import cn.cvtt.safenumber.web.dao.SysRoleDao;
import cn.cvtt.safenumber.web.dao.SysUserRoleDao;
import cn.cvtt.safenumber.web.pojo.SNException;
import cn.cvtt.safenumber.web.pojo.SysRole;
import cn.cvtt.safenumber.web.pojo.SysUser;
import cn.cvtt.safenumber.web.service.SysRoleMenuService;
import cn.cvtt.safenumber.web.service.SysRoleService;
import cn.cvtt.safenumber.web.service.SysUserService;
import cn.cvtt.safenumber.web.utils.CommonUtils;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.*;

/**
 * @author Yampery
 * @date 2017/6/9 10:31
 */
@Service("SysRoleService")
public class SysRoleServiceImpl implements SysRoleService {

    @Resource
    private SysRoleDao sysRoleDao;
    @Resource
    private SysRoleMenuService sysRoleMenuService;
    @Lazy
    @Resource
    private SysUserService sysUserService;
    @Resource
    SysUserRoleDao sysUserRoleDao;

    @Override
    public SysRole queryObject(Long roleId) {
        return sysRoleDao.queryObject(roleId);
    }

    @Override
    public List<SysRole> queryList(Map<String, Object> map) {
        return sysRoleDao.queryList(map);
    }

    @Override
    public int queryTotal(Map<String, Object> map) {
        return sysRoleDao.queryTotal(map);
    }

    @Override
    @Transactional
    public void save(SysRole role) {
        role.setCreateTime(new Date());
        sysRoleDao.save(role);

        // 检查是否越权
        checkPrems(role);

        //保存角色与菜单关系
        sysRoleMenuService.saveOrUpdate(role.getRoleId(), role.getMenuIdList());
    }

    @Override
    @Transactional
    public void update(SysRole role) {
        sysRoleDao.update(role);

        // 判断是否越权
        checkPrems(role);

        //更新角色与菜单关系
        sysRoleMenuService.saveOrUpdate(role.getRoleId(), role.getMenuIdList());
    }

    @Override
    @Transactional
    public void deleteBatch(Long[] roleIds) {
        sysRoleDao.deleteBatch(roleIds);
    }

    @Override
    public List<Long> queryRoleIdList(Long createUserId) {
        return sysRoleDao.queryRoleIdList(createUserId);
    }

    @Override
    public SysRole queryByRoleName(String roleName) {
        return sysRoleDao.queryByRoleName(roleName);
    }

    @Override
    public List<SysRole> getRoleList(Long createUserId) {
        // 最终要返回的角色列表
        List<SysRole> list = new ArrayList<>();
        // 获取当前登录用户所创建的角色
        List<SysRole> roles = sysRoleDao.getRoleList(createUserId);
        list.addAll(roles);
        Map<String, Object> map = new HashMap<>();
        map.put("createUserId", createUserId);
        List<SysUser> users = sysUserService.queryChildren(map);
        if (!CommonUtils.isNull(users)) {
            for (SysUser user : users) {
                list.addAll(sysRoleDao.getRoleList(user.getUserId()));
            }
        }
        return list;

        /*if (null != roles && 0 < roles.size()) {
            for (SysRole role : roles) {
                Long roleId = role.getRoleId();
                List<Long> userIds = sysUserRoleDao.quetUserIdsByRole(roleId);
                if (null != userIds && 0 < userIds.size()) {
                    for (Long userId : userIds) {
                        list.addAll(getRoleList(userId));
                    } /// for end~
                }  /// if end ~
            } /// for end~
        } /// if end~

        return list;*/
    }

    /**
     * 检查权限是否越权
     */
    private void checkPrems(SysRole role){
        //如果不是超级管理员，则需要判断角色的权限是否超过自己的权限
        if( sysUserService.isAdmin(role.getCreateUserId())){
            return ;
        }

        //查询用户所拥有的菜单列表
        List<Long> menuIdList = sysUserService.queryAllMenuId(role.getCreateUserId());

        //判断是否越权
        if(!menuIdList.containsAll(role.getMenuIdList())){
            throw new SNException("新增角色的权限，已超出你的权限范围");
        }
    }
}
