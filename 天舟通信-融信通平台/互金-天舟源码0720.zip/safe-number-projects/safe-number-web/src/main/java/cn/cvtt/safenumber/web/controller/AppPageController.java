package cn.cvtt.safenumber.web.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * 应用页面管理
 * @author Yampery
 * @date 2017/6/12 14:16
 */
@Controller("AppPageController")
@RequestMapping("app")
public class AppPageController {

    /**
     * 号码管理页面
     * @param url 地址
     * @return
     */
    @RequestMapping("/number/{url}.html")
    public String numberPage(@PathVariable("url") String url){
        String page = "app/number/" + url + ".html";
        return page;
    }

    /**
     * 退单查询页面
     * @param url
     * @return
     */
    @RequestMapping("/{url}.html")
    public String orderPage(@PathVariable("url") String url){
        String page = "app/" + url + ".html";
        return page;
    }

    /**
     * 系统设置页面
     * @param url
     * @return
     */
    @RequestMapping("/system/{url}.html")
    public String systemPage(@PathVariable("url") String url){
        String page = "app/system/" + url + ".html";
        return page;
    }
}
