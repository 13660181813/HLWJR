package cn.cvtt.safenumber.web.dao;

import cn.cvtt.safenumber.web.pojo.SysMenu;

import java.util.List;

/**
 * 管理菜单dao
 * @author Yampery
 * @date 2017/6/13 13:34
 */
public interface SysMenuDao extends BaseDao<SysMenu> {

    /**
     * 根据父菜单，查询子菜单
     * @param parentId 父菜单ID
     */
    List<SysMenu> queryListParentId(Long parentId);

    /**
     * 获取不包含按钮的菜单列表
     */
    List<SysMenu> queryNotButtonList();

    /**
     * 查询用户的权限列表
     */
    List<SysMenu> queryUserList(Long userId);

    /**
     * 查看用户是否具有某项权限
     * @param userId
     * @param perm
     * @return
     */
    int queryUserPerm(Long userId, String perm);
}
