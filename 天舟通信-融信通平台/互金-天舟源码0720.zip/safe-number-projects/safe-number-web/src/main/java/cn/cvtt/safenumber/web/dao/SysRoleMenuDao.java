package cn.cvtt.safenumber.web.dao;

import cn.cvtt.safenumber.web.pojo.SysRoleMenu;

import java.util.List;

/**
 * 应用资源访问
 * @author Yampery
 * @date 2017/6/8 15:50
 */
public interface SysRoleMenuDao extends BaseDao<SysRoleMenu> {

    /**
     * 根据角色ID，获取菜单ID列表
     */
    List<Long> queryMenuIdList(Long roleId);
}
