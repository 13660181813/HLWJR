package cn.cvtt.safenumber.web.validator;

/**
 * 新增数据组
 * @author Yampery
 * @date 2017/6/8 15:39
 */
public interface AddGroup {
}
