package cn.cvtt.safenumber.web.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * 安全号统计
 */
@Controller
@RequestMapping("statistic")
public class StatisticController extends AbstractController{
    private static Logger logger = LoggerFactory.getLogger(StatisticController.class);

    /**
     * 运营管理页面
     *
     * @param url 地址
     * @return
     */
    @RequestMapping("/{url}.html")
    public String numberPage(@PathVariable("url") String url) {
        String page = "statistic/" + url + ".html";
        return page;
    }

}
