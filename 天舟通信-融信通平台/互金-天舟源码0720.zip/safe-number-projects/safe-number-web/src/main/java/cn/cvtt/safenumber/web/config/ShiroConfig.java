package cn.cvtt.safenumber.web.config;

import at.pollux.thymeleaf.shiro.dialect.ShiroDialect;
import cn.cvtt.safenumber.web.shiro.UserRealm;
import org.apache.shiro.realm.Realm;
import org.apache.shiro.spring.web.config.DefaultShiroFilterChainDefinition;
import org.apache.shiro.spring.web.config.ShiroFilterChainDefinition;
import org.springframework.aop.framework.autoproxy.DefaultAdvisorAutoProxyCreator;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ShiroConfig {

    @Bean
    public Realm realm() {
        return new UserRealm();
    }

    @Bean
    public ShiroFilterChainDefinition shiroFilterChainDefinition() {
        DefaultShiroFilterChainDefinition chainDefinition = new DefaultShiroFilterChainDefinition();
        //chainDefinition.addPathDefinition("/login.html", "authc"); // need to accept POSTs from the login form
        //chainDefinition.addPathDefinition("/logout", "logout");
        //chainDefinition.addPathDefinition("/**", "anon");
        //chainDefinition.addPathDefinition("/", "authc, roles[sys]");
        chainDefinition.addPathDefinition("/login.html", "anon");
        chainDefinition.addPathDefinition("/sys/login", "anon");
        chainDefinition.addPathDefinition("/static/**", "anon");
        chainDefinition.addPathDefinition("/captcha.jpg", "anon");
        chainDefinition.addPathDefinition("/**", "authc");
        return chainDefinition;
    }

    /**
     * thymeleaf-extras-shiro提供，为html提供shiro标签
     */
    @Bean
    public ShiroDialect shiroDialect() {
        return new ShiroDialect();
    }

    /**
     * 加入下面配置能解决如下问题:
     * 当引入spring cloud后，在@Controller注解的类的方法中加入@RequiresRole等shiro注解，会导致该方法无法映射请求，导致返回404。
     * 估计是跟spring cloud引入了spring aop有关
     */
    @Bean
    public DefaultAdvisorAutoProxyCreator defaultAdvisorAutoProxyCreator() {
        DefaultAdvisorAutoProxyCreator creator = new DefaultAdvisorAutoProxyCreator();
        //参考：https://www.cnblogs.com/kingsonfu/p/10388114.html
        creator.setProxyTargetClass(true);
        //参考：https://segmentfault.com/a/1190000014479154?utm_medium=hao.caibaojian.com&utm_source=hao.caibaojian.com&share_user=1030000000178452
        //creator.setUsePrefix(true);
        return creator;
    }
}
