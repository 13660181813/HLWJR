package cn.cvtt.safenumber.web.controller;

import cn.cvtt.safenumber.web.annotation.SysLog;
import cn.cvtt.safenumber.web.pojo.*;
import cn.cvtt.safenumber.web.service.SysMenuService;
import cn.cvtt.safenumber.web.utils.CommonUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author Yampery
 * @date 2017/6/13 14:05
 */
@RestController("SysMenuController")
@RequestMapping("/sys/menu")
public class SysMenuController extends AbstractController {

    // 应用菜单
    @Resource private SysMenuService sysMenuService;

    /**
     * 所有应用菜单列表
     */
    @RequestMapping("/list")
    @RequiresPermissions("sys:menu:list")
    public ResponsePojo list(@RequestParam Map<String, Object> params){
        //查询列表数据
        QueryParams queryParams = new QueryParams(params);
        List<SysMenu> menuList = sysMenuService.queryList(queryParams);
        int total = sysMenuService.queryTotal(queryParams);

        PageResult result = new PageResult(menuList, total, queryParams.getLimit(), queryParams.getPage());

        return ResponsePojo.ok(result);
    }

    /**
     * 选择菜单(添加、修改菜单)
     */
    @RequestMapping("/select")
    @RequiresPermissions("sys:menu:select")
    public ResponsePojo select(){
        //查询列表数据
        List<SysMenu> menuList = sysMenuService.queryNotButtonList();

        //添加顶级菜单
        SysMenu root = new SysMenu();
        root.setMenuId(0L);
        root.setName("一级菜单");
        root.setParentId(-1L);
        root.setOpen(true);
        menuList.add(root);

        return ResponsePojo.ok(menuList);
    }

    /**
     * 角色授权菜单（remark：用于之后的管理应用）
     */
    @RequestMapping("/perms")
    @RequiresPermissions("sys:menu:perms")
    public ResponsePojo perms(){

        //查询列表数据
        List<?> menuList = null;

        if(isAdmin()){
            //只有超级管理员，才能查看所有管理员列表
            menuList = sysMenuService.queryList(new HashMap<String, Object>());
        } else {
            menuList = sysMenuService.queryUserList(getUserId());
        }
        return ResponsePojo.ok(menuList);
    }

    /**
     * 菜单信息
     */
    @RequestMapping("/info/{menuId}")
    @RequiresPermissions("sys:menu:info")
    public ResponsePojo info(@PathVariable("menuId") Long menuId){
        SysMenu menu = sysMenuService.queryObject(menuId);
        return ResponsePojo.ok(menu);
    }

    /**
     * 保存
     */
    @SysLog("保存菜单")
    @RequestMapping("/save")
    @RequiresPermissions("sys:menu:save")
    public ResponsePojo save(@RequestBody SysMenu menu){
        //数据校验
        verifyForm(menu);

        sysMenuService.save(menu);

        return ResponsePojo.ok();
    }

    /**
     * 修改
     */
    @SysLog("修改菜单")
    @RequestMapping("/update")
    @RequiresPermissions("sys:menu:update")
    public ResponsePojo update(@RequestBody SysMenu menu){
        //数据校验
        verifyForm(menu);

        sysMenuService.update(menu);

        return ResponsePojo.ok();
    }

    /**
     * 删除
     */
    @SysLog("删除菜单")
    @RequestMapping("/delete")
    @RequiresPermissions("sys:menu:delete")
    public ResponsePojo delete(@RequestBody Long[] menuIds){
        for(Long menuId : menuIds){
            if(menuId.longValue() <= 30){
                return ResponsePojo.error("系统菜单，不能删除");
            }
        }
        sysMenuService.deleteBatch(menuIds);

        return ResponsePojo.ok();
    }

    /**
     * 用户菜单列表
     */
    @RequestMapping("/user")
    public ResponsePojo user(){
        List<SysMenu> menuList = null;
        try {
            menuList = sysMenuService.getUserMenuList(getUserId());
            SysMenu menu = menuList.get(0);
            if (StringUtils.isNotBlank(menu.getUrl()) && !StringUtils.equals("null", menu.getUrl())) {

            } else{
                List list = menu.getList();
                if (!CommonUtils.isNull(list)) {
                    SysMenu mainMenu = (SysMenu) list.get(0);
                    menuList.get(0).setUrl(mainMenu.getUrl());
                }
            }
        } catch (Exception e) {
            System.out.println("查询菜单列表异常：" + e.getMessage() + "----- menuList = "+ menuList);
            return ResponsePojo.error(e.getMessage());
        }
        return ResponsePojo.ok(menuList);
    }

    /**
     * 验证参数是否正确
     */
    private void verifyForm(SysMenu menu){
        if(StringUtils.isBlank(menu.getName())){
            throw new SNException("菜单名称不能为空");
        }

        if(menu.getParentId() == null){
            throw new SNException("上级菜单不能为空");
        }

        //菜单
        if(menu.getType() == Constant.MenuType.MENU.getValue()){
            if(StringUtils.isBlank(menu.getUrl())){
                throw new SNException("菜单URL不能为空");
            }
        }

        //上级菜单类型
        int parentType = Constant.MenuType.CATALOG.getValue();
        if(menu.getParentId() != 0){
            SysMenu parentMenu = sysMenuService.queryObject(menu.getParentId());
            parentType = parentMenu.getType();
        }

        //目录、菜单
        if(menu.getType() == Constant.MenuType.CATALOG.getValue() ||
                menu.getType() == Constant.MenuType.MENU.getValue()){
            if(parentType != Constant.MenuType.CATALOG.getValue()){
                throw new SNException("上级菜单只能为目录类型");
            }
            return ;
        }

        //按钮
        if(menu.getType() == Constant.MenuType.BUTTON.getValue()){
            if(parentType != Constant.MenuType.MENU.getValue()){
                throw new SNException("上级菜单只能为菜单类型");
            }
            return ;
        }
    }
}
