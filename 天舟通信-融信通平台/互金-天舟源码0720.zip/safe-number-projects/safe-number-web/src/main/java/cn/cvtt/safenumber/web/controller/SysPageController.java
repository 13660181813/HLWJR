package cn.cvtt.safenumber.web.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * @author Yampery
 * @date 2017/6/13 14:34
 */
@Controller("SysPageController")
public class SysPageController {

    @RequestMapping("sys/{url}.html")
    public String page(@PathVariable("url") String url){
        return "sys/" + url + ".html";
    }

    @RequestMapping("generator/{url}.html")
    public String generator(@PathVariable("url") String url){
        return "generator/" + url + ".html";
    }

    @RequestMapping("tcs/{url}.html")
    public String bill(@PathVariable("url") String url) {
        return "tcs/" + url + ".html";
    }

}
