package cn.cvtt.safenumber.web;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.cloud.openfeign.EnableFeignClients;

@MapperScan("cn.cvtt.safenumber.web.dao")
//注：如果是调用所依赖的module中的@Component注解的bean，则需设定@ComponentScan的basePackages(或者将本Application类所在包名与所依赖bean的包名设为同一包名)，否则会提示找不到所需的bean
//@ComponentScan(basePackages = {"cn.cvtt.safenumber.web", "cn.cvtt.safenumber.common"})
//注：如果是调用所依赖的module中的@FeignClient注解的bean，则需设定@EnableFeignClients的basePackages，否则会提示找不到所需bean
@EnableFeignClients(basePackages = "cn.cvtt.safenumber.common.api")
@EnableEurekaClient
@SpringBootApplication
public class SafeNumberWebApplication {

    public static void main(String[] args) {
        SpringApplication.run(SafeNumberWebApplication.class, args);
    }

}
