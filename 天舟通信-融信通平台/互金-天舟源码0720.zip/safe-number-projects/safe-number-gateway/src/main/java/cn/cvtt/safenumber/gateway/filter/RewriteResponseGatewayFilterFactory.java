package cn.cvtt.safenumber.gateway.filter;

import cn.cvtt.safenumber.common.service.SnLastCallService;
import cn.cvtt.safenumber.common.vo.LastCallVo;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import org.apache.commons.lang.StringUtils;
import org.springframework.cloud.gateway.filter.GatewayFilter;
import org.springframework.cloud.gateway.filter.factory.rewrite.ModifyResponseBodyGatewayFilterFactory;
import org.springframework.cloud.gateway.filter.factory.rewrite.RewriteFunction;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import javax.annotation.Resource;
import java.util.Date;

@Component
public class RewriteResponseGatewayFilterFactory
        extends ModifyResponseBodyGatewayFilterFactory {

    @Resource
    private SnLastCallService snLastCallService;

    @Override
    public GatewayFilter apply(Config config) {
        return new ModifyResponseGatewayFilter(this.getConfig());
    }

    private Config getConfig() {
        Config config = new Config();
        // Config.setRewriteFunction(Class<T> inClass, Class<R> outClass, RewriteFunction<T, R> rewriteFunction)
        // inClass 原数据类型，可以指定为具体数据类型，原作者说:"这里可以指定为Object,是为了处理多种数据类型。当然支持多接口返回多数据类型的统一修改，yaml中的配置，path,uri需要做相关调整"
        // 但测试发现，如果inClass指定为Object，若与我编写的RewriteRequestGatewayFilterFactory配合，当authenticate失败直接返回时(StatusCode设为200OK)，
        // 会报Content type 'application/octet-stream' not supported for bodyType=java.lang.Object错误，即使在RewriteRequestGatewayFilterFactory中指定Content type为application/json也不行
        // 同时当RewriteRequestGatewayFilterFactory转发到了后端，后端返回Content type为text/plain时，也会报类似错误，所以将inClass设置为String
        // outClass 目标数据类型
        // rewriteFunction 内容重写方法
        config.setRewriteFunction(String.class, String.class, getRewriteFunction());
        return config;
    }

    private RewriteFunction<String, String> getRewriteFunction() {
        //return (exchange, resp) -> Mono.just(UnionResult.builder().requestId(exchange.getRequest().getHeaders().getFirst("cn-buddie.demo.requestId")).result(resp).build());
        return (exchange, response) -> {
            // 如果header中有X-Response-Direct，说明是前序RewriteRequestGatewayFilterFactory直接返回，则不修改返回结果
            //if (exchange.getResponse().getHeaders().getFirst("X-Response-Direct") != null)
            //    return Mono.just(response);
            //else {
                String responseType = exchange.getResponse().getHeaders().getFirst("X-Response-Type");
                if (StringUtils.isNotBlank(responseType)) {
                    JSONObject responseObject;
                    try {
                        responseObject = JSON.parseObject(response);
                    } catch (Exception e) {
                        responseObject = null;
                    }
                    if (responseObject != null) {
                        if (responseType.equals("call_query")) {
                            // responseType == call_query的时候不用区分code
                            return Mono.just(convertResponse(responseType, responseObject, ""));
                        } else if (responseType.equals("two_way_call")) {
                            // responseType == two_way_call的时候不用修改结果，但要根据成功还是失败决定是否调用service写last call
                            try {
                                if (responseObject.getJSONObject("twowaycall_response").getInteger("result") == 0) {
                                    LastCallVo lastCallVo = new LastCallVo();
                                    lastCallVo.setSub_service(exchange.getRequest().getQueryParams().getFirst("unitID"));
                                    lastCallVo.setCallee(exchange.getResponse().getHeaders().getFirst("X-Last-Call-callee"));
                                    lastCallVo.setDisplay_code(exchange.getResponse().getHeaders().getFirst("X-Last-Call-display_code"));
                                    lastCallVo.setCaller(exchange.getResponse().getHeaders().getFirst("X-Last-Call-caller"));
                                    lastCallVo.setCalled(exchange.getResponse().getHeaders().getFirst("X-Last-Call-called"));
                                    lastCallVo.setStart_time(new Date());
                                    snLastCallService.addSingle(lastCallVo.getSub_service(), lastCallVo.getCallee(), lastCallVo.getDisplay_code(), lastCallVo.getCaller(), lastCallVo.getCalled(), lastCallVo.getStart_time());
                                }
                            } catch (Exception e) {
                            }

                        } else {
                            Integer code = responseObject.getInteger("code");
                            if (code != null) {
                                if (code.equals(0)) {
                                    // 重组并返回正常响应包
                                    String unitID = exchange.getRequest().getQueryParams().getFirst("unitID");
                                    return Mono.just(convertResponse(responseType, responseObject, unitID));
                                } else {
                                    // 重组并返回错误响应包
                                    JSONObject rewriteRespone = new JSONObject();
                                    rewriteRespone.put("error_response", responseObject);
                                    return Mono.just(rewriteRespone.toJSONString());
                                }
                            }
                        }
                    }
                }
                return Mono.just(response);
            //}
        };
    }

    private String convertResponse(String responseType, JSONObject responseObject, String unitID) {
        switch (responseType) {
            case "user_register":
                return convertToRegisterResponse(responseObject, unitID);
            case "user_recover":
                return convertToRecoverResponse(responseObject, unitID);
            case "user_unregister":
                return convertToUnregisterResponse(responseObject, unitID);
            case "call_query":
                return convertToCallQueryResponse(responseObject);
            default:
                break;
        }
        return responseObject.toJSONString();
    }

    private String convertToRegisterResponse(JSONObject responseObject, String unitID) {
        JSONObject data = responseObject.getJSONObject("data");
        if (data != null) {
            JSONObject response = new JSONObject();
            JSONObject responseBody = new JSONObject();

            responseBody.put("result", 0);
            responseBody.put("unitID", unitID);
            responseBody.put("bind_id", data.getString("sub_id"));
            responseBody.put("prtms", data.getString("reg_phone"));
            responseBody.put("smbms", data.getString("uid"));
            responseBody.put("otherms", data.getString("contacts"));
            responseBody.put("subts", data.getString("reg_time"));
            responseBody.put("uidType", data.getString("uid_type"));
            responseBody.put("callrestrict", data.getString("call_restrict"));

            JSONObject settings = JSON.parseObject(data.getString("settings"));
            if (settings != null) {
                responseBody.put("calldisplay", settings.getString("call_display"));
                responseBody.put("callrecording", settings.getString("call_recording"));
                responseBody.put("anucode", settings.getString("anucode_aleg"));
                responseBody.put("bnucode", settings.getString("anucode_bleg"));
            }

            responseBody.put("validitytime", data.getString("expire_time"));
            responseBody.put("uuidinpartner", data.getString("uuid_in_partner"));

            response.put("binding_Relation_response", responseBody);

            return response.toJSONString();
        }
        return responseObject.toJSONString();
    }

    private String convertToRecoverResponse(JSONObject responseObject, String unitID) {
        JSONObject data = responseObject.getJSONObject("data");
        if (data != null) {
            JSONObject response = new JSONObject();
            JSONObject responseBody = new JSONObject();

            responseBody.put("result", 0);

            response.put("recover_Relation_response", responseBody);

            return response.toJSONString();
        }
        return responseObject.toJSONString();
    }

    private String convertToUnregisterResponse(JSONObject responseObject, String unitID) {
        JSONObject data = responseObject.getJSONObject("data");
        if (data != null) {
            JSONObject response = new JSONObject();
            JSONObject responseBody = new JSONObject();

            responseBody.put("result", 0);

            response.put("binding_Relation_response", responseBody);

            return response.toJSONString();
        }
        return responseObject.toJSONString();
    }

    private String convertToCallQueryResponse(JSONObject responseObject) {
        JSONObject data = responseObject.getJSONObject("data");
        if (data != null) {
            JSONObject response = new JSONObject();
            JSONObject responseBody = new JSONObject();

            responseBody.put("op_type", data.getByte("op_type"));
            responseBody.put("call_type", data.getByte("call_type"));
            responseBody.put("call_in_no", data.getString("callee"));
            responseBody.put("play_code", data.getString("play_code"));
            responseBody.put("display_code", data.getString("display_code"));
            responseBody.put("record", data.getBoolean("record"));
            responseBody.put("partner_id_real", data.getString("unit_id_real"));
            responseBody.put("last_call_time", data.getString("last_call_time"));
            responseBody.put("bind_id", data.getString("sub_id"));
            responseBody.put("regtime", data.getLong("reg_time"));
            responseBody.put("request_id", data.getString("uuid_in_partner"));

            response.put("secret_call_control_response", responseBody);

            return response.toJSONString();
        }
        return responseObject.toJSONString();
    }
}