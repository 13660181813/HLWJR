package cn.cvtt.safenumber.gateway;

import cn.cvtt.safenumber.gateway.filter.BodyToRequestUriFilterFactory;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.web.ServerProperties;
import org.springframework.cloud.gateway.route.RouteLocator;
import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import reactor.core.publisher.Mono;

import javax.annotation.Resource;

//测试发现在gateway的filter中使用FeignClient调用其他服务性能低
//@EnableFeignClients(basePackages = "cn.cvtt.safenumber.common.api")
@ComponentScan(basePackages = {"cn.cvtt.safenumber.gateway", "cn.cvtt.safenumber.common"})
@SpringBootApplication
public class SafeNumberGatewayApplication {

    @Value("${route.post-to-get.uri:}")
    private String postToGetUri;

    @Resource
    private ServerProperties serverProperties;

    @Resource
    private BodyToRequestUriFilterFactory bodyToRequestUriFilterFactory;

    public static void main(String[] args) {
        SpringApplication.run(SafeNumberGatewayApplication.class, args);
    }

    @Bean
    public RouteLocator routeLocator(RouteLocatorBuilder builder) {
        // 如果未配置postToGetUri
        if (StringUtils.isBlank(postToGetUri)) {
            // 使用本网关的服务ip和port作为postToGetUri
            int port = serverProperties.getPort() == null ? 8080 : serverProperties.getPort();
            String address = serverProperties.getAddress() == null ? "127.0.0.1" : serverProperties.getAddress().getHostAddress();
            postToGetUri = "http://" + address + ":" + port;
        }
        return builder.routes()
                // 利用ReadBodyPredicateFactory和自定义的BodyToRequestUriFilterFactory实现post到get的转换
                // ReadBody会自动把request body缓存在ServerWebExchange的attributes中，供后续filter处理
                // 注:此种方式下，request body不被修改，会被继续转发出去
//                .route("post-to-get",
//                        r -> r.method(HttpMethod.POST)
//                                .and()
//                                .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_FORM_URLENCODED_VALUE)
//                                .and()
//                                .readBody(String.class, readBody -> true)
//                                .filters(f -> f.filter(bodyToRequestUriFilterFactory.apply(new BodyToRequestUriFilterFactory.Config())))
//                                .uri(postToGetUri))
                // 利用ModifyRequestBody和自定义的BodyToRequestUriFilterFactory实现post到get的转换
                // 在ModifyRequestBody的RewriteFunction中获取request body并缓存在ServerWebExchange的attributes中，供后续filter处理，同时删除body内容(测试发现必须返回一个非blank的字符串，所以目前返回一个"=")
                .route("post-to-get",
                        r -> r.method(HttpMethod.POST)
                                .and()
                                .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_FORM_URLENCODED_VALUE)
                                .filters(f -> f
                                        .modifyRequestBody(String.class, String.class, MediaType.APPLICATION_FORM_URLENCODED_VALUE, (exchange, s) -> {
                                            exchange.getAttributes().put("cachedRequestBodyObject", s); // 缓存到exchange的attributes中，后续filter可使用
                                            return Mono.just("=");  // 测试发现必须返回一个非blank的字符串
                                        })
                                        .filter(bodyToRequestUriFilterFactory.apply(new BodyToRequestUriFilterFactory.Config())))
                                .uri(postToGetUri))
                .build();
    }

}
