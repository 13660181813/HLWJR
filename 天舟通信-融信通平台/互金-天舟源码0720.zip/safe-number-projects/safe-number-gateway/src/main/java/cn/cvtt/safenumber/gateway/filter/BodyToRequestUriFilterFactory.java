package cn.cvtt.safenumber.gateway.filter;

import org.springframework.cloud.gateway.filter.GatewayFilter;
import org.springframework.cloud.gateway.filter.factory.AbstractGatewayFilterFactory;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

import java.net.URI;

/**
 * 取出exchange中名为"cachedRequestBodyObject"的Attribute（之前的filter缓存的post body），作为get方法的query
 */
@Component
public class BodyToRequestUriFilterFactory
        extends AbstractGatewayFilterFactory<BodyToRequestUriFilterFactory.Config> {

    private static final String CACHE_REQUEST_BODY_OBJECT_KEY = "cachedRequestBodyObject";

    @Override
    public GatewayFilter apply(Config config) {
        return (exchange, chain) -> {
            String requestBody = exchange.getAttribute(CACHE_REQUEST_BODY_OBJECT_KEY);

            // 将requestBody作为Get的Query
            UriComponents uriComponents = UriComponentsBuilder.fromUri(exchange.getRequest().getURI()).replaceQuery(requestBody).build();
            URI uri;
            try {
                uri = new URI(uriComponents.toUriString()); // 不encode
            } catch (Exception ignore) {
                uri = uriComponents.toUri();    // encode
            }

            return chain.filter(exchange.mutate().request(exchange.getRequest().mutate().method(HttpMethod.GET).uri(uri).build()).build());
        };
    }

    public static class Config {
    }
}
