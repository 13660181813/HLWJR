package cn.cvtt.safenumber.gateway.filter;

import cn.cvtt.safenumber.common.api.SnResponse;
import cn.cvtt.safenumber.common.exception.BusinessException;
import cn.cvtt.safenumber.common.exception.SecureValidExceptionEnum;
import cn.cvtt.safenumber.common.model.SnUnit;
import cn.cvtt.safenumber.common.service.CallService;
import cn.cvtt.safenumber.common.service.SnUnitService;
import cn.cvtt.safenumber.common.util.SignUtil;
import cn.cvtt.safenumber.common.vo.TwoWayCallVo;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import org.apache.commons.lang.StringUtils;
import org.springframework.cloud.gateway.filter.GatewayFilter;
import org.springframework.cloud.gateway.filter.factory.AbstractGatewayFilterFactory;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;
import org.springframework.web.util.UriComponentsBuilder;
import reactor.core.publisher.Mono;

import javax.annotation.Resource;
import java.io.IOException;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.util.*;

/**
 * 实现签名检查和转换请求格式和方法的功能
 */
@Component
public class RewriteRequestGatewayFilterFactory
        extends AbstractGatewayFilterFactory<RewriteRequestGatewayFilterFactory.Config> {

    @Resource
    private SnUnitService snUnitService;

    @Resource
    private CallService callService;

    public RewriteRequestGatewayFilterFactory() {
        super(Config.class);
    }

    @Override
    public List<String> shortcutFieldOrder() {
        return Arrays.asList("requestType", "checkAuth", "idField", "keyField", "signField");
    }

    @Override
    public GatewayFilter apply(Config config) {

        if (config.requestType == null) throw new RuntimeException("'requestType' must be assigned for RewriteRequest filter.");

        return (exchange, chain) -> {
            ServerHttpRequest request = exchange.getRequest();

            if ( config.isCheckAuth() ) {
                SecureValidExceptionEnum error = authenticate(request.getQueryParams(), config);
                if (error != null) {
                    ServerHttpResponse response = exchange.getResponse();

                    response.getHeaders().add("Content-Type", "application/json;charset=UTF-8");
                    //response.getHeaders().add("X-Response-Direct", "true");   // 后续filter可以根据此header判断是否需要修改response(后改为不添加此header,后续filter根据是否有X-Response-Type header来判断)

                    JSONObject errorResponseBody = new JSONObject();
                    errorResponseBody.put("code", error.getCode());
                    errorResponseBody.put("msg", error.getMessage());
                    errorResponseBody.put("sub_code", error.getSubCode());
                    errorResponseBody.put("sub_msg", error.getSubMessage());
                    JSONObject errorResponse = new JSONObject();
                    errorResponse.put("error_response", errorResponseBody);

                    response.setStatusCode(HttpStatus.OK);
                    //response.setStatusCode(HttpStatus.UNAUTHORIZED);
                    //return response.setComplete();    // setComplete后，后续filter将不被调用
                    return response.writeWith( Mono.just(
                            response.bufferFactory().wrap(errorResponse.toJSONString().getBytes(StandardCharsets.UTF_8)) ) );
                }
            }

            switch (config.getRequestType()) {
                case "user_register":
                {
                    URI uri = UriComponentsBuilder.fromUri(request.getURI()).replaceQuery(convertToRegisterQuery(request.getQueryParams())).build().toUri();
                    return chain.filter(exchange.mutate().request(request.mutate().method(HttpMethod.POST).uri(uri).build()).build());
                }
                case "user_recover":
                {
                    URI uri = UriComponentsBuilder.fromUri(request.getURI()).replaceQuery(convertToRecoverQuery(request.getQueryParams())).build().toUri();
                    return chain.filter(exchange.mutate().request(request.mutate().method(HttpMethod.PATCH).uri(uri).build()).build());
                }
                case "user_unregister":
                {
                    URI uri = UriComponentsBuilder.fromUri(request.getURI()).replaceQuery(convertToUnregisterQuery(request.getQueryParams())).build().toUri();
                    return chain.filter(exchange.mutate().request(request.mutate().method(HttpMethod.DELETE).uri(uri).build()).build());
                }
                case "call_query":
                {
                    URI uri = UriComponentsBuilder.fromUri(request.getURI()).replaceQuery(convertToCallQueryQuery(request.getQueryParams())).build().toUri();
                    return chain.filter(exchange.mutate().request(request.mutate().method(HttpMethod.GET).uri(uri).build()).build());
                }
                case "two_way_call":
                {
                    SnResponse<String> snResponse = convertToTwoWayCallQuery(request.getQueryParams(), exchange.getResponse());
                    if (snResponse.getCode() == 0) {
                        URI uri = UriComponentsBuilder.fromUri(request.getURI()).replaceQuery(snResponse.getData()).build().encode().toUri();
                        return chain.filter(exchange.mutate().request(request.mutate().method(HttpMethod.GET).uri(uri).build()).build());
                    } else  {
                        ServerHttpResponse response = exchange.getResponse();

                        response.getHeaders().add("Content-Type", "application/json;charset=UTF-8");
                        //response.getHeaders().add("X-Response-Direct", "true");   // 后续filter可以根据此header判断是否需要修改response（后改为不添加此header,后续filter根据是否有X-Response-Type header来判断）

                        JSONObject errorResponse = new JSONObject();
                        errorResponse.put("error_response", JSON.toJSON(snResponse));

                        response.setStatusCode(HttpStatus.OK);
                        return response.writeWith( Mono.just(
                                response.bufferFactory().wrap(errorResponse.toJSONString().getBytes(StandardCharsets.UTF_8)) ) );
                    }
                }
                default:
                    break;
            }
            return chain.filter(exchange);
        };
    }

    public static class Config {

        private String requestType;

        private boolean checkAuth;

        private String idField;

        private String keyField;

        private String signField;

        public Config() {
            this.checkAuth = true;
            this.idField = "unitID";
            this.keyField = "appkey";
            this.signField = "sid";
        }

        public String getRequestType() {
            return requestType;
        }

        public void setRequestType(String requestType) {
            this.requestType = requestType;
        }

        public boolean isCheckAuth() {
            return checkAuth;
        }

        public void setCheckAuth(boolean checkAuth) {
            this.checkAuth = checkAuth;
        }

        public String getIdField() {
            return idField;
        }

        public void setIdField(String idField) {
            this.idField = idField;
        }

        public String getKeyField() {
            return keyField;
        }

        public void setKeyField(String keyField) {
            this.keyField = keyField;
        }

        public String getSignField() {
            return signField;
        }

        public void setSignField(String signField) {
            this.signField = signField;
        }
    }

    private SecureValidExceptionEnum authenticate(MultiValueMap<String, String> queryParams, Config config) {

        // 将queryParams转换为Map<String, String>（不包括签名字段），一个字段有多个值时用","拼接
        String sign = "";
        Map<String, String> parameterMap = new HashMap<>();
        for (Map.Entry<String, List<String>> entry : queryParams.entrySet()) {
            if (config.getSignField().equals(entry.getKey())) {
                sign = String.join(",", entry.getValue());
            } else {
                parameterMap.put(entry.getKey(), String.join(",", entry.getValue()));
            }
        }

        // 从请求中取出并检查鉴权所需的字段
        String id = parameterMap.get(config.getIdField());
        if (StringUtils.isBlank(id)) return SecureValidExceptionEnum.ERR_ID;
        String key = parameterMap.get(config.getKeyField());
        if (StringUtils.isBlank(key)) return SecureValidExceptionEnum.ERR_KEY;
        if (StringUtils.isBlank(sign)) return SecureValidExceptionEnum.ERR_SIGN;

        // 查询platform_key和secret
        SnUnit snUnit = snUnitService.getByUnitId(id);
        if (snUnit == null) return SecureValidExceptionEnum.ERR_ID;

        // 比较key和sign
        try {
            if (!StringUtils.equals(snUnit.getPlatform_key(), key)) return SecureValidExceptionEnum.ERR_KEY;
            String signCalculated = SignUtil.signTopRequest(parameterMap, snUnit.getSecret(), "MD5");
            if (StringUtils.equalsIgnoreCase(sign, signCalculated))
                return null;
            else
                return SecureValidExceptionEnum.ERR_SIGN;
        } catch (IOException e) {
            return SecureValidExceptionEnum.ERR_SIGN;
        }
    }

    private String convertToRegisterQuery(MultiValueMap<String, String> originQuery) {
        StringBuilder queryBuilder = new StringBuilder();

        JSONObject settings = new JSONObject();
        for (String key : originQuery.keySet()) {

            if (key.equals("msgtype")) continue;
            if (key.equals("producttype")) continue;
            if (key.equals("productcat")) continue;
            if (key.equals("sid")) continue;
            if (key.equals("appkey")) continue;
            if (key.equals("ver")) continue;

            for (String value : originQuery.get(key)) {
                String newKey;
                switch (key) {
                    //case "ver":
                    //    newKey = key;
                    //    value = "3.0";
                    //    break;
                    case "msgid":
                        newKey = "msg_id";
                        break;
                    //case "sid":
                    //    newKey = "sign";
                    //    break;
                    //case "appkey":
                    //    newKey = "platform_key";
                    //    break;
                    case "opmodule":
                        newKey = "op_module";
                        break;
                    case "opuser":
                        newKey = "op_user";
                        break;

                    case "unitID":
                        newKey = "sub_service";
                        break;
                    case "prtms":
                        newKey = "reg_phone";
                        break;
                    case "smbms":
                        newKey = "uid";
                        break;
                    case "otherms":
                        newKey = "contacts";
                        break;
                    case "subts":
                        newKey = "reg_time";
                        break;
                    case "productid":
                        newKey = "product_type";
                        break;
                    case "uidType":
                        newKey = "uid_type";
                        break;
                    case "callrestrict":
                        newKey = "call_restrict";
                        break;
                    case "validitytime":
                        newKey = "expire_time";
                        break;
                    case "uuidinpartner":
                        newKey = "uuid_in_partner";
                        break;

                    case "calldisplay":
                        newKey = "settings";
                        settings.put("call_display", value);
                        break;
                    case "callrecording":
                        newKey = "settings";
                        settings.put("call_recording", value);
                        break;
                    case "anucode":
                        newKey = "settings";
                        settings.put("anucode_aleg", value);
                        break;
                    case "bnucode":
                        newKey = "settings";
                        settings.put("anucode_bleg", value);
                        break;

                    //case "ts":
                    //case "service":
                    //case "rsvd":
                    default:
                        newKey = key;
                        break;
                }
                if (!StringUtils.equals(newKey, "settings"))
                    queryBuilder.append(newKey).append("=").append(value).append("&");
            }
        }
        queryBuilder.append("settings=").append(settings.toJSONString());

        String query = queryBuilder.toString();
        if (query.endsWith("&"))
            query = query.substring(0, query.length()-1);
        return query;
    }

    private String convertToRecoverQuery(MultiValueMap<String, String> originQuery) {
        StringBuilder queryBuilder = new StringBuilder();

        JSONObject settings = new JSONObject();
        for (String key : originQuery.keySet()) {

            if (key.equals("msgtype")) continue;
            if (key.equals("producttype")) continue;
            if (key.equals("productcat")) continue;
            if (key.equals("sid")) continue;
            if (key.equals("appkey")) continue;
            if (key.equals("ver")) continue;

            for (String value : originQuery.get(key)) {
                String newKey;
                switch (key) {
                    //case "ver":
                    //    newKey = key;
                    //    value = "3.0";
                    //    break;
                    case "msgid":
                        newKey = "msg_id";
                        break;
                    //case "sid":
                    //    newKey = "sign";
                    //    break;
                    //case "appkey":
                    //    newKey = "platform_key";
                    //    break;
                    case "opmodule":
                        newKey = "op_module";
                        break;
                    case "opuser":
                        newKey = "op_user";
                        break;

                    case "unitID":
                        newKey = "sub_service";
                        break;
                    case "prtms":
                        newKey = "reg_phone";
                        break;
                    case "smbms":
                        newKey = "uid";
                        break;
                    case "validitytime":
                        newKey = "expire_time";
                        break;

                    //case "ts":
                    //case "service":
                    //case "rsvd":
                    default:
                        newKey = key;
                        break;
                }
                queryBuilder.append(newKey).append("=").append(value).append("&");
            }
        }

        String query = queryBuilder.toString();
        if (query.endsWith("&"))
            query = query.substring(0, query.length()-1);
        return query;
    }

    private String convertToUnregisterQuery(MultiValueMap<String, String> originQuery) {
        StringBuilder queryBuilder = new StringBuilder();

        for (String key : originQuery.keySet()) {

            if (key.equals("msgtype")) continue;
            if (key.equals("sid")) continue;
            if (key.equals("appkey")) continue;
            if (key.equals("ver")) continue;

            for (String value : originQuery.get(key)) {
                String newKey;
                switch (key) {
                    //case "ver":
                    //    newKey = key;
                    //    value = "3.0";
                    //    break;
                    case "msgid":
                        newKey = "msg_id";
                        break;
                    //case "sid":
                    //    newKey = "sign";
                    //    break;
                    //case "appkey":
                    //    newKey = "platform_key";
                    //    break;
                    case "opmodule":
                        newKey = "op_module";
                        break;
                    case "opuser":
                        newKey = "op_user";
                        break;

                    case "unitID":
                        newKey = "sub_service";
                        break;
                    case "regphone":
                        newKey = "reg_phone";
                        break;
                    case "smbms":
                        newKey = "uid";
                        break;
                    case "uuidinpartner":
                        newKey = "uuid_in_partner";
                        break;
                    case "cancelPassport":
                        newKey = "cancel_calling_service";
                        break;

                    //case "ts":
                    //case "service":
                    //case "rsvd":
                    default:
                        newKey = key;
                        break;
                }
                queryBuilder.append(newKey).append("=").append(value).append("&");
            }
        }

        String query = queryBuilder.toString();
        if (query.endsWith("&"))
            query = query.substring(0, query.length()-1);
        return query;
    }

    private String convertToCallQueryQuery(MultiValueMap<String, String> originQuery) {
        StringBuilder queryBuilder = new StringBuilder();

        for (String key : originQuery.keySet()) {

            if (key.equals("method")) continue;
            if (key.equals("sign")) continue;
            if (key.equals("app_key")) continue;
            if (key.equals("platform_key")) continue;
            if (key.equals("v")) continue;
            if (key.equals("sign_method")) continue;
            if (key.equals("format")) continue;

            for (String value : originQuery.get(key)) {
                String newKey;
                switch (key) {
                    case "call_out_no":
                        newKey = "caller";
                        break;
                    case "partner_id":
                        newKey = "sub_service";
                        break;
                    case "no_x":
                        newKey = "called";
                        break;
                    case "timestamp":
                        newKey = "ts";
                        break;

                    case "call_id":
                        // 把call_id当做msg_id
                        queryBuilder.append("msg_id=").append(value).append("&");
                        newKey = key;
                        break;
                    default:
                        newKey = key;
                        break;
                }
                queryBuilder.append(newKey).append("=").append(value).append("&");
            }
        }
        queryBuilder.append("service=SafeNumber");

        String query = queryBuilder.toString();
        if (query.endsWith("&"))
            query = query.substring(0, query.length()-1);
        return query;
    }

    private SnResponse<String> convertToTwoWayCallQuery(MultiValueMap<String, String> originQuery, ServerHttpResponse response) {

        SnResponse<String> snResponse;
        try {
            TwoWayCallVo twoWayCallVo = new TwoWayCallVo();
            twoWayCallVo.setSub_service(originQuery.getFirst("unitID"));
            twoWayCallVo.setMsg_data(originQuery.getFirst("msgdata"));
            snResponse = new SnResponse<>(0, "success", "", "", callService.twoWayCall(null, twoWayCallVo));
        } catch (BusinessException e) {
            snResponse = new SnResponse<>(e.getExceptionEnum().getCode(), e.getExceptionEnum().getMessage(), e.getExceptionEnum().getSubCode(), e.getExceptionEnum().getSubMessage(), null);
        }
        catch (Exception e) {
            snResponse = new SnResponse<>(500, "未知错误，请联系管理员", "", "", null);
        }

        if (snResponse.getCode() == 0) {
            // 校验通过
            // 构造发往FreeSWITCH的数据
            JSONObject msgData = JSON.parseObject(snResponse.getData());
            msgData.put("app_name", originQuery.getFirst("unitID"));
            //msgdataJson.put("request_id", msgdataJson.getString("request_id"));
            //msgData.put("report_url", "");
            JSONObject requestData = new JSONObject();
            requestData.put("secret.call.twowaycall", msgData);

            JSONArray numbers_leg_a = msgData.getJSONObject("aleg").getJSONArray("numbers");
            JSONArray numbers_leg_b = msgData.getJSONObject("bleg").getJSONArray("numbers");

            // 利用header存储后续记录last call所需参数
            response.getHeaders().add("X-Last-Call-callee", numbers_leg_b.getJSONObject(0).getString("callee"));
            response.getHeaders().add("X-Last-Call-display_code", numbers_leg_b.getJSONObject(0).getString("caller"));
            response.getHeaders().add("X-Last-Call-caller", numbers_leg_a.getJSONObject(0).getString("callee"));
            response.getHeaders().add("X-Last-Call-called", numbers_leg_a.getJSONObject(0).getString("caller"));

            snResponse.setData("fsaspaas/fsaspaas.lua onxmlrpc json " + requestData.toString());
        } else {
            // 校验不通过
            snResponse.setData(null);
        }

        return snResponse;
    }

}
