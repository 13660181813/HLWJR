package cn.cvtt.safenumber.service.controller;

import cn.cvtt.safenumber.common.api.SnResponse;
import cn.cvtt.safenumber.common.model.SnUnit;
import cn.cvtt.safenumber.common.model.SnUnitKey;
import cn.cvtt.safenumber.common.exception.BusinessException;
import cn.cvtt.safenumber.common.exception.BusinessExceptionEnum;
import cn.cvtt.safenumber.common.service.SnUnitService;
import cn.cvtt.safenumber.common.vo.CommonVo;
import cn.cvtt.safenumber.common.vo.SnUnitCreateVo;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.validation.Valid;
import java.util.LinkedHashMap;
import java.util.Map;

@RestController
@RequestMapping("/v3/unit")
public class SnUnitController {

    @Resource
    private SnUnitService snUnitService;

    @GetMapping("/{unit_id}")
    public SnUnit getByUnitId(@PathVariable String unit_id) {
        return snUnitService.getByUnitId(unit_id);
    }

    @GetMapping
    /*public List<Cache.Entry<SnUnitKey, SnUnit>> getAll() {
        return snUnitService.getAll();
    }*/
    // List<Cache.Entry<SnUnitKey, SnUnit>>在序列化和反序列化时有点问题，所以改成Map
    public Map<SnUnitKey, SnUnit> getAll() {
        Map<SnUnitKey, SnUnit> snUnits = new LinkedHashMap<>();
        snUnitService.getAll().forEach(entry -> snUnits.put(entry.getKey(), entry.getValue()));
        return snUnits;
    }

    @PostMapping
    public SnResponse createSingle(@Valid SnUnitCreateVo snUnitCreateVo) {

        if (snUnitService.getByUnitId(snUnitCreateVo.getSub_service()) != null) {
            throw new BusinessException(BusinessExceptionEnum.ERR_UNIT_OCCUPIED);
        }

        SnUnitKey snUnitKey = new SnUnitKey(snUnitCreateVo.getSub_service());
        SnUnit snUnit = new SnUnit(snUnitCreateVo.getPlatform_key(),
                snUnitCreateVo.getSecret(),
                snUnitCreateVo.getParams(),
                snUnitCreateVo.getCall_settings(),
                snUnitCreateVo.getType(),
                snUnitCreateVo.getState(),
                snUnitCreateVo.getReserved());

        snUnitService.addSingle(snUnitKey, snUnit);

        return new SnResponse<>(0, "success", "", "", null);
    }

    @PutMapping
    public SnResponse updateSingle(@Valid SnUnitCreateVo snUnitCreateVo) {

        if (snUnitService.getByUnitId(snUnitCreateVo.getSub_service()) == null){
            throw new BusinessException(BusinessExceptionEnum.ERR_DATA_NOT_EXIST);
        } else {
            SnUnitKey snUnitKey = new SnUnitKey(snUnitCreateVo.getSub_service());
            SnUnit snUnit = new SnUnit(snUnitCreateVo.getPlatform_key(),
                    snUnitCreateVo.getSecret(),
                    snUnitCreateVo.getParams(),
                    snUnitCreateVo.getCall_settings(),
                    snUnitCreateVo.getType(),
                    snUnitCreateVo.getState(),
                    snUnitCreateVo.getReserved());

            snUnitService.addSingle(snUnitKey, snUnit);

            return new SnResponse<>(0, "success", "", "", null);
        }
    }

    @DeleteMapping
    public SnResponse deleteSingle(@Valid CommonVo snUnitDeleteVo) {

        if (snUnitService.delSingle(new SnUnitKey(snUnitDeleteVo.getSub_service())))
            return new SnResponse<>(0, "success", "", "", null);
        else
            throw new BusinessException(BusinessExceptionEnum.ERR_DATA_NOT_EXIST);
    }
}
