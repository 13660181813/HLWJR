package cn.cvtt.safenumber.service.component;

import cn.cvtt.safenumber.common.model.SnUnit;
import cn.cvtt.safenumber.common.service.*;
import com.alibaba.fastjson.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;
import java.util.Set;

@ConditionalOnProperty(prefix = "server", name = "serve-task", havingValue = "true")
@Component
@EnableScheduling
public class AutoTaskSchedule {

    private static final Logger logger = LoggerFactory.getLogger("cn.cvtt.safenumber.AutoTask");

    @Resource
    private StringRedisTemplate stringRedisTemplate;

    @Resource(name = "autoUnregisterThreadPoolTaskExecutor")
    private ThreadPoolTaskExecutor autoUnregisterThreadPoolTaskExecutor;
    @Resource
    private SnUserUnregisterQueueService snUserUnregisterQueueService;
    @Resource
    private SnUnitService snUnitService;
    @Resource
    private AutoUnregisterThread autoUnregisterThread;

    private Boolean enabled = true;

    private Boolean fast = false;

    public Boolean getEnabled() {
        return enabled;
    }

    public void setEnabled(Boolean enabled) {
        this.enabled = enabled;
    }

    public Boolean getFast() {
        return fast;
    }

    public void setFast(Boolean fast) {
        this.fast = fast;
    }

    public Object getStatus(){
        JSONObject status = new JSONObject();
        status.put("enabled", enabled);
        status.put("fast", fast);
        status.put("active", autoUnregisterThreadPoolTaskExecutor.getActiveCount());
        return status;
    }

    /**
     * 自动注销任务
     */
    @SuppressWarnings("unchecked")
    @Scheduled(cron = "*/1 * * * * *")
    public void autoUnregister() {
        if (!enabled) return;

        long count = 0L;
        boolean repeat;
        do {
            repeat = false;
            // 获取所有SnUserUnregisterQueue队列名称
            Set<String> snUserUnregisterQueue = stringRedisTemplate.keys("SnUserUnregisterQueue:*");
            if (snUserUnregisterQueue == null) break;
            for (String queue : snUserUnregisterQueue) {
                String[] queueNameParts = queue.split(":");
                if (queueNameParts.length >= 3) {
                    // 判断线程池负载
                    if (autoUnregisterThreadPoolTaskExecutor.getActiveCount() < (fast ? autoUnregisterThreadPoolTaskExecutor.getMaxPoolSize()
                            : autoUnregisterThreadPoolTaskExecutor.getCorePoolSize())) {
                        SnUnit snUnit = snUnitService.getByUnitId(queueNameParts[1]);
                        List sub_ids = snUserUnregisterQueueService.getAndRemove(queueNameParts[1], Byte.valueOf(queueNameParts[2]), 5000L);
                        if (sub_ids.size() > 0) {
                            count += sub_ids.size();
                            repeat = true;
                            autoUnregisterThread.run(queueNameParts[1], snUnit, sub_ids);
                        }
                    } else {
                        repeat = false;
                        break;
                    }
                }
            }
        } while (repeat);

        logger.info("[AutoUnregister] finished: total={}",
                count);
    }

    @Resource
    private SnUidReserveQueueService snUidReserveQueueService;
    @Resource
    private SnUidService snUidService;

    /**
     * uid自动解冻任务
     */
    @SuppressWarnings("unchecked")
    @Scheduled(cron = "*/1 * * * * *")
    public void autoRecoverUid() {
        if (!enabled) return;

        long start = System.currentTimeMillis();
        long count = 0L;

        boolean repeat;
        do {
            repeat = false;
            // 获取所有SnUserUnregisterQueue队列名称
            Set<String> snUidReserveQueue = stringRedisTemplate.keys("SnUidReserveQueue:*");
            if (snUidReserveQueue == null) break;
            for (String queue : snUidReserveQueue) {
                String[] queueNameParts = queue.split(":");
                if (queueNameParts.length >= 3) {
                    List uids = snUidReserveQueueService.getAndRemove(queueNameParts[1], Byte.valueOf(queueNameParts[2]), (fast ? 5000L : 2500L));
                    if (uids.size() > 0) {
                        count += uids.size();
                        repeat = true;
                        snUidService.add(queueNameParts[1], Byte.valueOf(queueNameParts[2]), (String[]) uids.toArray(new String[0]));
                    }
                }
            }
        } while (repeat);

        logger.info("[AutoRecoverUid] finished: total={}, duration={}",
                count,
                System.currentTimeMillis() - start);
    }
}
