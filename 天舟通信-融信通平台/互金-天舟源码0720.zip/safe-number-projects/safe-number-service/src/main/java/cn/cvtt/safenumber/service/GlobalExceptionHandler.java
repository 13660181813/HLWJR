package cn.cvtt.safenumber.service;

import cn.cvtt.safenumber.common.pojo.CallQueryResponse;
import cn.cvtt.safenumber.common.api.SnResponse;
import cn.cvtt.safenumber.common.exception.BusinessException;
import cn.cvtt.safenumber.common.exception.CallException;
import cn.cvtt.safenumber.common.exception.SecureValidException;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.validation.BindException;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class GlobalExceptionHandler {

    private static final Logger logger = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    @ExceptionHandler({BindException.class})
    public SnResponse bindExceptionHandler(BindException e) {

        String errMsg = "";

        for (FieldError fieldError : e.getBindingResult().getFieldErrors()) {
            String field = fieldError.getField();
            String message = fieldError.getDefaultMessage();
            // 不知道如何修改bind时抛出异常的消息，暂时使用下面方式
            if (StringUtils.contains(message, "java.lang.NumberFormatException")) {
                if (StringUtils.contains(message, "DateTimeExFormat")) {
                    message = "既不是有效的时间格式也不是有效的数值格式";
                } else {
                    message = "不是有效的数值格式";
                }
            } else if (StringUtils.contains(message, "DateTimeFormat")) {
                message = "不是有效的时间格式";
            }
            errMsg = errMsg.concat(field + message + ";");
        }

        return new SnResponse<>(101, "Parameter error", "invalid-parameter", errMsg, null);
    }

    @ExceptionHandler({SecureValidException.class})
    public SnResponse secureValidExceptionHandler(SecureValidException e) {
        return new SnResponse<>(e.getExceptionEnum().getCode(), e.getExceptionEnum().getMessage(), e.getExceptionEnum().getSubCode(), e.getExceptionEnum().getSubMessage(), null);
    }

    @ExceptionHandler({BusinessException.class})
    public SnResponse businessExceptionHandler(BusinessException e) {
        return new SnResponse<>(e.getExceptionEnum().getCode(), e.getExceptionEnum().getMessage(), e.getExceptionEnum().getSubCode(), e.getExceptionEnum().getSubMessage(), null);
    }

    @ExceptionHandler({CallException.class})
    public SnResponse<CallQueryResponse> callExceptionHandler(CallException e) {
        return new SnResponse<>(301, "Call query error", e.getExceptionEnum().getCode(), e.getExceptionEnum().getMessage(), new CallQueryResponse((byte)0, e.getCall_type(),"", e.getExceptionEnum().getCode(),"",false, e.getUnit_id_real(),null, null, null, null));
    }

    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    @ExceptionHandler({Exception.class})
    public SnResponse generalExceptionHandler(Exception e) {
        logger.error("{}", e.getMessage(), e);
        return new SnResponse<>(500, "未知错误，请联系管理员", "", "", null);
    }
}
