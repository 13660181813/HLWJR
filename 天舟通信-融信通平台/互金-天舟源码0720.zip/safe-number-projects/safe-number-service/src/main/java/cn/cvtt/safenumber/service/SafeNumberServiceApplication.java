package cn.cvtt.safenumber.service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.context.annotation.ComponentScan;

@ComponentScan(basePackages = {"cn.cvtt.safenumber.service", "cn.cvtt.safenumber.common"})
@EnableEurekaClient
@SpringBootApplication
public class SafeNumberServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(SafeNumberServiceApplication.class, args);
    }

}
