package cn.cvtt.safenumber.service.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.TaskScheduler;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler;

import java.util.concurrent.ThreadPoolExecutor;

@ConditionalOnProperty(prefix = "server", name = "serve-task", havingValue = "true")
@Configuration
public class ThreadPoolConfig {

    @Value("${task-executor.core-pool-size:1}")
    private int corePoolSize;
    @Value("${task-executor.max-pool-size:2}")
    private int maxPoolSize;

    /**
     * 自动注销线程池配置
     */
    @Bean
    public ThreadPoolTaskExecutor autoUnregisterThreadPoolTaskExecutor () {
        ThreadPoolTaskExecutor executor =new ThreadPoolTaskExecutor();
        // 设置核心线程数
        executor.setCorePoolSize(corePoolSize);
        // 设置最大线程数
        executor.setMaxPoolSize(maxPoolSize);
        // 设置队列容量
        executor.setQueueCapacity(maxPoolSize);
        // 设置线程活跃时间（秒）
        executor.setKeepAliveSeconds(60);
        // 设置默认线程名称
        executor.setThreadNamePrefix("AutoUnregisterThread");
        // 设置拒绝策略
        executor.setRejectedExecutionHandler(new ThreadPoolExecutor.CallerRunsPolicy());
        // 等待所有任务结束后再关闭线程池
        executor.setWaitForTasksToCompleteOnShutdown(true);

        executor.initialize();

        return executor;
    }

    /**
     * Scheduled注解使用的线程池。Scheduled注解默认是单线程的，通过此配置（setPoolSize）可以实现多个schedule并行
     * 通过implements SchedulingConfigurer也可以实现相同功能，但感觉此方式更简洁
     */
    @Bean
    public TaskScheduler taskScheduler() {
        ThreadPoolTaskScheduler threadPoolTaskScheduler = new ThreadPoolTaskScheduler();
        threadPoolTaskScheduler.setPoolSize(2);
        return threadPoolTaskScheduler;
    }

}
