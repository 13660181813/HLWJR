package cn.cvtt.safenumber.service.controller;

import cn.cvtt.safenumber.service.component.AutoTaskSchedule;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

@ConditionalOnProperty(prefix = "server", name = "serve-task", havingValue = "true")
@RestController
@RequestMapping("/v3/task")
public class TaskController {
    @Resource
    private AutoTaskSchedule autoTaskSchedule;

    @GetMapping
    public Object status() {
        return autoTaskSchedule.getStatus();
    }

    @PostMapping
    public Object control(String op_type) {
        if (op_type != null) {
            switch (op_type) {
                case "slow":
                    autoTaskSchedule.setEnabled(true);
                    autoTaskSchedule.setFast(false);
                    break;
                case "fast":
                    autoTaskSchedule.setEnabled(true);
                    autoTaskSchedule.setFast(true);
                    break;
                case "stop":
                    autoTaskSchedule.setEnabled(false);
                    break;
                default:
                    break;
            }
        }
        return autoTaskSchedule.getStatus();
    }
}
