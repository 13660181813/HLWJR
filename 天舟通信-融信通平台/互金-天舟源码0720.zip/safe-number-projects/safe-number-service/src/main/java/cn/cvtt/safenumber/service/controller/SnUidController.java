package cn.cvtt.safenumber.service.controller;

import cn.cvtt.safenumber.common.api.SnResponse;
import cn.cvtt.safenumber.common.model.SnUidSect;
import cn.cvtt.safenumber.common.model.SnUnit;
import cn.cvtt.safenumber.common.exception.BusinessException;
import cn.cvtt.safenumber.common.exception.BusinessExceptionEnum;
import cn.cvtt.safenumber.common.service.SnUidSectService;
import cn.cvtt.safenumber.common.service.SnUidService;
import cn.cvtt.safenumber.common.service.SnUnitService;
import cn.cvtt.safenumber.common.vo.SnUidCreateVo;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/v3/uid")
public class SnUidController {

    @Resource
    private SnUidService snUidService;
    @Resource
    private SnUidSectService snUidSectService;
    @Resource
    private SnUnitService snUnitService;

    @PostMapping
    public SnResponse add(@Valid SnUidCreateVo snUidCreateVo) {

        SnUnit snUnit = snUnitService.checkUnitId(snUidCreateVo.getSub_service());

        if (snUidSectService.getUidSectByUid(snUidCreateVo.getUid_begin()) != null
            || snUidSectService.getUidSectByUid(snUidCreateVo.getUid_end()) != null) {
            throw new BusinessException(BusinessExceptionEnum.ERR_UID_OCCUPIED);
        }

        Long uid_begin_key = Long.parseLong("1" + snUidCreateVo.getUid_begin());
        Long uid_end_key = Long.parseLong("1" + snUidCreateVo.getUid_end());

        Long countOfAdded = 0L;

        for (Long uid = uid_begin_key; uid <= uid_end_key; uid += 100000 ) {
            if (uid + 100000 > uid_end_key) {
                countOfAdded += snUidService.add(snUidCreateVo.getSub_service(), snUidCreateVo.getUid_type(), uid.toString().replaceFirst("1",""),
                        snUidCreateVo.getUid_end());
                break;
            } else {
                countOfAdded += snUidService.add(snUidCreateVo.getSub_service(), snUidCreateVo.getUid_type(), uid.toString().replaceFirst("1",""),
                        Long.valueOf(uid + 99999L).toString().replaceFirst("1", ""));
            }
        }
        // redis的set中如果有存在的数据，则添加时返回的成功数量不包括已存在的数量
        //if (countOfAdded == uid_end_key - uid_begin_key + 1) {
            snUidSectService.addUidSection(snUidCreateVo.getSub_service(), snUidCreateVo.getUid_type(), snUidCreateVo.getUid_begin(), snUidCreateVo.getUid_end());
            return new SnResponse<>(0, "success", "", "", countOfAdded);
        //}else {
        //    throw new BusinessException(BusinessExceptionEnum.ERR_UID_CREATE);
        //}
    }

    @GetMapping("/sect/{unit_id}")
    public List<SnUidSect> getByUnitId(@PathVariable String unit_id) {
        return snUidSectService.getUidSectByUnitId(unit_id);
    }

    @GetMapping("/sect/{unit_id}/{uid_type}")
    public List<SnUidSect> getByUnitIdAndType(@PathVariable String unit_id, @PathVariable Byte uid_type) {
        return snUidSectService.getUidSectByUnitIdAndType(unit_id, uid_type);
    }

}
