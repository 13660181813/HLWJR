package cn.cvtt.safenumber.service.controller;

import cn.cvtt.safenumber.common.api.SnResponse;
import cn.cvtt.safenumber.common.model.SnUnit;
import cn.cvtt.safenumber.common.model.SnUser;
import cn.cvtt.safenumber.common.model.SnUserKey;
import cn.cvtt.safenumber.common.service.SnUnitService;
import cn.cvtt.safenumber.common.service.SnUserService;
import cn.cvtt.safenumber.common.util.IpAddressUtil;
import cn.cvtt.safenumber.common.vo.SnUserRecoverVo;
import cn.cvtt.safenumber.common.vo.SnUserRegisterVo;
import cn.cvtt.safenumber.common.vo.SnUserUnregisterVo;
import cn.cvtt.safenumber.common.vo.SnUserUpdateVo;
import org.apache.commons.lang.StringUtils;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.cache.Cache;
import javax.validation.Valid;
import java.util.Date;
import java.util.List;

@RestController
@RequestMapping("/v3/user")
public class SnUserController {
    @Resource
    private SnUserService snUserService;
    @Resource
    private SnUnitService snUnitService;

    @PostMapping
    public SnResponse register(@Valid SnUserRegisterVo snUserRegisterVo) throws Exception {

        // 检查并获取对应的SnUnit信息
        SnUnit snUnit = snUnitService.checkUnitId(snUserRegisterVo.getSub_service());

        // 设置vo中的一些固定参数
        snUserRegisterVo.setReg_time(new Date());
        snUserRegisterVo.setOp_type("c");
        snUserRegisterVo.setOp_time(new Date());
        snUserRegisterVo.setOp_ip(IpAddressUtil.getIpAddress());

        return new SnResponse<>(0, "success", "", "", snUserService.addSingle(snUnit, snUserRegisterVo));
    }

    // 注意，此处利用patch方法不是特别规范
    @PatchMapping
    public SnResponse recover(@Valid SnUserRecoverVo snUserRecoverVo) throws Exception {

        // 检查并获取对应的SnUnit信息
        SnUnit snUnit = snUnitService.checkUnitId(snUserRecoverVo.getSub_service());

        // 设置vo中的一些固定参数
        snUserRecoverVo.setReg_time(new Date());
        snUserRecoverVo.setOp_type("a");    // a --> again 因为取消用了r(revoke)，所以选择a做为恢复的op_type
        snUserRecoverVo.setOp_time(new Date());
        snUserRecoverVo.setOp_ip(IpAddressUtil.getIpAddress());

        return new SnResponse<>(0, "success", "", "", snUserService.recoverSingle(snUnit, snUserRecoverVo));
    }

    @DeleteMapping
    public SnResponse unregister(@Valid SnUserUnregisterVo snUserUnregisterVo) throws Exception {

        // 检查并获取对应的SnUnit信息
        SnUnit snUnit = snUnitService.checkUnitId(snUserUnregisterVo.getSub_service());

        // 设置vo中的一些固定参数
        if (StringUtils.isBlank(snUserUnregisterVo.getOp_type()) || !StringUtils.equals(snUserUnregisterVo.getOp_type(), "r"))
            snUserUnregisterVo.setOp_type("d");   // 因有两种注销方式（普通注销或取消，op_type对应d和r），所以改为从http request中获取
        snUserUnregisterVo.setOp_time(new Date());
        snUserUnregisterVo.setOp_ip(IpAddressUtil.getIpAddress());

        return new SnResponse<>(0, "success", "", "", snUserService.delSingle(snUnit, snUserUnregisterVo));
    }

    @PutMapping
    public SnResponse updateSingle(@Valid SnUserUpdateVo snUserUpdateVo) throws Exception {

        // 检查并获取对应的SnUnit信息
        SnUnit snUnit = snUnitService.checkUnitId(snUserUpdateVo.getSub_service());

        snUserUpdateVo.setOp_type("u");
        snUserUpdateVo.setOp_time(new Date());
        snUserUpdateVo.setOp_ip(IpAddressUtil.getIpAddress());

        return new SnResponse<>(0, "success", "", "", snUserService.updateSingle(snUnit, snUserUpdateVo));
    }

    //出于性能考虑，暂未实现按uid_type分别查询
    @GetMapping("/{unit_id}/{uid_type}")
    public List<Cache.Entry<SnUserKey, SnUser>> getAll(@PathVariable String unit_id, @PathVariable Byte uid_type) {
        return snUserService.getAll(unit_id, uid_type);
    }
}
