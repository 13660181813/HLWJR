package cn.cvtt.safenumber.service.controller;

import cn.cvtt.safenumber.common.api.SnResponse;
import cn.cvtt.safenumber.common.model.SnUnit;
import cn.cvtt.safenumber.common.pojo.CallQueryResponse;
import cn.cvtt.safenumber.common.service.CallService;
import cn.cvtt.safenumber.common.service.SnLastCallService;
import cn.cvtt.safenumber.common.service.SnUnitService;
import cn.cvtt.safenumber.common.vo.CallQueryVo;
import cn.cvtt.safenumber.common.vo.LastCallVo;
import cn.cvtt.safenumber.common.vo.TwoWayCallVo;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.validation.Valid;

@RestController
@RequestMapping("/v3/call")
public class SnCallController {

    @Resource
    private SnUnitService snUnitService;

    @Resource
    private CallService callService;

    @Resource
    private SnLastCallService snLastCallService;

    @GetMapping
    public SnResponse<CallQueryResponse> callQuery(@Valid CallQueryVo callQueryVo) {
        SnUnit snUnit = snUnitService.checkUnitId(callQueryVo.getSub_service());
        return new SnResponse<>(0, "success", "", "", callService.callQuery(snUnit, callQueryVo));
    }

    @GetMapping("/two_way_call")
    public SnResponse<String> twoWayCall(@Valid TwoWayCallVo twoWayCallVo) {
        SnUnit snUnit = snUnitService.checkUnitId(twoWayCallVo.getSub_service());
        return new SnResponse<>(0, "success", "", "", callService.twoWayCall(snUnit, twoWayCallVo));
    }

    @PostMapping("/last_call")
    public SnResponse<Object> addLastCall(@Valid LastCallVo lastCallVo) {
        snLastCallService.addSingle(lastCallVo.getSub_service(), lastCallVo.getCallee(), lastCallVo.getDisplay_code(), lastCallVo.getCaller(), lastCallVo.getCalled(), lastCallVo.getStart_time());
        return new SnResponse<>(0, "success", "", "", null);
    }
}
