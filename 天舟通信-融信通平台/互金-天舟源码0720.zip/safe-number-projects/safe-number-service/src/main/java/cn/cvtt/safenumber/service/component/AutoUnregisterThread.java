package cn.cvtt.safenumber.service.component;

import cn.cvtt.safenumber.common.model.SnUnit;
import cn.cvtt.safenumber.common.service.*;
import cn.cvtt.safenumber.common.util.IpAddressUtil;
import cn.cvtt.safenumber.common.vo.SnUserUnregisterVo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;

/**
 * 自动注销线程（通过Async注解实现）
 */
@ConditionalOnProperty(prefix = "server", name = "serve-task", havingValue = "true")
@Component
@EnableAsync
public class AutoUnregisterThread {

    private static final Logger logger = LoggerFactory.getLogger("cn.cvtt.safenumber.AutoTask");

    @Resource
    private SnUserService snUserService;

    @Async("autoUnregisterThreadPoolTaskExecutor")
    public void run(String unit_id, SnUnit snUnit, List sub_ids) {
        long start = System.currentTimeMillis();
        long errCount = 0L;

        for (Object sub_id: sub_ids) {
            SnUserUnregisterVo snUserUnregisterVo = new SnUserUnregisterVo();
            snUserUnregisterVo.setMsg_id("1");
            snUserUnregisterVo.setTs(new Date());
            snUserUnregisterVo.setService("SafeNumber");
            snUserUnregisterVo.setSub_service(unit_id);
            snUserUnregisterVo.setOp_module("service");
            snUserUnregisterVo.setOp_user("task");
            snUserUnregisterVo.setOp_type("d");
            snUserUnregisterVo.setOp_time(new Date());
            snUserUnregisterVo.setOp_ip(IpAddressUtil.getIpAddress());
            snUserUnregisterVo.setSub_id((String) sub_id);
            try {
                snUserService.delSingle(snUnit, snUserUnregisterVo);
            } catch (Exception e) {
                logger.error("AutoUnregister error: sub_id={}, error={}",
                        sub_id,
                        e.getMessage(),
                        e);
                errCount ++;
            }
        }

        logger.info("AutoUnregister finished: total={}, error={}, duration={}",
                sub_ids.size(),
                errCount,
                System.currentTimeMillis() - start);
    }

}
