TODO
可以用Swagger来生成接口描述文档

0. 随机记录
URL: v2/stat/random-record/{unit:[ZHONGTONG|SHENTONG|JINGGUANG|SUNING|YUNDA]+}
[
    {
        "receiver_phone": "158****8393",
        "receiver_virtual_phone": "950132118523985",
        "sender_phone": "186****7566",
        "sender_virtual_phone": "950132105656025",
        "virtual_number": "73141093459632"
    },
    {
        "receiver_phone": "186****7006",
        "receiver_virtual_phone": "950132104036362",
        "sender_phone": "151****3550",
        "sender_virtual_phone": "950132102228755",
        "virtual_number": "73141238733686"
    }
]

1.近七天日期:
URL：/v2/stat/date
seven_date:['2020-10-24','2020-10-25','2020-10-26','2020-10-27','2020-10-28','2020-10-29','2020-10-30']


2.头部总数据：
URL: /v2/stat/header-data
{
express_num:554544, //快递单数
bound_num:45454, //绑定次数
unbundle_num:5656 //解绑
postpone_num:5656 //延期次数
call_num:54 //呼叫次数
}

3.近7日分品牌使用情况
URL：/v2/stat/slide-list
      slideList: [
        {
          company_name: "中通", //品牌名
          singular_num: "1033974", //快递单数
          bound_num: "1242312", //绑定次数
          call_num: "20947", //通话次数
          duration_time: "314382", //通话时长（秒）
        },
        {
          company_name: "申通",
          singular_num: "378331",
          bound_num: "392430",
          call_num: "391470",
          duration_time: "3696248",
        },
        {
          company_name: "京广",
          singular_num: "421418",
          bound_num: "828138",
          call_num: "1476",
          duration_time: "32155",
        },
        {
          company_name: "韵达",
          singular_num: "1",
          bound_num: "10",
          call_num: "47",
          duration_time: "804",
        },
        {
          company_name: "苏宁",
          singular_num: "1614700",
          bound_num: "2038663",
          call_num: "4847",
          duration_time: "105254",
        },
      ],


柱形图4个：

1.呼叫次数
URL：/v2/stat/call/count
[{
    name: '中通',
    data: [3129,2895,2955,2663,2953,2922,3430]
},{
    name: '申通',
    data: [54193,53115,54471,53346,58004,60676,57665]
},{
    name: '京广',
    data: [268, 235, 204, 158, 216,216,179]
},{
    name: '韵达',
    data: [22,5,9,6,1,3,1]
},{
    name: '苏宁',
    data: [819,744691,673,606,607,707]
}]


2.振铃率
URL：/v2/stat/call/ring_rate
[{
    name: '中通',
    data: [ '99.87%','99.86%','99.83%','100.00%','99.86%','99.93%','99.97%']
},{
    name: '申通',
    data: [ '99.78%','99.82%','99.70%','99.69%','99.65%','99.67%','99.67%']
},{
    name: '京广',
    data: ['99.63%','100.00%','100.00%','100.00%','100.00%','100.00%','100.00%']
},{
    name: '韵达',
    data: [ '100.00%','100.00%','100.00%','100.00%','100.00%','100.00%','100.00%']
},{
    name: '苏宁',
    data: [ '100.00%','100.00%','100.00%','99.55%','99.83%','100.00%','99.86%']
}]

3.均时长
URL：/v2/stat/call/average_time
[{
    name: '中通',
    data: [34.42,34.83,33.03,31.62,32.32,34.05,31.16]
},{
    name: '申通',
    data: [32.95,32.53,32.54,31.61,31.16,31.65,31.98]
},{
    name: '京广',
    data: [50.2,44.88,45.95,40.79,50.04,51.05,43.22]
},{
    name: '韵达',
    data: [ 59.67,0,20.5,47,0,0,0]
},{
    name: '苏宁',
    data: [40.45,38.55,38.56,41.38,40.62,40.71,39]
}]

4.延期次数
URL：/v2/stat/num/extend
[{
    name: '中通',
    data: [34.42,34.83,33.03,31.62,32.32,34.05,31.16]
},{
    name: '申通',
    data: [32.95,32.53,32.54,31.61,31.16,31.65,31.98]
},{
    name: '京广',
    data: [50.2,44.88,45.95,40.79,50.04,51.05,43.22]
},{
    name: '韵达',
    data: [ 59.67,0,20.5,47,0,0,0]
},{
    name: '苏宁',
    data: [40.45,38.55,38.56,41.38,40.62,40.71,39]
}]


饼图3个：

1.新增快递单
URL：/v2/stat/new/mail
[{value: 1033974, name: '中通'},
{value: 378331, name: '申通'},
{value: 421418, name: '京广'},
{value: 1, name: '韵达'},
{value: 1614700, name: '苏宁'}
]

2.新增绑定
URL：/v2/stat/new/bind
[{value: 1242312, name: '中通'},
{value: 392430, name: '申通'},
{value: 828138, name: '京广'},
{value: 10, name: '韵达'},
{value: 2038663, name: '苏宁'}
]
3.新增解绑
URL：/v2/stat/new/unbind
[{value: 1207244, name: '中通'},
{value: 285848, name: '申通'},
{value: 853286, name: '京广'},
{value: 18656, name: '韵达'},
{value: 1727027, name: '苏宁'}
]

折线图3个：

1.虚拟号使用情况
URL：/v2/stat/usage/num
注：接口返回的是data而不是date，猜测是笔误
[{
	name:'快递单数',
	date[注：接口返回的是data，猜测是笔误]:[130386, 105672, 164575, 160030, 157554, 171053, 144704]
},{
	name:'绑定次数',
	date:[157189, 131659, 198284, 191886, 188508, 200972, 173814]
},
{
	name:'解绑次数',
	date:[127386, 125174, 135210, 199278, 213848, 192167, 214181]
},]


2.虚拟号总时长（秒）
URL：/v2/stat/usage/call/time
[{
	name:'总时长（秒）',
	date:[130386, 105672, 164575, 160030, 157554, 171053, 144704]
}]

3.虚拟号呼叫次数
URL：/v2/stat/usage/call/count
[{
	name:'呼叫次数',
	date:[130386, 105672, 164575, 160030, 157554, 171053, 144704]
}]