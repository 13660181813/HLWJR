package cn.cvtt.safenumber.stat;

import cn.cvtt.safenumber.stat.entity.CountNumber;
import cn.cvtt.safenumber.stat.service.BindStatServiceV2;
import cn.cvtt.safenumber.stat.service.CallStatServiceV2;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import javax.annotation.Resource;
import java.util.List;

@SpringBootTest
class SafeNumberStatApplicationTests {

    @Resource
    private BindStatServiceV2 bindStatServiceV2;

    @Resource
    private CallStatServiceV2 callStatServiceV2;

    @Test
    void contextLoads() {
        System.out.println("");
    }
}
