package cn.cvtt.safenumber.stat.mapper;

import static cn.cvtt.safenumber.stat.mapper.TUnitDynamicSqlSupport.*;
import static org.mybatis.dynamic.sql.SqlBuilder.*;

import cn.cvtt.safenumber.stat.entity.TUnit;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import javax.annotation.Generated;
import org.apache.ibatis.annotations.DeleteProvider;
import org.apache.ibatis.annotations.InsertProvider;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.SelectProvider;
import org.apache.ibatis.annotations.UpdateProvider;
import org.apache.ibatis.type.JdbcType;
import org.mybatis.dynamic.sql.BasicColumn;
import org.mybatis.dynamic.sql.delete.DeleteDSLCompleter;
import org.mybatis.dynamic.sql.delete.render.DeleteStatementProvider;
import org.mybatis.dynamic.sql.insert.render.InsertStatementProvider;
import org.mybatis.dynamic.sql.insert.render.MultiRowInsertStatementProvider;
import org.mybatis.dynamic.sql.select.CountDSLCompleter;
import org.mybatis.dynamic.sql.select.SelectDSLCompleter;
import org.mybatis.dynamic.sql.select.render.SelectStatementProvider;
import org.mybatis.dynamic.sql.update.UpdateDSL;
import org.mybatis.dynamic.sql.update.UpdateDSLCompleter;
import org.mybatis.dynamic.sql.update.UpdateModel;
import org.mybatis.dynamic.sql.update.render.UpdateStatementProvider;
import org.mybatis.dynamic.sql.util.SqlProviderAdapter;
import org.mybatis.dynamic.sql.util.mybatis3.MyBatis3Utils;

@Mapper
public interface TUnitMapper {
    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    BasicColumn[] selectList = BasicColumn.columnList(unitid, addtime, addtimes, operator, parentid, safeNumberUser, unitadd, unitcontact, unitkey, unitmobile, unitname, unittel, unittype, unituidnumber);

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    @SelectProvider(type=SqlProviderAdapter.class, method="select")
    long count(SelectStatementProvider selectStatement);

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    @DeleteProvider(type=SqlProviderAdapter.class, method="delete")
    int delete(DeleteStatementProvider deleteStatement);

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    @InsertProvider(type=SqlProviderAdapter.class, method="insert")
    int insert(InsertStatementProvider<TUnit> insertStatement);

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    @InsertProvider(type=SqlProviderAdapter.class, method="insertMultiple")
    int insertMultiple(MultiRowInsertStatementProvider<TUnit> multipleInsertStatement);

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    @SelectProvider(type=SqlProviderAdapter.class, method="select")
    @ResultMap("TUnitResult")
    Optional<TUnit> selectOne(SelectStatementProvider selectStatement);

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    @SelectProvider(type=SqlProviderAdapter.class, method="select")
    @Results(id="TUnitResult", value = {
        @Result(column="unitid", property="unitid", jdbcType=JdbcType.VARCHAR, id=true),
        @Result(column="addtime", property="addtime", jdbcType=JdbcType.TIMESTAMP),
        @Result(column="addtimes", property="addtimes", jdbcType=JdbcType.VARCHAR),
        @Result(column="operator", property="operator", jdbcType=JdbcType.VARCHAR),
        @Result(column="parentid", property="parentid", jdbcType=JdbcType.VARCHAR),
        @Result(column="safeNumberUser", property="safeNumberUser", jdbcType=JdbcType.VARCHAR),
        @Result(column="unitadd", property="unitadd", jdbcType=JdbcType.VARCHAR),
        @Result(column="unitcontact", property="unitcontact", jdbcType=JdbcType.VARCHAR),
        @Result(column="unitkey", property="unitkey", jdbcType=JdbcType.VARCHAR),
        @Result(column="unitmobile", property="unitmobile", jdbcType=JdbcType.VARCHAR),
        @Result(column="unitname", property="unitname", jdbcType=JdbcType.VARCHAR),
        @Result(column="unittel", property="unittel", jdbcType=JdbcType.VARCHAR),
        @Result(column="unittype", property="unittype", jdbcType=JdbcType.VARCHAR),
        @Result(column="unituidnumber", property="unituidnumber", jdbcType=JdbcType.VARCHAR)
    })
    List<TUnit> selectMany(SelectStatementProvider selectStatement);

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    @UpdateProvider(type=SqlProviderAdapter.class, method="update")
    int update(UpdateStatementProvider updateStatement);

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    default long count(CountDSLCompleter completer) {
        return MyBatis3Utils.countFrom(this::count, TUnit, completer);
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    default int delete(DeleteDSLCompleter completer) {
        return MyBatis3Utils.deleteFrom(this::delete, TUnit, completer);
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    default int deleteByPrimaryKey(String unitid_) {
        return delete(c -> 
            c.where(unitid, isEqualTo(unitid_))
        );
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    default int insert(TUnit record) {
        return MyBatis3Utils.insert(this::insert, record, TUnit, c ->
            c.map(unitid).toProperty("unitid")
            .map(addtime).toProperty("addtime")
            .map(addtimes).toProperty("addtimes")
            .map(operator).toProperty("operator")
            .map(parentid).toProperty("parentid")
            .map(safeNumberUser).toProperty("safeNumberUser")
            .map(unitadd).toProperty("unitadd")
            .map(unitcontact).toProperty("unitcontact")
            .map(unitkey).toProperty("unitkey")
            .map(unitmobile).toProperty("unitmobile")
            .map(unitname).toProperty("unitname")
            .map(unittel).toProperty("unittel")
            .map(unittype).toProperty("unittype")
            .map(unituidnumber).toProperty("unituidnumber")
        );
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    default int insertMultiple(Collection<TUnit> records) {
        return MyBatis3Utils.insertMultiple(this::insertMultiple, records, TUnit, c ->
            c.map(unitid).toProperty("unitid")
            .map(addtime).toProperty("addtime")
            .map(addtimes).toProperty("addtimes")
            .map(operator).toProperty("operator")
            .map(parentid).toProperty("parentid")
            .map(safeNumberUser).toProperty("safeNumberUser")
            .map(unitadd).toProperty("unitadd")
            .map(unitcontact).toProperty("unitcontact")
            .map(unitkey).toProperty("unitkey")
            .map(unitmobile).toProperty("unitmobile")
            .map(unitname).toProperty("unitname")
            .map(unittel).toProperty("unittel")
            .map(unittype).toProperty("unittype")
            .map(unituidnumber).toProperty("unituidnumber")
        );
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    default int insertSelective(TUnit record) {
        return MyBatis3Utils.insert(this::insert, record, TUnit, c ->
            c.map(unitid).toPropertyWhenPresent("unitid", record::getUnitid)
            .map(addtime).toPropertyWhenPresent("addtime", record::getAddtime)
            .map(addtimes).toPropertyWhenPresent("addtimes", record::getAddtimes)
            .map(operator).toPropertyWhenPresent("operator", record::getOperator)
            .map(parentid).toPropertyWhenPresent("parentid", record::getParentid)
            .map(safeNumberUser).toPropertyWhenPresent("safeNumberUser", record::getSafeNumberUser)
            .map(unitadd).toPropertyWhenPresent("unitadd", record::getUnitadd)
            .map(unitcontact).toPropertyWhenPresent("unitcontact", record::getUnitcontact)
            .map(unitkey).toPropertyWhenPresent("unitkey", record::getUnitkey)
            .map(unitmobile).toPropertyWhenPresent("unitmobile", record::getUnitmobile)
            .map(unitname).toPropertyWhenPresent("unitname", record::getUnitname)
            .map(unittel).toPropertyWhenPresent("unittel", record::getUnittel)
            .map(unittype).toPropertyWhenPresent("unittype", record::getUnittype)
            .map(unituidnumber).toPropertyWhenPresent("unituidnumber", record::getUnituidnumber)
        );
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    default Optional<TUnit> selectOne(SelectDSLCompleter completer) {
        return MyBatis3Utils.selectOne(this::selectOne, selectList, TUnit, completer);
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    default List<TUnit> select(SelectDSLCompleter completer) {
        return MyBatis3Utils.selectList(this::selectMany, selectList, TUnit, completer);
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    default List<TUnit> selectDistinct(SelectDSLCompleter completer) {
        return MyBatis3Utils.selectDistinct(this::selectMany, selectList, TUnit, completer);
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    default Optional<TUnit> selectByPrimaryKey(String unitid_) {
        return selectOne(c ->
            c.where(unitid, isEqualTo(unitid_))
        );
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    default int update(UpdateDSLCompleter completer) {
        return MyBatis3Utils.update(this::update, TUnit, completer);
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    static UpdateDSL<UpdateModel> updateAllColumns(TUnit record, UpdateDSL<UpdateModel> dsl) {
        return dsl.set(unitid).equalTo(record::getUnitid)
                .set(addtime).equalTo(record::getAddtime)
                .set(addtimes).equalTo(record::getAddtimes)
                .set(operator).equalTo(record::getOperator)
                .set(parentid).equalTo(record::getParentid)
                .set(safeNumberUser).equalTo(record::getSafeNumberUser)
                .set(unitadd).equalTo(record::getUnitadd)
                .set(unitcontact).equalTo(record::getUnitcontact)
                .set(unitkey).equalTo(record::getUnitkey)
                .set(unitmobile).equalTo(record::getUnitmobile)
                .set(unitname).equalTo(record::getUnitname)
                .set(unittel).equalTo(record::getUnittel)
                .set(unittype).equalTo(record::getUnittype)
                .set(unituidnumber).equalTo(record::getUnituidnumber);
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    static UpdateDSL<UpdateModel> updateSelectiveColumns(TUnit record, UpdateDSL<UpdateModel> dsl) {
        return dsl.set(unitid).equalToWhenPresent(record::getUnitid)
                .set(addtime).equalToWhenPresent(record::getAddtime)
                .set(addtimes).equalToWhenPresent(record::getAddtimes)
                .set(operator).equalToWhenPresent(record::getOperator)
                .set(parentid).equalToWhenPresent(record::getParentid)
                .set(safeNumberUser).equalToWhenPresent(record::getSafeNumberUser)
                .set(unitadd).equalToWhenPresent(record::getUnitadd)
                .set(unitcontact).equalToWhenPresent(record::getUnitcontact)
                .set(unitkey).equalToWhenPresent(record::getUnitkey)
                .set(unitmobile).equalToWhenPresent(record::getUnitmobile)
                .set(unitname).equalToWhenPresent(record::getUnitname)
                .set(unittel).equalToWhenPresent(record::getUnittel)
                .set(unittype).equalToWhenPresent(record::getUnittype)
                .set(unituidnumber).equalToWhenPresent(record::getUnituidnumber);
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    default int updateByPrimaryKey(TUnit record) {
        return update(c ->
            c.set(addtime).equalTo(record::getAddtime)
            .set(addtimes).equalTo(record::getAddtimes)
            .set(operator).equalTo(record::getOperator)
            .set(parentid).equalTo(record::getParentid)
            .set(safeNumberUser).equalTo(record::getSafeNumberUser)
            .set(unitadd).equalTo(record::getUnitadd)
            .set(unitcontact).equalTo(record::getUnitcontact)
            .set(unitkey).equalTo(record::getUnitkey)
            .set(unitmobile).equalTo(record::getUnitmobile)
            .set(unitname).equalTo(record::getUnitname)
            .set(unittel).equalTo(record::getUnittel)
            .set(unittype).equalTo(record::getUnittype)
            .set(unituidnumber).equalTo(record::getUnituidnumber)
            .where(unitid, isEqualTo(record::getUnitid))
        );
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    default int updateByPrimaryKeySelective(TUnit record) {
        return update(c ->
            c.set(addtime).equalToWhenPresent(record::getAddtime)
            .set(addtimes).equalToWhenPresent(record::getAddtimes)
            .set(operator).equalToWhenPresent(record::getOperator)
            .set(parentid).equalToWhenPresent(record::getParentid)
            .set(safeNumberUser).equalToWhenPresent(record::getSafeNumberUser)
            .set(unitadd).equalToWhenPresent(record::getUnitadd)
            .set(unitcontact).equalToWhenPresent(record::getUnitcontact)
            .set(unitkey).equalToWhenPresent(record::getUnitkey)
            .set(unitmobile).equalToWhenPresent(record::getUnitmobile)
            .set(unitname).equalToWhenPresent(record::getUnitname)
            .set(unittel).equalToWhenPresent(record::getUnittel)
            .set(unittype).equalToWhenPresent(record::getUnittype)
            .set(unituidnumber).equalToWhenPresent(record::getUnituidnumber)
            .where(unitid, isEqualTo(record::getUnitid))
        );
    }
}