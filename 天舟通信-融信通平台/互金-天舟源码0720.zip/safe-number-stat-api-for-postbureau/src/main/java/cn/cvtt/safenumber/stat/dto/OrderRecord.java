package cn.cvtt.safenumber.stat.dto;

public class OrderRecord {
    private String sender_phone;
    private String sender_virtual_phone;
    private String virtual_number;
    private String receiver_phone;
    private String receiver_virtual_phone;

    public String getSender_phone() {
        return sender_phone;
    }

    public void setSender_phone(String sender_phone) {
        this.sender_phone = sender_phone;
    }

    public String getSender_virtual_phone() {
        return sender_virtual_phone;
    }

    public void setSender_virtual_phone(String sender_virtual_phone) {
        this.sender_virtual_phone = sender_virtual_phone;
    }

    public String getVirtual_number() {
        return virtual_number;
    }

    public void setVirtual_number(String virtual_number) {
        this.virtual_number = virtual_number;
    }

    public String getReceiver_phone() {
        return receiver_phone;
    }

    public void setReceiver_phone(String receiver_phone) {
        this.receiver_phone = receiver_phone;
    }

    public String getReceiver_virtual_phone() {
        return receiver_virtual_phone;
    }

    public void setReceiver_virtual_phone(String receiver_virtual_phone) {
        this.receiver_virtual_phone = receiver_virtual_phone;
    }
}
