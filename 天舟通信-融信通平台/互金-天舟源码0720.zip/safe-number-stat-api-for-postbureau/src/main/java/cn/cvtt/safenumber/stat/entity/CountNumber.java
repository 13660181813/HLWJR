package cn.cvtt.safenumber.stat.entity;

import java.util.Date;
import javax.annotation.Generated;

public class CountNumber {
    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private String id;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Date start_time;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private String unitid;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private String msgtype;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Integer xzbdcs;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private String opuidtype;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Integer mailCount;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public String getId() {
        return id;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setId(String id) {
        this.id = id;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Date getStart_time() {
        return start_time;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setStart_time(Date start_time) {
        this.start_time = start_time;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public String getUnitid() {
        return unitid;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setUnitid(String unitid) {
        this.unitid = unitid;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public String getMsgtype() {
        return msgtype;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setMsgtype(String msgtype) {
        this.msgtype = msgtype;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Integer getXzbdcs() {
        return xzbdcs;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setXzbdcs(Integer xzbdcs) {
        this.xzbdcs = xzbdcs;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public String getOpuidtype() {
        return opuidtype;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setOpuidtype(String opuidtype) {
        this.opuidtype = opuidtype;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Integer getMailCount() {
        return mailCount;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setMailCount(Integer mailCount) {
        this.mailCount = mailCount;
    }
}