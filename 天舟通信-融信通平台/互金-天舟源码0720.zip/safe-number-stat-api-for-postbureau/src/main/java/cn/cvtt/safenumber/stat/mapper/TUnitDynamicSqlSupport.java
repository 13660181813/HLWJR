package cn.cvtt.safenumber.stat.mapper;

import java.sql.JDBCType;
import java.util.Date;
import javax.annotation.Generated;
import org.mybatis.dynamic.sql.SqlColumn;
import org.mybatis.dynamic.sql.SqlTable;

public final class TUnitDynamicSqlSupport {
    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final TUnit TUnit = new TUnit();

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<String> unitid = TUnit.unitid;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Date> addtime = TUnit.addtime;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<String> addtimes = TUnit.addtimes;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<String> operator = TUnit.operator;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<String> parentid = TUnit.parentid;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<String> safeNumberUser = TUnit.safeNumberUser;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<String> unitadd = TUnit.unitadd;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<String> unitcontact = TUnit.unitcontact;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<String> unitkey = TUnit.unitkey;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<String> unitmobile = TUnit.unitmobile;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<String> unitname = TUnit.unitname;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<String> unittel = TUnit.unittel;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<String> unittype = TUnit.unittype;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<String> unituidnumber = TUnit.unituidnumber;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final class TUnit extends SqlTable {
        public final SqlColumn<String> unitid = column("unitid", JDBCType.VARCHAR);

        public final SqlColumn<Date> addtime = column("addtime", JDBCType.TIMESTAMP);

        public final SqlColumn<String> addtimes = column("addtimes", JDBCType.VARCHAR);

        public final SqlColumn<String> operator = column("operator", JDBCType.VARCHAR);

        public final SqlColumn<String> parentid = column("parentid", JDBCType.VARCHAR);

        public final SqlColumn<String> safeNumberUser = column("safeNumberUser", JDBCType.VARCHAR);

        public final SqlColumn<String> unitadd = column("unitadd", JDBCType.VARCHAR);

        public final SqlColumn<String> unitcontact = column("unitcontact", JDBCType.VARCHAR);

        public final SqlColumn<String> unitkey = column("unitkey", JDBCType.VARCHAR);

        public final SqlColumn<String> unitmobile = column("unitmobile", JDBCType.VARCHAR);

        public final SqlColumn<String> unitname = column("unitname", JDBCType.VARCHAR);

        public final SqlColumn<String> unittel = column("unittel", JDBCType.VARCHAR);

        public final SqlColumn<String> unittype = column("unittype", JDBCType.VARCHAR);

        public final SqlColumn<String> unituidnumber = column("unituidnumber", JDBCType.VARCHAR);

        public TUnit() {
            super("T_UNIT");
        }
    }
}