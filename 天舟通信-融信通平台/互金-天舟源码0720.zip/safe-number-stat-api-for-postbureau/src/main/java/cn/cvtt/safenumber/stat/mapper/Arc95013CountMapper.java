package cn.cvtt.safenumber.stat.mapper;

import static cn.cvtt.safenumber.stat.mapper.Arc95013CountDynamicSqlSupport.*;
import static org.mybatis.dynamic.sql.SqlBuilder.*;

import cn.cvtt.safenumber.stat.entity.Arc95013Count;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import javax.annotation.Generated;
import org.apache.ibatis.annotations.DeleteProvider;
import org.apache.ibatis.annotations.InsertProvider;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.SelectProvider;
import org.apache.ibatis.annotations.UpdateProvider;
import org.apache.ibatis.type.JdbcType;
import org.mybatis.dynamic.sql.BasicColumn;
import org.mybatis.dynamic.sql.delete.DeleteDSLCompleter;
import org.mybatis.dynamic.sql.delete.render.DeleteStatementProvider;
import org.mybatis.dynamic.sql.insert.render.InsertStatementProvider;
import org.mybatis.dynamic.sql.insert.render.MultiRowInsertStatementProvider;
import org.mybatis.dynamic.sql.select.CountDSLCompleter;
import org.mybatis.dynamic.sql.select.SelectDSLCompleter;
import org.mybatis.dynamic.sql.select.render.SelectStatementProvider;
import org.mybatis.dynamic.sql.update.UpdateDSL;
import org.mybatis.dynamic.sql.update.UpdateDSLCompleter;
import org.mybatis.dynamic.sql.update.UpdateModel;
import org.mybatis.dynamic.sql.update.render.UpdateStatementProvider;
import org.mybatis.dynamic.sql.util.SqlProviderAdapter;
import org.mybatis.dynamic.sql.util.mybatis3.MyBatis3Utils;

@Mapper
public interface Arc95013CountMapper {
    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    BasicColumn[] selectList = BasicColumn.columnList(id, start_time, bdcs, zlcs, cgcs, sbcs, zll, jtl, thzsc, thjsc, unitid);

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    @SelectProvider(type=SqlProviderAdapter.class, method="select")
    long count(SelectStatementProvider selectStatement);

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    @DeleteProvider(type=SqlProviderAdapter.class, method="delete")
    int delete(DeleteStatementProvider deleteStatement);

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    @InsertProvider(type=SqlProviderAdapter.class, method="insert")
    int insert(InsertStatementProvider<Arc95013Count> insertStatement);

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    @InsertProvider(type=SqlProviderAdapter.class, method="insertMultiple")
    int insertMultiple(MultiRowInsertStatementProvider<Arc95013Count> multipleInsertStatement);

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    @SelectProvider(type=SqlProviderAdapter.class, method="select")
    @ResultMap("Arc95013CountResult")
    Optional<Arc95013Count> selectOne(SelectStatementProvider selectStatement);

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    @SelectProvider(type=SqlProviderAdapter.class, method="select")
    @Results(id="Arc95013CountResult", value = {
        @Result(column="id", property="id", jdbcType=JdbcType.VARCHAR, id=true),
        @Result(column="start_time", property="start_time", jdbcType=JdbcType.DATE),
        @Result(column="bdcs", property="bdcs", jdbcType=JdbcType.INTEGER),
        @Result(column="zlcs", property="zlcs", jdbcType=JdbcType.INTEGER),
        @Result(column="cgcs", property="cgcs", jdbcType=JdbcType.INTEGER),
        @Result(column="sbcs", property="sbcs", jdbcType=JdbcType.INTEGER),
        @Result(column="zll", property="zll", jdbcType=JdbcType.DOUBLE),
        @Result(column="jtl", property="jtl", jdbcType=JdbcType.DOUBLE),
        @Result(column="thzsc", property="thzsc", jdbcType=JdbcType.DOUBLE),
        @Result(column="thjsc", property="thjsc", jdbcType=JdbcType.DOUBLE),
        @Result(column="unitid", property="unitid", jdbcType=JdbcType.VARCHAR)
    })
    List<Arc95013Count> selectMany(SelectStatementProvider selectStatement);

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    @UpdateProvider(type=SqlProviderAdapter.class, method="update")
    int update(UpdateStatementProvider updateStatement);

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    default long count(CountDSLCompleter completer) {
        return MyBatis3Utils.countFrom(this::count, arc95013Count, completer);
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    default int delete(DeleteDSLCompleter completer) {
        return MyBatis3Utils.deleteFrom(this::delete, arc95013Count, completer);
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    default int deleteByPrimaryKey(String id_) {
        return delete(c -> 
            c.where(id, isEqualTo(id_))
        );
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    default int insert(Arc95013Count record) {
        return MyBatis3Utils.insert(this::insert, record, arc95013Count, c ->
            c.map(id).toProperty("id")
            .map(start_time).toProperty("start_time")
            .map(bdcs).toProperty("bdcs")
            .map(zlcs).toProperty("zlcs")
            .map(cgcs).toProperty("cgcs")
            .map(sbcs).toProperty("sbcs")
            .map(zll).toProperty("zll")
            .map(jtl).toProperty("jtl")
            .map(thzsc).toProperty("thzsc")
            .map(thjsc).toProperty("thjsc")
            .map(unitid).toProperty("unitid")
        );
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    default int insertMultiple(Collection<Arc95013Count> records) {
        return MyBatis3Utils.insertMultiple(this::insertMultiple, records, arc95013Count, c ->
            c.map(id).toProperty("id")
            .map(start_time).toProperty("start_time")
            .map(bdcs).toProperty("bdcs")
            .map(zlcs).toProperty("zlcs")
            .map(cgcs).toProperty("cgcs")
            .map(sbcs).toProperty("sbcs")
            .map(zll).toProperty("zll")
            .map(jtl).toProperty("jtl")
            .map(thzsc).toProperty("thzsc")
            .map(thjsc).toProperty("thjsc")
            .map(unitid).toProperty("unitid")
        );
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    default int insertSelective(Arc95013Count record) {
        return MyBatis3Utils.insert(this::insert, record, arc95013Count, c ->
            c.map(id).toPropertyWhenPresent("id", record::getId)
            .map(start_time).toPropertyWhenPresent("start_time", record::getStart_time)
            .map(bdcs).toPropertyWhenPresent("bdcs", record::getBdcs)
            .map(zlcs).toPropertyWhenPresent("zlcs", record::getZlcs)
            .map(cgcs).toPropertyWhenPresent("cgcs", record::getCgcs)
            .map(sbcs).toPropertyWhenPresent("sbcs", record::getSbcs)
            .map(zll).toPropertyWhenPresent("zll", record::getZll)
            .map(jtl).toPropertyWhenPresent("jtl", record::getJtl)
            .map(thzsc).toPropertyWhenPresent("thzsc", record::getThzsc)
            .map(thjsc).toPropertyWhenPresent("thjsc", record::getThjsc)
            .map(unitid).toPropertyWhenPresent("unitid", record::getUnitid)
        );
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    default Optional<Arc95013Count> selectOne(SelectDSLCompleter completer) {
        return MyBatis3Utils.selectOne(this::selectOne, selectList, arc95013Count, completer);
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    default List<Arc95013Count> select(SelectDSLCompleter completer) {
        return MyBatis3Utils.selectList(this::selectMany, selectList, arc95013Count, completer);
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    default List<Arc95013Count> selectDistinct(SelectDSLCompleter completer) {
        return MyBatis3Utils.selectDistinct(this::selectMany, selectList, arc95013Count, completer);
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    default Optional<Arc95013Count> selectByPrimaryKey(String id_) {
        return selectOne(c ->
            c.where(id, isEqualTo(id_))
        );
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    default int update(UpdateDSLCompleter completer) {
        return MyBatis3Utils.update(this::update, arc95013Count, completer);
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    static UpdateDSL<UpdateModel> updateAllColumns(Arc95013Count record, UpdateDSL<UpdateModel> dsl) {
        return dsl.set(id).equalTo(record::getId)
                .set(start_time).equalTo(record::getStart_time)
                .set(bdcs).equalTo(record::getBdcs)
                .set(zlcs).equalTo(record::getZlcs)
                .set(cgcs).equalTo(record::getCgcs)
                .set(sbcs).equalTo(record::getSbcs)
                .set(zll).equalTo(record::getZll)
                .set(jtl).equalTo(record::getJtl)
                .set(thzsc).equalTo(record::getThzsc)
                .set(thjsc).equalTo(record::getThjsc)
                .set(unitid).equalTo(record::getUnitid);
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    static UpdateDSL<UpdateModel> updateSelectiveColumns(Arc95013Count record, UpdateDSL<UpdateModel> dsl) {
        return dsl.set(id).equalToWhenPresent(record::getId)
                .set(start_time).equalToWhenPresent(record::getStart_time)
                .set(bdcs).equalToWhenPresent(record::getBdcs)
                .set(zlcs).equalToWhenPresent(record::getZlcs)
                .set(cgcs).equalToWhenPresent(record::getCgcs)
                .set(sbcs).equalToWhenPresent(record::getSbcs)
                .set(zll).equalToWhenPresent(record::getZll)
                .set(jtl).equalToWhenPresent(record::getJtl)
                .set(thzsc).equalToWhenPresent(record::getThzsc)
                .set(thjsc).equalToWhenPresent(record::getThjsc)
                .set(unitid).equalToWhenPresent(record::getUnitid);
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    default int updateByPrimaryKey(Arc95013Count record) {
        return update(c ->
            c.set(start_time).equalTo(record::getStart_time)
            .set(bdcs).equalTo(record::getBdcs)
            .set(zlcs).equalTo(record::getZlcs)
            .set(cgcs).equalTo(record::getCgcs)
            .set(sbcs).equalTo(record::getSbcs)
            .set(zll).equalTo(record::getZll)
            .set(jtl).equalTo(record::getJtl)
            .set(thzsc).equalTo(record::getThzsc)
            .set(thjsc).equalTo(record::getThjsc)
            .set(unitid).equalTo(record::getUnitid)
            .where(id, isEqualTo(record::getId))
        );
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    default int updateByPrimaryKeySelective(Arc95013Count record) {
        return update(c ->
            c.set(start_time).equalToWhenPresent(record::getStart_time)
            .set(bdcs).equalToWhenPresent(record::getBdcs)
            .set(zlcs).equalToWhenPresent(record::getZlcs)
            .set(cgcs).equalToWhenPresent(record::getCgcs)
            .set(sbcs).equalToWhenPresent(record::getSbcs)
            .set(zll).equalToWhenPresent(record::getZll)
            .set(jtl).equalToWhenPresent(record::getJtl)
            .set(thzsc).equalToWhenPresent(record::getThzsc)
            .set(thjsc).equalToWhenPresent(record::getThjsc)
            .set(unitid).equalToWhenPresent(record::getUnitid)
            .where(id, isEqualTo(record::getId))
        );
    }
}