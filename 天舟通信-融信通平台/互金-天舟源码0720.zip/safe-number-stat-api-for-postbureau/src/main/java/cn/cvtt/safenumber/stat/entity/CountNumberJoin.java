package cn.cvtt.safenumber.stat.entity;

public class CountNumberJoin extends CountNumber{
    private String unitname;

    public String getUnitname() {
        return unitname;
    }

    public void setUnitname(String unitname) {
        this.unitname = unitname;
    }
}
