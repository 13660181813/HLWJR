package cn.cvtt.safenumber.stat;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SafeNumberStatApplication {

    public static void main(String[] args) {
        SpringApplication.run(SafeNumberStatApplication.class, args);
    }

}
