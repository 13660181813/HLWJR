package cn.cvtt.safenumber.stat.mapper;

import java.sql.JDBCType;
import java.util.Date;
import javax.annotation.Generated;
import org.mybatis.dynamic.sql.SqlColumn;
import org.mybatis.dynamic.sql.SqlTable;

public final class CountNumberDynamicSqlSupport {
    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final CountNumber countNumber = new CountNumber();

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<String> id = countNumber.id;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Date> start_time = countNumber.start_time;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<String> unitid = countNumber.unitid;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<String> msgtype = countNumber.msgtype;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Integer> xzbdcs = countNumber.xzbdcs;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<String> opuidtype = countNumber.opuidtype;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Integer> mailCount = countNumber.mailCount;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final class CountNumber extends SqlTable {
        public final SqlColumn<String> id = column("id", JDBCType.VARCHAR);

        public final SqlColumn<Date> start_time = column("start_time", JDBCType.DATE);

        public final SqlColumn<String> unitid = column("unitid", JDBCType.VARCHAR);

        public final SqlColumn<String> msgtype = column("msgtype", JDBCType.VARCHAR);

        public final SqlColumn<Integer> xzbdcs = column("xzbdcs", JDBCType.INTEGER);

        public final SqlColumn<String> opuidtype = column("opuidtype", JDBCType.VARCHAR);

        public final SqlColumn<Integer> mailCount = column("mailCount", JDBCType.INTEGER);

        public CountNumber() {
            super("COUNT_NUMBER");
        }
    }
}