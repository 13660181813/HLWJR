package cn.cvtt.safenumber.stat.controller;

import cn.cvtt.safenumber.stat.service.CallStatService;
import cn.cvtt.safenumber.stat.service.BindStatService;
import com.alibaba.fastjson.JSONObject;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

@RestController
@RequestMapping("/stat")
public class ApiController {

    @Resource
    private BindStatService bindStatService;

    @Resource
    private CallStatService callStatService;

    @RequestMapping(value = "/bind/{days}", method = RequestMethod.GET)
    public Object getBindStat(@PathVariable("days") Integer days) {
        if (days > 7 || days < 0) {
            JSONObject response = new JSONObject();
            response.put("error", "days can't be greater than 7 and less than 0");
            return response;
        }
        if (days > 0)
            // 返回历史数据
            return bindStatService.getBindStatByDays(days);
        else {
            // 返回当日数据
            return bindStatService.getBindStatToday();
        }
    }

    @RequestMapping(value = "/call/{days}", method = RequestMethod.GET)
    public Object getCallStat(@PathVariable("days") Integer days) {
        if (days > 7 || days < 0) {
            JSONObject response = new JSONObject();
            response.put("error", "days can't be greater than 7 and less than 0");
            return response;
        }
        if (days > 0)
            // 返回历史数据
            return callStatService.getCallStatByDays(days);
        else {
            // 返回当日数据
            return null;
        }
    }
}
