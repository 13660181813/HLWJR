package cn.cvtt.safenumber.stat.mapper;

import java.sql.JDBCType;
import java.util.Date;
import javax.annotation.Generated;
import org.mybatis.dynamic.sql.SqlColumn;
import org.mybatis.dynamic.sql.SqlTable;

public final class Arc95013CountDynamicSqlSupport {
    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final Arc95013Count arc95013Count = new Arc95013Count();

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<String> id = arc95013Count.id;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Date> start_time = arc95013Count.start_time;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Integer> bdcs = arc95013Count.bdcs;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Integer> zlcs = arc95013Count.zlcs;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Integer> cgcs = arc95013Count.cgcs;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Integer> sbcs = arc95013Count.sbcs;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Double> zll = arc95013Count.zll;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Double> jtl = arc95013Count.jtl;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Double> thzsc = arc95013Count.thzsc;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<Double> thjsc = arc95013Count.thjsc;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final SqlColumn<String> unitid = arc95013Count.unitid;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public static final class Arc95013Count extends SqlTable {
        public final SqlColumn<String> id = column("id", JDBCType.VARCHAR);

        public final SqlColumn<Date> start_time = column("start_time", JDBCType.DATE);

        public final SqlColumn<Integer> bdcs = column("bdcs", JDBCType.INTEGER);

        public final SqlColumn<Integer> zlcs = column("zlcs", JDBCType.INTEGER);

        public final SqlColumn<Integer> cgcs = column("cgcs", JDBCType.INTEGER);

        public final SqlColumn<Integer> sbcs = column("sbcs", JDBCType.INTEGER);

        public final SqlColumn<Double> zll = column("zll", JDBCType.DOUBLE);

        public final SqlColumn<Double> jtl = column("jtl", JDBCType.DOUBLE);

        public final SqlColumn<Double> thzsc = column("thzsc", JDBCType.DOUBLE);

        public final SqlColumn<Double> thjsc = column("thjsc", JDBCType.DOUBLE);

        public final SqlColumn<String> unitid = column("unitid", JDBCType.VARCHAR);

        public Arc95013Count() {
            super("ARC_95013_COUNT");
        }
    }
}