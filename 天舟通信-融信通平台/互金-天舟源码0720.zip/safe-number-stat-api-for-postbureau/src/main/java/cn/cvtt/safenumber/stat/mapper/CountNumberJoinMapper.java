package cn.cvtt.safenumber.stat.mapper;

import cn.cvtt.safenumber.stat.entity.CountNumberJoin;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.SelectProvider;
import org.mybatis.dynamic.sql.select.render.SelectStatementProvider;
import org.mybatis.dynamic.sql.util.SqlProviderAdapter;

import java.util.List;

@Mapper
public interface CountNumberJoinMapper {
    @SelectProvider(type= SqlProviderAdapter.class, method="select")
    @ResultMap("CountNumberJoinResult")
    List<CountNumberJoin> selectMany(SelectStatementProvider selectStatement);
}
