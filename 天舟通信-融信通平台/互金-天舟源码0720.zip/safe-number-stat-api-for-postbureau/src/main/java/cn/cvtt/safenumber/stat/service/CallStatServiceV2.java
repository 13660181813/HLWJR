package cn.cvtt.safenumber.stat.service;

import cn.cvtt.safenumber.stat.dto.StatItemV2;
import cn.cvtt.safenumber.stat.entity.Arc95013Count;
import cn.cvtt.safenumber.stat.mapper.Arc95013CountDynamicSqlSupport;
import cn.cvtt.safenumber.stat.mapper.Arc95013CountMapper;
import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.action.support.IndicesOptions;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.client.core.CountRequest;
import org.elasticsearch.client.core.CountResponse;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.elasticsearch.search.aggregations.Aggregations;
import org.elasticsearch.search.aggregations.metrics.ValueCount;
import org.elasticsearch.search.aggregations.metrics.ValueCountAggregationBuilder;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.mybatis.dynamic.sql.render.RenderingStrategies;
import org.mybatis.dynamic.sql.select.render.SelectStatementProvider;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.io.IOException;
import java.util.*;

import static org.mybatis.dynamic.sql.SqlBuilder.*;

@Service
public class CallStatServiceV2 {
    @Resource
    private Arc95013CountMapper arc95013CountMapper;

    @Resource
    private RestHighLevelClient elasticClient;

    private final static Map<String, String> UNIT_MAP = new HashMap<String, String>() {
        {
            put("11000000001", "中通");
            put("11000000002", "申通");
            put("11000000003", "京广");
            put("11000000005", "韵达");
            put("11000000007", "苏宁");
        }
    };

    private List<Arc95013Count> getCallStatByDaysFromDB(Integer days) {
        // 默认取前1天数据
        if (days == null) days = 1;
        // 设定查询起始日期
        Calendar start_time = Calendar.getInstance();
        start_time.setTime(new Date());
        start_time.add(Calendar.DATE, days * -1);
        start_time.set(Calendar.HOUR_OF_DAY, 0);
        start_time.set(Calendar.MINUTE, 0);
        start_time.set(Calendar.SECOND, 0);
        start_time.set(Calendar.MILLISECOND, 0);

        // 生成动态sql
        SelectStatementProvider selectStatement = select(
                Arc95013CountDynamicSqlSupport.id,
                Arc95013CountDynamicSqlSupport.unitid,
                Arc95013CountDynamicSqlSupport.start_time,
                Arc95013CountDynamicSqlSupport.bdcs,
                Arc95013CountDynamicSqlSupport.cgcs,
                Arc95013CountDynamicSqlSupport.sbcs,
                Arc95013CountDynamicSqlSupport.zlcs,
                Arc95013CountDynamicSqlSupport.zll,
                Arc95013CountDynamicSqlSupport.jtl,
                Arc95013CountDynamicSqlSupport.thjsc,
                Arc95013CountDynamicSqlSupport.thzsc
        )
                .from(Arc95013CountDynamicSqlSupport.arc95013Count)
                .where(Arc95013CountDynamicSqlSupport.start_time, isGreaterThanOrEqualTo(start_time.getTime()))
                .orderBy(Arc95013CountDynamicSqlSupport.start_time)
                .build()
                .render(RenderingStrategies.MYBATIS3);

        // 执行查询
        return arc95013CountMapper.selectMany(selectStatement);
    }

    public Object getTodayCallStatTest(String unit_id, String type) {
        // todo type==ring_rate时返回%字符串
        // 设定查询起始时间（今天0点到明天0点）
        Calendar start_time = Calendar.getInstance();
        Calendar end_time = Calendar.getInstance();
        start_time.setTime(new Date());
        start_time.set(Calendar.HOUR_OF_DAY, 0);
        start_time.set(Calendar.MINUTE, 0);
        start_time.set(Calendar.SECOND, 0);
        start_time.set(Calendar.MILLISECOND, 0);
        end_time.setTime(start_time.getTime());
        end_time.add(Calendar.DATE, 1);

        // 构造查询
        SearchSourceBuilder searchSourceBuilder = new SearchSourceBuilder();
        searchSourceBuilder.query(
                QueryBuilders.boolQuery()
                        .must(QueryBuilders.rangeQuery("@timestamp").from(start_time).to(end_time))
                        .must(QueryBuilders.termQuery("accountcode", unit_id))
                        .must(QueryBuilders.termQuery("direction", "inbound"))
        );

        CountRequest countRequest = new CountRequest("logstash-freeswitch-csv-cdr*")
                .indicesOptions(IndicesOptions.lenientExpandOpen())
                .preference("_local");
        countRequest.source(searchSourceBuilder);

        try {
            CountResponse countResponse = elasticClient
                    .count(countRequest, RequestOptions.DEFAULT);
            return countResponse.getCount();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return 0;
    }

    public Long getTodayCallStat(List<String> unit_ids, String type) {

        // 设定查询起始时间（今天0点到明天0点）
        Calendar start_time = Calendar.getInstance();
        Calendar end_time = Calendar.getInstance();
        start_time.setTime(new Date());
        start_time.set(Calendar.HOUR_OF_DAY, 0);
        start_time.set(Calendar.MINUTE, 0);
        start_time.set(Calendar.SECOND, 0);
        start_time.set(Calendar.MILLISECOND, 0);
        end_time.setTime(start_time.getTime());
        end_time.add(Calendar.DATE, 1);

        // 创建SearchRequest对象, 索引名=logstash-freeswitch-csv-cdr*
        SearchRequest searchRequest = new SearchRequest("logstash-freeswitch-csv-cdr*");
        // 通过QueryBuilders构建ES查询条件
        BoolQueryBuilder queryBuilder = QueryBuilders.boolQuery()
                .filter(QueryBuilders.rangeQuery("@timestamp").from(start_time).to(end_time))
                .filter(QueryBuilders.termsQuery("accountcode", unit_ids))
                .filter(QueryBuilders.termQuery("direction", "inbound"));

        switch (type) {
            case "count": {
                // 通过SearchSourceBuilder构建搜索参数
                SearchSourceBuilder sourceBuilder = new SearchSourceBuilder();
                sourceBuilder.query(queryBuilder);
                // 创建Value Count指标聚合
                // 聚合统计命名为：call-count， 统计accountcode字段值的数量
                ValueCountAggregationBuilder valueCountAggregationBuilder = AggregationBuilders.count("call-count")
                        .field("accountcode.keyword");
                sourceBuilder.aggregation(valueCountAggregationBuilder);
                sourceBuilder.size(0);
                // 设置搜索条件
                searchRequest.source(sourceBuilder);
                // 执行ES请求
                try {
                    SearchResponse searchResponse = elasticClient.search(searchRequest, RequestOptions.DEFAULT);
                    // 处理聚合查询结果
                    Aggregations aggregations = searchResponse.getAggregations();
                    // 根据call-count命名查询，ValueCount统计结果
                    ValueCount valueCount = aggregations.get("call-count");
                    return valueCount.getValue();
                } catch (IOException e) {
                    e.printStackTrace();
                    return (long) 0;
                }
            }
            case "ring_rate":
            case "average_time":
            default:
                break;
        }

        return (long) 0;
    }

    /**
     * 从MySQL和ES中获取数据并合并
     *
     * @return
     */
    public Object getCallStat(String type) {
        // 定义返回结果对象(Map)
        Map<String, StatItemV2> statItemMap = new HashMap<>();
        // 根据UNIT_MAP初始化返回结果
        UNIT_MAP.forEach((unit_id, unit_name) -> {
            statItemMap.put(unit_id, new StatItemV2(unit_name));
        });

        Calendar now = Calendar.getInstance();
        now.setTime(new Date());
        now.set(Calendar.HOUR_OF_DAY, 0);
        now.set(Calendar.MINUTE, 0);
        now.set(Calendar.SECOND, 0);
        now.set(Calendar.MILLISECOND, 0);

        // 从数据库获取前x天数据
        List<Arc95013Count> rows = getCallStatByDaysFromDB(7);
        // 遍历结果集，构造返回数据
        for (Arc95013Count row :
                rows) {
            if (statItemMap.get(row.getUnitid()) == null) continue;
            // 根据row的start_time判断数组(StatItemV2.data)下标
            long daysDiff = (now.getTime().getTime() - row.getStart_time().getTime()) / (3600 * 24 * 1000);
            if (daysDiff > 7 || daysDiff < 1) continue;
            switch (type) {
                case "count":
                    //statItemMap.get(row.getUnitid()).getData().add(row.getBdcs());
                    statItemMap.get(row.getUnitid()).getData().set(7 - (int) daysDiff, row.getBdcs());
                    break;
                case "ring_rate":
                    //statItemMap.get(row.getUnitid()).getData().add(String.format("%.2f", row.getZll() * 100) + "%");
                    statItemMap.get(row.getUnitid()).getData().set(7 - (int) daysDiff, String.format("%.2f", row.getZll() * 100) + "%");
                    break;
                case "average_time":
                    //statItemMap.get(row.getUnitid()).getData().add(row.getThjsc().intValue());
                    statItemMap.get(row.getUnitid()).getData().set(7 - (int) daysDiff, row.getThjsc().intValue());
                    break;
                default:
                    break;
            }
        }

        // 从ES获取当前数据
        /*UNIT_MAP.forEach((unit_id, unit_name) -> {
            statItemMap.get(unit_id).getData().add(getTodayCallStat(unit_id, type));
        });*/

        // 把返回结果转换为List
        List<StatItemV2> statItemList = new ArrayList<>();
        statItemMap.forEach((unit_id, data) -> {
            statItemList.add(data);
        });

        return statItemList;
    }

    private List<Arc95013Count> getCallTimeSum() {
        // 设定查询起始日期
        Calendar start_time = Calendar.getInstance();
        start_time.setTime(new Date());
        start_time.add(Calendar.DATE, -7);
        start_time.set(Calendar.HOUR_OF_DAY, 0);
        start_time.set(Calendar.MINUTE, 0);
        start_time.set(Calendar.SECOND, 0);
        start_time.set(Calendar.MILLISECOND, 0);

        // 生成动态sql
        SelectStatementProvider selectStatement = select(
                Arc95013CountDynamicSqlSupport.start_time,
                sum(Arc95013CountDynamicSqlSupport.thzsc).as("thzsc")
        )
                .from(Arc95013CountDynamicSqlSupport.arc95013Count)
                .where(Arc95013CountDynamicSqlSupport.start_time, isGreaterThanOrEqualTo(start_time.getTime()))
                .groupBy(Arc95013CountDynamicSqlSupport.start_time)
                .orderBy(Arc95013CountDynamicSqlSupport.start_time)
                .build()
                .render(RenderingStrategies.MYBATIS3);

        // 执行查询
        return arc95013CountMapper.selectMany(selectStatement);
    }

    private List<Arc95013Count> getCallCountSum() {
        // 设定查询起始日期
        Calendar start_time = Calendar.getInstance();
        start_time.setTime(new Date());
        start_time.add(Calendar.DATE, -7);
        start_time.set(Calendar.HOUR_OF_DAY, 0);
        start_time.set(Calendar.MINUTE, 0);
        start_time.set(Calendar.SECOND, 0);
        start_time.set(Calendar.MILLISECOND, 0);

        // 生成动态sql
        SelectStatementProvider selectStatement = select(
                Arc95013CountDynamicSqlSupport.start_time,
                sum(Arc95013CountDynamicSqlSupport.bdcs).as("bdcs")
        )
                .from(Arc95013CountDynamicSqlSupport.arc95013Count)
                .where(Arc95013CountDynamicSqlSupport.start_time, isGreaterThanOrEqualTo(start_time.getTime()))
                .groupBy(Arc95013CountDynamicSqlSupport.start_time)
                .orderBy(Arc95013CountDynamicSqlSupport.start_time)
                .build()
                .render(RenderingStrategies.MYBATIS3);

        // 执行查询
        return arc95013CountMapper.selectMany(selectStatement);
    }

    public Object getCallUsage(String type) {
        Calendar now = Calendar.getInstance();
        now.setTime(new Date());
        now.set(Calendar.HOUR_OF_DAY, 0);
        now.set(Calendar.MINUTE, 0);
        now.set(Calendar.SECOND, 0);
        now.set(Calendar.MILLISECOND, 0);
        // 定义返回结果对象(Map)
        Map<String, StatItemV2> statItemMap = new HashMap<>();

        if ("time".equals(type)) {
            statItemMap.put("总时长（秒）", new StatItemV2("总时长（秒）"));
            List<Arc95013Count> arc95013Counts = getCallTimeSum();
            for (Arc95013Count row :
                    arc95013Counts) {
                // 根据row的start_time判断数组(StatItemV2.data)下标
                long daysDiff = (now.getTime().getTime() - row.getStart_time().getTime()) / (3600 * 24 * 1000);
                if (daysDiff > 7 || daysDiff < 1) continue;
                //statItemMap.get("总时长（秒）").getData().add(row.getThzsc().intValue());
                statItemMap.get("总时长（秒）").getData().set(7 - (int) daysDiff, row.getThzsc().intValue());
            }
        } else if ("count".equals(type)) {
            statItemMap.put("呼叫次数", new StatItemV2("呼叫次数"));
            List<Arc95013Count> arc95013Counts = getCallCountSum();
            for (Arc95013Count row :
                    arc95013Counts) {
                // 根据row的start_time判断数组(StatItemV2.data)下标
                long daysDiff = (now.getTime().getTime() - row.getStart_time().getTime()) / (3600 * 24 * 1000);
                if (daysDiff > 7 || daysDiff < 1) continue;
                //statItemMap.get("呼叫次数").getData().add(row.getBdcs());
                statItemMap.get("呼叫次数").getData().set(7 - (int) daysDiff, row.getBdcs());
            }
        }

        // 把返回结果转换为List
        List<StatItemV2> statItemList = new ArrayList<>();
        statItemMap.forEach((unit_id, data) -> {
            statItemList.add(data);
        });

        return statItemList;
    }

    public Map<String, Arc95013Count> getCallTimeSumGroupByUnit() {
        // 设定查询起始日期
        Calendar start_time = Calendar.getInstance();
        start_time.setTime(new Date());
        start_time.add(Calendar.DATE, -7);
        start_time.set(Calendar.HOUR_OF_DAY, 0);
        start_time.set(Calendar.MINUTE, 0);
        start_time.set(Calendar.SECOND, 0);
        start_time.set(Calendar.MILLISECOND, 0);

        // 生成动态sql
        SelectStatementProvider selectStatement = select(
                Arc95013CountDynamicSqlSupport.unitid,
                sum(Arc95013CountDynamicSqlSupport.thzsc).as("thzsc")
        )
                .from(Arc95013CountDynamicSqlSupport.arc95013Count)
                .where(Arc95013CountDynamicSqlSupport.start_time, isGreaterThanOrEqualTo(start_time.getTime()))
                .groupBy(Arc95013CountDynamicSqlSupport.unitid)
                .build()
                .render(RenderingStrategies.MYBATIS3);

        // 执行查询
        List<Arc95013Count> rows = arc95013CountMapper.selectMany(selectStatement);

        // 转换为map
        Map<String, Arc95013Count> rowMap = new HashMap<>();
        rows.forEach((row) -> {
            rowMap.put(row.getUnitid(), row);
        });

        return rowMap;
    }

    public Map<String, Arc95013Count> getCallCountSumGroupByUnit() {
        // 设定查询起始日期
        Calendar start_time = Calendar.getInstance();
        start_time.setTime(new Date());
        start_time.add(Calendar.DATE, -7);
        start_time.set(Calendar.HOUR_OF_DAY, 0);
        start_time.set(Calendar.MINUTE, 0);
        start_time.set(Calendar.SECOND, 0);
        start_time.set(Calendar.MILLISECOND, 0);

        // 生成动态sql
        SelectStatementProvider selectStatement = select(
                Arc95013CountDynamicSqlSupport.unitid,
                sum(Arc95013CountDynamicSqlSupport.bdcs).as("bdcs")
        )
                .from(Arc95013CountDynamicSqlSupport.arc95013Count)
                .where(Arc95013CountDynamicSqlSupport.start_time, isGreaterThanOrEqualTo(start_time.getTime()))
                .groupBy(Arc95013CountDynamicSqlSupport.unitid)
                .build()
                .render(RenderingStrategies.MYBATIS3);

        // 执行查询
        List<Arc95013Count> rows = arc95013CountMapper.selectMany(selectStatement);

        // 转换为map
        Map<String, Arc95013Count> rowMap = new HashMap<>();
        rows.forEach((row) -> {
            rowMap.put(row.getUnitid(), row);
        });

        return rowMap;
    }

    public Integer getCallCountSum(List<String> unit_ids) {
        // 生成动态sql
        SelectStatementProvider selectStatement = select(
                sum(Arc95013CountDynamicSqlSupport.bdcs).as("bdcs")
        )
                .from(Arc95013CountDynamicSqlSupport.arc95013Count)
                .where(Arc95013CountDynamicSqlSupport.unitid, isIn(unit_ids))
                .build()
                .render(RenderingStrategies.MYBATIS3);

        // 执行查询
        Optional<Arc95013Count> arc95013Count = arc95013CountMapper.selectOne(selectStatement);
        if (arc95013Count.isPresent())
            return arc95013Count.get().getBdcs();
        else
            return 0;
    }
}
