package cn.cvtt.safenumber.stat.service;

import cn.cvtt.safenumber.stat.dto.CallStat;
import cn.cvtt.safenumber.stat.dto.CallStatItem;
import cn.cvtt.safenumber.stat.entity.Arc95013CountJoin;
import cn.cvtt.safenumber.stat.mapper.Arc95013CountDynamicSqlSupport;
import cn.cvtt.safenumber.stat.mapper.Arc95013CountJoinMapper;
import cn.cvtt.safenumber.stat.mapper.TUnitDynamicSqlSupport;
import org.apache.commons.lang3.StringUtils;
import org.mybatis.dynamic.sql.render.RenderingStrategies;
import org.mybatis.dynamic.sql.select.render.SelectStatementProvider;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.text.SimpleDateFormat;
import java.util.*;

import static org.mybatis.dynamic.sql.SqlBuilder.*;

@Service
public class CallStatService {
    @Value("${cvtt.exclude-unit:}")
    private String[] excludeUnit;

    @Resource
    private Arc95013CountJoinMapper arc95013CountJoinMapper;

    public Object getCallStatByDays(Integer days) {
        // 默认取前7天数据
        if (days == null) days = 7;
        // 设定查询起始日期
        Calendar start_time = Calendar.getInstance();
        start_time.setTime(new Date());
        start_time.add(Calendar.DATE, days * -1);
        start_time.set(Calendar.HOUR_OF_DAY, 0);
        start_time.set(Calendar.MINUTE, 0);
        start_time.set(Calendar.SECOND, 0);
        start_time.set(Calendar.MILLISECOND, 0);

        // 生成动态sql
        SelectStatementProvider selectStatement = select(
                Arc95013CountDynamicSqlSupport.id,
                Arc95013CountDynamicSqlSupport.unitid,
                Arc95013CountDynamicSqlSupport.start_time,
                Arc95013CountDynamicSqlSupport.bdcs,
                Arc95013CountDynamicSqlSupport.cgcs,
                Arc95013CountDynamicSqlSupport.sbcs,
                Arc95013CountDynamicSqlSupport.zlcs,
                Arc95013CountDynamicSqlSupport.zll,
                Arc95013CountDynamicSqlSupport.jtl,
                Arc95013CountDynamicSqlSupport.thjsc,
                Arc95013CountDynamicSqlSupport.thzsc,
                TUnitDynamicSqlSupport.unitname
        )
                .from(Arc95013CountDynamicSqlSupport.arc95013Count, "stat")
                .leftJoin(TUnitDynamicSqlSupport.TUnit, "unit").on(Arc95013CountDynamicSqlSupport.unitid, equalTo(TUnitDynamicSqlSupport.unitid))
                .where(Arc95013CountDynamicSqlSupport.start_time, isGreaterThanOrEqualTo(start_time.getTime()))
                .orderBy(Arc95013CountDynamicSqlSupport.start_time)
                .build()
                .render(RenderingStrategies.MYBATIS3);

        // 执行查询
        List<Arc95013CountJoin> rows = arc95013CountJoinMapper.selectMany(selectStatement);

        // 遍历结果集，放入新的数据结构（map）
        Map<String, CallStat> callStatMap = new LinkedHashMap<>();

        for (Arc95013CountJoin row :
                rows) {
            if (StringUtils.isBlank(row.getUnitname())) continue;
            if (row.getStart_time() == null) continue;
            boolean ignoreUnit = false;
            for (String unit :
                    excludeUnit) {
                if (StringUtils.equals(unit, row.getUnitid())) {
                    ignoreUnit = true;
                    break;
                }
            }
            if (ignoreUnit) continue;

            String startTime = new SimpleDateFormat("yyyy-MM-dd").format(row.getStart_time());

            CallStat callStat = callStatMap.get(row.getUnitname());
            if (callStat == null) callStat = new CallStat();

            CallStatItem callStatItem = callStat.getStatData().get(startTime);
            if (callStatItem == null) callStatItem = new CallStatItem();

            if (row.getBdcs() != null) callStatItem.setTotalCount(row.getBdcs());
            if (row.getZll() != null) callStatItem.setRingRate(row.getZll());
            if (row.getThzsc() != null) callStatItem.setTotalTime(row.getThzsc().intValue());
            if (row.getThjsc() != null) callStatItem.setAverageTime(row.getThjsc().intValue());

            callStat.getStatData().put(startTime, callStatItem);
            callStatMap.put(row.getUnitname(), callStat);
        }
        return callStatMap;
    }
}
