package cn.cvtt.safenumber.stat.mapper;

import static cn.cvtt.safenumber.stat.mapper.CountNumberDynamicSqlSupport.*;
import static org.mybatis.dynamic.sql.SqlBuilder.*;

import cn.cvtt.safenumber.stat.entity.CountNumber;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import javax.annotation.Generated;
import org.apache.ibatis.annotations.DeleteProvider;
import org.apache.ibatis.annotations.InsertProvider;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.SelectProvider;
import org.apache.ibatis.annotations.UpdateProvider;
import org.apache.ibatis.type.JdbcType;
import org.mybatis.dynamic.sql.BasicColumn;
import org.mybatis.dynamic.sql.delete.DeleteDSLCompleter;
import org.mybatis.dynamic.sql.delete.render.DeleteStatementProvider;
import org.mybatis.dynamic.sql.insert.render.InsertStatementProvider;
import org.mybatis.dynamic.sql.insert.render.MultiRowInsertStatementProvider;
import org.mybatis.dynamic.sql.select.CountDSLCompleter;
import org.mybatis.dynamic.sql.select.SelectDSLCompleter;
import org.mybatis.dynamic.sql.select.render.SelectStatementProvider;
import org.mybatis.dynamic.sql.update.UpdateDSL;
import org.mybatis.dynamic.sql.update.UpdateDSLCompleter;
import org.mybatis.dynamic.sql.update.UpdateModel;
import org.mybatis.dynamic.sql.update.render.UpdateStatementProvider;
import org.mybatis.dynamic.sql.util.SqlProviderAdapter;
import org.mybatis.dynamic.sql.util.mybatis3.MyBatis3Utils;

@Mapper
public interface CountNumberMapper {
    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    BasicColumn[] selectList = BasicColumn.columnList(id, start_time, unitid, msgtype, xzbdcs, opuidtype, mailCount);

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    @SelectProvider(type=SqlProviderAdapter.class, method="select")
    long count(SelectStatementProvider selectStatement);

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    @DeleteProvider(type=SqlProviderAdapter.class, method="delete")
    int delete(DeleteStatementProvider deleteStatement);

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    @InsertProvider(type=SqlProviderAdapter.class, method="insert")
    int insert(InsertStatementProvider<CountNumber> insertStatement);

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    @InsertProvider(type=SqlProviderAdapter.class, method="insertMultiple")
    int insertMultiple(MultiRowInsertStatementProvider<CountNumber> multipleInsertStatement);

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    @SelectProvider(type=SqlProviderAdapter.class, method="select")
    @ResultMap("CountNumberResult")
    Optional<CountNumber> selectOne(SelectStatementProvider selectStatement);

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    @SelectProvider(type=SqlProviderAdapter.class, method="select")
    @Results(id="CountNumberResult", value = {
        @Result(column="id", property="id", jdbcType=JdbcType.VARCHAR, id=true),
        @Result(column="start_time", property="start_time", jdbcType=JdbcType.DATE),
        @Result(column="unitid", property="unitid", jdbcType=JdbcType.VARCHAR),
        @Result(column="msgtype", property="msgtype", jdbcType=JdbcType.VARCHAR),
        @Result(column="xzbdcs", property="xzbdcs", jdbcType=JdbcType.INTEGER),
        @Result(column="opuidtype", property="opuidtype", jdbcType=JdbcType.VARCHAR),
        @Result(column="mailCount", property="mailCount", jdbcType=JdbcType.INTEGER)
    })
    List<CountNumber> selectMany(SelectStatementProvider selectStatement);

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    @UpdateProvider(type=SqlProviderAdapter.class, method="update")
    int update(UpdateStatementProvider updateStatement);

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    default long count(CountDSLCompleter completer) {
        return MyBatis3Utils.countFrom(this::count, countNumber, completer);
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    default int delete(DeleteDSLCompleter completer) {
        return MyBatis3Utils.deleteFrom(this::delete, countNumber, completer);
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    default int deleteByPrimaryKey(String id_) {
        return delete(c -> 
            c.where(id, isEqualTo(id_))
        );
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    default int insert(CountNumber record) {
        return MyBatis3Utils.insert(this::insert, record, countNumber, c ->
            c.map(id).toProperty("id")
            .map(start_time).toProperty("start_time")
            .map(unitid).toProperty("unitid")
            .map(msgtype).toProperty("msgtype")
            .map(xzbdcs).toProperty("xzbdcs")
            .map(opuidtype).toProperty("opuidtype")
            .map(mailCount).toProperty("mailCount")
        );
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    default int insertMultiple(Collection<CountNumber> records) {
        return MyBatis3Utils.insertMultiple(this::insertMultiple, records, countNumber, c ->
            c.map(id).toProperty("id")
            .map(start_time).toProperty("start_time")
            .map(unitid).toProperty("unitid")
            .map(msgtype).toProperty("msgtype")
            .map(xzbdcs).toProperty("xzbdcs")
            .map(opuidtype).toProperty("opuidtype")
            .map(mailCount).toProperty("mailCount")
        );
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    default int insertSelective(CountNumber record) {
        return MyBatis3Utils.insert(this::insert, record, countNumber, c ->
            c.map(id).toPropertyWhenPresent("id", record::getId)
            .map(start_time).toPropertyWhenPresent("start_time", record::getStart_time)
            .map(unitid).toPropertyWhenPresent("unitid", record::getUnitid)
            .map(msgtype).toPropertyWhenPresent("msgtype", record::getMsgtype)
            .map(xzbdcs).toPropertyWhenPresent("xzbdcs", record::getXzbdcs)
            .map(opuidtype).toPropertyWhenPresent("opuidtype", record::getOpuidtype)
            .map(mailCount).toPropertyWhenPresent("mailCount", record::getMailCount)
        );
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    default Optional<CountNumber> selectOne(SelectDSLCompleter completer) {
        return MyBatis3Utils.selectOne(this::selectOne, selectList, countNumber, completer);
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    default List<CountNumber> select(SelectDSLCompleter completer) {
        return MyBatis3Utils.selectList(this::selectMany, selectList, countNumber, completer);
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    default List<CountNumber> selectDistinct(SelectDSLCompleter completer) {
        return MyBatis3Utils.selectDistinct(this::selectMany, selectList, countNumber, completer);
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    default Optional<CountNumber> selectByPrimaryKey(String id_) {
        return selectOne(c ->
            c.where(id, isEqualTo(id_))
        );
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    default int update(UpdateDSLCompleter completer) {
        return MyBatis3Utils.update(this::update, countNumber, completer);
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    static UpdateDSL<UpdateModel> updateAllColumns(CountNumber record, UpdateDSL<UpdateModel> dsl) {
        return dsl.set(id).equalTo(record::getId)
                .set(start_time).equalTo(record::getStart_time)
                .set(unitid).equalTo(record::getUnitid)
                .set(msgtype).equalTo(record::getMsgtype)
                .set(xzbdcs).equalTo(record::getXzbdcs)
                .set(opuidtype).equalTo(record::getOpuidtype)
                .set(mailCount).equalTo(record::getMailCount);
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    static UpdateDSL<UpdateModel> updateSelectiveColumns(CountNumber record, UpdateDSL<UpdateModel> dsl) {
        return dsl.set(id).equalToWhenPresent(record::getId)
                .set(start_time).equalToWhenPresent(record::getStart_time)
                .set(unitid).equalToWhenPresent(record::getUnitid)
                .set(msgtype).equalToWhenPresent(record::getMsgtype)
                .set(xzbdcs).equalToWhenPresent(record::getXzbdcs)
                .set(opuidtype).equalToWhenPresent(record::getOpuidtype)
                .set(mailCount).equalToWhenPresent(record::getMailCount);
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    default int updateByPrimaryKey(CountNumber record) {
        return update(c ->
            c.set(start_time).equalTo(record::getStart_time)
            .set(unitid).equalTo(record::getUnitid)
            .set(msgtype).equalTo(record::getMsgtype)
            .set(xzbdcs).equalTo(record::getXzbdcs)
            .set(opuidtype).equalTo(record::getOpuidtype)
            .set(mailCount).equalTo(record::getMailCount)
            .where(id, isEqualTo(record::getId))
        );
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    default int updateByPrimaryKeySelective(CountNumber record) {
        return update(c ->
            c.set(start_time).equalToWhenPresent(record::getStart_time)
            .set(unitid).equalToWhenPresent(record::getUnitid)
            .set(msgtype).equalToWhenPresent(record::getMsgtype)
            .set(xzbdcs).equalToWhenPresent(record::getXzbdcs)
            .set(opuidtype).equalToWhenPresent(record::getOpuidtype)
            .set(mailCount).equalToWhenPresent(record::getMailCount)
            .where(id, isEqualTo(record::getId))
        );
    }
}