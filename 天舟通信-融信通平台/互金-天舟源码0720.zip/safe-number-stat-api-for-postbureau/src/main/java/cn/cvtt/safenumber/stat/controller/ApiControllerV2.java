package cn.cvtt.safenumber.stat.controller;

import cn.cvtt.safenumber.stat.entity.Arc95013Count;
import cn.cvtt.safenumber.stat.entity.CountNumber;
import cn.cvtt.safenumber.stat.service.BindStatServiceV2;
import cn.cvtt.safenumber.stat.service.CacheService;
import cn.cvtt.safenumber.stat.service.CallStatServiceV2;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.text.SimpleDateFormat;
import java.util.*;

@RestController
@RequestMapping("/v2/stat")
public class ApiControllerV2 {

    private final static Map<String, String> UNIT_MAP = new HashMap<String, String>() {
        {
            put("11000000001", "中通");
            put("11000000002", "申通");
            put("11000000003", "京广");
            put("11000000005", "韵达");
            put("11000000007", "苏宁");
        }
    };

    private final static Map<String, String> UNIT_MAP2 = new HashMap<String, String>() {
        {
            put("ZHONGTONG", "11000000001");
            put("SHENTONG", "11000000002");
            put("JINGGUANG", "11000000003");
            put("YUNDA", "11000000005");
            put("SUNING", "11000000007");
        }
    };

    @Resource
    private CallStatServiceV2 callStatServiceV2;
    @Resource
    private BindStatServiceV2 bindStatServiceV2;
    @Resource
    private CacheService cacheService;

    @RequestMapping(value = "random-record/{unit:[ZHONGTONG|SHENTONG|JINGGUANG|SUNING|YUNDA]+}", method = RequestMethod.GET)
    public Object randomRecord(@PathVariable("unit") String unit) {
        String unit_id = UNIT_MAP2.get(unit);
        return bindStatServiceV2.getRandownRecord(unit_id);
    }

    @RequestMapping("/slide-list")
    public Object slideList() {
        Map<String, CountNumber> mailSums = bindStatServiceV2.getMailSumGroupByUnit();
        Map<String, CountNumber> bindSums = bindStatServiceV2.getBindSumGroupByUnit();
        Map<String, Arc95013Count> callCountSums = callStatServiceV2.getCallCountSumGroupByUnit();
        Map<String, Arc95013Count> callTimeSums = callStatServiceV2.getCallTimeSumGroupByUnit();

        JSONObject out = new JSONObject();
        JSONArray dates = new JSONArray();

        UNIT_MAP.forEach((unit_id, unit_name) -> {
            JSONObject data = new JSONObject();
            data.put("company_name", unit_name);
            if (mailSums.get(unit_id) != null)
                data.put("singular_num", mailSums.get(unit_id).getMailCount());
            else
                data.put("singular_num", 0);
            if (bindSums.get(unit_id) != null)
                data.put("bound_num", bindSums.get(unit_id).getXzbdcs());
            else
                data.put("bound_num", 0);
            if (callCountSums.get(unit_id) != null)
                data.put("call_num", callCountSums.get(unit_id).getBdcs());
            else
                data.put("call_num", 0);
            if (callTimeSums.get(unit_id) != null)
                data.put("duration_time", callTimeSums.get(unit_id).getThzsc().intValue());
            else
                data.put("duration_time", 0);
            dates.add(data);
        });

        out.put("slideList", dates);
        return out;
    }

    @RequestMapping("/header-data")
    public Object headerData() {
        // 构造unit_ids
        List<String> unit_ids = new ArrayList<>();
        UNIT_MAP.forEach((unit_id, unit_name) -> {
            unit_ids.add(unit_id);
        });

        // 从redis获取昨日数据
        Calendar yesterday = Calendar.getInstance();
        yesterday.setTime(new Date());
        yesterday.add(Calendar.DATE, -1);
        String date = new SimpleDateFormat("yyyy-MM-dd").format(yesterday.getTime());

        Object lastMail = cacheService.get(date, "mail");
        Object lastBind = cacheService.get(date, "bind");
        Object lastUnbind = cacheService.get(date, "unbind");
        Object lastExtend = cacheService.get(date, "extend");
        Object lastCall = cacheService.get(date, "call");

        Calendar now = Calendar.getInstance();
        now.setTime(new Date());

        // 如果redis中无数据，则从数据库中获取并缓存
        if (lastMail == null) {
            lastMail = bindStatServiceV2.getMailSum(unit_ids);
            if (now.get(Calendar.HOUR_OF_DAY) >= 1)
                cacheService.put(date, "mail", lastMail.toString());
        }
        if (lastBind == null) {
            lastBind = bindStatServiceV2.getBindSum(unit_ids);
            if (now.get(Calendar.HOUR_OF_DAY) >= 1)
                cacheService.put(date, "bind", lastBind.toString());
        }
        if (lastUnbind == null) {
            lastUnbind = bindStatServiceV2.getUnbindSum(unit_ids);
            if (now.get(Calendar.HOUR_OF_DAY) >= 1)
                cacheService.put(date, "unbind", lastUnbind.toString());
        }
        if (lastExtend == null) {
            lastExtend = bindStatServiceV2.getExtendSum(unit_ids);
            if (now.get(Calendar.HOUR_OF_DAY) >= 1)
                cacheService.put(date, "extend", lastExtend.toString());
        }
        if (lastCall == null) {
            lastCall = callStatServiceV2.getCallCountSum(unit_ids);
            if (now.get(Calendar.HOUR_OF_DAY) >= 1)
                cacheService.put(date, "call", lastCall.toString());
        }
        // 从ES获取今日新增数据
        Long newMail = bindStatServiceV2.getTodayMailCount(unit_ids);
        Long newBind = bindStatServiceV2.getTodayBindStat(unit_ids, "bind");
        Long newUnbind = bindStatServiceV2.getTodayBindStat(unit_ids, "unbind");
        Long newExtend = bindStatServiceV2.getTodayBindStat(unit_ids, "extend");
        Long newCall = callStatServiceV2.getTodayCallStat(unit_ids, "count");

        int totalMail, totalBind, totalUnbind, totalExtend, totalCall;
        try {
            totalMail = Integer.parseInt(lastMail.toString());
        } catch (Exception ignore) {
            totalMail = 0;
        }
        try {
            totalBind = Integer.parseInt(lastBind.toString());
        } catch (Exception ignore) {
            totalBind = 0;
        }
        try {
            totalUnbind = Integer.parseInt(lastUnbind.toString());
        } catch (Exception ignore) {
            totalUnbind = 0;
        }
        try {
            totalExtend = Integer.parseInt(lastExtend.toString());
        } catch (Exception ignore) {
            totalExtend = 0;
        }
        try {
            totalCall = Integer.parseInt(lastCall.toString());
        } catch (Exception ignore) {
            totalCall = 0;
        }

        JSONObject out = new JSONObject();
        out.put("express_num", totalMail + newMail);
        out.put("bound_num", totalBind + newBind);
        out.put("unbundle_num", totalUnbind + newUnbind);
        out.put("postpone_num", totalExtend + newExtend);
        out.put("call_num", totalCall + newCall);
        return out;
    }

    @RequestMapping("/date")
    public Object date() {
        JSONObject out = new JSONObject();
        JSONArray dates = new JSONArray();
        Calendar start_time = Calendar.getInstance();
        start_time.setTime(new Date());
        start_time.add(Calendar.DATE, -8);
        start_time.set(Calendar.HOUR_OF_DAY, 0);
        start_time.set(Calendar.MINUTE, 0);
        start_time.set(Calendar.SECOND, 0);
        start_time.set(Calendar.MILLISECOND, 0);
        for (int i = 0; i < 7; i++) {
            start_time.add(Calendar.DATE, 1);
            dates.add(new SimpleDateFormat("yyyy-MM-dd").format(start_time.getTime()));
        }
        out.put("seven_date", dates);
        return out;
    }

    @RequestMapping(value = "/call/{type:[count|ring_rate|average_time]+}", method = RequestMethod.GET)
    public Object callStat(@PathVariable("type") String type) {
        return callStatServiceV2.getCallStat(type);
    }

    @RequestMapping(value = "/num/{type:[bind|unbind|extend]+}", method = RequestMethod.GET)
    public Object bindStat(@PathVariable("type") String type) {
        return bindStatServiceV2.getBindStat(type);
    }

    @RequestMapping(value = "/new/{type:[bind|unbind|mail]+}", method = RequestMethod.GET)
    public Object newData(@PathVariable("type") String type) {
        return bindStatServiceV2.getNewData(type);
    }

    @RequestMapping(value = "/usage/num", method = RequestMethod.GET)
    public Object numUsage() {
        return bindStatServiceV2.getNumUsage();
    }

    @RequestMapping(value = "/usage/call/{type:[count|time]+}", method = RequestMethod.GET)
    public Object callUsage(@PathVariable("type") String type) {
        return callStatServiceV2.getCallUsage(type);
    }
}
