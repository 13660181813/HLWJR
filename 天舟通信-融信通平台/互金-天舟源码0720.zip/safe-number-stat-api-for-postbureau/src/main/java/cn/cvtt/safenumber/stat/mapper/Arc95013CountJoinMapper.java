package cn.cvtt.safenumber.stat.mapper;

import cn.cvtt.safenumber.stat.entity.Arc95013CountJoin;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.SelectProvider;
import org.mybatis.dynamic.sql.select.render.SelectStatementProvider;
import org.mybatis.dynamic.sql.util.SqlProviderAdapter;

import java.util.List;

@Mapper
public interface Arc95013CountJoinMapper {
    @SelectProvider(type= SqlProviderAdapter.class, method="select")
    @ResultMap("Arc95013CountJoinResult")
    List<Arc95013CountJoin> selectMany(SelectStatementProvider selectStatement);
}
