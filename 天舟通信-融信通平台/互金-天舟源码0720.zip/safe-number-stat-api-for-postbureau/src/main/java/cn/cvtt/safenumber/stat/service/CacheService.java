package cn.cvtt.safenumber.stat.service;

import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

@Service
public class CacheService {

    private final static String KEY_PRE = "safe-number-daily:";

    @Resource
    private StringRedisTemplate stringRedisTemplate;

    public Object get(String date, String hk) {
        return stringRedisTemplate.opsForHash().get(KEY_PRE + date, hk);
    }

    public void put(String date, String hk, Object hv) {
        stringRedisTemplate.opsForHash().put(KEY_PRE + date, hk, hv);
    }
}
