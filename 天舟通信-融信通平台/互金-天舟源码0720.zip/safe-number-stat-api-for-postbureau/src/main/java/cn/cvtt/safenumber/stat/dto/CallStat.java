package cn.cvtt.safenumber.stat.dto;

import com.alibaba.fastjson.annotation.JSONField;

import java.util.LinkedHashMap;
import java.util.Map;

public class CallStat {
    @JSONField(name = "呼叫数据")
    private Map<String, CallStatItem> statData;

    public CallStat() {
        this.statData = new LinkedHashMap<>();
    }

    public Map<String, CallStatItem> getStatData() {
        return statData;
    }

    public void setStatData(Map<String, CallStatItem> statData) {
        this.statData = statData;
    }
}
