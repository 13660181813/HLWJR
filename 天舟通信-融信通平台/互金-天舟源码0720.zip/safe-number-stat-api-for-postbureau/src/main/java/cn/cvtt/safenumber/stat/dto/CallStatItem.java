package cn.cvtt.safenumber.stat.dto;

import com.alibaba.fastjson.annotation.JSONField;

public class CallStatItem {
    @JSONField(name = "拨打次数")
    private Integer totalCount;
    @JSONField(name = "振铃率")
    private Double ringRate;
    @JSONField(name = "通话总时长(秒)")
    private Integer totalTime;
    @JSONField(name = "通话均时长(秒)")
    private Integer averageTime;

    public CallStatItem() {
        this.totalCount = 0;
        this.ringRate = 0.0;
        this.totalTime = 0;
        this.averageTime = 0;
    }

    public Integer getTotalCount() {
        return totalCount;
    }

    public void setTotalCount(Integer totalCount) {
        this.totalCount = totalCount;
    }

    public Double getRingRate() {
        return ringRate;
    }

    public void setRingRate(Double ringRate) {
        this.ringRate = ringRate;
    }

    public Integer getTotalTime() {
        return totalTime;
    }

    public void setTotalTime(Integer totalTime) {
        this.totalTime = totalTime;
    }

    public Integer getAverageTime() {
        return averageTime;
    }

    public void setAverageTime(Integer averageTime) {
        this.averageTime = averageTime;
    }
}
