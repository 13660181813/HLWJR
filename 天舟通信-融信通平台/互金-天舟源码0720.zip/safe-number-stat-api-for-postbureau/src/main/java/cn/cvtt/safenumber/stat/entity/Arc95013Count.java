package cn.cvtt.safenumber.stat.entity;

import java.util.Date;
import javax.annotation.Generated;

public class Arc95013Count {
    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private String id;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Date start_time;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Integer bdcs;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Integer zlcs;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Integer cgcs;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Integer sbcs;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Double zll;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Double jtl;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Double thzsc;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Double thjsc;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private String unitid;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public String getId() {
        return id;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setId(String id) {
        this.id = id;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Date getStart_time() {
        return start_time;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setStart_time(Date start_time) {
        this.start_time = start_time;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Integer getBdcs() {
        return bdcs;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setBdcs(Integer bdcs) {
        this.bdcs = bdcs;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Integer getZlcs() {
        return zlcs;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setZlcs(Integer zlcs) {
        this.zlcs = zlcs;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Integer getCgcs() {
        return cgcs;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setCgcs(Integer cgcs) {
        this.cgcs = cgcs;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Integer getSbcs() {
        return sbcs;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setSbcs(Integer sbcs) {
        this.sbcs = sbcs;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Double getZll() {
        return zll;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setZll(Double zll) {
        this.zll = zll;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Double getJtl() {
        return jtl;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setJtl(Double jtl) {
        this.jtl = jtl;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Double getThzsc() {
        return thzsc;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setThzsc(Double thzsc) {
        this.thzsc = thzsc;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Double getThjsc() {
        return thjsc;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setThjsc(Double thjsc) {
        this.thjsc = thjsc;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public String getUnitid() {
        return unitid;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setUnitid(String unitid) {
        this.unitid = unitid;
    }
}