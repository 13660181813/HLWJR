package cn.cvtt.safenumber.stat.dto;

import com.alibaba.fastjson.annotation.JSONField;

public class BindStatItem {
    @JSONField(name = "新增快递单数")
    private Integer increaseMail;
    @JSONField(name = "新增绑定次数")
    private Integer increaseBind;
    @JSONField(name = "新增解绑次数")
    private Integer increaseUnbind;
    @JSONField(name = "新增延期次数")
    private Integer increaseExtend;

    public BindStatItem() {
        this.increaseMail = 0;
        this.increaseBind = 0;
        this.increaseUnbind = 0;
        this.increaseExtend = 0;
    }

    public Integer getIncreaseMail() {
        return increaseMail;
    }

    public void setIncreaseMail(Integer increaseMail) {
        this.increaseMail = increaseMail;
    }

    public Integer getIncreaseBind() {
        return increaseBind;
    }

    public void setIncreaseBind(Integer increaseBind) {
        this.increaseBind = increaseBind;
    }

    public Integer getIncreaseUnbind() {
        return increaseUnbind;
    }

    public void setIncreaseUnbind(Integer increaseUnbind) {
        this.increaseUnbind = increaseUnbind;
    }

    public Integer getIncreaseExtend() {
        return increaseExtend;
    }

    public void setIncreaseExtend(Integer increaseExtend) {
        this.increaseExtend = increaseExtend;
    }
}
