package cn.cvtt.safenumber.stat.entity;

public class Arc95013CountJoin extends Arc95013Count{
    private String unitname;

    public String getUnitname() {
        return unitname;
    }

    public void setUnitname(String unitname) {
        this.unitname = unitname;
    }
}
