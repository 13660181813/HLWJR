package cn.cvtt.safenumber.stat.service;

import cn.cvtt.safenumber.stat.dto.OrderRecord;
import cn.cvtt.safenumber.stat.dto.StatItemSimple;
import cn.cvtt.safenumber.stat.dto.StatItemV2;
import cn.cvtt.safenumber.stat.entity.CountNumber;
import cn.cvtt.safenumber.stat.mapper.CountNumberDynamicSqlSupport;
import cn.cvtt.safenumber.stat.mapper.CountNumberMapper;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import org.apache.commons.lang3.StringUtils;
import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.action.support.IndicesOptions;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.client.core.CountRequest;
import org.elasticsearch.client.core.CountResponse;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.script.Script;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.elasticsearch.search.aggregations.Aggregations;
import org.elasticsearch.search.aggregations.metrics.Cardinality;
import org.elasticsearch.search.aggregations.metrics.CardinalityAggregationBuilder;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.elasticsearch.search.sort.ScriptSortBuilder;
import org.elasticsearch.search.sort.SortBuilders;
import org.elasticsearch.search.sort.SortOrder;
import org.mybatis.dynamic.sql.render.RenderingStrategies;
import org.mybatis.dynamic.sql.select.render.SelectStatementProvider;
import org.springframework.stereotype.Service;
import org.springframework.util.MultiValueMap;
import org.springframework.web.util.UriComponentsBuilder;

import javax.annotation.Resource;
import java.io.IOException;
import java.util.*;

import static org.mybatis.dynamic.sql.SqlBuilder.*;

@Service
public class BindStatServiceV2 {
    @Resource
    private CountNumberMapper countNumberMapper;

    @Resource
    private RestHighLevelClient elasticClient;

    private final static Map<String, String> UNIT_MAP = new HashMap<String, String>() {
        {
            put("11000000001", "中通");
            put("11000000002", "申通");
            put("11000000003", "京广");
            put("11000000005", "韵达");
            put("11000000007", "苏宁");
        }
    };

    public final static Map<String, String> MSG_TYPE_MAP = new HashMap<String, String>() {
        {
            put("bind", "binding_Relation");
            put("unbind", "remove_Relation");
            put("extend", "extend_Relation");
        }
    };

    private List<CountNumber> getBindStatByDaysFromDB(Integer days, String type) {
        // 默认取前1天数据
        if (days == null) days = 1;
        // 设定查询起始日期
        Calendar start_time = Calendar.getInstance();
        start_time.setTime(new Date());
        start_time.add(Calendar.DATE, days * -1);
        start_time.set(Calendar.HOUR_OF_DAY, 0);
        start_time.set(Calendar.MINUTE, 0);
        start_time.set(Calendar.SECOND, 0);
        start_time.set(Calendar.MILLISECOND, 0);

        switch (type) {
            case "bind":
                type = "c";
                break;
            case "unbind":
                type = "d";
                break;
            case "extend":
                type = "e";
                break;
            default:
                break;
        }

        // 生成动态sql
        SelectStatementProvider selectStatement = select(
                CountNumberDynamicSqlSupport.id,
                CountNumberDynamicSqlSupport.unitid,
                CountNumberDynamicSqlSupport.start_time,
                CountNumberDynamicSqlSupport.mailCount,
                CountNumberDynamicSqlSupport.xzbdcs,
                CountNumberDynamicSqlSupport.opuidtype,
                CountNumberDynamicSqlSupport.msgtype
        )
                .from(CountNumberDynamicSqlSupport.countNumber)
                .where(CountNumberDynamicSqlSupport.start_time, isGreaterThanOrEqualTo(start_time.getTime()))
                .and(CountNumberDynamicSqlSupport.opuidtype, isEqualTo(type))
                .orderBy(CountNumberDynamicSqlSupport.start_time)
                .build()
                .render(RenderingStrategies.MYBATIS3);

        // 执行查询
        return countNumberMapper.selectMany(selectStatement);
    }

    public Long getTodayBindStat(List<String> unit_ids, String type) {
        // 设定查询起始时间（今天0点到明天0点）
        Calendar start_time = Calendar.getInstance();
        Calendar end_time = Calendar.getInstance();
        start_time.setTime(new Date());
        start_time.set(Calendar.HOUR_OF_DAY, 0);
        start_time.set(Calendar.MINUTE, 0);
        start_time.set(Calendar.SECOND, 0);
        start_time.set(Calendar.MILLISECOND, 0);
        end_time.setTime(start_time.getTime());
        end_time.add(Calendar.DATE, 1);

        CountRequest countRequest = new CountRequest("safenumber-api*")
                .indicesOptions(IndicesOptions.lenientExpandOpen())
                .preference("_local");

        // 构造查询
        BoolQueryBuilder queryBuilder = QueryBuilders.boolQuery()
                .must(QueryBuilders.rangeQuery("@timestamp").from(start_time).to(end_time))
                //.must(QueryBuilders.termsQuery("client.ip", "10.15.144.31", "10.15.144.32"))
                .must(QueryBuilders.termQuery("msgtype", MSG_TYPE_MAP.get(type)))
                .must(QueryBuilders.termsQuery("unitID", unit_ids))
                .mustNot(QueryBuilders.existsQuery("error_response.code"));

        SearchSourceBuilder searchSourceBuilder = new SearchSourceBuilder();
        searchSourceBuilder.query(queryBuilder);

        countRequest.source(searchSourceBuilder);

        try {
            CountResponse countResponse = elasticClient
                    .count(countRequest, RequestOptions.DEFAULT);
            return countResponse.getCount();
        } catch (IOException e) {
            e.printStackTrace();
            return (long) 0;
        }
    }

    public Long getTodayMailCount(List<String> unit_ids) {
        // 设定查询起始时间（今天0点到明天0点）
        Calendar start_time = Calendar.getInstance();
        Calendar end_time = Calendar.getInstance();
        start_time.setTime(new Date());
        start_time.set(Calendar.HOUR_OF_DAY, 0);
        start_time.set(Calendar.MINUTE, 0);
        start_time.set(Calendar.SECOND, 0);
        start_time.set(Calendar.MILLISECOND, 0);
        end_time.setTime(start_time.getTime());
        end_time.add(Calendar.DATE, 1);

        // 创建SearchRequest对象, 索引名=safenumber-api*
        SearchRequest searchRequest = new SearchRequest("safenumber-api*");
        // 通过QueryBuilders构建ES查询条件
        BoolQueryBuilder queryBuilder = QueryBuilders.boolQuery()
                .filter(QueryBuilders.rangeQuery("@timestamp").from(start_time).to(end_time))
                .filter(QueryBuilders.termQuery("msgtype", MSG_TYPE_MAP.get("bind")))
                .filter(QueryBuilders.termsQuery("unitID", unit_ids));
        // 通过SearchSourceBuilder构建搜索参数
        SearchSourceBuilder sourceBuilder = new SearchSourceBuilder();
        sourceBuilder.query(queryBuilder);
        CardinalityAggregationBuilder cardinalityAggregationBuilder = AggregationBuilders.cardinality("mail-count")
                .field("binding_response.uuidinpartner");
        sourceBuilder.aggregation(cardinalityAggregationBuilder);
        sourceBuilder.size(0);
        // 设置搜索条件
        searchRequest.source(sourceBuilder);
        // 执行ES请求
        try {
            SearchResponse searchResponse = elasticClient.search(searchRequest, RequestOptions.DEFAULT);
            // 处理聚合查询结果
            Aggregations aggregations = searchResponse.getAggregations();
            // 根据call-count命名查询，ValueCount统计结果
            Cardinality cardinality = aggregations.get("mail-count");
            return cardinality.getValue();
        } catch (IOException e) {
            e.printStackTrace();
            return (long) 0;
        }
    }

    public Object getBindStat(String type) {
        // 定义返回结果对象(Map)
        Map<String, StatItemV2> statItemMap = new HashMap<>();
        // 根据UNIT_MAP初始化返回结果
        UNIT_MAP.forEach((unit_id, unit_name) -> {
            statItemMap.put(unit_id, new StatItemV2(unit_name));
        });

        Calendar now = Calendar.getInstance();
        now.setTime(new Date());
        now.set(Calendar.HOUR_OF_DAY, 0);
        now.set(Calendar.MINUTE, 0);
        now.set(Calendar.SECOND, 0);
        now.set(Calendar.MILLISECOND, 0);

        // 从数据库获取前x天数据
        List<CountNumber> rows = getBindStatByDaysFromDB(7, type);
        // 遍历结果集，构造返回数据
        for (CountNumber row :
                rows) {
            if (statItemMap.get(row.getUnitid()) == null) continue;
            // 根据row的start_time判断数组(StatItemV2.data)下标
            long daysDiff = (now.getTime().getTime() - row.getStart_time().getTime()) / (3600 * 24 * 1000);
            if (daysDiff > 7 || daysDiff < 1) continue;
            statItemMap.get(row.getUnitid()).getData().set(7 - (int) daysDiff, row.getXzbdcs());
        }

        // 从ES获取当前数据
        /*UNIT_MAP.forEach((unit_id, unit_name) -> {
            statItemMap.get(unit_id).getData().add(getTodayBindStat(unit_id, type));
        });*/

        // 把返回结果转换为List
        List<StatItemV2> statItemList = new ArrayList<>();
        statItemMap.forEach((unit_id, data) -> {
            statItemList.add(data);
        });

        return statItemList;
    }

    public Object getNewData(String type) {
        // 定义返回结果对象(Map)
        Map<String, StatItemSimple> statItemMap = new HashMap<>();
        // 根据UNIT_MAP初始化返回结果
        UNIT_MAP.forEach((unit_id, unit_name) -> {
            statItemMap.put(unit_id, new StatItemSimple(unit_name));
        });

        // 从ES获取当前数据
        UNIT_MAP.forEach((unit_id, unit_name) -> {
            if ("mail".equals(type))
                statItemMap.get(unit_id).setValue(getTodayMailCount(Collections.singletonList(unit_id)));
            else
                statItemMap.get(unit_id).setValue(getTodayBindStat(Collections.singletonList(unit_id), type));
        });

        // 把返回结果转换为List
        List<StatItemSimple> statItemList = new ArrayList<>();
        statItemMap.forEach((unit_id, data) -> {
            statItemList.add(data);
        });

        return statItemList;
    }

    private List<CountNumber> getMailSum() {
        // 设定查询起始日期
        Calendar start_time = Calendar.getInstance();
        start_time.setTime(new Date());
        start_time.add(Calendar.DATE, -7);
        start_time.set(Calendar.HOUR_OF_DAY, 0);
        start_time.set(Calendar.MINUTE, 0);
        start_time.set(Calendar.SECOND, 0);
        start_time.set(Calendar.MILLISECOND, 0);

        // 生成动态sql
        SelectStatementProvider selectStatement = select(
                CountNumberDynamicSqlSupport.start_time,
                sum(CountNumberDynamicSqlSupport.mailCount).as("mailCount")
        )
                .from(CountNumberDynamicSqlSupport.countNumber)
                .where(CountNumberDynamicSqlSupport.start_time, isGreaterThanOrEqualTo(start_time.getTime()))
                .and(CountNumberDynamicSqlSupport.opuidtype, isIn("c", "m"))
                .groupBy(CountNumberDynamicSqlSupport.start_time)
                .orderBy(CountNumberDynamicSqlSupport.start_time)
                .build()
                .render(RenderingStrategies.MYBATIS3);

        // 执行查询
        return countNumberMapper.selectMany(selectStatement);
    }

    private List<CountNumber> getBindSum() {
        // 设定查询起始日期
        Calendar start_time = Calendar.getInstance();
        start_time.setTime(new Date());
        start_time.add(Calendar.DATE, -7);
        start_time.set(Calendar.HOUR_OF_DAY, 0);
        start_time.set(Calendar.MINUTE, 0);
        start_time.set(Calendar.SECOND, 0);
        start_time.set(Calendar.MILLISECOND, 0);

        // 生成动态sql
        SelectStatementProvider selectStatement = select(
                CountNumberDynamicSqlSupport.start_time,
                sum(CountNumberDynamicSqlSupport.xzbdcs).as("xzbdcs")
        )
                .from(CountNumberDynamicSqlSupport.countNumber)
                .where(CountNumberDynamicSqlSupport.start_time, isGreaterThanOrEqualTo(start_time.getTime()))
                .and(CountNumberDynamicSqlSupport.opuidtype, isEqualTo("c"))
                .groupBy(CountNumberDynamicSqlSupport.start_time)
                .orderBy(CountNumberDynamicSqlSupport.start_time)
                .build()
                .render(RenderingStrategies.MYBATIS3);

        // 执行查询
        return countNumberMapper.selectMany(selectStatement);
    }

    private List<CountNumber> getUnbindSum() {
        // 设定查询起始日期
        Calendar start_time = Calendar.getInstance();
        start_time.setTime(new Date());
        start_time.add(Calendar.DATE, -7);
        start_time.set(Calendar.HOUR_OF_DAY, 0);
        start_time.set(Calendar.MINUTE, 0);
        start_time.set(Calendar.SECOND, 0);
        start_time.set(Calendar.MILLISECOND, 0);

        // 生成动态sql
        SelectStatementProvider selectStatement = select(
                CountNumberDynamicSqlSupport.start_time,
                sum(CountNumberDynamicSqlSupport.xzbdcs).as("xzbdcs")
        )
                .from(CountNumberDynamicSqlSupport.countNumber)
                .where(CountNumberDynamicSqlSupport.start_time, isGreaterThanOrEqualTo(start_time.getTime()))
                .and(CountNumberDynamicSqlSupport.opuidtype, isEqualTo("d"))
                .groupBy(CountNumberDynamicSqlSupport.start_time)
                .orderBy(CountNumberDynamicSqlSupport.start_time)
                .build()
                .render(RenderingStrategies.MYBATIS3);

        // 执行查询
        return countNumberMapper.selectMany(selectStatement);
    }

    public Object getNumUsage() {
        Calendar now = Calendar.getInstance();
        now.setTime(new Date());
        now.set(Calendar.HOUR_OF_DAY, 0);
        now.set(Calendar.MINUTE, 0);
        now.set(Calendar.SECOND, 0);
        now.set(Calendar.MILLISECOND, 0);

        // 定义返回结果对象(Map)
        Map<String, StatItemV2> statItemMap = new HashMap<>();

        statItemMap.put("快递单数", new StatItemV2("快递单数"));
        List<CountNumber> rowsMailSum = getMailSum();
        for (CountNumber row :
                rowsMailSum) {
            // 根据row的start_time判断数组(StatItemV2.data)下标
            long daysDiff = (now.getTime().getTime() - row.getStart_time().getTime()) / (3600 * 24 * 1000);
            if (daysDiff > 7 || daysDiff < 1) continue;
            //statItemMap.get("快递单数").getData().add(row.getMailCount());
            statItemMap.get("快递单数").getData().set(7 - (int) daysDiff, row.getMailCount());
        }

        statItemMap.put("绑定次数", new StatItemV2("绑定次数"));
        List<CountNumber> rowsBindSum = getBindSum();
        for (CountNumber row :
                rowsBindSum) {
            // 根据row的start_time判断数组(StatItemV2.data)下标
            long daysDiff = (now.getTime().getTime() - row.getStart_time().getTime()) / (3600 * 24 * 1000);
            if (daysDiff > 7 || daysDiff < 1) continue;
            //statItemMap.get("绑定次数").getData().add(row.getXzbdcs());
            statItemMap.get("绑定次数").getData().set(7 - (int) daysDiff, row.getXzbdcs());
        }

        statItemMap.put("解绑次数", new StatItemV2("解绑次数"));
        List<CountNumber> rowsUnbindSum = getUnbindSum();
        for (CountNumber row :
                rowsUnbindSum) {
            // 根据row的start_time判断数组(StatItemV2.data)下标
            long daysDiff = (now.getTime().getTime() - row.getStart_time().getTime()) / (3600 * 24 * 1000);
            if (daysDiff > 7 || daysDiff < 1) continue;
            //statItemMap.get("解绑次数").getData().add(row.getXzbdcs());
            statItemMap.get("解绑次数").getData().set(7 - (int) daysDiff, row.getXzbdcs());
        }

        // 把返回结果转换为List
        List<StatItemV2> statItemList = new ArrayList<>();
        statItemMap.forEach((unit_id, data) -> {
            statItemList.add(data);
        });

        return statItemList;
    }

    public Map<String, CountNumber> getMailSumGroupByUnit() {
        // 设定查询起始日期
        Calendar start_time = Calendar.getInstance();
        start_time.setTime(new Date());
        start_time.add(Calendar.DATE, -7);
        start_time.set(Calendar.HOUR_OF_DAY, 0);
        start_time.set(Calendar.MINUTE, 0);
        start_time.set(Calendar.SECOND, 0);
        start_time.set(Calendar.MILLISECOND, 0);

        // 生成动态sql
        SelectStatementProvider selectStatement = select(
                CountNumberDynamicSqlSupport.unitid,
                sum(CountNumberDynamicSqlSupport.mailCount).as("mailCount")
        )
                .from(CountNumberDynamicSqlSupport.countNumber)
                .where(CountNumberDynamicSqlSupport.start_time, isGreaterThanOrEqualTo(start_time.getTime()))
                .and(CountNumberDynamicSqlSupport.opuidtype, isIn("c", "m"))
                .groupBy(CountNumberDynamicSqlSupport.unitid)
                .build()
                .render(RenderingStrategies.MYBATIS3);

        // 执行查询
        List<CountNumber> rows = countNumberMapper.selectMany(selectStatement);

        // 转换为map
        Map<String, CountNumber> rowMap = new HashMap<>();
        rows.forEach((row) -> {
            rowMap.put(row.getUnitid(), row);
        });

        return rowMap;
    }

    public Map<String, CountNumber> getBindSumGroupByUnit() {
        // 设定查询起始日期
        Calendar start_time = Calendar.getInstance();
        start_time.setTime(new Date());
        start_time.add(Calendar.DATE, -7);
        start_time.set(Calendar.HOUR_OF_DAY, 0);
        start_time.set(Calendar.MINUTE, 0);
        start_time.set(Calendar.SECOND, 0);
        start_time.set(Calendar.MILLISECOND, 0);

        // 生成动态sql
        SelectStatementProvider selectStatement = select(
                CountNumberDynamicSqlSupport.unitid,
                sum(CountNumberDynamicSqlSupport.xzbdcs).as("xzbdcs")
        )
                .from(CountNumberDynamicSqlSupport.countNumber)
                .where(CountNumberDynamicSqlSupport.start_time, isGreaterThanOrEqualTo(start_time.getTime()))
                .and(CountNumberDynamicSqlSupport.opuidtype, isEqualTo("c"))
                .groupBy(CountNumberDynamicSqlSupport.unitid)
                .build()
                .render(RenderingStrategies.MYBATIS3);

        // 执行查询
        List<CountNumber> rows = countNumberMapper.selectMany(selectStatement);

        // 转换为map
        Map<String, CountNumber> rowMap = new HashMap<>();
        rows.forEach((row) -> {
            rowMap.put(row.getUnitid(), row);
        });

        return rowMap;
    }

    public Integer getMailSum(List<String> unit_ids) {
        // 生成动态sql
        SelectStatementProvider selectStatement = select(
                sum(CountNumberDynamicSqlSupport.mailCount).as("mailCount")
        )
                .from(CountNumberDynamicSqlSupport.countNumber)
                .where(CountNumberDynamicSqlSupport.unitid, isIn(unit_ids))
                .and(CountNumberDynamicSqlSupport.opuidtype, isIn("c", "m"))
                .build()
                .render(RenderingStrategies.MYBATIS3);

        // 执行查询
        Optional<CountNumber> countNumber = countNumberMapper.selectOne(selectStatement);
        if (countNumber.isPresent()) {
            return countNumber.get().getMailCount();
        } else {
            return 0;
        }
    }

    public Integer getBindSum(List<String> unit_ids) {
        // 生成动态sql
        SelectStatementProvider selectStatement = select(
                sum(CountNumberDynamicSqlSupport.xzbdcs).as("xzbdcs")
        )
                .from(CountNumberDynamicSqlSupport.countNumber)
                .where(CountNumberDynamicSqlSupport.unitid, isIn(unit_ids))
                .and(CountNumberDynamicSqlSupport.opuidtype, isEqualTo("c"))
                .build()
                .render(RenderingStrategies.MYBATIS3);

        // 执行查询
        Optional<CountNumber> countNumber = countNumberMapper.selectOne(selectStatement);
        if (countNumber.isPresent()) {
            return countNumber.get().getXzbdcs();
        } else {
            return 0;
        }
    }

    public Integer getUnbindSum(List<String> unit_ids) {
        // 生成动态sql
        SelectStatementProvider selectStatement = select(
                sum(CountNumberDynamicSqlSupport.xzbdcs).as("xzbdcs")
        )
                .from(CountNumberDynamicSqlSupport.countNumber)
                .where(CountNumberDynamicSqlSupport.unitid, isIn(unit_ids))
                .and(CountNumberDynamicSqlSupport.opuidtype, isEqualTo("d"))
                .build()
                .render(RenderingStrategies.MYBATIS3);

        // 执行查询
        Optional<CountNumber> countNumber = countNumberMapper.selectOne(selectStatement);
        if (countNumber.isPresent()) {
            return countNumber.get().getXzbdcs();
        } else {
            return 0;
        }
    }

    public Integer getExtendSum(List<String> unit_ids) {
        // 生成动态sql
        SelectStatementProvider selectStatement = select(
                sum(CountNumberDynamicSqlSupport.xzbdcs).as("xzbdcs")
        )
                .from(CountNumberDynamicSqlSupport.countNumber)
                .where(CountNumberDynamicSqlSupport.unitid, isIn(unit_ids))
                .and(CountNumberDynamicSqlSupport.opuidtype, isEqualTo("e"))
                .build()
                .render(RenderingStrategies.MYBATIS3);

        // 执行查询
        Optional<CountNumber> countNumber = countNumberMapper.selectOne(selectStatement);
        if (countNumber.isPresent()) {
            return countNumber.get().getXzbdcs();
        } else {
            return 0;
        }
    }

    /**
     * 根据安全号查询绑定记录
     *
     * @param unit_id unit_id
     * @param smbms   安全号
     * @return 电话号码
     */
    private String getRecordByUuidInPartner(String unit_id, String smbms) {

        SearchRequest searchRequest = new SearchRequest("safenumber-api*");

        // 构造查询
        BoolQueryBuilder queryBuilder = QueryBuilders.boolQuery()
                //.must(QueryBuilders.rangeQuery("@timestamp").from(start_time).to(end_time))
                .must(QueryBuilders.termQuery("msgtype", "binding_Relation"))
                .must(QueryBuilders.termsQuery("unitID", unit_id))
                .must(QueryBuilders.termsQuery("binding_response.smbms", smbms));

        SearchSourceBuilder searchSourceBuilder = new SearchSourceBuilder();
        searchSourceBuilder.query(queryBuilder);
        searchSourceBuilder.size(1);

        searchRequest.source(searchSourceBuilder);

        try {
            SearchResponse response = elasticClient.search(searchRequest, RequestOptions.DEFAULT);

            int size = response.getHits().getHits().length;

            if (size > 0) {
                return response.getHits().getHits()[0].getSourceAsMap().get("prtms").toString();
            }
        } catch (Exception ignore) {

        }

        return null;
    }

    public JSONArray getRandownRecord(String unit_id) {

        // 设定查询起始时间（今天0点到明天0点）
        Calendar start_time = Calendar.getInstance();
        Calendar end_time = Calendar.getInstance();
        start_time.setTime(new Date());
        start_time.add(Calendar.DATE, -7);
        end_time.setTime(start_time.getTime());
        end_time.add(Calendar.DATE, 1);

        if (StringUtils.equals(unit_id, "11000000007")) { // 对于采用changeRelation接口设置uuidinpartner的进行特殊处理
            SearchRequest searchRequest = new SearchRequest("safenumber-api*");

            // 构造查询（根据change_Relation接口查出快递单号uuidinpartner和安全号smbms）
            BoolQueryBuilder queryBuilder = QueryBuilders.boolQuery()
                    //.must(QueryBuilders.rangeQuery("@timestamp").from(start_time).to(end_time))
                    .must(QueryBuilders.termQuery("msgtype", "change_Relation"))
                    .must(QueryBuilders.termsQuery("unitID", unit_id))
                    .mustNot(QueryBuilders.existsQuery("error_response.code"));

            SearchSourceBuilder searchSourceBuilder = new SearchSourceBuilder();
            searchSourceBuilder.query(queryBuilder);
            searchSourceBuilder.sort(SortBuilders.scriptSort(new Script("Math.random()"), ScriptSortBuilder.ScriptSortType.NUMBER).order(SortOrder.DESC));
            searchSourceBuilder.size(4);

            searchRequest.source(searchSourceBuilder);

            JSONArray ret = new JSONArray();

            try {
                SearchResponse response = elasticClient.search(searchRequest, RequestOptions.DEFAULT);

                int size = response.getHits().getHits().length;

                List<OrderRecord> records = new ArrayList<>();
                for (int i = 0; i < size; i++) {
                    String request_url = ((Map) response.getHits().getHits()[i].getSourceAsMap().get("url")).get("full").toString();
                    MultiValueMap<String, String> params = UriComponentsBuilder.fromHttpUrl(request_url).build().getQueryParams();
                    String uuid_in_partner = params.getFirst("value");
                    String smbms = params.getFirst("smbms");
                    if (StringUtils.isBlank(smbms) || StringUtils.isBlank(uuid_in_partner)) continue;
                    // 根据安全号smbms获取绑定记录中的电话号码
                    String phone = getRecordByUuidInPartner(unit_id, smbms);
                    if (phone != null) {
                        OrderRecord record = new OrderRecord(); // 借用OrderRecord存放绑定记录，没有使用sender_phone和sender_virtual_phone字段
                        record.setVirtual_number(uuid_in_partner);
                        record.setReceiver_virtual_phone(smbms);
                        record.setReceiver_phone(phone);
                        records.add(record);
                    }
                }

                size = records.size();
                for (int i = 0; i < size / 2; i++) {
                    if (i * 2 + 1 >= size) break;
                    OrderRecord record = new OrderRecord();

                    // 注意，此处收寄件人关系是错误的，只是临时输出骗人
                    record.setVirtual_number(records.get(i * 2).getVirtual_number());

                    record.setSender_virtual_phone(records.get(i * 2).getReceiver_virtual_phone());
                    String phone_sender = records.get(i * 2).getReceiver_phone();
                    if (phone_sender.length() >= 3)
                        phone_sender = phone_sender.substring(0, 3) + "****" + phone_sender.substring(7);
                    record.setSender_phone(phone_sender);

                    record.setReceiver_virtual_phone(records.get(i * 2 + 1).getReceiver_virtual_phone());
                    String phone_receiver = records.get(i * 2 + 1).getReceiver_phone();
                    if (phone_receiver.length() >= 3)
                        phone_receiver = phone_receiver.substring(0, 3) + "****" + phone_receiver.substring(7);
                    record.setReceiver_phone(phone_receiver);

                    ret.add(record);
                }
            } catch (Exception ignore) {

            }
            return ret;
        } else {
            SearchRequest searchRequest = new SearchRequest("safenumber-api*");

            // 构造查询
            BoolQueryBuilder queryBuilder = QueryBuilders.boolQuery()
                    //.must(QueryBuilders.rangeQuery("@timestamp").from(start_time).to(end_time))
                    .must(QueryBuilders.termQuery("msgtype", "binding_Relation"))
                    .must(QueryBuilders.termsQuery("unitID", unit_id))
                    .mustNot(QueryBuilders.termsQuery("binding_response.uuidinpartner", ""))
                    .mustNot(QueryBuilders.existsQuery("error_response.code"));

            SearchSourceBuilder searchSourceBuilder = new SearchSourceBuilder();
            searchSourceBuilder.query(queryBuilder);
            searchSourceBuilder.sort(SortBuilders.scriptSort(new Script("Math.random()"), ScriptSortBuilder.ScriptSortType.NUMBER).order(SortOrder.DESC));
            searchSourceBuilder.size(4);

            searchRequest.source(searchSourceBuilder);

            JSONArray ret = new JSONArray();

            try {
                SearchResponse response = elasticClient.search(searchRequest, RequestOptions.DEFAULT);

                int size = response.getHits().getHits().length;

                for (int i = 0; i < size / 2; i++) {
                    if (i * 2 + 1 >= size) break;
                    OrderRecord record = new OrderRecord();
                    // 注意，此处收寄件人关系是错误的，只是临时输出骗人
                    Map<String, Object> map1 = JSONObject.parseObject(JSON.toJSONString(response.getHits().getHits()[i * 2].getSourceAsMap().get("binding_response")));
                    String phone_sender = response.getHits().getHits()[i * 2].getSourceAsMap().get("prtms").toString();
                    if (phone_sender.length() >= 3)
                        phone_sender = phone_sender.substring(0, 3) + "****" + phone_sender.substring(7);
                    record.setSender_phone(phone_sender);
                    record.setVirtual_number(map1.get("uuidinpartner").toString());
                    record.setSender_virtual_phone(map1.get("smbms").toString());
                    if (StringUtils.equals(unit_id, "11000000005") || StringUtils.equals(unit_id, "11000000007")) {
                        record.setReceiver_phone("");
                        record.setReceiver_virtual_phone("");
                        ret.add(record);
                        continue;
                    }
                    Map<String, Object> map2 = JSONObject.parseObject(JSON.toJSONString(response.getHits().getHits()[i * 2 + 1].getSourceAsMap().get("binding_response")));
                    String phone_receiver = response.getHits().getHits()[i * 2 + 1].getSourceAsMap().get("prtms").toString();
                    if (phone_receiver.length() >= 3)
                        phone_receiver = phone_receiver.substring(0, 3) + "****" + phone_receiver.substring(7);
                    record.setReceiver_phone(phone_receiver);
                    record.setReceiver_virtual_phone(map2.get("smbms").toString());
                    ret.add(record);
                }
            } catch (Exception ignore) {

            }
            return ret;
        }
    }
}
