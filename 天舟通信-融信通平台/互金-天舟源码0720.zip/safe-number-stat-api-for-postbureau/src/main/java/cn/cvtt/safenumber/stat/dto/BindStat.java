package cn.cvtt.safenumber.stat.dto;

import com.alibaba.fastjson.annotation.JSONField;

import java.util.LinkedHashMap;
import java.util.Map;

public class BindStat {
    @JSONField(name = "绑定数据")
    private Map<String, BindStatItem> statData;

    public BindStat() {
        this.statData = new LinkedHashMap<>();
    }

    public Map<String, BindStatItem> getStatData() {
        return statData;
    }

    public void setStatData(Map<String, BindStatItem> statData) {
        this.statData = statData;
    }
}
