package cn.cvtt.safenumber.stat.service;

import cn.cvtt.safenumber.stat.dto.BindStat;
import cn.cvtt.safenumber.stat.dto.BindStatItem;
import cn.cvtt.safenumber.stat.entity.CountNumberJoin;
import cn.cvtt.safenumber.stat.mapper.CountNumberDynamicSqlSupport;
import cn.cvtt.safenumber.stat.mapper.CountNumberJoinMapper;
import cn.cvtt.safenumber.stat.mapper.TUnitDynamicSqlSupport;
import org.apache.commons.lang3.StringUtils;
import org.elasticsearch.action.support.IndicesOptions;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.client.core.CountRequest;
import org.elasticsearch.client.core.CountResponse;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.mybatis.dynamic.sql.render.RenderingStrategies;
import org.mybatis.dynamic.sql.select.render.SelectStatementProvider;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.*;

import static org.mybatis.dynamic.sql.SqlBuilder.*;

@Service
public class BindStatService {

    public final static Map<String, String> UNIT_MAP = new HashMap<String, String>() {
        {
            put("11000000001", "中通快递");
            put("11000000002", "申通快递");
            put("11000000003", "京广快递");
            put("11000000005", "韵达快递");
            put("11000000007", "苏宁快递");
        }
    };

    public final static Map<String, String> MSG_TYPE_MAP = new HashMap<String, String>() {
        {
            put("binding_Relation", "绑定");
            put("remove_Relation", "解绑");
            put("extend_Relation", "延期");
        }
    };

    //@Value("#{'${cvtt.exclude-unit}'.split(',')}")
    //private List<String> excludeUnit;
    @Value("${cvtt.exclude-unit:}")
    private String[] excludeUnit;

    @Resource
    private CountNumberJoinMapper countNumberJoinMapper;

    @Resource
    private RestHighLevelClient elasticClient;

    /**
     * 获取近几天的统计数据
     *
     * @param days 天数
     * @return 统计数据
     */
    public Map<String, BindStat> getBindStatByDays(Integer days) {
        // 默认取前7天数据
        if (days == null) days = 7;
        // 设定查询起始日期
        Calendar start_time = Calendar.getInstance();
        start_time.setTime(new Date());
        start_time.add(Calendar.DATE, days * -1);
        start_time.set(Calendar.HOUR_OF_DAY, 0);
        start_time.set(Calendar.MINUTE, 0);
        start_time.set(Calendar.SECOND, 0);
        start_time.set(Calendar.MILLISECOND, 0);

        // 生成动态sql
        SelectStatementProvider selectStatement = select(
                CountNumberDynamicSqlSupport.id,
                CountNumberDynamicSqlSupport.unitid,
                CountNumberDynamicSqlSupport.countNumber.start_time,
                CountNumberDynamicSqlSupport.countNumber.mailCount,
                CountNumberDynamicSqlSupport.countNumber.xzbdcs,
                CountNumberDynamicSqlSupport.opuidtype,
                CountNumberDynamicSqlSupport.msgtype,
                TUnitDynamicSqlSupport.TUnit.unitname
        )
                .from(CountNumberDynamicSqlSupport.countNumber, "stat")
                .leftJoin(TUnitDynamicSqlSupport.TUnit, "unit").on(CountNumberDynamicSqlSupport.countNumber.unitid, equalTo(TUnitDynamicSqlSupport.TUnit.unitid))
                .where(CountNumberDynamicSqlSupport.start_time, isGreaterThanOrEqualTo(start_time.getTime()))
                .orderBy(CountNumberDynamicSqlSupport.start_time)
                .build()
                .render(RenderingStrategies.MYBATIS3);

        // 执行查询
        List<CountNumberJoin> rows = countNumberJoinMapper.selectMany(selectStatement);

        // 遍历结果集，放入新的数据结构（map）
        Map<String, BindStat> bindStatMap = new LinkedHashMap<>();

        for (CountNumberJoin row :
                rows) {
            if (StringUtils.isBlank(row.getUnitname())) continue;
            if (row.getStart_time() == null) continue;
            boolean ignoreUnit = false;
            for (String unit :
                    excludeUnit) {
                if (StringUtils.equals(unit, row.getUnitid())) {
                    ignoreUnit = true;
                    break;
                }
            }
            if (ignoreUnit) continue;

            String startTime = new SimpleDateFormat("yyyy-MM-dd").format(row.getStart_time());

            BindStat bindStat = bindStatMap.get(row.getUnitname());
            if (bindStat == null) bindStat = new BindStat();

            BindStatItem bindStatItem = bindStat.getStatData().get(startTime);
            if (bindStatItem == null) bindStatItem = new BindStatItem();

            switch (row.getOpuidtype()) {
                case "c":
                    bindStatItem.setIncreaseBind(row.getXzbdcs());
                    bindStatItem.setIncreaseMail(row.getMailCount());
                    break;
                case "d":
                    bindStatItem.setIncreaseUnbind(row.getXzbdcs());
                    break;
                case "e":
                    bindStatItem.setIncreaseExtend(row.getXzbdcs());
                    break;
            }
            bindStat.getStatData().put(startTime, bindStatItem);
            bindStatMap.put(row.getUnitname(), bindStat);
        }

        // 变量map求各统计量的和
        bindStatMap.forEach((unit, bindStat) -> {
            BindStatItem bindStatSumItem = new BindStatItem();
            bindStat.getStatData().forEach((date, bindStatItem) -> {
                bindStatSumItem.setIncreaseMail(bindStatSumItem.getIncreaseMail() + bindStatItem.getIncreaseMail());
                bindStatSumItem.setIncreaseBind(bindStatSumItem.getIncreaseBind() + bindStatItem.getIncreaseBind());
                bindStatSumItem.setIncreaseUnbind(bindStatSumItem.getIncreaseUnbind() + bindStatItem.getIncreaseUnbind());
                bindStatSumItem.setIncreaseExtend(bindStatSumItem.getIncreaseExtend() + bindStatItem.getIncreaseExtend());
            });
            bindStat.getStatData().put("总计", bindStatSumItem);
        });
        return bindStatMap;
    }

    private long getTodayBindStat(String unit_id, String msg_type) {
        // 设定查询起始时间（今天0点到明天0点）
        Calendar start_time = Calendar.getInstance();
        Calendar end_time = Calendar.getInstance();
        start_time.setTime(new Date());
        start_time.set(Calendar.HOUR_OF_DAY, 0);
        start_time.set(Calendar.MINUTE, 0);
        start_time.set(Calendar.SECOND, 0);
        start_time.set(Calendar.MILLISECOND, 0);
        end_time.setTime(start_time.getTime());
        end_time.add(Calendar.DATE, 1);

        // 构造查询
        SearchSourceBuilder searchSourceBuilder = new SearchSourceBuilder();
        searchSourceBuilder.query(
                QueryBuilders.boolQuery()
                        .must(QueryBuilders.termsQuery("client.ip", "10.15.144.31", "10.15.144.32"))
                        //.must(QueryBuilders.rangeQuery("@timestamp").from("2020-11-03T16:00:00.000Z").to("2020-11-04T15:59:59.999Z")) （ES中有8小时时差，用字符时需要处理）
                        .must(QueryBuilders.rangeQuery("@timestamp").from(start_time).to(end_time))
                        .must(QueryBuilders.termQuery("msgtype", msg_type))
                        .must(QueryBuilders.termQuery("unitID", unit_id))
                        .mustNot(QueryBuilders.existsQuery("error_response.code"))
        );

        CountRequest countRequest = new CountRequest("safenumber-api*")
                .indicesOptions(IndicesOptions.lenientExpandOpen())
                .preference("_local");
        countRequest.source(searchSourceBuilder);

        try {
            CountResponse countResponse = elasticClient
                    .count(countRequest, RequestOptions.DEFAULT);
            return countResponse.getCount();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return 0;
    }

    /**
     * 获取今日数据
     *
     * @return 统计数据
     */
    public Map<String, BindStat> getBindStatToday() {
        Map<String, BindStat> bindStatMap = new LinkedHashMap<>();

        UNIT_MAP.forEach((unit_id, unit_name) -> {
            BindStat bindStat = new BindStat();
            BindStatItem bindStatItem = new BindStatItem();
            MSG_TYPE_MAP.forEach((msg_type, msg_name) -> {
                long num = getTodayBindStat(unit_id, msg_type);
                switch (msg_type) {
                    case "binding_Relation":
                        bindStatItem.setIncreaseBind((int) num);
                        break;
                    case "extend_Relation":
                        bindStatItem.setIncreaseExtend((int) num);
                        break;
                    case "remove_Relation":
                        bindStatItem.setIncreaseUnbind((int) num);
                        break;
                    default:
                        break;
                }
            });
            bindStat.getStatData().put(new SimpleDateFormat("yyyy-MM-dd").format(new Date()), bindStatItem);
            bindStatMap.put(unit_name, bindStat);
        });

        return bindStatMap;
    }
}
