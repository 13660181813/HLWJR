package cn.cvtt.safenumber.stat.dto;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class StatItemV2 {
    private String name;
    private List<Object> data;

    public StatItemV2(String name) {
        this.name = name;
        this.data = new ArrayList<>(Arrays.asList(0, 0, 0, 0, 0, 0, 0));
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<Object> getData() {
        return data;
    }

    public void setData(List<Object> data) {
        this.data = data;
    }
}
