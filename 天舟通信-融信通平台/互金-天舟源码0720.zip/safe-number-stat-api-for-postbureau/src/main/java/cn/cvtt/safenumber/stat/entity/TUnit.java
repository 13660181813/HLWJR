package cn.cvtt.safenumber.stat.entity;

import java.util.Date;
import javax.annotation.Generated;

public class TUnit {
    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private String unitid;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private Date addtime;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private String addtimes;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private String operator;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private String parentid;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private String safeNumberUser;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private String unitadd;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private String unitcontact;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private String unitkey;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private String unitmobile;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private String unitname;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private String unittel;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private String unittype;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    private String unituidnumber;

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public String getUnitid() {
        return unitid;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setUnitid(String unitid) {
        this.unitid = unitid;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public Date getAddtime() {
        return addtime;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setAddtime(Date addtime) {
        this.addtime = addtime;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public String getAddtimes() {
        return addtimes;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setAddtimes(String addtimes) {
        this.addtimes = addtimes;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public String getOperator() {
        return operator;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setOperator(String operator) {
        this.operator = operator;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public String getParentid() {
        return parentid;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setParentid(String parentid) {
        this.parentid = parentid;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public String getSafeNumberUser() {
        return safeNumberUser;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setSafeNumberUser(String safeNumberUser) {
        this.safeNumberUser = safeNumberUser;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public String getUnitadd() {
        return unitadd;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setUnitadd(String unitadd) {
        this.unitadd = unitadd;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public String getUnitcontact() {
        return unitcontact;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setUnitcontact(String unitcontact) {
        this.unitcontact = unitcontact;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public String getUnitkey() {
        return unitkey;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setUnitkey(String unitkey) {
        this.unitkey = unitkey;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public String getUnitmobile() {
        return unitmobile;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setUnitmobile(String unitmobile) {
        this.unitmobile = unitmobile;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public String getUnitname() {
        return unitname;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setUnitname(String unitname) {
        this.unitname = unitname;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public String getUnittel() {
        return unittel;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setUnittel(String unittel) {
        this.unittel = unittel;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public String getUnittype() {
        return unittype;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setUnittype(String unittype) {
        this.unittype = unittype;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public String getUnituidnumber() {
        return unituidnumber;
    }

    @Generated("org.mybatis.generator.api.MyBatisGenerator")
    public void setUnituidnumber(String unituidnumber) {
        this.unituidnumber = unituidnumber;
    }
}